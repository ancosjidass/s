# -*- coding: utf-8 -*-
"""
سیستمِ دعوت: لینکِ شخصیِ https://t.me/<bot>?start=ref_<آیدی>.
فقط برای کسی که «تازه‌ست» (قبلاً بات رو استارت نکرده/هاپ نکرده) پاداش می‌دیم؛ هر نفر فقط یک بار برای یک دعوت‌کننده.
پاداش از لجرِ هاپ پوینتِ موجود (war_svc.hop_apply) واریز می‌شه و مقدارش از پنلِ ادمین قابل‌تغییره.
"""
import datetime
import threading
import urllib.parse

from sqlalchemy import Column, Integer, BigInteger, Float, String, DateTime, UniqueConstraint, func
from sqlalchemy.exc import IntegrityError

import db
from db import Base, now

LOCK = threading.RLock()

CFG = [
    ("ref_enabled", "🟢 سیستمِ دعوت روشن باشه؟ (۱/۰)", "1", ""),
    ("ref_reward_hop", "💰 پاداشِ هر دعوتِ موفق (هاپ پوینت)", "250000000000", "۲۵۰ میلیارد = 250000000000"),
    ("ref_new_rule", "🆕 «تازه» یعنی چی؟ (no_row / never_hopped)", "no_row",
     "no_row = هیچ‌وقت بات رو ندیده | never_hopped = حسابِ قدیمی هست ولی هیچ‌وقت هاپ نزده"),
    ("ref_daily_cap", "📆 سقفِ دعوتِ پاداش‌دار در روزِ هر نفر (۰ = بدونِ سقف)", "0", "ضدِ اکانتِ فیک؛ پیشنهاد: ۵ تا ۱۰"),
    ("ref_total_cap", "♾ سقفِ کلِ دعوت‌های پاداش‌دارِ هر نفر (۰ = بدونِ سقف)", "0", ""),
    ("ref_notify_inviter", "🔔 به دعوت‌کننده تو پیوی خبر بده؟ (۱/۰)", "1", ""),
    ("ref_add_admin_rights", "➕ دسترسی‌های ادمینیِ درخواستی موقعِ افزودن به گروه", "delete_messages+pin_messages+invite_users+restrict_members",
     "با + جدا کن؛ مثلا delete_messages+pin_messages+invite_users"),
    ("ref_msg_inviter", "💬 پیامِ خبر به دعوت‌کننده", "🎉 {name} با لینکِ دعوتِ تو وارد بات شد!\n💰 +{hop} هاپ پوینت واریز شد.\n👥 تا الان {count} نفر رو دعوت کردی.", "جاهای {name} {hop} {count}"),
    ("ref_msg_welcome", "💬 پیامِ خوش‌آمد به دعوت‌شده", "👋 با دعوتِ {name} وارد بات شدی؛ خوش اومدی!", "جای {name}"),
    ("ref_msg_share", "📤 متنِ پیش‌فرضِ اشتراک‌گذاریِ لینک", "🦘 بیا تو ربات هاپ بازی کنیم! با این لینک وارد شو:", ""),
]
CFG_DEFAULT = {k: v for k, _l, v, _h in CFG}
CFG_LABEL = {k: l for k, l, _v, _h in CFG}
CFG_HELP = {k: h for k, _l, _v, h in CFG}
db.DEFAULT_CONFIG.update(CFG_DEFAULT)


class Referral(Base):
    __tablename__ = "referrals"
    id = Column(Integer, primary_key=True, autoincrement=True)
    inviter_id = Column(BigInteger, nullable=False, index=True)
    invitee_id = Column(BigInteger, nullable=False)
    hop = Column(Float, default=0)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("invitee_id", name="uq_referral_invitee"),)


def init_referral():
    Base.metadata.create_all(db.engine)
    s = db.get_session()
    try:
        have = {c.key for c in s.query(db.Config).all()}
        for k, v in CFG_DEFAULT.items():
            if k not in have:
                s.add(db.Config(key=k, value=v))
        s.commit()
        db.cfg_cache_clear()   # کلیدهایِ تازه‌سیدشده فوراً دیده بشن
    finally:
        s.close()


class _Safe(dict):
    def __missing__(self, k):
        return "{" + k + "}"


def msg(session, key, **kw):
    tpl = db.cfg_get(session, key) or CFG_DEFAULT[key]
    try:
        return tpl.format_map(_Safe(kw))
    except (ValueError, IndexError):
        return CFG_DEFAULT[key].format_map(_Safe(kw))


def gi(session, k, d=0):
    try:
        return int(float(db.cfg_get(session, k)))
    except (TypeError, ValueError):
        return d


# ---------------------------------------------------------------------------
def link(bot_username: str, uid: int) -> str:
    return f"https://t.me/{bot_username}?start=ref_{int(uid)}"


def add_group_url(bot_username: str, session=None) -> str:
    """لینکِ «افزودنِ ربات به گروه» که صفحه‌ی انتخابِ گروه + درخواستِ ادمین‌شدن رو باز می‌کنه."""
    own = session is None
    s = session or db.get_session()
    try:
        rights = (db.cfg_get(s, "ref_add_admin_rights") or "").strip()
    finally:
        if own:
            s.close()
    rights = "".join(ch for ch in rights if ch.isalnum() or ch in "_+")
    url = f"https://t.me/{bot_username}?startgroup=hopadd"
    return url + (f"&admin={rights}" if rights else "")


def share_url(bot_username: str, uid: int, session) -> str:
    text = msg(session, "ref_msg_share")
    return "https://t.me/share/url?" + urllib.parse.urlencode({"url": link(bot_username, uid), "text": text}, quote_via=urllib.parse.quote)


def stats(session, uid: int) -> dict:
    n, total = session.query(func.count(Referral.id), func.coalesce(func.sum(Referral.hop), 0)).filter(Referral.inviter_id == uid).one()
    last = session.query(Referral).filter(Referral.inviter_id == uid).order_by(Referral.id.desc()).limit(10).all()
    return {"count": int(n or 0), "hop": float(total or 0), "last": last}


def _is_new(session, invitee_id: int, existed_before: bool) -> bool:
    rule = (db.cfg_get(session, "ref_new_rule") or "no_row").strip()
    if not existed_before:
        return True
    if rule == "never_hopped":
        u = session.get(db.User, invitee_id)
        return bool(u) and (u.hop_count or 0) == 0 and u.last_hop_at is None
    return False


def register(session, tg_user, payload: str, existed_before: bool, at=None):
    """/start ref_<id> -> dict(inviter_id, invitee_id, hop, count, name) یا None (حساب نشد)."""
    at = at or datetime.datetime.utcnow()
    with LOCK:
        if not gi(session, "ref_enabled", 1):
            return None
        if not payload.isdigit():
            return None
        inviter_id, invitee_id = int(payload), int(tg_user.id)
        if inviter_id == invitee_id or getattr(tg_user, "is_bot", False):
            return None
        inviter = session.get(db.User, inviter_id)
        if inviter is None or not _is_new(session, invitee_id, existed_before):
            return None
        if session.query(Referral).filter_by(invitee_id=invitee_id).first():
            return None
        daily = gi(session, "ref_daily_cap", 0)
        if daily:
            day_start = at.replace(hour=0, minute=0, second=0, microsecond=0)
            if session.query(Referral).filter(Referral.inviter_id == inviter_id, Referral.created_at >= day_start).count() >= daily:
                return None
        total = gi(session, "ref_total_cap", 0)
        if total and session.query(Referral).filter_by(inviter_id=inviter_id).count() >= total:
            return None
        try:
            reward = float(db.cfg_get(session, "ref_reward_hop") or 0)
        except ValueError:
            reward = 0.0
        sp = session.begin_nested()
        try:
            session.add(Referral(inviter_id=inviter_id, invitee_id=invitee_id, hop=reward, created_at=at))
            session.flush()
            sp.commit()
        except IntegrityError:
            sp.rollback()
            return None
        if reward > 0:
            import war_svc
            war_svc.hop_apply(session, inviter, reward, "BONUS", f"referral:{invitee_id}", ref=invitee_id)
        session.commit()
        return {"inviter_id": inviter_id, "invitee_id": invitee_id, "hop": reward, "count": stats(session, inviter_id)["count"],
                "invitee_name": tg_user.first_name or tg_user.username or str(invitee_id)}


def validate_cfg(key: str, raw: str) -> str:
    raw = str(raw).strip()
    if key not in CFG_LABEL:
        raise ValueError("کلیدِ ناشناخته.")
    if key == "ref_new_rule":
        if raw not in ("no_row", "never_hopped"):
            raise ValueError("فقط no_row یا never_hopped.")
        return raw
    if key == "ref_add_admin_rights":
        ok = set("abcdefghijklmnopqrstuvwxyz_+")
        if raw and not set(raw) <= ok:
            raise ValueError("فقط حروفِ انگلیسیِ کوچک، _ و +")
        return raw
    if key.startswith("ref_msg_"):
        if not raw:
            raise ValueError("نمی‌تونه خالی باشه.")
        try:
            raw.format_map(_Safe())
        except (ValueError, IndexError):
            raise ValueError("آکولادهای متن درست نیست.")
        return raw
    try:
        v = float(raw)
    except ValueError:
        raise ValueError("یه عدد بفرست.")
    if v != v or v < 0 or v == float("inf"):
        raise ValueError("عددِ نامعتبر/منفی.")
    if key in ("ref_enabled", "ref_notify_inviter") and v not in (0, 1):
        raise ValueError("فقط ۰ یا ۱.")
    return str(int(v)) if v == int(v) else str(v)
