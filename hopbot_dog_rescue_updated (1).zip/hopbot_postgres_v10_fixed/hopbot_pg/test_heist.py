# -*- coding: utf-8 -*-
"""
تست‌های سرویسِ «سرقت تیمی هاپویی» روی دیتابیسِ موقتِ SQLite (به دیتابیسِ واقعی دست نمی‌زنه).
اجرا:  python -m pytest test_heist.py -q
"""
import datetime
import os
import tempfile
import types

os.environ.setdefault("BOT_TOKEN", "1:x")
os.environ.setdefault("OWNER_ID", "999")
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "heist_test.db")

import pytest  # noqa: E402

import db  # noqa: E402
import war_db as W  # noqa: E402
import heist_db as H  # noqa: E402
import heist_engine as E  # noqa: E402
import heist_svc as S  # noqa: E402
import heist_ui as UI  # noqa: E402
from heist_svc import HeistError, HeistEnded  # noqa: E402

T0 = datetime.datetime(2026, 10, 1, 12, 0, 0)
CHAT = -100123


class Clock:
    def __init__(self):
        self.t = T0

    def __call__(self):
        return self.t

    def adv(self, **kw):
        self.t += datetime.timedelta(**kw)
        return self.t


@pytest.fixture()
def clock(monkeypatch):
    c = Clock()
    monkeypatch.setattr(S, "utcnow", c)
    monkeypatch.setattr(db, "now", c, raising=False)
    return c


@pytest.fixture()
def ses(clock):
    db.Base.metadata.drop_all(db.engine)
    db.init_db()
    W.init_war()
    H.init_heist()
    s = db.get_session()
    yield s
    s.rollback()
    s.close()


def mkuser(s, uid, hop=0.0, xp=0.0):
    s.add(db.User(telegram_id=uid, username=f"u{uid}", first_name=f"U{uid}", hop_points=hop))
    s.commit()
    p = S.get_player(s, uid)
    p.xp = p.xp_total = xp
    s.commit()
    return s.get(db.User, uid)


def mkloc(s, name="Supermarket", **over):
    loc = S.admin_create_location(s, 1, name)
    base = dict(req_xp=1000, success_xp=250, cooldown_minutes=480, police_seconds=300, jail_minutes=180, bail_amount=300_000_000,
                items_count=5, item_fail_pct=12, value_variance=1_000_000, auto_start=True, grid_cells=20)
    base.update(over)
    for k, v in base.items():
        S.admin_set_location_field(s, 1, loc.id, k, str(v))
    S.admin_add_item(s, 1, loc.id, "Electronic Box", 50_000_000)
    return s.get(H.HeistLocation, loc.id)


def team(s, loc, ids=(1, 2, 3, 4), xp=5000, skills=None):
    users = [mkuser(s, i, hop=0, xp=xp) for i in ids]
    for u in users:
        p = S.get_player(s, u.telegram_id)
        for r, v in (skills or {}).items():
            setattr(p, "skill_" + r, v)
    s.commit()
    op = S.create_lobby(s, users[0], CHAT, loc.id)
    started = False
    for u in users[1:]:
        op, started = S.join_lobby(s, op.id, u, CHAT)
    return op, users, started


def uid_of(s, op, role):
    return s.query(H.HeistOpMember).filter_by(op_id=op.id, role=role).first().user_id


def play_spy(s, op):
    uid = uid_of(s, op, "spy")
    pd = S._pd(s.get(H.HeistOperation, op.id))
    for c in pd["seq"]:
        S.spy_pick(s, op.id, uid, CHAT, c)
    return S.spy_confirm(s, op.id, uid, CHAT)


def play_safe_all(s, op):
    uid = uid_of(s, op, "safe")
    for it in s.query(H.HeistOpItem).filter_by(op_id=op.id).all():
        S.safe_open(s, op.id, uid, CHAT, it.cell)


def play_carry(s, op, clock):
    uid = uid_of(s, op, "carrier")
    n = len(S._pd(s.get(H.HeistOperation, op.id))["queue"])
    for _ in range(n):
        S.carrier_start_item(s, op.id, uid, CHAT)
        clock.adv(seconds=16)
        S.refresh(s, op.id, CHAT)


def play_drive(s, op, clock):
    uid = uid_of(s, op, "driver")
    S.driver_start(s, op.id, uid, CHAT)
    clock.adv(seconds=170)
    S.refresh(s, op.id, CHAT)


def full_success(s, clock, loc=None, **kw):
    loc = loc or mkloc(s)
    op, users, _ = team(s, loc, **kw)
    play_spy(s, op)
    play_safe_all(s, op)
    play_carry(s, op, clock)
    play_drive(s, op, clock)
    return s.get(H.HeistOperation, op.id), users, loc


# ---------------------------------------------------------------- Basics ----
def test_no_default_locations(ses):
    assert S.list_locations(ses, include_hidden=True) == []
    assert ses.query(H.HeistLocation).count() == 0


def test_trigger_text_registered():
    import handlers
    src = open(handlers.__file__, encoding="utf-8").read()
    assert 'normalized == "دزدی تیمی هاپویی"' in src


def test_admin_creates_location_usable_immediately(ses):
    loc = mkloc(ses)
    assert loc.name == "Supermarket" and loc.req_xp == 1000 and loc.police_seconds == 300
    u = mkuser(ses, 1, xp=1000)
    assert S.location_state(ses, u, loc)["state"] == "available"


def test_two_locations_independent(ses):
    a = mkloc(ses, "Supermarket")
    b = mkloc(ses, "Bank", req_xp=5000, success_xp=1000, cooldown_minutes=600, jail_minutes=420, bail_amount=1_000_000_000)
    assert (a.cooldown_minutes, b.cooldown_minutes, a.req_xp, b.req_xp) == (480, 600, 1000, 5000)


def test_location_needs_items(ses):
    loc = S.admin_create_location(ses, 1, "Empty")
    u = mkuser(ses, 1, xp=99999)
    with pytest.raises(HeistError):
        S.create_lobby(ses, u, CHAT, loc.id)


def test_admin_validation(ses):
    loc = mkloc(ses)
    for key, val in (("police_seconds", "1"), ("items_count", "99"), ("item_fail_pct", "150"), ("grid_cells", "0"), ("cooldown_trigger", "xx")):
        with pytest.raises(HeistError):
            S.admin_set_location_field(ses, 1, loc.id, key, val)


# ---------------------------------------------------------- Lobby / roles ----
def test_lobby_roles_by_join_order_and_full(ses, clock):
    loc = mkloc(ses)
    op, users, started = team(ses, loc)
    roles = {m.user_id: m.role for m in ses.query(H.HeistOpMember).filter_by(op_id=op.id)}
    assert [roles[u.telegram_id] for u in users] == ["spy", "safe", "carrier", "driver"]
    assert started and ses.get(H.HeistOperation, op.id).status == E.SPY


def test_manual_start_when_auto_start_off(ses, clock):
    loc = mkloc(ses, auto_start=0)
    op, users, started = team(ses, loc)
    assert not started and ses.get(H.HeistOperation, op.id).status == E.FULL
    with pytest.raises(HeistError):
        S.manual_start(ses, op.id, users[1].telegram_id)       # فقط سازنده
    S.manual_start(ses, op.id, users[0].telegram_id)
    assert ses.get(H.HeistOperation, op.id).status == E.SPY


def test_fifth_player_cannot_join_and_double_join(ses, clock):
    loc = mkloc(ses)
    op, users, _ = team(ses, loc)
    extra = mkuser(ses, 9, xp=5000)
    with pytest.raises(HeistError):
        S.join_lobby(ses, op.id, extra, CHAT)
    loc2 = mkloc(ses, "B2")
    op2 = S.create_lobby(ses, mkuser(ses, 20, xp=5000), CHAT, loc2.id)
    with pytest.raises(HeistError):
        S.join_lobby(ses, op2.id, ses.get(db.User, 20), CHAT)


def test_cannot_join_two_operations(ses, clock):
    loc = mkloc(ses)
    a = mkuser(ses, 1, xp=5000)
    b = mkuser(ses, 2, xp=5000)
    S.create_lobby(ses, a, CHAT, loc.id)
    loc2 = mkloc(ses, "Other")
    with pytest.raises(HeistError):
        S.create_lobby(ses, a, CHAT, loc2.id)
    op_b = S.create_lobby(ses, b, CHAT, loc2.id)
    with pytest.raises(HeistError):
        S.join_lobby(ses, op_b.id, a, CHAT)


def test_leave_before_start_frees_slot_and_rejoin_resnapshots_skill(ses, clock):
    loc = mkloc(ses)
    users = [mkuser(ses, i, xp=5000) for i in (1, 2, 3)]
    op = S.create_lobby(ses, users[0], CHAT, loc.id)
    S.join_lobby(ses, op.id, users[1], CHAT)
    p = S.get_player(ses, 2)
    p.skill_safe = 2
    ses.commit()
    S.join_lobby(ses, op.id, users[2], CHAT)
    m = ses.query(H.HeistOpMember).filter_by(op_id=op.id, user_id=2).first()
    assert m.skill == 0                                         # Snapshot: تغییرِ بعدی اثر نداره
    S.leave_op(ses, op.id, 2)
    assert ses.query(H.HeistOpMember).filter_by(op_id=op.id).count() == 2
    S.join_lobby(ses, op.id, users[1], CHAT)
    m = ses.query(H.HeistOpMember).filter_by(op_id=op.id, user_id=2).first()
    assert m.skill == 2 and m.role == "safe"                    # Rejoin = Snapshotِ جدید


def test_leave_not_member_and_double_leave(ses, clock):
    loc = mkloc(ses)
    op = S.create_lobby(ses, mkuser(ses, 1, xp=5000), CHAT, loc.id)
    mkuser(ses, 2, xp=5000)
    with pytest.raises(HeistError):
        S.leave_op(ses, op.id, 2)
    j = ses.get(db.User, 2)
    S.join_lobby(ses, op.id, j, CHAT)
    S.leave_op(ses, op.id, 2)
    with pytest.raises(HeistError):
        S.leave_op(ses, op.id, 2)


def test_creator_leave_cancels_and_drops_cooldown(ses, clock):
    loc = mkloc(ses, cooldown_trigger="on_lobby_start")
    u = mkuser(ses, 1, xp=5000)
    op = S.create_lobby(ses, u, CHAT, loc.id)
    assert S.active_cooldown(ses, 1, loc.id, clock()) is not None
    assert S.leave_op(ses, op.id, 1) == "cancelled"
    assert S.active_cooldown(ses, 1, loc.id, clock()) is None


def test_lobby_expires(ses, clock):
    loc = mkloc(ses)
    op = S.create_lobby(ses, mkuser(ses, 1, xp=5000), CHAT, loc.id)
    clock.adv(minutes=31)
    S.run_tick(clock())
    assert ses.get(H.HeistOperation, op.id).status == E.CANCELLED


def test_leave_after_start_blocked_by_default(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    with pytest.raises(HeistError):
        S.leave_op(ses, op.id, 2)


def test_leave_after_start_fail_rule(ses, clock):
    op, users, _ = team(ses, mkloc(ses, leave_after_start="fail"))
    assert S.leave_op(ses, op.id, 2) == "failed"
    o = ses.get(H.HeistOperation, op.id)
    assert o.result == "failed" and o.fail_reason == "leave"


# -------------------------------------------------- XP lock / cooldown ----
def test_xp_lock_blocks_create_and_join_even_if_button_exists(ses, clock):
    loc = mkloc(ses)
    rich = mkuser(ses, 1, xp=5000)
    poor = mkuser(ses, 2, xp=10)
    op = S.create_lobby(ses, rich, CHAT, loc.id)
    assert S.location_state(ses, poor, loc)["state"] == "locked"
    with pytest.raises(HeistError) as e:
        S.join_lobby(ses, op.id, poor, CHAT)
    assert "باز نشده" in str(e.value)
    with pytest.raises(HeistError):
        S.create_lobby(ses, poor, CHAT, loc.id)


def test_unlock_uses_lifetime_xp_so_spending_does_not_relock(ses, clock):
    loc = mkloc(ses)
    u = mkuser(ses, 1, xp=1000)
    S.skill_add(ses, 1, "spy")
    assert S.location_state(ses, u, loc)["state"] == "available"


def test_cooldown_per_location_independent(ses, clock):
    a = mkloc(ses, "Supermarket", cooldown_minutes=480)
    b = mkloc(ses, "Bank", cooldown_minutes=600)
    op, users, _ = team(ses, a)
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    u = ses.get(db.User, 1)
    assert S.location_state(ses, u, a)["state"] == "cooldown"
    assert S.location_state(ses, u, b)["state"] == "available"
    with pytest.raises(HeistError) as e:
        S.create_lobby(ses, u, CHAT, a.id)
    assert "Cooldown" in str(e.value) and ":" in str(e.value)    # زمانِ باقی‌مانده نمایش داده می‌شه
    S.create_lobby(ses, u, CHAT, b.id)


def test_cooldown_blocks_join_of_someone_elses_lobby(ses, clock):
    a = mkloc(ses, "Supermarket")
    op, users, _ = team(ses, a)
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    other = mkuser(ses, 50, xp=5000)
    lob = S.create_lobby(ses, other, CHAT, a.id)
    with pytest.raises(HeistError):
        S.join_lobby(ses, lob.id, ses.get(db.User, 1), CHAT)


def test_cooldown_expires(ses, clock):
    a = mkloc(ses, cooldown_minutes=10)
    op, users, _ = team(ses, a)
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    clock.adv(minutes=11)
    assert S.location_state(ses, ses.get(db.User, 1), a)["state"] == "available"


@pytest.mark.parametrize("trigger,expect_after_success,expect_after_fail", [
    ("on_success", True, False), ("on_failure", False, True), ("on_finish", True, True), ("on_start", True, True)])
def test_cooldown_triggers(ses, clock, trigger, expect_after_success, expect_after_fail):
    loc = mkloc(ses, cooldown_trigger=trigger)
    op, users, _ = team(ses, loc)
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    assert (S.active_cooldown(ses, 1, loc.id, clock()) is not None) == expect_after_success
    ses.query(H.HeistCooldown).delete()
    ses.query(db.User).update({"jailed_until": None})
    ses.commit()
    op2, users2, _ = team(ses, loc, ids=(11, 12, 13, 14))
    clock.adv(minutes=6)
    S.refresh(ses, op2.id, CHAT)                                # پلیس
    assert ses.get(H.HeistOperation, op2.id).result == "failed"
    assert (S.active_cooldown(ses, 11, loc.id, clock()) is not None) == expect_after_fail


# ------------------------------------------------------------- Skills ----
def test_skill_conversion_and_reassignment(ses, clock):
    mkuser(ses, 1, xp=25)
    S.skill_add(ses, 1, "safe"); S.skill_add(ses, 1, "safe"); S.skill_add(ses, 1, "driver")
    p = S.get_player(ses, 1)
    assert (p.skill_safe, p.skill_driver, p.xp) == (2, 1, 10)       # هر ۵ XP = ۱ امتیاز
    S.skill_sub(ses, 1, "safe")
    p = S.get_player(ses, 1)
    assert p.skill_safe == 1 and p.free_points == 1 and p.xp == 10  # برگشت به XP نداریم
    S.skill_add(ses, 1, "driver")
    p = S.get_player(ses, 1)
    assert p.skill_driver == 2 and p.free_points == 0 and p.xp == 10  # اول امتیازِ آزاد خرج می‌شه


def test_skill_needs_xp_and_respects_max(ses, clock):
    mkuser(ses, 1, xp=4)
    with pytest.raises(HeistError):
        S.skill_add(ses, 1, "spy")
    S.admin_set_global_cfg(ses, 1, "heist_skill_max_safe", "2")
    S.admin_adjust_player(ses, 1, 1, xp_delta=1000)
    S.skill_add(ses, 1, "safe"); S.skill_add(ses, 1, "safe")
    with pytest.raises(HeistError):
        S.skill_add(ses, 1, "safe")


def test_skill_sub_floor(ses, clock):
    mkuser(ses, 1, xp=0)
    with pytest.raises(HeistError):
        S.skill_sub(ses, 1, "spy")


def test_conversion_rate_admin_configurable(ses, clock):
    S.admin_set_global_cfg(ses, 1, "heist_xp_per_skill_point", "50")
    mkuser(ses, 1, xp=49)
    with pytest.raises(HeistError):
        S.skill_add(ses, 1, "spy")
    S.admin_adjust_player(ses, 1, 1, xp_delta=1)
    S.skill_add(ses, 1, "spy")


def test_skill_change_mid_operation_has_no_effect(ses, clock):
    op, users, _ = team(ses, mkloc(ses), skills={"spy": 1, "driver": 2})
    p = S.get_player(ses, 4)
    p.skill_driver = 5
    ses.commit()
    assert ses.query(H.HeistOpMember).filter_by(op_id=op.id, role="driver").first().skill == 2
    drive_uid = 4
    # از Phase راننده زمان ۱۶۵ - ۲×۱۴ = ۱۳۷ باید باشه، نه ۱۶۵ - ۵×۱۴
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock)
    S.driver_start(ses, op.id, drive_uid, CHAT)
    o = ses.get(H.HeistOperation, op.id)
    assert int((o.phase_ready_at - clock()).total_seconds()) == 137


# ----------------------------------------------------------------- Spy ----
def test_spy_only_spy_can_act(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    for uid in (2, 3, 4):
        with pytest.raises(HeistError) as e:
            S.spy_pick(ses, op.id, uid, CHAT, 0)
        assert str(e.value) == S.msg(ses, "turn_spy")


def test_spy_backspace_removes_only_last(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    S.spy_pick(ses, op.id, 1, CHAT, 0); S.spy_pick(ses, op.id, 1, CHAT, 1); S.spy_pick(ses, op.id, 1, CHAT, 2)
    S.spy_backspace(ses, op.id, 1, CHAT)
    assert S._pd(ses.get(H.HeistOperation, op.id))["input"] == [0, 1]
    S.spy_backspace(ses, op.id, 1, CHAT); S.spy_backspace(ses, op.id, 1, CHAT); S.spy_backspace(ses, op.id, 1, CHAT)
    assert S._pd(ses.get(H.HeistOperation, op.id))["input"] == []


def test_spy_wrong_sequence_clears_and_regenerates(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    before = S._pd(ses.get(H.HeistOperation, op.id))
    wrong = [c for c in range(8)][::-1]
    for c in wrong[:len(before["seq"])]:
        S.spy_pick(ses, op.id, 1, CHAT, c)
    if wrong[:len(before["seq"])] == before["seq"]:
        pytest.skip("اتفاقاً درست بود")
    _, ok = S.spy_confirm(ses, op.id, 1, CHAT)
    after = S._pd(ses.get(H.HeistOperation, op.id))
    assert not ok and after["input"] == [] and after["attempt"] == 1
    assert ses.get(H.HeistOperation, op.id).status == E.SPY


def test_spy_length_uses_snapshot_skill(ses, clock):
    op, users, _ = team(ses, mkloc(ses), skills={"spy": 3})
    assert len(S._pd(ses.get(H.HeistOperation, op.id))["seq"]) == 5     # ۸ - ۳


def test_spy_success_goes_to_safe(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    _, ok = play_spy(ses, op)
    assert ok and ses.get(H.HeistOperation, op.id).status == E.SAFE


def test_cannot_act_in_wrong_phase(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    with pytest.raises(HeistError):
        S.safe_open(ses, op.id, 2, CHAT, 0)
    with pytest.raises(HeistError):
        S.driver_start(ses, op.id, 4, CHAT)


# ---------------------------------------------------------------- Safe ----
def test_safe_only_safecracker_and_empty_cell(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    play_spy(ses, op)
    for uid in (1, 3, 4):
        with pytest.raises(HeistError) as e:
            S.safe_open(ses, op.id, uid, CHAT, 0)
        assert str(e.value) == S.msg(ses, "turn_safe")
    cells = {i.cell for i in ses.query(H.HeistOpItem).filter_by(op_id=op.id)}
    empty = next(c for c in range(20) if c not in cells)
    _, it, _ = S.safe_open(ses, op.id, 2, CHAT, empty)
    assert it is None
    with pytest.raises(HeistError):
        S.safe_open(ses, op.id, 2, CHAT, empty)                  # باز کردنِ دوباره‌ی همون خونه


def test_item_found_goes_to_temp_loot_without_failure_roll(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    play_spy(ses, op)
    cell = ses.query(H.HeistOpItem).filter_by(op_id=op.id).first().cell
    _, it, _ = S.safe_open(ses, op.id, 2, CHAT, cell)
    assert it is not None and it.found is True and it.lost is None      # Roll هنوز انجام نشده


def test_kafi_zero_vs_with_items(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    play_spy(ses, op)
    with pytest.raises(HeistError) as e:
        S.safe_enough(ses, op.id, 2, CHAT)
    assert "هنوز چیزی پیدا نکردی" in str(e.value)
    cell = ses.query(H.HeistOpItem).filter_by(op_id=op.id).first().cell
    S.safe_open(ses, op.id, 2, CHAT, cell)
    S.safe_enough(ses, op.id, 2, CHAT)
    assert ses.get(H.HeistOperation, op.id).status == E.CARRIER


def test_kafi_disabled_by_admin(ses, clock):
    op, users, _ = team(ses, mkloc(ses, early_finish=0))
    play_spy(ses, op)
    cell = ses.query(H.HeistOpItem).filter_by(op_id=op.id).first().cell
    S.safe_open(ses, op.id, 2, CHAT, cell)
    with pytest.raises(HeistError):
        S.safe_enough(ses, op.id, 2, CHAT)


def test_all_items_found_auto_completes(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    play_spy(ses, op)
    play_safe_all(ses, op)
    assert ses.get(H.HeistOperation, op.id).status == E.CARRIER


def test_item_values_randomized_within_variance(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    vals = [i.value for i in ses.query(H.HeistOpItem).filter_by(op_id=op.id)]
    assert all(49_000_000 <= v <= 51_000_000 for v in vals)


# --------------------------------------------------------- Carrier/Driver ----
def test_carrier_only_carrier_and_per_item_timer(ses, clock):
    op, users, _ = team(ses, mkloc(ses), skills={"carrier": 3})
    play_spy(ses, op); play_safe_all(ses, op)
    with pytest.raises(HeistError) as e:
        S.carrier_start_item(ses, op.id, 1, CHAT)
    assert str(e.value) == S.msg(ses, "turn_carrier")
    S.carrier_start_item(ses, op.id, 3, CHAT)
    o = ses.get(H.HeistOperation, op.id)
    assert int((o.phase_ready_at - clock()).total_seconds()) == 12           # ۱۵ - ۳
    with pytest.raises(HeistError):
        S.carrier_start_item(ses, op.id, 3, CHAT)                           # آیتمِ قبلی هنوز تموم نشده
    clock.adv(seconds=13)
    S.refresh(ses, op.id, CHAT)
    assert S._pd(ses.get(H.HeistOperation, op.id))["idx"] == 1
    assert ses.query(H.HeistOpItem).filter_by(op_id=op.id, loaded=True).count() == 1


def test_driver_phase_requires_all_items_loaded(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    play_spy(ses, op); play_safe_all(ses, op)
    with pytest.raises(HeistError):
        S.driver_start(ses, op.id, 4, CHAT)
    play_carry(ses, op, clock)
    assert ses.get(H.HeistOperation, op.id).status == E.DRIVER


def test_no_kafi_in_carrier_or_driver(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    play_spy(ses, op); play_safe_all(ses, op)
    with pytest.raises(HeistError):
        S.safe_enough(ses, op.id, 2, CHAT)


def test_no_item_policy_blocked_default(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    play_spy(ses, op)
    with pytest.raises(HeistError):
        S.safe_enough(ses, op.id, 2, CHAT)


# --------------------------------------------------------------- Police ----
@pytest.mark.parametrize("phase", ["spy", "safe", "carrier", "driver"])
def test_police_fails_whole_team_in_every_phase(ses, clock, phase):
    loc = mkloc(ses)
    op, users, _ = team(ses, loc)
    if phase in ("safe", "carrier", "driver"):
        play_spy(ses, op)
    if phase in ("carrier", "driver"):
        play_safe_all(ses, op)
    if phase == "driver":
        play_carry(ses, op, clock)
    clock.t = T0 + datetime.timedelta(seconds=301)
    S.run_tick(clock())
    o = ses.get(H.HeistOperation, op.id)
    assert o.status == E.SETTLED and o.result == "failed" and o.fail_reason == "police"
    for u in users:
        ses.refresh(u)
        assert u.jailed_until and u.jail_bail_amount == 300_000_000 and u.jail_reason == "heist"
        assert S.get_player(ses, u.telegram_id).xp == 5000              # XP نمی‌گیره
    assert ses.query(db.User).filter(db.User.hop_points > 0).count() == 0


def test_afk_is_handled_by_police_timer(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    clock.adv(minutes=6)
    S.refresh(ses, op.id, CHAT)
    assert ses.get(H.HeistOperation, op.id).result == "failed"


def test_action_after_police_returns_ended(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    clock.adv(minutes=6)
    with pytest.raises(HeistEnded):
        S.spy_pick(ses, op.id, 1, CHAT, 0)
    assert ses.get(H.HeistOperation, op.id).result == "failed"


def test_police_wins_when_driving_finishes_after_deadline(ses, clock):
    op, users, _ = team(ses, mkloc(ses, police_seconds=60, driver_base_sec=165))
    ses.get(H.HeistOperation, op.id)
    # شبیه‌سازیِ رسیدن به مرحله‌ی راننده، سپس پایان رانندگی بعد از ددلاین
    o = ses.get(H.HeistOperation, op.id)
    o.status = E.DRIVER
    S._set_pd(o, {"driving": False})
    ses.commit()
    S.driver_start(ses, op.id, 4, CHAT)
    clock.adv(seconds=200)
    S.refresh(ses, op.id, CHAT)
    assert ses.get(H.HeistOperation, op.id).fail_reason == "police"


def test_prison_uses_existing_system_and_bail_amount(ses, clock):
    loc = mkloc(ses, jail_minutes=180, bail_amount=300_000_000)
    op, users, _ = team(ses, loc)
    clock.adv(minutes=6)
    S.refresh(ses, op.id, CHAT)
    u = ses.get(db.User, 1)
    assert int((u.jailed_until - clock()).total_seconds() // 60) in (179, 180)
    import handlers
    assert handlers._effective_bail(ses, u) == 300_000_000              # همون وثیقه‌ی هاپویی
    with pytest.raises(HeistError):
        S.create_lobby(ses, u, CHAT, loc.id)                             # زندانی نمی‌تونه سرقت کنه


def test_bail_not_allowed_minus_one(ses, clock):
    loc = mkloc(ses, bail_amount=-1)
    op, users, _ = team(ses, loc)
    clock.adv(minutes=6)
    S.refresh(ses, op.id, CHAT)
    import handlers
    assert handlers._effective_bail(ses, ses.get(db.User, 1)) < 0


# ------------------------------------------------------- Success / Reward ----
def test_success_pays_equal_split_xp_and_cooldown(ses, clock):
    loc = mkloc(ses, item_fail_pct=0, value_variance=0)
    op, users, _ = team(ses, loc)
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    o = ses.get(H.HeistOperation, op.id)
    assert o.result == "success" and o.total_loot == 250_000_000 and o.per_member == 62_500_000
    for u in users:
        ses.refresh(u)
        assert u.hop_points == 62_500_000
        p = S.get_player(ses, u.telegram_id)
        assert p.xp == 5250 and p.xp_total == 5250 and p.wins == 1
        assert S.active_cooldown(ses, u.telegram_id, loc.id, clock()) is not None
    led = ses.query(W.HopTransaction).filter(W.HopTransaction.reason == f"heist:{op.id}").all()
    assert len(led) == 4 and all(t.balance_after == 62_500_000 for t in led)   # لجر + Transaction


def test_item_failure_resolved_only_at_end_and_independent(ses, clock):
    loc = mkloc(ses, item_fail_pct=100, value_variance=0, safe_max_skill=0)
    op, users, _ = team(ses, loc)
    play_spy(ses, op); play_safe_all(ses, op)
    assert ses.query(H.HeistOpItem).filter_by(op_id=op.id, lost=True).count() == 0
    play_carry(ses, op, clock); play_drive(ses, op, clock)
    o = ses.get(H.HeistOperation, op.id)
    assert o.result == "success" and o.total_loot == 0                      # همه از دست رفتن
    assert ses.query(H.HeistOpItem).filter_by(op_id=op.id, lost=True).count() == 5


def test_safecracker_skill_reduces_failure_pct(ses, clock):
    loc = mkloc(ses, item_fail_pct=12)
    op, users, _ = team(ses, loc, skills={"safe": 5})
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    assert all(i.fail_pct_eff == 7 for i in ses.query(H.HeistOpItem).filter_by(op_id=op.id))


def test_half_policy(ses, clock):
    loc = mkloc(ses, item_fail_pct=100, value_variance=0, failed_item_policy="half", safe_max_skill=0)
    op, users, _ = team(ses, loc)
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    assert ses.get(H.HeistOperation, op.id).total_loot == 125_000_000


def test_failure_gives_no_xp_and_success_reward_once(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    before = {u.telegram_id: ses.refresh(u) or u.hop_points for u in users}
    # Double Callback / Replay / Job دوباره / Restart
    S.refresh(ses, op.id, CHAT)
    S.run_tick(clock())
    S._settle_success(ses, ses.get(H.HeistOperation, op.id), clock(), clock())
    ses.commit()
    for u in users:
        ses.refresh(u)
        assert u.hop_points == before[u.telegram_id]
    assert ses.query(H.HeistReward).filter_by(op_id=op.id).count() == 4
    assert ses.query(W.HopTransaction).filter(W.HopTransaction.reason == f"heist:{op.id}").count() == 4
    assert ses.query(H.HeistCooldown).filter_by(op_id=op.id).count() == 4


def test_resolution_id_unique_and_recorded(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    assert ses.get(H.HeistOperation, op.id).resolution_id == f"heist-{op.id}"


def test_history(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    clock.adv(minutes=6)
    S.refresh(ses, op.id, CHAT)
    h = S.history(ses, 1)
    assert len(h) == 1 and h[0]["result"] == "failed" and h[0]["reason"] == "police" and len(h[0]["team"]) == 4


# --------------------------------------------- Snapshot / Restart / Race ----
def test_config_snapshot_ignores_admin_changes_midway(ses, clock):
    loc = mkloc(ses, success_xp=250)
    op, users, _ = team(ses, loc)
    S.admin_set_location_field(ses, 1, loc.id, "success_xp", "9999")
    S.admin_set_location_field(ses, 1, loc.id, "police_seconds", "5")
    S.admin_set_location_field(ses, 1, loc.id, "item_fail_pct", "100")
    play_spy(ses, op); play_safe_all(ses, op); play_carry(ses, op, clock); play_drive(ses, op, clock)
    o = ses.get(H.HeistOperation, op.id)
    assert o.result == "success"
    assert S.get_player(ses, 1).xp == 5250                                  # ۲۵۰ (Snapshot) نه ۹۹۹۹
    # لابیِ جدید تنظیمِ جدید رو می‌گیره
    ses.query(H.HeistCooldown).delete(); ses.commit()
    op2, _, _ = team(ses, loc, ids=(21, 22, 23, 24))
    assert S._cfg(ses.get(H.HeistOperation, op2.id))["loc"]["success_xp"] == 9999


def test_restart_recovery_keeps_phase_timers_loot(ses, clock):
    op, users, _ = team(ses, mkloc(ses), skills={"carrier": 2})
    play_spy(ses, op)
    cell = ses.query(H.HeistOpItem).filter_by(op_id=op.id).first().cell
    S.safe_open(ses, op.id, 2, CHAT, cell)
    clock.adv(seconds=30)
    ses.close()                                                              # «ری‌استارت»: Sessionِ تازه
    s2 = db.get_session()
    try:
        o = s2.get(H.HeistOperation, op.id)
        assert o.status == E.SAFE and o.police_deadline == T0 + datetime.timedelta(seconds=300)
        assert s2.query(H.HeistOpItem).filter_by(op_id=op.id, found=True).count() == 1
        assert {m.role: m.skill for m in s2.query(H.HeistOpMember).filter_by(op_id=op.id)}["carrier"] == 2
        S.run_tick(clock())
        assert s2.get(H.HeistOperation, op.id).status == E.SAFE
    finally:
        s2.close()


def test_restart_after_downtime_settles_correctly(ses, clock):
    loc = mkloc(ses)
    op, users, _ = team(ses, loc)
    clock.adv(hours=5)                                                       # بات خاموش بود
    S.run_tick(clock())
    S.run_tick(clock())
    o = ses.get(H.HeistOperation, op.id)
    assert o.result == "failed" and o.fail_reason == "police"
    assert ses.query(H.HeistReward).filter_by(op_id=op.id).count() == 4


def test_downtime_during_drive_still_success_if_done_before_deadline(ses, clock):
    loc = mkloc(ses, police_seconds=600, item_fail_pct=0)
    op, users, _ = team(ses, loc)
    play_spy(ses, op); play_safe_all(ses, op)
    uid = uid_of(ses, op, "carrier")
    for _ in range(5):
        S.carrier_start_item(ses, op.id, uid, CHAT)
        clock.adv(seconds=16)
        S.refresh(ses, op.id, CHAT)
    S.driver_start(ses, op.id, 4, CHAT)                                      # ۱۶۵ ثانیه از ~۸۰ ثانیه گذشته
    clock.adv(hours=3)                                                       # بات خاموش؛ تایمر پایان رانندگی قبلِ ددلاین بود
    S.run_tick(clock())
    assert ses.get(H.HeistOperation, op.id).result == "success"


def test_two_operations_in_same_group_do_not_interfere(ses, clock):
    loc = mkloc(ses)
    op1, u1, _ = team(ses, loc, ids=(1, 2, 3, 4))
    op2, u2, _ = team(ses, loc, ids=(5, 6, 7, 8))
    assert op1.id != op2.id
    with pytest.raises(HeistError):
        S.spy_pick(ses, op1.id, 5, CHAT, 0)                                  # عضوِ op2 روی op1
    with pytest.raises(HeistError):
        S.spy_pick(ses, op2.id, 1, CHAT, 0)
    S.spy_pick(ses, op1.id, 1, CHAT, 0)
    assert S._pd(ses.get(H.HeistOperation, op2.id))["input"] == []


def test_wrong_chat_rejected(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    with pytest.raises(HeistError):
        S.spy_pick(ses, op.id, 1, CHAT - 1, 0)


# ---------------------------------------------------------- UI / Security ----
def tgu(uid):
    return types.SimpleNamespace(id=uid, username=f"u{uid}", first_name=f"U{uid}")


def open_panel(ses, uid=1, xp=5000):
    mkuser(ses, uid, xp=xp) if ses.get(db.User, uid) is None else None
    pn = S.panel_create(ses, CHAT, uid)
    S.panel_set_message(ses, pn.id, 555)
    return pn


def click(ses, pn, uid, action, *args, mid=555, chat=CHAT):
    data = ":".join(["ht", str(pn.id), action] + [str(a) for a in args])
    return UI.dispatch(ses, tgu(uid), chat, mid, data)


def test_ui_creator_lock_before_lobby(ses, clock):
    mkloc(ses)
    pn = open_panel(ses, 1)
    mkuser(ses, 2, xp=5000)
    toast, alert, view = click(ses, pn, 2, "go")
    assert toast == "این پنل برای شما نیست." and alert and view is None
    toast, alert, view = click(ses, pn, 1, "go")
    assert view is not None and "مکان‌های سرقت" in view[0]


def test_ui_wrong_message_or_chat_rejected(ses, clock):
    pn = open_panel(ses, 1)
    assert click(ses, pn, 1, "go", mid=1)[2] is None
    assert click(ses, pn, 1, "go", chat=-5)[2] is None


def test_ui_flow_lobby_then_others_can_join_creator_only_for_cancel(ses, clock):
    loc = mkloc(ses)
    pn = open_panel(ses, 1)
    for uid in (2, 3, 4):
        mkuser(ses, uid, xp=5000)
    _, _, view = click(ses, pn, 1, "loc", loc.id)
    assert "سرقت تیمی" in view[0]
    toast, _, _ = click(ses, pn, 2, "join")
    assert toast is None
    toast, alert, _ = click(ses, pn, 2, "cancel")
    assert "فقط سازنده" in toast
    toast, alert, _ = click(ses, pn, 9, "leave")
    assert "عضو این سرقت نیستید" in toast


def test_ui_locked_location_not_joinable_by_click(ses, clock):
    loc = mkloc(ses)
    pn = open_panel(ses, 1)
    mkuser(ses, 2, xp=5)
    click(ses, pn, 1, "loc", loc.id)
    toast, alert, _ = click(ses, pn, 2, "join")
    assert "باز نشده" in toast and alert


def test_ui_role_lock_message(ses, clock):
    loc = mkloc(ses)
    pn = open_panel(ses, 1)
    for uid in (2, 3, 4):
        mkuser(ses, uid, xp=5000)
    click(ses, pn, 1, "loc", loc.id)
    for uid in (2, 3, 4):
        click(ses, pn, uid, "join")
    toast, alert, _ = click(ses, pn, 3, "p", 0)
    assert toast == "الان نوبت جاسوس است." and alert


def test_ui_spy_view_has_hint_and_reverse_display(ses, clock):
    loc = mkloc(ses)
    pn = open_panel(ses, 1)
    for uid in (2, 3, 4):
        mkuser(ses, uid, xp=5000)
    click(ses, pn, 1, "loc", loc.id)
    for uid in (2, 3, 4):
        click(ses, pn, uid, "join")
    for c in (0, 1, 2):
        _, _, view = click(ses, pn, 1, "p", c)
    assert "💡 نکته: رنگ‌ها بعد از انتخاب برعکس نمایش داده می‌شوند" in view[0]
    assert "🟦 🟥 🟨" in view[0]
    assert any("پاک کردن آخرین رنگ" in b[0] for row in view[1] for b in row)


def test_ui_callback_validity(ses, clock):
    assert UI.dispatch(ses, tgu(1), CHAT, 1, "ht:abc:go")[1] is True
    assert UI.dispatch(ses, tgu(1), CHAT, 1, "ht:99999:go")[1] is True


def test_ui_skill_buttons(ses, clock):
    pn = open_panel(ses, 1, xp=100)
    _, _, view = click(ses, pn, 1, "s+", "safe")
    assert "صندوق‌دار: 1" in view[0]
    _, _, view = click(ses, pn, 1, "s-", "safe")
    assert "صندوق‌دار: 0" in view[0] and "امتیازِ آزاد (بعد از ➖): 1" in view[0]


def test_min_level_gate_whole_feature(ses, clock):
    loc = mkloc(ses)
    db.cfg_set(ses, "minlvl_heist", "5")
    ses.commit()
    u = mkuser(ses, 1, xp=5000)
    u.lvl = 1
    ses.commit()
    with pytest.raises(HeistError) as e:
        S.create_lobby(ses, u, CHAT, loc.id)
    assert "سطح" in str(e.value)
    pn = open_panel(ses, 1)
    toast, alert, view = click(ses, pn, 1, "go")
    assert alert and "سطح" in toast
    u.lvl = 5
    ses.commit()
    S.create_lobby(ses, u, CHAT, loc.id)


def test_feature_toggle_off(ses, clock):
    loc = mkloc(ses)
    S.admin_set_global_cfg(ses, 1, "heist_enabled", "0")
    with pytest.raises(HeistError):
        S.create_lobby(ses, mkuser(ses, 1, xp=5000), CHAT, loc.id)


def test_jailed_user_cannot_create_or_join(ses, clock):
    loc = mkloc(ses)
    u = mkuser(ses, 1, xp=5000)
    u.jailed_until = clock() + datetime.timedelta(hours=1)
    ses.commit()
    assert S.location_state(ses, u, loc)["state"] == "prison"
    with pytest.raises(HeistError):
        S.create_lobby(ses, u, CHAT, loc.id)


# ------------------------------------------------------------- Admin ----
def test_admin_global_config_and_messages(ses, clock):
    S.admin_set_global_cfg(ses, 1, "heist_color_pool", "🔴,🔵,🟢")
    assert S.color_pool(ses) == ["🔴", "🔵", "🟢"]
    with pytest.raises(HeistError):
        S.admin_set_global_cfg(ses, 1, "heist_color_pool", "🔴")
    S.admin_set_global_cfg(ses, 1, "heist_msg_turn_spy", "نوبتِ جاسوسه!")
    assert S.msg(ses, "turn_spy") == "نوبتِ جاسوسه!"
    with pytest.raises(HeistError):
        S.admin_set_global_cfg(ses, 1, "heist_msg_turn_spy", "{خراب")


def test_admin_defaults_for_new_locations(ses, clock):
    S.admin_set_global_cfg(ses, 1, H.DEF_PREFIX + "police_seconds", "120")
    loc = S.admin_create_location(ses, 1, "X")
    assert loc.police_seconds == 120


def test_admin_item_pool_and_soft_delete(ses, clock):
    loc = mkloc(ses)
    it = S.admin_add_item(ses, 1, loc.id, "Phone", 25_000_000)
    S.admin_set_item_field(ses, 1, it.id, "fail_pct", "30")
    S.admin_set_item_field(ses, 1, it.id, "weight", "3")
    assert [p["name"] for p in S.location_pool(ses, loc.id)] == ["Electronic Box", "Phone"]
    S.admin_toggle_item(ses, 1, it.id)
    assert [p["name"] for p in S.location_pool(ses, loc.id)] == ["Electronic Box"]
    S.admin_delete_location(ses, 1, loc.id)
    assert S.list_locations(ses, include_hidden=True) == []
    assert ses.get(H.HeistLocation, loc.id).deleted is True


def test_admin_cancel_op(ses, clock):
    op, users, _ = team(ses, mkloc(ses))
    S.admin_cancel_op(ses, op.id, 1)
    assert ses.get(H.HeistOperation, op.id).status == E.CANCELLED
    ses.query(db.User)                                       # کاربرها آزادن (بدونِ زندان)
    assert all(ses.get(db.User, u.telegram_id).jailed_until is None for u in users)


def test_all_admin_labels_are_persian_and_complete():
    for key, label, kind, default, group, hint in H.LOC_FIELDS:
        assert any("\u0600" <= ch <= "\u06ff" for ch in label), key
    for k, label, _v, _h in H.GLOBAL_CFG:
        assert any("\u0600" <= ch <= "\u06ff" for ch in label), k
    assert set(H.LOC_KEYS) == {c.name for c in H.HeistLocation.__table__.columns} & set(H.LOC_KEYS)


def test_war_labels_cover_every_config_key_and_column(ses):
    import war_labels as L
    for k in W.WAR_DEFAULT_CONFIG:
        if k != "war_room":
            assert k in L.CFG, k
    import war_admin as A
    for _key, (model, _pk, _title) in A.TABLES.items():
        for c in model.__table__.columns:
            assert c.name in L.COL, (model.__name__, c.name)
