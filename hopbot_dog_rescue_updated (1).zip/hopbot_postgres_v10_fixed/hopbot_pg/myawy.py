# -*- coding: utf-8 -*-
"""
گوشی هاپویی 📱 - شبیه‌سازِ شبکه‌های اجتماعی داخلِ ربات.

با تایپِ «گوشی هاپویی» در گروه فعال می‌شه (پنلِ شخصی و قفل‌شده به همون کاربر،
دقیقا مثلِ باقیِ منوهای هاپ‌منیج/بانک/ارز - نگاه کن به _verify_panel_owner).

اجزا:
- 📶 اپراتور: هر کاربر باید اینترنت بخره تا بتونه پست بذاره/ببینه. هر اپراتور
  قیمتِ هر گیگ و سرعتِ (Mbps) جدا داره؛ فقط مالک از پنل اپراتور می‌سازه/مدیریت
  می‌کنه و می‌تونه با خرجِ هاپ‌پوینتِ خودش سرعتشون رو بالا ببره.
- 📱 پلتفرم‌ها: مثلِ اینستا. هرکدوم نرخِ پاداشِ خودشو داره - نه لزوما «هر ۱۰
  لایک»، بلکه هر پلتفرم می‌تونه بگه «هر N لایک، X هاپ پوینت» (مثلا هر ۲ لایک
  ۵۰۰,۰۰۰ تا). اگه «بات‌فاندد» باشه، خودِ بات مستقیم پاداش رو واریز می‌کنه؛
  وگرنه به‌صورتِ «بدهیِ مالک» ثبت می‌شه و مالک باید دستی از پنل پرداختش کنه.
- ➕ درخواستِ پلتفرمِ جدید: هر پلیر می‌تونه (حداکثر ۲۵ بار در روز) از مالک
  بخواد یه پلتفرمِ جدید بسازه، با نرخِ پیشنهادیِ خودش (هر چند لایک، چقدر). اگه
  مالک قبول کنه، یه «فی» تعیین می‌کنه که کاربر باید ظرفِ ۳ روز (با استفاده از
  خودِ گوشی هاپویی) بپردازه، وگرنه درخواست خودکار لغو می‌شه.
- ✍️ پست: فقط متنی (فعلا). گذاشتنش گیگ مصرف می‌کنه و بر اساسِ سرعتِ اپراتورِ
  کاربر، بعد از چند دقیقه آماده/قابل‌دیدن می‌شه.
"""
import datetime
import json
import random

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationHandlerStop

import db
import economy
import keyboards as kb
from handlers import fmt, send_response, _verify_panel_owner, ask_for_input, ask_for_input_reply, is_reply_to_prompt

POSTS_PER_PAGE = 3

DRAWER_MAX_PHONES = 10  # سقفِ ثابتِ ظرفیتِ کشویِ گوشیِ هاپویی - هیچ سیستم ارتقا/افزایشی نداره


def _drawer_count(session, user_id):
    return session.query(db.UserPhone).filter_by(user_id=user_id, is_discarded=False).count()


# ---------------------------------------------------------------------------
# گوشی‌های هاپویی: کمکی‌های وضعیت (کشو/خرابی/انقضا/دسترسیِ پلتفرم)
# ---------------------------------------------------------------------------

def _equipped_phone(session, user_id):
    return (
        session.query(db.UserPhone)
        .filter_by(user_id=user_id, is_equipped=True, is_discarded=False)
        .first()
    )


def _phone_status(session, phone):
    """(is_expired, broken_parts) رو بدونِ تغییرِ دیتابیس برمی‌گردونه.
    broken_parts لیستی از (کلید, لیبل, قیمتِ تعمیر)ه."""
    if not phone:
        return True, []
    gen = session.get(db.PhoneGeneration, phone.generation_id)
    broken = []
    if phone.broken_lcd:
        broken.append(("lcd", "📺 ال‌سی‌دی", gen.repair_lcd_price if gen else 0))
    if phone.broken_battery:
        broken.append(("battery", "🔋 باتری", gen.repair_battery_price if gen else 0))
    if phone.broken_cpu:
        broken.append(("cpu", "💽 سی‌پی‌یو", gen.repair_cpu_price if gen else 0))
    expired = datetime.datetime.utcnow() >= phone.expires_at
    return expired, broken


def _require_working_phone(session, user):
    """برمی‌گردونه (phone, gen, error_text). اگه error_text خالی نبود، یعنی الان
    نمی‌شه از گوشی هاپویی/پلتفرم‌ها استفاده کرد و باید همین پیام نشون داده بشه."""
    phone = _equipped_phone(session, user.telegram_id)
    if not phone:
        return None, None, "📵 گوشی نداری! اول از «🏪 گوشی‌فروشی» یا «🏴 بازارِ سیاه» یه گوشی بخر."
    gen = session.get(db.PhoneGeneration, phone.generation_id)
    expired, broken = _phone_status(session, phone)
    if expired:
        return phone, gen, "⌛️ گوشیت منقضی شده! از «🗄 کشو» می‌تونی بفروشیش تو بازارِ سیاه یا دورش بندازی، بعد یه گوشیِ جدید بخر."
    if broken:
        parts = "، ".join(label for _, label, _ in broken)
        return phone, gen, f"🛠 گوشیت خرابه ({parts})! تا تعمیرش نکنی یا گوشیِ جدید نخری کار نمی‌کنه. از «🗄 کشو» تعمیرش کن."
    return phone, gen, None


def _generation_line(session, gen):
    if not gen:
        return None
    return session.get(db.PhoneLine, gen.line_id)


def _visible_platforms(session, gen, platforms):
    """گوشیِ فیک همیشه همه‌چیو می‌بینه (فلسفه‌ی فیک همینه). نسلِ «ممنوع‌شده»
    (خیلی قدیمی) فقط پلتفرم‌هایی رو می‌بینه که works_on_all_phones دارن."""
    line = _generation_line(session, gen)
    if line and line.is_fake:
        return platforms
    if not gen or not gen.banned_from_platforms:
        return platforms
    return [p for p in platforms if p.works_on_all_phones]


def _recompute_generation_bans(session, line_id):
    line = session.get(db.PhoneLine, line_id)
    if not line or line.is_fake:
        return
    window = db.cfg_get_int(session, "myawy_phone_ban_window")
    gens = (
        session.query(db.PhoneGeneration)
        .filter_by(line_id=line_id)
        .order_by(db.PhoneGeneration.gen_index.desc())
        .all()
    )
    if not gens:
        return
    latest_index = gens[0].gen_index
    for g in gens:
        if g.manual_ban:
            continue  # مدیر دستی ممنوعش کرده - قانونِ خودکار روش اثر نداره
        g.banned_from_platforms = (latest_index - g.gen_index) >= window


def expire_stale_markets(session):
    """گوشی‌هایی که از ساختشون به‌اندازه‌ی validity_days گذشته، خودکار از بازارِ
    خریدِ پلیرِ جدید «ناموجود» می‌شن (کسایی که قبلاً خریدن، گوشیشون دستِ خودشونه)."""
    nowt = datetime.datetime.utcnow()
    gens = session.query(db.PhoneGeneration).filter_by(is_market_available=True).all()
    for g in gens:
        if (nowt - g.created_at).days >= max(0, g.validity_days):
            g.is_market_available = False


def roll_daily_breakdowns(session):
    """برای هر گوشیِ خریداری‌شده (بعد از گذشتِ breakdown_grace_days از خرید)،
    یه‌بار در روز شانسِ خراب‌شدنِ هر قطعه‌ی سالم رو (مستقل از بقیه) چک می‌کنه."""
    nowt = datetime.datetime.utcnow()
    phones = session.query(db.UserPhone).filter_by(is_discarded=False).all()
    for ph in phones:
        if ph.broken_lcd and ph.broken_battery and ph.broken_cpu:
            continue
        gen = session.get(db.PhoneGeneration, ph.generation_id)
        if not gen:
            continue
        if nowt < ph.bought_at + datetime.timedelta(days=max(0, gen.breakdown_grace_days)):
            continue
        if ph.last_break_check_at and (nowt - ph.last_break_check_at).total_seconds() < 86400:
            continue
        ph.last_break_check_at = nowt
        chance = max(0.0, min(100.0, gen.daily_break_chance_pct)) / 100.0
        if not ph.broken_lcd and random.random() < chance:
            ph.broken_lcd = True
        if not ph.broken_battery and random.random() < chance:
            ph.broken_battery = True
        if not ph.broken_cpu and random.random() < chance:
            ph.broken_cpu = True


# ---------------------------------------------------------------------------
# کمکی‌ها
# ---------------------------------------------------------------------------

def _reset_daily_requests_if_needed(user):
    nowt = datetime.datetime.utcnow()
    last = user.myawy_requests_reset_at
    if not last or (nowt - last).total_seconds() >= 86400:
        user.myawy_requests_today = 0
        user.myawy_requests_reset_at = nowt


def _upload_seconds(session, operator):
    default_seconds = db.cfg_get_float(session, "myawy_default_upload_seconds")
    reduction_per_10 = db.cfg_get_float(session, "myawy_upload_seconds_reduction_per_10mbps")
    default_speed = db.cfg_get_float(session, "myawy_operator_default_speed_mbps")
    if not operator:
        return default_seconds
    # سرعتِ «فعال» ملاکه، نه سقفِ نهایی‌ای که ارتقا داده شده - مالک می‌تونه
    # بخشی از ظرفیتِ ارتقاداده‌شده رو خاموش نگه داره. کاملاً متناسب و دوطرفه:
    # هر مگابیت بالاتر از پیش‌فرض سریع‌تر می‌شه، هر مگابیت پایین‌تر کندتر
    # (قبلاً با max(0,...) این‌طرفش قفل شده بود و زیرِ ۱۰۰ اصلاً اثر نداشت)
    delta_mbps = operator.active_speed_mbps - default_speed
    delta_seconds = (delta_mbps / 10.0) * reduction_per_10
    return max(5.0, default_seconds - delta_seconds)


def _grant_like_rewards(session, post, platform):
    """هر بار که لایکِ جدید می‌خوره چک می‌کنه آیا به آستانه‌ی جدید (بر اساسِ
    likes_threshold همون پلتفرم) رسیده؛ اگه آره:
    - پلتفرمِ بات‌فاندد: فقط پستر خودکار پاداشِ پایه رو می‌گیره.
    - پلتفرمِ ساخته‌شده توسطِ یه پلیر (owner_user_id ست شده): هم پستر خودکار
      پاداشِ پایه رو می‌گیره، هم سازنده‌ی پلتفرم خودکار یه کمیسیون (پیش‌فرض
      ۲۸٪ رو پاداشِ پایه) می‌گیره - این‌طوری سازنده هم از پلتفرمِ خودش سود
      می‌بره، بدونِ اینکه پرداخت وابسته به دخالتِ مالک یا خودِ سازنده باشه.
    - پلتفرمِ خودِ مالک (نه بات‌فاندد، نه پلیرساخته): مثلِ قبل، بدهیِ مالک ثبت
      می‌شه و باید دستی از پنل پرداخت بشه.
    """
    threshold = max(1, platform.likes_threshold or 10)
    prev_chunks = post.paid_likes // threshold
    new_chunks = post.likes // threshold
    if new_chunks <= prev_chunks:
        return
    reward = (new_chunks - prev_chunks) * platform.reward_amount
    post.paid_likes = new_chunks * threshold
    if reward <= 0:
        return

    poster = session.get(db.User, post.user_id)

    if platform.is_bot_funded:
        if poster:
            poster.hop_points += reward * economy.money_income_multiplier(session, poster)
    elif platform.owner_user_id:
        if poster:
            poster.hop_points += reward * economy.money_income_multiplier(session, poster)
        creator = session.get(db.User, platform.owner_user_id)
        if creator:
            commission_pct = db.cfg_get_float(session, "myawy_creator_commission_pct") / 100.0
            creator.hop_points += reward * (1 + commission_pct) * economy.money_income_multiplier(session, creator)
    else:
        session.add(db.UserDebt(
            user_id=post.user_id,
            amount=reward,
            reason=f"لایکِ پست تو «{platform.name}»",
        ))


# ---------------------------------------------------------------------------
# ورودِ گروهی و خانه‌ی گوشی
# ---------------------------------------------------------------------------

async def handle_myawy_trigger(update, context):
    await show_myawy_home(update, context)


async def show_myawy_home(update, context):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        pending_fee = session.query(db.PlatformRequest).filter_by(
            user_id=user.telegram_id, status="awaiting_payment"
        ).first()
        session.commit()

        phone = _equipped_phone(session, user.telegram_id)
        lines = [
            "📱 گوشی هاپویی\n",
            f"📶 اینترنتِ باقی‌مونده: {fmt(user.internet_gb)} گیگ",
        ]
        if not phone:
            lines.append("📵 گوشیِ فعال نداری - از «🏪 گوشی‌فروشی» یا «🏴 بازارِ سیاه» یکی بخر.")
        else:
            gen = session.get(db.PhoneGeneration, phone.generation_id)
            line = _generation_line(session, gen)
            expired, broken = _phone_status(session, phone)
            name = f"{line.name if line else '?'} {gen.name if gen else '?'}"
            if expired:
                lines.append(f"⌛️ گوشیِ فعال: {name} - منقضی شده!")
            elif broken:
                parts = "، ".join(label for _, label, _ in broken)
                lines.append(f"🛠 گوشیِ فعال: {name} - خراب ({parts})")
            else:
                remain = _format_remaining(phone.expires_at - datetime.datetime.utcnow())
                lines.append(f"📱 گوشیِ فعال: {name} - سالم (اعتبار: {remain})")
        if pending_fee:
            lines.append("\n🧾 یه بدهیِ پلتفرمِ جدید داری - از دکمه‌ی پایین ببینش.")
        session.commit()
        await send_response(update, "\n".join(lines), kb.myawy_home_keyboard(user.telegram_id, bool(pending_fee)))
    finally:
        session.close()


async def cb_myawy_home(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_myawy_home(update, context)


def _format_remaining(delta: datetime.timedelta) -> str:
    total_seconds = max(0, int(delta.total_seconds()))
    days, rem = divmod(total_seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60
    parts = []
    if days:
        parts.append(f"{days} روز")
    if hours:
        parts.append(f"{hours} ساعت")
    if minutes or not parts:
        parts.append(f"{minutes} دقیقه")
    return " و ".join(parts)


async def cb_myawy_platform_debt(update, context):
    """اطلاعاتِ بدهیِ فیِ پلتفرمِ جدید: مقدارِ باقی‌مونده و زمانِ باقی‌مونده تا مهلت."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        req = session.query(db.PlatformRequest).filter_by(user_id=owner_id, status="awaiting_payment").first()
        if not req:
            await send_response(update, "❌ الان هیچ بدهیِ پلتفرمِ جدیدی نداری.", kb.myawy_home_keyboard(owner_id, False))
            return
        remain_amount = req.fee_amount - req.fee_paid_amount
        remain_time = req.fee_deadline - datetime.datetime.utcnow()
        jail_days = db.cfg_get_int(session, "myawy_fee_jail_days")
        time_txt = _format_remaining(remain_time) if remain_time.total_seconds() > 0 else "تمام شده!"
        text = (
            f"🧾 بدهیِ پلتفرمِ جدید: «{req.platform_name}»\n\n"
            f"💵 مقدارِ باقی‌مونده: {fmt(remain_amount)} 🪙\n"
            f"⏳ زمانِ باقی‌مونده: {time_txt}\n\n"
            f"⚠️ اگه سرِ وقت پرداخت نکنی، درخواست کنسل می‌شه و {jail_days} روز می‌ری زندانِ هاپویی."
        )
        await send_response(update, text, kb.myawy_platform_debt_keyboard(owner_id))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# اپراتور / خریدِ اینترنت
# ---------------------------------------------------------------------------

async def cb_myawy_operators(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        operators = session.query(db.Operator).filter_by(is_active=True).all()
        if not operators:
            await send_response(update, "📶 فعلا هیچ اپراتوری توسط مالک تعریف نشده.", kb.myawy_home_keyboard(owner_id, False))
            return
        await send_response(update, "📶 یکی از اپراتورها رو برای خریدِ اینترنت انتخاب کن:", kb.myawy_operators_keyboard(operators, owner_id))
    finally:
        session.close()


async def cb_myawy_buy_gb_ask(update, context):
    _, operator_id, owner_id = update.callback_query.data.split(":")
    operator_id, owner_id = int(operator_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(update, context, "📶 چند گیگ می‌خوای بخری؟ عدد رو بفرست.", {"type": "buy_gb", "operator_id": operator_id}, "myawy_awaiting")


# ---------------------------------------------------------------------------
# پلتفرم‌ها / فید / پست جدید / لایک
# ---------------------------------------------------------------------------

async def cb_myawy_platforms(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        phone, gen, error = _require_working_phone(session, user)
        if error:
            session.commit()
            await send_response(update, error, kb.myawy_home_keyboard(owner_id, False))
            return
        platforms = session.query(db.Platform).filter_by(is_active=True).all()
        platforms = _visible_platforms(session, gen, platforms)
        session.commit()
        if not platforms:
            await send_response(update, "📱 گوشیت هیچ پلتفرمی رو لود نمی‌کنه (نسلش خیلی قدیمیه).", kb.myawy_home_keyboard(owner_id, False))
            return
        await send_response(update, "📱 یکی از پلتفرم‌ها رو انتخاب کن:", kb.myawy_platforms_keyboard(platforms, owner_id))
    finally:
        session.close()


async def cb_myawy_platform_view(update, context):
    _, platform_id, owner_id = update.callback_query.data.split(":")
    platform_id, owner_id = int(platform_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        phone, gen, error = _require_working_phone(session, user)
        if error:
            session.commit()
            await send_response(update, error, kb.myawy_home_keyboard(owner_id, False))
            return
        p = session.get(db.Platform, platform_id)
        if not p or not p.is_active or p not in _visible_platforms(session, gen, [p] if p else []):
            session.commit()
            await send_response(update, "این پلتفرم دیگه وجود نداره یا رو گوشیت لود نمی‌شه.", kb.myawy_home_keyboard(owner_id, False))
            return
        text = f"{p.name}\n\n🎁 پاداش: {fmt(p.reward_amount)} 🪙 به‌ازای هر {p.likes_threshold} لایک"
        session.commit()
        await send_response(update, text, kb.myawy_platform_view_keyboard(p.id, owner_id))
    finally:
        session.close()


async def cb_myawy_new_post_ask(update, context):
    _, platform_id, owner_id = update.callback_query.data.split(":")
    platform_id, owner_id = int(platform_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        phone, gen, error = _require_working_phone(session, user)
        if error:
            session.commit()
            await send_response(update, error, kb.myawy_platform_view_keyboard(platform_id, owner_id))
            return
        cost = db.cfg_get_float(session, "myawy_gb_per_post_cost")
        if user.internet_gb < cost:
            await send_response(
                update,
                f"❌ اینترنتِ کافی نداری! برای یه پست {fmt(cost)} گیگ لازمه، فقط {fmt(user.internet_gb)} گیگ داری.",
                kb.myawy_platform_view_keyboard(platform_id, owner_id),
            )
            return
    finally:
        session.close()
    await ask_for_input(update, context, "✍️ متنِ پستت رو بفرست:", {"type": "new_post", "platform_id": platform_id}, "myawy_awaiting")


async def cb_myawy_feed(update, context):
    _, platform_id, owner_id, offset = update.callback_query.data.split(":")
    platform_id, owner_id, offset = int(platform_id), int(owner_id), int(offset)
    if not await _verify_panel_owner(update, owner_id):
        return
    await _render_feed(update, context, platform_id, owner_id, offset)


async def _render_feed(update, context, platform_id: int, owner_id: int, offset: int):
    session = db.get_session()
    try:
        p = session.get(db.Platform, platform_id)
        if not p:
            await send_response(update, "این پلتفرم دیگه وجود نداره.", kb.myawy_home_keyboard(owner_id, False))
            return
        user = db.get_or_create_user(session, update.effective_user)
        cost_per_view = db.cfg_get_float(session, "myawy_gb_per_view_cost")

        nowt = datetime.datetime.utcnow()
        all_ready = (
            session.query(db.MyawyPost)
            .filter(db.MyawyPost.platform_id == platform_id, db.MyawyPost.ready_at <= nowt)
            .order_by(db.MyawyPost.created_at.desc())
            .all()
        )
        page = all_ready[offset:offset + POSTS_PER_PAGE]
        if not page:
            text = "📰 پستی برای دیدن نیست." if offset == 0 else "📰 پستِ بیشتری نیست."
            await send_response(update, text, kb.myawy_platform_view_keyboard(platform_id, owner_id))
            return

        # موجودیِ گیگ رو چک کن - فقط به تعدادی که واقعا می‌تونه ببینه نشون بده
        max_affordable = int(user.internet_gb / cost_per_view) if cost_per_view > 0 else len(page)
        shown = page[:max(0, max_affordable)]
        if not shown:
            await send_response(
                update,
                f"❌ اینترنتِ کافی نداری! برای دیدنِ هر پست {fmt(cost_per_view)} گیگ لازمه.",
                kb.myawy_platform_view_keyboard(platform_id, owner_id),
            )
            return

        user.internet_gb -= cost_per_view * len(shown)
        session.commit()

        already_liked = {
            row.post_id for row in session.query(db.MyawyPostLike).filter_by(user_id=user.telegram_id).all()
        }

        lines = [f"📰 {p.name} - پست‌ها:\n"]
        likeable = []
        for i, post in enumerate(shown, start=1):
            author = session.get(db.User, post.user_id)
            author_name = author.display_name() if author else str(post.user_id)
            label = f"پست {i}"
            lines.append(f"{i}. 👤 {author_name}:\n{post.content}\n❤️ {post.likes} لایک\n")
            if post.user_id != user.telegram_id and post.id not in already_liked:
                likeable.append((post, label))

        has_more = len(all_ready) > offset + len(shown)
        await send_response(update, "\n".join(lines), kb.myawy_feed_keyboard(likeable, platform_id, owner_id, offset, has_more))
    finally:
        session.close()


async def cb_myawy_like(update, context):
    _, post_id, platform_id, owner_id, offset = update.callback_query.data.split(":")
    post_id, platform_id, owner_id, offset = int(post_id), int(platform_id), int(owner_id), int(offset)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        post = session.get(db.MyawyPost, post_id)
        platform = session.get(db.Platform, platform_id)
        if not post or not platform:
            await update.callback_query.answer("این پست دیگه وجود نداره.", show_alert=True)
            return
        if post.user_id == owner_id:
            await update.callback_query.answer("نمی‌تونی پستِ خودتو لایک کنی.", show_alert=True)
            return
        exists = session.query(db.MyawyPostLike).filter_by(post_id=post_id, user_id=owner_id).first()
        if exists:
            await update.callback_query.answer("قبلا لایک کردی ✅", show_alert=True)
            return
        session.add(db.MyawyPostLike(post_id=post_id, user_id=owner_id))
        post.likes += 1
        _grant_like_rewards(session, post, platform)
        session.commit()
        await update.callback_query.answer("❤️ لایک شد!")
    finally:
        session.close()
    # فید رو دوباره با همون آفست نشون بده تا لیستِ لایک‌ها به‌روز شه
    await _render_feed(update, context, platform_id, owner_id, offset)


# ---------------------------------------------------------------------------
# 📄 پست‌های من (دیدن/حذفِ پست‌های خودم تو یه پلتفرم)
# ---------------------------------------------------------------------------

async def _render_myposts(update, context, platform_id: int, owner_id: int):
    session = db.get_session()
    try:
        p = session.get(db.Platform, platform_id)
        if not p:
            await send_response(update, "این پلتفرم دیگه وجود نداره.", kb.myawy_home_keyboard(owner_id, False))
            return
        posts = (
            session.query(db.MyawyPost)
            .filter_by(platform_id=platform_id, user_id=owner_id)
            .order_by(db.MyawyPost.created_at.asc())
            .all()
        )
        session.commit()
        if not posts:
            await send_response(update, f"📄 پست‌های من تو «{p.name}»:\n\nپستی نداری.", kb.myawy_myposts_keyboard([], platform_id, owner_id))
            return
        nowt = datetime.datetime.utcnow()
        lines = [f"📄 پست‌های من تو «{p.name}»:\n"]
        items = []
        for i, post in enumerate(posts, start=1):
            uploading = post.ready_at > nowt
            status = " (⏳ در حالِ آپلود)" if uploading else ""
            lines.append(f"{i}. {post.content}\n❤️ {post.likes} لایک{status}\n")
            items.append((post.id, i))
        await send_response(update, "\n".join(lines), kb.myawy_myposts_keyboard(items, platform_id, owner_id))
    finally:
        session.close()


async def cb_myawy_myposts(update, context):
    _, platform_id, owner_id = update.callback_query.data.split(":")
    platform_id, owner_id = int(platform_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    await _render_myposts(update, context, platform_id, owner_id)


async def cb_myawy_mypost_delete(update, context):
    _, post_id, platform_id, owner_id = update.callback_query.data.split(":")
    post_id, platform_id, owner_id = int(post_id), int(platform_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        post = session.get(db.MyawyPost, post_id)
        if post and post.user_id == owner_id and post.platform_id == platform_id:
            session.query(db.MyawyPostLike).filter_by(post_id=post.id).delete(synchronize_session=False)
            session.delete(post)
            session.commit()
        else:
            session.commit()
            await update.callback_query.answer("این پست دیگه وجود نداره.", show_alert=True)
    finally:
        session.close()
    await _render_myposts(update, context, platform_id, owner_id)


async def cb_myawy_myposts_deleteall_ask(update, context):
    _, platform_id, owner_id = update.callback_query.data.split(":")
    platform_id, owner_id = int(platform_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        count = session.query(db.MyawyPost).filter_by(platform_id=platform_id, user_id=owner_id).count()
        session.commit()
    finally:
        session.close()
    if count == 0:
        await update.callback_query.answer("پستی نداری که حذف کنی.", show_alert=True)
        return
    await send_response(
        update, f"🗑 مطمئنی می‌خوای هر {count} پستِ خودت تو این پلتفرم رو کلا حذف کنی؟ برگشت‌ناپذیره.",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله، همه رو حذف کن", callback_data=f"myawy_myposts_deleteall_confirm:{platform_id}:{owner_id}"),
            InlineKeyboardButton("❌ انصراف", callback_data=f"myawy_myposts:{platform_id}:{owner_id}"),
        ]]),
    )


async def cb_myawy_myposts_deleteall_confirm(update, context):
    _, platform_id, owner_id = update.callback_query.data.split(":")
    platform_id, owner_id = int(platform_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        post_ids = [row[0] for row in session.query(db.MyawyPost.id).filter_by(platform_id=platform_id, user_id=owner_id).all()]
        if post_ids:
            session.query(db.MyawyPostLike).filter(db.MyawyPostLike.post_id.in_(post_ids)).delete(synchronize_session=False)
            session.query(db.MyawyPost).filter(db.MyawyPost.id.in_(post_ids)).delete(synchronize_session=False)
            session.commit()
    finally:
        session.close()
    await _render_myposts(update, context, platform_id, owner_id)


# ---------------------------------------------------------------------------
# درخواستِ پلتفرمِ جدید و پرداختِ فی
# ---------------------------------------------------------------------------

async def cb_myawy_request_platform(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        _reset_daily_requests_if_needed(user)
        max_per_day = db.cfg_get_int(session, "myawy_max_requests_per_day")
        if user.myawy_requests_today >= max_per_day:
            session.commit()
            await send_response(
                update,
                f"❌ امروز به سقفِ {max_per_day} درخواست رسیدی؛ فردا دوباره امتحان کن.",
                kb.myawy_home_keyboard(owner_id, False),
            )
            return
        session.commit()
    finally:
        session.close()
    await ask_for_input(update, context, "📝 اسمِ پلتفرمِ پیشنهادیت رو بفرست:", {"type": "request_platform_name"}, "myawy_awaiting")


async def cb_myawy_my_debts(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        debts = session.query(db.UserDebt).filter_by(user_id=owner_id, is_paid=False).all()
        if not debts:
            text = "💰 در حالِ حاضر هیچ بدهیِ پرداخت‌نشده‌ای از طرفِ مالک نداری."
        else:
            total = sum(d.amount for d in debts)
            lines = [f"💰 بدهی‌های پرداخت‌نشده (مجموع: {fmt(total)} 🪙):\n"]
            for d in debts:
                lines.append(f"• {fmt(d.amount)} 🪙 - {d.reason or ''}")
            text = "\n".join(lines)
        await send_response(update, text, kb.myawy_home_keyboard(owner_id, False))
    finally:
        session.close()


async def cb_myawy_pay_fee(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        req = session.query(db.PlatformRequest).filter_by(user_id=owner_id, status="awaiting_payment").first()
        if not req:
            await send_response(update, "❌ الان هیچ فیِ پلتفرمِ در انتظارِ پرداختی نداری.", kb.myawy_home_keyboard(owner_id, False))
            return
        remain = req.fee_amount - req.fee_paid_amount
    finally:
        session.close()
    await ask_for_input(update, context, f"🧾 چقدر می‌خوای بابتِ فی پرداخت کنی؟ (مونده: {fmt(remain)} 🪙)", {"type": "pay_fee"}, "myawy_awaiting")


# ---------------------------------------------------------------------------
# پردازشِ ورودی‌های متنی
# ---------------------------------------------------------------------------

async def myawy_awaiting_handler(update, context):
    awaiting = context.user_data.get("myawy_awaiting")
    if not awaiting:
        return
    if not is_reply_to_prompt(update, awaiting):
        return  # این پیام ریپلای به پرامپتِ ما نیست - نادیده بگیر
    text = (update.message.text or "").strip()
    kind = awaiting["type"]
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)

        if kind == "buy_gb":
            try:
                gb = float(text)
            except ValueError:
                context.user_data.pop("myawy_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if gb <= 0:
                context.user_data.pop("myawy_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            operator = session.get(db.Operator, awaiting["operator_id"])
            if not operator:
                await update.message.reply_text("❌ این اپراتور دیگه وجود نداره.")
                context.user_data.pop("myawy_awaiting", None)
                raise ApplicationHandlerStop
            cost = gb * operator.price_per_gb
            if user.hop_points < cost - 0.5:
                await update.message.reply_text(f"❌ موجودی کافی نیست! {fmt(cost)} 🪙 لازمه.")
                raise ApplicationHandlerStop
            user.hop_points -= cost
            user.internet_gb += gb
            user.operator_id = operator.id
            total_rev = db.cfg_get_float(session, "myawy_total_internet_revenue") + cost
            db.cfg_set(session, "myawy_total_internet_revenue", total_rev)
            # این بخشِ «در صفِ برداشت»ه - تا مالک از پنل «برداشت درآمد اپراتور» رو
            # نزنه، خودش صفر نمی‌شه (فرقش با شمارنده‌ی بالا که هیچ‌وقت صفر نمی‌شه)
            pending_rev = db.cfg_get_float(session, "myawy_pending_internet_revenue") + cost
            db.cfg_set(session, "myawy_pending_internet_revenue", pending_rev)
            session.commit()
            context.user_data.pop("myawy_awaiting", None)
            await update.message.reply_text(
                f"✅ {fmt(gb)} گیگ از {operator.name} خریده شد! اینترنتِ فعلی: {fmt(user.internet_gb)} گیگ",
                reply_markup=kb.myawy_home_keyboard(user.telegram_id, False),
            )
            raise ApplicationHandlerStop

        if kind == "new_post":
            if not text:
                await update.message.reply_text("متنِ پست نمی‌تونه خالی باشه.")
                raise ApplicationHandlerStop
            platform_id = awaiting["platform_id"]
            platform = session.get(db.Platform, platform_id)
            if not platform or not platform.is_active:
                await update.message.reply_text("❌ این پلتفرم دیگه وجود نداره.")
                context.user_data.pop("myawy_awaiting", None)
                raise ApplicationHandlerStop
            _phone, _gen, _error = _require_working_phone(session, user)
            if _error:
                await update.message.reply_text(_error)
                context.user_data.pop("myawy_awaiting", None)
                raise ApplicationHandlerStop
            cost = db.cfg_get_float(session, "myawy_gb_per_post_cost")
            if user.internet_gb < cost:
                await update.message.reply_text(f"❌ اینترنتِ کافی نداری! {fmt(cost)} گیگ لازمه.")
                context.user_data.pop("myawy_awaiting", None)
                raise ApplicationHandlerStop
            operator = session.get(db.Operator, user.operator_id) if user.operator_id else None
            upload_seconds = _upload_seconds(session, operator)
            user.internet_gb -= cost
            nowt = datetime.datetime.utcnow()
            post = db.MyawyPost(
                platform_id=platform_id, user_id=user.telegram_id, content=text[:1000],
                likes=0, paid_likes=0, ready_at=nowt + datetime.timedelta(seconds=upload_seconds), created_at=nowt,
            )
            session.add(post)
            session.commit()
            context.user_data.pop("myawy_awaiting", None)
            mins = int(upload_seconds // 60)
            secs = int(upload_seconds % 60)
            await update.message.reply_text(
                f"✅ پستت تو «{platform.name}» ثبت شد! تا حدودِ {mins} دقیقه و {secs} ثانیه‌ی دیگه برای بقیه قابل‌دیدن می‌شه.",
                reply_markup=kb.myawy_home_keyboard(user.telegram_id, False),
            )
            raise ApplicationHandlerStop

        if kind == "request_platform_name":
            name = text[:40]
            if not name:
                await update.message.reply_text("اسم نمی‌تونه خالی باشه.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(update, context, "🔢 به‌ازای هر چند تا لایک بخوای پاداش بگیری؟ یه عدد صحیح بفرست (مثلا 2):", {"type": "request_platform_likes", "name": name}, "myawy_awaiting")
            raise ApplicationHandlerStop

        if kind == "request_platform_likes":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("myawy_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, f"💰 به‌ازای هر {text} لایک، چقدر هاپ پوینت پیشنهاد می‌کنی؟ یه عدد بفرست:",
                {"type": "request_platform_reward", "name": awaiting["name"], "likes_threshold": int(text)},
                "myawy_awaiting",
            )
            raise ApplicationHandlerStop

        if kind == "request_platform_reward":
            try:
                reward = float(text)
            except ValueError:
                context.user_data.pop("myawy_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if reward <= 0:
                context.user_data.pop("myawy_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            _reset_daily_requests_if_needed(user)
            user.myawy_requests_today += 1
            likes_threshold = awaiting["likes_threshold"]
            session.add(db.PlatformRequest(
                user_id=user.telegram_id, platform_name=awaiting["name"],
                requested_reward_amount=reward, requested_likes_threshold=likes_threshold, status="pending",
            ))
            session.commit()
            context.user_data.pop("myawy_awaiting", None)
            await update.message.reply_text(
                f"✅ درخواستت برای پلتفرمِ «{awaiting['name']}» با پاداشِ پیشنهادیِ {fmt(reward)} 🪙 "
                f"به‌ازای هر {likes_threshold} لایک برای مالک فرستاده شد. منتظرِ تاییدش باش!",
                reply_markup=kb.myawy_home_keyboard(user.telegram_id, False),
            )
            raise ApplicationHandlerStop

        if kind == "pay_fee":
            try:
                amount = float(text)
            except ValueError:
                context.user_data.pop("myawy_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if amount <= 0:
                context.user_data.pop("myawy_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            req = session.query(db.PlatformRequest).filter_by(
                user_id=user.telegram_id, status="awaiting_payment"
            ).first()
            if not req:
                await update.message.reply_text("❌ الان هیچ فیِ در انتظارِ پرداختی نداری.")
                context.user_data.pop("myawy_awaiting", None)
                raise ApplicationHandlerStop
            remain = req.fee_amount - req.fee_paid_amount
            pay = min(amount, remain)
            if user.hop_points < pay:
                await update.message.reply_text(f"❌ موجودی کافی نیست! فقط {fmt(user.hop_points)} 🪙 داری.")
                raise ApplicationHandlerStop
            user.hop_points -= pay
            req.fee_paid_amount += pay
            context.user_data.pop("myawy_awaiting", None)

            if req.fee_paid_amount >= req.fee_amount:
                req.status = "approved"
                platform = db.Platform(
                    name=req.platform_name, reward_amount=req.requested_reward_amount,
                    likes_threshold=req.requested_likes_threshold,
                    is_bot_funded=False, owner_user_id=user.telegram_id, is_active=True,
                )
                session.add(platform)
                session.commit()
                await update.message.reply_text(
                    f"🎉 فی کامل پرداخت شد! پلتفرمِ «{req.platform_name}» الان فعاله.",
                    reply_markup=kb.myawy_home_keyboard(user.telegram_id, False),
                )
            else:
                session.commit()
                await update.message.reply_text(
                    f"✅ {fmt(pay)} 🪙 پرداخت شد. مونده: {fmt(req.fee_amount - req.fee_paid_amount)} 🪙 "
                    f"(تا {req.fee_deadline.strftime('%Y-%m-%d %H:%M')})",
                    reply_markup=kb.myawy_home_keyboard(user.telegram_id, bool(req)),
                )
            raise ApplicationHandlerStop

        if kind == "phone_sell_price":
            try:
                price = float(text)
            except ValueError:
                context.user_data.pop("myawy_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            phone_id = awaiting["phone_id"]
            ph = session.get(db.UserPhone, phone_id)
            context.user_data.pop("myawy_awaiting", None)
            if not ph or ph.user_id != user.telegram_id or ph.is_discarded:
                await update.message.reply_text("❌ این گوشی دیگه وجود نداره.")
                raise ApplicationHandlerStop
            if price < 1 or price >= ph.original_price:
                await update.message.reply_text(
                    f"❌ قیمت باید بینِ ۱ و کمتر از {fmt(ph.original_price)} 🪙 باشه؛ دوباره از دکمه‌ی مربوطه شروع کن."
                )
                raise ApplicationHandlerStop
            already = session.query(db.BlackMarketListing).filter_by(phone_id=ph.id, is_sold=False).first()
            if already:
                await update.message.reply_text("❌ این گوشی از قبل تو بازارِ سیاهه.")
                raise ApplicationHandlerStop
            session.add(db.BlackMarketListing(phone_id=ph.id, seller_id=user.telegram_id, price=price))
            session.commit()
            await update.message.reply_text(
                f"✅ گوشی با قیمتِ {fmt(price)} 🪙 گذاشته شد تو بازارِ سیاه.",
                reply_markup=kb.myawy_home_keyboard(user.telegram_id, False),
            )
            raise ApplicationHandlerStop
    finally:
        session.close()


# ---------------------------------------------------------------------------
# 🏪 گوشی‌فروشی (خریدِ رسمی از بازار)
# ---------------------------------------------------------------------------

async def cb_myawy_shop(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        expire_stale_markets(session)
        gens = (
            session.query(db.PhoneGeneration)
            .filter_by(is_active=True, is_market_available=True)
            .order_by(db.PhoneGeneration.line_id, db.PhoneGeneration.gen_index)
            .all()
        )
        items = []
        for g in gens:
            line = session.get(db.PhoneLine, g.line_id)
            tag = "🃏 " if line and line.is_fake else ""
            items.append((g.id, f"{tag}{line.name if line else '?'} {g.name} | {fmt(g.price)}🪙"))
        session.commit()
        text = "🏪 گوشی‌فروشیِ هاپویی - یکی رو انتخاب کن:" if items else "🏪 فعلاً هیچ گوشی‌ای تو بازار موجود نیست."
        await send_response(update, text, kb.myawy_shop_keyboard(items, owner_id))
    finally:
        session.close()


async def cb_myawy_shop_view(update, context):
    _, gen_id, owner_id = update.callback_query.data.split(":")
    gen_id, owner_id = int(gen_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        g = session.get(db.PhoneGeneration, gen_id)
        if not g or not g.is_active or not g.is_market_available:
            await send_response(update, "❌ این گوشی دیگه تو بازار موجود نیست.", kb.myawy_home_keyboard(owner_id, False))
            return
        line = _generation_line(session, g)
        text = (
            f"{'🃏 فیک - ' if line and line.is_fake else ''}{line.name if line else '?'} {g.name}\n\n"
            f"💵 قیمت: {fmt(g.price)} 🪙\n"
            f"📆 اعتبار: {g.validity_days} روز\n"
            f"⏳ شروعِ احتمالِ خرابی: {g.breakdown_grace_days} روز بعد از خرید\n"
            f"🎲 احتمالِ خرابیِ روزانه‌ی هر قطعه: {fmt(g.daily_break_chance_pct)}٪\n"
            f"🛠 هزینه‌ی تعمیر: 📺{fmt(g.repair_lcd_price)} | 🔋{fmt(g.repair_battery_price)} | 💽{fmt(g.repair_cpu_price)}"
        )
        session.commit()
        await send_response(update, text, kb.myawy_shop_view_keyboard(g.id, owner_id))
    finally:
        session.close()


async def cb_myawy_shop_buy(update, context):
    _, gen_id, owner_id = update.callback_query.data.split(":")
    gen_id, owner_id = int(gen_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        g = session.get(db.PhoneGeneration, gen_id)
        if not g or not g.is_active or not g.is_market_available:
            session.commit()
            await send_response(update, "❌ این گوشی دیگه تو بازار موجود نیست.", kb.myawy_home_keyboard(owner_id, False))
            return
        if user.hop_points < g.price:
            session.commit()
            await send_response(update, f"❌ موجودی کافی نیست! {fmt(g.price)} 🪙 لازمه.", kb.myawy_shop_view_keyboard(g.id, owner_id))
            return
        if _drawer_count(session, owner_id) >= DRAWER_MAX_PHONES:
            session.commit()
            await send_response(
                update,
                f"❌ کشوی گوشیِ هاپویی‌ت پره (حداکثر {DRAWER_MAX_PHONES} تا)! اول یکی از گوشی‌های تو «🗄 کشو» رو بفروش یا دورش بنداز.",
                kb.myawy_shop_view_keyboard(g.id, owner_id),
            )
            return
        user.hop_points -= g.price
        nowt = datetime.datetime.utcnow()
        will_equip = not bool(_equipped_phone(session, user.telegram_id))
        phone = db.UserPhone(
            user_id=user.telegram_id, generation_id=g.id, bought_at=nowt,
            expires_at=nowt + datetime.timedelta(days=g.validity_days),
            is_equipped=will_equip, original_price=g.price,
        )
        session.add(phone)
        session.commit()
        extra = " همین الان هم فعالش کردیم." if will_equip else " برای استفاده ازش، از «🗄 کشو» فعالش کن."
        await send_response(update, "✅ گوشی خریده شد و رفت تو کشوت!" + extra, kb.myawy_home_keyboard(owner_id, False))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# 🗄 کشو (مالکیت/فعال‌سازی/تعمیرات/دورانداختن)
# ---------------------------------------------------------------------------

async def _render_drawer(update, context, owner_id: int):
    session = db.get_session()
    try:
        phones = (
            session.query(db.UserPhone)
            .filter_by(user_id=owner_id, is_discarded=False)
            .order_by(db.UserPhone.bought_at.desc())
            .all()
        )
        items = []
        for ph in phones:
            g = session.get(db.PhoneGeneration, ph.generation_id)
            line = _generation_line(session, g)
            expired, broken = _phone_status(session, ph)
            tag = "🔌" if ph.is_equipped else "▫️"
            if expired:
                tag += "⌛️"
            elif broken:
                tag += "🛠"
            items.append((ph.id, f"{tag} {line.name if line else '?'} {g.name if g else '?'}"))
        session.commit()
        text = "🗄 کشوی گوشی‌های من:" if items else "🗄 کشوت خالیه - هنوز هیچ گوشی‌ای نخریدی."
        await send_response(update, text, kb.myawy_drawer_keyboard(items, owner_id))
    finally:
        session.close()


async def cb_myawy_drawer(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await _render_drawer(update, context, owner_id)


async def cb_myawy_phone_view(update, context):
    _, phone_id, owner_id = update.callback_query.data.split(":")[:3]
    phone_id, owner_id = int(phone_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        ph = session.get(db.UserPhone, phone_id)
        if not ph or ph.user_id != owner_id or ph.is_discarded:
            await send_response(update, "این گوشی دیگه تو کشوت نیست.", kb.myawy_home_keyboard(owner_id, False))
            return
        g = session.get(db.PhoneGeneration, ph.generation_id)
        line = _generation_line(session, g)
        expired, broken = _phone_status(session, ph)
        nowt = datetime.datetime.utcnow()
        remain = "منقضی شده ⌛️" if expired else _format_remaining(ph.expires_at - nowt)
        lines = [
            f"{line.name if line else '?'} {g.name if g else '?'}" + (" 🃏" if line and line.is_fake else ""),
            f"🔌 وضعیت: {'فعال (equipped)' if ph.is_equipped else 'تو کشوعه، فعال نیست'}",
            f"📆 اعتبار: {remain}",
            f"💵 قیمتِ خرید: {fmt(ph.original_price)} 🪙",
        ]
        if broken:
            lines.append("\n🛠 قطعاتِ خراب:")
            for _key, label, price in broken:
                lines.append(f"  • {label} - هزینه‌ی تعمیر: {fmt(price)} 🪙")
        else:
            lines.append("\n✅ سالمه.")
        session.commit()
        await send_response(
            update, "\n".join(lines),
            kb.myawy_phone_view_keyboard(ph.id, owner_id, ph.is_equipped, bool(broken), expired),
        )
    finally:
        session.close()


async def cb_myawy_phone_equip(update, context):
    _, phone_id, owner_id = update.callback_query.data.split(":")
    phone_id, owner_id = int(phone_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        ph = session.get(db.UserPhone, phone_id)
        if not ph or ph.user_id != owner_id or ph.is_discarded:
            await update.callback_query.answer("این گوشی دیگه وجود نداره.", show_alert=True)
            return
        session.query(db.UserPhone).filter_by(user_id=owner_id, is_equipped=True).update({"is_equipped": False})
        ph.is_equipped = True
        session.commit()
    finally:
        session.close()
    await cb_myawy_phone_view(update, context)


async def cb_myawy_phone_repair_pay(update, context):
    _, phone_id, owner_id, part = update.callback_query.data.split(":")
    phone_id, owner_id = int(phone_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        ph = session.get(db.UserPhone, phone_id)
        if not ph or ph.user_id != owner_id or ph.is_discarded:
            await update.callback_query.answer("این گوشی دیگه وجود نداره.", show_alert=True)
            return
        g = session.get(db.PhoneGeneration, ph.generation_id)
        user = db.get_or_create_user(session, update.effective_user)
        part_map = {
            "lcd": ("broken_lcd", g.repair_lcd_price if g else 0),
            "battery": ("broken_battery", g.repair_battery_price if g else 0),
            "cpu": ("broken_cpu", g.repair_cpu_price if g else 0),
        }
        if part not in part_map or not getattr(ph, part_map[part][0]):
            session.commit()
            await update.callback_query.answer("این قطعه سالمه.", show_alert=True)
            return
        price = part_map[part][1]
        if user.hop_points < price - 0.5:
            session.commit()
            await update.callback_query.answer(f"موجودی کافی نیست! {price:,.0f} 🪙 لازمه.", show_alert=True)
            return
        user.hop_points -= price
        setattr(ph, part_map[part][0], False)
        session.commit()
        await update.callback_query.answer("✅ تعمیر شد!")
    finally:
        session.close()
    await cb_myawy_phone_view(update, context)


async def cb_myawy_phone_sell_ask(update, context):
    _, phone_id, owner_id = update.callback_query.data.split(":")
    phone_id, owner_id = int(phone_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        ph = session.get(db.UserPhone, phone_id)
        if not ph or ph.user_id != owner_id or ph.is_discarded:
            await update.callback_query.answer("این گوشی دیگه وجود نداره.", show_alert=True)
            return
        already = session.query(db.BlackMarketListing).filter_by(phone_id=ph.id, is_sold=False).first()
        if already:
            session.commit()
            await update.callback_query.answer("این گوشی از قبل تو بازارِ سیاهه.", show_alert=True)
            return
        original_price = ph.original_price
        session.commit()
    finally:
        session.close()
    await ask_for_input(
        update, context,
        f"🏴 با چه قیمتی بذاری تو بازارِ سیاه؟ باید کمتر از قیمتِ اصلیش (زیرِ {fmt(original_price)} 🪙) "
        f"باشه - حتی ۱ هاپ پوینت هم مجازه.",
        {"type": "phone_sell_price", "phone_id": phone_id, "owner_id": owner_id}, "myawy_awaiting",
    )


async def cb_myawy_phone_discard_ask(update, context):
    _, phone_id, owner_id = update.callback_query.data.split(":")
    phone_id, owner_id = int(phone_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    await send_response(
        update, "🗑 مطمئنی می‌خوای این گوشی رو کلاً دور بندازی؟ این کار برگشت‌ناپذیره.",
        kb.myawy_phone_discard_confirm_keyboard(phone_id, owner_id),
    )


async def cb_myawy_phone_discard_confirm(update, context):
    _, phone_id, owner_id = update.callback_query.data.split(":")
    phone_id, owner_id = int(phone_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        ph = session.get(db.UserPhone, phone_id)
        if ph and ph.user_id == owner_id:
            ph.is_discarded = True
            ph.is_equipped = False
            session.query(db.BlackMarketListing).filter_by(phone_id=ph.id, is_sold=False).update({"is_sold": True})
            session.commit()
    finally:
        session.close()
    await _render_drawer(update, context, owner_id)


# ---------------------------------------------------------------------------
# 🏴 بازارِ سیاه (خرید و فروشِ دستِ‌دوم بینِ خودِ پلیرها)
# ---------------------------------------------------------------------------

async def _render_blackmarket(update, context, owner_id: int):
    session = db.get_session()
    try:
        listings = (
            session.query(db.BlackMarketListing)
            .filter(db.BlackMarketListing.is_sold == False, db.BlackMarketListing.seller_id != owner_id)  # noqa: E712
            .order_by(db.BlackMarketListing.created_at.desc())
            .limit(30)
            .all()
        )
        items = []
        for listing in listings:
            ph = session.get(db.UserPhone, listing.phone_id)
            if not ph or ph.is_discarded:
                continue
            g = session.get(db.PhoneGeneration, ph.generation_id)
            line = _generation_line(session, g)
            seller = session.get(db.User, listing.seller_id)
            label = (
                f"{line.name if line else '?'} {g.name if g else '?'} | {fmt(listing.price)}🪙 | "
                f"👤{seller.display_name() if seller else listing.seller_id}"
            )
            items.append((listing.id, label))
        my_listings = session.query(db.BlackMarketListing).filter_by(seller_id=owner_id, is_sold=False).count()
        session.commit()
        text = "🏴 بازارِ سیاهِ گوشی هاپویی:" if items else "🏴 فعلاً هیچ آگهی‌ای تو بازارِ سیاه نیست."
        await send_response(update, text, kb.myawy_bm_keyboard(items, owner_id, my_listings))
    finally:
        session.close()


async def cb_myawy_bm(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await _render_blackmarket(update, context, owner_id)


async def cb_myawy_bm_buy_ask(update, context):
    """قبلاً همینجا (با یه کلیک) خرید انجام می‌شد؛ حالا اول یه تاییدیه نشون
    می‌ده که تصادفی/اشتباهی روی گوشیِ اشتباه یا با پولِ زیاد خرید انجام نشه."""
    _, listing_id, owner_id = update.callback_query.data.split(":")
    listing_id, owner_id = int(listing_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        listing = session.get(db.BlackMarketListing, listing_id)
        if not listing or listing.is_sold:
            await update.callback_query.answer("این آگهی دیگه موجود نیست.", show_alert=True)
            await _render_blackmarket(update, context, owner_id)
            return
        if listing.seller_id == owner_id:
            await update.callback_query.answer("نمی‌تونی گوشیِ خودتو بخری!", show_alert=True)
            return
        ph = session.get(db.UserPhone, listing.phone_id)
        g = session.get(db.PhoneGeneration, ph.generation_id) if ph else None
        line = _generation_line(session, g) if g else None
        name = f"{line.name if line else '?'} {g.name if g else '?'}"
        seller = session.get(db.User, listing.seller_id)
        text = (
            f"🏴 مطمئنی می‌خوای این گوشی رو بخری؟\n\n"
            f"📱 {name}\n"
            f"💰 قیمت: {fmt(listing.price)} 🪙\n"
            f"👤 فروشنده: {seller.display_name() if seller else listing.seller_id}\n\n"
            "این کار فوریه و برگشت‌ناپذیره."
        )
        await send_response(update, text, kb.myawy_bm_buy_confirm_keyboard(listing_id, owner_id))
    finally:
        session.close()


async def cb_myawy_bm_buy_confirm(update, context):
    _, listing_id, owner_id = update.callback_query.data.split(":")
    listing_id, owner_id = int(listing_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        listing = session.get(db.BlackMarketListing, listing_id)
        if not listing or listing.is_sold:
            session.commit()
            await update.callback_query.answer("این آگهی دیگه موجود نیست.", show_alert=True)
            await _render_blackmarket(update, context, owner_id)
            return
        if listing.seller_id == owner_id:
            session.commit()
            await update.callback_query.answer("نمی‌تونی گوشیِ خودتو بخری!", show_alert=True)
            return
        buyer = db.get_or_create_user(session, update.effective_user)
        if buyer.hop_points < listing.price - 0.5:
            session.commit()
            await update.callback_query.answer(f"موجودی کافی نیست! {listing.price:,.0f} 🪙 لازمه.", show_alert=True)
            return
        if _drawer_count(session, owner_id) >= DRAWER_MAX_PHONES:
            session.commit()
            await update.callback_query.answer(
                f"❌ کشوی گوشیِ هاپویی‌ت پره (حداکثر {DRAWER_MAX_PHONES} تا)! اول یکی رو بفروش یا دورش بنداز.",
                show_alert=True,
            )
            return
        ph = session.get(db.UserPhone, listing.phone_id)
        if not ph or ph.is_discarded:
            listing.is_sold = True
            session.commit()
            await update.callback_query.answer("این گوشی دیگه وجود نداره.", show_alert=True)
            await _render_blackmarket(update, context, owner_id)
            return
        seller = session.get(db.User, listing.seller_id)
        buyer.hop_points -= listing.price
        if seller:
            seller.hop_points += listing.price
        ph.user_id = buyer.telegram_id
        ph.is_equipped = not bool(_equipped_phone(session, buyer.telegram_id))
        ph.original_price = listing.price  # سقفِ فروشِ بعدیِ همین گوشی از این به بعد رو همین قیمتِ آخر تعیین می‌کنه
        listing.is_sold = True
        session.commit()
        await update.callback_query.answer("✅ خریدی! رفت تو کشوت.")
    finally:
        session.close()
    await _render_blackmarket(update, context, owner_id)


async def _render_bm_mine(update, context, owner_id: int):
    session = db.get_session()
    try:
        listings = session.query(db.BlackMarketListing).filter_by(seller_id=owner_id, is_sold=False).all()
        items = []
        for listing in listings:
            ph = session.get(db.UserPhone, listing.phone_id)
            g = session.get(db.PhoneGeneration, ph.generation_id) if ph else None
            items.append((listing.id, f"{g.name if g else '?'} | {fmt(listing.price)}🪙"))
        session.commit()
        text = "🏴 آگهی‌های من:" if items else "هیچ آگهیِ فعالی تو بازارِ سیاه نداری."
        await send_response(update, text, kb.myawy_bm_mine_keyboard(items, owner_id))
    finally:
        session.close()


async def cb_myawy_bm_mine(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await _render_bm_mine(update, context, owner_id)


async def cb_myawy_bm_cancel(update, context):
    _, listing_id, owner_id = update.callback_query.data.split(":")
    listing_id, owner_id = int(listing_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        listing = session.get(db.BlackMarketListing, listing_id)
        if listing and listing.seller_id == owner_id and not listing.is_sold:
            listing.is_sold = True
            session.commit()
    finally:
        session.close()
    await _render_bm_mine(update, context, owner_id)


# ---------------------------------------------------------------------------
# مسیریاب دکمه‌های شیشه‌ای
# ---------------------------------------------------------------------------

MYAWY_PREFIX_MAP = {
    "myawy_home": cb_myawy_home,
    "myawy_operators": cb_myawy_operators,
    "myawy_buy_gb_ask": cb_myawy_buy_gb_ask,
    "myawy_platforms": cb_myawy_platforms,
    "myawy_platform_view": cb_myawy_platform_view,
    "myawy_new_post_ask": cb_myawy_new_post_ask,
    "myawy_feed": cb_myawy_feed,
    "myawy_like": cb_myawy_like,
    "myawy_request_platform": cb_myawy_request_platform,
    "myawy_my_debts": cb_myawy_my_debts,
    "myawy_platform_debt": cb_myawy_platform_debt,
    "myawy_pay_fee": cb_myawy_pay_fee,
    "myawy_shop": cb_myawy_shop,
    "myawy_shop_view": cb_myawy_shop_view,
    "myawy_shop_buy": cb_myawy_shop_buy,
    "myawy_drawer": cb_myawy_drawer,
    "myawy_phone_view": cb_myawy_phone_view,
    "myawy_phone_equip": cb_myawy_phone_equip,
    "myawy_phone_repair_pay": cb_myawy_phone_repair_pay,
    "myawy_phone_sell_ask": cb_myawy_phone_sell_ask,
    "myawy_phone_discard_ask": cb_myawy_phone_discard_ask,
    "myawy_phone_discard_confirm": cb_myawy_phone_discard_confirm,
    "myawy_bm": cb_myawy_bm,
    "myawy_bm_buy_ask": cb_myawy_bm_buy_ask,
    "myawy_bm_buy_confirm": cb_myawy_bm_buy_confirm,
    "myawy_bm_mine": cb_myawy_bm_mine,
    "myawy_bm_cancel": cb_myawy_bm_cancel,
    "myawy_myposts": cb_myawy_myposts,
    "myawy_mypost_delete": cb_myawy_mypost_delete,
    "myawy_myposts_deleteall_ask": cb_myawy_myposts_deleteall_ask,
    "myawy_myposts_deleteall_confirm": cb_myawy_myposts_deleteall_confirm,
}


async def myawy_callback_router(update, context) -> bool:
    """اگه data مالِ گوشی هاپویی بود پردازشش می‌کنه و True برمی‌گردونه، وگرنه
    False تا main.py بره سراغِ روتِر بعدی."""
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = MYAWY_PREFIX_MAP.get(prefix)
    if handler:
        await handler(update, context)
        return True
    return False
