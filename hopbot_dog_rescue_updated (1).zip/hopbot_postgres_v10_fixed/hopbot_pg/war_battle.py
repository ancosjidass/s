# -*- coding: utf-8 -*-
"""
نبردها (بخش ۲): قدرت، مچ‌میکینگ، جاسوسی، شیلد، آماده‌سازی، شروعِ حمله، Resolve (اتمیک و Idempotent)،
انتقام، لغو/انقضا و گزارش.

نکته‌های اقتصادی (طراحی مثل CoC، نه سرقت از کیف پول):
- غنیمت فقط از «گاوصندوقِ جنگ» هدف برداشته می‌شه (نه کیف‌پول/بانک) و همون مقدار به گاوصندوقِ مهاجم
  می‌ره؛ یعنی جابه‌جایی است نه چاپِ پول. مهاجم نمی‌تونه بیشتر از ظرفیتِ گاوصندوقش بگیره.
- سقفِ هر نبرد (ساعتِ درآمدِ خودِ مهاجم) و سقفِ روزانه‌ی هر جفت، اجازه‌ی پول‌شویی با اکانتِ دوم نمی‌ده.
"""
import datetime
import hashlib
import json
import math
import random

from sqlalchemy import func

import db
import war_db as W
import war_engine as E
import war_svc as S
from war_svc import WarError, cf, ci, cs, utcnow


# ---------------------------------------------------------------------------
# قدرت‌ها
# ---------------------------------------------------------------------------

def engine_units(session, uid, army=None, only_attackers=False):
    """WarUnit ها → Unitهای موتور. army: {key:{'h','d','lv'}} برای ارتشِ اعزام‌شده؛ None = ارتشِ داخلِ پایگاه."""
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    out = []
    if army is None:
        rows = [(u.unit_key, u.healthy, u.damaged, u.level) for u in session.query(W.WarUnit).filter_by(user_id=uid).all()]
    else:
        rows = [(k, v.get("h", 0), v.get("d", 0), v.get("lv", 1)) for k, v in army.items() if not k.startswith("_")]
    for key, h, dmg, lv in rows:
        d = defs.get(key)
        if not d or (h + dmg) <= 0:
            continue
        if only_attackers and d.atk <= 0 and d.special_power <= 0:
            continue
        out.append(E.Unit(key=key, cat=d.category, atk=d.atk, defn=d.defn, durability=d.durability,
                          accuracy=d.accuracy, support_pct=d.special_power, level_mult=S.unit_level_mult(d, lv),
                          healthy=h, damaged=dmg))
    return out


def defense_structures(session, uid):
    structs, wall = [], 1.0
    for d in S.bdefs(session):
        lvl = S.bld_level(session, uid, d.key)
        if lvl <= 0:
            continue
        v = S.building_value(d, lvl)
        if d.kind == "def_ground":
            structs.append({"type": "ground", "power": v})
        elif d.kind == "def_air":
            structs.append({"type": "air", "power": v})
        elif d.kind == "wall":
            wall = v
    return structs, wall


def power_of(session, uid, params=None):
    """(قدرتِ حمله, قدرتِ دفاع, Military Power) - نمایشی؛ هیچ‌وقت عددِ دقیقِ دیگران به کاربر نشون داده نمی‌شه."""
    if params is None:
        params, _ = S.formula_params(session)
    units = engine_units(session, uid)
    p = session.get(W.WarPlayer, uid)
    A, _, _ = E.attack_side(units, params, 100, 1.0, 1.0)
    structs, wall = defense_structures(session, uid)
    D, _ = E.defense_side(structs, units, params, 100, wall, 1.0)
    return A, D, A + D


def peek_vault(session, tp, now=None):
    """موجودیِ گاوصندوقِ هدف در لحظه‌ی الان بدونِ تغییرِ دیتابیس."""
    now = now or utcnow()
    hours = max(0.0, (now - tp.vault_at).total_seconds() / 3600.0)
    hop_cap, mat_cap = S.vault_caps(session, tp)
    net = max(0.0, S.mine_income_ph(session, tp, now) - S.maintenance_ph(session, tp.user_id))
    return (max(tp.vault_hop, min(hop_cap, tp.vault_hop + net * hours)),
            max(tp.vault_mat, min(mat_cap, tp.vault_mat + S.mat_income_ph(session, tp) * hours)))


def name_of(session, uid) -> str:
    u = session.get(db.User, uid)
    return u.display_name() if u else str(uid)


def fuzz(uid_a, uid_b, salt, spread) -> float:
    h = hashlib.sha256(f"{uid_a}:{uid_b}:{salt}".encode()).digest()
    r = int.from_bytes(h[:4], "big") / 0xFFFFFFFF
    return 1.0 + (r * 2 - 1) * spread


def info_error_pct(session, p) -> float:
    e = cf(session, "war_spy_base_error_pct", 35) - S.kind_level(session, p.user_id, "radar") * cf(session, "war_spy_error_per_radar_pct", 3) \
        - S.clan_bonus_pct(session, p.clan_id, "spy_pct")
    return max(5.0, e)


# ---------------------------------------------------------------------------
# دیپلماسی/بلاک
# ---------------------------------------------------------------------------

def _pair(a, b):
    return (a, b) if a < b else (b, a)


def relation_between(session, clan_a, clan_b):
    if not clan_a or not clan_b:
        return None
    x, y = _pair(clan_a, clan_b)
    return session.query(W.WarRelation).filter_by(clan_a=x, clan_b=y).first()


def relation_blocks_attack(session, clan_a, clan_b, now=None) -> str:
    """رشته‌ی دلیل اگه حمله بینِ این دو قبیله ممنوعه، وگرنه ''."""
    if not clan_a or not clan_b:
        return ""
    if clan_a == clan_b:
        return "هم‌قبیله‌ای‌ت رو نمی‌تونی بزنی."
    r = relation_between(session, clan_a, clan_b)
    if not r:
        return ""
    now = now or utcnow()
    if r.kind == "ally":
        return "قبیله‌ی هم‌پیمانه."
    if r.kind == "truce" and r.until and r.until > now:
        return "بینِ دو قبیله آتش‌بس برقراره."
    return ""


# ---------------------------------------------------------------------------
# مچ‌میکینگ / هدف‌ها
# ---------------------------------------------------------------------------

def loot_tier(est, my_hourly):
    x = est / max(1.0, my_hourly)
    if x < 0.4:
        return "کم"
    if x < 1.2:
        return "متوسط"
    if x < 2.5:
        return "زیاد"
    return "خیلی زیاد"


def risk_label(ratio):
    if ratio < 0.7:
        return "کم"
    if ratio < 1.15:
        return "متوسط"
    return "زیاد"


def antifarm_mult(session, attacker_id, defender_id, now=None) -> float:
    now = now or utcnow()
    hrs = cf(session, "war_antifarm_window_hours", 24)
    n = session.query(W.WarBattle).filter(
        W.WarBattle.attacker_id == attacker_id, W.WarBattle.defender_id == defender_id,
        W.WarBattle.clan_war_id.is_(None), W.WarBattle.status.in_(("marching", "resolved")),
        W.WarBattle.created_at >= now - datetime.timedelta(hours=hrs)).count()
    steps = S.csv_floats(session, "war_antifarm_steps", "1,0.7,0.4,0.15,0")
    if not steps:
        return 1.0
    return steps[min(n, len(steps) - 1)]


def find_targets(session, p, limit=10, now=None):
    now = now or utcnow()
    S.sync_player(session, p, now)
    rng_t = cf(session, "war_matchmaking_trophy_range", 350)
    inactive = now - datetime.timedelta(days=cf(session, "war_target_max_inactive_days", 14))
    my_ref = S.player_ref(session, p)
    err = info_error_pct(session, p) / 100.0
    params, _ = S.formula_params(session)
    my_A, _, my_mil = power_of(session, p.user_id, params)
    day = now.strftime("%Y-%m-%d")
    found = []
    for widen in (1, 2, 4, 100):
        lo, hi = p.trophies - rng_t * widen, p.trophies + rng_t * widen
        q = session.query(W.WarPlayer).filter(
            W.WarPlayer.user_id != p.user_id, W.WarPlayer.trophies >= lo, W.WarPlayer.trophies <= hi,
            W.WarPlayer.last_seen_at >= inactive).order_by(func.abs(W.WarPlayer.trophies - p.trophies)).limit(60)
        found = []
        for tp in q.all():
            if tp.shield_until and tp.shield_until > now:
                continue
            if p.clan_id and tp.clan_id and relation_blocks_attack(session, p.clan_id, tp.clan_id, now):
                continue
            if antifarm_mult(session, p.user_id, tp.user_id, now) <= 0:
                continue
            found.append(tp)
        if len(found) >= limit:
            break
    rows = []
    for tp in found[:limit * 2]:
        A2, D2, mil = power_of(session, tp.user_id, params)
        vh, _ = peek_vault(session, tp, now)
        est_loot = vh * (1 - cf(session, "war_vault_protect_pct", 10) / 100) * cf(session, "war_loot_max_frac_pct", 35) / 100 * 0.7
        est_loot = min(est_loot, cf(session, "war_loot_cap_hours", 6) * my_ref)
        f = fuzz(p.user_id, tp.user_id, day, err)
        rows.append({
            "user_id": tp.user_id, "name": name_of(session, tp.user_id), "trophies": tp.trophies,
            "th": tp.th_level, "power_lo": mil * f * (1 - err / 2), "power_hi": mil * f * (1 + err / 2),
            "loot": loot_tier(est_loot, my_ref), "risk": risk_label(D2 / max(1.0, my_A)),
            "clan": (session.get(W.WarClan, tp.clan_id).tag if tp.clan_id and session.get(W.WarClan, tp.clan_id) else ""),
            # مچ‌میکینگ فقط بر اساسِ کاپ نیست: نزدیکیِ قدرتِ واقعی هم وزن داره (بند ۲۲)
            "_sort": abs(tp.trophies - p.trophies) / max(1.0, rng_t) + 2.0 * abs(math.log(max(1.0, mil) / max(1.0, my_mil))) + random.random() * 0.3,
        })
    rows.sort(key=lambda r: r["_sort"])
    return rows[:limit]


# ---------------------------------------------------------------------------
# جاسوسی
# ---------------------------------------------------------------------------

def spy_target(session, p, target_id, now=None):
    now = now or utcnow()
    S.sync_player(session, p, now)
    S.require_feature(session, p, "spy")
    tp = session.get(W.WarPlayer, target_id)
    if not tp or target_id == p.user_id:
        raise WarError("هدف معتبر نیست.")
    last = S.metric_get(session, p.user_id, "spy_last_ts")
    cd = cf(session, "war_spy_cooldown_minutes", 10) * 60
    if last and now.timestamp() - last < cd:
        raise WarError(f"⏳ جاسوس هنوز برنگشته ({int(cd - (now.timestamp() - last))} ثانیه‌ی دیگه).")
    cost = round(cf(session, "war_spy_cost_ref_hours", 0.3) * S.player_ref(session, p), -1)
    S.hop_apply(session, session.get(db.User, p.user_id), -cost, "SPEND", "war:spy", ref=f"spy:{target_id}")
    row = session.query(W.WarMetric).filter_by(user_id=p.user_id, metric="spy_last_ts").first()
    if row is None:
        session.add(W.WarMetric(user_id=p.user_id, metric="spy_last_ts", value=now.timestamp()))
    else:
        row.value = now.timestamp()
    err = info_error_pct(session, p) / 100.0
    bucket = now.strftime("%Y-%m-%d-%H")
    params, _ = S.formula_params(session)
    _, _, mil = power_of(session, target_id, params)
    vh, vm = peek_vault(session, tp, now)
    f = fuzz(p.user_id, target_id, "pw" + bucket, err)
    info = {"name": name_of(session, target_id), "power": (mil * f * (1 - err / 2), mil * f * (1 + err / 2)),
            "vault": (vh * fuzz(p.user_id, target_id, "v" + bucket, err) * (1 - err / 2), vh * fuzz(p.user_id, target_id, "v" + bucket, err) * (1 + err / 2)),
            "readiness": max(0, min(100, tp.readiness * fuzz(p.user_id, target_id, "r" + bucket, err))),
            "units": [], "defenses": [], "trophies": tp.trophies, "th": tp.th_level, "cost": cost}
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    for u in session.query(W.WarUnit).filter_by(user_id=target_id).all():
        n = u.healthy + u.damaged
        if n <= 0 or u.unit_key not in defs:
            continue
        f2 = fuzz(p.user_id, target_id, "u" + u.unit_key + bucket, err)
        lo, hi = max(0, int(n * f2 * (1 - err))), int(math.ceil(n * f2 * (1 + err))) + 1
        info["units"].append((defs[u.unit_key].emoji + " " + defs[u.unit_key].name, lo, hi))
    for d in S.bdefs(session):
        if d.kind in ("def_ground", "def_air", "wall"):
            lv = S.bld_level(session, target_id, d.key)
            if lv:
                shift = int(round((fuzz(p.user_id, target_id, "b" + d.key + bucket, err) - 1) / max(err, 0.05) * 1.5))
                info["defenses"].append((d.emoji + " " + d.name, max(1, lv + shift - 1), lv + shift + 1))
    S.audit(session, p.user_id, "spy", target=target_id, cost=cost)
    return info


# ---------------------------------------------------------------------------
# شیلد و آماده‌سازی
# ---------------------------------------------------------------------------

def shield_hours_for(session, destruction) -> float:
    hrs = 0.0
    for tok in cs(session, "war_shield_rules", "40:8,90:14").split(","):
        try:
            th, h = tok.split(":")
            if destruction >= float(th):
                hrs = max(hrs, float(h))
        except ValueError:
            continue
    return hrs


def buy_shield(session, p):
    S.sync_player(session, p)
    now = utcnow()
    hrs = cf(session, "war_shield_buy_hours", 12)
    if p.shield_until and (p.shield_until - now).total_seconds() > hrs * 3600:
        raise WarError("شیلدِ فعالت هنوز طولانیه.")
    cost = round(cf(session, "war_shield_buy_ref_hours", 2) * S.player_ref(session, p), -1)
    S.hop_apply(session, session.get(db.User, p.user_id), -cost, "SPEND", "war:shield_buy")
    p.shield_until = max(p.shield_until or now, now) + datetime.timedelta(hours=hrs)
    S.audit(session, p.user_id, "shield_buy", cost=cost, hours=hrs)
    return cost, hrs


def prepare_army(session, p):
    """🔧 آماده‌سازیِ تیم و تجهیزات: هزینه‌ی هاپ + سوخت، افزایشِ ریدینس. تعمیر نمی‌کنه (جداست)."""
    S.sync_player(session, p)
    if p.readiness >= 99.9:
        raise WarError("ارتشت از قبل کاملاً آماده‌ست.")
    fuel_need = cf(session, "war_prepare_fuel", 1)
    if p.fuel < fuel_need:
        raise WarError("⛽ سوخت کافی نیست.")
    cost = round(cf(session, "war_prepare_cost_ref_hours", 0.4) * S.player_ref(session, p), -1)
    S.hop_apply(session, session.get(db.User, p.user_id), -cost, "SPEND", "war:prepare")
    p.fuel -= fuel_need
    gain = cf(session, "war_prepare_gain", 30)
    old = p.readiness
    p.readiness = min(100.0, p.readiness + gain)
    S.give_reward(session, p.user_id, "prepare", ref=f"prepare:{p.user_id}:{int(utcnow().timestamp())}", _player=p)
    S.audit(session, p.user_id, "prepare", cost=cost, old=old, new=p.readiness)
    return cost, old, p.readiness


# ---------------------------------------------------------------------------
# ترکیب ارتش
# ---------------------------------------------------------------------------

def default_composition(session, uid, mode="all"):
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    comp = {}
    for u in session.query(W.WarUnit).filter_by(user_id=uid).all():
        d = defs.get(u.unit_key)
        if not d or (d.atk <= 0 and d.special_power <= 0):
            continue
        n = u.healthy if mode in ("all", "half") else u.healthy + u.damaged
        if mode == "half":
            n = n // 2
        if n > 0:
            comp[u.unit_key] = n
    return comp


def materialize(session, uid, comp, healthy_only=False):
    """{key: qty} → {key:{'h','d','lv'}} با کم‌کردنِ اول از سالم‌ها؛ چیزی رو دیتابیس تغییر نمی‌ده."""
    have = S.units_of(session, uid)
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    out = {}
    for key, qty in comp.items():
        u, d = have.get(key), defs.get(key)
        if not u or not d or qty <= 0:
            continue
        avail_d = 0 if healthy_only else u.damaged
        take = min(int(qty), u.healthy + avail_d)
        h = min(take, u.healthy)
        out[key] = {"h": h, "d": take - h, "lv": u.level}
    return {k: v for k, v in out.items() if v["h"] + v["d"] > 0}


def army_housing(session, army):
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    return sum((v["h"] + v["d"]) * defs[k].housing for k, v in army.items() if k in defs)


def max_active_ops(session, p) -> int:
    return ci(session, "war_max_active_ops", 2) + max(0, p.th_level - 1) // 4


def active_ops(session, uid):
    return session.query(W.WarBattle).filter_by(attacker_id=uid, status="marching").order_by(W.WarBattle.resolve_at).all()


# ---------------------------------------------------------------------------
# شروع حمله
# ---------------------------------------------------------------------------

def launch_attack(session, p, target_id, btype_key, comp, healthy_only=False, chat_id=None, mode="normal",
                  war_id=None, revenge_of=None, now=None):
    now = now or utcnow()
    S.sync_player(session, p, now)
    if not S.ci(session, "war_enabled", 1):
        raise WarError("سیستمِ جنگ فعلاً خاموشه.")
    bt = session.get(W.WarBattleType, btype_key)
    if not bt or not bt.enabled:
        raise WarError("این نوعِ عملیات وجود نداره.")
    S.require_feature(session, p, "attack")
    if bt.unlock_feature:
        S.require_feature(session, p, bt.unlock_feature)
    if target_id == p.user_id:
        raise WarError("خودت رو نمی‌تونی بزنی.")
    tp = session.get(W.WarPlayer, target_id)
    if not tp:
        raise WarError("این هدف هنوز وارد بازی جنگ نشده.")
    if len(active_ops(session, p.user_id)) >= max_active_ops(session, p):
        raise WarError(f"عملیاتِ هم‌زمانت پره ({max_active_ops(session, p)} تا).")
    if session.query(W.WarBattle).filter_by(attacker_id=p.user_id, defender_id=target_id, status="marching").first():
        raise WarError("یه عملیاتِ در حالِ انجام روی این هدف داری.")
    farm = 1.0
    if mode == "normal":
        if tp.shield_until and tp.shield_until > now:
            raise WarError("🛡 هدف شیلد داره.")
        why = relation_blocks_attack(session, p.clan_id, tp.clan_id, now) if p.clan_id and tp.clan_id else ""
        if why:
            raise WarError(f"❌ {why}")
        farm = antifarm_mult(session, p.user_id, target_id, now)
        if farm <= 0:
            raise WarError("🚫 به‌خاطرِ حمله‌ی مکرر به این هدف، الان بی‌بازده‌ست؛ کمی صبر کن یا هدفِ دیگه‌ای بزن.")
    elif mode == "revenge":
        rb = session.get(W.WarBattle, revenge_of)
        if (not rb or rb.defender_id != p.user_id or rb.attacker_id != target_id or rb.status != "resolved"
                or rb.outcome not in ("attacker", "draw")
                or (now - rb.resolved_at).total_seconds() > cf(session, "war_revenge_hours", 24) * 3600):
            raise WarError("فرصتِ انتقام تموم شده یا معتبر نیست.")
        if session.query(W.WarBattle).filter_by(revenge_of=revenge_of).first():
            raise WarError("قبلاً انتقامت رو گرفتی.")
    army = materialize(session, p.user_id, comp, healthy_only)
    if not army:
        raise WarError("هیچ نیرویی برای اعزام انتخاب نشده.")
    if not any(k for k in army if any(u.atk > 0 for u in engine_units(session, p.user_id, {k: army[k]}))):
        raise WarError("حداقل یک واحدِ تهاجمی لازمه.")
    if army_housing(session, army) < bt.min_army_housing:
        raise WarError(f"برای این عملیات حداقل {bt.min_army_housing} ظرفیتِ نیرو لازمه.")
    if p.fuel < bt.fuel:
        raise WarError(f"⛽ سوخت کافی نیست (نیاز: {bt.fuel:g}).")
    cost = round(bt.cost_ref_hours * S.player_ref(session, p), -1)
    if cost > 0:
        S.hop_apply(session, session.get(db.User, p.user_id), -cost, "SPEND", f"war:op:{btype_key}", ref=f"op:{p.user_id}:{target_id}")
    p.fuel -= bt.fuel
    have = S.units_of(session, p.user_id)
    for k, v in army.items():
        have[k].healthy -= v["h"]
        have[k].damaged -= v["d"]
        v["lv"] = have[k].level
    army["_ready"] = round(p.readiness, 2)
    dur_s = random.randint(int(bt.min_seconds), int(max(bt.min_seconds, bt.max_seconds)))
    if war_id:
        wr = session.get(W.WarClanWar, war_id)
        room = (wr.end_at - now).total_seconds() - 60
        if room < bt.min_seconds:
            raise WarError("⏳ زمانِ کافی تا پایانِ جنگ نمونده.")
        dur_s = int(min(dur_s, room))
    if cf(session, "war_attack_breaks_shield", 1) and p.shield_until and p.shield_until > now and mode != "clanwar":
        p.shield_until = None
    b = W.WarBattle(attacker_id=p.user_id, defender_id=target_id, btype=btype_key, clan_war_id=war_id,
                    is_revenge=(mode == "revenge"), revenge_of=revenge_of if mode == "revenge" else None,
                    formula_version=S.ci(session, "war_formula_version", 1), seed=random.randrange(1, 2 ** 62),
                    farm_mult=farm, created_at=now, resolve_at=now + datetime.timedelta(seconds=dur_s),
                    army_json=json.dumps(army), origin_chat_id=chat_id)
    session.add(b)
    session.flush()
    S.audit(session, p.user_id, "battle_launch", battle=b.id, target=target_id, type=btype_key, cost=cost, army={k: v for k, v in army.items() if not k.startswith("_")})
    return b, cost


# ---------------------------------------------------------------------------
# Resolve (اتمیک + Idempotent)
# ---------------------------------------------------------------------------

def claim_battle(session, battle_id) -> bool:
    """اولین statement باید همین باشه (قبل از هر خوندنی) تا Race نداشته باشیم؛ فقط یک تراکنش برنده می‌شه."""
    n = session.query(W.WarBattle).filter(W.WarBattle.id == battle_id, W.WarBattle.status == "marching").update(
        {"status": "resolving"}, synchronize_session=False)
    return n == 1


def _trophy_delta(session, a_tr, d_tr, outcome, stars):
    base = cf(session, "war_trophy_base", 30)
    ratio = cf(session, "war_trophy_loss_ratio", 0.7)
    if outcome == "attacker":
        f = max(0.5, min(1.6, 1 + (d_tr - a_tr) / 1000.0))
        win = base * (0.4 + 0.6 * stars / 3.0) * f
        return int(round(win)), -int(round(win * ratio))
    if outcome == "defender":
        f = max(0.5, min(1.6, 1 + (a_tr - d_tr) / 1000.0))
        loss = base * 0.5 * f
        return -int(round(loss)), int(round(loss * 0.6))
    return 0, 0


def resolve_battle(session, battle_id, now=None):
    """Battle Resolution. برمی‌گردونه dict اعلان یا None اگه قبلاً پردازش شده. commit با فراخوان."""
    now = now or utcnow()
    if not claim_battle(session, battle_id):
        return None
    b = session.get(W.WarBattle, battle_id)
    ap, dp = S.get_player(session, b.attacker_id), S.get_player(session, b.defender_id)
    S.sync_player(session, ap, now)
    S.sync_player(session, dp, now)
    params, _ = S.formula_params(session, b.formula_version)
    bt = session.get(W.WarBattleType, b.btype) or W.WarBattleType(key=b.btype, name=b.btype)
    army = json.loads(b.army_json or "{}")
    atk_ready = army.pop("_ready", ap.readiness)
    atk_units = engine_units(session, b.attacker_id, army)
    def_units = engine_units(session, b.defender_id)
    structs, wall = defense_structures(session, b.defender_id)
    res = E.resolve(b.seed, atk_units, structs, def_units, params, atk_ready, dp.readiness,
                    atk_mult=bt.atk_mult, casualty_mult=bt.casualty_mult,
                    atk_research=1 + S.clan_bonus_pct(session, ap.clan_id, "atk_pct") / 100.0,
                    def_research=1 + S.clan_bonus_pct(session, dp.clan_id, "def_pct") / 100.0, wall_mult=wall)
    outcome, stars, destr = res["outcome"], res["stars"], res["destruction"]
    # --- تلفات ---
    a_units = S.units_of(session, b.attacker_id)
    for k, v in res["atk_units"].items():
        u = a_units.get(k)
        if u is None:
            u = W.WarUnit(user_id=b.attacker_id, unit_key=k, healthy=0, damaged=0, level=army.get(k, {}).get("lv", 1))
            session.add(u)
            a_units[k] = u
        u.healthy += v["h"]
        u.damaged += v["d"]
        u.destroyed_total += v["x"]
    d_units = S.units_of(session, b.defender_id)
    for k, v in res["def_units"].items():
        u = d_units.get(k)
        if u:
            u.healthy, u.damaged = v["h"], v["d"]
            u.destroyed_total += v["x"]
    # --- غنیمت (از گاوصندوق، جابه‌جایی) ---
    loot_h = loot_m = 0.0
    if outcome == "attacker":
        ev = S.event_mults(session, S.player_level(session, ap), b.btype, now)
        prot = 1 - cf(session, "war_vault_protect_pct", 10) / 100
        frac = cf(session, "war_loot_max_frac_pct", 35) / 100 * (destr / 100.0) ** cf(session, "war_loot_exp", 1.5)
        mult = bt.loot_mult * b.farm_mult * ev["loot"] * (1 + S.clan_bonus_pct(session, ap.clan_id, "loot_pct") / 100)
        if destr >= cf(session, "war_crushing_threshold", 90):
            mult *= 1 + cf(session, "war_crushing_bonus_pct", 25) / 100
            res["crushing"] = True
        if b.is_revenge:
            mult *= 1 + cf(session, "war_revenge_loot_bonus_pct", 15) / 100
        if b.clan_war_id:
            mult *= cf(session, "war_cw_loot_mult", 1.5)
        if dp.trophies + cf(session, "war_weak_target_trophy_gap", 400) < ap.trophies and not b.clan_war_id:
            mult *= cf(session, "war_weak_target_loot_pct", 50) / 100
        want_h = dp.vault_hop * prot * frac * mult
        want_m = dp.vault_mat * prot * frac * mult
        my_ref = S.player_ref(session, ap)
        cap = cf(session, "war_loot_cap_hours", 6) * my_ref
        pair_cap = cf(session, "war_pair_daily_loot_cap_hours", 10) * my_ref
        since = now - datetime.timedelta(hours=24)
        done = session.query(func.coalesce(func.sum(W.WarBattle.loot_hop), 0.0)).filter(
            W.WarBattle.attacker_id == b.attacker_id, W.WarBattle.defender_id == b.defender_id,
            W.WarBattle.status == "resolved", W.WarBattle.resolved_at >= since).scalar() or 0.0
        want_h = max(0.0, min(want_h, cap, pair_cap - done))
        hop_cap, mat_cap = S.vault_caps(session, ap)
        loot_h = math.floor(max(0.0, min(want_h, hop_cap - ap.vault_hop, dp.vault_hop)))
        loot_m = math.floor(max(0.0, min(want_m, mat_cap - ap.vault_mat, dp.vault_mat)))
        ap.vault_hop += loot_h
        dp.vault_hop -= loot_h
        ap.vault_mat += loot_m
        dp.vault_mat -= loot_m
    # --- کاپ ---
    t_a, t_d = (0, 0) if b.clan_war_id else _trophy_delta(session, ap.trophies, dp.trophies, outcome, stars)
    t_a = int(round(t_a * b.farm_mult)) if t_a > 0 else t_a
    ap.trophies = max(0, ap.trophies + t_a)
    dp.trophies = max(0, dp.trophies + t_d)
    # --- ریدینس ---
    r_before_a, r_before_d = ap.readiness, dp.readiness
    ap.readiness = max(0.0, ap.readiness - bt.readiness_loss * max(0.6, min(1.6, res["pressure"])))
    dp.readiness = max(0.0, dp.readiness - cf(session, "war_defense_readiness_loss", 6) * destr / 100.0)
    # --- شیلد ---
    shield_h = 0.0
    if outcome == "attacker" and not b.clan_war_id:
        shield_h = shield_hours_for(session, destr)
        if shield_h:
            dp.shield_until = max(dp.shield_until or now, now) + datetime.timedelta(hours=shield_h)
    # --- آمار ---
    ap.attacks += 1
    S.metric_bump(session, ap.user_id, "attacks", 1)
    if b.clan_war_id:
        S.metric_bump(session, ap.user_id, "cw_attacks", 1)
    if stars:
        ap.stars_total += stars
        S.metric_bump(session, ap.user_id, "stars", stars)
    if outcome == "attacker":
        ap.wins += 1
        dp.defense_losses += 1
        S.metric_bump(session, ap.user_id, "wins", 1)
    elif outcome == "defender":
        ap.losses += 1
        dp.defense_wins += 1
        S.metric_bump(session, dp.user_id, "defense_wins", 1)
    else:
        S.metric_bump(session, ap.user_id, "draws", 1)
    # --- پاداش‌ها (Reward Engine) ---
    xpm = bt.xp_mult * (cf(session, "war_revenge_xp_mult", 1.1) if b.is_revenge else 1.0)
    rew_a = rew_d = None
    if outcome == "attacker":
        sc = (0.5 + 0.5 * stars / 3.0) * bt.reward_mult
        rew_a = S.give_reward(session, ap.user_id, "battle_win", scale=sc, ref=f"battle:{b.id}", farm_mult=b.farm_mult, xp_mult=xpm, _player=ap, battle_type=b.btype)
        rew_d = S.give_reward(session, dp.user_id, "defense_loss", scale=max(0.3, destr / 100.0), ref=f"battle:{b.id}", farm_mult=b.farm_mult, _player=dp, battle_type=b.btype)
    elif outcome == "draw":
        rew_a = S.give_reward(session, ap.user_id, "battle_draw", scale=bt.reward_mult, ref=f"battle:{b.id}", farm_mult=b.farm_mult, xp_mult=xpm, _player=ap, battle_type=b.btype)
        rew_d = S.give_reward(session, dp.user_id, "defense_win", scale=0.5, ref=f"battle:{b.id}", farm_mult=b.farm_mult, _player=dp, battle_type=b.btype)
    else:
        rew_a = S.give_reward(session, ap.user_id, "battle_loss", scale=bt.reward_mult, ref=f"battle:{b.id}", farm_mult=b.farm_mult, xp_mult=xpm, _player=ap, battle_type=b.btype)
        rew_d = S.give_reward(session, dp.user_id, "defense_win", scale=1.0, ref=f"battle:{b.id}", farm_mult=b.farm_mult, _player=dp, battle_type=b.btype)
    if b.clan_war_id:
        import war_clan as C
        C.record_cw_attack(session, b, res)
    res.update({"loot_hop": loot_h, "loot_mat": loot_m, "trophies_atk": t_a, "trophies_def": t_d,
                "readiness_atk": [round(r_before_a), round(ap.readiness)], "readiness_def": [round(r_before_d), round(dp.readiness)],
                "shield_hours": shield_h, "rew_atk": rew_a, "rew_def": rew_d, "farm_mult": b.farm_mult,
                "atk_name": name_of(session, ap.user_id), "def_name": name_of(session, dp.user_id)})
    b.status, b.outcome, b.stars, b.destruction = "resolved", outcome, stars, destr
    b.loot_hop, b.loot_mat, b.resolved_at = loot_h, loot_m, now
    b.result_json = json.dumps(res, ensure_ascii=False)
    S.audit(session, None, "battle_resolved", battle=b.id, outcome=outcome, stars=stars, loot=loot_h, version=b.formula_version)
    return {"battle_id": b.id, "attacker": b.attacker_id, "defender": b.defender_id, "chat_id": b.origin_chat_id,
            "outcome": outcome, "stars": stars, "destruction": destr, "loot_hop": loot_h, "clan_war": b.clan_war_id}


def cancel_battle(session, battle_id, reason="cancelled", refund_pct=100.0):
    """لغو/انقضا/قطع: نیروها برمی‌گردن و بخشی از هزینه/سوخت بازپرداخت می‌شه. Idempotent."""
    n = session.query(W.WarBattle).filter(W.WarBattle.id == battle_id, W.WarBattle.status == "marching").update(
        {"status": "cancelled", "outcome": reason, "resolved_at": utcnow()}, synchronize_session=False)
    if n != 1:
        return False
    b = session.get(W.WarBattle, battle_id)
    army = json.loads(b.army_json or "{}")
    army.pop("_ready", None)
    have = S.units_of(session, b.attacker_id)
    for k, v in army.items():
        u = have.get(k)
        if u is None:
            u = W.WarUnit(user_id=b.attacker_id, unit_key=k, healthy=0, damaged=0, level=v.get("lv", 1))
            session.add(u)
        u.healthy += v["h"]
        u.damaged += v["d"]
    ap = S.get_player(session, b.attacker_id)
    bt = session.get(W.WarBattleType, b.btype)
    if bt and refund_pct > 0:
        ap.fuel = min(cf(session, "war_fuel_max", 10), ap.fuel + bt.fuel * refund_pct / 100)
        amt = math.floor(bt.cost_ref_hours * S.player_ref(session, ap) * refund_pct / 100)
        if amt > 0:
            S.hop_apply(session, session.get(db.User, b.attacker_id), amt, "REFUND", f"war:battle_cancel:{reason}", ref=f"battle:{b.id}")
    S.audit(session, None, "battle_cancel", battle=b.id, reason=reason)
    return True


def revenge_options(session, uid, now=None):
    now = now or utcnow()
    since = now - datetime.timedelta(hours=cf(session, "war_revenge_hours", 24))
    rows = session.query(W.WarBattle).filter(
        W.WarBattle.defender_id == uid, W.WarBattle.status == "resolved", W.WarBattle.outcome.in_(("attacker", "draw")),
        W.WarBattle.resolved_at >= since, W.WarBattle.clan_war_id.is_(None)).order_by(W.WarBattle.resolved_at.desc()).limit(10).all()
    out = []
    for b in rows:
        if session.query(W.WarBattle).filter_by(revenge_of=b.id).first():
            continue
        out.append(b)
    return out


# ---------------------------------------------------------------------------
# گزارش
# ---------------------------------------------------------------------------

def _loss_lines(session, units_res, defs):
    lines = []
    for k, v in units_res.items():
        d = defs.get(k)
        if not d:
            continue
        parts = []
        if v["x"]:
            parts.append(f"🔴×{v['x']}")
        if v["d"]:
            parts.append(f"🟡×{v['d']}")
        if parts:
            lines.append(f"  {d.emoji} {d.name}: {' '.join(parts)}")
    return lines


def report_text(session, b, full=False, viewer=None) -> str:
    from war_text import fmt, stars as star_s
    res = json.loads(b.result_json or "{}")
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    an, dn = res.get("atk_name", name_of(session, b.attacker_id)), res.get("def_name", name_of(session, b.defender_id))
    if b.status != "resolved":
        return f"🛰 عملیات #{b.id} هنوز در جریانه؛ نتیجه بعد از پایان اعلام می‌شه."
    win = {"attacker": an, "defender": dn}.get(b.outcome, "—")
    head = ["⚔️ نتیجه‌ی نبرد", f"#{b.id} | {an} ➜ {dn}", f"🏆 برنده: {win}" if b.outcome != "draw" else "🤝 مساوی",
            f"{star_s(b.stars)}  💥 تخریب: {b.destruction:.0f}%"]
    if res.get("crushing"):
        head.append("💀 پیروزی کوبنده!")
    head.append(f"💰 غنیمت: {fmt(b.loot_hop)} | 🔩 {fmt(b.loot_mat)}")
    ra, rd = res.get("rew_atk") or {}, res.get("rew_def") or {}
    if viewer is None or viewer == b.attacker_id:
        head.append(f"⭐ XP: {fmt(ra.get('xp', 0))} | 💠 هاپ: {fmt(ra.get('hop', 0))}")
    if viewer == b.defender_id:
        head.append(f"⭐ XP: {fmt(rd.get('xp', 0))} | 💠 غرامت/پاداش: {fmt(rd.get('hop', 0))}")
    if not full:
        return "\n".join(head)
    body = ["", "💥 خسارت‌ها:", f"{an}:"] + (_loss_lines(session, res.get("atk_units", {}), defs) or ["  —"]) + \
           [f"{dn}:"] + (_loss_lines(session, res.get("def_units", {}), defs) or ["  —"])
    body += ["", "🔥 Readiness:", f"  {an}: {res['readiness_atk'][0]}% ← {res['readiness_atk'][1]}%" if "readiness_atk" in res else "",
             f"  {dn}: {res['readiness_def'][0]}% ← {res['readiness_def'][1]}%" if "readiness_def" in res else ""]
    if res.get("trophies_atk") or res.get("trophies_def"):
        body.append(f"🏅 کاپ: {an} {res.get('trophies_atk', 0):+d} | {dn} {res.get('trophies_def', 0):+d}")
    if res.get("shield_hours"):
        body.append(f"🛡 شیلدِ مدافع: {res['shield_hours']:g} ساعت")
    if res.get("farm_mult", 1) < 1:
        body.append(f"♻️ ضدِ فارم: پاداش‌ها ×{res['farm_mult']:g}")
    body += ["", "📖 روایتِ نبرد:"] + E.story(res, an, dn, {}) + ["", f"🧮 فرمولِ نبرد: v{b.formula_version}"]
    return "\n".join(head + body)
