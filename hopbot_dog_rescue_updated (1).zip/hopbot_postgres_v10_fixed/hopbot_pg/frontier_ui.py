# -*- coding: utf-8 -*-
"""
🌌 FRONTIER — رابط تلگرام. فقط Request رو می‌گیره و به frontier_svc می‌ده.
- همه‌ی callback ها: fr:<action>:<owner_id>:<arg...> ؛ owner باید همون کلیک‌کننده باشه.
- تا حد امکان همون پیام ادیت می‌شه (handlers.send_response).
- اقدام‌های مهم (اعزام/حمله به باس) صفحه‌ی تأیید با توکنِ یک‌بارمصرف دارن (war_ui.make_token / consume_token).
- هیچ مقدارِ حساسی (پاداش/قدرت/شناسه) از callback خونده نمی‌شه؛ فقط کلیدهای مرحله/مسیر/درصد و همه‌چیز سمتِ سرور دوباره اعتبارسنجی می‌شه.
"""
import json
import logging
import time

from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb

import db
import war_db as W
import war_svc as S
import war_battle as B
import war_clan as C
import war_ui as UI
import frontier_db as F
import frontier_engine as FE
import frontier_svc as FS
from war_svc import WarError, cf, ci
from war_text import fmt, short, dur, bar

logger = logging.getLogger(__name__)

RARITY = {"common": "⚪️ معمولی", "rare": "🔵 کمیاب", "epic": "🟣 حماسی", "legendary": "🟠 افسانه‌ای", "mythic": "🔴 اسطوره‌ای"}
KIND_LABEL = {"scout": "🧭 شناسایی", "operation": "⚔️ عملیات", "elite": "💠 عملیاتِ پیشرفته", "secret": "🗝 منطقه‌ی مخفی", "boss": "🐉 نگهبان"}
STATE_ICON = {"cleared": "✅", "open": "🔓", "locked": "🔒", "hidden": "❔"}
SLOGAN = "«هر سرزمینی که فتح می‌کنی، رازی را آشکار می‌کند که ارزش جنگیدن دارد.»"
_LAST = {}


def cb(action, owner, *args):
    return ":".join(["fr", action, str(owner)] + [str(a) for a in args])


def B_(text, action, owner, *args):
    return Btn(text, callback_data=cb(action, owner, *args))


def back(owner, to="home"):
    return [B_("🔙 بازگشت", to, owner)]


def diff_stars(n):
    return "⭐" * max(1, min(5, int(n)))


def fmt_left(delta_seconds):
    return dur(delta_seconds)


# ---------------------------------------------------------------------------
# پنل‌ها: هر تابع (text, rows)
# ---------------------------------------------------------------------------

def _season_line(session):
    s = FS.current_season(session)
    if not s:
        return "📅 فصل: —"
    left = (s.end_at - FS.utcnow()).total_seconds()
    return f"📅 {s.name} | ⏳ {fmt_left(left)} مانده"


def _clan_line(session, p, season):
    if not p.clan_id:
        return "🏰 بدونِ قبیله — اکتشافِ شخصی فعاله؛ برای باس‌های گروهی به یه قبیله بپیوند."
    cl = session.get(W.WarClan, p.clan_id)
    rk, row = FS.my_rank(session, season, p.clan_id) if season else (None, None)
    extra = f" | رتبه‌ی {rk} ({row.bracket})" if rk else ""
    return f"🏰 {cl.name} [{cl.tag}]{extra}"


def p_home(session, p, **kw):
    uid = p.user_id
    st = S.feature_state(session, p, "frontier")
    if st != "unlocked":
        r = S.feature_rule(session, "frontier")
        miss = S.feature_missing(session, p, "frontier")
        txt = ["🌌 مرزهای هاپویی", SLOGAN, "", "🔒 این بخش هنوز قفله.", f"شرط: {miss}" if miss else ""]
        if r and r.hint:
            txt.append(f"❓ {r.hint}")
        return "\n".join(x for x in txt if x is not None), [[B_("🔒 مناطقِ قفل‌شده", "locked", uid)], [B_("⚔️ اتاق جنگ", "war", uid)]]
    welcome = FS.welcome(session, p)
    new_regions = FS.pop_region_unlocks(session, p)
    season = FS.current_season(session)
    S.sync_player(session, p)
    fmax = cf(session, "war_fuel_max", 10)
    rows_map = FS.map_view(session, p)
    done = sum(1 for r in rows_map if r["complete"])
    openn = sum(1 for r in rows_map if r["req"]["open"])
    lines = ["🌌 مرزهای هاپویی", SLOGAN, ""]
    if welcome:
        lines += [f"🎁 هدیه‌ی ورود: +{fmt(welcome.get('hop', 0))} هاپ | ⭐ +{welcome.get('xp', 0):.0f} XP | ⛽ سوخت پر شد!", ""]
    for r in new_regions:
        if r.unlock_story and r.key != "plains":
            lines += [r.unlock_story, ""]
    lines += [_season_line(session), f"🗺 مناطق: {done}/{len(rows_map)} کامل | {openn} باز", f"⛽ سوخت {p.fuel:.1f}/{fmax:.0f} | 🔥 آمادگی {p.readiness:.0f}%",
              _clan_line(session, p, season)]
    runs = FS.active_runs(session, uid)
    if runs:
        lines.append(f"🛰 عملیاتِ فعال: {len(runs)}/{FS.max_runs(session, p)}")
    mods = FS.event_mods(session)
    if mods["names"]:
        lines.append("🎉 " + " | ".join(mods["names"]))
    pio = FS.pioneer_state(session, p)
    ready = [n for n, s_, _d in pio if s_ == "ready"]
    if ready:
        lines.append("🚩 پاداشِ پیشگامی آماده‌ست! (🎁 جوایز)")
    rows = [[B_("🌌 نقشه جهان", "map", uid), B_("🧭 اکتشاف", "explore", uid)],
            [B_("⚔️ عملیات من", "ops", uid), B_("🐉 باس منطقه", "boss", uid)],
            [B_("🏰 پیشرفت قبیله", "clan", uid), B_("🏆 جدول جهانی", "board", uid)],
            [B_("🎖 افتخارات من", "honors", uid), B_("📜 داستان و اطلاعات", "lore", uid)],
            [B_("🔒 مناطق قفل‌شده", "locked", uid), B_("🎁 جوایز" + (" 🔔" if ready else ""), "rewards", uid)],
            [B_("⚔️ اتاق جنگ", "war", uid)]]
    return "\n".join(lines), rows


def p_map(session, p, **kw):
    uid = p.user_id
    lines = ["🌌 نقشه‌ی مرزهای هاپویی", ""]
    rows = []
    for r in FS.map_view(session, p):
        reg = r["region"]
        if r["req"]["open"]:
            v = r["view"]
            icon = "✅" if r["complete"] else "🔓"
            boss = FS.boss_def_for_node(session, FS._boss_node_of_region(session, reg.key).key) if FS._boss_node_of_region(session, reg.key) else None
            bs = "—"
            if boss:
                stt = session.query(F.FrontierBossState).filter_by(boss_key=boss.key, scope=FS.boss_scope(p)[0], scope_id=FS.boss_scope(p)[1], event_id=0).first()
                bs = "💀 شکست‌خورده" if stt and stt.status == "defeated" else (f"🐉 HP {int(100 * stt.hp / stt.hp_max)}٪" if stt else "🐉 دست‌نخورده")
            lines.append(f"{icon} {reg.emoji} {reg.name}")
            lines.append(f"   {bar(v['pct'], 8)} {v['pct']}٪ ({v['done']}/{v['total']}) | {bs}")
            rooms = len([n for n in v["all"] if n["node"].hidden and n["state"] != "hidden"])
            lines.append(f"   🗝 اتاق‌های کشف‌شده: {rooms} | 🔎 سرنخ: {FS.clue_count(session, uid, reg.key)}")
            rows.append([B_(f"{reg.emoji} {reg.name}", "region", uid, reg.key)])
        else:
            lines.append(f"🔒 {reg.emoji} {reg.name}")
            miss = [t for t, ok in r["req"]["base"] + (r["req"]["personal"] if not p.clan_id else r["req"]["personal"]) if not ok]
            if miss:
                lines.append("   برای ورود: " + "، ".join(miss[:3]))
    rows.append(back(uid))
    return "\n".join(lines), rows


def _node_line(session, p, x):
    n, st = x["node"], x["state"]
    stars_ = f" {'⭐' * x['prog'].best_stars}" if x["prog"] and x["prog"].best_stars else ""
    suffix = f" — {x['missing']}" if st == "locked" and x["missing"] else ""
    return f"{STATE_ICON[st]} {KIND_LABEL.get(n.kind, '')[:2]} {n.name}{stars_}{suffix}"


def p_region(session, p, key=None, **kw):
    uid = p.user_id
    reg = FS.region_of(session, key)
    if not reg:
        raise WarError("منطقه پیدا نشد.")
    v = FS.region_view(session, p, reg)
    if not v["req"]["open"]:
        return p_locked(session, p)
    lines = [f"{reg.emoji} {reg.name} ({reg.name_en})", "", (reg.story or "").split("||")[0], "",
             f"{bar(v['pct'], 10)} {v['pct']}٪ ({v['done']}/{v['total']})", "", "📍 مراحل:"]
    rows = []
    mods = FS.event_mods(session, reg.key)
    for x in v["nodes"]:
        lines.append(_node_line(session, p, x))
        if x["state"] in ("open", "cleared") and x["node"].kind != "boss":
            rows.append([B_(f"{STATE_ICON[x['state']]} {x['node'].name}", "node", uid, x["node"].key)])
    boss_node = FS._boss_node_of_region(session, reg.key)
    if boss_node:
        st_, miss = FS.node_state(session, p, boss_node, FS.progress_map(session, uid), set(), True, set())
        bd = FS.boss_def_for_node(session, boss_node.key)
        if bd:
            lines.append(f"{'🔓' if not miss else '🔒'} {bd.emoji} {bd.name}" + (f" — {miss}" if miss else ""))
            rows.append([B_(f"{bd.emoji} {bd.name}", "bossview", uid, bd.key)])
    sig = FS.pending_signals(session, p, reg.key)
    rooms_tot = len([n for n in FS.nodes_in(session, reg.key) if n.hidden])
    rooms_found = len([1 for n in FS.nodes_in(session, reg.key) if n.hidden and FS.has_room(session, uid, n.key)])
    lines += ["", f"🗝 اتاق‌های مخفی: {rooms_found}/{rooms_tot} | 🔎 سرنخ: {FS.clue_count(session, uid, reg.key)}"]
    if sig:
        lines.append("🔍 سیگنالی عجیب شناسایی شد! (بررسی کن)")
        for n, _i in sig:
            rows.append([B_("🔍 سیگنالِ مشکوک", "signal", uid, n.key)])
    if mods["names"]:
        lines.append("🎉 " + " | ".join(mods["names"]))
    rows.append([B_("📜 داستان", "lore", uid, reg.key), B_("🌌 نقشه", "map", uid)])
    rows.append(back(uid))
    return "\n".join(lines), rows


def _reward_preview(session, p, trigger, region):
    rule = session.get(W.WarRewardRule, trigger)
    if not rule:
        return ""
    mods = FS.event_mods(session, region.key)
    ref = S.player_ref(session, p)
    hop = rule.hop_ref_hours * ref * region.reward_scale * mods["reward"]
    xp = rule.xp * region.reward_scale * mods["xp"]
    return f"≈ {short(hop)} هاپ | ⭐ {xp:.0f} XP" + (f" | 🔩 {rule.materials * region.reward_scale:.0f}" if rule.materials else "")


def p_node(session, p, key=None, **kw):
    uid = p.user_id
    n = session.get(F.FrontierNode, key)
    if not n:
        raise WarError("مرحله پیدا نشد.")
    reg = FS.region_of(session, n.region_key)
    prog = FS.progress_map(session, uid)
    rooms = {d.key[5:] for d in FS.discovered(session, uid, "room")}
    req = FS.region_requirements(session, p, reg)
    st, miss = FS.node_state(session, p, n, prog, rooms, req["open"], FS.treasure_open_nodes(session))
    if st == "hidden":
        raise WarError("🔒 این مرحله هنوز کشف نشده.")
    pr = prog.get(n.key)
    comp = FS.preset_comp(session, uid, 100)
    ratio = FS.estimate(session, p, comp, n, "assault") if comp else 0.0
    cost = round(n.cost_ref_hours * S.player_ref(session, p), -1)
    lines = [f"{KIND_LABEL.get(n.kind, '')} {n.name}", f"📍 {reg.name}", "", n.story, "",
             f"🎯 سختی: {diff_stars(n.difficulty)} | 👹 دشمن: {n.enemy_name or '—'}",
             f"⚖️ ارزیابی با کلِ ارتش: {FE.power_tier_label(ratio) if comp else '— (نیرو نداری)'}",
             f"⛽ {n.fuel:g} | 💰 {short(cost)} | ⏱ {fmt_left(n.min_seconds)}–{fmt_left(n.max_seconds)}",
             f"🏳️ امتیازِ فتح: {n.points}"]
    first = "اولین کلیر: " + _reward_preview(session, p, n.reward_trigger, reg)
    lines.append(first if not (pr and pr.clears) else f"✅ {pr.clears} بار کلیر | بهترین: {'⭐' * (pr.best_stars or 0)}")
    rows = []
    if st in ("open", "cleared"):
        rows.append([B_("🚀 انتخابِ مسیر عملیات", "route", uid, n.key)])
    else:
        lines.append(f"🔒 شرط: {miss}")
    rows.append(back(uid, "explore") if False else [B_("🔙 بازگشت", "region", uid, n.region_key)])
    return "\n".join(lines), rows


def _route_text(rc, mat):
    parts = [f"قدرت ×{rc['atk']:g}", f"تلفات ×{rc['cas']:g}", f"امتیازِ فتح ×{rc['pts']:g}", f"زمان ×{rc['dur']:g}"]
    if rc["clue"]:
        parts.append(f"🔎 {rc['clue']:g}٪ سرنخ")
    if rc["pen"]:
        parts.append(f"دفاعِ دشمن تا {rc['pen'] * 100:.0f}٪ کمتر با ترکیبِ هوایی/ویژه")
    if rc["mat"]:
        parts.append(f"🔩 مصرفِ مواد ×{rc['mat']:g}")
    return " | ".join(parts)


def p_route(session, p, key=None, boss=False, event=0, **kw):
    uid = p.user_id
    rc = FS.routes_cfg(session)
    if boss:
        bd = session.get(F.FrontierBossDef, key)
        title, back_to, back_arg = f"{bd.emoji} {bd.name}", "bossview", bd.key
        nref = None
        lines = [f"{title}", "", "مسیرِ حمله به باس رو انتخاب کن:", ""]
    else:
        n = session.get(F.FrontierNode, key)
        nref = n
        lines = [f"{KIND_LABEL.get(n.kind, '')} {n.name}", "", "مسیرِ عملیات رو انتخاب کن:", ""]
        back_to, back_arg = "node", n.key
    comp = FS.preset_comp(session, uid, 100)
    rows = []
    for rk in FE.ROUTE_KEYS:
        r = rc[rk]
        if not boss and rk not in (nref.routes or "").split(","):
            continue
        lab = ""
        if nref is not None and comp:
            lab = " — " + FE.power_tier_label(FS.estimate(session, p, comp, nref, rk))
        lines.append(f"{r['emoji']} {r['name']}{lab}\n   {_route_text(r, r['mat'])}")
        rows.append([B_(f"{r['emoji']} {r['name']}", "army", uid, key, rk, 1 if boss else 0, event)])
    if boss:
        lines += ["", "💥 مستقیم: بیشترین آسیب | 🥷 نفوذ: نقطه‌ضعفِ فاز رو بهتر می‌زنه، تلفاتِ کمتر | 📦 لجستیک: آسیب نمی‌زنه ولی قدرتِ حمله‌ی بعدیِ قبیله بالا می‌ره"]
    rows.append([B_("🔙 بازگشت", back_to, uid, back_arg)])
    return "\n".join(lines), rows


def _army_lines(session, uid, comp):
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    return "، ".join(f"{defs[k].emoji}{defs[k].name} ×{n}" for k, n in comp.items() if k in defs) or "—"


MODE_LABEL = {"all": "همه", "air": "🛩 فقط هوایی/موشکی", "ground": "🪖 فقط زمینی/زره/دریایی"}


def p_army(session, p, key=None, route=None, boss=0, event=0, mode="all", **kw):
    uid = p.user_id
    boss, event = int(boss), int(event)
    mode = mode if mode in FS.MODE_CATS else "all"
    full = FS.preset_comp(session, uid, 100, mode=mode)
    if not full:
        raise WarError("نیروی سالمِ تهاجمی نداری؛ از «تجهیزات» بساز/تعمیر کن.")
    lines = [f"🪖 چه مقدار از نیروها اعزام بشن؟ ({MODE_LABEL[mode]})", f"موجودیِ سالم: {_army_lines(session, uid, full)}", ""]
    nref = None if boss else session.get(F.FrontierNode, key)
    rows = []
    for pct in (25, 50, 75, 100):
        comp = FS.preset_comp(session, uid, pct, mode=mode)
        if not comp:
            continue
        lab = f"{pct}٪ ({sum(comp.values())} واحد)"
        if nref is not None:
            lab += " " + FE.power_tier_label(FS.estimate(session, p, comp, nref, route))[:2]
        rows.append([B_(lab, "confirm", uid, key, route, pct, boss, event, mode)])
    other = [m for m in ("all", "air", "ground") if m != mode and FS.preset_comp(session, uid, 100, mode=m)]
    if other:
        lines.append("🎛 تمرکزِ ارتش رو عوض کن (مثلاً نیروهای هوایی برای نفوذ یا ضعفِ باس):")
        rows.append([B_(MODE_LABEL[m], "army", uid, key, route, boss, event, m) for m in other])
    rows.append([B_("🔙 بازگشت", "route", uid, key, boss, event)])
    return "\n".join(lines), rows


def p_confirm(session, p, key=None, route=None, pct=100, boss=0, event=0, mode="all", **kw):
    uid = p.user_id
    pct, boss, event = int(pct), int(boss), int(event)
    mode = mode if mode in FS.MODE_CATS else "all"
    comp = FS.preset_comp(session, uid, pct, mode=mode)
    if not comp:
        raise WarError("با این انتخاب نیرویی برای اعزام نیست.")
    rc = FS.routes_cfg(session)[route]
    if boss:
        bd = session.get(F.FrontierBossDef, key)
        title = f"{bd.emoji} {bd.name}"
        fuel, cost_h, lo, hi = 2.0, 0.12, 600, 900
        cost = round(cost_h * S.player_ref(session, p), -1)
    else:
        n = session.get(F.FrontierNode, key)
        title = n.name
        fuel, lo, hi = n.fuel, n.min_seconds, n.max_seconds
        cost = round(n.cost_ref_hours * S.player_ref(session, p), -1)
    tok = UI.make_token(session, uid, "fr_launch", {"key": key, "route": route, "pct": pct, "boss": boss, "event": event, "mode": mode})
    lines = [f"🚀 تأییدِ اعزام: {title}", f"مسیر: {rc['emoji']} {rc['name']}", f"نیروها: {_army_lines(session, uid, comp)}",
             f"⛽ {fuel:g} | 💰 {fmt(cost)} | ⏱ ≈ {fmt_left(lo * rc['dur'])}–{fmt_left(hi * rc['dur'])}",
             "", "بعد از شروع، نیروها تا پایانِ عملیات درگیرن و نتیجه خودکار (حتی اگه ربات ری‌استارت شه) اعلام می‌شه."]
    rows = [[B_("✅ آغازِ عملیات", "go", uid, tok)], [B_("🔙 بازگشت", "army", uid, key, route, boss, event, mode)]]
    return "\n".join(lines), rows


def p_explore(session, p, **kw):
    """🧭 اکتشاف = بهترین منطقه‌ی بازِ ناتمام."""
    for r in FS.map_view(session, p):
        if r["req"]["open"] and not r["complete"]:
            return p_region(session, p, key=r["region"].key)
    rows = FS.map_view(session, p)
    for r in rows:
        if r["req"]["open"]:
            return p_region(session, p, key=r["region"].key)
    return p_locked(session, p)


def p_ops(session, p, **kw):
    uid = p.user_id
    runs = FS.active_runs(session, uid)
    lines = ["⚔️ عملیاتِ من", ""]
    cancel_rows = []
    now = FS.utcnow()
    for r in runs:
        nm = r.node_key
        node = session.get(F.FrontierNode, r.node_key)
        if node:
            nm = node.name
        elif r.node_key.startswith("event:"):
            bd = session.get(F.FrontierBossDef, r.node_key[6:])
            nm = bd.name if bd else nm
        span = max(1, (r.resolve_at - r.created_at).total_seconds())
        pct = min(99, (now - r.created_at).total_seconds() / span * 100)
        rc = FS.routes_cfg(session)[r.route]
        lines += [f"#{r.id} 🛰 {nm}", f"   {rc['emoji']} {rc['name']} | {bar(pct, 8)} {pct:.0f}٪ | ⏳ {fmt_left((r.resolve_at - now).total_seconds())}"]
        if r.status == "marching":
            cancel_rows.append([B_(f"🛑 لغوِ #{r.id} ({ci(session, 'frontier_cancel_refund_pct', 50)}٪ بازگشتِ هزینه)", "cancel", uid, r.id)])
    if not runs:
        lines.append("الان عملیاتِ فعالی نداری.")
    done = session.query(F.FrontierRun).filter(F.FrontierRun.user_id == uid, F.FrontierRun.status == "resolved") \
        .order_by(F.FrontierRun.id.desc()).limit(4).all()
    rows = []
    if done:
        lines += ["", "📜 آخرین نتایج:"]
        for r in done:
            node = session.get(F.FrontierNode, r.node_key)
            nm = node.name if node else r.node_key
            ic = {"win": "✅", "lose": "❌", "support": "📦", "void": "↩️"}.get(r.outcome, "▫️")
            lines.append(f"{ic} #{r.id} {nm}")
            rows.append([B_(f"📜 گزارشِ #{r.id}", "report", uid, r.id)])
    rows = cancel_rows + rows
    rows.append(back(uid))
    return "\n".join(lines), rows


def report_text(session, run) -> str:
    res = json.loads(run.result_json or "{}")
    node = session.get(F.FrontierNode, run.node_key)
    nm = node.name if node else run.node_key
    rc = FS.routes_cfg(session)[run.route]
    out = res.get("outcome")
    head = {"win": "🏆 عملیات موفق", "lose": "💥 عملیات ناموفق", "support": "📦 پشتیبانی انجام شد", "void": "↩️ عملیات لغو شد"}.get(out, "📜 گزارش")
    lines = [f"{head}", f"📍 {nm} | {rc['emoji']} {rc['name']}"]
    if res.get("kind") == "boss":
        if out != "void":
            lines.append(f"💥 آسیب به باس: {fmt(res.get('damage', 0))}")
            if res.get("hp_left") is not None:
                lines.append(f"🐉 HP باقی‌مانده: {fmt(res['hp_left'])} / {fmt(res['hp_max'])}")
            if res.get("phase_name"):
                lines.append(f"🌀 فاز: {res['phase_name']}")
    elif out in ("win", "lose"):
        lines.append(f"⭐ {res.get('stars', 0)} ستاره | تخریب {res.get('destruction', 0):.0f}٪")
    if res.get("lost") is not None and out != "void" and res.get("atk_units"):
        lines.append(f"🪖 تلفات: {res.get('lost', 0)}")
    rw = res.get("rewards") or {}
    if rw:
        lines.append(f"🎁 +{fmt(rw.get('hop', 0))} هاپ | ⭐ +{rw.get('xp', 0):.0f} XP" + (f" | 🔩 +{rw['mat']:.0f}" if rw.get("mat") else ""))
    if res.get("first_clear"):
        lines.append("🌟 اولین کلیر!")
    if res.get("points"):
        lines.append(f"🏳️ +{res['points']:.0f} امتیازِ فتح")
    lines += res.get("notes", [])
    if res.get("killed"):
        lines.append("💀 ضربه‌ی نهایی رو تو زدی!")
    for hk in res.get("honors", []):
        hd = session.get(F.FrontierHonorDef, hk)
        if hd:
            lines.append(f"🎖 افتخارِ جدید: {hd.emoji} {hd.name}")
    return "\n".join(lines)


def p_report(session, p, run_id=None, **kw):
    run = session.get(F.FrontierRun, int(run_id))
    if not run or run.user_id != p.user_id:
        raise WarError("گزارش پیدا نشد.")
    return report_text(session, run), [back(p.user_id, "ops")]


# ---------------------------- باس ----------------------------------------

def _boss_state_for(session, p, bd, event_id=0):
    scope, sid = FS.boss_scope(p)
    return session.query(F.FrontierBossState).filter_by(boss_key=bd.key, scope=scope, scope_id=sid, event_id=event_id).first()


def p_boss(session, p, **kw):
    uid = p.user_id
    lines = ["🐉 باس‌های منطقه", ""]
    rows = []
    for r in FS.map_view(session, p):
        if not r["req"]["open"]:
            continue
        bn = FS._boss_node_of_region(session, r["region"].key)
        bd = FS.boss_def_for_node(session, bn.key) if bn else None
        if not bd:
            continue
        st = _boss_state_for(session, p, bd)
        if st and st.status == "defeated":
            hp = "💀 شکست خورده"
        elif st:
            hp = f"{bar(100 * st.hp / st.hp_max, 8)} {int(100 * st.hp / st.hp_max)}٪"
        else:
            hp = "دست‌نخورده"
        lines.append(f"{bd.emoji} {bd.name} ({r['region'].name}) — {hp}")
        rows.append([B_(f"{bd.emoji} {bd.name}", "bossview", uid, bd.key)])
    for ev, bd in FS.awakened_bosses(session):
        lines.append(f"🔥 رویداد: {bd.emoji} {bd.name} (تا {fmt_left((ev.end_at - FS.utcnow()).total_seconds())})")
        rows.append([B_(f"🔥 {bd.emoji} {bd.name}", "bossview", uid, bd.key, ev.id)])
    if len(rows) == 0:
        lines.append("هنوز باسی در دسترس نیست؛ مرحله‌های منطقه رو کلیر کن.")
    rows.append(back(uid))
    return "\n".join(lines), rows


def p_bossview(session, p, key=None, event=0, **kw):
    uid = p.user_id
    event = int(event)
    bd = session.get(F.FrontierBossDef, key)
    if not bd or not bd.enabled:
        raise WarError("باس پیدا نشد.")
    scope = FS.boss_scope(p)[0]
    st = _boss_state_for(session, p, bd, event)
    hp_max = FS.boss_hp_for(session, bd, scope)
    hp = st.hp if st else hp_max
    phases = FS.boss_phases(bd)
    idx, ph = FE.phase_of(phases, hp, st.hp_max if st else hp_max)
    pct = 100 * hp / (st.hp_max if st else hp_max)
    lines = [f"{bd.emoji} {bd.name} ({bd.name_en})", f"{'👥 باسِ مشترکِ قبیله' if scope == 'clan' else '👤 نسخه‌ی شخصی (بدونِ قبیله — HP کمتر، پاداشِ کمتر)'}", "",
             f"سلامتی:\n{bar(pct, 12)} {pct:.0f}٪", f"HP: {fmt(hp)} / {fmt(st.hp_max if st else hp_max)}", "",
             f"🌀 فازِ {idx + 1}/{len(phases)}: {ph.get('name', '')}", f"   {ph.get('note', '')}"]
    res = FS.boss_resist(bd)
    strong = [k for k, v in res.items() if v < 1.0]
    weak = [k for k, v in res.items() if v > 1.0]
    if ph.get("weak"):
        weak = list(dict.fromkeys([ph["weak"]] + weak))
    names = {"ground": "زمینی", "armor": "زره‌ی سنگین", "air": "هوایی", "missile": "موشکی", "naval": "دریایی", "special": "ویژه"}
    if strong:
        lines.append("🛡 مقاوم در برابر: " + "، ".join(names.get(k, k) for k in strong))
    if weak:
        lines.append("🎯 آسیب‌پذیر: " + "، ".join(names.get(k, k) for k in weak))
    if bd.skill:
        lines.append(f"☠️ مهارتِ ویژه: {bd.skill}")
    rows = []
    if st:
        top = FS.boss_top(session, st.id, 5)
        if top:
            lines += ["", "👥 مشارکت:"]
            for i, (u, d, c) in enumerate(top, 1):
                lines.append(f"{i}. {B.name_of(session, u)}: {fmt(d)} ({c} حمله)")
        mine = session.query(F.FrontierBossAttack).filter_by(state_id=st.id, user_id=uid).count()
        lines.append(f"\nحمله‌های من: {mine}")
    day = FS.daily_row(session, uid)
    left = max(0, ci(session, "frontier_boss_attacks_daily", 8) - (day.boss_attacks or 0))
    lines.append(f"🗡 حمله‌ی امروز: {left} باقی‌مانده")
    if st and st.status != "active":
        lines.append("🏁 این باس شکست خورده است.")
    else:
        rows.append([B_("🗡 حمله به باس", "route", uid, bd.key, 1, event)])
    rows.append(back(uid, "boss"))
    return "\n".join(lines), rows


# ---------------------------- قبیله / جدول ---------------------------------

def p_clan(session, p, **kw):
    uid = p.user_id
    season = FS.current_season(session)
    if not p.clan_id:
        lines = ["🏰 پیشرفتِ قبیله", "", "هنوز عضوِ قبیله‌ای نیستی.", "• اکتشافِ شخصی همه‌جا کار می‌کنه.",
                 "• باس‌های گروهی (HP مشترک)، رقابتِ فصلی و مأموریت‌های قبیله‌ای با پیوستن به قبیله فعال می‌شن."]
        return "\n".join(lines), [[B_("🏰 قبیله‌ها (اتاق جنگ)", "warclan", uid)], back(uid)]
    cl = session.get(W.WarClan, p.clan_id)
    lines = [f"🏰 {cl.name} [{cl.tag}]", f"👥 {C.member_count(session, cl.id)} عضو", ""]
    rk, row = FS.my_rank(session, season, cl.id) if season else (None, None)
    if row:
        lines += [f"🏆 رتبه‌ی {rk} در لیگِ «{ {'small': 'کوچک', 'medium': 'متوسط', 'large': 'بزرگ'}.get(row.bracket, row.bracket)}»",
                  f"امتیازِ فصل: {row.total:,.0f} | باس‌ها: {row.boss_kills} | اعضای فعال: {row.active_members}/{row.members_n}"]
    else:
        lines.append("📊 هنوز امتیازی در این فصل ثبت نشده.")
    lines.append("")
    for r in FS.regions(session):
        cr = FS.clan_region_row(session, cl.id, r.key)
        if cr and (cr.points or cr.boss_down):
            lines.append(f"{r.emoji} {r.name}: {int(cr.points)} امتیاز {'| 💀 باس شکست خورده' if cr.boss_down else ''}")
    if season:
        top = session.query(F.FrontierContribution).filter_by(season_id=season.id, clan_id=cl.id).order_by(F.FrontierContribution.points.desc()).limit(5).all()
        if top:
            lines += ["", "🌟 برترین‌های فصل:"]
            for i, c in enumerate(top, 1):
                lines.append(f"{i}. {B.name_of(session, c.user_id)} — {c.points:,.0f} امتیاز | {c.runs} عملیات")
    mine = session.query(F.FrontierContribution).filter_by(season_id=season.id if season else 0, user_id=uid, clan_id=cl.id).first()
    if mine:
        lines.append(f"\nمشارکتِ من: {mine.points:,.0f} امتیاز | {mine.runs} عملیات | {fmt(mine.boss_damage)} آسیب")
    buffs = [b for b in FS.active_buffs(session, uid, p.clan_id) if b.scope == "clan"]
    for b in buffs:
        lines.append(f"📦 باسِ لجستیک: +{b.pct:g}٪ قدرتِ حمله ({b.charges} شارژ)")
    return "\n".join(lines), [[B_("🏆 جدول جهانی", "board", uid)], back(uid)]


def p_board(session, p, bracket="all", **kw):
    uid = p.user_id
    season = FS.current_season(session)
    if not season:
        return "🏆 فصلی فعال نیست.", [back(uid)]
    br = None if bracket == "all" else bracket
    rows_db = FS.leaderboard(session, season, br, limit=10)
    names = {"all": "کلی", "small": "کوچک", "medium": "متوسط", "large": "بزرگ"}
    lines = [f"🏆 جدول جهانیِ Frontier — {season.name}", f"⏳ {fmt_left((season.end_at - FS.utcnow()).total_seconds())} تا پایانِ فصل | لیگ: {names.get(bracket, bracket)}",
             "(امتیاز = فعالیتِ سقف‌دار ÷ اندازه‌ی قبیله + باس + کشف + مشارکتِ همه‌ی اعضا)", ""]
    medals = ["🥇", "🥈", "🥉"]
    for i, r in enumerate(rows_db, 1):
        cl = session.get(W.WarClan, r.clan_id)
        mark = " ◀️ شما" if p.clan_id == r.clan_id else ""
        lines.append(f"{medals[i - 1] if i <= 3 else str(i) + '.'} {cl.name if cl else '?'} [{cl.tag if cl else ''}] — {r.total:,.0f} ({r.active_members}/{r.members_n} فعال){mark}")
    if not rows_db:
        lines.append("هنوز قبیله‌ای امتیاز نگرفته؛ اولین باش!")
    if p.clan_id:
        rk, row = FS.my_rank(session, season, p.clan_id, br)
        if rk and rk > 10:
            lines.append(f"…\n{rk}. قبیله‌ی شما — {row.total:,.0f}")
    hall = FS.hall_of_fame(session, 3)
    if hall:
        lines += ["", "🏛 تالارِ افتخارات:"] + [f"{h.season_name}: {medals[h.rank - 1]} {h.clan_name} [{h.clan_tag}]" for h in hall]
    rows = [[B_("کلی", "board", uid, "all"), B_("کوچک", "board", uid, "small"), B_("متوسط", "board", uid, "medium"), B_("بزرگ", "board", uid, "large")], back(uid)]
    return "\n".join(lines), rows


def p_honors(session, p, **kw):
    uid = p.user_id
    owned = {h.key: h for h, _d in FS.honors_of(session, uid)}
    lines = ["🎖 افتخاراتِ من", ""]
    vals = FS.honor_values(session, uid)
    for hd in session.query(F.FrontierHonorDef).filter_by(enabled=True).order_by(F.FrontierHonorDef.sort).all():
        if hd.key in owned:
            lines.append(f"{hd.emoji} {hd.name} — {RARITY.get(hd.rarity, hd.rarity)}" + (f" | 🏷 {hd.title}" if hd.title else "") +
                         f"\n   ✅ {owned[hd.key].earned_at:%Y-%m-%d}: {hd.description}")
        else:
            v = min(vals.get(hd.metric, 0), hd.threshold)
            lines.append(f"▫️ ❔ {hd.name} — {RARITY.get(hd.rarity, hd.rarity)}\n   {hd.description} ({v}/{hd.threshold})")
    return "\n".join(lines)[:3900], [back(uid)]


def p_lore(session, p, key=None, page=0, **kw):
    uid = p.user_id
    page = int(page or 0)
    if not key:
        lines = ["📜 داستان و اطلاعات", "", "کدوم سرزمین؟"]
        rows = []
        for r in FS.map_view(session, p):
            if r["req"]["open"]:
                rows.append([B_(f"{r['region'].emoji} {r['region'].name}", "lore", uid, r["region"].key, 0)])
            else:
                lines.append(f"🔒 {r['region'].emoji} ؟؟؟ — {r['region'].hint or 'هنوز ناشناخته'}")
        rows.append(back(uid))
        return "\n".join(lines), rows
    reg = FS.region_of(session, key)
    if not reg or not FS.region_requirements(session, p, reg)["open"]:
        raise WarError("🔒 این سرزمین هنوز ناشناخته‌ست.")
    pages = [x.strip() for x in (reg.story or "").split("||") if x.strip()]
    page = max(0, min(page, max(0, len(pages) - 1)))
    lines = [f"{reg.emoji} {reg.name}", "", pages[page] if pages else "—", f"\n({page + 1}/{max(1, len(pages))})"]
    if page == len(pages) - 1:
        rooms = [n for n in FS.nodes_in(session, reg.key) if n.hidden and FS.has_room(session, uid, n.key)]
        if rooms:
            lines += ["", "🗝 اتاق‌های کشف‌شده: " + "، ".join(n.name for n in rooms)]
        lines.append(f"🔎 سرنخ‌ها: {FS.clue_count(session, uid, reg.key)}")
    nav = []
    if page > 0:
        nav.append(B_("◀️", "lore", uid, key, page - 1))
    if page < len(pages) - 1:
        nav.append(B_("▶️", "lore", uid, key, page + 1))
    rows = ([nav] if nav else []) + [[B_("📜 فهرست", "lore", uid)], back(uid)]
    return "\n".join(lines), rows


def p_locked(session, p, **kw):
    uid = p.user_id
    lines = ["🔒 مناطقِ قفل‌شده", ""]
    any_ = False
    for r in FS.regions(session):
        req = FS.region_requirements(session, p, r)
        if req["open"]:
            continue
        any_ = True
        lines.append(f"🔒 {r.emoji} {r.name}\nبرای ورود:")
        for t, ok in req["base"]:
            lines.append(f"  {'✅' if ok else '▫️'} {t}")
        if req["personal"] or req["clan"]:
            lines.append("  — مسیرِ شخصی —")
            for t, ok in req["personal"]:
                lines.append(f"  {'✅' if ok else '▫️'} {t}")
            if p.clan_id and req["clan"]:
                lines.append("  — یا مسیرِ قبیله —")
                for t, ok in req["clan"]:
                    lines.append(f"  {'✅' if ok else '▫️'} {t}")
            elif not p.clan_id and r.req_clan_points:
                lines.append("  (با قبیله هم می‌شه: شرط‌های گروهی)")
        lines.append("")
    if not any_:
        lines.append("همه‌ی مناطق برات بازه! 🌌")
    return "\n".join(lines), [back(uid)]


def p_rewards(session, p, **kw):
    uid = p.user_id
    lines = ["🎁 جوایز", ""]
    rows = []
    pio = FS.pioneer_state(session, p)
    if pio:
        lines.append("🚩 نردبانِ پیشگامی (۳ روزِ اول؛ هر روز حداقل یک عملیات انجام بده):")
        label = {"claimed": "✅ دریافت شد", "ready": "🎁 آماده", "today": "▫️ امروز یه عملیات انجام بده", "future": "⏳ بعداً", "missed": "❌ از دست رفت"}
        for n, st, d in pio:
            rule = session.get(W.WarRewardRule, f"fr_pioneer_{n}")
            val = f"≈ {short(rule.hop_ref_hours * S.player_ref(session, p))} هاپ | ⭐ {rule.xp:.0f}" if rule else ""
            lines.append(f"  روز {n}: {label[st]}  {val}")
            if st == "ready":
                rows.append([B_(f"🎁 دریافتِ روز {n}", "pio", uid, n)])
    lines.append("")
    lines.append("🎯 مأموریت‌های Frontier:")
    n_q = 0
    for kind, title in (("daily", "📅"), ("weekly", "🗓"), ("special", "✨")):
        for q, prog, claimed in S.quests_for(session, p, kind):
            if not q.metric.startswith("fr_"):
                continue
            if q.kind == "special" and claimed:
                continue
            n_q += 1
            mark = "✅" if claimed else ("🎁" if prog >= q.target else "▫️")
            lines.append(f"{mark} {title} {q.name} [{min(prog, q.target)}/{q.target}] ⭐{q.xp:g}" +
                         (f" 💠≈{short(q.hop_ref_hours * S.player_ref(session, p))}" if q.hop_ref_hours else ""))
            if prog >= q.target and not claimed:
                rows.append([B_(f"🎁 {q.name[:40]}", "qclaim", uid, q.key)])
    if not n_q:
        lines.append("—")
    recent = FS.recent_rewards(session, uid, 5)
    if recent:
        lines += ["", "🧾 آخرین پاداش‌ها:"]
        for c in recent:
            lines.append(f"  {c.trigger or c.claim_key}: +{fmt(c.hop)} هاپ | ⭐{c.xp:.0f}")
    rows.append(back(uid))
    return "\n".join(lines), rows


def p_signal(session, p, key=None, **kw):
    uid = p.user_id
    n = session.get(F.FrontierNode, key)
    if not n or not n.hidden:
        raise WarError("سیگنالی وجود نداره.")
    info = FS.signal_info(session, p, n)
    if info["found"]:
        raise WarError("این اتاق رو قبلاً کشف کردی.")
    lines = [n.signal_text or "🔍 سیگنالی عجیب!", "", f"🔎 سرنخ‌های تو: {info['clues']} (حداقل {info['need']})", "سه مسیر وجود داره؛ انتخابِ درست ورودیِ اتاق رو آشکار می‌کنه و انتخابِ غلط یه سرنخ رو می‌سوزونه."]
    if info["hint"] is not None:
        lines.append(f"🧭 ردپاها نشون می‌دن گزینه‌ی «{info['opts'][info['hint']]}» درست نیست." + (" (اطلاعاتِ مشترکِ قبیله)" if info["clan_hint"] else ""))
    elif info["clues"] < n.hint_clues:
        lines.append(f"💡 با {n.hint_clues} سرنخ (یا اطلاعاتِ مشترکِ قبیله) یکی از گزینه‌های غلط مشخص می‌شه.")
    if info["cooldown"] > 0:
        lines.append(f"⏳ تیمِ شناسایی تا {int(info['cooldown'] // 60) + 1} دقیقه‌ی دیگه برمی‌گرده.")
    rows = []
    if info["ready"] and info["cooldown"] <= 0:
        for i, o in enumerate(info["opts"]):
            if i == info["hint"]:
                continue
            rows.append([B_(o, "sig", uid, n.key, i)])
    rows.append([B_("🔙 بازگشت", "region", uid, n.region_key)])
    return "\n".join(lines), rows


PANELS = {"home": p_home, "map": p_map, "region": p_region, "node": p_node, "route": p_route, "army": p_army, "confirm": p_confirm,
          "explore": p_explore, "ops": p_ops, "report": p_report, "boss": p_boss, "bossview": p_bossview, "clan": p_clan,
          "board": p_board, "honors": p_honors, "lore": p_lore, "locked": p_locked, "rewards": p_rewards, "signal": p_signal}


def war_panel(session, context, update, p, page=0):
    """ورودی از war_ui (alias «مرزهای هاپویی» / Deep Link /start war_frontier)."""
    return p_home(session, p)


# ---------------------------------------------------------------------------
# مسیریابِ Callback
# ---------------------------------------------------------------------------

async def show(update, context, owner, panel, **kw):
    session = db.get_session()
    try:
        p = S.get_player(session, owner)
        S.sync_player(session, p)
        text, kb = PANELS[panel](session, p, **kw)
        session.commit()
    except WarError as e:
        session.rollback()
        text, kb = str(e), [[B_("🔙 مرزها", "home", owner)]]
    finally:
        session.close()
    if isinstance(kb, list):
        kb = Kb(kb)
    await UI.send(update, text, kb)


async def fr_callback_router(update, context):
    q = update.callback_query
    data = q.data or ""
    parts = data.split(":")
    if len(parts) < 3:
        await q.answer()
        return True
    action = parts[1]
    try:
        owner = int(parts[2])
    except ValueError:
        await q.answer()
        return True
    args = parts[3:]
    if update.effective_user.id != owner:
        await q.answer("🚫 این پنل مالِ شما نیست؛ دستورش رو خودت بنویس.", show_alert=True)
        return True
    now = time.time()
    if action in ("go", "sig", "pio", "qclaim", "cancel") and now - _LAST.get((owner, action), 0) < 0.8:
        await q.answer("⏳ یواش‌تر!")
        return True
    _LAST[(owner, action)] = now
    session = db.get_session()
    toast, nxt = None, None
    try:
        gate = UI.level_gate_error(session, owner)
        if gate:
            session.commit()
            await q.answer(gate[:190], show_alert=True)
            return True
        p = S.get_player(session, owner)
        S.sync_player(session, p)
        toast, nxt = await _act(session, context, update, p, action, args)
        session.commit()
    except WarError as e:
        session.rollback()
        await q.answer(str(e)[:190], show_alert=True)
        return True
    except Exception as e:  # noqa
        session.rollback()
        logger.exception("frontier callback failed: %s", data)
        msg = "⚠️ این عملیات با هم‌زمانی/خطا روبه‌رو شد؛ دوباره امتحان کن." if "UNIQUE" in str(e).upper() or "IntegrityError" in type(e).__name__ else "⚠️ خطای غیرمنتظره؛ دوباره امتحان کن."
        await q.answer(msg, show_alert=True)
        return True
    finally:
        session.close()
    if toast:
        try:
            await q.answer(toast[:190])
        except Exception:
            pass
    else:
        try:
            await q.answer()
        except Exception:
            pass
    if nxt:
        panel, kw = nxt if isinstance(nxt, tuple) else (nxt, {})
        await show(update, context, owner, panel, **kw)
    return True


async def _act(session, context, update, p, a, args):
    uid = p.user_id
    if a == "war":
        return None, None if await _open_war(update, context, uid) else None
    if a == "warclan":
        await _open_war(update, context, uid, "clan")
        return None, None
    if a not in ("home", "locked"):                 # فقط صفحه‌ی اصلی و «مناطق قفل‌شده» (نمایشِ شرط‌ها) برای قفل‌شده‌ها بازه
        FS.require_open(session, p)
    if a in PANELS and a not in ("route", "army", "confirm", "region", "node", "bossview", "report", "signal", "board", "lore"):
        return None, a
    if a in ("region", "node", "signal", "report"):
        key = args[0]
        return None, (a, {"key": key} if a != "report" else {"run_id": key})
    if a == "bossview":
        return None, ("bossview", {"key": args[0], "event": args[1] if len(args) > 1 else 0})
    if a == "board":
        return None, ("board", {"bracket": args[0] if args else "all"})
    if a == "lore":
        return None, ("lore", {"key": args[0] if args else None, "page": args[1] if len(args) > 1 else 0})
    if a == "route":
        key = args[0]
        boss = len(args) > 1 and args[1] == "1"
        return None, ("route", {"key": key, "boss": boss, "event": int(args[2]) if len(args) > 2 else 0})
    if a == "army":
        key, route, boss, event = args[0], args[1], args[2], args[3]
        mode = args[4] if len(args) > 4 else "all"
        if route not in FE.ROUTE_KEYS or mode not in FS.MODE_CATS:
            raise WarError("مسیرِ نامعتبر.")
        return None, ("army", {"key": key, "route": route, "boss": boss, "event": event, "mode": mode})
    if a == "confirm":
        key, route, pct, boss, event = args[0], args[1], args[2], args[3], args[4]
        mode = args[5] if len(args) > 5 else "all"
        if route not in FE.ROUTE_KEYS or int(pct) not in (25, 50, 75, 100) or mode not in FS.MODE_CATS:
            raise WarError("مقدارِ نامعتبر.")
        return None, ("confirm", {"key": key, "route": route, "pct": pct, "boss": boss, "event": event, "mode": mode})
    if a == "go":
        d = UI.consume_token(session, uid, args[0], "fr_launch")
        comp = FS.preset_comp(session, uid, int(d["pct"]), mode=d.get("mode", "all"))
        chat = update.effective_chat
        cid = chat.id if chat and chat.type != "private" else None
        if int(d.get("boss", 0)):
            run, cost = FS.launch_boss(session, p, d["key"], d["route"], comp, event_id=int(d.get("event", 0)), chat_id=cid)
        else:
            run, cost = FS.launch_run(session, p, d["key"], d["route"], comp, chat_id=cid)
        return f"🚀 عملیات #{run.id} آغاز شد (هزینه: {fmt(cost)})", "ops"
    if a == "cancel":
        FS.player_cancel(session, p, int(args[0]))
        return "🛑 عملیات لغو شد؛ نیروها برگشتن.", "ops"
    if a == "sig":
        res = FS.answer_signal(session, p, args[0], int(args[1]))
        if res["ok"]:
            return "🗝 اتاقِ مخفی کشف شد!", ("region", {"key": res["node"].region_key})
        return res["text"], ("signal", {"key": args[0]})
    if a == "pio":
        r = FS.claim_pioneer(session, p, int(args[0]))
        return f"🎁 +{fmt(r.get('hop', 0))} هاپ | ⭐ +{r.get('xp', 0):.0f}", "rewards"
    if a == "qclaim":
        qd = session.get(W.WarQuestDef, args[0])
        if not qd or not qd.metric.startswith("fr_"):
            raise WarError("مأموریت پیدا نشد.")
        q, r = S.claim_quest(session, p, args[0])
        return f"🎁 {q.name}: ⭐{r['xp']:g}" + (f" 💰{fmt(r['hop'])}" if r["hop"] else ""), "rewards"
    raise WarError("اقدامِ ناشناخته.")


async def _open_war(update, context, uid, panel="war_room"):
    await UI.show_panel(update, context, uid, panel)
    return True


# ---------------------------------------------------------------------------
# اعلان‌ها (از tick job)
# ---------------------------------------------------------------------------

async def notify(context, uid, text, rows=None):
    try:
        await context.bot.send_message(chat_id=uid, text=text[:3900], reply_markup=Kb(rows) if rows else None)
    except Exception:
        pass


async def frontier_tick_job(context):
    import asyncio
    events = await asyncio.to_thread(FS.run_tick)
    for ev in events:
        try:
            await _send_event(context, ev)
        except Exception:
            logger.exception("frontier notify failed")


async def _send_event(context, ev):
    t = ev.get("type")
    session = db.get_session()
    try:
        if t == "fr_run":
            run = session.get(F.FrontierRun, ev["run_id"])
            if not run:
                return
            txt = "🌌 Frontier\n" + report_text(session, run)
            await notify(context, run.user_id, txt, [[B_("🌌 مرزها", "home", run.user_id), B_("⚔️ عملیات من", "ops", run.user_id)]])
            if run.chat_id:
                try:
                    node = session.get(F.FrontierNode, run.node_key)
                    res = json.loads(run.result_json or "{}")
                    gtxt = (f"🌌 {B.name_of(session, run.user_id)} — {node.name if node else run.node_key}: "
                            f"{ {'win': '🏆 موفق', 'lose': '💥 ناموفق', 'support': '📦 پشتیبانی', 'void': '↩️ لغو'}.get(run.outcome, '') }")
                    if res.get("kind") == "boss" and res.get("damage"):
                        gtxt += f" | 💥 {short(res['damage'])}"
                    await context.bot.send_message(chat_id=run.chat_id, text=gtxt[:ci(session, "frontier_notify_group_chars", 500)])
                except Exception:
                    pass
        elif t == "fr_region_done":
            reg = FS.region_of(session, ev["region"])
            await notify(context, ev["user"], f"🌌 {reg.emoji} {reg.name} کامل شد!\n🎁 پاداشِ تکمیلِ منطقه به حسابت اومد.")
        elif t == "fr_boss_down":
            bd = session.get(F.FrontierBossDef, ev["boss"])
            targets = set(ev["participants"])
            members = []
            if ev["scope"] == "clan":
                members = [m.user_id for m in session.query(W.WarClanMember).filter_by(clan_id=ev["scope_id"]).all()]
            targets |= set(members)
            msg = f"🐉 {bd.emoji} {bd.name} شکست خورد!" + ("\n🏆 پاداشِ مشارکت‌کننده‌ها پرداخت شد." if not ev.get("event") else "")
            for u in targets:
                await notify(context, u, msg)
            if ev["scope"] == "clan":
                cl = session.get(W.WarClan, ev["scope_id"])
                if cl and cl.announce_chat_id:
                    try:
                        await context.bot.send_message(chat_id=cl.announce_chat_id, text=f"🐉 قبیله‌ی {cl.name} باسِ «{bd.name}» رو شکست داد! 🏆")
                    except Exception:
                        pass
            for u in list(targets):                      # بازشدنِ منطقه‌ی بعدی: پیامِ داستانی (فقط یک‌بار)
                try:
                    pl = S.get_player(session, u, create=False)
                    if not pl:
                        continue
                    for r in FS.pop_region_unlocks(session, pl):
                        if r.unlock_story:
                            await notify(context, u, r.unlock_story, [[B_("🌌 نقشه", "map", u)]])
                    session.commit()
                except Exception:
                    session.rollback()
        elif t == "fr_season_end":
            for u, hop, rank in ev["payouts"]:
                await notify(context, u, f"🏆 فصلِ Frontier «{ev['name']}» تموم شد!\n" + (f"قبیله‌ت رتبه‌ی {rank} شد 🎉\n" if rank else "پاداشِ مشارکت ✅\n") + f"💰 +{fmt(hop)} هاپ")
    finally:
        session.close()
