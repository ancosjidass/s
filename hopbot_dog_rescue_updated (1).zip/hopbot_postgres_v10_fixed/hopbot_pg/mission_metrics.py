# -*- coding: utf-8 -*-
"""
معیارهای مأموریت: همه از جدول‌های «موجودِ» بازی‌ها خونده می‌شن (بدونِ دست‌زدن به کدِ بازی‌ها).
هر معیار = تعدادِ رویدادهای یه بازیکن از زمانِ since تا الان. اگه جدولی (مثلا تو یه نصبِ قدیمی) نبود، ۰ برمی‌گردونه.
اضافه‌کردنِ معیارِ جدید = یه خط تو METRICS.
"""
import json
import logging

import datetime
from sqlalchemy import text

logger = logging.getLogger(__name__)


def _ts(since):
    """مقایسه‌ی زمان: روی SQLite رشته (مثلِ قبل)، روی PostgreSQL خودِ datetime (ستون‌ها timestamp‌ان)."""
    import db as _db
    if _db.IS_PG:
        return since if since else datetime.datetime(1970, 1, 1)
    return (since.strftime("%Y-%m-%d %H:%M:%S.%f") if since else "0000-00-00 00:00:00")


def _count(session, sql, uid, since):
    try:
        return int(session.execute(text(sql), {"u": uid, "s": _ts(since)}).scalar() or 0)
    except Exception as e:                                 # جدول/ستون نبود
        session.rollback()
        logger.warning("metric query failed: %s", e)
        return 0


def _sql(sql, metric=None):
    """live = ردیف‌هایِ هنوز پاک‌نشده؛ + شمارنده‌ی خلاصه‌ی ردیف‌هایی که db_purge قبلاً پاکشون کرده."""
    def f(session, uid, since):
        n = _count(session, sql, uid, since)
        if metric:
            n += _rolled(session, metric, uid, since)
        return n
    return f


def _rolled(session, metric, uid, since):
    try:
        import db_purge
        return db_purge.counter_sum(session, metric, uid, since)
    except Exception as e:
        session.rollback()
        logger.warning("rolled counter failed: %s", e)
        return 0


def _lottery(session, uid, since):
    try:
        rows = session.execute(text("SELECT participants_json FROM lottery_events WHERE created_at >= :s"), {"s": _ts(since)}).all()
    except Exception:
        session.rollback()
        return 0
    n = 0
    for (pj,) in rows:
        try:
            for p in json.loads(pj or "[]"):
                pid = p.get("id") if isinstance(p, dict) else p
                if str(pid) == str(uid):
                    n += 1
                    break
        except (ValueError, AttributeError):
            continue
    return n + _rolled(session, "lottery_joined", uid, since)


METRICS = {
    "casino_played": ("🎲 بازیِ کازینو (تاس/بلک‌جک/...)", _sql("SELECT COUNT(*) FROM casino_players WHERE user_id=:u AND joined_at>=:s", "casino_played")),
    "roulette_played": ("🔫 بازیِ رولت", _sql("SELECT COUNT(*) FROM roulette_players WHERE user_id=:u AND joined_at>=:s", "roulette_played")),
    "uno_played": ("🃏 بازیِ اونو", _sql("SELECT COUNT(*) FROM uno_players WHERE user_id=:u AND joined_at>=:s", "uno_played")),
    "mafia_played": ("🕴 بازیِ مافیا", _sql("SELECT COUNT(*) FROM mafia_players WHERE user_id=:u AND joined_at>=:s", "mafia_played")),
    "guess_played": ("🔢 بازیِ حدس عدد", _sql("SELECT COUNT(*) FROM guessnum_rounds WHERE (initiator_id=:u OR setter_id=:u OR guesser_id=:u) AND created_at>=:s AND status!='cancelled'", "guess_played")),
    "mind_played": ("🧠 ماستر‌مایند (تمام‌شده)", _sql("SELECT COUNT(*) FROM mastermind_rounds WHERE (player1_id=:u OR player2_id=:u) AND ended_at>=:s AND status='resolved'", "mind_played")),
    "ship_played": ("🚢 نبردِ دریایی (تمام‌شده)", _sql("SELECT COUNT(*) FROM battleship_rounds WHERE (player1_id=:u OR player2_id=:u) AND ended_at>=:s AND status='resolved'", "ship_played")),
    "duel_played": ("⚔️ دوئل (تمام‌شده)", _sql("SELECT COUNT(*) FROM duel_lobbies WHERE (host_id=:u OR guest_id=:u) AND winner_id IS NOT NULL AND ended_at>=:s", "duel_played")),
    "rob_attempts": ("🔫 حمله به بازیکنِ دیگه", _sql("SELECT COUNT(*) FROM attack_sessions WHERE attacker_id=:u AND created_at>=:s", "rob_attempts")),
    "smuggle_started": ("📦 شروعِ قاچاق", _sql("SELECT COUNT(*) FROM smuggling_operations WHERE user_id=:u AND started_at>=:s", "smuggle_started")),
    "smuggle_success": ("📦 قاچاقِ موفق", _sql("SELECT COUNT(*) FROM smuggling_operations WHERE user_id=:u AND status='success' AND ended_at>=:s", "smuggle_success")),
    "heist_played": ("🥷 شرکت در سرقتِ تیمی", _sql("SELECT COUNT(*) FROM heist_rewards WHERE user_id=:u AND created_at>=:s", "heist_played")),
    "heist_success": ("🥷 سرقتِ تیمیِ موفق", _sql("SELECT COUNT(*) FROM heist_rewards WHERE user_id=:u AND hop>0 AND created_at>=:s", "heist_success")),
    "war_attacks": ("⚔️ حمله در جنگ هاپویی", _sql("SELECT COUNT(*) FROM war_battles WHERE attacker_id=:u AND created_at>=:s", "war_attacks")),
    "war_wins": ("🏆 بردِ حمله در جنگ هاپویی", _sql("SELECT COUNT(*) FROM war_battles WHERE attacker_id=:u AND outcome='attacker' AND created_at>=:s", "war_wins")),
    "frontier_runs": ("🌌 عملیاتِ Frontier", _sql("SELECT COUNT(*) FROM frontier_runs WHERE user_id=:u AND created_at>=:s", "frontier_runs")),
    "frontier_wins": ("🌌 کلیرِ موفقِ Frontier", _sql("SELECT COUNT(*) FROM frontier_runs WHERE user_id=:u AND outcome='win' AND created_at>=:s", "frontier_wins")),
    "myawy_posts": ("📝 پستِ جدید در میاوی", _sql("SELECT COUNT(*) FROM myawy_posts WHERE user_id=:u AND created_at>=:s", "myawy_posts")),
    "myawy_likes": ("❤️ لایک‌کردنِ پستِ دیگران", _sql("SELECT COUNT(*) FROM myawy_post_likes WHERE user_id=:u AND created_at>=:s", "myawy_likes")),
    "lottery_joined": ("🎟 شرکت در قرعه‌کشی", _lottery),
}
METRIC_LABEL = {k: v[0] for k, v in METRICS.items()}


def measure(session, metric: str, uid: int, since) -> int:
    spec = METRICS.get(metric)
    return spec[1](session, uid, since) if spec else 0
