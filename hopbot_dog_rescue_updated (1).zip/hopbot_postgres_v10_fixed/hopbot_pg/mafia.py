# -*- coding: utf-8 -*-
"""
🕵️ مافیا/گرگینه (کازینو هاپویی)

بازیِ ۵ تا ۸ نفره، همیشه تو گروه. لابی مثلِ رولت/اونو: سازنده مبلغِ ورودی و تعدادِ
بازیکن و «سناریو» رو می‌چینه، بقیه می‌پیوندن. وقتی پر شد، هر بازیکن با پیامِ خصوصی
نقشش رو می‌فهمه (دقیقاً مثلِ الگویِ اونو/نبردِ دریایی) و بازی بینِ شب و روز می‌چرخه
تا یه طرف ببره. تیمِ برنده هرکدوم ۵.۵× مبلغِ ورودیِ خودشون رو می‌گیرن؛ تیمِ بازنده
مبلغِ ورودیش سوخته (دقیقاً مدلِ ضریبیِ بقیه‌ی بازی‌هایِ کازینو).

۴ سناریو (تعدادِ نقش‌ها بر اساسِ تعدادِ بازیکن، هر سناریو جمعش دقیقاً برابرِ n ـه):

  🎭 کلاسیک      — مافیا + دکتر + کارآگاه + شهروند
  🛡 پیشرفته     — مافیا + کارآگاه + محافظ + تک‌تیرانداز (بدونِ دکتر؛ نقش‌هایِ بیشتر)
  ⚡️ سریع        — مافیا + دکتر + شهروند (بدونِ کارآگاه؛ تایمرهایِ کوتاه‌تر)
  🃏 روانی       — مافیا + دکتر + کارآگاه (از ۶نفر به بالا) + یه «روانی» + شهروند

نقش‌ها:
  🔪 مافیا       — شب‌ها با هم‌تیمی‌هاش (اگه بیشتر از ۱ نفر باشن) رای می‌دن کی کشته بشه؛
                  اکثریتِ آرایِ مافیا تصمیم رو می‌گیره؛ تساوی = اون شب کسی کشته نمی‌شه.
  💉 دکتر        — هر شب یه نفر (حتی خودش) رو از کشته‌شدن به‌دستِ مافیا نجات می‌ده.
  🔍 کارآگاه     — هر شب یه نفرِ دیگه رو استعلام می‌گیره: «مافیاست» یا «بی‌گناهه».
  🛡 محافظ       — هر شب یه نفرِ دیگه رو محافظت می‌کنه؛ اگه مافیا همونو بزنه، خودِ
                  محافظ به‌جاش می‌میره و اون بازیکن زنده می‌مونه.
  🎯 تک‌تیرانداز — کلِ بازی فقط ۱ گلوله داره؛ هر شب می‌تونه شلیک کنه (یا رد کنه). شلیکش
                  همیشه می‌کشه (نه دکتر نه محافظ جلوشو می‌گیره) - چه هدف مافیا باشه چه
                  بی‌گناه؛ بعدِ اولین شلیک دیگه گلوله نداره.
  🃏 روانی       — نقشِ خنثاست؛ هیچ اقدامِ شبونه‌ای نداره و کارآگاه «بی‌گناه» می‌بینتش. تنها
                  راهِ بردش اینه که رویِ گروه با رای‌گیریِ روز اعدام بشه (اون‌وقت فوراً
                  می‌بره و ۵.۵× مبلغِ ورودیشُ تنها می‌گیره). اگه اعدام نشه، نه تو تیمِ مافیاست نه
                  تیمِ شهر و آخرِ بازی (چه شهر ببره چه مافیا) چیزی نمی‌گیره.
  👤 شهروند      — بدونِ قدرت؛ فقط رای می‌ده.

فازها: هر دور یه «شب» (پیامِ خصوصیِ اقدام‌ها) و بعدش یه «روز» (رای‌گیریِ اعدام تو
گروه) داره. هر فاز مهلتِ خودش رو داره ولی اگه همه‌ی کسایی که باید اقدام/رای کنن زودتر
کارشون رو انجام بدن، فاز فوراً تموم می‌شه (منتظرِ تایمر نمی‌مونه).

برد: مافیا وقتی می‌بره که تعدادِ زنده‌هاش با تعدادِ بقیه‌ی زنده‌ها برابر یا بیشتر بشه.
شهر وقتی می‌بره که همه‌ی مافیاها حذف بشن. اگه تو یه شب/روز هم آخرین مافیا هم آخرین
غیرمافیا با هم حذف بشن، مساویه و پولِ همه برمی‌گرده. وگرنه هر بازمانده‌یِ طرفِ
برنده ۵.۵× مبلغِ ورودیِ خودشُ می‌گیره (روانی استثناست: طبقِ بالا).
"""
import asyncio
import datetime
import json
import logging
import math
import random

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationHandlerStop

import casino
import db
from handlers import fmt, send_response, ask_for_input, is_reply_to_prompt, parse_amount

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# تنظیمات
# ---------------------------------------------------------------------------
MIN_PLAYERS = 5
MAX_PLAYERS = 8                # بازه‌ی آزادِ لابیِ گروهی
GLOBAL_TIERS = (1_000_000, 100_000_000, 500_000_000)  # سه مبلغِ ثابتِ لابیِ جهانی (مثلِ رولت روسی)
GLOBAL_PLAYER_TIERS = (5, 8, 11)  # سه تعدادِ ثابتِ لابیِ جهانی
GLOBAL_WAIT_SECONDS = 360      # مهلتِ لابیِ جهانی (۶ دقیقه)
GLOBAL_JOIN_MIN_REMAINING = 15  # میزی که کمتر از این‌قدر به لغوش مونده، به آدمِ جدید داده نمی‌شه
WIN_MULTIPLIER = 5.5           # تیمِ برنده هرکدوم ۵.۵ برابرِ مبلغِ ورودیِ خودشون رو می‌گیرن؛ بازنده‌ها مبلغشون سوخته
LOBBY_SECONDS = 240            # مهلتِ پرشدنِ لابیِ گروهی تو گپ
SETUP_ABANDON_SECONDS = 90     # اگه کسی سناریو/مبلغ/تعداد رو نچینه و ول کنه
LOG_KEEP = 8

MAX_SPEECH_CHARS = 250          # سقفِ طولِ حرفِ هر نفر تو نوبتِ صحبتِ روز (پنلِ همه نمایشش می‌ده)

MF_CFG_LIMITS = {
    "casino_mafia_night_seconds": (15, 600),
    "casino_mafia_day_seconds": (15, 600),
    "casino_mafia_day_speak_seconds": (30, 600),  # تایم‌اوتِ هر نوبتِ صحبتِ روز (هر دو حالتِ گروهی/جهانی)
}
_MF_CFG_DEFAULTS = {"casino_mafia_night_seconds": 60, "casino_mafia_day_seconds": 90,
                    "casino_mafia_day_speak_seconds": 180}

SCENARIOS = ("classic", "advanced", "quick", "psycho")
SCENARIO_TITLE = {
    "classic": "🎭 کلاسیک", "advanced": "🛡 پیشرفته", "quick": "⚡️ سریع", "psycho": "🃏 روانی",
}
SCENARIO_DESC = {
    "classic": "مافیا + دکتر + کارآگاه + شهروند. حالتِ استانداردِ بازی.",
    "advanced": "مافیا + کارآگاه + محافظ + تک‌تیرانداز (بدونِ دکتر). نقش‌های بیشتر، استراتژی بیشتر.",
    "quick": "مافیا + دکتر + شهروند (بدونِ کارآگاه). تایمرهای کوتاه‌تر؛ بازیِ سریع.",
    "psycho": "مافیا + دکتر (+کارآگاه از ۶نفر به بالا) + یه روانی که فقط با اعدام‌شدن می‌بره.",
}

# چیدمانِ نقش‌ها: SCENARIO -> n -> {role: count}. جمعِ هر ردیف دقیقاً برابرِ n ـه.
ROLE_TABLES = {
    "classic": {
        5: {"mafia": 1, "doctor": 1, "detective": 1, "citizen": 2},
        6: {"mafia": 1, "doctor": 1, "detective": 1, "citizen": 3},
        7: {"mafia": 2, "doctor": 1, "detective": 1, "citizen": 3},
        8: {"mafia": 2, "doctor": 1, "detective": 1, "citizen": 4},
        11: {"mafia": 3, "doctor": 1, "detective": 1, "citizen": 6},
    },
    "advanced": {
        5: {"mafia": 1, "detective": 1, "bodyguard": 1, "citizen": 2},
        6: {"mafia": 1, "detective": 1, "bodyguard": 1, "sniper": 1, "citizen": 2},
        7: {"mafia": 2, "detective": 1, "bodyguard": 1, "sniper": 1, "citizen": 2},
        8: {"mafia": 2, "detective": 1, "bodyguard": 1, "sniper": 1, "citizen": 3},
        11: {"mafia": 3, "detective": 1, "bodyguard": 1, "sniper": 1, "citizen": 5},
    },
    "quick": {
        5: {"mafia": 1, "doctor": 1, "citizen": 3},
        6: {"mafia": 1, "doctor": 1, "citizen": 4},
        7: {"mafia": 2, "doctor": 1, "citizen": 4},
        8: {"mafia": 2, "doctor": 1, "citizen": 5},
        11: {"mafia": 3, "doctor": 1, "citizen": 7},
    },
    "psycho": {
        5: {"mafia": 1, "doctor": 1, "psycho": 1, "citizen": 2},
        6: {"mafia": 1, "doctor": 1, "detective": 1, "psycho": 1, "citizen": 2},
        7: {"mafia": 2, "doctor": 1, "detective": 1, "psycho": 1, "citizen": 2},
        8: {"mafia": 2, "doctor": 1, "detective": 1, "psycho": 1, "citizen": 3},
        11: {"mafia": 3, "doctor": 1, "detective": 1, "psycho": 1, "citizen": 5},
    },
}
for _scn, _table in ROLE_TABLES.items():
    for _n, _roles in _table.items():
        assert sum(_roles.values()) == _n, (_scn, _n, _roles)

ROLE_TITLE = {
    "mafia": "🔪 مافیا", "doctor": "💉 دکتر", "detective": "🔍 کارآگاه", "bodyguard": "🛡 محافظ",
    "sniper": "🎯 تک‌تیرانداز", "psycho": "🃏 روانی", "citizen": "👤 شهروند",
}
NIGHT_ACTION_ROLES = ("mafia", "doctor", "detective", "bodyguard", "sniper")
TOWN_ROLES = ("citizen", "doctor", "detective", "bodyguard", "sniper")  # همه‌ی غیرمافیا/غیرروانی

_rng = random.SystemRandom()


def mf_settings(session):
    def get(key):
        lo, hi = MF_CFG_LIMITS[key]
        try:
            v = int(float(db.cfg_get(session, key)))
        except Exception:
            v = _MF_CFG_DEFAULTS[key]
        return max(lo, min(hi, v))
    return {"night": get("casino_mafia_night_seconds"), "day": get("casino_mafia_day_seconds"),
            "day_speak": get("casino_mafia_day_speak_seconds")}


def _settings_now():
    session = db.get_session()
    try:
        return mf_settings(session)
    finally:
        session.close()


def validate_cfg(key, text):
    lim = MF_CFG_LIMITS.get(key)
    if not lim:
        return None
    try:
        v = float(text)
    except (TypeError, ValueError):
        return "❌ باید یه عدد بفرستی."
    if v != int(v):
        return "❌ باید یه عددِ صحیح بفرستی."
    if not (lim[0] <= int(v) <= lim[1]):
        return f"❌ این مقدار باید بینِ {lim[0]} تا {lim[1]} باشه."
    return None


def _now():
    return datetime.datetime.utcnow()


# ---------------------------------------------------------------------------
# قفل‌ها و تایمرها (دقیقاً همون الگویِ roulette.py)
# ---------------------------------------------------------------------------
_round_locks = {}
_bg_tasks = set()


def _get_round_lock(round_id: int) -> asyncio.Lock:
    lock = _round_locks.get(round_id)
    if lock is None:
        lock = asyncio.Lock()
        _round_locks[round_id] = lock
    return lock


def _schedule(coro_fn, delay, *args):
    async def runner():
        try:
            await asyncio.sleep(delay)
            await coro_fn(*args)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("خطا در تایمرِ مافیا/گرگینه")
    task = asyncio.create_task(runner())
    _bg_tasks.add(task)
    task.add_done_callback(_bg_tasks.discard)


def with_round_lock(func):
    async def wrapper(update, context):
        try:
            rid = int(update.callback_query.data.split(":")[1])
        except (ValueError, IndexError, AttributeError):
            await func(update, context)
            return
        async with _get_round_lock(rid):
            await func(update, context)
        session = db.get_session()
        try:
            r = session.get(db.MafiaRound, rid)
            if not r or r.status in ("resolved", "cancelled"):
                _round_locks.pop(rid, None)
        finally:
            session.close()
    return wrapper


async def _safe_answer(q, *args, **kwargs):
    try:
        await q.answer(*args, **kwargs)
    except Exception as e:
        logger.warning("answerِ کالبک شکست خورد: %s", e)


# ---------------------------------------------------------------------------
# ادیتِ مقاوم (رولت روسی همین الگو رو داره)
# ---------------------------------------------------------------------------
_RESEND_ERRORS = ("message to edit not found", "message can't be edited", "message to be edited not found")
_PERMANENT_ERRORS = ("chat not found", "bot was blocked", "bot was kicked", "user is deactivated",
                     "forbidden", "have no rights", "chat_write_forbidden")


def _retry_after_seconds(exc):
    ra = getattr(exc, "retry_after", None)
    if ra is None:
        return None
    try:
        return float(ra.total_seconds()) if hasattr(ra, "total_seconds") else float(ra)
    except Exception:
        return 2.0


async def _edit_msg_ex(context, chat_id, message_id, text, kb=None):
    """(آی‌دیِ پیامِ نهایی, موفق؟) - نگاه کن به roulette._edit_msg_ex برایِ توضیحِ کامل."""
    if message_id:
        not_found = False
        for attempt in range(1, 5):
            try:
                await context.bot.edit_message_text(
                    chat_id=chat_id, message_id=message_id, text=text, reply_markup=kb)
                return message_id, True
            except Exception as e:
                err = str(e).lower()
                if "not modified" in err:
                    return message_id, True
                if any(x in err for x in _RESEND_ERRORS):
                    not_found = True
                    break
                if any(x in err for x in _PERMANENT_ERRORS):
                    logger.warning("ادیتِ پیامِ مافیا (خطای دائمی): %s", e)
                    return message_id, True
                if attempt == 4:
                    logger.warning("ادیتِ پیامِ مافیا بعد از چند تلاش شکست خورد: %s", e)
                    return message_id, False
                delay = _retry_after_seconds(e)
                await asyncio.sleep(min(delay, 20.0) + 0.5 if delay is not None else 0.6 * attempt)
        if not not_found:
            return message_id, False
    try:
        msg = await context.bot.send_message(chat_id=chat_id, text=text, reply_markup=kb)
        return msg.message_id, True
    except Exception as e:
        logger.warning("فرستادنِ پیامِ مافیا شکست خورد: %s", e)
        return message_id, False


async def _edit_msg(context, chat_id, message_id, text, kb=None):
    new_id, _ok = await _edit_msg_ex(context, chat_id, message_id, text, kb)
    return new_id


async def _try_dm(context, user_id, text, kb=None):
    """فقط برایِ فرستادنِ *اولینِ* یه پیامِ خصوصی (نه ادیت). خروجی: message_id یا None."""
    try:
        msg = await context.bot.send_message(chat_id=user_id, text=text, reply_markup=kb)
        return msg.message_id
    except Exception as e:
        logger.info("DM به %s شکست خورد: %s", user_id, e)
        return None


_dirty = {}


def _day_speak_order_list(r):
    try:
        return json.loads(r.day_speak_order) if r.day_speak_order else []
    except Exception:
        return []


def _speeches_load(r):
    """(شمارِ روزی که این صحبت‌ها مالِ اونه, [ {u: uid, t: متن یا \"\", o: spoke/skipped/timeout} ])"""
    try:
        d = json.loads(r.day_speeches) if r.day_speeches else None
    except Exception:
        d = None
    if not isinstance(d, dict) or not isinstance(d.get("items"), list):
        return 0, []
    try:
        day = int(d.get("day") or 0)
    except Exception:
        day = 0
    return day, d["items"]


def _speeches_save(r, day, items):
    r.day_speeches = json.dumps({"day": day, "items": items}, ensure_ascii=False)


def _speeches_block(session, r, max_each=None):
    """بلوکِ «صحبت‌هایِ روزِ N» که تو پنلِ همه (خصوصی/گروه/جهانی) نشون داده می‌شه؛
    تا وقتی روزِ بعدی شروع نشده (یعنی تمامِ شبِ بعدش هم) همون‌جا می‌مونه.
    هرکی حرف نزده باشه (چه تایم‌اوت، چه ردِ نوبت، چه اتمامِ بدونِ حرف) «حرف نزد» می‌خوره."""
    day, items = _speeches_load(r)
    if not items:
        return ""
    lines = [f"🗣 صحبت‌هایِ روزِ {day}:"]
    for it in items:
        name = _name(session, it.get("u"))
        t = it.get("t") or ""
        if t:
            if max_each and len(t) > max_each:
                t = t[:max_each - 1] + "…"
            lines.append(f"{name} : {t}")
        else:
            lines.append(f"{name} : حرف نزد")
    return "\n".join(lines)


_TG_LIMIT = 3900


def _with_recap(session, r, text):
    """متنِ یه پنل + بلوکِ صحبت‌هایِ روز (اگه داشته باشه) - با رعایتِ سقفِ ۴۰۹۶ حرفیِ تلگرام."""
    for max_each in (None, 80, 30):
        block = _speeches_block(session, r, max_each)
        out = text + ("\n\n" + block if block else "")
        if len(out) <= _TG_LIMIT:
            return out
    return out[:_TG_LIMIT] + "…"


def _turn_info(r):
    """(order, idx, uid نوبتِ فعلی یا None)"""
    order = _day_speak_order_list(r)
    idx = r.day_speak_index or 0
    return order, idx, (order[idx] if idx < len(order) else None)


async def _resync(context, rid):
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.MafiaRound, rid)
            if not r or r.status not in ("night", "day", "resolved", "cancelled"):
                return
            await _broadcast(context, session, r)
        finally:
            session.close()


# ---------------------------------------------------------------------------
# کمکی‌هایِ دیتابیس
# ---------------------------------------------------------------------------

def _name(session, uid):
    u = session.get(db.User, uid)
    return u.display_name() if u else str(uid)


def _all_players(session, rid):
    return session.query(db.MafiaPlayer).filter_by(round_id=rid).order_by(db.MafiaPlayer.id).all()


def _alive_players(session, rid):
    return [p for p in _all_players(session, rid) if p.alive]


def _get_player(session, rid, uid):
    return session.query(db.MafiaPlayer).filter_by(round_id=rid, user_id=uid).first()


def _mafia_alive(players):
    return [p for p in players if p.alive and p.role == "mafia"]


def _town_alive(players):
    """زنده‌هایِ غیرِ مافیا (روانی هم اینجا حساب می‌شه - برایِ محاسبه‌ی برابریِ مافیا)."""
    return [p for p in players if p.alive and p.role != "mafia"]


def _log(r, line):
    lines = [x for x in (r.log_text or "").split("\n") if x]
    lines.append(line)
    r.log_text = "\n".join(lines[-LOG_KEEP:])


def _refund_all(session, r):
    if not r.entry_amount:
        return
    for p in _all_players(session, r.id):
        u = session.get(db.User, p.user_id)
        if u:
            u.hop_points = (u.hop_points or 0) + r.entry_amount


def _cancel_text(r, n, kind="timeout"):
    if kind == "creator":
        return "❌ مافیا/گرگینه توسطِ سازنده لغو شد؛ پولِ هرکسی که پرداخت کرده بود برگشت داده شد."
    if kind == "inactive":
        return "⏳ این بازی به‌خاطرِ عدمِ فعالیت لغو شد."
    if n <= 1:
        when = f"{GLOBAL_WAIT_SECONDS // 60} دقیقه" if r.mode == "global" else f"{LOBBY_SECONDS} ثانیه"
        return f"⏳ {when} گذشت و هیچ هاپویی نیومد؛ بازی لغو شد و پولت برگشت داده شد."
    if r.mode == "global":
        return (f"⏳ {GLOBAL_WAIT_SECONDS // 60} دقیقه گذشت و میزِ جهانی پر نشد ({n}/{r.target_players})؛ "
                "بازی لغو شد و پولت برگشت داده شد.")
    return (f"❌ به تعدادِ کافی بازیکن نپیوست ({n}/{r.target_players})؛ "
            "بازی لغو شد و مبلغ‌ها برگشت داده شد.")


def _lobby_targets(session, r):
    """[(chat_id, message_id, uid)] - پیام‌هایی که باید موقعِ لغوِ لابی ادیت بشن.
    group: یه پیامِ مشترک. global: پنلِ خودِ هر بازیکن."""
    if r.mode == "group":
        return [(r.chat_id, r.message_id, None)] if r.message_id else []
    return [(p.chat_id, p.dm_message_id, p.user_id) for p in _all_players(session, r.id) if p.dm_message_id]


def _cancel_db(session, r, text=None):
    if text is None:
        text = _cancel_text(r, len(_all_players(session, r.id)))
    targets = _lobby_targets(session, r)
    _refund_all(session, r)
    r.log_text = text
    r.status = "cancelled"
    r.ended_at = _now()
    return targets


def _expiry(r):
    if r.status == "setup":
        return (r.last_action_at or r.created_at, SETUP_ABANDON_SECONDS)
    if r.status == "lobby":
        limit = GLOBAL_WAIT_SECONDS if r.mode == "global" else LOBBY_SECONDS
        return (r.lobby_opened_at or r.created_at, limit)
    return None


def _is_expired(r, now, grace=0):
    e = _expiry(r)
    if not e or not e[0]:
        return False
    return (now - e[0]).total_seconds() >= e[1] + grace


_lazy_edits = []


def expire_stale_for_user(session, user_id):
    """مثلِ roulette.expire_stale_for_user: دورِ setup/lobbyِ این کاربر که مهلتش
    گذشته رو همین لحظه لغو می‌کنه، تا کسی با «وسطِ کازینو هستی» گیر نکنه."""
    now = _now()
    mine = session.query(db.MafiaPlayer.round_id).filter(db.MafiaPlayer.user_id == user_id)
    rows = (session.query(db.MafiaRound)
            .filter(db.MafiaRound.status.in_(("setup", "lobby")),
                    (db.MafiaRound.initiator_id == user_id) | db.MafiaRound.id.in_(mine))
            .all())
    changed = False
    for r in rows:
        if r.status == "lobby" and len(_all_players(session, r.id)) >= (r.target_players or 99):
            continue
        if _is_expired(r, now, grace=3):
            text = _cancel_text(r, len(_all_players(session, r.id)), "inactive" if r.status == "setup" else "timeout")
            for chat_id, message_id, _uid in _cancel_db(session, r, text):
                if message_id:
                    _lazy_edits.append((chat_id, message_id, text))
            changed = True
    if changed:
        session.commit()


def user_has_active_mafia(session, user_id) -> bool:
    """setup/lobby: سازنده یا عضو. night/day: فقط اگه هنوز *زنده*‌ست - حذف‌شده دیگه
    وسطِ بازی حساب نمی‌شه و می‌تونه بازیِ دیگه‌ای شروع کنه."""
    expire_stale_for_user(session, user_id)
    mine = session.query(db.MafiaPlayer.round_id).filter(db.MafiaPlayer.user_id == user_id)
    row = (session.query(db.MafiaRound)
           .filter(db.MafiaRound.status.in_(("setup", "lobby")),
                   (db.MafiaRound.initiator_id == user_id) | db.MafiaRound.id.in_(mine))
           .first())
    if row:
        return True
    alive_mine = (session.query(db.MafiaPlayer.round_id)
                  .filter(db.MafiaPlayer.user_id == user_id, db.MafiaPlayer.alive == True))  # noqa: E712
    return bool(session.query(db.MafiaRound)
                .filter(db.MafiaRound.status.in_(("night", "day")), db.MafiaRound.id.in_(alive_mine))
                .first())


# ---------------------------------------------------------------------------
# نمایش‌ها: منو / انتخابِ سناریو / تنظیمات / لابی
# ---------------------------------------------------------------------------

def _players_summary(session, players, reveal=False):
    """خلاصه‌ی بازیکن‌ها برایِ پنلِ گروه. reveal=True یعنی نقشِ همه رو نشون بده
    (فقط تهِ بازی، بعد از تمومِ کامل)."""
    lines = []
    for p in players:
        n = _name(session, p.user_id)
        if p.alive:
            lines.append(f"🟢 {n}" + (f" — {ROLE_TITLE.get(p.role, p.role)}" if reveal else ""))
        else:
            lines.append(f"☠️ {n} — {p.out_reason or 'حذف شد'}"
                         + (f" ({ROLE_TITLE.get(p.role, p.role)})" if reveal and " — " not in (p.out_reason or "") else ""))
    return "\n".join(lines) if lines else "—"


def _mode_menu_view(owner_id):
    text = (f"🕵️ مافیا/گرگینه\n\nبازیِ {MIN_PLAYERS} تا {MAX_PLAYERS} نفره (تو گروه) یا لابیِ جهانی "
            f"({'/'.join(str(x) for x in GLOBAL_PLAYER_TIERS)} نفره). کجا بازی کنیم؟")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🏠 لابی تو همین گروه", callback_data=f"mf_mode_group:{owner_id}")],
        [InlineKeyboardButton("🌍 پیدا کردن لابی جهانی", callback_data=f"mf_mode_global:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"mf_menu:{owner_id}")],
    ])
    return text, kb


def _scenario_menu_view(owner_id, mode="group", in_group=True):
    prefix = "mf_scn" if mode == "group" else "mf_gscn"
    lines = ["🕵️ مافیا/گرگینه", "", "یه سناریو انتخاب کن:"]
    for scn in SCENARIOS:
        lines.append(f"\n{SCENARIO_TITLE[scn]}\n{SCENARIO_DESC[scn]}")
    rows = [[InlineKeyboardButton(SCENARIO_TITLE[scn], callback_data=f"{prefix}:{owner_id}:{scn}")] for scn in SCENARIOS]
    if mode == "group" or in_group:
        back = f"mf_mode_menu:{owner_id}"
    else:
        back = f"mf_menu:{owner_id}"
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=back)])
    return "\n".join(lines), InlineKeyboardMarkup(rows)


def _gtier_menu_view(session, owner_id, scn):
    tiers = [a for a in GLOBAL_TIERS if not casino.max_bet_exceeded(session, a)]
    if not tiers:
        text = f"🌍 لابیِ جهانی — {SCENARIO_TITLE[scn]}\n\n⛔️ الان هیچ میزی با سقفِ مجازِ قمار جور نیست."
    else:
        text = (f"🌍 لابیِ جهانی — {SCENARIO_TITLE[scn]}\n\nیکی از میزها رو انتخاب کن. هر بازیکنی (از هر گپی) که "
                "همین میز و همین تعدادِ نفر رو انتخاب کنه با تو می‌افته.")
    rows = [[InlineKeyboardButton(f"🪙 {fmt(a)}", callback_data=f"mf_gtier:{owner_id}:{scn}:{a}")] for a in tiers]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"mf_mode_global:{owner_id}")])
    return text, InlineKeyboardMarkup(rows)


def _gcount_menu_view(owner_id, scn, amount):
    text = (f"🌍 میزِ {fmt(amount)} 🪙 — {SCENARIO_TITLE[scn]}\n\nچند نفره بازی کنیم؟ "
            "(هرکی همین مبلغ، همین سناریو و همین تعداد رو انتخاب کنه با تو می‌افته)")
    rows = [[InlineKeyboardButton(f"👥 {n} نفره", callback_data=f"mf_gjoin:{owner_id}:{scn}:{amount}:{n}")
             for n in GLOBAL_PLAYER_TIERS]]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"mf_gscn:{owner_id}:{scn}")])
    return text, InlineKeyboardMarkup(rows)


def _setup_view(r):
    scn_txt = SCENARIO_TITLE.get(r.scenario, "— تنظیم نشده —")
    amount_txt = fmt(r.entry_amount) + " 🪙" if r.entry_amount else "— تنظیم نشده —"
    players_txt = str(r.target_players) if r.target_players else "— تنظیم نشده —"
    text = ("🕵️ مافیا/گرگینه — تنظیمات\n\n"
            f"🎭 سناریو: {scn_txt}\n"
            f"💰 مبلغ ورودی: {amount_txt}\n"
            f"👥 تعداد بازیکن: {players_txt}")
    if r.scenario:
        text += f"\n\n{SCENARIO_DESC[r.scenario]}"
    rows = [[InlineKeyboardButton("🎭 تغییرِ سناریو", callback_data=f"mf_scn_menu:{r.id}")],
            [InlineKeyboardButton("💰 انتخاب مبلغ ورودی", callback_data=f"mf_amt_menu:{r.id}")],
            [InlineKeyboardButton("👥 انتخاب تعداد بازیکن", callback_data=f"mf_plr_menu:{r.id}")]]
    if r.scenario and r.entry_amount and r.target_players:
        rows.append([InlineKeyboardButton("▶️ شروع بازی", callback_data=f"mf_start:{r.id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"mf_back:{r.id}"),
                 InlineKeyboardButton("❌ لغو", callback_data=f"mf_cancel:{r.id}")])
    return text, InlineKeyboardMarkup(rows)


def _lobby_view(session, r):
    players = _all_players(session, r.id)
    names = "\n".join(f"• {_name(session, p.user_id)}" for p in players) or "هنوز کسی نیست..."
    win_amt = (r.entry_amount or 0) * WIN_MULTIPLIER
    text = (f"🕵️ مافیا/گرگینه — {SCENARIO_TITLE.get(r.scenario)} — در انتظار بازیکن‌ها "
            f"({len(players)}/{r.target_players})\n"
            f"💰 مبلغ ورودی هرنفر: {fmt(r.entry_amount)} 🪙 — 🏆 برد = {WIN_MULTIPLIER}× یعنی {fmt(win_amt)} 🪙\n\n"
            f"{names}\n\n"
            f"⏳ اگه تا {LOBBY_SECONDS} ثانیه پر نشه، بازی لغو و پولِ همه برگشت داده می‌شه.")
    rows = [[InlineKeyboardButton("🎮 پیوستن به بازی", callback_data=f"mf_join:{r.id}")],
            [InlineKeyboardButton("🚪 ترک بازی", callback_data=f"mf_leave:{r.id}")],
            [InlineKeyboardButton("❌ لغو (فقط سازنده)", callback_data=f"mf_cancel:{r.id}")]]
    return text, InlineKeyboardMarkup(rows)


def _global_lobby_view(session, r, for_uid=None):
    players = _all_players(session, r.id)
    names = "\n".join(f"• {_name(session, p.user_id)}" for p in players) or "هنوز کسی نیست..."
    win_amt = (r.entry_amount or 0) * WIN_MULTIPLIER
    mins = GLOBAL_WAIT_SECONDS // 60
    text = (f"🕵️ مافیا/گرگینه — 🌍 لابیِ جهانی — {SCENARIO_TITLE.get(r.scenario)} "
            f"({len(players)}/{r.target_players})\n"
            f"💰 ورودی: {fmt(r.entry_amount)} 🪙 — 🏆 برد = {WIN_MULTIPLIER}× یعنی {fmt(win_amt)} 🪙\n\n"
            f"{names}\n\n"
            f"🔎 در حالِ پیدا کردنِ حریف... هرکی همین سناریو، مبلغ و تعداد رو انتخاب کنه با شما می‌افته.\n"
            f"⏳ اگه تا {mins} دقیقه پر نشه خودکار لغو می‌شه و پولت برمی‌گرده.")
    rows = []
    if for_uid:
        rows.append([InlineKeyboardButton("🚪 منصرف شدم", callback_data=f"mf_gleave:{r.id}:{for_uid}")])
    return text, InlineKeyboardMarkup(rows) if rows else None


def _phase_label(r):
    if r.status == "night":
        return f"🌙 شبِ {r.day_number}"
    if r.status == "day":
        if r.day_speak_active:
            return f"☀️ روزِ {r.day_number} (🎙 نوبتِ صحبت‌ها)"
        return f"☀️ روزِ {r.day_number}"
    return ""


def _group_view(session, r):
    """پنلِ گروه در طولِ بازی (شب/روز). جزئیاتِ نقش‌ها/اقدام‌ها اینجا فاش نمی‌شه -
    فقط زنده/مرده و دلیلِ مرگ (بعد از اعلام). صحبت‌هایِ روز هم همین‌جا (فقط‌خواندنی)
    نمایش داده می‌شه؛ هیچ‌کس تو گروه محدود/ساکت نمی‌شه و صحبت‌ها تو پیوی انجام می‌شن."""
    players = _all_players(session, r.id)
    cfg = mf_settings(session)
    lines = [f"🕵️ مافیا/گرگینه — {SCENARIO_TITLE.get(r.scenario)} — {_phase_label(r)}", ""]
    lines.append(_players_summary(session, players))
    lines.append("")
    if r.status == "night":
        acted, total = _night_progress(session, r, players)
        lines.append(f"🌙 بازیکن‌هایی که نقشِ‌شب دارن، دارن تو پیویِ خودشون تصمیم می‌گیرن... ({acted}/{total})")
        lines.append(f"⏳ حداکثر تا {cfg['night']} ثانیه‌ی دیگه.")
    elif r.status == "day" and r.day_speak_active:
        order, idx, cur = _turn_info(r)
        done = min(idx, len(order))
        lines.append(f"🎙 فازِ صحبتِ روز ({done}/{len(order)} نوبت تموم شد).")
        if cur is not None:
            lines.append(f"🎤 نوبتِ {_name(session, cur)} — ⏳ {cfg['day_speak']} ثانیه وقت داره.")
        lines.append("✍️ هرکس نوبتش شد، تو پیویِ ربات رویِ پنلِ خودش ریپلای می‌کنه و حرفش رو می‌نویسه؛ "
                     "حرف‌ها همین‌جا و تو پنلِ همه‌ی بازیکن‌ها نوشته می‌شن.")
    elif r.status == "day":
        voted, total = _day_progress(session, r, players)
        lines.append(f"☀️ رای‌گیری برایِ اعدام باز است ({voted}/{total} رای دادن).")
        lines.append(f"⚖️ برایِ اعدام حداقل {(total + 1) // 2} رای (نصفِ زنده‌ها یا بیشتر) لازمه؛ تساویِ بالاترین‌ها = قرعه.")
        lines.append(f"⏳ حداکثر تا {cfg['day']} ثانیه‌ی دیگه.")
        tally = _day_vote_tally(players)
        if tally:
            lines.append("")
            lines.append("🗳 آرایِ فعلی:")
            for key, voters in tally.items():
                label = "🤷 رای‌ندادن" if key is None else _name(session, key)
                lines.append(f"• {label}: {', '.join(_name(session, v.user_id) for v in voters)}")
    if r.log_text:
        lines += ["", "📜 آخرین اتفاق‌ها:", r.log_text]
    text = _with_recap(session, r, "\n".join(lines))
    kb = _day_keyboard(session, r, players) if (r.status == "day" and not r.day_speak_active) else None
    return text, kb


def _mafia_status_text(session, r, players, p):
    """پنلِ شخصیِ کسی که الان اقدام/رایی نداره (زنده‌ی بدونِ نقشِ‌شب، یا مرده) -
    همون خلاصه‌ای که تو پنلِ گروه هست، فقط شخصی‌شده. تو هر دو حالتِ گروهی و جهانی."""
    cfg = mf_settings(session)
    tag = " — 🌍" if r.mode == "global" else ""
    lines = [f"🕵️ مافیا/گرگینه{tag} — {SCENARIO_TITLE.get(r.scenario)} — {_phase_label(r)}", ""]
    lines.append(_players_summary(session, players))
    lines.append("")
    if not p.alive:
        lines.append(f"☠️ تو حذف شدی ({p.out_reason or '—'}؛ نقشت «{ROLE_TITLE.get(p.role, p.role)}» بود).")
        lines.append("بازی برایِ بقیه ادامه داره؛ همینجا نتیجه‌ی نهایی رو می‌بینی.")
    elif r.status == "night":
        acted, total = _night_progress(session, r, players)
        lines.append(f"🌙 نقشِ تو ({ROLE_TITLE.get(p.role, p.role)}) امشب اقدامی نداره؛ منتظرِ بقیه باش... ({acted}/{total})")
        lines.append(f"⏳ حداکثر تا {cfg['night']} ثانیه‌ی دیگه.")
    if r.log_text:
        lines += ["", "📜 آخرین اتفاق‌ها:", r.log_text]
    return _with_recap(session, r, "\n".join(lines))


def _dm_day_view(session, r, players, p):
    """پنلِ خصوصیِ فازِ روز برایِ یه بازیکن (هم لابیِ گروهی هم جهانی):
    وسطِ چرخِ صحبت‌ها → نوبتِ چه‌کسیه + (برایِ صاحبِ نوبت) راهنمایِ ریپلای و دکمه‌هایِ
    «ردِ نوبت/اتمامِ صحبت»؛ بعدش → رای‌گیری با دکمه‌ها. تهش همیشه صحبت‌هایِ امروز."""
    cfg = mf_settings(session)
    tag = " — 🌍" if r.mode == "global" else ""
    lines = [f"🕵️ مافیا/گرگینه{tag} — {SCENARIO_TITLE.get(r.scenario)} — {_phase_label(r)}", ""]
    lines.append(_players_summary(session, players))
    lines.append("")
    kb = None
    if not p.alive:
        lines.append(f"☠️ تو حذف شدی ({p.out_reason or '—'}؛ نقشت «{ROLE_TITLE.get(p.role, p.role)}» بود). "
                     "می‌تونی جریانِ بازی رو همینجا ببینی، ولی دیگه صحبت/رای نداری.")
        if r.status == "day" and r.day_speak_active:
            order, idx, cur = _turn_info(r)
            if cur is not None:
                lines.append(f"🎤 الان نوبتِ {_name(session, cur)} ({idx + 1}/{len(order)}) است.")
    elif r.day_speak_active:
        order, idx, cur = _turn_info(r)
        total = len(order)
        if cur == p.user_id:
            lines.append(f"🎤 نوبتِ توئه! ({idx + 1}/{total})")
            lines.append(f"✍️ رویِ همین پیام ریپلای بزن و حرفت رو بنویس (فقط ۱ پیام، حداکثر {MAX_SPEECH_CHARS} کاراکتر).")
            lines.append(f"⏳ {cfg['day_speak']} ثانیه وقت داری؛ اگه حرفی نزنی نوبتت رد می‌شه و برایِ بقیه "
                         "«حرف نزد» نوشته می‌شه.")
            lines.append("اگه حرفی نداری «ردِ نوبت» یا «اتمامِ صحبت» رو بزن.")
            kb = _day_speak_keyboard(r.id, r.day_speak_seq)
        else:
            lines.append(f"🎤 نوبتِ صحبتِ {_name(session, cur)} ({idx + 1}/{total}) — ⏳ {cfg['day_speak']} ثانیه وقت داره."
                         if cur is not None else "🎤 صحبت‌ها داره تموم می‌شه...")
            upcoming = order[idx + 1: idx + 4]
            if upcoming:
                lines.append("⏭ نوبت‌هایِ بعدی: " + "، ".join(_name(session, u) for u in upcoming))
            lines.append("وقتی نوبتت شد، همین پنل بهت خبر می‌ده.")
    else:
        voted, total = _day_progress(session, r, players)
        lines.append(f"☀️ رای‌گیری برایِ اعدام باز است ({voted}/{total} رای دادن).")
        lines.append(f"⚖️ برایِ اعدام حداقل {(total + 1) // 2} رای (نصفِ زنده‌ها یا بیشتر) لازمه؛ تساویِ بالاترین‌ها = قرعه.")
        lines.append(f"⏳ حداکثر تا {cfg['day']} ثانیه‌ی دیگه.")
        tally = _day_vote_tally(players)
        if tally:
            lines.append("")
            lines.append("🗳 آرایِ فعلی:")
            for key, voters in tally.items():
                label = "🤷 رای‌ندادن" if key is None else _name(session, key)
                lines.append(f"• {label}: {', '.join(_name(session, v.user_id) for v in voters)}")
        kb = _day_keyboard(session, r, players)
    if r.log_text:
        lines += ["", "📜 آخرین اتفاق‌ها:", r.log_text]
    return _with_recap(session, r, "\n".join(lines)), kb


def _final_view(session, r):
    players = _all_players(session, r.id)
    win_amt = (r.entry_amount or 0) * WIN_MULTIPLIER
    side = r.winner_side
    title = {"mafia": "🔪 مافیا بردن!", "town": "🏆 شهر بردن!", "psycho": "🃏 روانی برد!",
             "draw": "🤝 مساوی شد"}.get(side, "پایانِ بازی")
    lines = [f"🕵️ مافیا/گرگینه — {SCENARIO_TITLE.get(r.scenario)} — پایانِ بازی", "", title,
             (f"💰 برنده‌ها هرکدوم {fmt(win_amt)} 🪙 گرفتن ({WIN_MULTIPLIER}× ورودیِ خودشون)."
              if side not in ("draw", None) else f"💰 مبلغِ ورودی ({fmt(r.entry_amount)} 🪙) به همه برگشت."), ""]
    lines.append(_players_summary(session, players, reveal=True))
    if r.log_text:
        lines += ["", "📜 آخرین اتفاق‌ها:", r.log_text]
    return "\n".join(lines), None


def _view(session, r, for_uid=None):
    if r.status == "setup":
        return _setup_view(r)
    if r.status == "lobby":
        return _global_lobby_view(session, r, for_uid) if r.mode == "global" else _lobby_view(session, r)
    if r.status in ("night", "day") and for_uid is not None:
        # پنلِ خصوصیِ یه بازیکن (تو هر دو حالتِ گروهی و جهانی)
        p = _get_player(session, r.id, for_uid)
        if p:
            players = _all_players(session, r.id)
            if r.status == "day":
                return _dm_day_view(session, r, players, p)
            panel = None
            if p.alive and p.role in NIGHT_ACTION_ROLES and not (p.role == "sniper" and p.sniper_used):
                panel = _role_panel_view(session, r, players, p)
            if panel:
                return panel
            return _mafia_status_text(session, r, players, p), None
    if r.status in ("night", "day"):
        return _group_view(session, r)
    if r.status == "resolved":
        return _final_view(session, r)
    return (r.log_text or "❌ این بازی لغو شد."), None


async def _broadcast(context, session, r):
    """group: پیامِ مشترکِ گروه + (شب/روز) پنلِ خصوصیِ بازیکن‌ها. global: فقط پنلِ خصوصیِ
    هر بازیکن (به‌جز کسی که همین الان پنلِ اقدامِ‌شبش جداگونه مدیریت می‌شه - نگاه کن به
    _send_all_night_panels)."""
    if r.mode == "global":
        await _broadcast_dms(context, session, r)
        return
    if not r.message_id:
        return
    text, kb = _view(session, r)
    new_id, ok = await _edit_msg_ex(context, r.chat_id, r.message_id, text, kb)
    if new_id and new_id != r.message_id:
        r.message_id = new_id
        session.commit()
    dm_ok = True
    if r.status in ("night", "day"):
        dm_ok = await _broadcast_dms(context, session, r, schedule_retry=False)
    if (not ok or not dm_ok) and _dirty.get(r.id, 0) < 6:
        _dirty[r.id] = _dirty.get(r.id, 0) + 1
        _schedule(_resync, 4 * _dirty[r.id], context, r.id)
    elif ok and dm_ok:
        _dirty.pop(r.id, None)


async def _broadcast_dms(context, session, r, schedule_retry=True):
    """پنلِ خصوصیِ بازیکن‌ها رو (هر دو حالتِ گروهی/جهانی) ادیت می‌کنه. True یعنی همه موفق بودن."""
    players = _all_players(session, r.id)
    if r.status == "lobby":
        targets = players
    elif r.status == "night":
        # پنلِ کسایی که همین الان نقشِ‌شبِ فعال دارن جدا مدیریت می‌شه (_send_all_night_panels)؛
        # اینجا فقط بقیه (زنده‌یِ بدونِ اقدام + مرده‌ها) رو به‌روز می‌کنیم تا دوباره‌کاری/رقابت
        # رویِ همون پیام پیش نیاد.
        targets = [p for p in players
                   if not (p.alive and p.role in NIGHT_ACTION_ROLES and not (p.role == "sniper" and p.sniper_used))]
    else:
        targets = players
    results = await asyncio.gather(
        *[_send_personal_view(context, session, r, p, players) for p in targets], return_exceptions=True)
    changed = False
    failed = False
    for p, res in zip(targets, results):
        if isinstance(res, Exception):
            logger.warning("ادیتِ پنلِ شخصیِ مافیا: %s", res)
            failed = True
            continue
        ok, new_id = res
        if not ok:
            failed = True
        if new_id != p.dm_message_id:
            p.dm_message_id = new_id
            changed = True
    if changed:
        session.commit()
    if not schedule_retry:
        return not failed
    if failed and _dirty.get(r.id, 0) < 6:
        _dirty[r.id] = _dirty.get(r.id, 0) + 1
        _schedule(_resync, 4 * _dirty[r.id], context, r.id)
    elif not failed:
        _dirty.pop(r.id, None)
    return not failed


async def _send_personal_view(context, session, r, p, players):
    text, kb = _view(session, r, for_uid=p.user_id)
    new_id, ok = await _edit_msg_ex(context, p.user_id, p.dm_message_id, text, kb)
    return ok, new_id


# ---------------------------------------------------------------------------
# منو / تنظیمات / لابی (دکمه‌ها)
# ---------------------------------------------------------------------------

async def _check_owner(update, owner_id):
    if update.effective_user.id != owner_id:
        await _safe_answer(update.callback_query,
                           "⛔️ این منو مالِ تو نیست! برای بازکردنِ کازینوی خودت، بنویس «کازینو هاپویی».",
                           show_alert=True)
        return False
    return True


async def _check_initiator(update, r):
    if not r or update.effective_user.id != r.initiator_id:
        await _safe_answer(update.callback_query,
                           "⛔️ این بازی مال تو نیست! برای ساختنِ بازی خودت بنویس «کازینو هاپویی».", show_alert=True)
        return False
    return True


BUSY_MSG = "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن."


def _is_private(update):
    chat = update.effective_chat
    return bool(chat and chat.type == "private")


async def cb_mf_new(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, owner_id):
            await _safe_answer(update.callback_query, BUSY_MSG, show_alert=True)
            return
        if _is_private(update):
            text, kb = _scenario_menu_view(owner_id, mode="global", in_group=False)
        else:
            text, kb = _mode_menu_view(owner_id)
    finally:
        session.close()
    await send_response(update, text, kb)


async def cb_mf_menu(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    text, kb = casino.menu_text_and_kb(owner_id)
    await send_response(update, text, kb)


async def cb_mf_mode_menu(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    text, kb = _mode_menu_view(owner_id)
    await send_response(update, text, kb)


async def cb_mf_mode_group(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    if _is_private(update):
        await _safe_answer(update.callback_query,
                           "⛔️ لابیِ گروهی فقط تو گروه ممکنه؛ تو پیوی از لابیِ جهانی استفاده کن.", show_alert=True)
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, owner_id):
            await _safe_answer(update.callback_query, BUSY_MSG, show_alert=True)
            return
        text, kb = _scenario_menu_view(owner_id, mode="group")
    finally:
        session.close()
    await send_response(update, text, kb)


async def cb_mf_mode_global(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, owner_id):
            await _safe_answer(update.callback_query, BUSY_MSG, show_alert=True)
            return
        text, kb = _scenario_menu_view(owner_id, mode="global", in_group=not _is_private(update))
    finally:
        session.close()
    await send_response(update, text, kb)


async def cb_mf_scn(update, context):
    _, owner_id, scn = update.callback_query.data.split(":")
    owner_id = int(owner_id)
    if not await _check_owner(update, owner_id):
        return
    if scn not in SCENARIOS:
        await _safe_answer(update.callback_query, "❌ این سناریو معتبر نیست.", show_alert=True)
        return
    if _is_private(update):
        await _safe_answer(update.callback_query,
                           "⛔️ لابیِ گروهی فقط تو گروه ممکنه؛ تو پیوی از لابیِ جهانی استفاده کن.", show_alert=True)
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, owner_id):
            await _safe_answer(update.callback_query, BUSY_MSG, show_alert=True)
            return
        r = db.MafiaRound(mode="group", chat_id=update.effective_chat.id,
                          message_id=update.callback_query.message.message_id,
                          initiator_id=owner_id, status="setup", scenario=scn)
        session.add(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


async def cb_mf_gscn(update, context):
    _, owner_id, scn = update.callback_query.data.split(":")
    owner_id = int(owner_id)
    if not await _check_owner(update, owner_id):
        return
    if scn not in SCENARIOS:
        await _safe_answer(update.callback_query, "❌ این سناریو معتبر نیست.", show_alert=True)
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, owner_id):
            await _safe_answer(update.callback_query, BUSY_MSG, show_alert=True)
            return
        text, kb = _gtier_menu_view(session, owner_id, scn)
    finally:
        session.close()
    await send_response(update, text, kb)


async def cb_mf_gtier(update, context):
    _, owner_id, scn, amount = update.callback_query.data.split(":")
    owner_id, amount = int(owner_id), int(amount)
    if not await _check_owner(update, owner_id):
        return
    if scn not in SCENARIOS or amount not in GLOBAL_TIERS:
        await _safe_answer(update.callback_query, "❌ این انتخاب معتبر نیست.", show_alert=True)
        return
    text, kb = _gcount_menu_view(owner_id, scn, amount)
    await send_response(update, text, kb)


def _touch(r):
    r.last_action_at = _now()


@with_round_lock
async def cb_mf_scn_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
        owner_id = r.initiator_id
    finally:
        session.close()
    rows = [[InlineKeyboardButton(SCENARIO_TITLE[scn], callback_data=f"mf_scn2:{rid}:{scn}")] for scn in SCENARIOS]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"mf_setup:{rid}")])
    text = "🎭 سناریو رو انتخاب کن:\n\n" + "\n".join(f"{SCENARIO_TITLE[s]} — {SCENARIO_DESC[s]}" for s in SCENARIOS)
    await send_response(update, text, InlineKeyboardMarkup(rows))


@with_round_lock
async def cb_mf_scn2(update, context):
    _, rid, scn = update.callback_query.data.split(":")
    rid = int(rid)
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup" or scn not in SCENARIOS:
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        r.scenario = scn
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_mf_setup(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_mf_amt_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
        amounts = casino._preset_amounts(session)
        rows = []
        for i in range(0, len(amounts), 2):
            rows.append([InlineKeyboardButton(f"🪙 {fmt(a)}", callback_data=f"mf_amt_pick:{rid}:{a}")
                         for a in amounts[i:i + 2]])
        rows.append([InlineKeyboardButton("✏️ مبلغ دلخواه", callback_data=f"mf_amt_custom:{rid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"mf_setup:{rid}")])
    finally:
        session.close()
    await send_response(update, "💰 مبلغ ورودی رو انتخاب کن:", InlineKeyboardMarkup(rows))


@with_round_lock
async def cb_mf_amt_pick(update, context):
    _, rid, amount = update.callback_query.data.split(":")
    rid, amount = int(rid), float(amount)
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        if casino.max_bet_exceeded(session, amount):
            await _safe_answer(update.callback_query,
                               f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست.", show_alert=True)
            return
        r.entry_amount = amount
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_mf_amt_custom(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
    finally:
        session.close()
    await ask_for_input(update, context, "✏️ مبلغ ورودی دلخواه رو به عدد بفرست (مثلاً 5m یا 2b):",
                        {"type": "amount", "round_id": rid}, "mf_awaiting", cancel_callback=f"mf_amtx:{rid}")


@with_round_lock
async def cb_mf_amtx(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        context.user_data.pop("mf_awaiting", None)
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_mf_plr_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
    finally:
        session.close()
    ns = list(range(MIN_PLAYERS, MAX_PLAYERS + 1))
    rows = [[InlineKeyboardButton(f"{n} نفره", callback_data=f"mf_plr_pick:{rid}:{n}") for n in ns],
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f"mf_setup:{rid}")]]
    await send_response(update, f"👥 تعداد بازیکن رو انتخاب کن ({MIN_PLAYERS} تا {MAX_PLAYERS} نفر):",
                        InlineKeyboardMarkup(rows))


@with_round_lock
async def cb_mf_plr_pick(update, context):
    _, rid, n = update.callback_query.data.split(":")
    rid, n = int(rid), int(n)
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup" or not (MIN_PLAYERS <= n <= MAX_PLAYERS):
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        r.target_players = n
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_mf_back(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        r.status = "cancelled"
        r.ended_at = _now()
        session.commit()
        owner_id = r.initiator_id
    finally:
        session.close()
    text, kb = _mode_menu_view(owner_id)
    await send_response(update, text, kb)


@with_round_lock
async def cb_mf_cancel(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not r:
            await _safe_answer(update.callback_query, "⛔️ این بازی پیدا نشد.", show_alert=True)
            return
        if update.effective_user.id != r.initiator_id:
            await _safe_answer(update.callback_query, "⛔️ فقط سازنده‌ی بازی می‌تونه لغوش کنه!", show_alert=True)
            return
        if r.status not in ("setup", "lobby"):
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه قابلِ لغو نیست.", show_alert=True)
            return
        cancel_msg = _cancel_text(r, 0, "creator")
        _cancel_db(session, r, cancel_msg)
        session.commit()
    finally:
        session.close()
    await send_response(update, cancel_msg, None)


@with_round_lock
async def cb_mf_start(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if not (r.scenario and r.entry_amount and r.target_players):
            await _safe_answer(update.callback_query, "اول سناریو، مبلغ و تعدادِ بازیکن رو مشخص کن.", show_alert=True)
            return
        if casino.max_bet_exceeded(session, r.entry_amount):
            await _safe_answer(update.callback_query,
                               f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if (user.hop_points or 0) < r.entry_amount - 0.5:
            await _safe_answer(update.callback_query, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.MafiaPlayer(round_id=r.id, user_id=user.telegram_id, chat_id=r.chat_id))
        r.status = "lobby"
        r.lobby_opened_at = _now()
        _touch(r)
        session.commit()
        text, kb = _lobby_view(session, r)
    finally:
        session.close()
    _schedule(_lobby_timeout, LOBBY_SECONDS + 1, context, rid)
    await send_response(update, text, kb)


@with_round_lock
async def cb_mf_join(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    uid = update.effective_user.id
    q = update.callback_query
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not r or r.status != "lobby":
            await _safe_answer(q, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if _get_player(session, rid, uid):
            await _safe_answer(q, "قبلا پیوستی ✅", show_alert=True)
            return
        if casino._user_has_active_round(session, uid):
            await _safe_answer(q, BUSY_MSG, show_alert=True)
            return
        if _is_expired(r, _now()):
            await _safe_answer(q, "⏳ مهلتِ این لابی تموم شده و داره لغو می‌شه.", show_alert=True)
            return
        count = len(_all_players(session, rid))
        if count >= r.target_players:
            await _safe_answer(q, "ظرفیت این بازی تکمیله.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if (user.hop_points or 0) < r.entry_amount - 0.5:
            await _safe_answer(q, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.MafiaPlayer(round_id=rid, user_id=uid, chat_id=r.chat_id))
        _touch(r)
        session.commit()
        full = (count + 1) >= r.target_players
        await _safe_answer(q, "✅ پیوستی!")
        if full:
            await _begin_game(context, session, r)
        else:
            await _broadcast(context, session, r)
    finally:
        session.close()


@with_round_lock
async def cb_mf_leave(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    uid = update.effective_user.id
    q = update.callback_query
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not r or r.status != "lobby":
            await _safe_answer(q, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if uid == r.initiator_id:
            await _safe_answer(q, "⛔️ تو سازنده‌ی این بازی‌ای! اگه می‌خوای بیخیالش بشی، رو «❌ لغو» بزن.",
                               show_alert=True)
            return
        p = _get_player(session, rid, uid)
        if not p:
            await _safe_answer(q, "⛔️ تو عضوِ این بازی نیستی.", show_alert=True)
            return
        u = session.get(db.User, uid)
        if u and r.entry_amount:
            u.hop_points = (u.hop_points or 0) + r.entry_amount
        session.delete(p)
        _touch(r)
        session.commit()
        await _safe_answer(q, "🚪 از بازی خارج شدی؛ پولت برگشت داده شد.")
        await _broadcast(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# لابیِ جهانی
# ---------------------------------------------------------------------------

_mm_lock = None


def _get_mm_lock() -> asyncio.Lock:
    global _mm_lock
    if _mm_lock is None:
        _mm_lock = asyncio.Lock()
    return _mm_lock


def _global_join_db(session, tg_user, chat_id, scenario, amount, n):
    """(بدونِ await) نسخه‌ی مافیایِ روتین‌هایِ لابیِ جهانیِ رولت روسی: هر بازیکن
    (چه سناریو، چه مبلغ، چه تعداد یکی باشه) پولش کم می‌شه و به یه میزِ منتظرِ
    هم‌سناریو/هم‌مبلغ/هم‌تعداد وصل می‌شه (یا میزِ جدید می‌سازه)."""
    uid = tg_user.id
    if casino._user_has_active_round(session, uid):
        return BUSY_MSG, None, False
    if scenario not in SCENARIOS or n not in GLOBAL_PLAYER_TIERS or amount not in GLOBAL_TIERS:
        return "❌ این انتخاب معتبر نیست.", None, False
    if casino.max_bet_exceeded(session, amount):
        return f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست.", None, False
    user = db.get_or_create_user(session, tg_user)
    if (user.hop_points or 0) < amount - 0.5:
        return f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", None, False

    now = _now()
    table = None
    candidates = (session.query(db.MafiaRound)
                  .filter(db.MafiaRound.mode == "global", db.MafiaRound.status == "lobby",
                          db.MafiaRound.scenario == scenario, db.MafiaRound.entry_amount == amount,
                          db.MafiaRound.target_players == n)
                  .order_by(db.MafiaRound.created_at).all())
    for c in candidates:
        ref = c.lobby_opened_at or c.created_at
        if (now - ref).total_seconds() > GLOBAL_WAIT_SECONDS - GLOBAL_JOIN_MIN_REMAINING:
            continue
        if len(_all_players(session, c.id)) >= n:
            continue
        table = c
        break
    is_new = table is None
    if is_new:
        table = db.MafiaRound(mode="global", chat_id=chat_id, initiator_id=None, scenario=scenario,
                              entry_amount=amount, target_players=n, status="lobby",
                              lobby_opened_at=now, last_action_at=now)
        session.add(table)
        session.flush()
    user.hop_points -= amount
    session.add(db.MafiaPlayer(round_id=table.id, user_id=uid, chat_id=uid))
    table.last_action_at = now
    session.commit()
    return None, table.id, is_new


async def cb_mf_gjoin(update, context):
    q = update.callback_query
    _, owner_id, scn, amount, n = q.data.split(":")
    owner_id, amount, n = int(owner_id), int(amount), int(n)
    if not await _check_owner(update, owner_id):
        return
    if scn not in SCENARIOS or amount not in GLOBAL_TIERS or n not in GLOBAL_PLAYER_TIERS:
        await _safe_answer(q, "❌ این انتخاب معتبر نیست.", show_alert=True)
        return

    async with _get_mm_lock():
        session = db.get_session()
        try:
            err, rid, is_new = _global_join_db(session, update.effective_user, update.effective_chat.id, scn, amount, n)
        finally:
            session.close()
    if err:
        await _safe_answer(q, err, show_alert=True)
        return
    await _safe_answer(q, "✅ تو صفِ لابیِ جهانی هستی!")
    if is_new:
        _schedule(_lobby_timeout, GLOBAL_WAIT_SECONDS + 1, context, rid)
    await _after_join(context, rid)


async def _after_join(context, rid):
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.MafiaRound, rid)
            if not r or r.status != "lobby":
                return
            if len(_all_players(session, rid)) >= (r.target_players or 99):
                await _begin_game(context, session, r)
            else:
                await _broadcast(context, session, r)
        finally:
            session.close()


@with_round_lock
async def cb_mf_gleave(update, context):
    q = update.callback_query
    _, rid, owner_id = q.data.split(":")
    rid, owner_id = int(rid), int(owner_id)
    if update.effective_user.id != owner_id:
        await _safe_answer(q, "⛔️ این دکمه مالِ تو نیست.", show_alert=True)
        return
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not r or r.mode != "global" or r.status != "lobby":
            await _safe_answer(q, "⛔️ این لابی دیگه فعال نیست.", show_alert=True)
            return
        p = _get_player(session, rid, owner_id)
        if not p:
            await _safe_answer(q, "⛔️ تو تو این لابی نیستی.", show_alert=True)
            return
        my_chat, my_msg = p.chat_id, p.dm_message_id
        u = session.get(db.User, owner_id)
        if u and r.entry_amount:
            u.hop_points = (u.hop_points or 0) + r.entry_amount
        session.delete(p)
        session.flush()
        others = len(_all_players(session, rid))
        if others == 0:
            r.status = "cancelled"
            r.log_text = "❌ همه از لابی رفتن؛ لابی لغو شد."
            r.ended_at = _now()
        r.last_action_at = _now()
        session.commit()

        await _safe_answer(q, "🚪 منصرف شدی؛ پولت برگشت داده شد.")
        await _edit_msg(context, my_chat, my_msg, "🚪 از لابیِ جهانی خارج شدی؛ پولت برگشت داده شد.",
                        InlineKeyboardMarkup([[InlineKeyboardButton("🎰 بازگشت به کازینو",
                                                                    callback_data=f"mf_menu:{owner_id}")]]))
        if others:
            await _broadcast(context, session, r)
    finally:
        session.close()


async def mf_awaiting_handler(update, context):
    state = context.user_data.get("mf_awaiting")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return
    prompt_chat = state.get("_prompt_chat_id")
    if prompt_chat is not None and update.effective_chat.id != prompt_chat:
        return
    uid = update.effective_user.id
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, state["round_id"])
        context.user_data.pop("mf_awaiting", None)
        if not r or r.status != "setup" or r.initiator_id != uid:
            return
        parsed = parse_amount((update.message.text or "").strip())
        err = None
        if parsed is None or parsed != int(parsed) or parsed <= 0:
            err = "❌ مقدار اشتباه است (باید یه عددِ صحیحِ بزرگ‌تر از صفر باشه)."
        elif casino.max_bet_exceeded(session, parsed):
            err = f"❌ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست."
        else:
            r.entry_amount = int(parsed)
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
        if err:
            text = f"{err}\n\n{text}"
        new_id = await _edit_msg(context, r.chat_id, r.message_id, text, kb)
        if new_id and new_id != r.message_id:
            r.message_id = new_id
            session.commit()
    finally:
        session.close()
    raise ApplicationHandlerStop


# ---------------------------------------------------------------------------
# تایم‌اوتِ setup/lobby
# ---------------------------------------------------------------------------

async def _lobby_timeout(context, rid):
    async with _get_round_lock(rid):
        session = db.get_session()
        r = None
        try:
            r = session.get(db.MafiaRound, rid)
            if not r or r.status != "lobby":
                return
            players = _all_players(session, rid)
            if len(players) >= (r.target_players or 99):
                await _begin_game(context, session, r)
                return
            if not _is_expired(r, _now()):
                return
            n = len(players)
            text = _cancel_text(r, n)
            targets = _cancel_db(session, r, text)
            session.commit()
            await asyncio.gather(*[_edit_msg(context, c, m, text, None) for c, m, _u in targets],
                                 return_exceptions=True)
        finally:
            ended = bool(r) and r.status in ("resolved", "cancelled")
            session.close()
            if ended:
                _round_locks.pop(rid, None)


async def _setup_timeout(context, rid):
    async with _get_round_lock(rid):
        session = db.get_session()
        r = None
        try:
            r = session.get(db.MafiaRound, rid)
            if not r or r.status != "setup" or not _is_expired(r, _now()):
                return
            text = _cancel_text(r, 0, "inactive")
            targets = _cancel_db(session, r, text)
            session.commit()
            for chat_id, message_id, _uid in targets:
                await _edit_msg(context, chat_id, message_id, text, None)
        finally:
            ended = bool(r) and r.status in ("resolved", "cancelled")
            session.close()
            if ended:
                _round_locks.pop(rid, None)


# ---------------------------------------------------------------------------
# پیشرفتِ فاز (برایِ پنلِ گروه) + هدف‌هایِ معتبر
# ---------------------------------------------------------------------------

def _actionable_night_players(players):
    return [p for p in players if p.alive and p.role in NIGHT_ACTION_ROLES
            and not (p.role == "sniper" and p.sniper_used)]


def _night_progress(session, r, players):
    act = _actionable_night_players(players)
    done = sum(1 for p in act if p.night_target_id is not None)
    return done, len(act)


def _day_progress(session, r, players):
    alive = [p for p in players if p.alive]
    done = sum(1 for p in alive if p.day_vote_id is not None)
    return done, len(alive)


def _day_vote_tally(players):
    """{target_user_id یا None: [رای‌دهنده‌ها]} - None یعنی «رای نمی‌دم» (ابستین)."""
    alive = [p for p in players if p.alive]
    tally = {}
    for p in alive:
        if p.day_vote_id is None:
            continue
        key = None if p.day_vote_id == 0 else p.day_vote_id
        tally.setdefault(key, []).append(p)
    return tally


def _day_keyboard(session, r, players):
    alive = [p for p in players if p.alive]
    tally = _day_vote_tally(players)
    rows = []
    for p in alive:
        n = len(tally.get(p.user_id, []))
        label = f"⚖️ اعدامِ {_name(session, p.user_id)}" + (f" ({n} رای)" if n else "")
        rows.append([InlineKeyboardButton(label, callback_data=f"mf_vote:{r.id}:{r.phase_seq}:{p.user_id}")])
    ab = len(tally.get(None, []))
    rows.append([InlineKeyboardButton("🤷 رای نمی‌دم" + (f" ({ab} رای)" if ab else ""),
                                      callback_data=f"mf_vote:{r.id}:{r.phase_seq}:0")])
    return InlineKeyboardMarkup(rows)


# ---------------------------------------------------------------------------
# پنل‌هایِ خصوصیِ نقش‌ها (شب)
# ---------------------------------------------------------------------------

def _mafia_team_tally_lines(session, mafia_alive):
    votes = {}
    for p in mafia_alive:
        if p.night_target_id is None:
            key = None
        elif p.night_target_id == 0:
            key = "skip"
        else:
            key = p.night_target_id
        votes.setdefault(key, []).append(p)
    lines = []
    for key, voters in votes.items():
        if key is None:
            continue
        label = "🚫 رد کردن" if key == "skip" else _name(session, key)
        lines.append(f"• {label}: {', '.join(_name(session, v.user_id) for v in voters)}")
    return lines


def _mafia_panel(session, r, players, me):
    mafia_alive = _mafia_alive(players)
    targets = [p for p in players if p.alive and p.role != "mafia"]
    teammates = [p for p in mafia_alive if p.user_id != me.user_id]
    lines = [f"🔪 نقشِ تو: مافیا — {_phase_label(r)}"]
    if teammates:
        lines.append("هم‌تیمی‌هات: " + ", ".join(_name(session, t.user_id) for t in teammates))
    lines.append("")
    lines.append("کیو بزنیم؟ (اکثریتِ آرایِ مافیا تصمیم می‌گیره؛ تساوی = امشب کسی کشته نمی‌شه)")
    tally = _mafia_team_tally_lines(session, mafia_alive)
    if tally:
        lines += ["", "🗳 آرایِ فعلیِ تیم:"] + tally
    rows = [[InlineKeyboardButton(_name(session, t.user_id), callback_data=f"mf_act:{r.id}:{r.phase_seq}:{t.user_id}")]
            for t in targets]
    rows.append([InlineKeyboardButton("🚫 رد کردن (کسی رو نزنیم)", callback_data=f"mf_act:{r.id}:{r.phase_seq}:0")])
    return "\n".join(lines), InlineKeyboardMarkup(rows)


def _doctor_panel(session, r, players, me):
    targets = [p for p in players if p.alive]
    lines = [f"💉 نقشِ تو: دکتر — {_phase_label(r)}", "", "امشب کیو نجات بدیم؟ (می‌تونی خودتُ هم انتخاب کنی)"]
    if me.night_target_id is not None:
        who = "خودت" if me.night_target_id == me.user_id else (_name(session, me.night_target_id) if me.night_target_id else "هیچ‌کس")
        lines += ["", f"✅ الان انتخابِ تو: {who}"]
    rows = [[InlineKeyboardButton(("👤 خودت" if t.user_id == me.user_id else _name(session, t.user_id)),
                                  callback_data=f"mf_act:{r.id}:{r.phase_seq}:{t.user_id}")] for t in targets]
    rows.append([InlineKeyboardButton("🚫 رد کردن (هیچ‌کس)", callback_data=f"mf_act:{r.id}:{r.phase_seq}:0")])
    return "\n".join(lines), InlineKeyboardMarkup(rows)


def _detective_panel(session, r, players, me):
    # هر شب فقط «یک» استعلام: بعد از اولین انتخاب، دکمه‌ها بسته می‌شن و نتیجه با آیدیِ
    # هدف نوشته می‌شه (جلوگیری از استعلامِ بی‌نهایت)
    if me.night_target_id is not None:
        if me.night_target_id == 0:
            return (f"🔍 نقشِ تو: کارآگاه — {_phase_label(r)}\n\n"
                    "🚫 این شب استعلام نگرفتی."), InlineKeyboardMarkup([])
        tgt = next((x for x in players if x.user_id == me.night_target_id), None)
        who = _name(session, me.night_target_id)
        verdict = "🔴 مافیاست!" if (tgt and tgt.role == "mafia") else "🟢 بی‌گناهه."
        return (f"🔍 نقشِ تو: کارآگاه — {_phase_label(r)}\n\n"
                f"نتیجه‌ی استعلام: {who} که روش کلیک کردی {verdict}\n"
                "(هر شب فقط یک استعلام داری.)"), InlineKeyboardMarkup([])
    targets = [p for p in players if p.alive and p.user_id != me.user_id]
    lines = [f"🔍 نقشِ تو: کارآگاه — {_phase_label(r)}", "", "امشب کیو استعلام بگیریم؟"]
    rows = [[InlineKeyboardButton(_name(session, t.user_id), callback_data=f"mf_act:{r.id}:{r.phase_seq}:{t.user_id}")]
            for t in targets]
    rows.append([InlineKeyboardButton("🚫 رد کردن (این شب استعلام نگیر)", callback_data=f"mf_act:{r.id}:{r.phase_seq}:0")])
    return "\n".join(lines), InlineKeyboardMarkup(rows)


def _bodyguard_panel(session, r, players, me):
    targets = [p for p in players if p.alive and p.user_id != me.user_id]
    lines = [f"🛡 نقشِ تو: محافظ — {_phase_label(r)}", "",
             "امشب از کی محافظت کنیم؟ (اگه مافیا همونو بزنه، به‌جاش تو می‌میری)"]
    rows = [[InlineKeyboardButton(_name(session, t.user_id), callback_data=f"mf_act:{r.id}:{r.phase_seq}:{t.user_id}")]
            for t in targets]
    rows.append([InlineKeyboardButton("🚫 رد کردن (هیچ‌کس)", callback_data=f"mf_act:{r.id}:{r.phase_seq}:0")])
    return "\n".join(lines), InlineKeyboardMarkup(rows)


def _sniper_panel(session, r, players, me):
    targets = [p for p in players if p.alive and p.user_id != me.user_id]
    lines = [f"🎯 نقشِ تو: تک‌تیرانداز — {_phase_label(r)}", "",
             "فقط ۱ گلوله داری؛ شلیکت همیشه می‌کشه (چه مافیا باشه چه بی‌گناه) و نه دکتر نه محافظ جلوشو می‌گیره.",
             "امشب شلیک می‌کنی؟"]
    rows = [[InlineKeyboardButton(f"🎯 شلیک به {_name(session, t.user_id)}",
                                  callback_data=f"mf_act:{r.id}:{r.phase_seq}:{t.user_id}")] for t in targets]
    rows.append([InlineKeyboardButton("🚫 رد کردن (این شب شلیک نکن)", callback_data=f"mf_act:{r.id}:{r.phase_seq}:0")])
    return "\n".join(lines), InlineKeyboardMarkup(rows)


def _role_panel_view(session, r, players, p):
    """(text, kb) یا None (نقشی که شب‌ها اقدامی نداره، یا تک‌تیراندازی که گلوله‌ش تموم شده)."""
    panel = None
    if p.role == "mafia":
        panel = _mafia_panel(session, r, players, p)
    elif p.role == "doctor":
        panel = _doctor_panel(session, r, players, p)
    elif p.role == "detective":
        panel = _detective_panel(session, r, players, p)
    elif p.role == "bodyguard":
        panel = _bodyguard_panel(session, r, players, p)
    elif p.role == "sniper" and not p.sniper_used:
        panel = _sniper_panel(session, r, players, p)
    elif p.role == "sniper" and p.sniper_used and p.night_target_id not in (None, 0):
        panel = (f"🎯 نقشِ تو: تک‌تیرانداز — {_phase_label(r)}\n\n"
                 f"گلوله‌ت رو روی {_name(session, p.night_target_id)} خالی کردی. دیگه گلوله‌ای نداری."), \
                InlineKeyboardMarkup([])
    if panel is None:
        return None
    text, kb = panel
    # صحبت‌هایِ روزِ قبل تا آخرِ همین شب تو پنلِ نقش هم می‌مونن
    return _with_recap(session, r, text), kb


async def _send_role_panel(context, session, r, p, players) -> bool:
    panel = _role_panel_view(session, r, players, p)
    if panel is None:
        return True
    text, kb = panel
    new_id, ok = await _edit_msg_ex(context, p.user_id, p.dm_message_id, text, kb)
    if new_id != p.dm_message_id:
        p.dm_message_id = new_id
    return ok


async def _send_all_night_panels(context, session, r, players):
    actionable = _actionable_night_players(players)
    if not actionable:
        return
    results = await asyncio.gather(*[_send_role_panel(context, session, r, p, players) for p in actionable],
                                   return_exceptions=True)
    session.commit()
    for p, res in zip(actionable, results):
        if isinstance(res, Exception) or res is False:
            logger.warning("پنلِ شبِ مافیا برایِ %s نرسید", p.user_id)


async def _refresh_mafia_panels(context, session, r, players):
    mafia_alive = _mafia_alive(players)
    for m in mafia_alive:
        await _send_role_panel(context, session, r, m, players)
    session.commit()


# ---------------------------------------------------------------------------
# نقش‌دهی و شروعِ بازی
# ---------------------------------------------------------------------------

def _assign_roles(session, r, players):
    n = len(players)
    table = ROLE_TABLES[r.scenario][n]
    pool = []
    for role, cnt in table.items():
        pool += [role] * cnt
    _rng.shuffle(pool)
    order = list(players)
    _rng.shuffle(order)
    for p, role in zip(order, pool):
        p.role = role
        p.alive = True
        p.sniper_used = False
        p.night_target_id = None
        p.day_vote_id = None
        p.out_reason = None


_ROLE_EXPLAIN = {
    "mafia": "هر شب با هم‌تیمی‌هات (اگه داری) رای می‌دین کی کشته بشه؛ اکثریتِ آرا تصمیم رو می‌گیره.",
    "doctor": "هر شب می‌تونی یه نفر (حتی خودت) رو از کشته‌شدن به‌دستِ مافیا نجات بدی.",
    "detective": "هر شب می‌تونی یه نفرِ دیگه رو استعلام بگیری: مافیاست یا بی‌گناه.",
    "bodyguard": "هر شب یه نفرِ دیگه رو محافظت می‌کنی؛ اگه مافیا همونو بزنه، به‌جاش تو می‌میری و اون زنده می‌مونه.",
    "sniper": "کلِ بازی فقط ۱ گلوله داری. هر شب می‌تونی شلیک کنی (همیشه می‌کشه، نه دکتر نه محافظ جلوشو می‌گیره) یا رد کنی.",
    "psycho": ("نقشت خنثاست: هیچ اقدامِ شبونه‌ای نداری و کارآگاه بی‌گناه می‌بینتت. تنها راهِ بردنت اینه که با "
              "رای‌گیریِ روز اعدام بشی (اون‌وقت فوراً می‌بری و کلِ پاتُ تنها می‌گیری). وگرنه آخرِ بازی چیزی "
              "نمی‌گیری، حتی اگه شهر ببره."),
    "citizen": "قدرتِ خاصی نداری؛ فقط تو رای‌گیریِ روز شرکت کن و سعی کن مافیا رو پیدا کنی.",
}


def _role_reveal_text(session, r, p, players):
    lines = [f"🕵️ نقشِ تو تو این بازیِ مافیا/گرگینه ({SCENARIO_TITLE.get(r.scenario)}): {ROLE_TITLE[p.role]}", ""]
    if p.role == "mafia":
        teammates = [x for x in players if x.role == "mafia" and x.user_id != p.user_id]
        lines.append("هم‌تیمی‌هات: " + ", ".join(_name(session, t.user_id) for t in teammates)
                     if teammates else "تنها مافیایِ این بازی تویی.")
        lines.append("")
    lines.append(_ROLE_EXPLAIN[p.role])
    return "\n".join(lines)


async def _abort_unreachable(context, session, r):
    players = _all_players(session, r.id)
    _refund_all(session, r)
    r.status = "cancelled"
    text = ("❌ بازی لغو شد: حداقل یکی از بازیکن‌ها ربات رو تو پیوی استارت نکرده، پس نمی‌شد نقشش رو براش فرستاد.\n"
            "مبلغِ همه برگشت داده شد. (اول ربات رو تو پیوی /start بزنید، بعد دوباره امتحان کنید.)")
    r.log_text = text
    r.ended_at = _now()
    session.commit()
    if r.mode == "group" and r.message_id:
        await _edit_msg(context, r.chat_id, r.message_id, text, None)
    await asyncio.gather(*[_edit_msg(context, p.user_id, p.dm_message_id, text, None)
                           for p in players if p.dm_message_id], return_exceptions=True)


async def _begin_game(context, session, r):
    session.refresh(r)
    if r.status != "lobby":
        return
    players = _all_players(session, r.id)
    if len(players) < MIN_PLAYERS:
        return
    _assign_roles(session, r, players)
    session.commit()
    ok_all = True
    for p in players:
        text = _role_reveal_text(session, r, p, players)
        mid = await _try_dm(context, p.user_id, text)
        if mid is None:
            ok_all = False
        else:
            p.dm_message_id = mid
    if not ok_all:
        await _abort_unreachable(context, session, r)
        return
    session.commit()
    await _start_night(context, session, r, first=True)


# ---------------------------------------------------------------------------
# فازِ شب
# ---------------------------------------------------------------------------

async def _start_night(context, session, r, first=False):
    now = _now()
    cfg = mf_settings(session)
    r.status = "night"
    r.day_number = (r.day_number or 0) + 1
    r.phase_seq = (r.phase_seq or 0) + 1
    r.phase_started_at = now
    r.phase_deadline_at = now + datetime.timedelta(seconds=cfg["night"])
    players = _all_players(session, r.id)
    for p in players:
        p.night_target_id = None
    _log(r, "🌙 بازی شروع شد؛ شبِ اول فرا رسید." if first else f"🌙 شبِ {r.day_number} فرا رسید.")
    r.last_action_at = now
    session.commit()
    await _broadcast(context, session, r)
    await _send_all_night_panels(context, session, r, players)
    _schedule(_night_timeout, cfg["night"] + 1, context, r.id, r.phase_seq)


def _mafia_kill_target(players):
    mafia = _mafia_alive(players)
    votes = {}
    for p in mafia:
        t = p.night_target_id
        if t and t != 0:
            votes[t] = votes.get(t, 0) + 1
    if not votes:
        return None
    mx = max(votes.values())
    winners = [t for t, c in votes.items() if c == mx]
    return winners[0] if len(winners) == 1 else None


def _apply_death(session, p, reason):
    p.alive = False
    p.out_reason = f"{reason} — نقشش «{ROLE_TITLE[p.role]}» بود"


async def _maybe_resolve_night_early(context, session, r):
    session.refresh(r)
    if r.status != "night":
        return
    players = _all_players(session, r.id)
    actionable = _actionable_night_players(players)
    if actionable and all(p.night_target_id is not None for p in actionable):
        await _resolve_night(context, session, r, players)


async def _resolve_night(context, session, r, players):
    sniper = next((p for p in players if p.alive and p.role == "sniper" and p.night_target_id not in (None, 0)), None)
    doctor = next((p for p in players if p.alive and p.role == "doctor" and p.night_target_id not in (None, 0)), None)
    bodyguard = next((p for p in players if p.alive and p.role == "bodyguard" and p.night_target_id not in (None, 0)), None)
    mafia_target_id = _mafia_kill_target(players)

    dead_ids = set()

    if sniper:
        victim = next((p for p in players if p.user_id == sniper.night_target_id and p.alive), None)
        if victim:
            was_mafia = victim.role == "mafia"
            reason = ("با تیرِ تک‌تیرانداز کشته شد (هدف درست بود، مافیا بود)" if was_mafia
                      else "با تیرِ تک‌تیرانداز کشته شد (هدف اشتباه بود، بی‌گناه بود)")
            _apply_death(session, victim, reason)
            dead_ids.add(victim.user_id)
            _log(r, f"🎯 تک‌تیراندازِ گروه شلیک کرد؛ {_name(session, victim.user_id)} کشته شد "
                    f"({'مافیا بود!' if was_mafia else 'بی‌گناه بود'}).")
        else:
            _log(r, "🎯 تک‌تیراندازِ گروه شلیک کرد ولی هدف قبلش مرده بود؛ گلوله هدر رفت.")

    if mafia_target_id and mafia_target_id not in dead_ids:
        mtarget = next((p for p in players if p.user_id == mafia_target_id and p.alive), None)
        if mtarget:
            if doctor and doctor.night_target_id == mafia_target_id:
                _log(r, f"💉 دکتر جونِ {_name(session, mtarget.user_id)} رو نجات داد؛ مافیا شکست خورد.")
            elif bodyguard and bodyguard.night_target_id == mafia_target_id:
                _apply_death(session, bodyguard, f"با جونِ خودش از {_name(session, mtarget.user_id)} محافظت کرد")
                dead_ids.add(bodyguard.user_id)
                _log(r, f"🛡 محافظ به‌جایِ {_name(session, mtarget.user_id)} کشته شد.")
            else:
                _apply_death(session, mtarget, "شب به دستِ مافیا کشته شد")
                dead_ids.add(mtarget.user_id)
                _log(r, f"🔪 مافیا امشب {_name(session, mtarget.user_id)} رو زد.")
    elif mafia_target_id is None:
        alive_mafia = _mafia_alive(players)
        if alive_mafia:
            _log(r, "🔪 مافیا امشب رویِ یه نفر به توافق نرسید (یا رد کرد)؛ کسی کشته نشد.")

    if not dead_ids:
        _log(r, "🌙 این شب کسی نمرد.")

    for p in players:
        p.night_target_id = None
    r.last_action_at = _now()
    session.commit()

    winner = _check_win(players)
    if winner:
        await _finish_game(context, session, r, winner)
        return
    await _start_day(context, session, r)


async def _night_timeout(context, rid, seq):
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.MafiaRound, rid)
            if not r or r.status != "night" or (r.phase_seq or 0) != seq:
                return
            if r.phase_deadline_at and r.phase_deadline_at > _now() + datetime.timedelta(seconds=2):
                return
            players = _all_players(session, rid)
            await _resolve_night(context, session, r, players)
        finally:
            ended = session.get(db.MafiaRound, rid)
            done = bool(ended) and ended.status in ("resolved", "cancelled")
            session.close()
            if done:
                _round_locks.pop(rid, None)


# ---------------------------------------------------------------------------
# برد/باخت
# ---------------------------------------------------------------------------

def _check_win(players):
    """None یعنی بازی ادامه داره؛ وگرنه یکی از mafia/town/draw. (روانی فقط با
    اعدام‌شدنِ روز چک می‌شه - نگاه کن به cb_mf_vote/_resolve_day)."""
    mafia = _mafia_alive(players)
    town = _town_alive(players)  # شاملِ روانیِ زنده هم می‌شه
    if not mafia and not town:
        return "draw"
    if not mafia:
        return "town"
    if len(mafia) >= len(town):
        return "mafia"
    return None


async def _finish_game(context, session, r, winner_side, psycho_winner=None):
    """پرداختِ برد: هر بازمانده‌یِ تیمِ برنده {WIN_MULTIPLIER} برابرِ مبلغِ ورودیِ *خودش*
    رو می‌گیره (نه تقسیمِ پات)؛ تیمِ بازنده مبلغِ ورودیش سوخته - دقیقاً همون مدلِ
    ضریبیِ بقیه‌ی بازی‌هایِ کازینو (نگاه کن به casino.slot_payout_multiplier/تاس)."""
    players = _all_players(session, r.id)
    per_winner = (r.entry_amount or 0) * WIN_MULTIPLIER
    r.winner_side = winner_side
    r.status = "resolved"
    r.ended_at = _now()
    r.phase_seq = (r.phase_seq or 0) + 1

    if winner_side == "draw":
        _refund_all(session, r)
        _log(r, "🤝 آخرین مافیا و آخرین غیرِمافیا با هم حذف شدن؛ بازی مساوی شد و پولِ همه برگشت داده شد.")
    elif winner_side == "psycho":
        u = session.get(db.User, psycho_winner.user_id)
        if u:
            u.hop_points = (u.hop_points or 0) + per_winner
        _log(r, f"🃏 {_name(session, psycho_winner.user_id)} (روانی) با رایِ گروه اعدام شد و "
                f"{WIN_MULTIPLIER}× مبلغِ ورودیش ({fmt(per_winner)} 🪙) رو تنهایی برد!")
    else:
        if winner_side == "mafia":
            winners = [p for p in players if p.alive and p.role == "mafia"]
            side_label = "🔪 مافیا"
        else:
            winners = [p for p in players if p.alive and p.role in TOWN_ROLES]
            side_label = "🏆 شهر"
        for w in winners:
            u = session.get(db.User, w.user_id)
            if u:
                u.hop_points = (u.hop_points or 0) + per_winner
        names = "، ".join(_name(session, w.user_id) for w in winners) if winners else "—"
        _log(r, f"{side_label} بردن! هرکدوم از بازمانده‌هاشون {WIN_MULTIPLIER}× مبلغِ ورودیِ خودش "
                f"({fmt(per_winner)} 🪙) گرفت: {names}")

    session.commit()
    await _broadcast(context, session, r)
    if r.mode == "group":
        await _notify_players_final(context, session, r, players)


async def _notify_players_final(context, session, r, players):
    """پیامِ خصوصیِ هر بازیکن هم با نتیجه‌ی نهایی ادیت می‌شه (اگه پنلِ نقشش رو داشت)."""
    text, _ = _final_view(session, r)
    async def _one(p):
        if p.dm_message_id:
            await _edit_msg_ex(context, p.user_id, p.dm_message_id, text, None)
    await asyncio.gather(*[_one(p) for p in players], return_exceptions=True)


# ---------------------------------------------------------------------------
# فازِ روز (رای‌گیری)
# ---------------------------------------------------------------------------

async def _start_day_voting(context, session, r):
    """رای‌گیریِ واقعیِ اعدام. بعدِ تمومِ چرخِ نوبت‌هایِ صحبت (هر دو حالتِ گروهی/جهانی)
    شروع می‌شه. پنلِ خصوصیِ همه + پنلِ گروه (تو حالتِ گروهی) با دکمه‌هایِ رای ادیت می‌شن."""
    now = _now()
    cfg = mf_settings(session)
    r.status = "day"
    r.day_speak_active = False
    r.day_speak_message_id = None
    r.day_speak_deadline_at = None
    r.phase_seq = (r.phase_seq or 0) + 1
    r.phase_started_at = now
    r.phase_deadline_at = now + datetime.timedelta(seconds=cfg["day"])
    for p in _all_players(session, r.id):
        p.day_vote_id = None
    r.last_action_at = now
    session.commit()
    await _clear_ping(context, r.id)
    await _broadcast(context, session, r)
    _schedule(_day_timeout, cfg["day"] + 1, context, r.id, r.phase_seq)


async def _start_day(context, session, r):
    """شروعِ فازِ روز (هر دو حالتِ گروهی و جهانی): اول یه چرخِ نوبتیِ صحبت بینِ زنده‌ها
    (ترتیبِ تصادفی) راه می‌افته. هرکس نوبتش شد، تو پیویِ ربات رویِ پنلِ خودش ریپلای
    می‌کنه و حرفش رو می‌نویسه؛ حرفش تو پنلِ همه (خصوصی + گروه) نوشته می‌شه. اگه
    {day_speak} ثانیه (پیش‌فرض ۱۸۰) حرف نزنه یا «ردِ نوبت/اتمامِ صحبت» رو بزنه، نوبتش
    رد می‌شه و برایِ بقیه «حرف نزد» نوشته می‌شه. بعدِ تمومِ همه‌ی نوبت‌ها رای‌گیری شروع
    می‌شه. صحبت‌هایِ روزِ N تا آخرِ شبِ N تو پنل‌ها می‌مونن و با شروعِ روزِ N+1 پاک می‌شن.
    هیچ‌کس تو گروه ساکت/محدود نمی‌شه و عضویتِ گپ هم لازم نیست."""
    now = _now()
    r.status = "day"
    r.phase_started_at = now
    r.last_action_at = now
    for p in _all_players(session, r.id):
        p.day_vote_id = None
    alive = _alive_players(session, r.id)
    order = [p.user_id for p in alive]
    _rng.shuffle(order)
    r.day_speak_active = True
    r.day_speak_order = json.dumps(order)
    r.day_speak_index = 0
    r.day_speak_message_id = None
    r.phase_deadline_at = None
    _speeches_save(r, r.day_number or 0, [])
    session.commit()
    await _advance_day_speak(context, session, r)


def _day_speak_keyboard(rid, seq):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton("⏭ ردِ نوبت", callback_data=f"mf_dspass:{rid}:{seq}"),
        InlineKeyboardButton("➡️ اتمامِ صحبت", callback_data=f"mf_dsdone:{rid}:{seq}"),
    ]])


_ping_ids = {}   # rid -> (user_id, message_id) پیامِ «نوبتِ توئه» که آخرِ نوبت پاک می‌شه


async def _clear_ping(context, rid):
    info = _ping_ids.pop(rid, None)
    if info:
        try:
            await context.bot.delete_message(chat_id=info[0], message_id=info[1])
        except Exception:
            pass


async def _advance_day_speak(context, session, r):
    """می‌ره سراغِ اولین نفرِ *زنده‌یِ* موندنی تو صفِ نوبت‌ها؛ اگه صف تموم شده
    بود، چرخِ صحبت رو می‌بنده و رای‌گیریِ واقعی رو شروع می‌کنه."""
    order = _day_speak_order_list(r)
    idx = r.day_speak_index or 0
    while idx < len(order):
        p = _get_player(session, r.id, order[idx])
        if p and p.alive:
            break
        idx += 1
    r.day_speak_index = idx
    if idx >= len(order):
        r.day_speak_active = False
        r.day_speak_message_id = None
        session.commit()
        await _start_day_voting(context, session, r)
        return
    uid = order[idx]
    cfg = mf_settings(session)
    r.day_speak_seq = (r.day_speak_seq or 0) + 1
    r.day_speak_deadline_at = _now() + datetime.timedelta(seconds=cfg["day_speak"])
    session.commit()
    await _clear_ping(context, r.id)
    await _broadcast(context, session, r)
    # یه پیامِ کوتاه تا صاحبِ نوبت نوتیفیکیشن بگیره (ادیتِ پنل نوتیف نمی‌ده)
    mid = await _try_dm(context, uid, f"🎤 نوبتِ صحبتِ توئه! رویِ پنلِ بازیِ مافیا ریپلای کن و حرفت رو بنویس "
                                       f"({cfg['day_speak']} ثانیه وقت داری).")
    if mid:
        _ping_ids[r.id] = (uid, mid)
    _schedule(_day_speak_timeout, cfg["day_speak"] + 1, context, r.id, r.day_speak_seq)


def _clean_speech(text):
    t = " ".join((text or "").split())      # خط‌های جدید/فاصله‌هایِ اضافه → یه فاصله
    if len(t) > MAX_SPEECH_CHARS:
        t = t[:MAX_SPEECH_CHARS - 1] + "…"
    return t


async def _finish_turn(context, session, r, uid, outcome, text=""):
    """نوبتِ فعلی رو می‌بنده (ثبتِ حرف تو لیستِ صحبت‌هایِ امروز) و می‌ره سراغِ نفرِ بعد.
    outcome: 'spoke' (حرف زد) / 'skipped' (ردِ نوبت) / 'done' (اتمامِ صحبت بدونِ حرف) /
    'timeout' (تو وقتش هیچی نگفت). هر کدوم به‌جز 'spoke' با متنِ خالی ثبت می‌شن
    و تو پنل‌ها «حرف نزد» نوشته می‌شه."""
    day, items = _speeches_load(r)
    items = list(items)
    body = _clean_speech(text) if outcome == "spoke" else ""
    items.append({"u": uid, "t": body, "o": outcome})
    _speeches_save(r, r.day_number or day, items)
    r.day_speak_index = (r.day_speak_index or 0) + 1
    r.last_action_at = _now()
    session.commit()
    await _advance_day_speak(context, session, r)


async def _day_speak_timeout(context, rid, seq):
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.MafiaRound, rid)
            if not r or r.status != "day" or not r.day_speak_active or (r.day_speak_seq or 0) != seq:
                return
            if r.day_speak_deadline_at and r.day_speak_deadline_at > _now() + datetime.timedelta(seconds=2):
                return
            _order, _idx, cur = _turn_info(r)
            if cur is None:
                return
            await _finish_turn(context, session, r, cur, "timeout")
        finally:
            ended = session.get(db.MafiaRound, rid)
            done = bool(ended) and ended.status in ("resolved", "cancelled")
            session.close()
            if done:
                _round_locks.pop(rid, None)


async def _handle_day_speak_button(update, context, outcome):
    q = update.callback_query
    try:
        _, rid, seq = q.data.split(":")
        rid, seq = int(rid), int(seq)
    except ValueError:
        await _safe_answer(q)
        return
    uid = update.effective_user.id
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not r or r.status != "day" or not r.day_speak_active or (r.day_speak_seq or 0) != seq:
            await _safe_answer(q, "⛔️ این نوبت دیگه معتبر نیست.", show_alert=True)
            return
        _order, _idx, current_uid = _turn_info(r)
        if current_uid != uid:
            await _safe_answer(q, "⛔️ الان نوبتِ تو نیست.", show_alert=True)
            return
        await _safe_answer(q, "✅ ثبت شد.")
        await _finish_turn(context, session, r, uid, outcome)
    finally:
        session.close()


@with_round_lock
async def cb_mf_dspass(update, context):
    await _handle_day_speak_button(update, context, "skipped")


@with_round_lock
async def cb_mf_dsdone(update, context):
    await _handle_day_speak_button(update, context, "done")


def _current_speaker_round(session, uid):
    """دورِ مافیایی که همین الان نوبتِ صحبتِ uid ـه (یا None). هر کاربر هم‌زمان فقط
    تو یه بازیِ مافیا می‌تونه زنده باشه، پس حداکثر یکی پیدا می‌شه."""
    mine = session.query(db.MafiaPlayer.round_id).filter(db.MafiaPlayer.user_id == uid,
                                                         db.MafiaPlayer.alive == True)  # noqa: E712
    rows = (session.query(db.MafiaRound)
            .filter(db.MafiaRound.status == "day", db.MafiaRound.day_speak_active == True,  # noqa: E712
                    db.MafiaRound.id.in_(mine)).all())
    for row in rows:
        if _turn_info(row)[2] == uid:
            return row
    return None


def is_current_speaker(session, uid) -> bool:
    return _current_speaker_round(session, uid) is not None


async def handle_day_speech(update, context) -> bool:
    """پیامِ متنیِ *پیوی*: اگه فرستنده همین الان نوبتِ صحبتِ یه بازیِ مافیا (گروهی یا
    جهانی) باشه و پیامش ریپلای رویِ پنلِ بازیِ خودش باشه، متنش به‌عنوانِ صحبتِ امروزش ثبت
    می‌شه و نوبت می‌ره سراغِ نفرِ بعد - True برمی‌گردونه. غیرِ اینصورت False (پیام
    طبقِ معمول پردازش می‌شه). مستقلِ از سیستمِ awaiting."""
    chat = update.effective_chat
    user = update.effective_user
    msg = update.message
    if not chat or chat.type != "private" or not user or not msg or not getattr(msg, "text", None):
        return False
    reply = getattr(msg, "reply_to_message", None)
    if reply is None:
        return False
    uid = user.id
    session = db.get_session()
    try:
        row = _current_speaker_round(session, uid)
        if row is None:
            return False
        target_rid = row.id
    finally:
        session.close()
    async with _get_round_lock(target_rid):
        session = db.get_session()
        try:
            r = session.get(db.MafiaRound, target_rid)
            if not r or r.status != "day" or not r.day_speak_active:
                return False
            if _turn_info(r)[2] != uid:
                return False
            p = _get_player(session, target_rid, uid)
            if not p or not p.alive or not p.dm_message_id:
                return False
            if getattr(reply, "message_id", None) != p.dm_message_id:
                return False      # ریپلای رویِ یه پیامِ دیگه بوده، نه پنلِ بازی
            await _finish_turn(context, session, r, uid, "spoke", msg.text)
            return True
        finally:
            session.close()


def _tally_lynch_target(players):
    """(target_id یا None, تعدادِ رایِ اون, [تساویِ بالاترین‌ها]).
    قانون: برایِ اعدام باید رایِ هدف حداقل «نصفِ زنده‌ها» باشه (۵ نفر → ۳ رای، ۴ نفر → ۲ رای).
    «رای نمی‌دم» و کسی که رای نداده جزوِ زنده‌ها حساب می‌شن. اگه چند نفر با همین حدِ نصاب
    باهم مساوی شدن، بینشون قرعه‌کشی می‌شه. اگه هیچ‌کس به حدِ نصاب نرسید، کسی اعدام نمی‌شه."""
    alive_n = sum(1 for p in players if p.alive)
    tally = _day_vote_tally(players)
    tally.pop(None, None)
    if not tally or alive_n <= 0:
        return None, 0, []
    mx = max(len(v) for v in tally.values())
    need = (alive_n + 1) // 2          # ceil(alive/2)
    if mx == 0 or mx < need:
        return None, mx, []
    top = [t for t, v in tally.items() if len(v) == mx]
    if len(top) == 1:
        return top[0], mx, top
    return _rng.choice(top), mx, top


async def _maybe_resolve_day_early(context, session, r):
    session.refresh(r)
    if r.status != "day" or r.day_speak_active:
        return
    players = _all_players(session, r.id)
    alive = [p for p in players if p.alive]
    if alive and all(p.day_vote_id is not None for p in alive):
        await _resolve_day(context, session, r, players)


async def _resolve_day(context, session, r, players):
    target_id, votes, tied = _tally_lynch_target(players)
    for p in players:
        p.day_vote_id = None
    if target_id is None:
        _log(r, "☀️ رای‌گیری تموم شد؛ هیچ‌کس به حداقل نصفِ آرا نرسید - امروز کسی اعدام نشد.")
        r.last_action_at = _now()
        session.commit()
        await _start_night(context, session, r)
        return

    lynched = next((p for p in players if p.user_id == target_id and p.alive), None)
    if not lynched:
        _log(r, "☀️ رای‌گیری تموم شد ولی رایِ اکثریت به کسی خورد که دیگه زنده نبود؛ کسی اعدام نشد.")
        r.last_action_at = _now()
        session.commit()
        await _start_night(context, session, r)
        return

    if len(tied) > 1:
        names = " و ".join(_name(session, t) for t in tied)
        _log(r, f"🎲 قرعه شد بین {names}؛ {_name(session, lynched.user_id)} رفت بیرون (اعدام شد).")

    if lynched.role == "psycho":
        _apply_death(session, lynched, f"با رایِ گروه ({votes} رای) اعدام شد")
        r.last_action_at = _now()
        session.commit()
        await _finish_game(context, session, r, "psycho", psycho_winner=lynched)
        return

    _apply_death(session, lynched, f"با رایِ گروه ({votes} رای) اعدام شد")
    _log(r, f"⚖️ {_name(session, lynched.user_id)} با رایِ گروه اعدام شد — نقشش «{ROLE_TITLE[lynched.role]}» بود.")
    r.last_action_at = _now()
    session.commit()

    winner = _check_win(players)
    if winner:
        await _finish_game(context, session, r, winner)
        return
    await _start_night(context, session, r)


async def _day_timeout(context, rid, seq):
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.MafiaRound, rid)
            if not r or r.status != "day" or r.day_speak_active or (r.phase_seq or 0) != seq:
                return
            if r.phase_deadline_at and r.phase_deadline_at > _now() + datetime.timedelta(seconds=2):
                return
            players = _all_players(session, rid)
            await _resolve_day(context, session, r, players)
        finally:
            ended = session.get(db.MafiaRound, rid)
            done = bool(ended) and ended.status in ("resolved", "cancelled")
            session.close()
            if done:
                _round_locks.pop(rid, None)


@with_round_lock
async def cb_mf_vote(update, context):
    q = update.callback_query
    try:
        _, rid, seq, target = q.data.split(":")
        rid, seq, target = int(rid), int(seq), int(target)
    except ValueError:
        await _safe_answer(q)
        return
    uid = update.effective_user.id
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not r or r.status != "day" or (r.phase_seq or 0) != seq:
            await _safe_answer(q, "⛔️ این رای‌گیری دیگه تموم شده.", show_alert=True)
            return
        if r.day_speak_active:
            await _safe_answer(q, "⛔️ اول باید نوبتِ صحبت‌ها تموم بشه.", show_alert=True)
            return
        p = _get_player(session, rid, uid)
        if not p or not p.alive:
            await _safe_answer(q, "⛔️ تو الان تو این بازی زنده نیستی.", show_alert=True)
            return
        players = _all_players(session, rid)
        if target != 0:
            tgt = next((x for x in players if x.user_id == target and x.alive), None)
            if not tgt:
                await _safe_answer(q, "⛔️ این گزینه معتبر نیست.", show_alert=True)
                return
        p.day_vote_id = target
        r.last_action_at = _now()
        session.commit()
        await _safe_answer(q, "✅ رایت ثبت شد.")
        await _broadcast(context, session, r)
        await _maybe_resolve_day_early(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# اقدامِ شب (دکمه‌هایِ پنلِ خصوصی)
# ---------------------------------------------------------------------------

@with_round_lock
async def cb_mf_act(update, context):
    q = update.callback_query
    try:
        _, rid, seq, target = q.data.split(":")
        rid, seq, target = int(rid), int(seq), int(target)
    except ValueError:
        await _safe_answer(q)
        return
    uid = update.effective_user.id
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not r or r.status != "night" or (r.phase_seq or 0) != seq:
            await _safe_answer(q, "⛔️ این فاز دیگه تموم شده.", show_alert=True)
            return
        p = _get_player(session, rid, uid)
        if not p or not p.alive or p.role not in NIGHT_ACTION_ROLES:
            await _safe_answer(q, "⛔️ نقشِ تو تو این فاز اقدامی نداره.", show_alert=True)
            return
        if p.role == "sniper" and p.sniper_used:
            await _safe_answer(q, "⛔️ گلوله‌ت رو قبلاً استفاده کردی.", show_alert=True)
            return
        if p.role == "detective" and p.night_target_id is not None:
            await _safe_answer(q, "⛔️ این شب قبلاً استعلام گرفتی؛ هر شب فقط یک استعلام داری.", show_alert=True)
            return
        players = _all_players(session, rid)
        target_player = None
        if target != 0:
            target_player = next((x for x in players if x.user_id == target and x.alive), None)
            if not target_player:
                await _safe_answer(q, "⛔️ این هدف معتبر نیست (شاید مرده یا اشتباهه).", show_alert=True)
                return
            if target_player.user_id == p.user_id and p.role in ("detective", "bodyguard", "sniper"):
                await _safe_answer(q, "⛔️ نمی‌تونی خودت رو انتخاب کنی.", show_alert=True)
                return
            if p.role == "mafia" and target_player.role == "mafia":
                await _safe_answer(q, "⛔️ نمی‌تونی هم‌تیمی‌تُ بزنی.", show_alert=True)
                return
        p.night_target_id = target
        r.last_action_at = _now()
        if p.role == "detective" and target_player:
            # نتیجه داخلِ خودِ پنل (با آیدیِ هدف) نوشته می‌شه و دکمه‌ها بسته می‌شن
            await _safe_answer(q, "🔍 استعلام ثبت شد؛ نتیجه توی پیام نوشته شد.")
        elif p.role == "sniper" and target_player:
            p.sniper_used = True
            await _safe_answer(q, f"🎯 گلوله‌تُ رو {_name(session, target_player.user_id)} خالی کردی.")
        else:
            await _safe_answer(q, "✅ ثبت شد.")
        session.commit()
        await _send_role_panel(context, session, r, p, players)
        if p.role == "mafia":
            await _refresh_mafia_panels(context, session, r, players)
        else:
            session.commit()
        await _maybe_resolve_night_early(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# جاروبِ دوره‌ای + مسیریاب
# ---------------------------------------------------------------------------

GLOBAL_LIST_LIMIT = 10


def global_lobbies(session, limit=GLOBAL_LIST_LIMIT):
    """مثلِ roulette.global_lobbies: لابی‌هایِ جهانیِ مافیا که هنوز جا دارن.
    ترتیب: پرتر بالاتر، بینِ هم‌تعدادها زودتر بالاتر (مبلغ/سناریو نقشی نداره)."""
    now = _now()
    rows = (session.query(db.MafiaRound)
            .filter(db.MafiaRound.mode == "global", db.MafiaRound.status == "lobby").all())
    out = []
    for r in rows:
        ref = r.lobby_opened_at or r.created_at or now
        if (now - ref).total_seconds() > GLOBAL_WAIT_SECONDS - GLOBAL_JOIN_MIN_REMAINING:
            continue
        cnt = len(_all_players(session, r.id))
        if cnt <= 0 or cnt >= (r.target_players or 0):
            continue
        out.append((cnt, ref, r.id, r.scenario, r.entry_amount, r.target_players))
    out.sort(key=lambda x: (-x[0], x[1], x[2]))
    return out[:limit]


def global_lobbies_text(session):
    rows = global_lobbies(session)
    if not rows:
        return None
    lines = ["🕵️ لابی‌های جهانیِ مافیا/گرگینه که در حالِ عضوگیری‌ان:"]
    for i, (cnt, _ref, _rid, scn, amount, target) in enumerate(rows, 1):
        lines.append(f"{i}. {SCENARIO_TITLE.get(scn, scn)} {target} نفره — {fmt(amount)} 🪙 — {cnt}/{target}")
    lines.append("(لابی‌ای که پر بشه و بازیش شروع بشه از این لیست حذف می‌شه.)")
    return "\n".join(lines)


ACTIVE_STATUSES = ("setup", "lobby", "night", "day")


async def tick_mafia(session, context):
    while _lazy_edits:
        chat_id, message_id, text = _lazy_edits.pop()
        await _edit_msg(context, chat_id, message_id, text, None)

    now = _now()
    rows = (session.query(db.MafiaRound.id, db.MafiaRound.status, db.MafiaRound.phase_seq,
                          db.MafiaRound.phase_deadline_at, db.MafiaRound.day_speak_active,
                          db.MafiaRound.day_speak_seq, db.MafiaRound.day_speak_deadline_at)
            .filter(db.MafiaRound.status.in_(ACTIVE_STATUSES)).all())
    for rid, status, seq, deadline, ds_active, ds_seq, ds_deadline in rows:
        try:
            if status == "setup":
                await _setup_timeout(context, rid)
            elif status == "lobby":
                await _lobby_timeout(context, rid)
            elif status == "night" and deadline and deadline < now:
                await _night_timeout(context, rid, seq or 0)
            elif status == "day" and ds_active and ds_deadline and ds_deadline < now:
                await _day_speak_timeout(context, rid, ds_seq or 0)
            elif status == "day" and not ds_active and deadline and deadline < now:
                await _day_timeout(context, rid, seq or 0)
        except Exception:
            logger.exception("خطا در جاروبِ مافیا/گرگینه (دور %s)", rid)

    for rid, n in list(_dirty.items()):
        if n >= 12:
            _dirty.pop(rid, None)
        elif n >= 6:
            _dirty[rid] = n + 1
            try:
                await _resync(context, rid)
            except Exception:
                logger.exception("خطا در همگام‌سازیِ پنلِ مافیا (دور %s)", rid)


MF_PREFIX_MAP = {
    "mf_new": cb_mf_new,
    "mf_menu": cb_mf_menu,
    "mf_mode_menu": cb_mf_mode_menu,
    "mf_mode_group": cb_mf_mode_group,
    "mf_mode_global": cb_mf_mode_global,
    "mf_scn": cb_mf_scn,
    "mf_gscn": cb_mf_gscn,
    "mf_gtier": cb_mf_gtier,
    "mf_gjoin": cb_mf_gjoin,
    "mf_gleave": cb_mf_gleave,
    "mf_scn_menu": cb_mf_scn_menu,
    "mf_scn2": cb_mf_scn2,
    "mf_setup": cb_mf_setup,
    "mf_amt_menu": cb_mf_amt_menu,
    "mf_amt_pick": cb_mf_amt_pick,
    "mf_amt_custom": cb_mf_amt_custom,
    "mf_amtx": cb_mf_amtx,
    "mf_plr_menu": cb_mf_plr_menu,
    "mf_plr_pick": cb_mf_plr_pick,
    "mf_back": cb_mf_back,
    "mf_cancel": cb_mf_cancel,
    "mf_start": cb_mf_start,
    "mf_join": cb_mf_join,
    "mf_leave": cb_mf_leave,
    "mf_act": cb_mf_act,
    "mf_vote": cb_mf_vote,
    "mf_dspass": cb_mf_dspass,
    "mf_dsdone": cb_mf_dsdone,
}

# پیشوندهایی که دومین بخشِ callback_data شون واقعاً آی‌دیِ دورِ (rid) ـه (نه owner_id) -
# فقط همین‌ها وارد _heal_stale_panel می‌شن (برایِ owner_id-محورها معنی نداره).
_ROUND_PREFIXES = {
    "mf_scn_menu", "mf_scn2", "mf_setup", "mf_amt_menu", "mf_amt_pick", "mf_amt_custom", "mf_amtx",
    "mf_plr_menu", "mf_plr_pick", "mf_back", "mf_cancel", "mf_start", "mf_join", "mf_leave",
    "mf_act", "mf_vote", "mf_gleave",
}


async def _heal_stale_panel(update, context, prefix, data) -> bool:
    """پنلِ کهنه/مرده: اگه دور دیگه لغو/تموم شده یا فازش عوض شده، به‌جایِ فقط یه
    هشدارِ خشک، همون پیامی که کاربر روش زده رو با وضعیتِ واقعی ادیت می‌کنیم."""
    try:
        rid = int(data.split(":")[1])
    except (ValueError, IndexError):
        return False
    q = update.callback_query
    uid = update.effective_user.id
    session = db.get_session()
    try:
        r = session.get(db.MafiaRound, rid)
        if not r:
            return False
        dead = r.status in ("cancelled", "resolved")
        pre_game_prefixes = {"mf_scn_menu", "mf_scn2", "mf_setup", "mf_amt_menu", "mf_amt_pick",
                             "mf_amt_custom", "mf_amtx", "mf_plr_menu", "mf_plr_pick", "mf_back", "mf_start"}
        stale = (r.status in ("lobby", "night", "day") and prefix in pre_game_prefixes) or \
                (r.status != "night" and prefix == "mf_act") or (r.status != "day" and prefix == "mf_vote")
        if not (dead or stale):
            return False
        if prefix == "mf_amtx":
            context.user_data.pop("mf_awaiting", None)
        p = _get_player(session, rid, uid)
        if prefix in ("mf_act", "mf_vote") and not p:
            await _safe_answer(q, "⛔️ تو تو این بازی نیستی.", show_alert=True)
            return True
        await _safe_answer(q, "⛔️ این پنل کهنه بود؛ وضعیتِ واقعیِ بازی رو نشونت دادم.", show_alert=True)
        msg = q.message
        if msg is None:
            return True
        if r.status in ("night",) and p and p.alive and p.role in NIGHT_ACTION_ROLES and not (p.role == "sniper" and p.sniper_used):
            players = _all_players(session, rid)
            await _send_role_panel(context, session, r, p, players)
            session.commit()
        else:
            text, kb = _view(session, r, for_uid=uid if r.mode == "global" else None)
            await _edit_msg(context, msg.chat_id, msg.message_id, text, kb)
        return True
    finally:
        session.close()


async def mf_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = MF_PREFIX_MAP.get(prefix)
    if handler:
        if prefix in _ROUND_PREFIXES and await _heal_stale_panel(update, context, prefix, data):
            return True
        await handler(update, context)
        return True
    return False
