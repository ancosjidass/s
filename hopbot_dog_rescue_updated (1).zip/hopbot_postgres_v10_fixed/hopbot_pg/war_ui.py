# -*- coding: utf-8 -*-
"""
رابط تلگرامِ «جنگ هاپویی». فقط Request را می‌گیرد و به لایه‌ی سرویس (war_svc/war_battle/war_clan) می‌دهد.

- Group = Lobby / War Room / اعلان‌ها؛ Private = اطلاعاتِ حساس (منابع دقیق، جاسوسی، تجهیزات).
- همه‌ی callbackها: wr:<action>:<owner_id>:<arg...>  و owner باید همان کلیک‌کننده باشد.
- هر «اقدامِ خطرناک» (اخراج/ارتقا/انتقالِ مالکیت/ترک/کودتا/حمله) صفحه‌ی تأیید با توکنِ یک‌بارمصرف دارد.
"""
import datetime
import json
import logging
import secrets
import time

from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb
from telegram.ext import ApplicationHandlerStop

import db
import war_db as W
import war_svc as S
import war_battle as B
import war_clan as C
from war_svc import WarError, cf, ci, utcnow
from war_text import normalize, fmt, short, dur, bar, stars as star_s

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# Alias / Trigger
# ---------------------------------------------------------------------------
_alias_cache = {"ts": 0.0, "map": {}}


def alias_map(force=False):
    if force or time.time() - _alias_cache["ts"] > 30:
        s = db.get_session()
        try:
            _alias_cache["map"] = {a.text: a.panel for a in s.query(W.WarAlias).all()}
            _alias_cache["ts"] = time.time()
        finally:
            s.close()
    return _alias_cache["map"]


def match_trigger(text: str):
    """اگه پیام دقیقاً (بعد از نرمال‌سازی) یکی از aliasها باشه، panel رو برمی‌گردونه؛ پیام‌های عادی هرگز مچ نمی‌شن."""
    if not text or len(text) > 60:
        return None
    return alias_map().get(normalize(text))


def group_setting(session, chat_id):
    gs = session.get(W.WarGroupSetting, chat_id)
    if gs is None:
        gs = W.WarGroupSetting(chat_id=chat_id)
        session.add(gs)
        session.flush()
    return gs


# ---------------------------------------------------------------------------
# ابزارها
# ---------------------------------------------------------------------------
PANEL_LAST = {}   # (chat_id, user_id) -> (message_id, ts)  برای Reuse/Rate-limit


def cb(action, owner, *args):
    return ":".join(["wr", action, str(owner)] + [str(a) for a in args])


def B_(text, action, owner, *args):
    return Btn(text, callback_data=cb(action, owner, *args))


def back_row(owner, to="main"):
    return [B_("🔙 بازگشت", to, owner)]


def make_token(session, uid, action, payload):
    tok = secrets.token_hex(6)
    session.add(W.WarConfirm(token=tok, user_id=uid, action=action, payload=json.dumps(payload),
                             expires_at=utcnow() + datetime.timedelta(seconds=ci(session, "war_confirm_ttl_seconds", 180))))
    return tok


def consume_token(session, uid, tok, action):
    n = session.query(W.WarConfirm).filter(W.WarConfirm.token == tok, W.WarConfirm.user_id == uid, W.WarConfirm.action == action,
                                           W.WarConfirm.used == False, W.WarConfirm.expires_at > utcnow()).update(  # noqa: E712
        {"used": True}, synchronize_session=False)
    if n != 1:
        raise WarError("⌛️ این تأیید منقضی یا مصرف شده؛ دوباره از اول شروع کن.")
    return json.loads(session.get(W.WarConfirm, tok).payload or "{}")


def is_private(update):
    return update.effective_chat and update.effective_chat.type == "private"


async def send(update, text, kb=None):
    from handlers import send_response
    return await send_response(update, text, kb)


async def deep_link_button(context, text, arg):
    try:
        uname = context.bot.username
    except Exception:
        uname = None
    if not uname:
        return None
    return Btn(text, url=f"https://t.me/{uname}?start=war_{arg}")


def level_gate_error(session, uid):
    """حداقلِ سطح (lvl) لازم برای ورود به کلِ بخشِ جنگ هاپویی (پنلِ ادمین ← حداقلِ سطحِ بخش‌ها).
    اگه سطحِ کاربر کافی نباشه متنِ خطا، وگرنه None."""
    user = session.get(db.User, uid)
    if user is None:
        return None
    return db.check_module_level(session, user, "war")


def feature_gate_text(session, p, feature):
    st = S.feature_state(session, p, feature)
    if st == "unlocked":
        return None
    r = S.feature_rule(session, feature)
    if st == "locked" and r:
        return f"🔒 «{r.label}» قفله. شرط: {S.feature_missing(session, p, feature)}"
    return "🔒 این قابلیت هنوز برات باز نشده."


# ---------------------------------------------------------------------------
# ورودی متنی (از handlers.text_router)
# ---------------------------------------------------------------------------
async def handle_trigger(update, context, normalized: str):
    panel = match_trigger(normalized)
    if not panel:
        return
    uid, chat = update.effective_user.id, update.effective_chat
    session = db.get_session()
    try:
        if chat.type != "private":
            gs = group_setting(session, chat.id)
            if not gs.enabled or not gs.text_triggers or (panel in ("war_room", "attack", "clan_attack", "clan_war", "status") and not gs.war_enabled) \
                    or (panel in ("clan", "treasury", "diplomacy", "clan_war") and not gs.clan_enabled):
                session.commit()
                return
            if gs.admin_only_actions and panel == "group_settings":
                pass
        # ریت‌لیمیتِ پنل + Reuse (اسپم نشه)
        last = PANEL_LAST.get((chat.id, uid))
        if last and time.time() - last[1] < ci(session, "war_panel_cooldown_seconds", 3):
            session.commit()
            return
        gate_err = level_gate_error(session, uid)
        if gate_err:
            session.commit()
            await update.message.reply_text(gate_err)
            return
        try:
            S.get_player(session, uid)
        except WarError as e:
            await update.message.reply_text(str(e))
            session.commit()
            return
        session.commit()
        if panel == "group_settings":
            await show_group_settings(update, context, session)
            return
        msg = await render_panel(update, context, uid, panel, from_text=True)
        if msg is not None:
            PANEL_LAST[(chat.id, uid)] = (getattr(msg, "message_id", 0), time.time())
    finally:
        session.close()


async def render_panel(update, context, uid, panel, from_text=False, page=0):
    """هر Trigger پنلِ متناسبِ خودش رو باز می‌کنه (نه یه منوی یکسان برای همه)."""
    fn = {
        "main": p_main, "war_room": p_war_room, "attack": p_attack_targets, "clan_attack": p_clan_war,
        "clan_war": p_clan_war, "clan": p_clan, "history": p_history, "status": p_status, "units": p_units,
        "resources": p_resources, "xp": p_xp, "profile": p_profile, "quests": p_quests, "treasury": p_treasury,
        "diplomacy": p_diplomacy,
    }.get(panel)
    if not fn:
        return None
    session = db.get_session()
    try:
        p = S.get_player(session, uid)
        S.sync_player(session, p)
        new = S.pop_new_unlocks(session, p)
        text, kb = fn(session, context, update, p, page)
        if new:
            text = "🔓 NEW SYSTEM UNLOCKED\n" + "\n".join(f"{r.emoji} {r.label}" for r in new) + "\n\n" + text
        session.commit()
    except WarError as e:
        session.rollback()
        text, kb = str(e), None
    finally:
        session.close()
    if isinstance(kb, list):
        kb = Kb(kb)
    return await send(update, text, kb)


# ---------------------------------------------------------------------------
# پنل‌ها: هر تابع (text, keyboard_rows)
# ---------------------------------------------------------------------------
def _hdr(session, p):
    lvl, cur, need = S.level_from_xp(session, p.xp)
    return lvl, cur, need


def p_main(session, context, update, p, page=0):
    uid = p.user_id
    lvl, cur, need = _hdr(session, p)
    idx, lname = C.league_of(session, p.trophies)
    text = [f"🎮 Hāpoyi", f"", f"👤 {B.name_of(session, uid)}",
            f"⭐ سطح {lvl}  {bar(cur / need * 100 if need else 100, 8)}", f"🏅 {lname} | {p.trophies} کاپ",
            f"🏛 مقر {p.th_level}"]
    rows, hidden_hint = [], None
    items = [("profile", "👤 پروفایل", "profile"), ("xp", "⭐ XP", "xp"), ("resources", "📦 منابع", "resources"),
             ("war_room", "⚔️ اتاق جنگ", "war_room"), ("clan", "🏰 قبیله", "clan"), ("quests", "🎯 مأموریت", "quests"),
             ("achievements", "🏆 دستاورد", "ach"), ("league", "🏅 لیگ", "league")]
    row = []
    for feat, label, act in items:
        feat_key = {"profile": "war_room", "xp": "war_room", "resources": "war_room"}.get(feat, feat)
        st = S.feature_state(session, p, feat_key)
        if st == "hidden":
            r = S.feature_rule(session, feat_key)
            if r and r.hint and not hidden_hint:
                hidden_hint = r.hint
            continue
        lab = label if st == "unlocked" else f"🔒 {label.split(' ', 1)[1]}"
        row.append(B_(lab, act if st == "unlocked" else "locked", uid, feat_key))
        if len(row) == 2:
            rows.append(row)
            row = []
    if row:
        rows.append(row)
    if hidden_hint:
        text += ["", f"❓ {hidden_hint}"]
    return "\n".join(text), rows


def p_profile(session, context, update, p, page=0):
    uid = p.user_id
    lvl, cur, need = _hdr(session, p)
    A, D, mil = B.power_of(session, uid)
    cl, m = C.clan_of(session, uid)
    idx, lname = C.league_of(session, p.trophies)
    badges = "".join(session.get(W.WarAchievementDef, a.key).badge or "" for a in session.query(W.WarAchievement).filter_by(user_id=uid).all()
                     if session.get(W.WarAchievementDef, a.key))
    lines = [f"👤 {B.name_of(session, uid)} {badges}", f"⭐ سطح {lvl} ({cur:,.0f}/{need:,.0f})", f"🏛 مقر {p.th_level} | 🏅 {lname} ({p.trophies})",
             f"🪖 Military Power: {fmt(mil)}", f"🔥 Readiness: {p.readiness:.0f}%",
             f"⚔️ {p.wins} برد / {p.losses} باخت | 🛡 {p.defense_wins} دفاع | ⭐ {p.stars_total}"]
    if cl:
        lines.append(f"🏰 {cl.name} [{cl.tag}] – {C.rank_label(session, m.rank)}")
    return "\n".join(lines), [back_row(uid)]


def p_xp(session, context, update, p, page=0):
    lvl, cur, need = _hdr(session, p)
    return (f"⭐ XP شخصی\nسطح {lvl}\n{bar(cur / need * 100 if need else 100)} {cur:,.0f}/{need:,.0f}\n"
            f"مجموع: {p.xp:,.0f}"), [back_row(p.user_id)]


def p_resources(session, context, update, p, page=0):
    uid = p.user_id
    hop_cap, mat_cap = S.vault_caps(session, p)
    inc, maint = S.mine_income_ph(session, p), S.maintenance_ph(session, uid)
    user = session.get(db.User, uid)
    fmax = cf(session, "war_fuel_max", 10)
    if not is_private(update):
        # اطلاعاتِ حساسِ دقیق فقط در خصوصی؛ در گروه فقط خلاصه‌ی گرد
        text = (f"📦 منابعِ جنگ (خلاصه)\n💰 گاوصندوق ≈ {short(p.vault_hop)}\n🔩 مواد ≈ {short(p.vault_mat)}\n⛽ سوخت: {p.fuel:.0f}/{fmax:.0f}")
        rows = [[B_("💰 برداشتِ گاوصندوق", "collect", uid)], back_row(uid)]
        return text, rows
    text = (f"📦 منابع (خصوصی)\n💰 کیف‌پول: {fmt(user.hop_points)}\n🏦 گاوصندوقِ جنگ: {fmt(p.vault_hop)} / {fmt(hop_cap)}\n"
            f"🔩 مواد: {fmt(p.vault_mat)} / {fmt(mat_cap)}\n⛽ سوخت: {p.fuel:.1f}/{fmax:.0f}\n🔥 آمادگی: {p.readiness:.0f}%\n\n"
            f"📈 تولیدِ معدن: {fmt(inc)}/ساعت\n🔧 نگهداریِ تجهیزات: {fmt(maint)}/ساعت\n🔩 تولیدِ مواد: {fmt(S.mat_income_ph(session, p))}/ساعت")
    return text, [[B_("💰 برداشتِ گاوصندوق", "collect", uid)], back_row(uid)]


def p_war_room(session, context, update, p, page=0):
    uid = p.user_id
    A, D, mil = B.power_of(session, uid)
    ops = B.active_ops(session, uid)
    lvl = S.player_level(session, p)
    lines = ["⚔️ اتاق جنگ هاپویی", "", f"👤 {B.name_of(session, uid)}", f"⭐ Level: {lvl}",
             f"🔥 Readiness: {p.readiness:.0f}%", f"🪖 Military Power: {fmt(mil)}", f"⛽ سوخت: {p.fuel:.0f}/{cf(session, 'war_fuel_max', 10):.0f}"]
    if p.shield_until and p.shield_until > utcnow():
        lines.append(f"🛡 شیلد: {dur((p.shield_until - utcnow()).total_seconds())}")
    if ops:
        lines += ["", f"🛰 Active Operations: {len(ops)}/{B.max_active_ops(session, p)}"]
        for b in ops[:4]:
            lines.append(f"  #{b.id} 🛰 در جریان | هدف: {B.name_of(session, b.defender_id)} | ⏳ ≈ {dur((b.resolve_at - utcnow()).total_seconds())}")
    rows = []
    r1 = []
    if S.feature_state(session, p, "attack") != "hidden":
        r1.append(B_("🎯 حمله فردی", "attack", uid))
    if S.feature_state(session, p, "clan_war") != "hidden":
        r1.append(B_("🏰 حمله قبیله‌ای", "clan_war", uid))
    if r1:
        rows.append(r1)
    if S.feature_state(session, p, "frontier") != "hidden" and ci(session, "frontier_enabled", 1):
        rows.insert(0, [Btn("🌌 مرزهای هاپویی ✨ جدید", callback_data=f"fr:home:{uid}")])
    rows.append([B_("🛡 دفاع", "defense", uid), B_("🔧 آماده‌سازی", "prepare", uid)])
    rows.append([B_("🚀 تجهیزات", "units", uid), B_("📜 گزارش جنگ", "history", uid)])
    r3 = [B_("🏰 قبیله", "clan", uid)]
    if S.feature_state(session, p, "diplomacy") != "hidden":
        r3.append(B_("🤝 دیپلماسی", "diplomacy", uid))
    rows.append(r3)
    if ops:
        rows.append([B_("📊 جزئیاتِ عملیات‌ها", "ops", uid)])
    if S.feature_state(session, p, "spy") == "unlocked":
        rows.append([B_("🕵️ جاسوسی", "spy_menu", uid)])
    rows.append([B_("🏗 پایگاه", "base", uid), B_("🎮 پنل اصلی", "main", uid)])
    return "\n".join(lines), rows


def p_status(session, context, update, p, page=0):
    ops = B.active_ops(session, p.user_id)
    if not ops:
        return "🛰 الان هیچ عملیاتِ فعالی نداری.", [back_row(p.user_id, "war_room")]
    lines = ["⚔️ Active Operations"]
    for b in ops:
        lines += ["", f"Battle #{b.id}", "🛰 Operation In Progress", f"Target: {B.name_of(session, b.defender_id)}",
                  f"⏳ Estimated Completion: {dur((b.resolve_at - utcnow()).total_seconds())}"]
        span = max(1, (b.resolve_at - b.created_at).total_seconds())
        pct = min(99, (utcnow() - b.created_at).total_seconds() / span * 100)
        lines.append(f"{bar(pct)} {pct:.0f}%")            # فقط زمان‌بندی؛ نتیجه لو نمی‌ره
    return "\n".join(lines), [back_row(p.user_id, "war_room")]


def p_ops(session, context, update, p, page=0):
    return p_status(session, context, update, p, page)


def p_defense(session, context, update, p, page=0):
    uid = p.user_id
    lines = ["🛡 دفاع", ""]
    for d in S.bdefs(session):
        if d.kind in ("def_ground", "def_air", "wall"):
            lv = S.bld_level(session, uid, d.key)
            if lv:
                lines.append(f"{d.emoji} {d.name}: سطح {lv}")
    if p.shield_until and p.shield_until > utcnow():
        lines.append(f"🛡 شیلدِ فعال: {dur((p.shield_until - utcnow()).total_seconds())}")
    cost = round(cf(session, "war_shield_buy_ref_hours", 2) * S.player_ref(session, p), -1)
    rows = [[B_(f"🛡 خرید شیلد ({cf(session, 'war_shield_buy_hours', 12):g}h) – {short(cost)}", "shield_buy", uid)]]
    rev = B.revenge_options(session, uid)
    for b in rev[:3]:
        rows.append([B_(f"⚔️ انتقام از {B.name_of(session, b.attacker_id)}", "revenge", uid, b.id)])
    rows.append(back_row(uid, "war_room"))
    return "\n".join(lines), rows


# --------------------------- پایگاه / ساختمان‌ها ---------------------------
def p_base(session, context, update, p, page=0):
    uid = p.user_id
    blds = S.buildings_of(session, uid)
    lines = [f"🏗 پایگاه – مقر {p.th_level}", f"👷 سازنده: {S.builders_busy(session, uid)}/{S.builders_total(session, p)}", ""]
    rows = []
    for d in S.bdefs(session):
        b = blds.get(d.key)
        if b is None and p.th_level < d.unlock_th:
            if d.visible_before:
                lines.append(f"🔒 {d.emoji} {d.name} (مقر {d.unlock_th})")
            continue
        lvl = b.level if b else 0
        cap = S.building_cap(session, p, d)
        st = ""
        if b and b.upgrade_to:
            st = f" ⏳→{b.upgrade_to} ({dur((b.upgrade_finish_at - utcnow()).total_seconds())})"
        lines.append(f"{d.emoji} {d.name}: {lvl}/{cap}{st}")
        if not (b and b.upgrade_to) and lvl < cap:
            hop, mat, secs = S.building_upgrade_cost(session, d, lvl + 1)
            rows.append([B_(f"⬆️ {d.name} → {lvl + 1} | {short(hop)} 🔩{short(mat)} ⏱{dur(secs)}", "upgrade", uid, d.key)])
    rows.append(back_row(uid, "war_room"))
    return "\n".join(lines), rows


# --------------------------- تجهیزات ---------------------------
def p_units(session, context, update, p, page=0):
    uid = p.user_id
    have = S.units_of(session, uid)
    cap = S.camp_capacity(session, p)
    used = S.housing_used(session, uid)
    lines = ["🚀 تجهیزات", f"🏕 ظرفیت: {used}/{cap}"]
    for d in S.udefs(session):
        u = have.get(d.key)
        ok, miss = S.unit_unlocked(session, p, d)
        if not u and not ok and not d.visible_before:
            continue
        if u and (u.healthy or u.damaged):
            lines.append(f"{d.emoji} {d.name} (Mk {u.level}): 🟢{u.healthy} 🟡{u.damaged}")
    jobs = session.query(W.WarJob).filter_by(user_id=uid, status="queued").order_by(W.WarJob.finish_at).all()
    if jobs:
        lines.append("\n🏭 صف:")
        for j in jobs:
            d = session.get(W.WarUnitDef, j.unit_key)
            lines.append(f"  {'🔨' if j.kind == 'train' else '🔧'} {d.name if d else j.unit_key}×{j.qty} – {dur((j.finish_at - utcnow()).total_seconds())}")
    rows = [[B_("🏭 ساخت", "train_menu", uid), B_("🔧 تعمیر", "repair_menu", uid)],
            [B_("⬆️ ارتقای تجهیز", "uupg_menu", uid), B_("💰 فروش", "sell_menu", uid)]]
    if p.clan_id:
        rows.append([B_("🏰 قلعه‌ی قبیله (اهدا)", "castle", uid)])
    rows.append(back_row(uid, "war_room"))
    return "\n".join(lines), rows


def p_train_menu(session, context, update, p, page=0):
    uid = p.user_id
    lines = ["🏭 ساخت تجهیزات", f"👷 صف: {session.query(W.WarJob).filter_by(user_id=uid, status='queued').count()}/{S.queue_slots(session, p)}"]
    rows = []
    for d in S.udefs(session):
        ok, miss = S.unit_unlocked(session, p, d)
        if not ok:
            if d.visible_before:
                lines.append(f"🔒 {d.emoji} {d.name} – {miss}")
            continue
        lines.append(f"{d.emoji} {d.name} T{d.tier}: 💰{short(d.cost)} 🔩{short(d.cost_mat)} ⏱{dur(d.train_seconds)} 🏕{d.housing}")
        rows.append([B_(f"{d.emoji}×1", "train", uid, d.key, 1), B_("×5", "train", uid, d.key, 5), B_("×10", "train", uid, d.key, 10), B_("×25", "train", uid, d.key, 25)])
    rows.append(back_row(uid, "units"))
    return "\n".join(lines), rows


def p_repair_menu(session, context, update, p, page=0):
    uid = p.user_id
    lines = [f"🔧 تعمیرگاه – تخفیف {S.repair_discount(session, p) * 100:.0f}%", "نابودشده‌ها تعمیر نمی‌شن؛ باید بسازی."]
    rows = []
    for d in S.udefs(session):
        u = S.units_of(session, uid).get(d.key)
        if u and u.damaged > 0 and d.repairable:
            c, m = S.repair_cost(session, p, d, u.damaged)
            lines.append(f"{d.emoji} {d.name}: 🟡{u.damaged} → 💰{short(c)} 🔩{short(m)}")
            rows.append([B_(f"🔧 {d.name} ×1", "repair", uid, d.key, 1), B_(f"همه ({u.damaged})", "repair", uid, d.key, u.damaged)])
    if not rows:
        lines.append("\n✅ همه‌چیز سالمه.")
    rows.append(back_row(uid, "units"))
    return "\n".join(lines), rows


def p_uupg_menu(session, context, update, p, page=0):
    uid = p.user_id
    lines = ["⬆️ ارتقای تجهیز (Mk)"]
    rows = []
    for d in S.udefs(session):
        u = S.units_of(session, uid).get(d.key)
        if u and d.upgradeable and (u.healthy + u.damaged) > 0:
            tag = f"Mk{u.level}/{d.max_level}"
            if u.level < d.max_level:
                cost = d.cost * cf(session, "war_unit_upgrade_cost_mult", 3) * u.level * max(1, u.healthy + u.damaged) ** 0.5
                rows.append([B_(f"{d.emoji} {d.name} {tag} → +{d.upg_stat_pct:g}% | {short(cost)}", "uupg", uid, d.key)])
            else:
                lines.append(f"{d.emoji} {d.name}: {tag} (حداکثر)")
    rows.append(back_row(uid, "units"))
    return "\n".join(lines), rows


def p_sell_menu(session, context, update, p, page=0):
    uid = p.user_id
    rows = []
    for d in S.udefs(session):
        u = S.units_of(session, uid).get(d.key)
        if u and u.healthy > 0:
            rows.append([B_(f"{d.emoji} فروش ×1 (+{short(d.cost * d.sell_pct / 100)})", "sell", uid, d.key, 1)])
    rows.append(back_row(uid, "units"))
    return "💰 فروشِ تجهیزات (فقط سالم‌ها؛ با ضریبِ فروش)", rows


# --------------------------- مأموریت ---------------------------
def p_quests(session, context, update, p, page=0):
    uid = p.user_id
    lines = ["🎯 مأموریت‌ها"]
    rows = []
    for kind, title in (("daily", "📅 روزانه"), ("weekly", "🗓 هفتگی"), ("special", "✨ ویژه")):
        qs = S.quests_for(session, p, kind)
        if not qs:
            continue
        lines.append(f"\n{title}")
        for q, prog, claimed in qs:
            if q.kind == "special" and claimed:
                continue
            mark = "✅" if claimed else ("🎁" if prog >= q.target else "▫️")
            rw = f"⭐{q.xp:g}" + (f" 💠≈{short(q.hop_ref_hours * S.player_ref(session, p))}" if q.hop_ref_hours else "")
            lines.append(f"{mark} {q.name} [{prog}/{q.target}] {rw}")
            if prog >= q.target and not claimed:
                rows.append([B_(f"🎁 دریافت: {q.name}", "qclaim", uid, q.key)])
    rows.append(back_row(uid))
    return "\n".join(lines), rows


def p_ach(session, context, update, p, page=0):
    uid = p.user_id
    lines = ["🏆 دستاوردها"]
    for a in session.query(W.WarAchievementDef).filter_by(enabled=True).all():
        got = S.has_achievement(session, uid, a.key)
        val = S.metric_get(session, uid, a.metric)
        lines.append(f"{'✅' if got else '▫️'} {a.emoji} {a.name} – {min(val, a.threshold):.0f}/{a.threshold}")
    return "\n".join(lines), [back_row(uid)]


def p_league(session, context, update, p, page=0):
    uid = p.user_id
    lines = ["🏅 لیگ", ""]
    idx, name = C.league_of(session, p.trophies)
    lines.append(f"جایگاهِ تو: {name} ({p.trophies} کاپ)")
    lines.append("\n🥇 برترین‌ها:")
    for i, row in enumerate(session.query(W.WarPlayer).order_by(W.WarPlayer.trophies.desc()).limit(10).all(), 1):
        lines.append(f"{i}. {B.name_of(session, row.user_id)} – {row.trophies}")
    return "\n".join(lines), [back_row(uid)]


# --------------------------- حمله فردی ---------------------------
def p_attack_targets(session, context, update, p, page=0):
    uid = p.user_id
    gate = feature_gate_text(session, p, "attack")
    if gate:
        return gate, [back_row(uid, "war_room")]
    ts = B.find_targets(session, p, limit=ci(session, "war_page_size", 5) * 3)
    ps = ci(session, "war_page_size", 5)
    pages = max(1, (len(ts) + ps - 1) // ps)
    page = max(0, min(page, pages - 1))
    scout = round(cf(session, "war_scout_cost_ref_hours", 0.05) * S.player_ref(session, p), -1)
    lines = ["🎯 اهداف پیشنهادی", ""]
    rows = []
    if not ts:
        lines.append("هدفِ مناسبی الان پیدا نشد؛ کمی بعد دوباره امتحان کن.")
    for t in ts[page * ps:(page + 1) * ps]:
        tag = f"[{t['clan']}] " if t["clan"] else ""
        lines += [f"{tag}{t['name']} (🏛{t['th']} 🏅{t['trophies']})", f"Power ≈ {short(t['power_lo'])} – {short(t['power_hi'])}",
                  f"Potential Loot: {t['loot']} | Risk: {t['risk']}", ""]
        rows.append([B_(f"🎯 {t['name'][:18]}", "tgt", uid, t["user_id"])])
    if pages > 1:
        rows.append([B_("◀️", "attack_p", uid, max(0, page - 1)), Btn(f"{page + 1}/{pages}", callback_data="wr:noop:0"), B_("▶️", "attack_p", uid, min(pages - 1, page + 1))])
    rows.append([B_("🔄 اهدافِ جدید", "attack", uid)])
    rows.append(back_row(uid, "war_room"))
    return "\n".join(lines), rows


def p_target(session, context, update, p, page=0, target_id=None):
    uid = p.user_id
    tp = session.get(W.WarPlayer, target_id)
    if not tp:
        raise WarError("هدف پیدا نشد.")
    A, D, mil = B.power_of(session, target_id)
    err = B.info_error_pct(session, p) / 100.0
    f = B.fuzz(uid, target_id, utcnow().strftime("%Y-%m-%d"), err)
    lines = [f"🎯 {B.name_of(session, target_id)}", f"🏛 مقر {tp.th_level} | 🏅 {tp.trophies}", f"Power ≈ {short(mil * f * (1 - err / 2))} – {short(mil * f * (1 + err / 2))}",
             "", "نوعِ عملیات رو انتخاب کن:"]
    rows = []
    for bt in session.query(W.WarBattleType).filter_by(enabled=True).order_by(W.WarBattleType.sort).all():
        if bt.key == "clanwar":
            continue
        if S.feature_state(session, p, bt.unlock_feature or "attack") != "unlocked":
            if S.feature_state(session, p, bt.unlock_feature or "attack") == "locked":
                lines.append(f"🔒 {bt.emoji} {bt.name}")
            continue
        cost = round(bt.cost_ref_hours * S.player_ref(session, p), -1)
        rows.append([B_(f"{bt.emoji} {bt.name} | {short(cost)} ⛽{bt.fuel:g} ⏱{dur(bt.min_seconds)}-{dur(bt.max_seconds)}", "compose", uid, target_id, bt.key)])
    rows.append(back_row(uid, "attack"))
    return "\n".join(lines), rows


def _comp_state(context, uid, target_id, btype):
    st = context.user_data.get("war_comp")
    if not st or st.get("t") != target_id or st.get("b") != btype or st.get("mode") != context.user_data.get("war_comp_mode"):
        st = None
    return st


def p_compose(session, context, update, p, page=0, target_id=None, btype=None, mode="normal", extra=None):
    uid = p.user_id
    st = context.user_data.get("war_comp")
    if not st or st.get("t") != target_id or st.get("b") != btype or st.get("x") != (extra or 0):
        st = {"t": target_id, "b": btype, "x": extra or 0, "q": B.default_composition(session, uid, "all"), "ho": True, "mode": mode}
        context.user_data["war_comp"] = st
    bt = session.get(W.WarBattleType, btype)
    have = S.units_of(session, uid)
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    lines = [f"{bt.emoji} {bt.name} ← {B.name_of(session, target_id)}", "ترکیبِ نیروها:"]
    rows = []
    for k, d in defs.items():
        u = have.get(k)
        if not u or (d.atk <= 0 and d.special_power <= 0):
            continue
        avail = u.healthy if st["ho"] else u.healthy + u.damaged
        q = min(st["q"].get(k, 0), avail)
        st["q"][k] = q
        rows.append([B_("➖", "cq", uid, k, -1), Btn(f"{d.emoji} {d.name}: {q}/{avail}", callback_data="wr:noop:0"), B_("➕", "cq", uid, k, 1)])
    army = B.materialize(session, uid, st["q"], st["ho"])
    lines.append(f"🏕 ظرفیتِ اعزام: {B.army_housing(session, army)} | 🩹 با آسیب‌دیده‌ها: {'خیر' if st['ho'] else 'بله'}")
    rows.append([B_("🪖 همه", "cpre", uid, "all"), B_("⚖️ نیمی", "cpre", uid, "half"), B_("🩹 تغییرِ آسیب‌دیده", "cho", uid)])
    rows.append([B_("✅ ادامه", "cprev", uid), B_("🔙", "tgt" if mode == "normal" else "cw_targets", uid, target_id) if mode == "normal" else B_("🔙", "clan_war", uid)])
    return "\n".join(lines), rows


def p_preview(session, context, update, p, page=0):
    uid = p.user_id
    st = context.user_data.get("war_comp")
    if not st:
        raise WarError("جلسه‌ی انتخاب منقضی شد.")
    bt = session.get(W.WarBattleType, st["b"])
    army = B.materialize(session, uid, st["q"], st["ho"])
    cost = 0 if bt.key == "clanwar" else round(bt.cost_ref_hours * S.player_ref(session, p), -1)
    hop_cap, _ = S.vault_caps(session, p)
    lines = ["⚠️ هزینه‌ی عملیات:", f"💰 {fmt(cost)}", f"⛽ {bt.fuel:g} Fuel", f"🔥 آمادگی الان: {p.readiness:.0f}%", f"⏱ مدت: {dur(bt.min_seconds)} تا {dur(bt.max_seconds)}",
             "", "نیروهای اعزامی:"]
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    for k, v in army.items():
        lines.append(f"  {defs[k].emoji} {defs[k].name}: 🟢{v['h']} 🟡{v['d']}")
    if p.vault_hop > 0.8 * hop_cap:
        lines.append("\n📌 گاوصندوقت تقریباً پره؛ غنیمت هدر می‌ره. اول برداشت کن!")
    if p.readiness < 50:
        lines.append("\n⚠️ آمادگیت پایینه؛ قدرتِ ارتش کم می‌شه. شاید بهتره اول آماده‌سازی کنی.")
    tok = make_token(session, uid, "attack", {"t": st["t"], "b": st["b"], "q": st["q"], "ho": st["ho"], "mode": st.get("mode", "normal"), "x": st.get("x", 0)})
    rows = [[B_("✅ تأیید", "attack_go", uid, tok), B_("❌ لغو", "war_room", uid)]]
    return "\n".join(lines), rows


# --------------------------- گزارش‌ها ---------------------------
def p_history(session, context, update, p, page=0):
    uid = p.user_id
    ps = ci(session, "war_page_size", 5)
    q = session.query(W.WarBattle).filter((W.WarBattle.attacker_id == uid) | (W.WarBattle.defender_id == uid)).order_by(W.WarBattle.id.desc())
    total = q.count()
    pages = max(1, (total + ps - 1) // ps)
    page = max(0, min(page, pages - 1))
    lines = ["📜 Battle History", ""]
    rows = []
    for b in q.offset(page * ps).limit(ps).all():
        me_atk = b.attacker_id == uid
        opp = B.name_of(session, b.defender_id if me_atk else b.attacker_id)
        if b.status != "resolved":
            res = "🛰"
        elif b.outcome == "draw":
            res = "🤝"
        else:
            res = "🏆" if (b.outcome == "attacker") == me_atk else "💔"
        lines.append(f"#{b.id} {res} {'⚔️' if me_atk else '🛡'} {opp} {star_s(b.stars) if b.status == 'resolved' else ''}")
        rows.append([B_(f"📜 #{b.id}", "report", uid, b.id)])
    if not total:
        lines.append("هنوز نبردی ثبت نشده.")
    if pages > 1:
        rows.append([B_("◀️", "history_p", uid, max(0, page - 1)), Btn(f"{page + 1}/{pages}", callback_data="wr:noop:0"), B_("▶️", "history_p", uid, min(pages - 1, page + 1))])
    rows.append(back_row(uid, "war_room"))
    return "\n".join(lines), rows


def p_spy_menu(session, context, update, p, page=0):
    uid = p.user_id
    S.require_feature(session, p, "spy")
    cost = round(cf(session, "war_spy_cost_ref_hours", 0.3) * S.player_ref(session, p), -1)
    ts = B.find_targets(session, p, limit=5)
    rows = [[B_(f"🕵️ {t['name'][:16]} ({short(cost)})", "spy", uid, t["user_id"])] for t in ts]
    rows.append(back_row(uid, "war_room"))
    return f"🕵️ جاسوسی\nاطلاعات تقریبی‌ان؛ با رادار/تحقیق دقیق‌تر می‌شن.\nهزینه: {fmt(cost)}", rows


# ---------------------------------------------------------------------------
# قبیله
# ---------------------------------------------------------------------------
def p_clan(session, context, update, p, page=0):
    uid = p.user_id
    gate = feature_gate_text(session, p, "clan")
    if gate:
        return gate, [back_row(uid)]
    cl, m = C.clan_of(session, uid)
    if not cl:
        return _clan_join_screen(session, p)
    cnt = C.member_count(session, cl.id)
    cap = C.capacity(session, cl)
    need_xp = C.clan_xp_required(session, cl.level)
    lines = [f"🏰 {cl.name} [{cl.tag}]", f"سطح {cl.level} | {bar(cl.xp / need_xp * 100 if need_xp else 100, 8)} {cl.xp:,.0f}/{need_xp:,.0f} XP",
             f"👥 اعضا: {cnt}/{cap} (سقف {ci(session, 'war_clan_max_members', 25)})", f"🎖 رتبه‌ی تو: {C.rank_label(session, m.rank)}",
             f"🏦 خزانه: {short(cl.treasury)}"]
    if cl.description:
        lines.append(f"📝 {cl.description}")
    war = C.active_war_of(session, cl.id)
    if war:
        lines.append(f"⚔️ جنگِ #{war.id}: {'آماده‌سازی' if war.status == 'prep' else 'فعال'}")
    rows = [[B_("👥 اعضا", "cmembers", uid, 0), B_("🏦 خزانه", "treasury", uid)]]
    if C.can(session, m, "view_requests"):
        n = len(C.pending_requests(session, cl.id))
        rows.append([B_(f"📥 درخواست‌ها ({n})", "creqs", uid, 0)])
    r = []
    if S.feature_state(session, p, "clan_war") != "hidden":
        r.append(B_("⚔️ جنگ قبیله", "clan_war", uid))
    if S.feature_state(session, p, "clan_research") == "unlocked":
        r.append(B_("🔬 تحقیقات", "research", uid))
    if r:
        rows.append(r)
    r = []
    if S.feature_state(session, p, "diplomacy") == "unlocked":
        r.append(B_("🤝 دیپلماسی", "diplomacy", uid))
    r.append(B_("📜 تاریخچه", "clog", uid))
    rows.append(r)
    if C.can(session, m, "edit"):
        rows.append([B_("⚙️ تنظیماتِ قبیله", "csettings", uid)])
    if S.feature_state(session, p, "coup") == "unlocked" and m.rank < C.LEADER_RANK:
        rows.append([B_("🚨 کودتا", "coup", uid)])
    rows.append([B_("🚪 ترکِ قبیله", "leave_ask", uid)] if m.rank < C.LEADER_RANK else [B_("🚪 ترک/انحلال", "leave_ask", uid)])
    rows.append(back_row(uid))
    return "\n".join(lines), rows


def _clan_join_screen(session, p):
    uid = p.user_id
    lines = ["🏰 قبیله", "هنوز عضوِ هیچ قبیله‌ای نیستی.", "", "✨ قبیله‌های پیشنهادی:"]
    rows = []
    sug = C.suggest_clans(session, p)
    if not sug:
        lines.append("— فعلاً قبیله‌ی مناسبی پیدا نشد؛ خودت بساز یا جستجو کن.")
    for c, cnt in sug:
        lines.append(f"• [{c.tag}] {c.name} | سطح {c.level} | 👥 {cnt}/{C.capacity(session, c)} | حداقل 🏅{c.min_trophies}")
        rows.append([B_(f"🔎 [{c.tag}] {c.name}", "cview", uid, c.id)])
    mine = C.my_requests(session, uid)
    if mine:
        lines.append(f"\n📤 درخواست‌های بازِ تو: {len(mine)}")
        rows.append([B_("📤 درخواست‌هام", "myreqs", uid)])
    rows.append([B_("🔍 جستجو", "csearch", uid), B_("➕ ساختِ قبیله", "ccreate", uid)])
    rows.append(back_row(uid))
    return "\n".join(lines), rows


def p_cview(session, context, update, p, page=0, clan_id=None):
    uid = p.user_id
    c = session.get(W.WarClan, clan_id)
    if not c or c.disbanded:
        raise WarError("قبیله پیدا نشد.")
    cnt = C.member_count(session, c.id)
    lines = [f"🏰 [{c.tag}] {c.name}", f"سطح {c.level} | 👥 {cnt}/{C.capacity(session, c)}", f"شرط: 🏅≥{c.min_trophies} | سطح≥{c.min_level}",
             f"📝 {c.description or '—'}", f"👑 {B.name_of(session, c.leader_id)}"]
    rows = []
    if not p.clan_id:
        rows.append([B_("📤 ارسالِ درخواست", "creq_send", uid, c.id)])
    rows.append(back_row(uid, "clan"))
    return "\n".join(lines), rows


def p_cmembers(session, context, update, p, page=0):
    uid = p.user_id
    cl, m = C.clan_of(session, uid)
    if not cl:
        raise WarError("عضوِ قبیله‌ای نیستی.")
    mem = C.members_list(session, cl.id)
    ps = ci(session, "war_page_size", 5) + 2
    pages = max(1, (len(mem) + ps - 1) // ps)
    page = max(0, min(page, pages - 1))
    lines = [f"👥 اعضای {cl.name}: {len(mem)}/{C.capacity(session, cl)}", ""]
    rows = []
    for x in mem[page * ps:(page + 1) * ps]:
        info = C.applicant_card(session, x.user_id)
        lines.append(f"{C.rank_label(session, x.rank)} {info['name']} | سطح {info['level']} | 🏅{info['trophies']} | مشارکت {x.contribution:.0f}")
        if x.user_id != uid and (m.rank >= C.LEADER_RANK or C.can_kick(session, m, x)):
            rows.append([B_(f"⚙️ {info['name'][:20]}", "mmanage", uid, x.user_id)])
    if pages > 1:
        rows.append([B_("◀️", "cmembers", uid, max(0, page - 1)), Btn(f"{page + 1}/{pages}", callback_data="wr:noop:0"), B_("▶️", "cmembers", uid, min(pages - 1, page + 1))])
    rows.append(back_row(uid, "clan"))
    return "\n".join(lines), rows


def p_mmanage(session, context, update, p, page=0, target_id=None):
    uid = p.user_id
    cl, m = C.clan_of(session, uid)
    tm = C.member_of(session, target_id)
    if not tm or tm.clan_id != cl.id:
        raise WarError("این نفر عضوِ قبیله‌ت نیست.")
    info = C.applicant_card(session, target_id)
    lines = [f"⚙️ {info['name']}", f"{C.rank_label(session, tm.rank)} | سطح {info['level']} | 🏅{info['trophies']}", f"مشارکت: {tm.contribution:.0f} | عضو از {tm.joined_at:%Y-%m-%d}"]
    rows = []
    if m.rank >= C.LEADER_RANK:
        names = C.rank_names(session)
        row = []
        for r in range(1, 5):
            if r != tm.rank:
                row.append(B_(f"{C.RANK_EMOJI[r]} {names[r - 1]}", "rank_ask", uid, target_id, r))
        rows.append(row[:2])
        if len(row) > 2:
            rows.append(row[2:])
        rows.append([B_("👑 انتقالِ مالکیت", "xfer_ask", uid, target_id)])
    if C.can_kick(session, m, tm):
        rows.append([B_("🚫 اخراج", "kick_ask", uid, target_id)])
    rows.append(back_row(uid, "cmembers"))
    return "\n".join(lines), rows


def _confirm_screen(session, uid, text, action, payload, back="clan"):
    tok = make_token(session, uid, action, payload)
    return f"⚠️ مطمئنی؟\n\n{text}", [[B_("✅ بله، مطمئنم", "cfm", uid, action, tok), B_("❌ انصراف", back, uid)]]


def p_creqs(session, context, update, p, page=0):
    uid = p.user_id
    cl, m = C.clan_of(session, uid)
    C.need(session, m, "view_requests")
    reqs = C.pending_requests(session, cl.id)
    lines = [f"📥 درخواست‌های عضویت ({len(reqs)})", f"👥 {C.member_count(session, cl.id)}/{C.capacity(session, cl)}", ""]
    rows = []
    can_decide = C.can(session, m, "accept_requests")
    for r in reqs[:8]:
        a = C.applicant_card(session, r.user_id)
        lines.append(f"• {a['name']} | سطح {a['level']} | 🏛{a['th']} | 🏅{a['trophies']} | ⚔️{a['wins']} برد | ⭐{a['stars']} | 🏆{a['ach']}")
        if r.message:
            lines.append(f"  💬 {r.message}")
        if can_decide:
            rows.append([B_(f"✅ {a['name'][:12]}", "req_ok", uid, r.id), B_("❌", "req_no", uid, r.id)])
    if not reqs:
        lines.append("درخواستی نیست.")
    if not can_decide:
        lines.append("\n(فقط رتبه‌ی بالاتر می‌تونه قبول/رد کنه)")
    rows.append(back_row(uid, "clan"))
    return "\n".join(lines), rows


def p_treasury(session, context, update, p, page=0):
    uid = p.user_id
    cl, m = C.clan_of(session, uid)
    if not cl:
        raise WarError("عضوِ قبیله‌ای نیستی.")
    r1 = S.player_ref(session, p)
    lines = [f"🏦 خزانه‌ی {cl.name}", f"موجودی: {fmt(cl.treasury)} / {short(C.treasury_cap(session, cl))}", f"مشارکتِ تو: {m.contribution:.0f} (این هفته {m.week_contribution:.0f})",
             f"📆 تسویه‌ی بعدی: {dur(max(0, (cl.last_settlement_at + datetime.timedelta(days=cf(session, 'war_settle_days', 7)) - utcnow()).total_seconds()))}",
             f"(فقط {cf(session, 'war_settle_pool_pct', 20):g}% خزانه در هر تسویه بینِ اعضا پخش می‌شه)", "", "کمک به خزانه:"]
    rows = [[B_(f"➕ {short(r1 * h)}", "deposit", uid, int(r1 * h)) for h in (0.25, 1, 4)]]
    rows.append([B_("✏️ مبلغِ دلخواه", "deposit_ask", uid)])
    rows.append([B_("🧾 تراکنش‌ها", "ctx", uid)])
    rows.append(back_row(uid, "clan"))
    return "\n".join(lines), rows


def p_clog(session, context, update, p, page=0):
    cl, m = C.clan_of(session, p.user_id)
    if not cl:
        raise WarError("عضوِ قبیله‌ای نیستی.")
    lines = ["📜 تاریخچه‌ی قبیله"] + [f"{r.created_at:%m-%d %H:%M} {r.text}" for r in session.query(W.WarClanLog).filter_by(clan_id=cl.id).order_by(W.WarClanLog.id.desc()).limit(12).all()]
    return "\n".join(lines), [back_row(p.user_id, "clan")]


def p_ctx(session, context, update, p, page=0):
    cl, m = C.clan_of(session, p.user_id)
    C.need(session, m, "withdraw_log")
    lines = ["🧾 تراکنش‌های خزانه"] + [f"{r.created_at:%m-%d %H:%M} {r.type} {r.amount:+,.0f} ({B.name_of(session, r.user_id) if r.user_id else 'سیستم'})"
                                     for r in session.query(W.WarClanTx).filter_by(clan_id=cl.id).order_by(W.WarClanTx.id.desc()).limit(12).all()]
    return "\n".join(lines), [back_row(p.user_id, "treasury")]


def p_csettings(session, context, update, p, page=0):
    uid = p.user_id
    cl, m = C.clan_of(session, uid)
    C.need(session, m, "edit")
    lines = ["⚙️ تنظیمات", f"ورود: {'با درخواست' if cl.join_mode == 'request' else 'بسته'}", f"حداقل کاپ: {cl.min_trophies} | حداقل سطح: {cl.min_level}"]
    rows = [[B_("🔁 حالتِ ورود", "cs_mode", uid)], [B_("🏅 حداقل کاپ", "cs_set", uid, "trophies"), B_("⭐ حداقل سطح", "cs_set", uid, "level")],
            [B_("📝 توضیح", "cs_set", uid, "desc")]]
    if not is_private(update):
        rows.append([B_("📣 ثبتِ این گروه برای اعلان‌ها", "cs_announce", uid)])
    rows.append(back_row(uid, "clan"))
    return "\n".join(lines), rows


def p_research(session, context, update, p, page=0):
    uid = p.user_id
    cl, m = C.clan_of(session, uid)
    S.require_feature(session, p, "clan_research")
    st = C.research_state(session, cl.id)
    lines = ["🔬 تحقیقاتِ قبیله (هزینه از خزانه)", ""]
    rows = []
    for d in session.query(W.WarResearchDef).filter_by(enabled=True).all():
        r = st.get(d.key)
        lv = r.level if r else 0
        busy = f" ⏳{dur((r.upgrade_finish_at - utcnow()).total_seconds())}" if r and r.upgrade_finish_at else ""
        cost, mins = C.research_cost(session, cl, d, lv)
        lines.append(f"{d.branch}: {d.name} {lv}/{d.max_level} (+{lv * d.effect_per_level:g}%){busy}")
        if lv < d.max_level and cl.level >= d.req_clan_level and C.can(session, m, "research") and not busy:
            rows.append([B_(f"⬆️ {d.name} | {short(cost)} ⏱{dur(mins * 60)}", "rsrch", uid, d.key)])
    rows.append(back_row(uid, "clan"))
    return "\n".join(lines), rows


def p_diplomacy(session, context, update, p, page=0):
    uid = p.user_id
    gate = feature_gate_text(session, p, "diplomacy")
    if gate:
        return gate, [back_row(uid)]
    cl, m = C.clan_of(session, uid)
    if not cl:
        raise WarError("اول باید عضوِ یه قبیله باشی.")
    icon = {"ally": "🤝 هم‌پیمان", "truce": "🕊 آتش‌بس", "enemy": "⚔️ دشمن", "pending_ally": "⏳ پیشنهادِ پیمان", "pending_truce": "⏳ پیشنهادِ آتش‌بس"}
    lines = ["🤝 دیپلماسی", ""]
    rows = []
    for r, oc in C.relations_of(session, cl.id):
        lines.append(f"{icon.get(r.kind, r.kind)}: [{oc.tag}] {oc.name} ({r.score:+d})")
        if r.kind.startswith("pending_") and r.proposer != cl.id and C.can(session, m, "diplomacy"):
            rows.append([B_(f"✅ {oc.tag}", "rel_ok", uid, r.id), B_("❌", "rel_no", uid, r.id)])
        elif r.kind in ("ally", "truce", "enemy") and C.can(session, m, "diplomacy"):
            rows.append([B_(f"✂️ پایان با {oc.tag}", "rel_break", uid, oc.id)])
    if len(lines) == 2:
        lines.append("رابطه‌ای نداری.")
    if C.can(session, m, "diplomacy"):
        rows.append([B_("➕ پیشنهادِ رابطه", "rel_new", uid)])
    rows.append(back_row(uid, "clan"))
    return "\n".join(lines), rows


def p_castle(session, context, update, p, page=0):
    uid = p.user_id
    cl, m = C.clan_of(session, uid)
    if not cl:
        raise WarError("عضوِ قبیله‌ای نیستی.")
    lines = ["🏰 قلعه‌ی قبیله", "درخواستِ نیرو از هم‌قبیله‌ای‌ها:", ""]
    rows = []
    for r in C.open_requests(session, cl.id, exclude_uid=uid):
        d = session.get(W.WarUnitDef, r.unit_key)
        lines.append(f"• {B.name_of(session, r.requester_id)}: {d.emoji if d else ''}{d.name if d else r.unit_key} {r.filled}/{r.qty}")
        rows.append([B_(f"🎁 اهدا ×1 → {B.name_of(session, r.requester_id)[:12]}", "don", uid, r.id, 1), B_("×5", "don", uid, r.id, 5)])
    rows.append([B_("🙋 درخواستِ نیرو", "don_req", uid)])
    rows.append(back_row(uid, "units"))
    return "\n".join(lines), rows


# --------------------------- جنگ قبیله ---------------------------
def p_clan_war(session, context, update, p, page=0):
    uid = p.user_id
    gate = feature_gate_text(session, p, "clan_war")
    if gate:
        return gate, [back_row(uid, "war_room")]
    cl, m = C.clan_of(session, uid)
    if not cl:
        raise WarError("اول باید عضوِ یه قبیله باشی.")
    war = C.active_war_of(session, cl.id)
    if not war:
        left = ""
        if cl.war_search_until and cl.war_search_until > utcnow():
            left = f"\n🔎 در حالِ جستجو ({cl.war_search_size} نفره) – {dur((cl.war_search_until - utcnow()).total_seconds())}"
        lines = ["🏰 Clan War", "الان جنگی نداری." + left]
        rows = []
        if C.can(session, m, "start_war"):
            if cl.war_search_until and cl.war_search_until > utcnow():
                rows.append([B_("🛑 لغو جستجو", "cw_cancel", uid)])
            else:
                rows.append([B_(f"🔎 جستجوی جنگ {n} نفره", "cw_search", uid, n) for n in (3, 5, 10) if n <= ci(session, "war_cw_max_size", 10)])
        rows.append(back_row(uid, "clan"))
        return "\n".join(lines), rows
    enemy_id = war.clan_b if war.clan_a == cl.id else war.clan_a
    en = session.get(W.WarClan, enemy_id)
    mine = war_roster_ids = C.war_roster(session, war.id, cl.id)
    theirs = C.war_roster(session, war.id, enemy_id)
    sa, sb, da, db_ = C.war_scores(session, war)
    my_stars, en_stars = (sa, sb) if war.clan_a == cl.id else (sb, sa)
    status = "🛰 Preparation" if war.status == "prep" else "🟢 Active"
    endt = war.prep_end_at if war.status == "prep" else war.end_at
    lines = ["🏰 Clan War", "", f"Your Clan:\n{cl.name}", "", f"Enemy:\n{en.name}", "", f"Members:\n{len(mine)} / {C.war_size(session, war.id)}  vs  {len(theirs)}", "",
             f"Status:\n{status} – {dur((endt - utcnow()).total_seconds())}", "", f"⭐ {my_stars} - {en_stars}"]
    joined = any(x.user_id == uid for x in mine)
    rows = []
    if not joined:
        rows.append([B_("⚔️ Join War", "cw_join", uid, war.id)])
    elif war.status == "active":
        me = next(x for x in mine if x.user_id == uid)
        left = ci(session, "war_cw_attacks_per_member", 2) - me.attacks_used
        if left > 0:
            rows.append([B_(f"⚔️ حمله ({left} باقی)", "cw_targets", uid, war.id)])
    rows.append([B_("📊 Status", "clan_war", uid), B_("👥 Participants", "cw_parts", uid, war.id)])
    rows.append([B_("📜 Report", "cw_report", uid, war.id), B_("🏦 Treasury", "treasury", uid)])
    rows.append(back_row(uid, "clan"))
    return "\n".join(lines), rows


def p_cw_parts(session, context, update, p, page=0, war_id=None):
    war = session.get(W.WarClanWar, war_id)
    lines = ["👥 Participants"]
    for cid in (war.clan_a, war.clan_b):
        c = session.get(W.WarClan, cid)
        lines.append(f"\n[{c.tag}] {c.name}")
        for x in C.war_roster(session, war.id, cid):
            lines.append(f"  {B.name_of(session, x.user_id)} – حمله {x.attacks_used}/{ci(session, 'war_cw_attacks_per_member', 2)} – ⭐{x.stars_scored}")
    return "\n".join(lines), [back_row(p.user_id, "clan_war")]


def p_cw_targets(session, context, update, p, page=0, war_id=None):
    uid = p.user_id
    war = session.get(W.WarClanWar, war_id)
    cl, m = C.clan_of(session, uid)
    enemy = war.clan_b if war.clan_a == cl.id else war.clan_a
    lines = ["🎯 اهدافِ جنگ", ""]
    rows = []
    for x in C.war_roster(session, war.id, enemy):
        lines.append(f"{B.name_of(session, x.user_id)} – ⭐{x.best_stars_taken}/3 (تخریب {x.best_dest_taken:.0f}%)")
        rows.append([B_(f"🎯 {B.name_of(session, x.user_id)[:18]} ({x.best_stars_taken}⭐)", "cw_go", uid, war.id, x.user_id)])
    rows.append(back_row(uid, "clan_war"))
    return "\n".join(lines), rows


# ---------------------------------------------------------------------------
# مسیریاب پنل‌ها + Callbackها
# ---------------------------------------------------------------------------
PANEL_FUNCS = {
    "main": p_main, "profile": p_profile, "xp": p_xp, "resources": p_resources, "war_room": p_war_room, "status": p_status,
    "ops": p_ops, "defense": p_defense, "base": p_base, "units": p_units, "train_menu": p_train_menu, "repair_menu": p_repair_menu,
    "uupg_menu": p_uupg_menu, "sell_menu": p_sell_menu, "quests": p_quests, "ach": p_ach, "league": p_league, "attack": p_attack_targets,
    "history": p_history, "spy_menu": p_spy_menu, "clan": p_clan, "treasury": p_treasury, "clog": p_clog, "ctx": p_ctx,
    "csettings": p_csettings, "research": p_research, "diplomacy": p_diplomacy, "castle": p_castle, "clan_war": p_clan_war,
}


def p_frontier_entry(session, context, update, p, page=0):
    """🌌 ورودِ Frontier از alias «مرزهای هاپویی» یا Deep Link /start war_frontier."""
    import frontier_ui
    return frontier_ui.war_panel(session, context, update, p, page)


PANEL_FUNCS["frontier"] = p_frontier_entry


def p_report(session, context, update, p, page=0, battle_id=None):
    b = session.get(W.WarBattle, battle_id)
    if not b or p.user_id not in (b.attacker_id, b.defender_id):
        raise WarError("این گزارش مالِ تو نیست.")
    return B.report_text(session, b, full=True, viewer=p.user_id), [back_row(p.user_id, "history")]


async def wr_callback_router(update, context):
    q = update.callback_query
    data = q.data or ""
    if data.startswith("wr:noop"):
        await q.answer()
        return True
    parts = data.split(":")
    if len(parts) < 3:
        await q.answer()
        return True
    action = parts[1]
    try:
        owner = int(parts[2])
    except ValueError:
        await q.answer()
        return True
    args = parts[3:]
    if update.effective_user.id != owner:
        await q.answer("🚫 این پنل مالِ شما نیست؛ دستورش رو خودت بنویس.", show_alert=True)
        return True
    session = db.get_session()
    try:
        gate_err = level_gate_error(session, owner)
        if gate_err:
            session.commit()
            await q.answer(gate_err[:190], show_alert=True)
            session.close()
            return True
        gs_chat = update.effective_chat
        if gs_chat and gs_chat.type != "private":
            gs = group_setting(session, gs_chat.id)
            if not gs.enabled:
                await q.answer("⛔️ هاپویی در این گروه خاموشه.", show_alert=True)
                session.commit()
                return True
        p = S.get_player(session, owner)
        S.sync_player(session, p)
        toast, nxt = await _do_action(session, context, update, p, action, args)
        session.commit()
    except WarError as e:
        session.rollback()
        await q.answer(str(e)[:190], show_alert=True)
        session.close()
        return True
    except Exception as e:  # noqa
        session.rollback()
        logger.exception("war callback failed: %s", data)
        msg = "⚠️ این عملیات با هم‌زمانی/خطا روبه‌رو شد؛ دوباره امتحان کن." if "UNIQUE" in str(e).upper() or "IntegrityError" in type(e).__name__ else "⚠️ خطای غیرمنتظره؛ دوباره امتحان کن."
        await q.answer(msg, show_alert=True)
        session.close()
        return True
    session.close()
    if toast:
        try:
            await q.answer(toast[:190])
        except Exception:
            pass
    if nxt:
        panel, kw = nxt if isinstance(nxt, tuple) else (nxt, {})
        await show_panel(update, context, owner, panel, **kw)
    return True


async def show_panel(update, context, owner, panel, **kw):
    session = db.get_session()
    try:
        p = S.get_player(session, owner)
        S.sync_player(session, p)
        new = S.pop_new_unlocks(session, p)
        special = {"target": lambda: p_target(session, context, update, p, 0, kw.get("target_id")),
                   "compose": lambda: p_compose(session, context, update, p, 0, kw.get("target_id"), kw.get("btype"), kw.get("mode", "normal"), kw.get("extra")),
                   "preview": lambda: p_preview(session, context, update, p),
                   "report": lambda: p_report(session, context, update, p, 0, kw.get("battle_id")),
                   "cview": lambda: p_cview(session, context, update, p, 0, kw.get("clan_id")),
                   "cmembers": lambda: p_cmembers(session, context, update, p, kw.get("page", 0)),
                   "mmanage": lambda: p_mmanage(session, context, update, p, 0, kw.get("target_id")),
                   "creqs": lambda: p_creqs(session, context, update, p, kw.get("page", 0)),
                   "cw_parts": lambda: p_cw_parts(session, context, update, p, 0, kw.get("war_id")),
                   "cw_targets": lambda: p_cw_targets(session, context, update, p, 0, kw.get("war_id")),
                   "attack": lambda: p_attack_targets(session, context, update, p, kw.get("page", 0)),
                   "history": lambda: p_history(session, context, update, p, kw.get("page", 0)),
                   "confirm": lambda: kw["screen"]}
        if panel in special:
            text, kb = special[panel]()
        elif panel in PANEL_FUNCS:
            text, kb = PANEL_FUNCS[panel](session, context, update, p, 0)
        else:
            text, kb = "؟", None
        if new:
            text = "🔓 NEW SYSTEM UNLOCKED\n" + "\n".join(f"{r.emoji} {r.label}" for r in new) + "\n\n" + text
        session.commit()
    except WarError as e:
        session.rollback()
        text, kb = str(e), None
    finally:
        session.close()
    if isinstance(kb, list):
        kb = Kb(kb)
    await send(update, text, kb)


def _amt(v):
    return f"{v:,.0f}"


async def _do_action(session, context, update, p, a, args):
    """اجرای اقدام؛ برمی‌گردونه (toast, next_panel|(panel,kwargs)|None). همه‌ی اقداماتِ مالی/موجودی با session یکسان → اتمیک."""
    uid = p.user_id
    chat = update.effective_chat
    if a in PANEL_FUNCS and a not in ("attack",):
        return None, a
    if a in ("attack_p",):
        return None, ("attack", {"page": int(args[0])})
    if a == "attack":
        return None, "attack"
    if a == "locked":
        r = S.feature_rule(session, args[0])
        raise WarError(f"🔒 شرط: {S.feature_missing(session, p, args[0])}" if r and r.visible_before else "🔒 هنوز باز نشده")
    if a == "collect":
        amt = S.collect_vault(session, p)
        return f"💰 {_amt(amt)} هاپ به کیف‌پولت واریز شد", "resources"
    if a == "prepare":
        cost, old, new = B.prepare_army(session, p)
        return f"🔧 آمادگی {old:.0f}% ← {new:.0f}% (هزینه {short(cost)})", "war_room"
    if a == "shield_buy":
        cost, hrs = B.buy_shield(session, p)
        return f"🛡 شیلد {hrs:g} ساعته فعال شد", "defense"
    if a == "upgrade":
        b, hop, mat, secs = S.start_upgrade(session, p, args[0])
        return f"⬆️ ارتقا شروع شد ({dur(secs)})", "base"
    if a == "train":
        job, cost, mat = S.enqueue_train(session, p, args[0], int(args[1]))
        return f"🏭 ساخت ×{args[1]} در صف ({dur((job.finish_at - utcnow()).total_seconds())})", "train_menu"
    if a == "repair":
        job, cost, mat = S.enqueue_repair(session, p, args[0], int(args[1]))
        return f"🔧 تعمیر شروع شد (هزینه {short(cost)})", "repair_menu"
    if a == "uupg":
        u, cost, mat = S.upgrade_unit(session, p, args[0])
        return f"⬆️ ارتقا به Mk{u.level}", "uupg_menu"
    if a == "sell":
        amt = S.sell_units(session, p, args[0], int(args[1]))
        return f"💰 {_amt(amt)} دریافت شد", "sell_menu"
    if a == "qclaim":
        q, r = S.claim_quest(session, p, args[0])
        return f"🎁 XP {r['xp']:g} | هاپ {_amt(r['hop'])}", "quests"
    if a == "tgt":
        return None, ("target", {"target_id": int(args[0])})
    if a == "compose":
        context.user_data.pop("war_comp", None)
        return None, ("compose", {"target_id": int(args[0]), "btype": args[1], "mode": "normal"})
    if a in ("cq", "cpre", "cho"):
        st = context.user_data.get("war_comp")
        if not st:
            raise WarError("جلسه منقضی شد.")
        if a == "cq":
            have = S.units_of(session, uid).get(args[0])
            cur = st["q"].get(args[0], 0)
            mx = (have.healthy if st["ho"] else have.healthy + have.damaged) if have else 0
            st["q"][args[0]] = max(0, min(mx, cur + int(args[1]) * (5 if mx > 30 else 1)))
        elif a == "cpre":
            st["q"] = B.default_composition(session, uid, args[0])
        else:
            st["ho"] = not st["ho"]
        return None, ("compose", {"target_id": st["t"], "btype": st["b"], "mode": st.get("mode", "normal"), "extra": st.get("x")})
    if a == "cprev":
        return None, "preview"
    if a == "attack_go":
        d = consume_token(session, uid, args[0], "attack")
        chat_id = chat.id if chat and chat.type != "private" else None
        if d.get("mode") == "clanwar":
            b, cost = C.cw_launch(session, p, int(d["x"]), int(d["t"]), d["q"], d["ho"], chat_id)
        elif d.get("mode") == "revenge":
            b, cost = B.launch_attack(session, p, int(d["t"]), d["b"], d["q"], d["ho"], chat_id, mode="revenge", revenge_of=int(d["x"]))
        else:
            b, cost = B.launch_attack(session, p, int(d["t"]), d["b"], d["q"], d["ho"], chat_id)
        context.user_data.pop("war_comp", None)
        return f"🛰 عملیات #{b.id} آغاز شد", "war_room"
    if a == "revenge":
        rb = session.get(W.WarBattle, int(args[0]))
        if not rb or rb.defender_id != uid:
            raise WarError("معتبر نیست.")
        context.user_data.pop("war_comp", None)
        return None, ("compose", {"target_id": rb.attacker_id, "btype": "standard", "mode": "revenge", "extra": rb.id})
    if a == "report":
        return None, ("report", {"battle_id": int(args[0])})
    if a == "history_p":
        return None, ("history", {"page": int(args[0])})
    if a == "spy":
        info = B.spy_target(session, p, int(args[0]))
        txt = [f"🕵️ گزارشِ جاسوسی: {info['name']}", f"🏛 {info['th']} | 🏅 {info['trophies']}", f"Power: {short(info['power'][0])} تا {short(info['power'][1])}",
               f"💰 گاوصندوق: {short(info['vault'][0])} تا {short(info['vault'][1])}", f"🔥 آمادگی ≈ {info['readiness']:.0f}%", "", "🚀 نیروها (تقریبی):"]
        txt += [f"  {n}: {lo}–{hi}" for n, lo, hi in info["units"]] or ["  —"]
        txt += ["", "🛡 دفاع (تقریبی):"] + [f"  {n}: سطح {lo}–{hi}" for n, lo, hi in info["defenses"]]
        return None, ("confirm", {"screen": ("\n".join(txt), [[B_("🎯 حمله", "tgt", uid, int(args[0]))], back_row(uid, "spy_menu")])})
    # ------------------- قبیله -------------------
    return await _do_clan_action(session, context, update, p, a, args)


async def _do_clan_action(session, context, update, p, a, args):
    uid = p.user_id
    if a == "ccreate":
        context.user_data["war_awaiting"] = {"type": "clan_create"}
        await _prompt(update, context, "🏰 اسم و تگ رو این‌طوری بفرست:\nنام قبیله | تگ\nمثال: گرگ‌های سیاه | GRG")
        return None, None
    if a == "csearch":
        context.user_data["war_awaiting"] = {"type": "clan_search"}
        await _prompt(update, context, "🔍 اسم یا تگ قبیله رو بنویس:")
        return None, None
    if a == "cview":
        return None, ("cview", {"clan_id": int(args[0])})
    if a == "creq_send":
        r = C.send_request(session, p, int(args[0]))
        return "📤 درخواست ارسال شد؛ منتظر تأیید بمون", "clan"
    if a == "myreqs":
        lines = ["📤 درخواست‌های بازِ تو"]
        rows = []
        for r in C.my_requests(session, uid):
            c = session.get(W.WarClan, r.clan_id)
            lines.append(f"• [{c.tag}] {c.name}")
            rows.append([B_(f"🗑 لغو {c.tag}", "req_cancel", uid, r.id)])
        rows.append(back_row(uid, "clan"))
        return None, ("confirm", {"screen": ("\n".join(lines), rows)})
    if a == "req_cancel":
        C.cancel_request(session, uid, int(args[0]))
        return "لغو شد", "clan"
    if a == "cmembers":
        return None, ("cmembers", {"page": int(args[0])})
    if a == "creqs":
        return None, ("creqs", {"page": int(args[0])})
    if a in ("req_ok", "req_no"):
        applicant, clan = C.decide_request(session, uid, int(args[0]), a == "req_ok")
        session.flush()
        context.application.create_task(notify_user(context, applicant, f"{'🎉 درخواستت برای قبیله‌ی ' + clan.name + ' پذیرفته شد!' if a == 'req_ok' else 'درخواستت برای ' + clan.name + ' رد شد.'}"))
        return ("✅ پذیرفته شد" if a == "req_ok" else "رد شد"), ("creqs", {"page": 0})
    if a == "mmanage":
        return None, ("mmanage", {"target_id": int(args[0])})
    if a == "rank_ask":
        tid, r = int(args[0]), int(args[1])
        names = C.rank_names(session)
        tm = C.member_of(session, tid)
        txt = f"رتبه‌ی {B.name_of(session, tid)} از «{names[tm.rank - 1]}» به «{names[r - 1]}» تغییر کنه؟"
        return None, ("confirm", {"screen": _confirm_screen(session, uid, txt, "rank", {"t": tid, "r": r}, "clan")})
    if a == "xfer_ask":
        tid = int(args[0])
        txt = f"👑 مالکیتِ قبیله به {B.name_of(session, tid)} منتقل بشه؟\nتو معاون می‌شی و دیگه به تنظیماتِ سازنده دسترسی نداری. این کار برگشت‌پذیر نیست مگر با رضایتِ اون."
        return None, ("confirm", {"screen": _confirm_screen(session, uid, txt, "xfer", {"t": tid}, "clan")})
    if a == "kick_ask":
        tid = int(args[0])
        txt = f"🚫 {B.name_of(session, tid)} از قبیله اخراج بشه؟"
        return None, ("confirm", {"screen": _confirm_screen(session, uid, txt, "kick", {"t": tid}, "clan")})
    if a == "leave_ask":
        cl, m = C.clan_of(session, uid)
        if not cl:
            raise WarError("عضوِ قبیله‌ای نیستی.")
        txt = "🚪 از قبیله خارج می‌شی. دارایی‌های شخصی‌ت می‌مونه؛ دارایی‌های قبیله (خزانه/دفاع/تحقیقات) نمی‌ره. بعدش یه مدت نمی‌تونی به قبیله‌ی دیگه بپیوندی."
        return None, ("confirm", {"screen": _confirm_screen(session, uid, txt, "leave", {}, "clan")})
    if a == "coup":
        pv = C.coup_preview(session, p)
        txt = (f"🚨 کودتا!\nشانسِ موفقیت ≈ {pv['chance']:.0f}%\n⭐ هزینه‌ی XP (همیشه کم می‌شه): {pv['xp_cost']:,.0f}\n💰 پاداشِ موفقیت (از خزانه): {_amt(pv['reward'])}\n"
               f"❗️ در صورتِ شکست: XP و مشارکتِ بیشتری از دست می‌دی.")
        return None, ("confirm", {"screen": _confirm_screen(session, uid, txt, "coup", {}, "clan")})
    if a == "cfm":
        action, tok = args[0], args[1]
        d = consume_token(session, uid, tok, action)
        return await _run_confirmed(session, context, update, p, action, d)
    if a == "cs_mode":
        cl, m = C.clan_of(session, uid)
        C.set_join_rules(session, uid, mode="closed" if cl.join_mode == "request" else "request")
        return "✅", "csettings"
    if a == "cs_set":
        context.user_data["war_awaiting"] = {"type": "clan_set", "field": args[0]}
        await _prompt(update, context, {"trophies": "🏅 حداقل کاپ (عدد):", "level": "⭐ حداقل سطح (عدد):", "desc": "📝 توضیح (حداکثر ۱۲۰ حرف):"}[args[0]])
        return None, None
    if a == "cs_announce":
        cl, m = C.clan_of(session, uid)
        C.need(session, m, "edit")
        cl.announce_chat_id = update.effective_chat.id
        return "📣 این گروه برای اعلانِ قبیله ثبت شد", "csettings"
    if a == "deposit":
        amt, gain = C.deposit(session, p, float(args[0]))
        return f"🏦 {_amt(amt)} به خزانه رفت (+{gain:.0f} مشارکت)", "treasury"
    if a == "deposit_ask":
        context.user_data["war_awaiting"] = {"type": "deposit"}
        await _prompt(update, context, "✏️ مبلغِ کمک رو بفرست (مثلاً 500k):")
        return None, None
    if a == "rsrch":
        cost, mins = C.start_research(session, uid, args[0])
        return f"🔬 شروع شد ({dur(mins * 60)})", "research"
    if a == "rel_new":
        context.user_data["war_awaiting"] = {"type": "rel_new"}
        await _prompt(update, context, "🤝 تگِ قبیله + نوعِ رابطه رو بفرست:\nمثال: GRG ally  (ally / truce / enemy)")
        return None, None
    if a in ("rel_ok", "rel_no"):
        C.respond_relation(session, uid, int(args[0]), a == "rel_ok")
        return "✅", "diplomacy"
    if a == "rel_break":
        C.break_relation(session, uid, int(args[0]))
        return "رابطه پایان یافت", "diplomacy"
    if a == "cw_search":
        n = C.search_war(session, uid, int(args[0]))
        return f"🔎 جستجوی جنگ {n} نفره شروع شد", "clan_war"
    if a == "cw_cancel":
        C.cancel_search(session, uid)
        return "لغو شد", "clan_war"
    if a == "cw_join":
        C.join_war(session, p, int(args[0]))
        return "✅ در لیستِ جنگ ثبت شدی", "clan_war"
    if a == "cw_parts":
        return None, ("cw_parts", {"war_id": int(args[0])})
    if a == "cw_targets":
        return None, ("cw_targets", {"war_id": int(args[0])})
    if a == "cw_go":
        context.user_data.pop("war_comp", None)
        return None, ("compose", {"target_id": int(args[1]), "btype": "clanwar", "mode": "clanwar", "extra": int(args[0])})
    if a == "cw_report":
        war = session.get(W.WarClanWar, int(args[0]))
        sa, sb, da, db_ = C.war_scores(session, war)
        ka, kb_ = C.war_kills(session, war.id)
        ca, cb_ = session.get(W.WarClan, war.clan_a), session.get(W.WarClan, war.clan_b)
        txt = (f"📜 گزارشِ جنگ #{war.id}\n[{ca.tag}] {ca.name}: ⭐{sa} | تخریب {da:.0f}% | 💥 {ka} واحدِ دشمن نابود شد\n"
               f"[{cb_.tag}] {cb_.name}: ⭐{sb} | تخریب {db_:.0f}% | 💥 {kb_} واحدِ دشمن نابود شد\n"
               f"نتیجه: {({'a': ca.name + ' 🏆', 'b': cb_.name + ' 🏆', 'draw': 'مساوی', 'cancelled': 'لغو', None: 'در جریان'})[war.winner]}")
        return None, ("confirm", {"screen": (txt, [back_row(uid, "clan_war")])})
    if a == "don_req":
        context.user_data["war_awaiting"] = {"type": "don_req"}
        await _prompt(update, context, "🙋 کلید تجهیز و تعداد رو بفرست:\nمثال: tank 3")
        return None, None
    if a == "don":
        qty, r = C.donate(session, p, int(args[0]), int(args[1]))
        context.application.create_task(notify_user(context, r.requester_id, f"🎁 {B.name_of(session, uid)} برات {qty} واحد اهدا کرد!"))
        return f"🎁 {qty} واحد اهدا شد", "castle"
    if a == "clog":
        return None, "clog"
    raise WarError("این دکمه دیگه معتبر نیست.")


async def _run_confirmed(session, context, update, p, action, d):
    uid = p.user_id
    if action == "rank":
        old, new = C.set_rank(session, uid, int(d["t"]), int(d["r"]))
        context.application.create_task(notify_user(context, int(d["t"]), f"🎖 رتبه‌ی تو در قبیله تغییر کرد: {C.rank_names(session)[new - 1]}"))
        return "✅ رتبه تغییر کرد", ("mmanage", {"target_id": int(d["t"])})
    if action == "xfer":
        C.transfer_leadership(session, uid, int(d["t"]))
        context.application.create_task(notify_user(context, int(d["t"]), "👑 مالکیتِ قبیله به تو منتقل شد!"))
        return "👑 انجام شد", "clan"
    if action == "kick":
        C.kick(session, uid, int(d["t"]))
        context.application.create_task(notify_user(context, int(d["t"]), "🚫 از قبیله اخراج شدی."))
        return "اخراج شد", ("cmembers", {"page": 0})
    if action == "leave":
        C.leave_clan(session, uid)
        return "🚪 از قبیله خارج شدی", "clan"
    if action == "coup":
        ok, pv, reward = C.attempt_coup(session, p)
        return (f"🚨 کودتا موفق! +{_amt(reward)}" if ok else "🕵️ کودتا شکست خورد"), "clan"
    raise WarError("نامعتبر")


async def _prompt(update, context, text):
    from handlers import send_response
    msg = await send_response(update, text, Kb([[Btn("🔙 لغو", callback_data=f"wr:cancel:{update.effective_user.id}")]]))
    if msg:
        st = context.user_data.get("war_awaiting", {})
        st["_prompt_message_id"] = msg.message_id
        st["_prompt_chat_id"] = msg.chat_id


async def war_awaiting_handler(update, context):
    """جوابِ متنیِ پرامپت‌ها (ساخت قبیله، جستجو، مبلغ دلخواه، ...)."""
    st = context.user_data.get("war_awaiting")
    if not st:
        return False
    from handlers import is_reply_to_prompt, parse_amount
    if not is_reply_to_prompt(update, st):
        return False
    context.user_data.pop("war_awaiting", None)
    text = (update.message.text or "").strip()
    uid = update.effective_user.id
    session = db.get_session()
    reply, kb, nxt = None, None, None
    try:
        gate_err = level_gate_error(session, uid)
        if gate_err:
            session.commit()
            await update.message.reply_text(gate_err)
            return True
        p = S.get_player(session, uid)
        S.sync_player(session, p)
        t = st["type"]
        if t == "clan_create":
            if "|" not in text:
                raise WarError("فرمت: نام | تگ")
            name, tag = [x.strip() for x in text.split("|", 1)]
            c, cost = C.create_clan(session, p, name, tag)
            reply = f"🏰 قبیله‌ی «{c.name}» [{c.tag}] ساخته شد! (هزینه {short(cost)})"
        elif t == "clan_search":
            res = C.search_clans(session, text)
            if not res:
                reply = "چیزی پیدا نشد."
            else:
                rows = [[B_(f"[{c.tag}] {c.name} ({n}/{C.capacity(session, c)})", "cview", uid, c.id)] for c, n in res]
                reply, kb = "🔍 نتایج:", Kb(rows)
        elif t == "clan_set":
            f = st["field"]
            if f == "desc":
                C.set_join_rules(session, uid, desc=text)
            else:
                C.set_join_rules(session, uid, **({"min_trophies": int(text)} if f == "trophies" else {"min_level": int(text)}))
            reply = "✅ ذخیره شد."
        elif t == "deposit":
            v = parse_amount(text)
            if not v:
                raise WarError("مبلغ نامعتبر.")
            amt, gain = C.deposit(session, p, v)
            reply = f"🏦 {_amt(amt)} به خزانه رفت (+{gain:.0f} مشارکت)"
        elif t == "rel_new":
            tag, kind = (text.split() + [""])[:2]
            oc = session.query(W.WarClan).filter(W.WarClan.tag == tag.upper(), W.WarClan.disbanded == False).first()  # noqa: E712
            if not oc:
                raise WarError("قبیله‌ای با این تگ نیست.")
            r, pending = C.propose_relation(session, uid, oc.id, kind.lower())
            reply = "⏳ پیشنهاد ارسال شد." if pending else "✅ انجام شد."
        elif t == "don_req":
            k, q = (text.split() + ["1"])[:2]
            C.request_units(session, p, k.lower(), int(q))
            reply = "🙋 درخواستت برای هم‌قبیله‌ای‌ها ثبت شد."
        session.commit()
    except WarError as e:
        session.rollback()
        reply = f"❌ {e}"
    except ValueError:
        session.rollback()
        reply = "❌ مقدار نامعتبر."
    finally:
        session.close()
    if reply:
        await update.message.reply_text(reply, reply_markup=kb)
    raise ApplicationHandlerStop


async def cb_cancel(update, context):
    context.user_data.pop("war_awaiting", None)
    await send(update, "❌ لغو شد.", None)


# ---------------------------------------------------------------------------
# تنظیماتِ گروه
# ---------------------------------------------------------------------------
async def show_group_settings(update, context, session):
    chat = update.effective_chat
    uid = update.effective_user.id
    from handlers import is_owner
    try:
        member = await context.bot.get_chat_member(chat.id, uid)
        is_adm = member.status in ("administrator", "creator")
    except Exception:
        is_adm = False
    if not (is_adm or is_owner(uid)):
        await update.message.reply_text("⛔️ فقط ادمینِ گروه می‌تونه تنظیمات رو ببینه.")
        return
    gs = group_setting(session, chat.id)
    session.commit()
    await update.message.reply_text(_gs_text(gs), reply_markup=_gs_kb(gs, uid))


def _gs_text(gs):
    on = lambda v: "🟢" if v else "🔴"  # noqa: E731
    return (f"⚙️ تنظیماتِ هاپویی برای این گروه\n{on(gs.enabled)} هاپویی\n{on(gs.war_enabled)} جنگ\n{on(gs.clan_enabled)} قبیله\n"
            f"{on(gs.notify_battles)} اعلانِ نبردها\n{on(gs.clan_announcements)} اعلانِ قبیله\n{on(gs.text_triggers)} تریگرهای متنی\n{on(gs.admin_only_actions)} فقط ادمین (تنظیمات)")


def _gs_kb(gs, uid):
    fields = [("enabled", "هاپویی"), ("war_enabled", "جنگ"), ("clan_enabled", "قبیله"), ("notify_battles", "اعلانِ نبرد"),
              ("clan_announcements", "اعلانِ قبیله"), ("text_triggers", "تریگرِ متنی")]
    return Kb([[Btn(f"{'🟢' if getattr(gs, f) else '🔴'} {n}", callback_data=f"wrgs:{f}:{uid}")] for f, n in fields])


async def gs_callback(update, context):
    q = update.callback_query
    _, field, owner = q.data.split(":")
    if update.effective_user.id != int(owner):
        await q.answer("🚫", show_alert=True)
        return True
    session = db.get_session()
    try:
        chat = update.effective_chat
        gs = group_setting(session, chat.id)
        if field in ("enabled", "war_enabled", "clan_enabled", "notify_battles", "clan_announcements", "text_triggers"):
            setattr(gs, field, not getattr(gs, field))
        session.commit()
        await q.edit_message_text(_gs_text(gs), reply_markup=_gs_kb(gs, int(owner)))
        await q.answer()
    finally:
        session.close()
    return True


# ---------------------------------------------------------------------------
# اعلان‌ها / Tick
# ---------------------------------------------------------------------------
async def notify_user(context, uid, text, kb=None):
    try:
        await context.bot.send_message(chat_id=uid, text=text, reply_markup=kb)
    except Exception:
        pass


async def war_tick_job(context):
    """Scheduler: نبردها را Resolve می‌کند (Persistent/Retryable/Idempotent) و اعلان می‌فرستد."""
    import asyncio
    events = await asyncio.to_thread(C.run_tick)   # DBِ sync، خارج از event-loop
    for ev in events:
        try:
            await _send_event(context, ev)
        except Exception:
            logger.exception("war notify failed")


async def _send_event(context, ev):
    t = ev.get("type")
    session = db.get_session()
    try:
        if t == "battle":
            b = session.get(W.WarBattle, ev["battle_id"])
            short_txt = B.report_text(session, b, full=False)
            an, dn = B.name_of(session, b.attacker_id), B.name_of(session, b.defender_id)
            kb_a = Kb([[Btn("📜 گزارش کامل", callback_data=cb("report", b.attacker_id, b.id))]])
            kb_d = Kb([[Btn("📜 گزارش کامل", callback_data=cb("report", b.defender_id, b.id))]])
            await notify_user(context, b.attacker_id, B.report_text(session, b, viewer=b.attacker_id), kb_a)
            if b.status == "resolved":
                extra = "\n⚔️ می‌تونی انتقام بگیری (پنل دفاع)." if b.outcome in ("attacker", "draw") and not b.clan_war_id else ""
                await notify_user(context, b.defender_id, f"🚨 به تو حمله شد!\n" + B.report_text(session, b, viewer=b.defender_id) + extra, kb_d)
            if ev.get("chat_id"):
                gs = session.get(W.WarGroupSetting, ev["chat_id"])
                if not gs or gs.notify_battles:
                    res = {"attacker": an, "defender": dn}.get(b.outcome, "—")
                    txt = (f"⚔️ Battle Finished\n\n{an} vs {dn}\n\n" + (f"🏆 Winner:\n{res}\n\n" if b.outcome != "draw" else "🤝 Draw\n\n") +
                           f"💰 Loot: +{fmt(b.loot_hop)}\n{star_s(b.stars)}")
                    await context.bot.send_message(chat_id=ev["chat_id"], text=txt[:ci(session, "war_notify_group_max_chars", 600)])
        elif t in ("cw_start", "cw_end", "cw_found", "cw_cancel"):
            war = session.get(W.WarClanWar, ev["war_id"])
            ca, cb_ = session.get(W.WarClan, war.clan_a), session.get(W.WarClan, war.clan_b)
            msg = {"cw_found": f"⚔️ جنگِ قبیله پیدا شد!\n{ca.name} vs {cb_.name}\nهمین حالا Join War بزنید (پنلِ قبیله).",
                   "cw_start": f"🟢 جنگِ #{war.id} شروع شد! {ca.name} vs {cb_.name}",
                   "cw_cancel": f"⚠️ جنگِ #{war.id} لغو شد (شرکت‌کننده‌ی کافی نبود).",
                   "cw_end": f"🏁 جنگِ #{war.id} تموم شد: ⭐{war.stars_a} - {war.stars_b}\nبرنده: " + ({'a': ca.name, 'b': cb_.name}.get(war.winner, 'مساوی'))}[t]
            for c in (ca, cb_):
                for m in C.members_list(session, c.id):
                    await notify_user(context, m.user_id, msg)
                if c.announce_chat_id:
                    gs = session.get(W.WarGroupSetting, c.announce_chat_id)
                    if not gs or gs.clan_announcements:
                        try:
                            await context.bot.send_message(chat_id=c.announce_chat_id, text=msg)
                        except Exception:
                            pass
        elif t == "settlement":
            for uid, amt in ev["payouts"]:
                await notify_user(context, uid, f"💸 تسویه‌ی قبیله: {fmt(amt)} هاپ به کیف‌پولت واریز شد.")
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Deep Link  (/start war_<panel>)
# ---------------------------------------------------------------------------
async def handle_start_deeplink(update, context) -> bool:
    args = getattr(context, "args", None) or []
    if not args or not args[0].startswith("war_"):
        return False
    panel = args[0][4:] or "resources"
    if panel not in PANEL_FUNCS and panel not in ("war_room", "main"):
        panel = "main"
    session = db.get_session()
    try:
        gate_err = level_gate_error(session, update.effective_user.id)
        if gate_err:
            session.commit()
            await update.message.reply_text(gate_err)
            return True
        S.get_player(session, update.effective_user.id)
        session.commit()
    except WarError as e:
        await update.message.reply_text(str(e))
        return True
    finally:
        session.close()
    await render_panel(update, context, update.effective_user.id, panel)
    return True


def private_link_row(context_bot_username, uid, panel="resources"):
    return Btn("🔐 ادامه در خصوصی", url=f"https://t.me/{context_bot_username}?start=war_{panel}")
