# -*- coding: utf-8 -*-
"""رابطِ «لینک دعوت» + «افزودن من به گروه» + پنلِ ادمین. تو پیوی (حتی وقتی پیویِ عمومی بسته‌ست) کار می‌کنه."""
import logging
import math

import db
import mentions
import referral as R

logger = logging.getLogger(__name__)
PAGE = 8


def fmt(n):
    return f"{int(round(n)):,}"


def _markup(rows):
    from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as K
    out = []
    for r in rows:
        out.append([B(a, url=b[4:]) if b.startswith("url:") else B(a, callback_data=b) for a, b in r])
    return K(out)


def panel_view(session, user_id: int, bot_username: str):
    st = R.stats(session, user_id)
    try:
        reward = float(db.cfg_get(session, "ref_reward_hop") or 0)
    except ValueError:
        reward = 0
    lines = ["🔗 لینک دعوت هاپویی", "━━━━━━━━━━━━━━",
             f"هر دوستِ تازه‌ای که با لینکِ تو بات رو استارت کنه، 💰 {fmt(reward)} هاپ پوینت برات واریز می‌شه.",
             "⚠️ فقط برای کسی حساب می‌شه که قبلاً بات رو استارت نکرده.", "",
             "🔗 لینکِ تو (روش بزن تا کپی بشه):", R.link(bot_username, user_id), "",
             f"👥 دعوت‌شده‌ها: {st['count']}", f"💰 درآمدِ دعوت: {fmt(st['hop'])} هاپ"]
    if st["last"]:
        lines += ["", "🕒 آخرین دعوت‌ها:"]
        for i, r in enumerate(st["last"], 1):
            u = session.get(db.User, r.invitee_id)
            lines.append(f"{i}. {u.display_name() if u else r.invitee_id}")
    rows = [[("📤 اشتراک‌گذاریِ لینک", "url:" + R.share_url(bot_username, user_id, session))],
            [("➕ افزودنِ من به گروه", "url:" + R.add_group_url(bot_username, session))],
            [("🔄 تازه‌سازی", f"ref:menu:{user_id}"), ("🔙 بازگشت", "back_main")]]
    return "\n".join(lines), rows


async def show_panel(update, context):
    from handlers import send_response
    uid = update.effective_user.id
    if update.callback_query:
        owner = int(update.callback_query.data.split(":")[2])
        if owner != uid:
            await update.callback_query.answer("این پنل برای شما نیست.", show_alert=True)
            return
    uname = context.bot.username or ""
    session = db.get_session()
    try:
        db.get_or_create_user(session, update.effective_user)
        text, rows = panel_view(session, uid, uname)
    finally:
        session.close()
    if update.callback_query:
        await send_response(update, text, _markup(rows))
    else:
        await update.message.reply_text(text, reply_markup=_markup(rows), disable_web_page_preview=True)


async def cb_ref(update, context):
    await show_panel(update, context)


async def handle_referral_start(update, context, existed_before: bool):
    """از cmd_start صدا زده می‌شه. -> True اگه پیامِ خوش‌آمدِ دعوت فرستاده شد (و cmd_start می‌تونه ادامه بده)."""
    args = getattr(context, "args", None) or []
    if not args or not args[0].startswith("ref_"):
        return
    session = db.get_session()
    try:
        info = R.register(session, update.effective_user, args[0][4:], existed_before)
        welcome = None
        notify = None
        if info:
            inviter = session.get(db.User, info["inviter_id"])
            iname = inviter.display_name() if inviter else "دوستت"
            welcome = R.msg(session, "ref_msg_welcome", name=iname)
            if R.gi(session, "ref_notify_inviter", 1):
                notify = R.msg(session, "ref_msg_inviter", name=mentions.of(update.effective_user), hop=fmt(info["hop"]), count=info["count"])
    except Exception:
        session.rollback()
        logger.exception("referral register failed")
        info, welcome, notify = None, None, None
    finally:
        session.close()
    if info and notify:
        try:
            await context.bot.send_message(info["inviter_id"], notify)
        except Exception as e:                      # دعوت‌کننده بات رو بلاک کرده/پیوی نداره
            logger.info("referral notify failed: %s", e)
    if welcome:
        try:
            await update.message.reply_text(welcome)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# پنل ادمین
# ---------------------------------------------------------------------------
async def _send(update, text, rows):
    from handlers import send_response
    return await send_response(update, text[:3900], _markup(rows))


async def cb_admin_menu(update, context):
    session = db.get_session()
    try:
        on = R.gi(session, "ref_enabled", 1)
        n, total = session.query(R.func.count(R.Referral.id), R.func.coalesce(R.func.sum(R.Referral.hop), 0)).one()
        top = (session.query(R.Referral.inviter_id, R.func.count(R.Referral.id)).group_by(R.Referral.inviter_id)
               .order_by(R.func.count(R.Referral.id).desc()).limit(5).all())
        lines = ["🔗 مدیریتِ سیستمِ دعوت", f"👥 کلِ دعوت‌های موفق: {n}", f"💰 کلِ هاپِ پرداخت‌شده: {fmt(total)}"]
        if top:
            lines.append("\n🏆 برترین دعوت‌کننده‌ها:")
            for i, (uid, c) in enumerate(top, 1):
                u = session.get(db.User, uid)
                lines.append(f"{i}. {u.display_name() if u else uid} — {c}")
        lines.append("\n⚠️ پاداشِ بالا + بدونِ سقف = ریسکِ اکانتِ فیک. در «سقفِ روزانه» یه عددِ منطقی بذار.")
    finally:
        session.close()
    rows = [[(f"{'🟢' if on else '🔴'} دعوت: {'روشن' if on else 'خاموش'}", "admin_ref_toggle")],
            [("⚙️ تنظیمات (پاداش، سقف‌ها، متن‌ها)", "admin_ref_cfg:0")],
            [("🔙 پنل مدیریت", "admin_panel")]]
    await _send(update, "\n".join(lines), rows)


async def cb_admin_toggle(update, context):
    session = db.get_session()
    try:
        db.cfg_set(session, "ref_enabled", "0" if R.gi(session, "ref_enabled", 1) else "1")
    finally:
        session.close()
    await cb_admin_menu(update, context)


async def cb_admin_cfg(update, context):
    page = int(update.callback_query.data.split(":")[1])
    keys = [k for k, _l, _v, _h in R.CFG]
    pages = max(1, math.ceil(len(keys) / PAGE))
    page = max(0, min(page, pages - 1))
    session = db.get_session()
    try:
        lines, rows = [f"⚙️ تنظیماتِ دعوت ({page + 1}/{pages})", ""], []
        for k in keys[page * PAGE:(page + 1) * PAGE]:
            lines.append(f"• {R.CFG_LABEL[k]}: {str(db.cfg_get(session, k))[:45]}")
            if R.CFG_HELP.get(k):
                lines.append(f"   ({R.CFG_HELP[k]})")
            rows.append([(f"✏️ {R.CFG_LABEL[k][:45]}", f"admin_ref_cfgk:{k}")])
    finally:
        session.close()
    rows.append([("◀️", f"admin_ref_cfg:{max(0, page - 1)}"), (f"{page + 1}/{pages}", "admin_ref_noop"), ("▶️", f"admin_ref_cfg:{min(pages - 1, page + 1)}")])
    rows.append([("🔙 بازگشت", "admin_ref_menu")])
    await _send(update, "\n".join(lines), rows)


async def cb_admin_noop(update, context):
    await update.callback_query.answer()


async def cb_admin_cfgk(update, context):
    from handlers import ask_for_input
    key = update.callback_query.data.split(":", 1)[1]
    if key not in R.CFG_LABEL:
        await update.callback_query.answer("؟", show_alert=True)
        return
    session = db.get_session()
    try:
        cur = db.cfg_get(session, key)
    finally:
        session.close()
    await ask_for_input(update, context, f"✏️ {R.CFG_LABEL[key]}\nمقدارِ فعلی: {cur}\n\nمقدارِ جدید رو بفرست:",
                        {"type": "referral_cfg", "key": key}, "admin_state", "admin_ref_menu")


async def ref_admin_awaiting_handler(update, context, state):
    text = (update.message.text or "").strip()
    session = db.get_session()
    try:
        v = R.validate_cfg(state["key"], text)
        db.cfg_set(session, state["key"], v)
        reply = f"✅ {R.CFG_LABEL[state['key']]} ← {v}"
    except ValueError as e:
        session.rollback()
        reply = f"❌ {e}"
    finally:
        session.close()
    await update.message.reply_text(reply, reply_markup=_markup([[("🔙 منوی دعوت", "admin_ref_menu")]]))


ADMIN_REF_CALLBACKS = {"admin_ref_menu": cb_admin_menu, "admin_ref_toggle": cb_admin_toggle, "admin_ref_cfg": cb_admin_cfg,
                       "admin_ref_cfgk": cb_admin_cfgk, "admin_ref_noop": cb_admin_noop}
