# -*- coding: utf-8 -*-
"""تست‌های بالانس (از شبیه‌سازیِ war_sim.py). اجرا: python -m pytest test_war_balance.py -q"""
import war_sim as X


def test_anti_farm_bounds_total_reward():
    f = X.scenario_farming()
    assert f["attacks_allowed"] <= 5 and f["blocked"] >= 6
    assert f["total_xp"] <= f["first_xp"] * 2.3          # ۱+۰٫۷+۰٫۴+۰٫۱۵ = ۲٫۲۵ (نه ۱۲×)
    assert f["total_hop"] <= f["first_hop"] * 2.3


def test_losing_streak_still_progresses():
    l = X.scenario_losing_streak()
    assert l["xp_gain"] > 0 and l["balance_change"] > -2_000_000 and l["ach_progress"] >= 3


def test_treasury_cannot_be_drained_and_coup_is_bounded():
    t = X.scenario_treasury_and_coup()
    assert t["max_single_pct_of_treasury"] < 1.0           # یک نفر حتی با مشارکتِ بسیار زیاد < ۱٪ خزانه
    assert t["treasury_after_pct"] > 90
    assert t["coup_reward_pct_of_treasury"] <= 4.0 and t["coup_reward_in_hours_of_income"] <= t["coup_reward_cap_hours"] + 1e-6
    assert t["coup_xp_cost"] > 0


def test_new_player_can_win_but_not_trivially():
    r = X.scenario_new_player_experience()
    wr = r["جدید vs جدید"][0]
    assert 0.25 <= wr <= 0.75


def test_win_probability_curve_monotonic_and_not_binary():
    rows = X.scenario_ratio_curve()
    ws = [w for _, w, _ in rows]
    assert ws == sorted(ws) and ws[0] == 0 and ws[-1] == 1
    assert any(0.15 < w < 0.85 for w in ws)                 # ناحیه‌ی میانیِ نه‌-صفر-نه‌-صد (کنترل‌شده)


def test_war_income_is_three_to_four_times_factory_across_personas():
    rep = X.run_personas(days=3)
    for name, r in rep.items():
        assert 3.0 <= r["war_vs_factory"] <= 4.0, name
        assert r["sink_ratio"] < 1.0                         # هیچ‌کس خرجش از تولیدش بیشتر نیست (اقتصادِ سالم)


def test_long_battle_survives_restart():
    r = X.scenario_long_battle_and_draw_and_timeout()
    assert r["resolved_early"] is False and r["resolved_late"] is True
