# -*- coding: utf-8 -*-
"""
لایه‌ی سرویسِ «سرقت تیمی هاپویی»: بازیکن/مهارت، مکان‌ها، لابی، State Machine، تایمرها، تسویه، ادمین.

قراردادها:
- هر تابعِ عمومی که چیزی تغییر می‌ده داخلِ یک تراکنشه (commit در انتها، rollback در خطا) و زیرِ یک قفلِ سراسری
  (threading.RLock) اجرا می‌شه؛ پس کلیک‌های هم‌زمان/تیکِ زمان‌بند نمی‌تونن همدیگه رو قاطی کنن.
- تمامِ زمان‌ها در DB هستن (police_deadline / phase_ready_at / expires_at / cooldown.until)؛ ری‌استارت امنه.
- پاداشِ هاپ فقط از war_svc.hop_apply (لجرِ HopTransaction) و زندان فقط از User.jailed_until (همون وثیقه‌ی هاپویی).
- خطای کاربرپسند = HeistError (متنش مستقیم به بازیکن نشون داده می‌شه).
"""
import datetime
import functools
import json
import threading

from sqlalchemy import func

import db
import heist_db as H
import heist_engine as E

LOCK = threading.RLock()


def utcnow():
    return datetime.datetime.utcnow()


class HeistError(Exception):
    """پیامِ فارسیِ قابل‌نمایش به بازیکن/ادمین."""


class _Safe(dict):
    def __missing__(self, key):
        return "{" + key + "}"


# ---------------------------------------------------------------------------
# کانفیگ و متن
# ---------------------------------------------------------------------------
def gs(session, key, default=""):
    v = db.cfg_get(session, key)
    return default if v is None else str(v)


def gi(session, key, default=0) -> int:
    try:
        return int(float(db.cfg_get(session, key)))
    except (TypeError, ValueError):
        return default


def msg(session, key, **kw) -> str:
    tpl = db.cfg_get(session, H.MSG_PREFIX + key) or H.MESSAGES[key][1]
    try:
        return tpl.format_map(_Safe(kw))
    except (ValueError, IndexError, KeyError, AttributeError):
        return H.MESSAGES[key][1]


def color_pool(session) -> list:
    pool = [c.strip() for c in gs(session, "heist_color_pool").split(",") if c.strip()]
    return pool if len(pool) >= 2 else [c.strip() for c in H.GLOBAL_CFG_DEFAULT["heist_color_pool"].split(",")]


def _txn(fn):
    @functools.wraps(fn)
    def wrapper(session, *a, **kw):
        with LOCK:
            try:
                out = fn(session, *a, **kw)
                session.commit()
                return out
            except Exception:
                session.rollback()
                raise
    return wrapper


def log(session, op_id, kind, **detail):
    session.add(H.HeistEvent(op_id=op_id or 0, kind=kind, detail=H.dumps(detail)))


# ---------------------------------------------------------------------------
# بازیکن و مهارت
# ---------------------------------------------------------------------------
def get_player(session, user_id: int) -> "H.HeistPlayer":
    p = session.get(H.HeistPlayer, user_id)
    if p is None:
        p = H.HeistPlayer(user_id=user_id, xp=0, xp_total=0, skill_spy=0, skill_safe=0, skill_carrier=0,
                          skill_driver=0, free_points=0, heists=0, wins=0)
        session.add(p)
        session.flush()
    return p


def skill_of(p, role: str) -> int:
    return int(getattr(p, "skill_" + role) or 0)


def skills_dict(p) -> dict:
    return {r: skill_of(p, r) for r in E.ROLES}


def unlock_xp(session, p) -> float:
    return (p.xp_total if gi(session, "heist_unlock_lifetime_xp", 1) else p.xp) or 0


def points_available(session, p) -> int:
    rate = max(1, gi(session, "heist_xp_per_skill_point", 5))
    return int(p.free_points or 0) + int((p.xp or 0) // rate)


def skill_caps(session, role: str):
    return gi(session, f"heist_skill_min_{role}", 0), gi(session, f"heist_skill_max_{role}", 0)


@_txn
def skill_add(session, user_id: int, role: str) -> "H.HeistPlayer":
    """➕: اول از امتیازِ آزاد (بعد از ➖) خرج می‌کنه، اگه نبود XP رو به امتیاز تبدیل می‌کنه."""
    if role not in E.ROLES:
        raise HeistError("مهارتِ نامعتبر.")
    p = get_player(session, user_id)
    lo, hi = skill_caps(session, role)
    if hi and skill_of(p, role) >= hi:
        raise HeistError(f"این مهارت به سقفش ({hi}) رسیده.")
    if (p.free_points or 0) > 0:
        p.free_points -= 1
    else:
        rate = max(1, gi(session, "heist_xp_per_skill_point", 5))
        if (p.xp or 0) < rate:
            raise HeistError(f"XP کافی نیست؛ هر امتیازِ مهارت {rate} XP می‌خواد.")
        p.xp -= rate                     # تبدیلِ XP → امتیاز (برگشت‌ناپذیر)
    setattr(p, "skill_" + role, skill_of(p, role) + 1)
    log(session, 0, "skill_add", user=user_id, role=role, level=skill_of(p, role))
    return p


@_txn
def skill_sub(session, user_id: int, role: str) -> "H.HeistPlayer":
    """➖: یک امتیاز از این مهارت برداشته می‌شه و «آزاد» می‌شه (به XP برنمی‌گرده)."""
    if role not in E.ROLES:
        raise HeistError("مهارتِ نامعتبر.")
    p = get_player(session, user_id)
    lo, _hi = skill_caps(session, role)
    if skill_of(p, role) <= max(0, lo):
        raise HeistError("این مهارت دیگه پایین‌تر نمیاد.")
    setattr(p, "skill_" + role, skill_of(p, role) - 1)
    p.free_points = (p.free_points or 0) + 1
    log(session, 0, "skill_sub", user=user_id, role=role, level=skill_of(p, role))
    return p


# ---------------------------------------------------------------------------
# مکان‌ها
# ---------------------------------------------------------------------------
def loc_dict(loc) -> dict:
    d = {k: getattr(loc, k) for k in H.LOC_KEYS}
    for k, spec in H.LOC_BY_KEY.items():
        if spec[2] == "bool":
            d[k] = bool(d[k])
    return d


def location_pool(session, location_id: int) -> list:
    rows = (session.query(H.HeistLocationItem)
            .filter(H.HeistLocationItem.location_id == location_id, H.HeistLocationItem.enabled == True)  # noqa: E712
            .order_by(H.HeistLocationItem.id).all())
    return [{"id": r.id, "name": r.name, "base_value": int(r.base_value or 0), "weight": float(r.weight if r.weight is not None else 1),
             "fail_pct": r.fail_pct, "variance": r.variance} for r in rows]


def list_locations(session, include_hidden=False):
    q = session.query(H.HeistLocation).filter(H.HeistLocation.deleted == False)  # noqa: E712
    if not include_hidden:
        q = q.filter(H.HeistLocation.enabled == True)  # noqa: E712
    return q.order_by(H.HeistLocation.req_xp, H.HeistLocation.sort, H.HeistLocation.id).all()


def active_cooldown(session, user_id, location_id, now):
    cd = (session.query(H.HeistCooldown)
          .filter(H.HeistCooldown.user_id == user_id, H.HeistCooldown.location_id == location_id, H.HeistCooldown.until > now)
          .order_by(H.HeistCooldown.until.desc()).first())
    return cd


def open_membership(session, user_id):
    return (session.query(H.HeistOpMember, H.HeistOperation)
            .join(H.HeistOperation, H.HeistOperation.id == H.HeistOpMember.op_id)
            .filter(H.HeistOpMember.user_id == user_id, H.HeistOperation.status.in_(list(E.OPEN_STATUSES))).first())


def location_state(session, user, loc, now=None) -> dict:
    """وضعیتِ مکان برای این کاربر - سمتِ سرور: locked/available/lobby/progress/cooldown/prison."""
    now = now or utcnow()
    p = get_player(session, user.telegram_id)
    if user.jailed_until and user.jailed_until > now:
        return {"state": "prison", "remain": (user.jailed_until - now).total_seconds()}
    if unlock_xp(session, p) < (loc.req_xp or 0):
        return {"state": "locked", "need": loc.req_xp}
    cd = active_cooldown(session, user.telegram_id, loc.id, now)
    if cd:
        return {"state": "cooldown", "remain": (cd.until - now).total_seconds()}
    om = open_membership(session, user.telegram_id)
    if om and om[1].location_id == loc.id:
        return {"state": "lobby" if om[1].status in (E.RECRUITING, E.FULL) else "progress", "op_id": om[1].id}
    return {"state": "available"}


def _eligibility(session, user, loc, now):
    """همه‌ی شرط‌های ساخت/ورود؛ هر تخلفی = HeistError. (UI هیچ‌وقت منبعِ حقیقت نیست.)"""
    if not gi(session, "heist_enabled", 1):
        raise HeistError("🥷 بخش سرقت تیمی فعلاً خاموشه.")
    gate = db.check_module_level(session, user, "heist")
    if gate:
        raise HeistError(gate)
    if user.jailed_until and user.jailed_until > now:
        raise HeistError("🔒 تو زندانِ هاپویی هستی و نمی‌تونی سرقت کنی. برای آزادی بنویس «وثیقه».")
    if loc is None or loc.deleted or not loc.enabled:
        raise HeistError("این مکان در دسترس نیست.")
    p = get_player(session, user.telegram_id)
    if unlock_xp(session, p) < (loc.req_xp or 0):
        raise HeistError(msg(session, "locked_join"))
    cd = active_cooldown(session, user.telegram_id, loc.id, now)
    if cd:
        raise HeistError(msg(session, "cooldown_join", remain=E.fmt_long((cd.until - now).total_seconds())))
    if open_membership(session, user.telegram_id):
        raise HeistError("تو الان عضو یه سرقتِ دیگه هستی؛ اول از اون خارج شو یا تمومش کن.")
    if not location_pool(session, loc.id):
        raise HeistError("این مکان هنوز آیتمی نداره و قابلِ سرقت نیست.")


# ---------------------------------------------------------------------------
# پنل‌ها (مالک/چت سمتِ سرور)
# ---------------------------------------------------------------------------
@_txn
def panel_create(session, chat_id, owner_id) -> "H.HeistPanel":
    pn = H.HeistPanel(chat_id=chat_id, owner_id=owner_id)
    session.add(pn)
    session.flush()
    return pn


def panel_get(session, panel_id):
    return session.get(H.HeistPanel, panel_id)


@_txn
def panel_set_message(session, panel_id, message_id):
    pn = session.get(H.HeistPanel, panel_id)
    if pn:
        pn.message_id = message_id


# ---------------------------------------------------------------------------
# لابی
# ---------------------------------------------------------------------------
def _members(session, op_id):
    return session.query(H.HeistOpMember).filter(H.HeistOpMember.op_id == op_id).order_by(H.HeistOpMember.slot).all()


def _add_member(session, op, user, now):
    taken = {m.slot for m in _members(session, op.id)}
    slot = next((s for s in range(1, E.TEAM_SIZE + 1) if s not in taken), None)
    if slot is None:
        raise HeistError("تیم پر شده.")
    p = get_player(session, user.telegram_id)
    role = E.role_of_slot(slot)
    m = H.HeistOpMember(op_id=op.id, user_id=user.telegram_id, slot=slot, role=role,
                        name=(user.display_name() if hasattr(user, "display_name") else str(user.telegram_id)),
                        skill=skill_of(p, role), skills_json=H.dumps(skills_dict(p)), joined_at=now)
    session.add(m)
    session.flush()
    log(session, op.id, "join", user=user.telegram_id, slot=slot, role=role, skill=m.skill, skills=skills_dict(p))
    return m


def _loc_cooldown_rule(loc_cfg):
    return loc_cfg.get("cooldown_trigger", "on_finish"), int(loc_cfg.get("cooldown_minutes", 0) or 0)


def _set_cooldown(session, user_id, location_id, op_id, minutes, now):
    if minutes <= 0:
        return
    try:
        import battlepass_engine as _bp
        with session.begin_nested():
            minutes = _bp.heist_cooldown(session, user_id, minutes)   # بوسترِ کاهشِ کول‌دانِ بتل‌پس
    except Exception:
        pass
    exists = (session.query(H.HeistCooldown).filter_by(user_id=user_id, location_id=location_id, op_id=op_id).first())
    if not exists:
        session.add(H.HeistCooldown(user_id=user_id, location_id=location_id, op_id=op_id, until=now + datetime.timedelta(minutes=minutes)))


def _apply_cooldowns(session, op, loc_cfg, triggers, now):
    trig, minutes = _loc_cooldown_rule(loc_cfg)
    if trig in triggers:
        for m in _members(session, op.id):
            _set_cooldown(session, m.user_id, op.location_id, op.id, minutes, now)


def _drop_lobby_cooldowns(session, op):
    session.query(H.HeistCooldown).filter(H.HeistCooldown.op_id == op.id).delete(synchronize_session=False)


@_txn
def create_lobby(session, user, chat_id, location_id, panel_id=None) -> "H.HeistOperation":
    now = utcnow()
    loc = session.get(H.HeistLocation, location_id)
    _eligibility(session, user, loc, now)
    ttl = max(1, gi(session, "heist_lobby_ttl_minutes", 30))
    op = H.HeistOperation(location_id=loc.id, chat_id=chat_id, creator_id=user.telegram_id, panel_id=panel_id, status=E.RECRUITING,
                          seed=E.new_seed(), created_at=now, expires_at=now + datetime.timedelta(minutes=ttl), phase_data="{}")
    session.add(op)
    session.flush()
    _add_member(session, op, user, now)
    if panel_id:
        pn = session.get(H.HeistPanel, panel_id)
        if pn:
            pn.op_id = op.id
    log(session, op.id, "lobby_created", creator=user.telegram_id, location=loc.id, chat=chat_id)
    _apply_member_lobby_cooldown(session, op, loc, user.telegram_id, now)
    return op


def _apply_member_lobby_cooldown(session, op, loc, user_id, now):
    if loc.cooldown_trigger == "on_lobby_start":
        _set_cooldown(session, user_id, loc.id, op.id, int(loc.cooldown_minutes or 0), now)


@_txn
def join_lobby(session, op_id, user, chat_id):
    """Join؛ همه‌ی شرط‌ها (XP/کول‌داون/قفل/وضعیت) دوباره سمتِ سرور چک می‌شن. -> (op, started)"""
    now = utcnow()
    op = session.get(H.HeistOperation, op_id)
    if op is None or op.status != E.RECRUITING:
        raise HeistError("این لابی دیگه بازنیست.")
    if op.chat_id != chat_id:
        raise HeistError("این سرقت مالِ این گروه نیست.")
    if session.query(H.HeistOpMember).filter_by(op_id=op.id, user_id=user.telegram_id).first():
        raise HeistError("تو قبلاً عضو این سرقت شدی.")
    loc = session.get(H.HeistLocation, op.location_id)
    _eligibility(session, user, loc, now)
    _add_member(session, op, user, now)
    _apply_member_lobby_cooldown(session, op, loc, user.telegram_id, now)
    started = False
    if len(_members(session, op.id)) >= E.TEAM_SIZE:
        op.status = E.FULL
        log(session, op.id, "team_full")
        if loc.auto_start:
            _start(session, op, now)
            started = True
    return op, started


@_txn
def manual_start(session, op_id, user_id):
    op = session.get(H.HeistOperation, op_id)
    if op is None or op.status not in (E.RECRUITING, E.FULL):
        raise HeistError("این عملیات قابلِ شروع نیست.")
    if op.creator_id != user_id:
        raise HeistError("فقط سازنده‌ی لابی می‌تونه عملیات رو شروع کنه.")
    if len(_members(session, op.id)) < E.TEAM_SIZE:
        raise HeistError("تیم هنوز کامل نشده.")
    _start(session, op, utcnow())
    return op


def _start(session, op, now):
    """شروعِ واقعیِ عملیات: Snapshotِ تنظیمات + چیدنِ آیتم‌ها + پازلِ اول + تایمرِ پلیس."""
    loc = session.get(H.HeistLocation, op.location_id)
    cfg = {"loc": loc_dict(loc), "pool": location_pool(session, loc.id), "colors": color_pool(session),
           "allow_repeat": bool(gi(session, "heist_spy_allow_repeat", 0)), "location_id": loc.id, "location_name": loc.name}
    if not cfg["pool"]:
        raise HeistError("این مکان آیتمی نداره.")
    op.cfg_json = H.dumps(cfg)
    placed = E.place_items(op.seed, cfg["loc"]["grid_cells"], cfg["pool"], cfg["loc"]["items_count"], cfg["loc"]["value_variance"])
    for it in placed:
        session.add(H.HeistOpItem(op_id=op.id, cell=it["cell"], item_id=it["item_id"], name=it["name"], base_value=it["base_value"],
                                  value=it["value"], fail_pct_base=it["fail_pct"], found=False, loaded=False))
    op.status = E.SPY
    op.started_at = now
    op.police_deadline = now + datetime.timedelta(seconds=int(cfg["loc"]["police_seconds"]))
    op.phase_started_at = now
    op.phase_ready_at = None
    op.expires_at = None
    spy = _member_by_role(session, op.id, "spy")
    op.phase_data = H.dumps(_new_spy_state(op, cfg, spy.skill, 0))
    log(session, op.id, "start", seed_hint="stored", police_deadline=op.police_deadline, items=[(i["cell"], i["name"], i["value"]) for i in placed],
        skills={m.role: m.skill for m in _members(session, op.id)})
    _apply_cooldowns(session, op, cfg["loc"], {"on_start"}, now)


def _cfg(op) -> dict:
    return json.loads(op.cfg_json or "{}")


def _pd(op) -> dict:
    return json.loads(op.phase_data or "{}")


def _set_pd(op, d):
    op.phase_data = H.dumps(d)


def _member_by_role(session, op_id, role):
    return session.query(H.HeistOpMember).filter_by(op_id=op_id, role=role).first()


def _member_of(session, op_id, user_id):
    return session.query(H.HeistOpMember).filter_by(op_id=op_id, user_id=user_id).first()


@_txn
def leave_op(session, op_id, user_id):
    """❌ خروج از سرقت. -> 'left' | 'cancelled' | 'failed'"""
    now = utcnow()
    op = session.get(H.HeistOperation, op_id)
    if op is None:
        raise HeistError(msg(session, "not_member"))
    m = _member_of(session, op_id, user_id)
    if m is None:
        raise HeistError(msg(session, "not_member"))
    if op.status in (E.SETTLED, E.CANCELLED):
        raise HeistError("این سرقت تموم شده.")
    if op.status in (E.RECRUITING, E.FULL):
        if op.creator_id == user_id:
            _cancel(session, op, "creator_left")
            return "cancelled"
        session.query(H.HeistCooldown).filter_by(op_id=op.id, user_id=user_id).delete(synchronize_session=False)
        session.delete(m)
        op.status = E.RECRUITING
        log(session, op.id, "leave", user=user_id, before_start=True)
        return "left"
    rule = _cfg(op)["loc"].get("leave_after_start", "blocked")
    if rule != "fail":
        raise HeistError("بعد از شروعِ عملیات نمی‌تونی خارج بشی.")
    log(session, op.id, "leave", user=user_id, before_start=False)
    _settle_failure(session, op, "leave", now)
    return "failed"


def _cancel(session, op, why):
    op.status = E.CANCELLED
    op.finished_at = utcnow()
    _drop_lobby_cooldowns(session, op)
    log(session, op.id, "cancelled", why=why)


@_txn
def admin_cancel_op(session, op_id, actor_id):
    op = session.get(H.HeistOperation, op_id)
    if op is None or op.status in (E.SETTLED, E.CANCELLED):
        raise HeistError("عملیاتِ بازی با این شماره پیدا نشد.")
    _cancel(session, op, f"admin:{actor_id}")
    return op


# ---------------------------------------------------------------------------
# دسترسی (Permission Model)
# ---------------------------------------------------------------------------
def _turn_msg(session, role):
    return msg(session, "turn_" + role)


def authorize(session, op_id, user_id, chat_id, phase=None):
    """User + Operation + Chat + Phase + Role + Status + Membership. -> (op, member)"""
    op = session.get(H.HeistOperation, op_id)
    if op is None or op.chat_id != chat_id:
        raise HeistError("این سرقت پیدا نشد.")
    m = _member_of(session, op_id, user_id)
    if m is None:
        raise HeistError(msg(session, "not_member"))
    if phase is not None:
        if op.status not in E.ACTIVE_PHASES:
            raise HeistError("این مرحله دیگه فعال نیست.")
        if op.status != phase:
            raise HeistError("این دکمه مالِ مرحله‌ی دیگه‌ایه.")
        need = E.PHASE_ROLE[phase]
        if m.role != need:
            raise HeistError(_turn_msg(session, need))
    return op, m


# ---------------------------------------------------------------------------
# تایمر و پیشروی (Idempotent)
# ---------------------------------------------------------------------------
def police_remaining(op, now=None) -> float:
    now = now or utcnow()
    if not op.police_deadline:
        return 0
    return max(0.0, (op.police_deadline - now).total_seconds())


def _found_items(session, op_id):
    return (session.query(H.HeistOpItem).filter_by(op_id=op_id, found=True).order_by(H.HeistOpItem.cell).all())


def advance(session, op_id, now=None) -> str:
    """زمان‌های رسیده رو اعمال می‌کنه (آیتمِ در حالِ بارگیری، رانندگی، پلیس). Idempotent.
    برمی‌گردونه وضعیتِ نهایی. (بدونِ commit؛ صدازننده commit می‌کنه.)"""
    now = now or utcnow()
    op = session.get(H.HeistOperation, op_id)
    if op is None or op.status not in E.ACTIVE_PHASES:
        return op.status if op else ""
    deadline = op.police_deadline
    # ۱) مراحلِ زمان‌دار که *قبل* از رسیدنِ پلیس تموم شدن (حتی اگه ری‌استارت باعثِ دیر پردازش‌شدن شده)
    for _ in range(64):
        if op.status == E.CARRIER and op.phase_ready_at and op.phase_ready_at <= now and op.phase_ready_at < deadline:
            _finish_item_load(session, op)
            continue
        if op.status == E.DRIVER and op.phase_ready_at and op.phase_ready_at <= now and op.phase_ready_at < deadline:
            _settle_success(session, op, op.phase_ready_at, now)
            return op.status
        break
    # ۲) پلیس
    if op.status in E.ACTIVE_PHASES and now >= deadline:
        _settle_failure(session, op, "police", deadline)
    return op.status


def _finish_item_load(session, op):
    pd = _pd(op)
    done_at = op.phase_ready_at
    iid = pd.get("loading")
    if iid is not None:
        it = session.get(H.HeistOpItem, iid)
        if it and not it.loaded:
            it.loaded = True
        pd["idx"] = int(pd.get("idx", 0)) + 1
        pd["loading"] = None
        log(session, op.id, "item_loaded", item=iid, at=done_at)
    op.phase_ready_at = None
    if pd["idx"] >= len(pd.get("queue", [])):
        _enter_phase(session, op, E.DRIVER, {"driving": False}, done_at)
    else:
        _set_pd(op, pd)


def _enter_phase(session, op, phase, pd, at):
    if not E.can_transition(op.status, phase):
        raise HeistError("تغییرِ وضعیتِ نامعتبر.")
    log(session, op.id, "phase", frm=op.status, to=phase, at=at)
    op.status = phase
    op.phase_started_at = at
    op.phase_ready_at = None
    _set_pd(op, pd)


def _new_spy_state(op, cfg, skill, attempt):
    loc = cfg["loc"]
    pal = cfg["colors"]
    n = E.spy_length(loc, skill)
    if not cfg.get("allow_repeat") and n > len(pal):
        n = len(pal)
    seq = E.gen_sequence(op.seed, attempt, n, len(pal), cfg.get("allow_repeat", False))
    return {"attempt": attempt, "seq": seq, "input": []}


# ---------------------------------------------------------------------------
# اکشن‌های مرحله‌ها
# ---------------------------------------------------------------------------
def _live(session, op_id, user_id, chat_id, phase):
    """advance + authorize؛ اگه وسطش پلیس رسید همون اول Failure ثبت می‌شه و خطای مناسب میاد."""
    op0 = session.get(H.HeistOperation, op_id)
    if op0 is None or op0.chat_id != chat_id:
        raise HeistError("این سرقت پیدا نشد.")
    advance(session, op_id)
    op = session.get(H.HeistOperation, op_id)
    if op.status == E.SETTLED:
        session.commit()      # تسویه‌ای که advance همین الان انجام داد باید ثبت بشه (rollbackِ _txn نباید بپردازدش)
        raise HeistEnded()
    return authorize(session, op_id, user_id, chat_id, phase)


class HeistEnded(HeistError):
    """عملیات (موفق یا ناموفق) همین الان بسته شده؛ UI باید گزارشِ نهایی رو نشون بده."""


@_txn
def refresh(session, op_id, chat_id):
    """به‌روزکردنِ وضعیت (دکمه‌ی 📊): advance بدونِ نیاز به نقش."""
    op = session.get(H.HeistOperation, op_id)
    if op is None or op.chat_id != chat_id:
        raise HeistError("این سرقت پیدا نشد.")
    advance(session, op_id)
    return session.get(H.HeistOperation, op_id)


@_txn
def spy_pick(session, op_id, user_id, chat_id, color_idx: int):
    op, m = _live(session, op_id, user_id, chat_id, E.SPY)
    cfg = _cfg(op)
    pd = _pd(op)
    if not 0 <= int(color_idx) < len(cfg["colors"]):
        raise HeistError("رنگِ نامعتبر.")
    if len(pd["input"]) >= len(pd["seq"]):
        raise HeistError("ورودی پر شده؛ «تأیید» یا «پاک کردن» رو بزن.")
    pd["input"].append(int(color_idx))
    _set_pd(op, pd)
    return op


@_txn
def spy_backspace(session, op_id, user_id, chat_id):
    op, m = _live(session, op_id, user_id, chat_id, E.SPY)
    pd = _pd(op)
    if pd["input"]:
        pd["input"].pop()                # فقط آخرین رنگ
    _set_pd(op, pd)
    return op


@_txn
def spy_confirm(session, op_id, user_id, chat_id):
    """-> (op, ok)"""
    op, m = _live(session, op_id, user_id, chat_id, E.SPY)
    cfg = _cfg(op)
    pd = _pd(op)
    if E.sequence_ok(pd["seq"], pd["input"]):
        log(session, op.id, "spy_ok", attempts=pd["attempt"] + 1)
        _enter_phase(session, op, E.SAFE, {"opened": []}, utcnow())
        return op, True
    attempt = pd["attempt"] + 1
    log(session, op.id, "spy_wrong", attempt=attempt)
    _set_pd(op, _new_spy_state(op, cfg, m.skill, attempt))   # ورودی پاک + پازلِ جدید
    return op, False


def _safe_all_found(session, op):
    total = session.query(func.count(H.HeistOpItem.id)).filter_by(op_id=op.id).scalar() or 0
    found = session.query(func.count(H.HeistOpItem.id)).filter_by(op_id=op.id, found=True).scalar() or 0
    return total, found


def _leave_safe_phase(session, op):
    items = _found_items(session, op.id)
    now = utcnow()
    if not items:
        _enter_phase(session, op, E.DRIVER, {"driving": False}, now)         # فقط با no_item_policy=skip می‌رسیم اینجا
        return
    _enter_phase(session, op, E.CARRIER, {"queue": [i.id for i in items], "idx": 0, "loading": None}, now)


@_txn
def safe_open(session, op_id, user_id, chat_id, cell: int):
    """-> (op, item_or_None, finished_phase)"""
    op, m = _live(session, op_id, user_id, chat_id, E.SAFE)
    cfg = _cfg(op)
    pd = _pd(op)
    cell = int(cell)
    if not 0 <= cell < int(cfg["loc"]["grid_cells"]):
        raise HeistError("خونه‌ی نامعتبر.")
    if cell in pd["opened"]:
        raise HeistError("این خونه رو قبلاً باز کردی.")
    pd["opened"].append(cell)
    _set_pd(op, pd)
    it = session.query(H.HeistOpItem).filter_by(op_id=op.id, cell=cell).first()
    if it is not None:
        it.found = True
        log(session, op.id, "item_found", cell=cell, item=it.name, value=it.value)
    else:
        log(session, op.id, "cell_empty", cell=cell)
    total, found = _safe_all_found(session, op)
    finished = False
    if cfg["loc"]["auto_finish_all"] and total and found >= total:
        _leave_safe_phase(session, op)
        finished = True
    return op, it, finished


def _enough_threshold(loc):
    need = int(loc.get("min_found_items", 1) or 0)
    if loc.get("no_item_policy", "blocked") != "skip":
        need = max(1, need)
    return need


@_txn
def safe_enough(session, op_id, user_id, chat_id):
    """✅ کافیه (فقط مرحله‌ی صندوق)."""
    op, m = _live(session, op_id, user_id, chat_id, E.SAFE)
    loc = _cfg(op)["loc"]
    if not loc["early_finish"]:
        raise HeistError("دکمه‌ی «کافیه» تو این مکان غیرفعاله؛ باید همه‌ی خونه‌ها رو بگردی.")
    total, found = _safe_all_found(session, op)
    if found == 0 and _enough_threshold(loc) > 0:
        raise HeistError(msg(session, "nothing_found"))
    need = min(_enough_threshold(loc), total)
    if found < need:
        raise HeistError(f"حداقل {need} آیتم لازمه (تا الان {found}).")
    _leave_safe_phase(session, op)
    return op


@_txn
def carrier_start_item(session, op_id, user_id, chat_id):
    op, m = _live(session, op_id, user_id, chat_id, E.CARRIER)
    pd = _pd(op)
    if pd.get("loading") is not None:
        raise HeistError("آیتمِ فعلی هنوز در حالِ جابه‌جاییه.")
    if pd["idx"] >= len(pd["queue"]):
        raise HeistError("همه‌ی آیتم‌ها منتقل شدن.")
    sec = E.carrier_seconds(_cfg(op)["loc"], m.skill)
    pd["loading"] = pd["queue"][pd["idx"]]
    _set_pd(op, pd)
    op.phase_ready_at = utcnow() + datetime.timedelta(seconds=sec)
    log(session, op.id, "item_load_start", item=pd["loading"], seconds=sec)
    return op


@_txn
def driver_start(session, op_id, user_id, chat_id):
    op, m = _live(session, op_id, user_id, chat_id, E.DRIVER)
    pd = _pd(op)
    if pd.get("driving"):
        raise HeistError("ماشین همین الان در حالِ حرکته.")
    sec = E.driver_seconds(_cfg(op)["loc"], m.skill)
    pd["driving"] = True
    _set_pd(op, pd)
    op.phase_ready_at = utcnow() + datetime.timedelta(seconds=sec)
    log(session, op.id, "drive_start", seconds=sec)
    return op


# ---------------------------------------------------------------------------
# تسویه (Resolution) - هر تابع فقط یک بار؛ ضدِ پرداختِ دوباره
# ---------------------------------------------------------------------------
def _settle_failure(session, op, reason, at):
    if op.status == E.SETTLED or op.resolution_id:
        return
    now = utcnow()
    cfg = _cfg(op)
    loc = cfg["loc"]
    members = _members(session, op.id)
    op.status = E.SETTLED
    op.result = "failed"
    op.fail_reason = reason
    op.finished_at = at
    op.settled_at = now
    op.resolution_id = f"heist-{op.id}"
    op.total_loot = 0
    op.per_member = 0
    jail_min = int(loc.get("jail_minutes", 0) or 0)
    bail = float(loc.get("bail_amount", 0) or 0)
    for m in members:
        p = get_player(session, m.user_id)
        p.heists = (p.heists or 0) + 1
        session.add(H.HeistReward(op_id=op.id, user_id=m.user_id, hop=0, xp=0))
        if jail_min > 0:
            u = session.get(db.User, m.user_id)
            if u is not None:
                until = now + datetime.timedelta(minutes=jail_min)
                if not (u.jailed_until and u.jailed_until >= until):   # زندانِ بلندتر رو کوتاه نمی‌کنیم
                    u.jailed_until = until
                    u.jail_bail_amount = bail
                    u.jail_reason = "heist"
    _apply_cooldowns(session, op, loc, {"on_finish", "on_failure"}, at)
    log(session, op.id, "failed", reason=reason, at=at, jail_minutes=jail_min, bail=bail)


def _settle_success(session, op, completed_at, now):
    if op.status == E.SETTLED or op.resolution_id:
        return
    import war_svc                                    # لجرِ هاپ پوینتِ موجود (هیچ ارزِ جدیدی نداریم)
    cfg = _cfg(op)
    loc = cfg["loc"]
    members = _members(session, op.id)
    by_role = {m.role: m for m in members}
    safe_skill = by_role["safe"].skill
    items = _found_items(session, op.id)
    pcts = []
    for it in items:
        base = it.fail_pct_base if it.fail_pct_base is not None else float(loc.get("item_fail_pct", 0))
        pcts.append(E.item_fail_pct(base, loc, safe_skill))
    rolls = E.roll_failures(op.seed, [{"cell": i.cell} for i in items], pcts)    # هر آیتم مستقل
    total = 0
    for it, pct, lost in zip(items, pcts, rolls):
        it.fail_pct_eff = pct
        it.lost = bool(lost)
        if not lost:
            total += it.value
        elif loc.get("failed_item_policy") == "half":
            total += it.value // 2
    creator_idx = next((i for i, m in enumerate(members) if m.user_id == op.creator_id), 0)
    paid_total, shares = E.split_loot(total, len(members), loc.get("split_remainder", "normalize"), op.seed, creator_idx)
    xp = float(loc.get("success_xp", 0) or 0)
    op.status = E.SETTLED
    op.result = "success"
    op.finished_at = completed_at
    op.settled_at = now
    op.resolution_id = f"heist-{op.id}"
    op.total_loot = paid_total
    op.per_member = shares[0] if shares else 0
    for m, share in zip(members, shares):
        u = session.get(db.User, m.user_id)
        if share > 0 and u is not None:
            war_svc.hop_apply(session, u, share, "EARN", f"heist:{op.id}", ref=op.id)
            try:
                import battlepass_engine as _bp
                with session.begin_nested():
                    _bp.heist_bonus(session, u, share, op.id)   # بوسترِ غنیمتِ بتل‌پس (از خانه، نه از سهمِ بقیه)
            except Exception:
                pass
        p = get_player(session, m.user_id)
        p.xp = (p.xp or 0) + xp
        p.xp_total = (p.xp_total or 0) + xp
        p.heists = (p.heists or 0) + 1
        p.wins = (p.wins or 0) + 1
        session.add(H.HeistReward(op_id=op.id, user_id=m.user_id, hop=share, xp=xp))
    _apply_cooldowns(session, op, loc, {"on_finish", "on_success"}, completed_at)
    log(session, op.id, "success", total_before_split=total, paid_total=paid_total, shares=shares, xp=xp,
        rolls=[(i.cell, round(p_, 2), bool(l_)) for i, p_, l_ in zip(items, pcts, rolls)])


@_txn
def force_settle_tick(session, op_id):
    """برای تست/ادمین: فقط advance."""
    advance(session, op_id)
    return session.get(H.HeistOperation, op_id)


# ---------------------------------------------------------------------------
# Scheduler (از jobs صدا زده می‌شه؛ Persistent / Retryable / Idempotent)
# ---------------------------------------------------------------------------
def run_tick(now=None) -> list:
    """همه‌ی عملیات‌های باز رو جلو می‌بره. -> لیستِ رویدادها برای به‌روزکردنِ پنل‌ها در گروه."""
    events = []
    with LOCK:
        session = db.get_session()
        try:
            now = now or utcnow()
            refresh_s = max(5, gi(session, "heist_panel_refresh_seconds", 15))
            ops = session.query(H.HeistOperation).filter(H.HeistOperation.status.in_(list(E.OPEN_STATUSES))).all()
            for op in ops:
                before = op.status
                if op.status in (E.RECRUITING, E.FULL):
                    if op.expires_at and op.expires_at <= now:
                        _cancel(session, op, "expired")
                        events.append({"op_id": op.id, "chat_id": op.chat_id, "change": "cancelled"})
                    continue
                advance(session, op.id, now)
                if op.status != before:
                    events.append({"op_id": op.id, "chat_id": op.chat_id, "change": "settled" if op.status == E.SETTLED else "phase"})
                elif op.status in E.ACTIVE_PHASES and (not op.last_refresh_at or (now - op.last_refresh_at).total_seconds() >= refresh_s):
                    op.last_refresh_at = now
                    events.append({"op_id": op.id, "chat_id": op.chat_id, "change": "refresh"})
            session.commit()
        except Exception:
            session.rollback()
            raise
        finally:
            session.close()
    return events


# ---------------------------------------------------------------------------
# تاریخچه
# ---------------------------------------------------------------------------
def history(session, user_id, limit=None) -> list:
    limit = limit or max(1, gi(session, "heist_history_size", 10))
    rows = (session.query(H.HeistOperation)
            .join(H.HeistOpMember, H.HeistOpMember.op_id == H.HeistOperation.id)
            .filter(H.HeistOpMember.user_id == user_id, H.HeistOperation.status == E.SETTLED)
            .order_by(H.HeistOperation.settled_at.desc()).limit(limit).all())
    out = []
    for op in rows:
        cfg = _cfg(op)
        rw = session.query(H.HeistReward).filter_by(op_id=op.id, user_id=user_id).first()
        team = [m.name for m in _members(session, op.id)]
        out.append({"op_id": op.id, "location": cfg.get("location_name", "?"), "result": op.result, "reason": op.fail_reason,
                    "hop": rw.hop if rw else 0, "xp": rw.xp if rw else 0, "at": op.settled_at, "team": team})
    return out


# ---------------------------------------------------------------------------
# ادمین (Data-driven؛ همه‌ی تغییرها Audit می‌شن)
# ---------------------------------------------------------------------------
@_txn
def admin_create_location(session, actor_id, name: str) -> "H.HeistLocation":
    name = (name or "").strip()
    if not name:
        raise HeistError("نام نمی‌تونه خالی باشه.")
    if session.query(H.HeistLocation).filter(H.HeistLocation.name == name, H.HeistLocation.deleted == False).first():  # noqa: E712
        raise HeistError("مکانی با این نام از قبل هست.")
    vals = H.loc_default_values(session)
    err = H.validate_loc_cross(vals)
    if err:
        raise HeistError("پیش‌فرض‌های مکان‌های جدید ناسازگارن: " + err)
    loc = H.HeistLocation(code=f"loc_{int(utcnow().timestamp() * 1000)}", name=name, **vals)
    session.add(loc)
    session.flush()
    loc.code = f"loc_{loc.id}"
    log(session, 0, "admin_loc_create", actor=actor_id, loc=loc.id, name=name)
    return loc


@_txn
def admin_set_location_field(session, actor_id, loc_id: int, key: str, raw: str):
    loc = session.get(H.HeistLocation, loc_id)
    if loc is None or loc.deleted:
        raise HeistError("مکان پیدا نشد.")
    spec = H.LOC_BY_KEY.get(key)
    if spec is None:
        raise HeistError("فیلدِ نامعتبر.")
    try:
        value = H.coerce(spec[2], raw)
    except ValueError as e:
        raise HeistError(str(e))
    err = H.validate_loc_value(key, value)
    if err:
        raise HeistError(err)
    vals = loc_dict(loc)
    vals[key] = value
    err = H.validate_loc_cross(vals)
    if err:
        raise HeistError(err)
    old = getattr(loc, key)
    setattr(loc, key, value)
    log(session, 0, "admin_loc_set", actor=actor_id, loc=loc.id, key=key, old=old, new=value)
    return loc


@_txn
def admin_toggle_location(session, actor_id, loc_id: int):
    loc = session.get(H.HeistLocation, loc_id)
    if loc is None or loc.deleted:
        raise HeistError("مکان پیدا نشد.")
    loc.enabled = not loc.enabled
    log(session, 0, "admin_loc_toggle", actor=actor_id, loc=loc.id, enabled=loc.enabled)
    return loc


@_txn
def admin_delete_location(session, actor_id, loc_id: int):
    loc = session.get(H.HeistLocation, loc_id)
    if loc is None:
        raise HeistError("مکان پیدا نشد.")
    loc.deleted = True
    loc.enabled = False
    log(session, 0, "admin_loc_delete", actor=actor_id, loc=loc.id)
    return loc


ITEM_FIELDS = [
    ("name", "📛 نام آیتم", "str"),
    ("base_value", "💰 ارزشِ پایه (هاپ پوینت)", "int"),
    ("weight", "⚖️ شانسِ نسبیِ انتخاب‌شدن (وزن)", "float"),
    ("fail_pct", "⚠️ احتمالِ از دست رفتن (٪؛ خالی/‎-‎ = پیش‌فرضِ مکان)", "float?"),
    ("variance", "🎲 نوسانِ ارزش (±؛ خالی/‎-‎ = پیش‌فرضِ مکان)", "float?"),
]
ITEM_LABEL = {k: l for k, l, _t in ITEM_FIELDS}


@_txn
def admin_add_item(session, actor_id, loc_id: int, name: str, base_value: int):
    if session.get(H.HeistLocation, loc_id) is None:
        raise HeistError("مکان پیدا نشد.")
    name = (name or "").strip()
    if not name:
        raise HeistError("نام نمی‌تونه خالی باشه.")
    if base_value < 0:
        raise HeistError("ارزش منفی نمی‌شه.")
    it = H.HeistLocationItem(location_id=loc_id, name=name, base_value=int(base_value), weight=1, enabled=True)
    session.add(it)
    session.flush()
    log(session, 0, "admin_item_add", actor=actor_id, loc=loc_id, item=it.id, name=name, value=base_value)
    return it


@_txn
def admin_set_item_field(session, actor_id, item_id: int, key: str, raw: str):
    it = session.get(H.HeistLocationItem, item_id)
    if it is None:
        raise HeistError("آیتم پیدا نشد.")
    kinds = {k: t for k, _l, t in ITEM_FIELDS}
    if key not in kinds:
        raise HeistError("فیلدِ نامعتبر.")
    raw = str(raw).strip()
    if kinds[key] == "float?" and raw in ("", "-", "خالی", "none"):
        value = None
    else:
        try:
            value = H.coerce(kinds[key].rstrip("?"), raw)
        except ValueError as e:
            raise HeistError(str(e))
        if key in ("base_value", "weight", "variance") and value < 0:
            raise HeistError("منفی مجاز نیست.")
        if key == "fail_pct" and not 0 <= value <= 100:
            raise HeistError("درصد باید بینِ ۰ تا ۱۰۰ باشه.")
        if key == "name" and not value:
            raise HeistError("نام نمی‌تونه خالی باشه.")
    old = getattr(it, key)
    setattr(it, key, value)
    log(session, 0, "admin_item_set", actor=actor_id, item=item_id, key=key, old=old, new=value)
    return it


@_txn
def admin_toggle_item(session, actor_id, item_id: int):
    it = session.get(H.HeistLocationItem, item_id)
    if it is None:
        raise HeistError("آیتم پیدا نشد.")
    it.enabled = not it.enabled
    log(session, 0, "admin_item_toggle", actor=actor_id, item=item_id, enabled=it.enabled)
    return it


@_txn
def admin_delete_item(session, actor_id, item_id: int):
    it = session.get(H.HeistLocationItem, item_id)
    if it is None:
        raise HeistError("آیتم پیدا نشد.")
    session.delete(it)               # عملیات‌های در حال اجرا Snapshot دارن و اثر نمی‌گیرن
    log(session, 0, "admin_item_delete", actor=actor_id, item=item_id)


def validate_global_cfg(key: str, raw: str):
    """-> (مقدارِ تمیز, خطا). فقط کلیدهای heist_* تعریف‌شده."""
    raw = str(raw).strip()
    if key not in H.ALL_CFG_LABEL:
        return None, "کلیدِ ناشناخته."
    if key.startswith(H.MSG_PREFIX):
        if not raw:
            return None, "متن نمی‌تونه خالی باشه."
        try:
            raw.format_map(_Safe())
        except (ValueError, IndexError):
            return None, "آکولادهای متن درست نیست؛ از {نام} استفاده کن."
        return raw, ""
    if key == "heist_color_pool":
        colors = [c.strip() for c in raw.split(",") if c.strip()]
        if len(colors) < 2 or len(set(colors)) != len(colors):
            return None, "حداقل ۲ رنگِ متفاوت، با کاما جدا شده."
        return ",".join(colors), ""
    if key.startswith(H.DEF_PREFIX):
        lk = key[len(H.DEF_PREFIX):]
        spec = H.LOC_BY_KEY[lk]
        try:
            v = H.coerce(spec[2], raw)
        except ValueError as e:
            return None, str(e)
        err = H.validate_loc_value(lk, v)
        if err:
            return None, err
        return ("1" if v is True else "0" if v is False else str(v)), ""
    try:
        v = float(raw)
    except ValueError:
        return None, "یه عدد بفرست."
    if v != v or v in (float("inf"), float("-inf")) or v != int(v):
        return None, "یه عددِ صحیحِ معتبر بفرست."
    v = int(v)
    if v < 0:
        return None, "منفی مجاز نیست."
    if key == "heist_xp_per_skill_point" and v < 1:
        return None, "حداقل ۱."
    if key in ("heist_enabled", "heist_unlock_lifetime_xp", "heist_spy_allow_repeat") and v not in (0, 1):
        return None, "فقط ۰ یا ۱."
    if key == "heist_panel_refresh_seconds" and v < 5:
        return None, "حداقل ۵ ثانیه."
    if key == "heist_lobby_ttl_minutes" and v < 1:
        return None, "حداقل ۱ دقیقه."
    return str(v), ""


@_txn
def admin_set_global_cfg(session, actor_id, key: str, raw: str):
    val, err = validate_global_cfg(key, raw)
    if err:
        raise HeistError(err)
    old = db.cfg_get(session, key)
    db.cfg_set(session, key, val)
    log(session, 0, "admin_cfg_set", actor=actor_id, key=key, old=old, new=val)
    return val


@_txn
def admin_adjust_player(session, actor_id, user_id: int, xp_delta: float = 0, clear_cooldowns=False, reset_skills=False):
    if session.get(db.User, user_id) is None:
        raise HeistError("بازیکن پیدا نشد.")
    p = get_player(session, user_id)
    if xp_delta:
        p.xp = max(0.0, (p.xp or 0) + xp_delta)
        p.xp_total = max(0.0, (p.xp_total or 0) + xp_delta)
    if reset_skills:
        for r in E.ROLES:
            setattr(p, "skill_" + r, 0)
        p.free_points = 0
    if clear_cooldowns:
        session.query(H.HeistCooldown).filter_by(user_id=user_id).delete(synchronize_session=False)
    log(session, 0, "admin_player", actor=actor_id, user=user_id, xp_delta=xp_delta, clear_cd=clear_cooldowns, reset=reset_skills)
    return p


def dashboard(session, hours=None) -> dict:
    hours = hours or gi(session, "heist_dashboard_hours", 24)
    since = utcnow() - datetime.timedelta(hours=hours)
    q = session.query(H.HeistOperation)
    settled = q.filter(H.HeistOperation.status == E.SETTLED, H.HeistOperation.settled_at >= since)
    return {
        "hours": hours,
        "locations": session.query(H.HeistLocation).filter(H.HeistLocation.deleted == False).count(),  # noqa: E712
        "players": session.query(H.HeistPlayer).count(),
        "open": q.filter(H.HeistOperation.status.in_(list(E.OPEN_STATUSES))).count(),
        "success": settled.filter(H.HeistOperation.result == "success").count(),
        "failed": settled.filter(H.HeistOperation.result == "failed").count(),
        "hop_paid": session.query(func.coalesce(func.sum(H.HeistOperation.total_loot), 0)).filter(
            H.HeistOperation.status == E.SETTLED, H.HeistOperation.result == "success", H.HeistOperation.settled_at >= since).scalar() or 0,
    }
