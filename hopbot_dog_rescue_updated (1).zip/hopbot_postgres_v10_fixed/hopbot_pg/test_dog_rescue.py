# -*- coding: utf-8 -*-
"""تست‌های دیتابیسیِ رویدادِ سگ زندانی؛ اجرا: python -m pytest -q test_dog_rescue.py"""
import asyncio
import datetime
import os
import tempfile
from types import SimpleNamespace

_TMP = tempfile.mkdtemp(prefix="hop_dog_rescue_")
os.environ.setdefault("DB_PATH", os.path.join(_TMP, "dog_rescue_test.db"))
os.environ.setdefault("BOT_TOKEN", "1:test")
os.environ.setdefault("OWNER_ID", "1")

import pytest

import db
import war_db
import battlepass_db
import battlepass_engine as bp
import dog_rescue as D


@pytest.fixture(scope="module", autouse=True)
def _init():
    db.init_db()
    war_db.init_war()
    battlepass_db.init_battlepass()
    D.init_dog_rescue()
    yield


def _make_event(uid, chat_id, balance, minutes=5):
    s = db.get_session()
    try:
        user = s.get(db.User, uid)
        if user is None:
            user = db.User(telegram_id=uid, username=f"u{uid}", first_name=f"User {uid}", hop_points=balance)
            s.add(user)
        event = D.DogRescueEvent(
            chat_id=chat_id, message_id=uid + 100000, status="active",
            created_at=datetime.datetime.utcnow(),
            expires_at=datetime.datetime.utcnow() + datetime.timedelta(minutes=minutes),
        )
        s.add(event)
        s.commit()
        return event.id, event.message_id
    finally:
        s.close()


def _tg_user(uid):
    return SimpleNamespace(id=uid, username=f"u{uid}", first_name=f"User {uid}")


def test_fixed_cost_chance_and_xp_balance():
    assert D.COSTS == (100, 1000, 4000)
    assert D.CHANCES == {100: 0.45, 1000: 0.50, 4000: 0.55}
    assert D.BP_XP_BASE == {100: 25, 1000: 35, 4000: 45}


def test_lost_attempt_debits_ledger_and_cannot_retry():
    uid = 981001
    eid, mid = _make_event(uid, -100981001, 500)
    result = D._record_attempt(eid, -100981001, mid, _tg_user(uid), 100, roll=0.99)
    assert result["status"] == "lost"
    assert result["snapshot"]["caption"].count("<b>1</b>") >= 1

    s = db.get_session()
    try:
        user = s.get(db.User, uid)
        event = s.get(D.DogRescueEvent, eid)
        tx = s.query(war_db.HopTransaction).filter_by(user_id=uid, reason="DOG_RESCUE_ATTEMPT").one()
        assert user.hop_points == pytest.approx(400)
        assert tx.amount == pytest.approx(-100)
        assert event.attempts_total == 1 and event.attempts_100 == 1
        assert event.status == "active"
    finally:
        s.close()

    again = D._record_attempt(eid, -100981001, mid, _tg_user(uid), 100, roll=0.1)
    assert again["status"] == "already_tried"


def test_first_success_grants_selected_battlepass_xp_and_closes_event():
    uid = 981002
    eid, mid = _make_event(uid, -100981002, 5000)
    result = D._record_attempt(eid, -100981002, mid, _tg_user(uid), 4000, roll=0.54)
    assert result["status"] == "won"
    assert result["base_xp"] == 45
    assert result["reward_xp"] >= 45

    s = db.get_session()
    try:
        user = s.get(db.User, uid)
        event = s.get(D.DogRescueEvent, eid)
        season = bp.current_season(s)
        player = bp.get_player(s, user, season, create=False)
        assert user.hop_points == pytest.approx(1000)
        assert event.status == "rescued" and event.won_by == uid
        assert event.reward_xp == pytest.approx(player.xp)
        assert event.attempts_total == 1 and event.attempts_4000 == 1
    finally:
        s.close()


def test_lowest_cost_success_grants_25_battlepass_xp():
    uid = 981008
    eid, mid = _make_event(uid, -100981008, 100)
    result = D._record_attempt(eid, -100981008, mid, _tg_user(uid), 100, roll=0.44)
    assert result["status"] == "won"
    assert result["base_xp"] == 25
    assert result["reward_xp"] == pytest.approx(25)


def test_global_winner_cooldown_blocks_other_groups_without_debit():
    uid = 981003
    eid1, mid1 = _make_event(uid, -100981003, 5000)
    won = D._record_attempt(eid1, -100981003, mid1, _tg_user(uid), 1000, roll=0.10)
    assert won["status"] == "won"
    assert won["base_xp"] == 35 and won["reward_xp"] == pytest.approx(35)

    eid2, mid2 = _make_event(uid, -100981004, 5000)
    blocked = D._record_attempt(eid2, -100981004, mid2, _tg_user(uid), 100, roll=0.10)
    assert blocked["status"] == "win_cooldown"
    s = db.get_session()
    try:
        assert s.get(db.User, uid).hop_points == pytest.approx(4000)
        assert s.query(D.DogRescueAttempt).filter_by(event_id=eid2, user_id=uid).count() == 0
    finally:
        s.close()


def test_expired_event_cannot_charge_or_award():
    uid = 981005
    eid, mid = _make_event(uid, -100981005, 1000, minutes=-1)
    before = datetime.datetime.utcnow()
    result = D._record_attempt(eid, -100981005, mid, _tg_user(uid), 100, roll=0.1, nowt=before)
    assert result["status"] == "lonely"
    s = db.get_session()
    try:
        assert s.get(db.User, uid).hop_points == pytest.approx(1000)
        assert s.get(D.DogRescueEvent, eid).status == "lonely"
        assert s.query(D.DogRescueAttempt).filter_by(event_id=eid).count() == 0
    finally:
        s.close()

def test_spawn_scans_groups_independently_and_obeys_30_minute_cooldown(monkeypatch):
    nowt = datetime.datetime.utcnow()
    chat_new, chat_recent = -100981006, -100981007
    s = db.get_session()
    try:
        s.add_all([
            db.GroupChat(chat_id=chat_new, title="new-group", last_seen_at=nowt),
            db.GroupChat(chat_id=chat_recent, title="recent-group", last_seen_at=nowt),
            D.DogRescueEvent(chat_id=chat_recent, message_id=500007, status="rescued",
                created_at=nowt - datetime.timedelta(minutes=10),
                expires_at=nowt - datetime.timedelta(minutes=5), closed_at=nowt - datetime.timedelta(minutes=5)),
        ])
        s.commit()
    finally:
        s.close()

    sent = []
    async def fake_send(_bot, event_id, chat_id):
        sent.append((event_id, chat_id))
    monkeypatch.setattr(D, "_send_event", fake_send)
    monkeypatch.setattr(D.random, "random", lambda: 0.10)
    asyncio.run(D.tick_job(SimpleNamespace(bot=object())))

    assert len(sent) == 1 and sent[0][1] == chat_new
    s = db.get_session()
    try:
        assert s.query(D.DogRescueEvent).filter_by(chat_id=chat_new, status="active").count() == 1
        assert s.query(D.DogRescueEvent).filter_by(chat_id=chat_recent).count() == 1
    finally:
        s.close()

