# -*- coding: utf-8 -*-
"""صفحه‌کلیدهای شیشه‌ای (Inline Keyboard) ربات - همه با ایموجی."""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup


def hop_hop_keyboard(owner_id: int):
    """این پیام (نتیجه‌ی هاپ‌هاپ) ممکنه تو گروه دیده بشه، ولی دکمه‌هاش فقط برای
    همون کسی کار می‌کنن که خودش هاپ کرده - وگرنه یه نفرِ دیگه می‌تونست از رو
    پیامِ این کاربر، اکانتِ خودش رو (با کلیک رو همون دکمه‌ها) مدیریت کنه."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🦘 هاپ هاپ!", callback_data=f"hop_hop_owned:{owner_id}")],
        [InlineKeyboardButton("🏭 هاپ منیج", callback_data=f"hop_manage_owned:{owner_id}")],
    ])


BOT_USERNAME = ""      # تو main._post_init پر می‌شه


def _invite_rows(owner_id: int):
    """«افزودن من به گروه» (صفحه‌ی انتخابِ گروه + درخواستِ ادمین‌شدن) و «لینک دعوت» - حتی با پیویِ بسته."""
    rows = []
    if BOT_USERNAME:
        import referral
        rows.append([InlineKeyboardButton("➕ افزودنِ من به گروه", url=referral.add_group_url(BOT_USERNAME))])
    rows.append([InlineKeyboardButton("🔗 لینک دعوت (پاداش بگیر!)", callback_data=f"ref:menu:{owner_id}")])
    return rows


def main_private_menu(is_owner: bool, owner_id: int, pv_open: bool = True):
    """این منو ممکنه از داخلِ یه پیامِ گروهی (نتیجه‌ی هاپ‌هاپ یا هاپ منیج) با
    زدنِ «بازگشت» باز شده باشه، پس همه‌ی دکمه‌هاش به همون صاحبِ اصلیِ پیام قفلن.
    pv_open=False (پیویِ عمومی خاموشه و کاربر ادمین نیست): فقط «سیو / بازیابی اکانت» نشون داده می‌شه."""
    if not pv_open:
        return InlineKeyboardMarkup(_invite_rows(owner_id) + [
            [InlineKeyboardButton("💾 سیو / بازیابی اکانت (جیمیل)", callback_data=f"acct:menu:{owner_id}")],
            [InlineKeyboardButton("🌐 Language / زبان", callback_data=f"lang:menu:{owner_id}")],
        ])
    rows = [
        [InlineKeyboardButton("🦘 هاپ هاپ", callback_data=f"hop_hop_owned:{owner_id}"),
         InlineKeyboardButton("🏭 هاپ منیج", callback_data=f"hop_manage_owned:{owner_id}")],
        [InlineKeyboardButton("🛒 سوپرمارکت", callback_data=f"market_open_owned:{owner_id}"),
         InlineKeyboardButton("🏦 بانک هاپویی", callback_data=f"bank_open_owned:{owner_id}")],
        [InlineKeyboardButton("💱 ارز دیجیتال", callback_data=f"crypto_open_owned:{owner_id}"),
         InlineKeyboardButton("📊 پروفایل من", callback_data=f"profile_open_owned:{owner_id}")],
        [InlineKeyboardButton("📖 راهنمایی هاپویی", callback_data=f"hguide_open:{owner_id}")],
    ] + _invite_rows(owner_id) + [
        [InlineKeyboardButton("💾 سیو / بازیابی اکانت (جیمیل)", callback_data=f"acct:menu:{owner_id}")],
        [InlineKeyboardButton("🌐 Language / زبان", callback_data=f"lang:menu:{owner_id}")],
    ]
    if is_owner:
        rows.append([InlineKeyboardButton("⚙️ پنل مدیریت", callback_data="admin_panel")])
    return InlineKeyboardMarkup(rows)


def hop_manage_keyboard(can_upgrade: bool, owner_id: int):
    """
    این پنل شخصیه (وضعیت کارخونه‌ی خودِ کاربره)، ولی چون ممکنه پیام مربوطه از
    طریق تایپ «هاپ منیج» توی گروه ساخته شده باشه، این پیام برای همه‌ی اعضای
    گروه قابل‌دیدن و قابل‌کلیکه. برای اینکه یه نفر دیگه نتونه از روی پنلِ باز
    شده‌ی این کاربر، کارخونه/اسمِ خودش رو مدیریت کنه (و این پیام رو بی‌ربط به
    صاحبش تغییر بده)، آی‌دیِ صاحبِ پنل تو خودِ callback_data قفل می‌شه؛ موقع
    کلیک چک می‌شه که کلیک‌کننده همون صاحبه یا نه.
    """
    rows = []
    if can_upgrade:
        rows.append([InlineKeyboardButton("⬆️ ارتقای تولید", callback_data=f"factory_upgrade:{owner_id}")])
    rows.append([InlineKeyboardButton("💰 برداشت تولید", callback_data=f"factory_collect:{owner_id}")])
    rows.append([InlineKeyboardButton("🐕 تغییر اسم سگ", callback_data=f"cat_name_ask:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"back_main_owned:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def factory_rank_confirm_keyboard(owner_id: int):
    """تاییدِ رفتن به مقامِ بعدِ کارخونه (چون تولید/ظرفیت ریست می‌شه)."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ بله، برو مقامِ بعد", callback_data=f"factory_rank_confirm:{owner_id}")],
        [InlineKeyboardButton("❌ نه، بیخیال", callback_data=f"factory_rank_cancel:{owner_id}")],
    ])


def league_menu_keyboard(owner_id):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🦘 لیدربورد هاپ هاپ", callback_data=f"league_hops:{owner_id}")],
        [InlineKeyboardButton("🪙 لیدربورد هاپ پوینت", callback_data=f"league_points:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"back_main_owned:{owner_id}")],
    ])


def league_result_keyboard(owner_id):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"league_menu:{owner_id}")],
    ])


def market_keyboard(has_market: bool, owner_id: int):
    if not has_market:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🏗️ ساخت سوپرمارکت (۱,۵۰۰,۰۰۰ 🪙)", callback_data=f"market_buy:{owner_id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f"back_main_owned:{owner_id}")],
        ])
    rows = [
        [InlineKeyboardButton("⬆️ ارتقای سرعت تولید", callback_data=f"market_upgrade:{owner_id}")],
        [InlineKeyboardButton("💰 برداشت محصولات", callback_data=f"market_collect:{owner_id}")],
        [InlineKeyboardButton("💵 فروش همه‌ی محصولات", callback_data=f"market_sell_all:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"back_main_owned:{owner_id}")],
    ]
    return InlineKeyboardMarkup(rows)


def bank_keyboard(has_bank: bool, owner_id: int):
    if not has_bank:
        return InlineKeyboardMarkup([
            [InlineKeyboardButton("🏦 افتتاح بانک (۱,۲۰۰,۰۰۰ 🪙)", callback_data=f"bank_create:{owner_id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f"back_main_owned:{owner_id}")],
        ])
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📥 واریز", callback_data=f"bank_deposit_ask:{owner_id}")],
        [InlineKeyboardButton("📤 برداشت", callback_data=f"bank_withdraw_ask:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"back_main_owned:{owner_id}")],
    ])


def crypto_list_keyboard(currencies, owner_id: int):
    rows = []
    for c in currencies:
        rows.append([InlineKeyboardButton(
            f"{c.emoji} {c.name} | خرید {c.buy_price:,.0f} / فروش {c.sell_price:,.0f}",
            callback_data=f"crypto_view:{c.id}:{owner_id}")])
    rows.append([InlineKeyboardButton("💼 ولت", callback_data=f"wallet_open:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"back_main_owned:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def crypto_action_keyboard(currency_id: int, owner_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🟢 خرید", callback_data=f"crypto_buy_ask:{currency_id}:{owner_id}"),
         InlineKeyboardButton("🔴 فروش", callback_data=f"crypto_sell_ask:{currency_id}:{owner_id}")],
        [InlineKeyboardButton("🔔 آلارمِ قیمت", callback_data=f"crypto_alarm_menu:{currency_id}:{owner_id}"),
         InlineKeyboardButton("📋 سفارش (Limit)", callback_data=f"crypto_order_menu:{currency_id}:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"crypto_open_owned:{owner_id}")],
    ])


def crypto_alarm_menu_keyboard(alarms, currency_id: int, owner_id: int):
    rows = []
    for a in alarms:
        arrow = "📈" if a.direction == "up" else "📉"
        rows.append([InlineKeyboardButton(f"🗑 {arrow} {a.target_price:,.0f}", callback_data=f"crypto_alarm_del:{a.id}:{owner_id}")])
    rows.append([InlineKeyboardButton("➕ آلارمِ جدید", callback_data=f"crypto_alarm_add:{currency_id}:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"crypto_view:{currency_id}:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def crypto_order_menu_keyboard(orders, currency_id: int, owner_id: int):
    rows = []
    for o in orders:
        label = "🟢 خرید" if o.kind == "buy" else "🔴 فروش"
        rows.append([InlineKeyboardButton(
            f"🗑 {label} {o.quantity:,.0f} @ {o.target_price:,.0f}",
            callback_data=f"crypto_order_cancel:{o.id}:{owner_id}")])
    rows.append([InlineKeyboardButton("➕ سفارشِ خرید", callback_data=f"crypto_order_buy_ask:{currency_id}:{owner_id}"),
                 InlineKeyboardButton("➕ سفارشِ فروش", callback_data=f"crypto_order_sell_ask:{currency_id}:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"crypto_view:{currency_id}:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def wallet_menu_keyboard(owner_id: int, has_wallet: bool):
    rows = []
    if not has_wallet:
        rows.append([InlineKeyboardButton("💼 ساختِ ولت", callback_data=f"wallet_buy:{owner_id}")])
    else:
        rows.append([InlineKeyboardButton("🔄 انتقالِ ارز", callback_data=f"wallet_transfer_ask:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"crypto_open_owned:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def wallet_currency_picker_keyboard(currencies, target_user_id: int, owner_id: int):
    rows = []
    for c in currencies:
        rows.append([InlineKeyboardButton(
            f"{c.emoji} {c.name}", callback_data=f"wallet_pick_currency:{c.id}:{target_user_id}:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"wallet_open:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def wallet_confirm_keyboard(owner_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ تایید نهایی", callback_data=f"wallet_confirm:{owner_id}"),
         InlineKeyboardButton("❌ انصراف", callback_data=f"wallet_open:{owner_id}")],
    ])


def confirm_keyboard(yes_cb: str, no_cb: str = "cancel_action"):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ بله، مطمئنم", callback_data=yes_cb),
         InlineKeyboardButton("❌ انصراف", callback_data=no_cb)],
    ])


def lottery_join_keyboard(event_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🎉 شرکت در قرعه‌کشی", callback_data=f"lottery_join:{event_id}")],
    ])


# ---------------------------------------------------------------------------
# گوشی هاپویی (شبکه‌های اجتماعی)
# ---------------------------------------------------------------------------

def myawy_home_keyboard(owner_id: int, has_pending_fee: bool):
    rows = [
        [InlineKeyboardButton("📶 اپراتور (خرید اینترنت)", callback_data=f"myawy_operators:{owner_id}")],
        [InlineKeyboardButton("🏪 گوشی‌فروشی", callback_data=f"myawy_shop:{owner_id}"),
         InlineKeyboardButton("🗄 کشوی گوشی‌های من", callback_data=f"myawy_drawer:{owner_id}")],
        [InlineKeyboardButton("🏴 بازارِ سیاه", callback_data=f"myawy_bm:{owner_id}")],
        [InlineKeyboardButton("📱 پلتفرم‌ها", callback_data=f"myawy_platforms:{owner_id}")],
        [InlineKeyboardButton("➕ درخواستِ پلتفرمِ جدید", callback_data=f"myawy_request_platform:{owner_id}")],
        [InlineKeyboardButton("💰 بدهی‌های من", callback_data=f"myawy_my_debts:{owner_id}")],
    ]
    if has_pending_fee:
        rows.append([InlineKeyboardButton("🧾 بدهیِ پلتفرمِ جدید", callback_data=f"myawy_platform_debt:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"back_main_owned:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def myawy_operators_keyboard(operators, owner_id: int):
    rows = []
    for op in operators:
        rows.append([InlineKeyboardButton(
            f"{op.name} | {op.price_per_gb:,.0f}🪙/GB | {op.active_speed_mbps:,.0f}Mbps",
            callback_data=f"myawy_buy_gb_ask:{op.id}:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def myawy_platforms_keyboard(platforms, owner_id: int):
    rows = []
    for p in platforms:
        rows.append([InlineKeyboardButton(
            f"{p.name} ({p.reward_amount:,.0f}🪙/{p.likes_threshold}لایک)",
            callback_data=f"myawy_platform_view:{p.id}:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def myawy_platform_view_keyboard(platform_id: int, owner_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("📰 دیدنِ پست‌ها", callback_data=f"myawy_feed:{platform_id}:{owner_id}:0")],
        [InlineKeyboardButton("📄 پست‌های من", callback_data=f"myawy_myposts:{platform_id}:{owner_id}")],
        [InlineKeyboardButton("✍️ پستِ جدید", callback_data=f"myawy_new_post_ask:{platform_id}:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_platforms:{owner_id}")],
    ])


def myawy_myposts_keyboard(items, platform_id: int, owner_id: int):
    """items: لیستِ (post_id, نمایشیِ شماره‌ی پست)."""
    rows = [
        [InlineKeyboardButton(f"🗑 حذفِ پستِ {idx}", callback_data=f"myawy_mypost_delete:{pid}:{platform_id}:{owner_id}")]
        for pid, idx in items
    ]
    if items:
        rows.append([InlineKeyboardButton("🗑 حذفِ همه‌ی پست‌های من", callback_data=f"myawy_myposts_deleteall_ask:{platform_id}:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_platform_view:{platform_id}:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def myawy_platform_debt_keyboard(owner_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 پرداخت", callback_data=f"myawy_pay_fee:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_home:{owner_id}")],
    ])


def myawy_feed_keyboard(likeable_posts, platform_id: int, owner_id: int, offset: int, has_more: bool):
    """likeable_posts: لیستِ (post, label) که هنوز میشه لایکشون کرد."""
    rows = []
    for post, label in likeable_posts:
        rows.append([InlineKeyboardButton(
            f"❤️ لایکِ {label} ({post.likes})",
            callback_data=f"myawy_like:{post.id}:{platform_id}:{owner_id}:{offset}")])
    if has_more:
        rows.append([InlineKeyboardButton("➡️ پست‌های بعدی", callback_data=f"myawy_feed:{platform_id}:{owner_id}:{offset + 3}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_platform_view:{platform_id}:{owner_id}")])
    return InlineKeyboardMarkup(rows)


# ---------------------------------------------------------------------------
# گوشی‌فروشی / کشو / تعمیرات / بازارِ سیاه
# ---------------------------------------------------------------------------

def myawy_shop_keyboard(items, owner_id: int):
    """items: لیستِ (generation_id, label)."""
    rows = [[InlineKeyboardButton(label, callback_data=f"myawy_shop_view:{gid}:{owner_id}")] for gid, label in items]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def myawy_shop_view_keyboard(gen_id: int, owner_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 خرید", callback_data=f"myawy_shop_buy:{gen_id}:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_shop:{owner_id}")],
    ])


def myawy_drawer_keyboard(items, owner_id: int):
    """items: لیستِ (phone_id, label)."""
    rows = [[InlineKeyboardButton(label, callback_data=f"myawy_phone_view:{pid}:{owner_id}")] for pid, label in items]
    rows.append([InlineKeyboardButton("🏪 خریدِ گوشیِ جدید", callback_data=f"myawy_shop:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def myawy_phone_view_keyboard(phone_id: int, owner_id: int, is_equipped: bool, has_broken: bool, is_expired: bool):
    rows = []
    if not is_equipped:
        rows.append([InlineKeyboardButton("🔌 استفاده از این گوشی", callback_data=f"myawy_phone_equip:{phone_id}:{owner_id}")])
    if has_broken:
        for key, label in (("lcd", "📺 تعمیرِ ال‌سی‌دی"), ("battery", "🔋 تعمیرِ باتری"), ("cpu", "💽 تعمیرِ سی‌پی‌یو")):
            rows.append([InlineKeyboardButton(label, callback_data=f"myawy_phone_repair_pay:{phone_id}:{owner_id}:{key}")])
    if not is_expired:
        rows.append([InlineKeyboardButton("🏴 گذاشتن تو بازارِ سیاه", callback_data=f"myawy_phone_sell_ask:{phone_id}:{owner_id}")])
    else:
        rows.append([InlineKeyboardButton("🏴 فروش تو بازارِ سیاه", callback_data=f"myawy_phone_sell_ask:{phone_id}:{owner_id}")])
    rows.append([InlineKeyboardButton("🗑 دور انداختن", callback_data=f"myawy_phone_discard_ask:{phone_id}:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_drawer:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def myawy_phone_discard_confirm_keyboard(phone_id: int, owner_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ بله، دورش بنداز", callback_data=f"myawy_phone_discard_confirm:{phone_id}:{owner_id}"),
         InlineKeyboardButton("❌ انصراف", callback_data=f"myawy_phone_view:{phone_id}:{owner_id}")],
    ])


def myawy_bm_keyboard(items, owner_id: int, my_listings_count: int):
    """items: لیستِ (listing_id, label)."""
    rows = [[InlineKeyboardButton(label, callback_data=f"myawy_bm_buy_ask:{lid}:{owner_id}")] for lid, label in items]
    rows.append([InlineKeyboardButton(f"🏴 آگهی‌های من ({my_listings_count})", callback_data=f"myawy_bm_mine:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def myawy_bm_buy_confirm_keyboard(listing_id: int, owner_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ بله، بخر", callback_data=f"myawy_bm_buy_confirm:{listing_id}:{owner_id}"),
         InlineKeyboardButton("❌ انصراف", callback_data=f"myawy_bm:{owner_id}")],
    ])


def myawy_bm_mine_keyboard(items, owner_id: int):
    """items: لیستِ (listing_id, label)."""
    rows = [[InlineKeyboardButton(f"❌ لغوِ «{label}»", callback_data=f"myawy_bm_cancel:{lid}:{owner_id}")] for lid, label in items]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"myawy_bm:{owner_id}")])
    return InlineKeyboardMarkup(rows)


# ---------------------------------------------------------------------------
# تاکسیِ هاپویی
# ---------------------------------------------------------------------------

def taxi_home_keyboard(owner_id: int, user, car):
    rows = []
    if not car:
        rows.append([InlineKeyboardButton("🏪 خریدِ ماشین", callback_data=f"taxi_shop:{owner_id}")])
        return InlineKeyboardMarkup(rows)

    state = user.taxi_state
    if state == "idle":
        rows.append([InlineKeyboardButton("🚕 شروعِ تاکسی‌رانی", callback_data=f"taxi_start:{owner_id}")])
    elif state in ("at_station", "en_route", "returning"):
        rows.append([InlineKeyboardButton("🛑 کنسل‌کردنِ تاکسی‌رانی", callback_data=f"taxi_cancel_ask:{owner_id}")])
    elif state == "shift_complete":
        rows.append([InlineKeyboardButton("🏧 برداشتِ درآمد", callback_data=f"taxi_withdraw:{owner_id}")])
    elif state == "resting":
        rows.append([InlineKeyboardButton("😴 در حالِ استراحت...", callback_data=f"taxi_home:{owner_id}")])

    rows.append([
        InlineKeyboardButton("🏎 ارتقای موتور", callback_data=f"taxi_upgrade_engine:{owner_id}"),
        InlineKeyboardButton("⭐️ ارتقای محبوبیت", callback_data=f"taxi_upgrade_appeal:{owner_id}"),
    ])
    rows.append([InlineKeyboardButton("🎖 رفتن به مقامِ بعد", callback_data=f"taxi_advance_rank_ask:{owner_id}")])
    rows.append([
        InlineKeyboardButton("🧼 کارواش", callback_data=f"taxi_carwash:{owner_id}"),
        InlineKeyboardButton("⛽️ باک‌زدن", callback_data=f"taxi_refuel:{owner_id}"),
    ])
    rows.append([InlineKeyboardButton("🏪 عوض‌کردنِ ماشین", callback_data=f"taxi_shop:{owner_id}")])
    rows.append([InlineKeyboardButton("🔄 بروزرسانیِ وضعیت", callback_data=f"taxi_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def taxi_shop_keyboard(items, owner_id: int):
    """items: لیستِ (car_model_id, label)."""
    rows = [[InlineKeyboardButton(label, callback_data=f"taxi_shop_view:{cid}:{owner_id}")] for cid, label in items]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"taxi_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def taxi_shop_view_keyboard(car_id: int, owner_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("💳 خرید", callback_data=f"taxi_shop_buy_ask:{car_id}:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"taxi_shop:{owner_id}")],
    ])


# ---------------------------------------------------------------------------
# کارتِ هاپویی
# ---------------------------------------------------------------------------

def cards_home_keyboard(owner_id: int, active: bool, has_sellable: bool):
    rows = []
    if active:
        rows.append([
            InlineKeyboardButton("🔹 کمیاب", callback_data=f"cards_list_view:1:{owner_id}"),
            InlineKeyboardButton("🔸 جنگلی", callback_data=f"cards_list_view:2:{owner_id}"),
            InlineKeyboardButton("👑 لجند", callback_data=f"cards_list_view:3:{owner_id}"),
        ])
        rows.append([InlineKeyboardButton("📋 آگهی‌های کارت", callback_data=f"cards_market:{owner_id}")])
    if has_sellable:
        rows.append([InlineKeyboardButton("🗑 فروشِ کارت‌های تکراریِ ایونتِ قبل", callback_data=f"cards_sell_duplicates:{owner_id}")])
    if not rows:
        rows.append([InlineKeyboardButton("🔄 بروزرسانی", callback_data=f"cards_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def cards_list_keyboard(list_no: int, owner_id: int, has_free: bool, price: float):
    rows = []
    if has_free:
        rows.append([InlineKeyboardButton("🎲 کشیدنِ توکنِ رایگان", callback_data=f"cards_draw_free:{list_no}:{owner_id}")])
    rows.append([InlineKeyboardButton(f"💳 خریدِ توکن ({price:,.0f}🪙 - بدونِ تکراری)", callback_data=f"cards_buy_token:{list_no}:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"cards_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def cards_sell_pick_list_keyboard(owner_id: int):
    rows = [
        [InlineKeyboardButton("🔹 کمیاب", callback_data=f"cards_market_sell_list:1:{owner_id}"),
         InlineKeyboardButton("🔸 جنگلی", callback_data=f"cards_market_sell_list:2:{owner_id}"),
         InlineKeyboardButton("👑 لجند", callback_data=f"cards_market_sell_list:3:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"cards_market:{owner_id}")],
    ]
    return InlineKeyboardMarkup(rows)


def cards_sell_pick_slot_keyboard(my_slots, owner_id: int):
    """my_slots: لیستِ (CardSlot, count)."""
    rows = [
        [InlineKeyboardButton(f"{s.emoji}" + (f" (×{c})" if c > 1 else ""), callback_data=f"cards_market_sell_pick:{s.id}:{owner_id}")]
        for s, c in my_slots
    ]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"cards_market:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def cards_market_keyboard(items, owner_id: int, my_count: int):
    """items: لیستِ (listing_id, label)."""
    rows = [[InlineKeyboardButton(label, callback_data=f"cards_market_buy_ask:{lid}:{owner_id}")] for lid, label in items]
    rows.append([InlineKeyboardButton("💰 فروشِ یه کارتِ من", callback_data=f"cards_market_sell_ask:{owner_id}")])
    rows.append([InlineKeyboardButton(f"📋 آگهی‌های من ({my_count})", callback_data=f"cards_market_mine:{owner_id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"cards_home:{owner_id}")])
    return InlineKeyboardMarkup(rows)


def cards_market_buy_confirm_keyboard(listing_id: int, owner_id: int):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("✅ بله، بخر", callback_data=f"cards_market_buy_confirm:{listing_id}:{owner_id}"),
         InlineKeyboardButton("❌ انصراف", callback_data=f"cards_market:{owner_id}")],
    ])


def cards_market_mine_keyboard(items, owner_id: int):
    """items: لیستِ (listing_id, emoji)."""
    rows = [[InlineKeyboardButton(f"❌ لغوِ «{label}»", callback_data=f"cards_market_cancel:{lid}:{owner_id}")] for lid, label in items]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"cards_market:{owner_id}")])
    return InlineKeyboardMarkup(rows)


# ---------------------------------------------------------------------------
# کدِ جایزه‌ی هاپویی
# ---------------------------------------------------------------------------

def redeem_home_keyboard(owner_id: int):
    return InlineKeyboardMarkup([[InlineKeyboardButton("🎁 واردکردنِ کد", callback_data=f"redeem_start:{owner_id}")]])
