# -*- coding: utf-8 -*-
"""
🌌 مدیریتِ Frontier — زیرمجموعه‌ی پنلِ «مدیریتِ جنگ هاپویی» (همون دسترسیِ «war»؛ همه‌ی callback ها با admin_war_ شروع می‌شن).
- جدول‌ها (مناطق/مراحل/باس‌ها/رویدادها/افتخارات): ویرایشگرِ عمومیِ war_admin (admin_war_tbl:fr_*)
- کانفیگ: admin_war_cfg:<page>:fr
- فصل / رویداد / ابزارِ باس و عملیات / داشبورد / اعلانِ راه‌اندازی: اینجا
هر تغییرِ مدیریتی Actor و دلیل رو تو WarAudit ثبت می‌کنه (S.audit).
"""
import asyncio
import datetime
import logging

from sqlalchemy import func
from telegram import InlineKeyboardButton as Btn

import db
import war_db as W
import war_svc as S
import war_admin as WA
import frontier_db as F
import frontier_svc as FS
from war_svc import WarError, ci
from war_text import fmt, short

logger = logging.getLogger(__name__)


def _rows_back(rows):
    return rows + [[Btn("🔙 Frontier", callback_data="admin_war_fr")]]


async def cb_fr_menu(update, context):
    session = db.get_session()
    try:
        on = ci(session, "frontier_enabled", 1)
        season = FS.current_season(session, create=False)
        n_runs = session.query(F.FrontierRun).filter_by(status="marching").count()
        n_boss = session.query(F.FrontierBossState).filter_by(status="active").count()
        ev = FS.active_events(session)
        sline = f"📅 {season.name} (تا {season.end_at:%Y-%m-%d %H:%M})" if season else "📅 فصلِ فعالی نیست"
        session.commit()
    finally:
        session.close()
    rows = [[Btn(f"{'🟢' if on else '🔴'} Frontier", callback_data="admin_war_frtoggle")],
            [Btn("📅 فصل جدید", callback_data="admin_war_frseason:new"), Btn("➕ تمدید", callback_data="admin_war_frseason:ext"),
             Btn("🏁 پایان فصل", callback_data="admin_war_frseason:end")],
            [Btn("🌌 مناطق", callback_data="admin_war_tbl:fr_region:0"), Btn("🧭 مراحل", callback_data="admin_war_tbl:fr_node:0")],
            [Btn("🐉 باس‌ها", callback_data="admin_war_tbl:fr_boss:0"), Btn("🎖 افتخارات", callback_data="admin_war_tbl:fr_honor:0")],
            [Btn("🎉 رویدادها", callback_data="admin_war_tbl:fr_event:0"), Btn("⚙️ تنظیمات", callback_data="admin_war_cfg:0:fr")],
            [Btn("⚡ ایونتِ سریع", callback_data="admin_war_frev"), Btn("🎁 قوانین پاداش", callback_data="admin_war_tbl:rule:0")],
            [Btn("🐉 مدیریتِ باس‌های زنده", callback_data="admin_war_frboss"), Btn("🛑 لغوِ عملیات", callback_data="admin_war_frrun")],
            [Btn("📊 داشبورد", callback_data="admin_war_frdash"), Btn("🏰 مشارکتِ قبیله‌ها", callback_data="admin_war_frclans")],
            [Btn("📣 اعلانِ راه‌اندازی", callback_data="admin_war_frann")],
            [Btn("🔙 مدیریتِ جنگ", callback_data="admin_war_menu")]]
    await WA._send(update, f"🌌 مدیریتِ Frontier\n{sline}\n🛰 عملیاتِ فعال: {n_runs} | 🐉 باسِ زنده: {n_boss} | 🎉 رویدادِ فعال: {len(ev)}\n"
                           "(همه‌ی اعداد بدونِ تغییرِ کد و بلافاصله اثر می‌کنن)", rows)


async def cb_fr_toggle(update, context):
    session = db.get_session()
    try:
        new = "0" if ci(session, "frontier_enabled", 1) else "1"
        db.cfg_set(session, "frontier_enabled", new)
        S.audit(session, update.effective_user.id, "admin_frontier_toggle", value=new)
        session.commit()
    finally:
        session.close()
    await cb_fr_menu(update, context)


async def cb_fr_season(update, context):
    act = update.callback_query.data.split(":")[1]
    prompts = {"new": "📅 فصلِ جدید (فصلِ فعلی تسویه می‌شه!)\nفرمت: <تعدادِ روز> <دلیل>\nمثال: 28 شروعِ فصلِ ۲",
               "ext": "➕ تمدیدِ فصل\nفرمت: <تعدادِ روز> <دلیل>", "end": "🏁 پایانِ فوریِ فصل (تسویه و پرداختِ جوایز)\nفقط دلیل رو بنویس:"}
    await WA._ask(update, context, prompts[act], {"type": "war_frx", "kind": "season_" + act})


async def cb_fr_ev(update, context):
    await WA._ask(update, context, "⚡ ایونتِ سریع\nفرمت: <نوع> <منطقه|-> <ساعت> <ضریبِ قدرتِ دشمن> <ضریبِ پاداش> <ضریبِ امتیاز> [کلیدِ باس/مرحله]\n"
                                   "نوع‌ها: storm (طوفان) | conquest (آخر هفته‌ی فتح) | awakening (باسِ رویداد) | treasure (اتاقِ گنج)\n"
                                   "مثال طوفان: storm glass 6 1.25 1.3 1\n"
                                   "مثال بیداری: awakening ironwood 24 1 1 1 boss_ironwood_awake\n"
                                   "مثال گنجینه: treasure plains 12 1 1 1 pl_vault",
                  {"type": "war_frx", "kind": "event"})


async def cb_fr_boss(update, context):
    session = db.get_session()
    try:
        rows_db = session.query(F.FrontierBossState).filter_by(status="active").order_by(F.FrontierBossState.id.desc()).limit(10).all()
        lines = ["🐉 باس‌های زنده (۱۰ تای آخر)", "فرمت‌ها:", "• HP: hp <id> <مقدار> <دلیل>", "• ریست: reset <id> <دلیل>", "• اخراجِ باسِ خراب: expire <id> <دلیل>", ""]
        for s_ in rows_db:
            lines.append(f"#{s_.id} {s_.boss_key} [{s_.scope}:{s_.scope_id}] HP {fmt(s_.hp)}/{fmt(s_.hp_max)}")
    finally:
        session.close()
    await WA._ask(update, context, "\n".join(lines), {"type": "war_frx", "kind": "boss"})


async def cb_fr_run(update, context):
    await WA._ask(update, context, "🛑 لغوِ عملیاتِ Frontier (نیرو/سوخت/مواد/هزینه ۱۰۰٪ برمی‌گرده)\nفرمت: <شماره‌ی عملیات> <دلیل>", {"type": "war_frx", "kind": "run"})


async def cb_fr_ann(update, context):
    await WA._ask(update, context, "📣 اعلانِ راه‌اندازیِ Frontier\nبرای کی؟ بنویس:\n• war  → همه‌ی بازیکن‌های جنگ\n• all  → همه‌ی کاربرانِ ربات (ممکنه طول بکشه)\n"
                                   "اختیاری: بعدش یه خط متنِ دلخواه بنویس (وگرنه متنِ پیش‌فرض).", {"type": "war_frx", "kind": "announce"})


async def cb_fr_dash(update, context):
    session = db.get_session()
    try:
        now = FS.utcnow()
        since = now - datetime.timedelta(hours=24)
        by = dict(session.query(F.FrontierRun.outcome, func.count(F.FrontierRun.id)).filter(F.FrontierRun.created_at >= since).group_by(F.FrontierRun.outcome).all())
        act = session.query(F.FrontierRun).filter_by(status="marching").count()
        users = session.query(func.count(func.distinct(F.FrontierRun.user_id))).filter(F.FrontierRun.created_at >= since).scalar() or 0
        claims = session.query(F.FrontierRewardClaim.trigger, func.count(F.FrontierRewardClaim.id), func.sum(F.FrontierRewardClaim.hop), func.sum(F.FrontierRewardClaim.xp)) \
            .filter(F.FrontierRewardClaim.created_at >= since).group_by(F.FrontierRewardClaim.trigger).all()
        day = FS._day()
        cap_hours = session.query(func.sum(F.FrontierDaily.ref_hours)).filter_by(day=day).scalar() or 0
        pts = session.query(func.sum(F.FrontierDaily.points)).filter_by(day=day).scalar() or 0
        bosses = dict(session.query(F.FrontierBossState.status, func.count(F.FrontierBossState.id)).group_by(F.FrontierBossState.status).all())
        regions_clear = session.query(F.FrontierProgress.node_key, func.count(F.FrontierProgress.id)).filter(
            F.FrontierProgress.clears >= 1, ~F.FrontierProgress.node_key.like("\\_%", escape="\\")).group_by(F.FrontierProgress.node_key).all()
        lines = ["📊 داشبوردِ Frontier (۲۴ ساعت)", f"👥 بازیکنِ فعال: {users} | 🛰 در جریان: {act}",
                 f"✅ برد: {by.get('win', 0)} | ❌ باخت: {by.get('lose', 0)} | 📦 پشتیبانی: {by.get('support', 0)} | ↩️ لغو: {by.get('void', 0)}",
                 f"🏳️ امروز: {pts:,.0f} امتیازِ فتح | 💠 {cap_hours:.1f} ساعتِ مرجعِ پاداشِ سقف‌دار",
                 f"🐉 باس‌ها: " + ", ".join(f"{k}:{v}" for k, v in bosses.items()), "", "🎁 اقتصادِ پاداش‌های یک‌بارمصرف (۲۴ ساعت):"]
        tot = 0
        for t, n, hop, xp in claims:
            lines.append(f"• {t or '—'}: {n} بار | {short(hop or 0)} هاپ | ⭐{(xp or 0):.0f}")
            tot += hop or 0
        lines.append(f"جمع: {short(tot)} هاپ")
        top = sorted(regions_clear, key=lambda x: -x[1])[:5]
        if top:
            lines.append("\n🔥 پرکلیرترین مراحل: " + ", ".join(f"{k}({v})" for k, v in top))
        s_ = FS.current_season(session, create=False)
        if s_:
            lines.append("\n🏆 فصل: " + ", ".join(f"#{r.clan_id}:{r.total:,.0f}" for r in FS.leaderboard(session, s_, None, 5)))
        session.commit()
    finally:
        session.close()
    await WA._send(update, "\n".join(lines), _rows_back([]))


async def cb_fr_clans(update, context):
    session = db.get_session()
    try:
        s_ = FS.current_season(session, create=False)
        lines = ["🏰 مشارکتِ قبیله‌ها در فصل", ""]
        if s_:
            for r in FS.leaderboard(session, s_, None, 15):
                cl = session.get(W.WarClan, r.clan_id)
                lines.append(f"{cl.name if cl else r.clan_id}: امتیاز {r.total:,.0f} | فعال {r.active_members}/{r.members_n} | باس {r.boss_kills} | عملیات {r.ops} | لیگ {r.bracket}")
        else:
            lines.append("فصلی فعال نیست.")
        session.commit()
    finally:
        session.close()
    await WA._send(update, "\n".join(lines), _rows_back([]))


def _split_reason(parts, n):
    reason = " ".join(parts[n:]).strip()
    if not reason:
        raise WarError("دلیل الزامیه (برای آدیت).")
    return reason


async def handle_input(session, update, state, text, uid):
    kind = state["kind"]
    parts = text.split()
    if kind in ("season_new", "season_ext"):
        if not parts:
            raise WarError("فرمت: <روز> <دلیل>")
        days = float(parts[0].translate(str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")))
        reason = _split_reason(parts, 1)
        if kind == "season_new":
            s_ = FS.start_season(session, uid, days=days, reason=reason)
            return f"✅ فصلِ «{s_.name}» شروع شد ({days:g} روز). فصلِ قبلی تسویه شد."
        cur = FS.current_season(session, create=False)
        if not cur:
            raise WarError("فصلِ فعالی نیست.")
        FS.extend_season(session, uid, cur.id, days, reason)
        return f"✅ فصل {days:g} روز تمدید شد."
    if kind == "season_end":
        cur = FS.current_season(session, create=False)
        if not cur:
            raise WarError("فصلِ فعالی نیست.")
        FS.end_season(session, uid, cur.id, text)
        return "✅ فصل تموم و جوایز پرداخت شد."
    if kind == "event":
        if len(parts) < 6:
            raise WarError("فرمت: <نوع> <منطقه|-> <ساعت> <قدرت> <پاداش> <امتیاز> [کلید]")
        k, region, hours, pm, rm, ptm = parts[:6]
        extra = parts[6] if len(parts) > 6 else ""
        if k not in ("storm", "conquest", "awakening", "treasure"):
            raise WarError("نوعِ نامعتبر.")
        region = "" if region == "-" else region
        if region and not session.get(F.FrontierRegion, region):
            raise WarError("منطقه پیدا نشد.")
        if k == "awakening" and not session.get(F.FrontierBossDef, extra):
            raise WarError("کلیدِ باسِ رویداد لازمه.")
        if k == "treasure" and not session.get(F.FrontierNode, extra):
            raise WarError("کلیدِ مرحله‌ی گنج لازمه.")
        names = {"storm": "🌪 طوفان", "conquest": "⚔️ آخر هفته‌ی فتح", "awakening": "🔥 بیداریِ غولِ آهنین", "treasure": "💎 گنجینه‌ی باستانی"}
        now = FS.utcnow()
        e = F.FrontierEvent(kind=k, name=names[k], region_key=region, boss_key=extra if k == "awakening" else "", node_key=extra if k == "treasure" else "",
                            power_mult=float(pm), reward_mult=float(rm), xp_mult=float(rm), points_mult=float(ptm),
                            start_at=now, end_at=now + datetime.timedelta(hours=float(hours)), enabled=True, note=f"by {uid}")
        session.add(e)
        session.flush()
        S.audit(session, uid, "admin_frontier_event", id=e.id, kind=k, region=region, hours=hours)
        return f"✅ رویدادِ #{e.id} ({names[k]}) برای {hours} ساعت فعال شد."
    if kind == "boss":
        if len(parts) < 3:
            raise WarError("فرمت: hp <id> <مقدار> <دلیل> | reset <id> <دلیل> | expire <id> <دلیل>")
        op, sid = parts[0], int(parts[1])
        st = session.query(F.FrontierBossState).filter_by(id=sid).with_for_update().first()
        if not st:
            raise WarError("نمونه‌ی باس پیدا نشد.")
        if op == "hp":
            val = float(parts[2])
            reason = _split_reason(parts, 3)
            st.hp = max(1.0, min(val, st.hp_max))
            S.audit(session, uid, "admin_frontier_boss_hp", state=sid, hp=st.hp, reason=reason)
            return f"✅ HP باس #{sid} = {fmt(st.hp)}"
        if op == "reset":
            reason = _split_reason(parts, 2)
            st.hp, st.status, st.defeated_at, st.paid = st.hp_max, "active", None, False
            S.audit(session, uid, "admin_frontier_boss_reset", state=sid, reason=reason)
            return f"✅ باس #{sid} ریست شد (پاداش‌های قبلی دست‌نخورده؛ کلیم‌ها دوباره پرداخت نمی‌شن)."
        if op == "expire":
            reason = _split_reason(parts, 2)
            st.status = "expired"
            S.audit(session, uid, "admin_frontier_boss_expire", state=sid, reason=reason)
            return f"✅ باس #{sid} غیرفعال شد."
        raise WarError("عملیاتِ نامعتبر.")
    if kind == "run":
        if len(parts) < 2:
            raise WarError("فرمت: <شماره> <دلیل>")
        rid = int(parts[0])
        reason = _split_reason(parts, 1)
        if not FS.cancel_run(session, rid, "admin", 100.0, actor=uid):
            raise WarError("عملیاتِ در جریانی با این شماره نیست.")
        S.audit(session, uid, "admin_frontier_run_cancel", run=rid, reason=reason)
        return f"✅ عملیات #{rid} لغو شد و همه‌چیز برگشت."
    if kind == "announce":
        target = parts[0] if parts else ""
        if target not in ("war", "all"):
            raise WarError("war یا all")
        custom = text.partition("\n")[2].strip()
        S.audit(session, uid, "admin_frontier_announce", target=target)
        if target == "war":
            ids = [r[0] for r in session.query(W.WarPlayer.user_id).all()]
        else:
            ids = [r[0] for r in session.query(db.User.telegram_id).all()]
        asyncio.get_event_loop().create_task(_broadcast(update.get_bot() if hasattr(update, "get_bot") else update.message.get_bot(), ids, custom))
        return f"📣 ارسال به {len(ids)} نفر شروع شد (در پس‌زمینه)."
    raise WarError("اقدامِ ناشناخته.")


DEFAULT_ANN = ("🌌 مرزهای هاپویی باز شد!\n\n۶ سرزمینِ ناشناخته، باس‌های افسانه‌ای، اتاق‌های مخفی و جایزه‌های روزِ اول 🎁\n"
               "• هدیه‌ی ورود: هاپ + XP + سوختِ پر\n• هفته‌ی راه‌اندازی: پاداش‌ها ۱٫۵ برابر!\n• بدونِ قبیله هم می‌تونی کاوش کنی\n\n"
               "بنویس: «مرزهای هاپویی»")


async def _broadcast(bot, ids, custom):
    msg = custom or DEFAULT_ANN
    ok = 0
    for i, u in enumerate(ids):
        try:
            await bot.send_message(chat_id=u, text=msg)
            ok += 1
        except Exception:
            pass
        if i % 20 == 19:
            await asyncio.sleep(1.0)
    logger.info("frontier announce: %s/%s delivered", ok, len(ids))


WA.ADMIN_WAR_CALLBACKS.update({
    "admin_war_fr": cb_fr_menu, "admin_war_frtoggle": cb_fr_toggle, "admin_war_frseason": cb_fr_season, "admin_war_frev": cb_fr_ev,
    "admin_war_frboss": cb_fr_boss, "admin_war_frrun": cb_fr_run, "admin_war_frann": cb_fr_ann, "admin_war_frdash": cb_fr_dash,
    "admin_war_frclans": cb_fr_clans,
})
