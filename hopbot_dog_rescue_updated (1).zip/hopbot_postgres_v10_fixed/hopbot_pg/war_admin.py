# -*- coding: utf-8 -*-
"""
پنل ادمینِ «جنگ هاپویی». همه‌چیز Data-driven:
- ویرایشگرِ عمومیِ جدول‌ها (تجهیزات، ساختمان‌ها، نوع نبرد، قوانین پاداش، آنلاک، مأموریت، دستاورد، تحقیق، ایونت، Alias)
  → هر مورد بدونِ تغییرِ کد ساخته/ویرایش/حذف/غیرفعال می‌شه و بلافاصله در بازی اثر می‌کنه.
- کانفیگِ war_* (درصدها/مقادیر)، انتشارِ نسخه‌ی جدیدِ فرمولِ نبرد، داشبورد، شبیه‌سازیِ Read-Only، تعدیلِ هاپ با لجر.
"""
import datetime
import json
import math

from sqlalchemy import func
from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb
from telegram.ext import ApplicationHandlerStop

import db
import war_db as W
import war_svc as S
import war_engine as E
import war_battle as B
from war_svc import WarError, cf, ci, utcnow
from war_text import normalize, fmt, short
import war_labels as LB
import frontier_db as FR_DB

PAGE = 8

TABLES = {
    "unit": (W.WarUnitDef, "key", "🚀 تجهیزات"),
    "bld": (W.WarBuildingDef, "key", "🏗 ساختمان‌ها"),
    "btype": (W.WarBattleType, "key", "⚔️ نوع نبرد"),
    "rule": (W.WarRewardRule, "trigger", "🎁 قوانین پاداش"),
    "unlock": (W.WarUnlockRule, "feature", "🔓 آنلاک‌ها"),
    "quest": (W.WarQuestDef, "key", "🎯 مأموریت‌ها"),
    "ach": (W.WarAchievementDef, "key", "🏆 دستاوردها"),
    "rsrch": (W.WarResearchDef, "key", "🔬 تحقیقات"),
    "event": (W.WarEvent, "id", "🎉 ایونت‌ها"),
    "alias": (W.WarAlias, "id", "💬 Aliasهای تریگر"),
    # 🌌 Frontier (در منوی جنگ نمایش داده نمی‌شن؛ از «🌌 Frontier» باز می‌شن)
    "fr_region": (FR_DB.FrontierRegion, "key", "🌌 مناطق Frontier"),
    "fr_node": (FR_DB.FrontierNode, "key", "🧭 مراحل Frontier"),
    "fr_boss": (FR_DB.FrontierBossDef, "key", "🐉 باس‌ها"),
    "fr_event": (FR_DB.FrontierEvent, "id", "🎉 رویدادهای Frontier"),
    "fr_honor": (FR_DB.FrontierHonorDef, "key", "🎖 افتخارات Frontier"),
}

# کلیدهایی که متن/JSON هستن (نه عدد)
TEXT_CFG = FR_DB.TEXT_KEYS | {"war_leagues", "war_league_weekly_ref_hours", "war_shield_rules", "war_antifarm_steps", "war_f_star_thresholds",
            "war_f_counter_matrix", "war_clan_perms", "war_clan_rank_names"}


def _cols(model):
    return [c for c in model.__table__.columns]


def _label(row, pk):
    for attr in ("name", "label", "text", "feature", "trigger", "key"):
        v = getattr(row, attr, None)
        if v:
            return f"{v}" if attr == pk else f"{v} ({getattr(row, pk)})"
    return str(getattr(row, pk))


def _coerce(col, raw: str):
    t = type(col.type).__name__
    raw = raw.strip()
    if t in ("Integer", "BigInteger"):
        return int(float(raw))
    if t == "Float":
        return float(raw)
    if t == "Boolean":
        return raw.lower() in ("1", "true", "yes", "y", "on", "بله", "آره", "فعال", "روشن")
    if t == "DateTime":
        return datetime.datetime.strptime(raw, "%Y-%m-%d %H:%M")
    return raw


def _kb(rows):
    return Kb(rows)


async def _send(update, text, rows):
    from handlers import send_response
    return await send_response(update, text, _kb(rows))


async def _ask(update, context, text, state):
    from handlers import ask_for_input
    await ask_for_input(update, context, text, state, "admin_state", "admin_war_menu")


# ---------------------------------------------------------------------------
# منوی اصلی
# ---------------------------------------------------------------------------

async def cb_war_menu(update, context):
    session = db.get_session()
    try:
        v = ci(session, "war_formula_version", 1)
        on = ci(session, "war_enabled", 1)
    finally:
        session.close()
    rows = [[Btn(f"{'🟢' if on else '🔴'} سیستمِ جنگ", callback_data="admin_war_toggle")],
            [Btn("⚙️ تنظیمات و درصدها", callback_data="admin_war_cfg:0")],
            [Btn(f"🧮 فرمولِ نبرد (v{v}) – انتشارِ نسخه‌ی جدید", callback_data="admin_war_formula")],
            [Btn("📊 داشبورد", callback_data="admin_war_dash:24"), Btn("🧪 شبیه‌سازی", callback_data="admin_war_sim")]]
    keys = [k for k in TABLES if not k.startswith("fr_")]
    rows.append([Btn("🌌 Frontier (مرزهای هاپویی)", callback_data="admin_war_fr")])
    for i in range(0, len(keys), 2):
        rows.append([Btn(TABLES[k][2], callback_data=f"admin_war_tbl:{k}:0") for k in keys[i:i + 2]])
    rows.append([Btn("💠 تعدیلِ هاپ (لجر)", callback_data="admin_war_adj"), Btn("🛑 لغوِ نبرد", callback_data="admin_war_cancelb")])
    rows.append([Btn("♻️ بازکالیبراسیونِ قیمت‌ها", callback_data="admin_war_recal"), Btn("📜 آدیت", callback_data="admin_war_audit")])
    rows.append([Btn("🔙 پنل مدیریت", callback_data="admin_panel")])
    await _send(update, "⚔️ مدیریتِ جنگ هاپویی\n(همه‌ی اعداد/تجهیزات/پاداش‌ها/آنلاک‌ها از همین‌جا؛ بدونِ تغییرِ کد)", rows)


async def cb_war_toggle(update, context):
    session = db.get_session()
    try:
        db.cfg_set(session, "war_enabled", "0" if ci(session, "war_enabled", 1) else "1")
        S.audit(session, update.effective_user.id, "admin_war_toggle")
        session.commit()
    finally:
        session.close()
    await cb_war_menu(update, context)


# ---------------------------------------------------------------------------
# کانفیگ
# ---------------------------------------------------------------------------

async def cb_war_cfg(update, context):
    _parts = update.callback_query.data.split(":")
    page = int(_parts[1])
    _fr = _parts[2:3] == ["fr"]
    _suf = ":fr" if _fr else ""
    keys = sorted(k for k in set(W.WAR_DEFAULT_CONFIG) | set(FR_DB.FRONTIER_DEFAULT_CONFIG) if k.startswith("frontier_") == _fr)
    pages = max(1, math.ceil(len(keys) / 12))
    page = max(0, min(page, pages - 1))
    session = db.get_session()
    try:
        lines = [f"⚙️ تنظیماتِ جنگ ({page + 1}/{pages})", "(موارد «🧮» پیش‌نویسِ فرمولِ نبردن؛ با «انتشارِ نسخه‌ی جدید» اعمال می‌شن)", ""]
        rows = []
        for k in keys[page * 12:(page + 1) * 12]:
            v = str(db.cfg_get(session, k))
            lab = LB.cfg_label(k)
            lines.append(f"• {lab}: {v[:40]}")
            rows.append([Btn("✏️ " + lab[:50], callback_data=f"admin_war_cfgk:{k}")])
    finally:
        session.close()
    nav = [Btn("◀️", callback_data=f"admin_war_cfg:{max(0, page - 1)}{_suf}"), Btn(f"{page + 1}/{pages}", callback_data="admin_war_noop"),
           Btn("▶️", callback_data=f"admin_war_cfg:{min(pages - 1, page + 1)}{_suf}")]
    rows.append(nav)
    rows.append([Btn("🔙", callback_data="admin_war_fr" if _fr else "admin_war_menu")])
    await _send(update, "\n".join(lines), rows)


async def cb_war_cfgk(update, context):
    key = update.callback_query.data.split(":", 1)[1]
    session = db.get_session()
    try:
        cur = db.cfg_get(session, key)
    finally:
        session.close()
    await _ask(update, context, f"✏️ {LB.cfg_label(key)}\n(نامِ فنی: {key})\nمقدارِ فعلی: {cur}\nمقدارِ جدید رو بفرست:", {"type": "war_cfg", "key": key})


def validate_cfg(key, value: str) -> str:
    """خطا رو برمی‌گردونه ('' یعنی معتبر). جلوی مقادیرِ مخربِ بالانس رو هم می‌گیره."""
    if key not in W.WAR_DEFAULT_CONFIG and key not in FR_DB.FRONTIER_DEFAULT_CONFIG:
        return "کلیدِ ناشناخته"
    if key == "frontier_routes":
        try:
            import frontier_engine as _FE
            d = json.loads(value)
            if not isinstance(d, dict) or not all(k in d for k in _FE.ROUTE_KEYS):
                return "JSON باید assault/infiltration/logistics داشته باشه"
            for r in d.values():
                if any(not isinstance(v, (int, float)) for k, v in r.items() if k not in ("name", "emoji")):
                    return "مقادیر باید عدد باشن"
        except ValueError:
            return "JSON نامعتبر"
        return ""
    if key == "frontier_stealth_cats":
        return ""
    if key == "war_f_counter_matrix":
        try:
            return E.validate_counter_matrix(json.loads(value))
        except ValueError:
            return "JSON نامعتبر"
    if key == "war_clan_perms":
        try:
            d = json.loads(value)
            if not isinstance(d, dict) or any(not isinstance(v, int) or not 1 <= v <= 5 for v in d.values()):
                return "همه‌ی مقادیر باید عددِ ۱ تا ۵ باشن"
        except ValueError:
            return "JSON نامعتبر"
        return ""
    if key == "war_clan_rank_names":
        return "" if len([x for x in value.split(",") if x.strip()]) == 5 else "دقیقاً ۵ نام (با کاما) لازمه"
    if key == "war_shield_rules":
        for tok in value.split(","):
            try:
                a, b = tok.split(":")
                float(a), float(b)
            except ValueError:
                return "فرمت: تخریب:ساعت,تخریب:ساعت"
        return ""
    if key == "war_leagues":
        for tok in value.split(","):
            if ":" not in tok:
                return "فرمت: نام:کاپ,نام:کاپ"
            try:
                int(tok.rsplit(":", 1)[1])
            except ValueError:
                return "کاپ باید عدد باشه"
        return ""
    if key in TEXT_CFG:
        try:
            [float(x) for x in value.split(",") if x.strip()]
        except ValueError:
            return "لیستِ عددی با کاما لازمه"
        return ""
    try:
        v = float(value)
    except ValueError:
        return "مقدارِ عددی لازمه"
    if v != v or v in (float("inf"), float("-inf")):
        return "مقدارِ نامعتبر"
    if v < 0 and key != "minlvl_war":
        return "منفی مجاز نیست"
    if key == "war_income_multiplier" and not 0.5 <= v <= 10:
        return "ضریبِ درآمدِ جنگ باید بینِ ۰٫۵ و ۱۰ باشه (پیش‌فرض ۳٫۵)"
    if key == "war_clan_max_members" and not 2 <= v <= 100:
        return "بینِ ۲ و ۱۰۰"
    if key == "war_f_random" and v > 0.5:
        return "نویز نباید بیشتر از ۰٫۵ باشه (قدرتِ واقعی مهمه)"
    if key == "war_f_damaged_mult" and not 0.05 <= v <= 1:
        return "بین ۰٫۰۵ و ۱"
    if key.endswith("_pct") and v > 1000:
        return "درصدِ بیش‌ازحد"
    return ""


# ---------------------------------------------------------------------------
# فرمول / کالیبراسیون / آدیت
# ---------------------------------------------------------------------------

async def cb_war_formula(update, context):
    session = db.get_session()
    try:
        cur = ci(session, "war_formula_version", 1)
        vs = session.query(W.WarFormulaVersion).order_by(W.WarFormulaVersion.version.desc()).limit(5).all()
        txt = [f"🧮 نسخه‌ی فعالِ فرمول: v{cur}", "نبردهای قدیمی با نسخه‌ی خودشون قابل‌تحلیل می‌مونن.", ""]
        txt += [f"v{v.version} – {v.created_at:%Y-%m-%d %H:%M} {v.note}" for v in vs]
        nb = session.query(W.WarBattle.formula_version, func.count(W.WarBattle.id)).group_by(W.WarBattle.formula_version).all()
        txt += ["", "نبردها به‌تفکیکِ نسخه: " + (", ".join(f"v{a}:{b}" for a, b in nb) or "—")]
    finally:
        session.close()
    await _send(update, "\n".join(txt), [[Btn("📌 انتشارِ نسخه‌ی جدید از پیش‌نویس", callback_data="admin_war_formula_go")], [Btn("🔙", callback_data="admin_war_menu")]])


async def cb_war_formula_go(update, context):
    session = db.get_session()
    try:
        v = S.publish_formula(session, update.effective_user.id, "انتشار از پنل ادمین")
    except WarError as e:
        session.rollback()
        await update.callback_query.answer(str(e), show_alert=True)
        return
    finally:
        session.close()
    await update.callback_query.answer(f"✅ نسخه‌ی v{v} منتشر شد")
    await cb_war_formula(update, context)


async def cb_war_recal(update, context):
    session = db.get_session()
    try:
        old = cf(session, "war_ref_calibration", 0)
        new = S.ref_hourly(session, 1)
        ratio = new / old if old else 1.0
        if abs(ratio - 1) < 1e-6:
            msg = "قیمت‌ها از قبل با اقتصادِ فعلی هم‌ترازن."
        else:
            for d in session.query(W.WarUnitDef).all():
                d.cost = round(d.cost * ratio, -1)
                d.maint_per_hour = round(d.maint_per_hour * ratio, 0)
            for r in session.query(W.WarRewardRule).all():
                r.hop_abs = round(r.hop_abs * ratio)
            db.cfg_set(session, "war_ref_calibration", str(new))
            S.audit(session, update.effective_user.id, "war_recalibrate", ratio=ratio)
            msg = f"✅ قیمت‌ها ×{ratio:.3f} شدن (هم‌تراز با اقتصادِ کارخونه)."
        session.commit()
    finally:
        session.close()
    await update.callback_query.answer(msg, show_alert=True)


async def cb_war_audit(update, context):
    session = db.get_session()
    try:
        rows = session.query(W.WarAudit).filter(W.WarAudit.action.like("admin_%") | W.WarAudit.action.like("war_%")).order_by(W.WarAudit.id.desc()).limit(15).all()
        txt = ["📜 آخرین تغییراتِ ادمین"] + [f"{r.created_at:%m-%d %H:%M} {r.actor_id} {r.action} {r.detail[:60]}" for r in rows]
    finally:
        session.close()
    await _send(update, "\n".join(txt), [[Btn("🔙", callback_data="admin_war_menu")]])


# ---------------------------------------------------------------------------
# ویرایشگرِ عمومیِ جدول‌ها
# ---------------------------------------------------------------------------

async def cb_war_tbl(update, context):
    _, key, page = update.callback_query.data.split(":")
    model, pk, title = TABLES[key]
    page = int(page)
    session = db.get_session()
    try:
        q = session.query(model).order_by(getattr(model, pk))
        total = q.count()
        rows_db = q.offset(page * PAGE).limit(PAGE).all()
        pages = max(1, math.ceil(total / PAGE))
        rows = [[Btn(("✅ " if getattr(r, "enabled", True) else "⛔️ ") + _label(r, pk)[:40], callback_data=f"admin_war_row:{key}:{getattr(r, pk)}")] for r in rows_db]
        rows.append([Btn("➕ جدید", callback_data=f"admin_war_new:{key}")])
        rows.append([Btn("◀️", callback_data=f"admin_war_tbl:{key}:{max(0, page - 1)}"), Btn(f"{page + 1}/{pages}", callback_data="admin_war_noop"),
                     Btn("▶️", callback_data=f"admin_war_tbl:{key}:{min(pages - 1, page + 1)}")])
        rows.append([Btn("🔙", callback_data="admin_war_menu")])
        await _send(update, f"{title} ({total})", rows)
    finally:
        session.close()


def _row_text(row, model, pk):
    lines = [f"📝 {_label(row, pk)}", ""]
    for c in _cols(model):
        lines.append(f"• {LB.col_label(c.name)}: {getattr(row, c.name)}")
    return "\n".join(lines)


async def cb_war_row(update, context):
    _, key, pkv = update.callback_query.data.split(":", 2)
    model, pk, title = TABLES[key]
    session = db.get_session()
    try:
        row = session.get(model, int(pkv) if pk == "id" else pkv)
        if not row:
            await update.callback_query.answer("پیدا نشد", show_alert=True)
            return
        text = _row_text(row, model, pk)
        rows = []
        for c in _cols(model):
            if c.name != pk and c.name != "enabled":
                rows.append([Btn(("✏️ " + LB.col_label(c.name))[:60], callback_data=f"admin_war_fk:{key}:{c.name}:{pkv}")])
        rows.append([Btn("✏️ ویرایشِ چندفیلدی (متنی)", callback_data=f"admin_war_fld:{key}:{pkv}")])
        if hasattr(row, "enabled"):
            rows.append([Btn("🔁 فعال/غیرفعال", callback_data=f"admin_war_tgl:{key}:{pkv}")])
        rows.append([Btn("📄 کپی با کلیدِ جدید", callback_data=f"admin_war_clone:{key}:{pkv}"), Btn("🗑 حذف", callback_data=f"admin_war_del:{key}:{pkv}")])
        rows.append([Btn("🔙", callback_data=f"admin_war_tbl:{key}:0")])
    finally:
        session.close()
    await _send(update, text[:3900], rows)


async def cb_war_fk(update, context):
    """ویرایشِ یه فیلدِ مشخص با دکمه (برچسبِ فارسی)."""
    _, key, col, pkv = update.callback_query.data.split(":", 3)
    model, pk, _t = TABLES[key]
    session = db.get_session()
    try:
        row = session.get(model, int(pkv) if pk == "id" else pkv)
        cur = getattr(row, col, "?") if row else "?"
    finally:
        session.close()
    await _ask(update, context, f"✏️ {LB.col_label(col)}\n(نامِ فنی: {col})\nمقدارِ فعلی: {cur}\n\nمقدارِ جدید رو بفرست:",
               {"type": "war_fld", "tbl": key, "pk": pkv, "only": col})


async def cb_war_fld(update, context):
    _, key, pkv = update.callback_query.data.split(":", 2)
    await _ask(update, context, "✏️ هر خط یه تغییر: «نامِ فیلد مقدار»\n(اسمِ فنی یا عینِ برچسبِ فارسی)\nمثال:\natk 120\ncost 350000\nenabled 0\n(چندخطی هم می‌تونی بفرستی)", {"type": "war_fld", "tbl": key, "pk": pkv})


async def cb_war_tgl(update, context):
    _, key, pkv = update.callback_query.data.split(":", 2)
    model, pk, _t = TABLES[key]
    session = db.get_session()
    try:
        row = session.get(model, int(pkv) if pk == "id" else pkv)
        row.enabled = not row.enabled
        S.audit(session, update.effective_user.id, "admin_war_toggle_row", table=key, pk=pkv, enabled=row.enabled)
        session.commit()
        _reload_alias(key)
    finally:
        session.close()
    await cb_war_row(update, context)


async def cb_war_del(update, context):
    parts = update.callback_query.data.split(":", 3)
    _, key, pkv = parts[:3]
    if len(parts) == 3:
        await _send(update, f"⚠️ حذفِ «{pkv}» قطعی؟ (بهتره غیرفعالش کنی؛ حذف ممکنه به بازیکنانی که اون رو دارن آسیب بزنه)",
                    [[Btn("✅ حذفِ قطعی", callback_data=f"admin_war_del:{key}:{pkv}:y")], [Btn("❌ انصراف", callback_data=f"admin_war_row:{key}:{pkv}")]])
        return
    model, pk, _t = TABLES[key]
    session = db.get_session()
    try:
        row = session.get(model, int(pkv) if pk == "id" else pkv)
        if row:
            session.delete(row)
            S.audit(session, update.effective_user.id, "admin_war_delete_row", table=key, pk=pkv)
            session.commit()
        _reload_alias(key)
    finally:
        session.close()
    await update.callback_query.answer("🗑 حذف شد")
    update.callback_query.data = f"admin_war_tbl:{key}:0"
    await cb_war_tbl(update, context)


async def cb_war_clone(update, context):
    _, key, pkv = update.callback_query.data.split(":", 2)
    await _ask(update, context, "📄 کلیدِ جدید رو بفرست (انگلیسی، بدونِ فاصله):", {"type": "war_clone", "tbl": key, "pk": pkv})


async def cb_war_new(update, context):
    key = update.callback_query.data.split(":")[1]
    model, pk, title = TABLES[key]
    if key == "event":
        hint = "نام | مدت(ساعت) | xp_mult | loot_mult | hop_mult | income_mult\nمثال: Weekend War | 48 | 2 | 1.5 | 1 | 1"
    elif key == "alias":
        hint = "panel | متنِ تریگر\nپنل‌ها: main war_room attack clan_attack clan history status units resources xp profile quests treasury diplomacy clan_war\nمثال: war_room | اتاق عملیات هاپویی"
    else:
        hint = "کلید | نام (بعد از ساخت، فیلدها رو با ✏️ تنظیم کن)\nمثال: adv_drone | پهپادِ پیشرفته"
    await _ask(update, context, f"➕ {title}\n{hint}", {"type": "war_new", "tbl": key})


async def cb_war_noop(update, context):
    await update.callback_query.answer()


def _reload_alias(key):
    if key == "alias":
        try:
            import war_ui
            war_ui.alias_map(force=True)
        except Exception:
            pass


# ---------------------------------------------------------------------------
# داشبورد
# ---------------------------------------------------------------------------

def dashboard_stats(session, hours=24):
    now = utcnow()
    since = now - datetime.timedelta(hours=hours)
    q = session.query
    s = {}
    s["players"] = q(W.WarPlayer).count()
    s["active"] = q(W.WarPlayer).filter(W.WarPlayer.last_seen_at >= since).count()
    lv = {}
    xps = []
    for p in q(W.WarPlayer).limit(5000).all():
        l = S.player_level(session, p)
        b = f"{(l - 1) // 5 * 5 + 1}-{(l - 1) // 5 * 5 + 5}"
        lv[b] = lv.get(b, 0) + 1
        xps.append(p.xp)
    s["levels"] = dict(sorted(lv.items(), key=lambda kv: int(kv[0].split("-")[0])))
    s["xp_avg"] = sum(xps) / len(xps) if xps else 0
    s["xp_max"] = max(xps) if xps else 0
    tx = q(W.HopTransaction).filter(W.HopTransaction.created_at >= since, W.HopTransaction.reason.like("war:%"))
    s["hop_gen"] = tx.filter(W.HopTransaction.amount > 0).with_entities(func.coalesce(func.sum(W.HopTransaction.amount), 0)).scalar() or 0
    s["hop_spent"] = -(tx.filter(W.HopTransaction.amount < 0).with_entities(func.coalesce(func.sum(W.HopTransaction.amount), 0)).scalar() or 0)
    s["circulation"] = q(func.coalesce(func.sum(db.User.hop_points), 0)).scalar() or 0
    bt = q(W.WarBattle).filter(W.WarBattle.status == "resolved", W.WarBattle.resolved_at >= since)
    s["battles"] = bt.count()
    s["att_wins"] = bt.filter(W.WarBattle.outcome == "attacker").count()
    s["def_wins"] = bt.filter(W.WarBattle.outcome == "defender").count()
    s["draws"] = bt.filter(W.WarBattle.outcome == "draw").count()
    s["avg_loot"] = bt.with_entities(func.coalesce(func.avg(W.WarBattle.loot_hop), 0)).scalar() or 0
    dmg = 0
    n = 0
    for b in bt.limit(500).all():
        r = json.loads(b.result_json or "{}")
        dmg += sum(v["x"] for v in r.get("atk_units", {}).values()) + sum(v["x"] for v in r.get("def_units", {}).values())
        n += 1
    s["avg_destroyed"] = dmg / n if n else 0
    s["eq_created"] = q(func.coalesce(func.sum(W.WarJob.qty), 0)).filter(W.WarJob.kind == "train", W.WarJob.status == "done", W.WarJob.finish_at >= since).scalar() or 0
    s["eq_repaired"] = q(func.coalesce(func.sum(W.WarJob.qty), 0)).filter(W.WarJob.kind == "repair", W.WarJob.status == "done", W.WarJob.finish_at >= since).scalar() or 0
    s["eq_destroyed_total"] = q(func.coalesce(func.sum(W.WarUnit.destroyed_total), 0)).scalar() or 0
    s["clans"] = q(W.WarClan).filter_by(disbanded=False).count()
    s["clan_wars"] = q(W.WarClanWar).filter(W.WarClanWar.created_at >= since).count()
    s["treasury"] = q(func.coalesce(func.sum(W.WarClan.treasury), 0)).scalar() or 0
    ctx = q(W.WarClanTx).filter(W.WarClanTx.created_at >= since)
    s["deposits"] = ctx.filter(W.WarClanTx.type == "deposit").with_entities(func.coalesce(func.sum(W.WarClanTx.amount), 0)).scalar() or 0
    s["withdrawals"] = -(ctx.filter(W.WarClanTx.amount < 0).with_entities(func.coalesce(func.sum(W.WarClanTx.amount), 0)).scalar() or 0)
    s["coups"] = q(W.WarCoup).filter(W.WarCoup.created_at >= since).count()
    s["quests_done"] = q(W.WarQuestProgress).filter(W.WarQuestProgress.claimed == True).count()  # noqa: E712
    return s


async def cb_war_dash(update, context):
    hours = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        s = dashboard_stats(session, hours)
    finally:
        session.close()
    lv = " | ".join(f"{k}:{v}" for k, v in s["levels"].items()) or "—"
    txt = (f"📊 داشبورد ({hours}h)\n👥 بازیکن: {s['players']} (فعال {s['active']})\n📶 سطح‌ها: {lv}\n⭐ XP میانگین {fmt(s['xp_avg'])} | بیشینه {fmt(s['xp_max'])}\n"
           f"💠 هاپِ تولیدشده: {short(s['hop_gen'])} | خرج‌شده: {short(s['hop_spent'])} | در گردش: {short(s['circulation'])}\n"
           f"⚔️ نبرد: {s['battles']} (مهاجم {s['att_wins']} / مدافع {s['def_wins']} / مساوی {s['draws']})\n💰 میانگین غنیمت: {short(s['avg_loot'])} | 💥 میانگین تلفات/نبرد: {s['avg_destroyed']:.1f}\n"
           f"🚀 ساخته {s['eq_created']} | تعمیر {s['eq_repaired']} | نابودی (کل) {s['eq_destroyed_total']}\n🏰 قبیله {s['clans']} | جنگ {s['clan_wars']} | خزانه {short(s['treasury'])}\n"
           f"🏦 واریز {short(s['deposits'])} | برداشت/تسویه {short(s['withdrawals'])} | 🚨 کودتا {s['coups']} | 🎯 مأموریتِ انجام‌شده {s['quests_done']}")
    await _send(update, txt, [[Btn("24h", callback_data="admin_war_dash:24"), Btn("7d", callback_data="admin_war_dash:168"), Btn("30d", callback_data="admin_war_dash:720")],
                              [Btn("🔙", callback_data="admin_war_menu")]])


# ---------------------------------------------------------------------------
# شبیه‌سازی (Read-Only: هیچ چیزی در دیتابیس تغییر نمی‌کنه)
# ---------------------------------------------------------------------------

def simulate(session, atk_id, def_id, btype="standard", n=200, version=None):
    params, ver = S.formula_params(session, version)
    bt = session.get(W.WarBattleType, btype)
    if not bt:
        raise WarError("نوعِ نبرد نامعتبر")
    ap, dp = session.get(W.WarPlayer, atk_id), session.get(W.WarPlayer, def_id)
    if not ap or not dp:
        raise WarError("بازیکن پیدا نشد")
    comp = B.default_composition(session, atk_id, "all")
    army = B.materialize(session, atk_id, comp, True)
    atk_units = B.engine_units(session, atk_id, army)
    def_units = B.engine_units(session, def_id)
    structs, wall = B.defense_structures(session, def_id)
    out = {"outcome": {"attacker": 0, "defender": 0, "draw": 0}, "stars": 0.0, "destr": 0.0, "atk_lost": 0.0, "def_lost": 0.0, "loot": 0.0, "xp": 0.0, "hop": 0.0, "ready": 0.0, "comp": 0.0}
    vh, _ = B.peek_vault(session, dp)
    my_ref = S.player_ref(session, ap)
    for i in range(n):
        r = E.resolve(1000 + i, atk_units, structs, def_units, params, ap.readiness, dp.readiness, atk_mult=bt.atk_mult, casualty_mult=bt.casualty_mult,
                      atk_research=1 + S.clan_bonus_pct(session, ap.clan_id, "atk_pct") / 100, def_research=1 + S.clan_bonus_pct(session, dp.clan_id, "def_pct") / 100, wall_mult=wall)
        out["outcome"][r["outcome"]] += 1
        out["stars"] += r["stars"]
        out["destr"] += r["destruction"]
        out["atk_lost"] += sum(v["x"] for v in r["atk_units"].values())
        out["def_lost"] += sum(v["x"] for v in r["def_units"].values())
        out["ready"] += bt.readiness_loss * max(0.6, min(1.6, r["pressure"]))
        if r["outcome"] == "attacker":
            frac = cf(session, "war_loot_max_frac_pct", 35) / 100 * (r["destruction"] / 100) ** cf(session, "war_loot_exp", 1.5)
            loot = min(vh * (1 - cf(session, "war_vault_protect_pct", 10) / 100) * frac * bt.loot_mult, cf(session, "war_loot_cap_hours", 6) * my_ref)
            out["loot"] += loot
            rule = session.get(W.WarRewardRule, "battle_win")
        elif r["outcome"] == "draw":
            rule = session.get(W.WarRewardRule, "battle_draw")
        else:
            rule = session.get(W.WarRewardRule, "battle_loss")
        if rule:
            out["xp"] += rule.xp * bt.xp_mult
            out["hop"] += rule.hop_abs + rule.hop_ref_hours * my_ref
    res = {k: (v / n if not isinstance(v, dict) else v) for k, v in out.items()}
    res["n"], res["version"] = n, ver
    return res


def sim_text(r, a, d, btype):
    o = r["outcome"]
    n = r["n"]
    return (f"🧪 شبیه‌سازی (Read-Only) – فرمول v{r['version']}\n{a} ➜ {d} | {btype} | {n} اجرا\n\n🏆 توزیعِ برنده: مهاجم {o['attacker'] / n * 100:.0f}% | مدافع {o['defender'] / n * 100:.0f}% | مساوی {o['draw'] / n * 100:.0f}%\n"
            f"⭐ میانگین ستاره {r['stars']:.2f} | 💥 تخریب {r['destr']:.0f}%\n💔 تلفاتِ مهاجم {r['atk_lost']:.1f} | تلفاتِ مدافع {r['def_lost']:.1f}\n💰 غنیمتِ میانگین {short(r['loot'])}\n"
            f"⭐ XP {r['xp']:.0f} | 💠 هاپِ پاداش {short(r['hop'])}\n🔥 افتِ ریدینس {r['ready']:.0f}%")


async def cb_war_sim(update, context):
    await _ask(update, context, "🧪 آیدیِ مهاجم، آیدیِ مدافع و (اختیاری) نوعِ نبرد و تعداد:\nمثال: 12345 67890 standard 300", {"type": "war_sim"})


async def cb_war_adj(update, context):
    await _ask(update, context, "💠 تعدیلِ هاپ (با لجرِ ADMIN_ADJUSTMENT):\nآیدی مبلغ(+/-) دلیل\nمثال: 12345 -500000 جبرانِ باگ", {"type": "war_adj"})


async def cb_war_cancelb(update, context):
    await _ask(update, context, "🛑 شماره‌ی نبردِ در جریان برای لغو (نیروها و ۱۰۰٪ هزینه برمی‌گرده):", {"type": "war_cancelb"})


# ---------------------------------------------------------------------------
# جوابِ متنیِ پرامپت‌ها (از admin.admin_awaiting_handler صدا زده می‌شه)
# ---------------------------------------------------------------------------

async def war_admin_awaiting_handler(update, context, state):
    text = (update.message.text or "").strip()
    stype = state["type"]
    uid = update.effective_user.id
    session = db.get_session()
    reply = None
    reload_key = None
    try:
        if stype == "war_frx":
            import frontier_admin
            reply = await frontier_admin.handle_input(session, update, state, text, uid)
        elif stype == "war_cfg":
            key = state["key"]
            err = validate_cfg(key, text)
            if err:
                raise WarError(f"مقدارِ نامعتبر: {err}")
            db.cfg_set(session, key, text)
            S.audit(session, uid, "admin_war_cfg", key=key, value=text)
            reply = f"✅ {LB.cfg_label(key)} ← {text}" + ("\n(پیش‌نویسِ فرمول؛ برای اعمال «انتشارِ نسخه‌ی جدید» رو بزن)" if key in W.FORMULA_KEYS else "")
        elif stype == "war_fld":
            model, pk, _t = TABLES[state["tbl"]]
            row = session.get(model, int(state["pk"]) if pk == "id" else state["pk"])
            if not row:
                raise WarError("ردیف پیدا نشد")
            cols = {c.name: c for c in _cols(model)}
            changed = []
            lines_in = [f"{state['only']} {text}"] if state.get("only") else text.splitlines()
            for line in lines_in:
                if not line.strip():
                    continue
                name, _, val = line.strip().partition(" ")
                name = LB.find_col(cols, name) or name
                if name not in cols or name == pk:
                    raise WarError(f"فیلدِ «{name}» معتبر/قابل‌ویرایش نیست")
                v = _coerce(cols[name], val)
                if isinstance(v, (int, float)) and not isinstance(v, bool) and (v != v or v < 0) and name not in ("score",):
                    raise WarError(f"مقدارِ منفی/نامعتبر برای {name}")
                setattr(row, name, v)
                changed.append(f"{name}={v}")
            if not changed:
                raise WarError("چیزی برای تغییر نبود")
            S.audit(session, uid, "admin_war_edit", table=state["tbl"], pk=state["pk"], changes=changed)
            reply = "✅ " + " | ".join(changed)
            reload_key = state["tbl"]
        elif stype == "war_new":
            key = state["tbl"]
            model, pk, _t = TABLES[key]
            parts = [x.strip() for x in text.split("|")]
            if key == "event":
                if len(parts) < 2:
                    raise WarError("فرمت: نام | مدت(ساعت) | xp | loot | hop | income")
                vals = [float(x) for x in parts[2:6]] + [1.0] * (4 - len(parts[2:6]))
                now = utcnow()
                row = W.WarEvent(name=parts[0], start_at=now, end_at=now + datetime.timedelta(hours=float(parts[1])), xp_mult=vals[0], loot_mult=vals[1], hop_mult=vals[2], income_mult=vals[3])
            elif key == "alias":
                if len(parts) != 2:
                    raise WarError("فرمت: panel | متن")
                nt = normalize(parts[1])
                if len(nt) < 3:
                    raise WarError("متنِ تریگر خیلی کوتاهه")
                if session.query(W.WarAlias).filter_by(text=nt).first():
                    raise WarError("این تریگر قبلاً هست")
                row = W.WarAlias(panel=parts[0], text=nt, builtin=False)
            else:
                if len(parts) < 2 or not parts[0] or " " in parts[0]:
                    raise WarError("فرمت: کلید | نام (کلید بدونِ فاصله)")
                if session.get(model, parts[0]):
                    raise WarError("این کلید وجود داره")
                kw = {pk: parts[0]}
                if hasattr(model, "name"):
                    kw["name"] = parts[1]
                elif hasattr(model, "label"):
                    kw["label"] = parts[1]
                row = model(**kw)
            session.add(row)
            S.audit(session, uid, "admin_war_create", table=key, row=text)
            reply = "✅ ساخته شد؛ از منوی همون جدول فیلدهاش رو تنظیم کن. بلافاصله در بازی قابل‌استفاده‌ست."
            reload_key = key
        elif stype == "war_clone":
            model, pk, _t = TABLES[state["tbl"]]
            new_key = text.strip()
            if not new_key or " " in new_key or session.get(model, new_key):
                raise WarError("کلیدِ نامعتبر یا تکراری")
            src = session.get(model, int(state["pk"]) if pk == "id" else state["pk"])
            data = {c.name: getattr(src, c.name) for c in _cols(model)}
            data[pk] = new_key
            session.add(model(**data))
            S.audit(session, uid, "admin_war_clone", table=state["tbl"], src=state["pk"], new=new_key)
            reply = "✅ کپی ساخته شد."
            reload_key = state["tbl"]
        elif stype == "war_sim":
            parts = text.split()
            a, d = int(parts[0]), int(parts[1])
            bt = parts[2] if len(parts) > 2 else "standard"
            n = min(2000, int(parts[3])) if len(parts) > 3 else 200
            S.get_player(session, a, create=False)
            r = simulate(session, a, d, bt, n)
            reply = sim_text(r, a, d, bt)
            session.rollback()         # Read-Only: هیچ چیز ذخیره نمی‌شه
        elif stype == "war_adj":
            parts = text.split(None, 2)
            target, amount = int(parts[0]), float(parts[1])
            reason = parts[2] if len(parts) > 2 else "admin"
            user = session.get(db.User, target)
            if not user:
                raise WarError("کاربر پیدا نشد")
            S.hop_apply(session, user, amount, "ADMIN_ADJUSTMENT", f"admin:{reason}", ref=f"admin:{uid}")
            S.audit(session, uid, "admin_war_adjust", target=target, amount=amount, reason=reason)
            reply = f"✅ تعدیل انجام شد: {amount:+,.0f} (موجودیِ جدید {user.hop_points:,.0f})"
        elif stype == "war_cancelb":
            ok = B.cancel_battle(session, int(text), "admin_cancel", 100)
            S.audit(session, uid, "admin_war_cancel_battle", battle=text, ok=ok)
            reply = "✅ لغو شد" if ok else "نبردِ در جریانی با این شماره نیست"
        session.commit()
        if reload_key:
            _reload_alias(reload_key)        # بعد از commit؛ وگرنه کش تغییر رو نمی‌بینه
    except WarError as e:
        session.rollback()
        reply = f"❌ {e}"
    except (ValueError, IndexError) as e:
        session.rollback()
        reply = f"❌ ورودیِ نامعتبر ({e})"
    finally:
        session.close()
    if reply:
        await update.message.reply_text(reply[:3900], reply_markup=Kb([[Btn("🔙 منوی جنگ", callback_data="admin_war_menu")]]))
    raise ApplicationHandlerStop


ADMIN_WAR_CALLBACKS = {
    "admin_war_menu": cb_war_menu, "admin_war_toggle": cb_war_toggle, "admin_war_cfg": cb_war_cfg, "admin_war_cfgk": cb_war_cfgk,
    "admin_war_formula": cb_war_formula, "admin_war_formula_go": cb_war_formula_go, "admin_war_recal": cb_war_recal,
    "admin_war_audit": cb_war_audit, "admin_war_tbl": cb_war_tbl, "admin_war_row": cb_war_row, "admin_war_fld": cb_war_fld, "admin_war_fk": cb_war_fk,
    "admin_war_tgl": cb_war_tgl, "admin_war_del": cb_war_del, "admin_war_clone": cb_war_clone, "admin_war_new": cb_war_new,
    "admin_war_noop": cb_war_noop, "admin_war_dash": cb_war_dash, "admin_war_sim": cb_war_sim, "admin_war_adj": cb_war_adj,
    "admin_war_cancelb": cb_war_cancelb,
}


import frontier_admin  # noqa: E402,F401  (ثبتِ callbackهای Frontier در ADMIN_WAR_CALLBACKS)
