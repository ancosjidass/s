# -*- coding: utf-8 -*-
"""
ایموجی‌هایِ پریمیومِ تلگرام (custom emoji) برایِ کلِ ربات — بدونِ دست‌زدن به کدِ بازی‌ها.

چطور کار می‌کنه
  • تو کدِ ربات همه‌جا ایموجیِ معمولی (🎲 ✅ ...) نوشته شده. این ماژول درست قبلِ ارسالِ هر پیام به
    تلگرام (Bot._post) متنِ خروجی رو می‌خونه و هر ایموجیِ معمولی که براش «ایموجیِ پریمیوم» یاد گرفته
    باشه رو با entityِ custom_emoji عوض می‌کنه. تو دکمه‌ها هم ایموجیِ اولِ متن به آیکونِ دکمه
    (icon_custom_emoji_id) تبدیل می‌شه.
  • نگاشتِ «ایموجیِ معمولی ➜ ایموجیِ پریمیوم» تو دیتابیس ذخیره می‌شه (جدولِ custom_emoji_map).
    خودت با ربات یادش می‌دی: /emoji_learn بزن و پیامی بفرست که ایموجی‌هایِ پریمیومت توشه.
    لازم نیست idها رو دستی پیدا کنی.

شرطِ تلگرام (Bot API 9.4): ایموجیِ پریمیوم فقط تو پیام‌هایی که خودِ ربات تو پیوی/گروه/سوپرگروه می‌فرسته
کار می‌کنه و فقط وقتی که «صاحبِ ربات» (اکانتی که ربات رو تو BotFather ساخته) تلگرام پریمیوم داشته باشه.
جاهایی که تلگرام اجازه نمی‌ده: پاپ‌آپ/هشدارِ دکمه‌ها (answerCallbackQuery)، کانال، نتایجِ inline،
اسمِ بات/توضیحاتش، و ایموجی‌هایِ غیرِ اول تو متنِ دکمه (هر دکمه فقط یه آیکون داره).

ایمنی: اگه تلگرام پیامِ تبدیل‌شده رو نپذیره (مثلاً صاحبِ بات پریمیوم نیست)، همون پیام بدونِ تبدیل ارسال
می‌شه؛ یعنی بات هیچ‌وقت به‌خاطرِ این قابلیت پیامی رو از دست نمی‌ده.
"""
import ast
import datetime
import glob
import logging
import os
import re
import time

from sqlalchemy import Column, DateTime, String

import config
import db

logger = logging.getLogger(__name__)

ENABLED_KEY = "premium_emoji_enabled"
MAX_ENTITIES = 100          # سقفِ تلگرام برایِ تعدادِ entity تو یه پیام


class CustomEmoji(db.Base):
    __tablename__ = "custom_emoji_map"
    char = Column(String, primary_key=True)        # ایموجیِ معمولی (بدونِ FE0F)
    emoji_id = Column(String, nullable=False)      # custom_emoji_id
    added_at = Column(DateTime, default=datetime.datetime.utcnow)


# ---------------------------------------------------------------------------
# تشخیصِ ایموجی تو متن
# ---------------------------------------------------------------------------
_PICT = ("[\U0001F000-\U0001FAFF\u2600-\u27BF\u2B00-\u2BFF\u2300-\u23FF\u2190-\u21FF\u25A0-\u25FF"
         "\u2900-\u297F\u3030\u303D\u3297\u3299\u00A9\u00AE\u203C\u2049\u2122\u2139\u24C2]")
_MOD = "[\U0001F3FB-\U0001F3FF]"
EMOJI_RE = re.compile(
    r"[0-9#*]\ufe0f?\u20e3"                                   # keycap
    r"|[\U0001F1E6-\U0001F1FF]{2}"                            # پرچم
    + "|" + _PICT + r"(?:\ufe0f|" + _MOD + r")?(?:\u200d" + _PICT + r"\ufe0f?)*"
)


def norm(s: str) -> str:
    return s.replace("\ufe0f", "").replace("\ufe0e", "")


def _u16(s: str) -> int:
    return len(s.encode("utf-16-le")) // 2


# ---------------------------------------------------------------------------
# نگاشت + تنظیمات (کش)
# ---------------------------------------------------------------------------
_MAP = {}
_MAP_LOADED = False
_ENABLED = (True, 0.0)           # (مقدار, زمانِ آخرین خوندن)
_SEEN = {}                       # ایموجی‌هایِ بدونِ نگاشت که تو خروجی دیده شدن
_FAILS = {"n": 0, "off_until": 0.0}


def load_map(force=False):
    global _MAP_LOADED
    if _MAP_LOADED and not force:
        return
    s = db.get_session()
    try:
        _MAP.clear()
        for r in s.query(CustomEmoji).all():
            _MAP[r.char] = r.emoji_id
        _MAP_LOADED = True
    finally:
        s.close()


def is_enabled() -> bool:
    global _ENABLED
    now = time.time()
    if now < _FAILS["off_until"]:
        return False
    val, ts = _ENABLED
    if now - ts > 20:
        s = db.get_session()
        try:
            v = (db.cfg_get(s, ENABLED_KEY) or "1").strip()
        except Exception:
            v = "1"
        finally:
            s.close()
        val = v not in ("0", "false", "off", "")
        _ENABLED = (val, now)
    return val


def set_enabled(on: bool):
    global _ENABLED
    s = db.get_session()
    try:
        db.cfg_set(s, ENABLED_KEY, "1" if on else "0")
    finally:
        s.close()
    _ENABLED = (on, time.time())


def learn(pairs: dict) -> int:
    """pairs: {ایموجیِ معمولی: custom_emoji_id}"""
    load_map()
    s = db.get_session()
    n = 0
    try:
        for ch, eid in pairs.items():
            k = norm(ch)
            if not k or not eid:
                continue
            row = s.get(CustomEmoji, k)
            if row is None:
                s.add(CustomEmoji(char=k, emoji_id=str(eid)))
            else:
                row.emoji_id = str(eid)
            _MAP[k] = str(eid)
            n += 1
        s.commit()
    finally:
        s.close()
    return n


def forget(ch: str) -> bool:
    load_map()
    k = norm(ch)
    s = db.get_session()
    try:
        row = s.get(CustomEmoji, k)
        if row is None:
            return False
        s.delete(row)
        s.commit()
        _MAP.pop(k, None)
        return True
    finally:
        s.close()


BACKUP_KEY = "premium_emoji_backup"


def reset_all() -> int:
    """همه‌ی نگاشت‌هایِ پریمیوم رو پاک می‌کنه ➜ همه‌ی ایموجی‌ها (متن + دکمه) به حالتِ معمولی برمی‌گردن.
    قبلش یه نسخه‌یِ پشتیبان تو کانفیگ می‌ذاره تا با /emoji_restore برگرده. تعدادِ پاک‌شده رو برمی‌گردونه."""
    import json
    load_map()
    s = db.get_session()
    try:
        rows = s.query(CustomEmoji).all()
        backup = {r.char: r.emoji_id for r in rows}
        if backup:
            db.cfg_set(s, BACKUP_KEY, json.dumps(backup, ensure_ascii=False))
        for r in rows:
            s.delete(r)
        s.commit()
    finally:
        s.close()
    _MAP.clear()
    _SEEN.clear()
    _FAILS["n"] = 0
    _FAILS["off_until"] = 0.0
    return len(backup)


def restore_backup() -> int:
    import json
    s = db.get_session()
    try:
        raw = db.cfg_get(s, BACKUP_KEY)
    finally:
        s.close()
    if not raw:
        return 0
    try:
        return learn(json.loads(raw))
    except Exception:
        return 0


# ---------------------------------------------------------------------------
# تبدیلِ متن و دکمه‌ها
# ---------------------------------------------------------------------------
def _entity_dict(e):
    return e.to_dict() if hasattr(e, "to_dict") else dict(e)


def convert_text(text: str, entities):
    """متنِ ساده + entityهایِ فعلی ➜ لیستِ entityِ ادغام‌شده (با custom_emoji). اگه چیزی عوض نشه None."""
    if not text or not _MAP:
        return None
    from telegram import MessageEntity
    existing = list(entities or [])
    occupied = [(_ent_off(e), _ent_off(e) + _ent_len(e)) for e in existing]
    new = []
    for m in EMOJI_RE.finditer(text):
        k = norm(m.group(0))
        eid = _MAP.get(k)
        if eid is None:
            if k and k not in ("→", "←"):
                _SEEN[k] = _SEEN.get(k, 0) + 1
            continue
        off = _u16(text[:m.start()])
        ln = _u16(m.group(0))
        if any(a < off + ln and off < b for a, b in occupied):
            continue            # وسطِ منشن/کد/لینک دست نمی‌زنیم
        new.append(MessageEntity(type="custom_emoji", offset=off, length=ln, custom_emoji_id=eid))
    if not new:
        return None
    merged = existing + new
    merged.sort(key=lambda e: (_ent_off(e), -_ent_len(e)))
    if len(merged) > MAX_ENTITIES:           # سقفِ تلگرام؛ ایموجی‌هایِ آخرِ متن معمولی می‌مونن
        keep_old = len(existing)
        merged = sorted(existing + new[:max(0, MAX_ENTITIES - keep_old)],
                        key=lambda e: (_ent_off(e), -_ent_len(e)))
    return merged


def _ent_off(e):
    return e.offset if hasattr(e, "offset") else e["offset"]


def _ent_len(e):
    return e.length if hasattr(e, "length") else e["length"]


def convert_markup(markup):
    """ایموجیِ اولِ متنِ هر دکمه ➜ icon_custom_emoji_id. خروجی: dict یا None (اگه تغییری نبود)."""
    if markup is None or not _MAP or not hasattr(markup, "to_dict"):
        return None
    d = markup.to_dict()
    rows = d.get("inline_keyboard") or d.get("keyboard")
    if not rows:
        return None
    changed = False
    for row in rows:
        for b in row:
            if not isinstance(b, dict) or "text" not in b or b.get("icon_custom_emoji_id"):
                continue
            t = b["text"]
            stripped = t.lstrip()
            m = EMOJI_RE.match(stripped)
            if not m:
                continue
            eid = _MAP.get(norm(m.group(0)))
            rest = stripped[m.end():].lstrip()
            if eid and rest:                      # دکمه‌ی فقط-ایموجی رو دست نمی‌زنیم (متنِ خالی مجاز نیست)
                b["text"] = rest
                b["icon_custom_emoji_id"] = eid
                changed = True
            elif not eid:
                k = norm(m.group(0))
                _SEEN[k] = _SEEN.get(k, 0) + 1
    return d if changed else None


_TEXT_FIELDS = {
    "sendMessage": ("text", "entities"),
    "editMessageText": ("text", "entities"),
    "sendPhoto": ("caption", "caption_entities"),
    "sendVideo": ("caption", "caption_entities"),
    "sendAnimation": ("caption", "caption_entities"),
    "sendDocument": ("caption", "caption_entities"),
    "sendAudio": ("caption", "caption_entities"),
    "sendVoice": ("caption", "caption_entities"),
    "editMessageCaption": ("caption", "caption_entities"),
}
_MARKUP_ENDPOINTS = set(_TEXT_FIELDS) | {"editMessageReplyMarkup"}


def transform(endpoint: str, data: dict):
    """نسخه‌ی تبدیل‌شده‌ی data یا None اگه چیزی برایِ تبدیل نبود."""
    if endpoint not in _MARKUP_ENDPOINTS:
        return None
    new = dict(data)
    changed = False
    fields = _TEXT_FIELDS.get(endpoint)
    # ExtBot قبل از _insert_defaults مقدارِ «پیش‌فرض» رو به‌شکلِ DefaultValue می‌ده، نه None
    pm = data.get("parse_mode")
    pm = getattr(pm, "value", pm)
    if fields and pm is None:
        tkey, ekey = fields
        t = data.get(tkey)
        if isinstance(t, str):
            ents = convert_text(t, data.get(ekey))
            if ents is not None:
                new[ekey] = ents
                changed = True
    mk = convert_markup(data.get("reply_markup"))
    if mk is not None:
        new["reply_markup"] = mk
        changed = True
    return new if changed else None


# ---------------------------------------------------------------------------
# نصبِ هوک روی Bot._post
# ---------------------------------------------------------------------------
def install():
    from telegram import Bot
    from telegram.error import BadRequest
    global _RAW_POST
    orig = Bot.__dict__.get("_post")
    if orig is None or getattr(orig, "_hop_premium", False):
        return False
    _RAW_POST = orig

    async def _post(self, endpoint, data=None, *args, **kwargs):
        new = None
        try:
            if data is not None and is_enabled():
                load_map()
                new = transform(endpoint, data)
        except Exception:
            logger.exception("premium_emoji transform failed")
            new = None
        if new is None:
            return await orig(self, endpoint, data, *args, **kwargs)
        try:
            res = await orig(self, endpoint, new, *args, **kwargs)
            _FAILS["n"] = 0
            return res
        except BadRequest as e:
            msg = str(e).lower()
            if "not modified" in msg:
                raise
            # پیامِ تبدیل‌شده پذیرفته نشد (مثلاً صاحبِ ربات پریمیوم نیست) ➜ همون پیام بدونِ تبدیل
            res = await orig(self, endpoint, data, *args, **kwargs)
            _FAILS["n"] += 1
            logger.warning("premium emoji rejected by Telegram (%s) — sent plain [%d]", e, _FAILS["n"])
            if _FAILS["n"] >= 5:
                _FAILS["off_until"] = time.time() + 600
                logger.error("premium emoji paused for 10 minutes after repeated rejections")
            return res

    _post._hop_premium = True
    Bot._post = _post
    logger.info("premium_emoji hook installed")
    return True


# ---------------------------------------------------------------------------
# فرمان‌هایِ مالک
# ---------------------------------------------------------------------------
_HERE = os.path.dirname(os.path.abspath(__file__))
_learn_until = {}      # uid -> زمانِ پایانِ حالتِ یادگیری


def scan_source_emojis():
    """ایموجی‌هایِ معمولیِ داخلِ رشته‌هایِ کدِ بات (فقط string literal، نه کامنت)، به ترتیبِ فراوانی."""
    cnt = {}
    for f in glob.glob(os.path.join(_HERE, "*.py")):
        base = os.path.basename(f)
        if base.startswith(("test_", "war_sim")) or base == "premium_emoji.py":
            continue
        try:
            tree = ast.parse(open(f, encoding="utf-8").read())
        except Exception:
            continue
        for node in ast.walk(tree):
            if isinstance(node, ast.Constant) and isinstance(node.value, str):
                for m in EMOJI_RE.finditer(node.value):
                    k = norm(m.group(0))
                    if k in ("→", "←", "↔", "↩", "↪") or not k:
                        continue
                    cnt[k] = cnt.get(k, 0) + 1
    return cnt


def missing_report():
    load_map()
    src = scan_source_emojis()
    for k, n in _SEEN.items():
        src[k] = max(src.get(k, 0), n)
    miss = sorted(((k, n) for k, n in src.items() if k not in _MAP), key=lambda x: -x[1])
    return miss, len(src)


def _is_owner(update):
    u = update.effective_user
    return bool(u and u.id == config.OWNER_ID and update.effective_chat and update.effective_chat.type == "private")


async def cmd_emoji(update, context):
    if not _is_owner(update):
        return
    load_map()
    miss, total = missing_report()
    await update.effective_message.reply_text(
        "ایموجی‌هایِ پریمیوم\n"
        f"وضعیت: {'روشن' if is_enabled() else 'خاموش'}\n"
        f"یاد گرفته‌شده: {len(_MAP)} از {total} ایموجیِ بات\n"
        f"هنوز معمولی: {len(miss)}\n\n"
        "/emoji_learn  ➜ یاد دادنِ ایموجی‌هایِ پریمیومت\n"
        "/emoji_missing  ➜ ایموجی‌هایی که هنوز معمولی‌ان (به ترتیبِ تعدادِ استفاده)\n"
        "/emoji_list  ➜ لیستِ یاد گرفته‌شده‌ها\n"
        "/emoji_test  ➜ تستِ ارسال (خطایِ تلگرام رو نشون می‌ده)\n"
        "/emoji_del 🔥  ➜ پاک‌کردنِ یه نگاشت\n"
        "/emoji_reset  ➜ ریستِ کامل: همه‌ی ایموجی‌ها برگردن به حالتِ عادی\n"
        "/emoji_restore  ➜ برگردوندنِ نگاشت‌هایِ قبل از ریست\n"
        "/emoji_on  /emoji_off  ➜ روشن/خاموش کردنِ کلِ قابلیت")


async def cmd_learn(update, context):
    if not _is_owner(update):
        return
    _learn_until[update.effective_user.id] = time.time() + 900
    await update.effective_message.reply_text(
        "حالتِ یادگیری ۱۵ دقیقه روشنه.\n"
        "حالا یه یا چند پیام بفرست که ایموجی‌هایِ پریمیومت (از پکِ خودت) توشه. هر ایموجیِ پریمیوم "
        "جایگزینِ همون ایموجیِ معمولی می‌شه که تو پیام بهش چسبیده (مثلاً اگه پریمیومِ «🔥» رو بفرستی، "
        "هر 🔥 تو بات اون ایموجی می‌شه).\n"
        "برایِ یه ایموجیِ معمولی هر بار آخرین چیزی که بفرستی ذخیره می‌شه. وقتی تموم شد: /emoji_done")


async def cmd_done(update, context):
    if not _is_owner(update):
        return
    _learn_until.pop(update.effective_user.id, None)
    load_map()
    miss, _ = missing_report()
    await update.effective_message.reply_text(f"تموم شد. {len(_MAP)} ایموجی یاد گرفته شد؛ {len(miss)} تا هنوز معمولی‌ان (/emoji_missing).")


async def on_learn_message(update, context):
    from telegram.ext import ApplicationHandlerStop
    if not _is_owner(update):
        return
    if time.time() > _learn_until.get(update.effective_user.id, 0):
        return
    msg = update.effective_message
    text = msg.text or msg.caption or ""
    ents = msg.entities if msg.text else msg.caption_entities
    pairs = {}
    for e in ents or []:
        if e.type == "custom_emoji" and e.custom_emoji_id:
            # ایموجیِ معمولیِ همراهِ ایموجیِ پریمیوم = متنی که entity پوشونده
            raw = text.encode("utf-16-le")
            seg = raw[e.offset * 2:(e.offset + e.length) * 2].decode("utf-16-le", "ignore")
            if seg:
                pairs[seg] = e.custom_emoji_id
    if not pairs:
        await msg.reply_text("تو این پیام ایموجیِ پریمیوم ندیدم. از پنلِ ایموجیِ خودت (پکِ پریمیوم) بفرست.")
        raise ApplicationHandlerStop
    n = learn(pairs)
    miss, _ = missing_report()
    shown = " ".join(pairs.keys())
    await msg.reply_text(f"{n} ایموجی یاد گرفته شد: {shown}\nهنوز معمولی: {len(miss)}")
    raise ApplicationHandlerStop


async def cmd_missing(update, context):
    if not _is_owner(update):
        return
    miss, total = missing_report()
    if not miss:
        await update.effective_message.reply_text("همه‌ی ایموجی‌هایِ بات پریمیوم شدن. 🎉")
        return
    lines = [f"{k} ×{n}" for k, n in miss]
    chunk = []
    await update.effective_message.reply_text(
        f"{len(miss)} ایموجی هنوز معمولی‌ان (از {total}). ×عدد = تعدادِ استفاده تو متن‌هایِ بات. "
        "اول پرتکرارها رو بده، چون بیشترِ متن‌ها رو می‌پوشونن.")
    for i, ln in enumerate(lines, 1):
        chunk.append(ln)
        if i % 40 == 0 or i == len(lines):
            await update.effective_message.reply_text("   ".join(chunk))
            chunk = []


async def cmd_list(update, context):
    if not _is_owner(update):
        return
    load_map()
    if not _MAP:
        await update.effective_message.reply_text("هنوز چیزی یاد داده نشده. /emoji_learn")
        return
    await update.effective_message.reply_text(" ".join(_MAP.keys()) + f"\n\n{len(_MAP)} ایموجی")


async def cmd_del(update, context):
    if not _is_owner(update):
        return
    arg = " ".join(context.args or [])
    ms = [norm(m.group(0)) for m in EMOJI_RE.finditer(arg)]
    if not ms:
        await update.effective_message.reply_text("مثلاً: /emoji_del 🔥")
        return
    ok = [m for m in ms if forget(m)]
    await update.effective_message.reply_text(f"پاک شد: {' '.join(ok) or 'هیچ‌کدوم تو لیست نبود'}")


async def cmd_reset(update, context):
    if not _is_owner(update):
        return
    _learn_until.pop(update.effective_user.id, None)
    n = reset_all()
    await update.effective_message.reply_text(
        f"✅ ریست شد. {n} نگاشتِ پریمیوم پاک شد و همه‌ی ایموجی‌هایِ بات (متن و دکمه‌ها) به حالتِ عادی برگشتن.\n"
        "اگه خواستی همون‌ها برگردن: /emoji_restore")


async def cmd_restore(update, context):
    if not _is_owner(update):
        return
    n = restore_backup()
    await update.effective_message.reply_text(
        f"{n} نگاشت برگشت." if n else "پشتیبانی برایِ برگردوندن پیدا نشد.")


async def cmd_on(update, context):
    if _is_owner(update):
        _FAILS["off_until"] = 0.0
        _FAILS["n"] = 0
        set_enabled(True)
        await update.effective_message.reply_text("روشن شد.")


async def cmd_off(update, context):
    if _is_owner(update):
        set_enabled(False)
        await update.effective_message.reply_text("خاموش شد؛ همه‌چیز با ایموجیِ معمولی ارسال می‌شه.")


async def cmd_test(update, context):
    """یه پیام با همه‌ی ایموجی‌هایِ یاد گرفته‌شده + یه دکمه‌ی آیکون‌دار؛ خطایِ تلگرام (اگه باشه) رو نشون می‌ده."""
    if not _is_owner(update):
        return
    load_map()
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    from telegram.error import BadRequest
    if not _MAP:
        await update.effective_message.reply_text("اول /emoji_learn")
        return
    sample = list(_MAP.keys())[:30]
    first = sample[0]
    text = "تست: " + " ".join(sample)
    kb = InlineKeyboardMarkup([[InlineKeyboardButton(f"{first} دکمه‌ی تست", callback_data="emoji:test")]])
    bot = context.bot
    try:
        # مستقیم و بدونِ fallback تا خطایِ واقعیِ تلگرام دیده بشه
        data = {"chat_id": update.effective_chat.id, "text": text, "reply_markup": kb}
        tdata = transform("sendMessage", data)
        if tdata is None:
            await update.effective_message.reply_text("چیزی برایِ تبدیل پیدا نشد.")
            return
        await (_RAW_POST or type(bot)._post)(bot, "sendMessage", tdata)
        await update.effective_message.reply_text("✅ تلگرام ایموجی‌هایِ پریمیوم و آیکونِ دکمه رو پذیرفت.")
    except BadRequest as e:
        await update.effective_message.reply_text(
            f"❌ تلگرام قبول نکرد: {e}\n\nمعمولاً یعنی اکانتی که ربات رو تو BotFather ساخته تلگرام پریمیوم نداره.")


_RAW_POST = None


def register(app):
    from telegram.ext import CommandHandler, MessageHandler, filters
    cmds = {"emoji": cmd_emoji, "emoji_learn": cmd_learn, "emoji_done": cmd_done, "emoji_missing": cmd_missing,
            "emoji_list": cmd_list, "emoji_del": cmd_del, "emoji_on": cmd_on, "emoji_off": cmd_off,
            "emoji_test": cmd_test, "emoji_reset": cmd_reset, "emoji_restore": cmd_restore}
    owner = filters.User(user_id=config.OWNER_ID) & filters.ChatType.PRIVATE
    for name, fn in cmds.items():
        app.add_handler(CommandHandler(name, fn, filters=owner), group=-5)
    app.add_handler(MessageHandler(owner & ~filters.COMMAND, on_learn_message), group=-5)

