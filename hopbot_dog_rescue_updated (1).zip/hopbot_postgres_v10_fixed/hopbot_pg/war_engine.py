# -*- coding: utf-8 -*-
"""
موتور نبردِ جنگ هاپویی - خالص (بدون دیتابیس/تلگرام) و کاملاً قطعی نسبت به seed.

ورودی همه‌چیز از پارامترهای «نسخه‌ی فرمول» (dict) میاد؛ هیچ عددِ بالانسی این‌جا هاردکد نیست
(فقط مقادیرِ پیش‌فرضِ ایمن برای وقتی کلیدی وجود نداشته باشه).
"""
import json
import math
import random
from dataclasses import dataclass, field

DEF_TYPES = ("ground", "air", "generic")
_CAT_TO_DEF_TYPE = {"ground": "ground", "armor": "ground", "air": "air"}  # بقیه: generic


@dataclass
class Unit:
    key: str
    cat: str
    atk: float
    defn: float
    durability: float = 1.0
    accuracy: float = 1.0
    support_pct: float = 0.0
    level_mult: float = 1.0
    healthy: int = 0
    damaged: int = 0


@dataclass
class Params:
    k: float = 2.2
    h: float = 1.15
    rnd: float = 0.15
    damaged_mult: float = 0.6
    support_cap: float = 0.25
    def_army_share: float = 0.8
    readiness_floor: float = 0.5
    star_thresholds: tuple = (40.0, 65.0, 90.0)
    draw_threshold: float = 30.0
    atk_destroy: float = 0.08
    atk_damage: float = 0.20
    def_destroy: float = 0.06
    def_damage: float = 0.18
    counter: dict = field(default_factory=dict)

    @staticmethod
    def from_dict(d: dict) -> "Params":
        def f(key, default):
            try:
                return float(d.get(key, default))
            except (TypeError, ValueError):
                return default
        try:
            th = tuple(float(x) for x in str(d.get("war_f_star_thresholds", "40,65,90")).split(","))
            if len(th) != 3:
                th = (40.0, 65.0, 90.0)
        except ValueError:
            th = (40.0, 65.0, 90.0)
        try:
            cm = json.loads(d.get("war_f_counter_matrix") or "{}")
        except (TypeError, ValueError):
            cm = {}
        return Params(
            k=f("war_f_k", 2.2), h=f("war_f_h", 1.15), rnd=f("war_f_random", 0.15),
            damaged_mult=f("war_f_damaged_mult", 0.6), support_cap=f("war_f_support_cap", 0.25),
            def_army_share=f("war_f_def_army_share", 0.8), readiness_floor=f("war_f_readiness_floor", 0.5),
            star_thresholds=th, draw_threshold=f("war_f_draw_threshold", 30),
            atk_destroy=f("war_f_atk_destroy", 0.08), atk_damage=f("war_f_atk_damage", 0.20),
            def_destroy=f("war_f_def_destroy", 0.06), def_damage=f("war_f_def_damage", 0.18),
            counter=cm,
        )


def validate_counter_matrix(cm: dict) -> str:
    """هیچ Equipmentی نباید Uncounterable یا Unbeatable باشه: ضرایب باید داخل [0.5, 1.5] باشن."""
    if not isinstance(cm, dict) or not cm:
        return "ماتریس خالیه"
    for cat, row in cm.items():
        if not isinstance(row, dict):
            return f"ردیفِ {cat} معتبر نیست"
        for t, v in row.items():
            if t not in DEF_TYPES:
                return f"نوعِ دفاعِ «{t}» مجاز نیست (ground/air/generic)"
            try:
                v = float(v)
            except (TypeError, ValueError):
                return "مقدارِ غیرعددی"
            if not 0.5 <= v <= 1.5:
                return f"ضریبِ {cat}/{t} باید بین ۰٫۵ و ۱٫۵ باشه (هیچ تجهیزی نباید کاملاً Uncounterable باشه)"
    return ""


def cond_power(u: Unit, attr: str, p: Params) -> float:
    """قدرتِ مؤثرِ گروهِ یک نوع واحد: سالم‌ها کامل، آسیب‌دیده‌ها با ضریبِ Damaged."""
    base = getattr(u, attr) * u.level_mult
    return base * (u.healthy + u.damaged * p.damaged_mult)


def readiness_factor(readiness: float, p: Params) -> float:
    r = max(0.0, min(100.0, readiness)) / 100.0
    return p.readiness_floor + (1.0 - p.readiness_floor) * r


def attack_side(army, p: Params, readiness: float, atk_mult: float, research_mult: float):
    """برمی‌گردونه: (کلِ حمله‌ی خام, حمله به تفکیکِ دسته, بونوسِ پشتیبانی)."""
    by_cat = {}
    support = 0.0
    for u in army:
        n_eff = u.healthy + u.damaged * p.damaged_mult
        if u.support_pct:
            support += u.support_pct / 100.0 * n_eff
        if u.atk > 0:
            by_cat[u.cat] = by_cat.get(u.cat, 0.0) + cond_power(u, "atk", p) * u.accuracy
    support = min(p.support_cap, support)
    total = sum(by_cat.values())
    rf = readiness_factor(readiness, p)
    return total * rf * atk_mult * research_mult * (1.0 + support), by_cat, support


def defense_side(structures, def_army, p: Params, def_readiness: float, wall_mult: float, research_mult: float):
    """structures: [{'type': ground|air|generic, 'power': x}] ؛ def_army: [Unit] مستقر در پایگاه."""
    P = {"ground": 0.0, "air": 0.0, "generic": 0.0}
    for s in structures:
        t = s["type"] if s["type"] in P else "generic"
        P[t] += float(s["power"])
    rf = readiness_factor(def_readiness, p)
    for u in def_army:
        if u.defn > 0:
            t = _CAT_TO_DEF_TYPE.get(u.cat, "generic")
            P[t] += cond_power(u, "defn", p) * p.def_army_share * rf
    total = sum(P.values()) * wall_mult * research_mult
    return total, P


def counter_multiplier(by_cat: dict, P: dict, p: Params) -> float:
    """میانگینِ وزنی ضریبِ کانتر: ترکیبِ ارتشِ مهاجم × ترکیبِ دفاع."""
    a_total = sum(by_cat.values())
    p_total = sum(P.values())
    if a_total <= 0 or p_total <= 0:
        return 1.0
    m = 0.0
    for cat, a in by_cat.items():
        row = p.counter.get(cat) or {}
        inner = 0.0
        for t in DEF_TYPES:
            inner += (P[t] / p_total) * float(row.get(t, 1.0))
        m += (a / a_total) * inner
    return m


def destruction_from_ratio(ratio: float, p: Params) -> float:
    if ratio <= 0:
        return 0.0
    rk = ratio ** p.k
    return 100.0 * rk / (rk + p.h ** p.k)


def stars_from_destruction(d: float, p: Params) -> int:
    return sum(1 for th in p.star_thresholds if d >= th)


def _stoch_round(x: float, rng: random.Random) -> int:
    base = int(math.floor(x))
    return base + (1 if rng.random() < (x - base) else 0)


def apply_casualties(units, destroy_rate: float, damage_rate: float, cas_mult: float, rng: random.Random):
    """
    هر گروه: {key: (new_healthy, new_damaged, destroyed)}.
    آسیب‌دیده‌ها ۱٫۵ برابر مستعدِ نابودی‌ان. نرخ‌ها با durability تقسیم می‌شن.
    """
    out = {}
    for u in units:
        dur = max(0.2, u.durability)
        rd = min(0.9, destroy_rate * cas_mult / dur)
        rdm = min(0.9, damage_rate * cas_mult / dur)
        dead_h = min(u.healthy, _stoch_round(u.healthy * rd, rng))
        dead_d = min(u.damaged, _stoch_round(u.damaged * min(1.0, rd * 1.5), rng))
        alive_h = u.healthy - dead_h
        new_dam = min(alive_h, _stoch_round(alive_h * rdm, rng))
        out[u.key] = (alive_h - new_dam, u.damaged - dead_d + new_dam, dead_h + dead_d)
    return out


def resolve(seed: int, army, structures, def_army, p: Params, atk_readiness: float, def_readiness: float,
            atk_mult: float = 1.0, casualty_mult: float = 1.0, atk_research: float = 1.0,
            def_research: float = 1.0, wall_mult: float = 1.0) -> dict:
    """نبردِ کامل. خروجی JSON‌پذیر؛ با seed یکسان همیشه نتیجه‌ی یکسان."""
    rng = random.Random(seed)
    A, by_cat, support = attack_side(army, p, atk_readiness, atk_mult, atk_research)
    D, P = defense_side(structures, def_army, p, def_readiness, wall_mult, def_research)
    M = counter_multiplier(by_cat, P, p)
    A_eff = A * M
    noise = 1.0 + rng.uniform(-p.rnd, p.rnd)
    if D <= 0:
        ratio = 1e6 if A_eff > 0 else 0.0
    else:
        ratio = (A_eff / D) * noise
    destruction = destruction_from_ratio(ratio, p) if A_eff > 0 else 0.0
    st = stars_from_destruction(destruction, p)
    if st >= 1:
        outcome = "attacker"
    elif destruction >= p.draw_threshold:
        outcome = "draw"
    else:
        outcome = "defender"
    pressure_a = 3.0 if A_eff <= 0 else max(0.25, min(3.0, D / A_eff))
    pressure_d = max(0.25, min(3.0, (A_eff / D) if D > 0 else 3.0)) * (destruction / 100.0)
    atk_cas = apply_casualties(army, p.atk_destroy * pressure_a, p.atk_damage * pressure_a, casualty_mult, rng)
    def_cas = apply_casualties(def_army, p.def_destroy * pressure_d, p.def_damage * pressure_d, 1.0, rng)
    return {
        "outcome": outcome, "stars": st, "destruction": round(destruction, 2), "ratio": round(ratio, 4),
        "attack_power": round(A_eff, 2), "defense_power": round(D, 2), "counter_mult": round(M, 4),
        "support_bonus": round(support, 4), "pressure": round(pressure_a, 3),
        "atk_units": {k: {"h": v[0], "d": v[1], "x": v[2]} for k, v in atk_cas.items()},
        "def_units": {k: {"h": v[0], "d": v[1], "x": v[2]} for k, v in def_cas.items()},
    }


def story(res: dict, atk_name: str, def_name: str, names: dict) -> list:
    """روایتِ کوتاهِ نبرد (Battle Story) - فقط از نتیجه ساخته می‌شه، هیچ اطلاعاتِ اضافه‌ای لو نمیده."""
    lines = ["⚔️ عملیات آغاز شد", "🛰 نیروها مستقر شدند"]
    if res.get("counter_mult", 1) >= 1.08:
        lines.append("🎯 ترکیبِ نیروها نقطه‌ضعفِ دفاعِ دشمن رو پیدا کرد")
    elif res.get("counter_mult", 1) <= 0.92:
        lines.append("🛡 دفاعِ دشمن مقابلِ این ترکیب قدرتِ بیشتری داشت")
    d = res.get("destruction", 0)
    if d >= 60:
        lines.append("💥 بخشِ بزرگی از دفاعِ دشمن نابود شد")
    elif d >= 30:
        lines.append("💥 بخشی از دفاعِ دشمن از بین رفت")
    else:
        lines.append("🧱 دفاعِ دشمن مقاومت کرد")
    dead_def = sum(v["x"] for v in res.get("def_units", {}).values())
    dead_atk = sum(v["x"] for v in res.get("atk_units", {}).values())
    if dead_def:
        lines.append("🔥 ضدحمله‌ی دشمن و درگیریِ تن‌به‌تن")
    if dead_atk:
        lines.append(f"💔 {dead_atk} واحدِ مهاجم از دست رفت")
    if res["outcome"] == "attacker":
        lines.append(f"🏆 نتیجه: {atk_name} پیروز شد ({res['stars']}⭐)")
    elif res["outcome"] == "draw":
        lines.append("🤝 نتیجه: نبرد مساوی شد")
    else:
        lines.append(f"🏆 نتیجه: {def_name} دفاع کرد و پایگاه ایستاد")
    return lines
