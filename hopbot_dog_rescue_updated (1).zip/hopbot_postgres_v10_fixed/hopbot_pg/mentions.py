# -*- coding: utf-8 -*-
"""
سیستمِ مرکزیِ «منشن»: به‌جای @یوزرنیم، اسمِ بازیکن به‌صورتِ منشنِ قابل‌کلیک نشون داده می‌شه.

طرز کار:
  ۱) هرجا اسمِ کاربر لازمه (db.User.display_name() یا mentions.of(tg_user)) یه «نشانه» تو متن می‌ره:
        <U+E000>آیدی<U+E001>اسم<U+E002>
  ۲) mentions.install() همه‌ی متدهای ارسال/ویرایشِ پیامِ ربات رو یه‌بار می‌پیچه؛ قبل از رفتن به تلگرام
     (الف) متن و دکمه‌ها به زبانِ چتِ مقصد ترجمه می‌شن (i18n.tr) و
     (ب) نشانه‌ها به اسمِ ساده + entity تبدیل می‌شن (آفستِ UTF-16 درست).
  ۳) نوعِ entity برایِ هر کاربر:
        • اگه کاربر قبلاً تو پیوی با بات حرف زده (chat_prefs.is_pm_known) → text_mention (کلیک + نوتیفِ منشن)
        • وگرنه اگه یوزرنیم داره → لینکِ https://t.me/<یوزرنیم>
        • وگرنه → لینکِ tg://openmessage?user_id=<آیدی>   (بدونِ نیاز به پیوی‌کردنِ کاربر با بات)
     با config.MENTION_MODE می‌شه عوضش کرد: auto (پیش‌فرض) | mention | link
  ۴) زنجیره‌یِ جایگزین: اگه تلگرام entity رو رد کنه → همه با لینک → اگه بازم نشد متنِ ساده.
     هیچ پیامی گم نمی‌شه. متنِ دکمه‌ها و هشدارِ کالبک فقط اسمِ ساده می‌گیرن (تلگرام اونجا entity نداره).
"""
import logging
import re

logger = logging.getLogger(__name__)

OPEN, MID, CLOSE = "\ue000", "\ue001", "\ue002"
_MARK = re.compile(OPEN + r"(-?\d+)" + MID + r"(.*?)" + CLOSE, re.S)
_STRAY = re.compile("[" + OPEN + MID + CLOSE + "]")
MAX_ENTITIES = 100                                   # سقفِ تلگرام در هر پیام


def _clean_name(name) -> str:
    n = _STRAY.sub("", str(name or "")).replace("\n", " ").strip()
    return n or "کاربر"


def mark(uid, name) -> str:
    return f"{OPEN}{int(uid)}{MID}{_clean_name(name)}{CLOSE}"


def of(tg_user) -> str:
    """منشن از روی آبجکتِ کاربرِ تلگرام (update.effective_user و مشابهش)."""
    name = getattr(tg_user, "first_name", None) or getattr(tg_user, "username", None) or str(getattr(tg_user, "id", ""))
    return mark(tg_user.id, name)


def has(text) -> bool:
    return isinstance(text, str) and OPEN in text


def plain(text):
    """نشانه‌ها → اسمِ ساده (برای دکمه‌ها، هشدار، لاگ)."""
    if not isinstance(text, str) or OPEN not in text and MID not in text and CLOSE not in text:
        return text
    return _STRAY.sub("", _MARK.sub(lambda m: m.group(2), text))


def u16len(s: str) -> int:
    return len(s.encode("utf-16-le")) // 2


def resolve(text: str):
    """-> (متنِ ساده, [(offset16, length16, user_id)])"""
    if not has(text):
        return text, []
    out, ents, pos = [], [], 0
    cur16 = 0
    for m in _MARK.finditer(text):
        before = text[pos:m.start()]
        before = _STRAY.sub("", before)
        out.append(before)
        cur16 += u16len(before)
        name = _STRAY.sub("", m.group(2))
        ents.append((cur16, u16len(name), int(m.group(1))))
        out.append(name)
        cur16 += u16len(name)
        pos = m.end()
    tail = _STRAY.sub("", text[pos:])
    out.append(tail)
    return "".join(out), [e for e in ents if e[1] > 0]


# ---------------------------------------------------------------------------
# اتصال به python-telegram-bot
# ---------------------------------------------------------------------------
# متد: (نامِ پارامترِ متن, اندیسِ موقعیتیِ متن یا None, نامِ پارامترِ entities, اندیسِ موقعیتیِ chat_id یا None)
_TEXT_METHODS = {
    "send_message": ("text", 1, "entities", 0),
    "edit_message_text": ("text", 0, "entities", None),
    "send_photo": ("caption", None, "caption_entities", 0),
    "send_video": ("caption", None, "caption_entities", 0),
    "send_animation": ("caption", None, "caption_entities", 0),
    "send_document": ("caption", None, "caption_entities", 0),
    "send_audio": ("caption", None, "caption_entities", 0),
    "send_voice": ("caption", None, "caption_entities", 0),
    "edit_message_caption": ("caption", None, "caption_entities", None),
    "edit_message_reply_markup": (None, None, None, None),     # فقط دکمه‌ها
}


def _mode():
    try:
        import config
        return (getattr(config, "MENTION_MODE", "auto") or "auto").lower()
    except Exception:
        return "auto"


def _link_for(uid, username):
    if username:
        return f"https://t.me/{username}"
    return f"tg://openmessage?user_id={int(uid)}"


def _make_entity(off, length, uid, name, kind="mention", username=None):
    from telegram import MessageEntity, User
    if kind == "mention":
        return MessageEntity(type="text_mention", offset=off, length=length,
                             user=User(id=uid, first_name=name or "کاربر", is_bot=False))
    return MessageEntity(type="text_link", offset=off, length=length, url=_link_for(uid, username))


def _kind_for(uid, mode):
    """-> (kind, username)  kind: mention | link"""
    if mode == "link":
        kind = "link"
    elif mode == "mention":
        kind = "mention"
    else:
        try:
            import chat_prefs
            kind = "mention" if chat_prefs.is_pm_known(uid) else "link"
        except Exception:
            kind = "mention"
    uname = None
    if kind == "link":
        try:
            import chat_prefs
            uname = chat_prefs.username_of(uid)
        except Exception:
            uname = None
    return kind, uname


def _map_markup(rm, fn):
    """fn روی متنِ هر دکمه‌ی اینلاین اجرا می‌شه (فقط اگه چیزی عوض بشه markup جدید ساخته می‌شه)."""
    rows = getattr(rm, "inline_keyboard", None) if rm is not None else None
    if not rows:
        return rm
    changed = False
    new = []
    for r in rows:
        nr = []
        for b in r:
            t = getattr(b, "text", "")
            nt = fn(t)
            if nt != t:
                from telegram import InlineKeyboardButton
                d = b.to_dict()
                d["text"] = nt
                b = InlineKeyboardButton.de_json(d, None)
                changed = True
            nr.append(b)
        new.append(nr)
    if not changed:
        return rm
    from telegram import InlineKeyboardMarkup
    return InlineKeyboardMarkup(new)


def _clean_markup(rm):
    """متنِ دکمه‌ها نمی‌تونه منشن داشته باشه؛ نشانه‌ها رو به اسمِ ساده تبدیل می‌کنه."""
    return _map_markup(rm, lambda t: plain(t) if has(t) else t)


def _chat_arg(spec, args, kwargs):
    pos = spec[3]
    if "chat_id" in kwargs:
        return kwargs["chat_id"]
    if pos is not None and len(args) > pos:
        return args[pos]
    return None


def _prepare(name, spec, args, kwargs):
    """-> (variants) لیستِ (args, kwargs) به ترتیبِ اولویت؛ اولی بهترین، آخری متنِ ساده.
    فقط اگه لازم باشه چیزی عوض می‌شه."""
    import i18n
    tname, tpos, ename, _cp = spec
    args = list(args)
    lang = i18n.lang_of_chat(_chat_arg(spec, args, kwargs))

    # دکمه‌ها: ترجمه ← حذفِ نشانه‌ها
    if "reply_markup" in kwargs:
        rm = i18n.tr_markup(kwargs["reply_markup"], lang)
        kwargs["reply_markup"] = _clean_markup(rm)
    if tname is None:
        return [(args, kwargs)]

    in_kw = tname in kwargs
    if in_kw:
        text = kwargs.get(tname)
    elif tpos is not None and len(args) > tpos:
        text = args[tpos]
    else:
        text = None
    if not isinstance(text, str):
        return [(args, kwargs)]

    text = i18n.tr(text, lang)                       # ترجمه (نشانه‌هایِ منشن دست‌نخورده می‌مونن)

    def _put(a, k, value):
        a, k = list(a), dict(k)
        if in_kw:
            k[tname] = value
        else:
            a[tpos] = value
        return a, k

    if not has(text):
        return [_put(args, kwargs, text)]

    plain_variant = _put(args, kwargs, plain(text))
    has_manual = bool(kwargs.get(ename))
    pm = kwargs.get("parse_mode")
    if pm is not None and not _is_default(pm):
        has_manual = True
    new_text, ents = resolve(text)
    if has_manual or not ents:
        return [plain_variant]
    names = {int(m.group(1)): _STRAY.sub("", m.group(2)) for m in _MARK.finditer(text)}
    mode = _mode()
    variants = []
    for kind_override in (None, "link"):
        objs = []
        for (o, l, uid) in ents[:MAX_ENTITIES]:
            kind, uname = _kind_for(uid, mode)
            if kind_override:
                kind = kind_override
                try:
                    import chat_prefs
                    uname = chat_prefs.username_of(uid)
                except Exception:
                    uname = None
            objs.append(_make_entity(o, l, uid, names.get(uid, ""), kind, uname))
        a, k = _put(args, kwargs, new_text)
        k[ename] = objs
        variants.append((a, k))
        if all(e.type == "text_link" for e in objs):
            break                                   # نسخه‌یِ دوم (همه لینک) فقط وقتی لازمه که اولی mention داشت
    variants.append(plain_variant)
    return variants


def _is_default(pm):
    return pm.__class__.__name__ == "DefaultValue"


def _wrap(orig, name, spec):
    async def wrapper(self, *args, **kwargs):
        try:
            variants = _prepare(name, spec, args, dict(kwargs))
        except Exception:
            logger.exception("mentions/i18n prepare failed")
            variants = [(list(args), dict(kwargs))]
        last = len(variants) - 1
        for i, (a, k) in enumerate(variants):
            try:
                return await orig(self, *a, **k)
            except Exception as e:
                err = str(e).lower()
                if i < last and ("entit" in err or "user" in err or "parse" in err or "url" in err or "link" in err):
                    logger.warning("mention variant %d rejected (%s) → next", i, e)
                    continue
                raise
    wrapper._hop_mentions = True
    wrapper.__name__ = getattr(orig, "__name__", name)
    wrapper.__doc__ = getattr(orig, "__doc__", None)
    return wrapper


def _wrap_answer(orig):
    async def wrapper(self, *args, **kwargs):
        try:
            import i18n
            lang = i18n.lang_of_chat(None)           # چتِ جاریِ آپدیت
            if "text" in kwargs:
                kwargs["text"] = plain(i18n.tr(kwargs["text"], lang))
            elif len(args) > 1:
                args = list(args)
                args[1] = plain(i18n.tr(args[1], lang))
        except Exception:
            logger.exception("answer_callback_query localize failed")
        return await orig(self, *args, **kwargs)
    wrapper._hop_mentions = True
    return wrapper


def install():
    """یه‌بار موقعِ استارتِ بات صدا بزن. چندبار صدا زدنش بی‌ضرره."""
    import telegram
    classes = [telegram.Bot]
    try:
        from telegram.ext import ExtBot
        classes.append(ExtBot)
    except Exception:
        pass
    n = 0
    for cls in classes:
        for name, spec in _TEXT_METHODS.items():
            fn = cls.__dict__.get(name)
            if fn is None or getattr(fn, "_hop_mentions", False):
                continue
            setattr(cls, name, _wrap(fn, name, spec))
            n += 1
        fn = cls.__dict__.get("answer_callback_query")
        if fn is not None and not getattr(fn, "_hop_mentions", False):
            setattr(cls, "answer_callback_query", _wrap_answer(fn))
            n += 1
    logger.info("mentions+i18n installed (%d methods)", n)
    return n
