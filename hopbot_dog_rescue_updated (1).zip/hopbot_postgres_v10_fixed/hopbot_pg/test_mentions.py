# -*- coding: utf-8 -*-
"""
تست‌های سیستمِ منشن. اجرا:  python3 -m unittest test_mentions -v
(برای متدهای ارسال از یه «تلگرامِ ساختگی» استفاده می‌شه؛ سازگاریِ نهایی با python-telegram-bot واقعی باید روی سرور چک بشه.)
"""
import asyncio
import sys
import types
import unittest

import mentions as M


class Pure(unittest.TestCase):
    def test_mark_and_plain(self):
        t = f"سلام {M.mark(5, 'علی')} خوبی؟"
        self.assertEqual(M.plain(t), "سلام علی خوبی؟")
        self.assertTrue(M.has(t))
        self.assertFalse(M.has("بدونِ منشن"))

    def test_offsets_utf16_with_emoji_and_persian(self):
        t = f"🥷 {M.mark(7, 'رضا')} و {M.mark(8, 'Sara😀')}!"
        text, ents = M.resolve(t)
        self.assertEqual(text, "🥷 رضا و Sara😀!")
        u = text.encode("utf-16-le")
        for off, ln, uid in ents:
            seg = u[off * 2:(off + ln) * 2].decode("utf-16-le")
            self.assertEqual(seg, {7: "رضا", 8: "Sara😀"}[uid])
        self.assertEqual([e[2] for e in ents], [7, 8])

    def test_no_marks_untouched(self):
        self.assertEqual(M.resolve("ساده"), ("ساده", []))

    def test_name_cleaning(self):
        m = M.mark(1, "a\nb\ue000c")
        self.assertEqual(M.plain(m), "a bc")
        self.assertEqual(M.plain(M.mark(2, "")), "کاربر")

    def test_truncated_marker_is_stripped_not_leaked(self):
        t = M.mark(3, "نامِ بلند")[:-3]                          # برش خوردنِ وسطِ نشانه (text[:3900])
        out, ents = M.resolve("x" + t)
        self.assertNotIn(M.OPEN, out)
        self.assertNotIn(M.MID, out)
        self.assertEqual(ents, [])

    def test_of_prefers_first_name(self):
        u = types.SimpleNamespace(id=9, first_name="مینا", username="mina")
        self.assertEqual(M.plain(M.of(u)), "مینا")
        u2 = types.SimpleNamespace(id=9, first_name=None, username="mina")
        self.assertEqual(M.plain(M.of(u2)), "mina")
        u3 = types.SimpleNamespace(id=9, first_name=None, username=None)
        self.assertEqual(M.plain(M.of(u3)), "9")


def _fake_telegram():
    tg = types.ModuleType("telegram")
    ext = types.ModuleType("telegram.ext")

    class MessageEntity:
        def __init__(self, type, offset, length, user=None, url=None):
            self.type, self.offset, self.length, self.user, self.url = type, offset, length, user, url

    class User:
        def __init__(self, id, first_name, is_bot):
            self.id, self.first_name, self.is_bot = id, first_name, is_bot

    class Btn:
        def __init__(self, text, callback_data=None):
            self.text, self.callback_data = text, callback_data

        def to_dict(self):
            return {"text": self.text, "callback_data": self.callback_data}

        @classmethod
        def de_json(cls, d, bot):
            return cls(**d)

    class Markup:
        def __init__(self, rows):
            self.inline_keyboard = rows

    class Bot:
        calls = []
        fail_with_entities = False

        async def send_message(self, chat_id, text, parse_mode=None, entities=None, reply_markup=None):
            if entities and Bot.fail_with_entities:
                raise RuntimeError("Bad Request: can't parse entities")
            Bot.calls.append(("send", chat_id, text, entities, reply_markup))
            return "ok"

        async def edit_message_text(self, text, chat_id=None, message_id=None, entities=None, reply_markup=None):
            Bot.calls.append(("edit", chat_id, text, entities, reply_markup))
            return "ok"

        async def send_photo(self, chat_id, photo, caption=None, caption_entities=None):
            Bot.calls.append(("photo", chat_id, caption, caption_entities, None))

        async def answer_callback_query(self, callback_query_id, text=None, show_alert=None):
            Bot.calls.append(("answer", callback_query_id, text, None, None))

    class ExtBot(Bot):
        async def send_message(self, chat_id, text, parse_mode=None, entities=None, reply_markup=None):
            return await super().send_message(chat_id=chat_id, text=text, parse_mode=parse_mode, entities=entities, reply_markup=reply_markup)

    tg.Bot, tg.MessageEntity, tg.User = Bot, MessageEntity, User
    tg.InlineKeyboardButton, tg.InlineKeyboardMarkup = Btn, Markup
    ext.ExtBot = ExtBot
    tg.ext = ext
    return tg, ext


class Hook(unittest.TestCase):
    def setUp(self):
        self._saved = {k: sys.modules.get(k) for k in ("telegram", "telegram.ext")}
        tg, ext = _fake_telegram()
        sys.modules["telegram"], sys.modules["telegram.ext"] = tg, ext
        self.tg = tg
        tg.Bot.calls.clear()
        tg.Bot.fail_with_entities = False
        import chat_prefs, config
        self._cp = (chat_prefs.get_lang, chat_prefs.is_pm_known, chat_prefs.username_of, getattr(config, "MENTION_MODE", "auto"))
        chat_prefs.get_lang = lambda cid: "fa"                  # این تست‌ها به دیتابیس نیاز ندارن
        chat_prefs.username_of = lambda uid: None
        chat_prefs.is_pm_known = lambda uid: True
        config.MENTION_MODE = "mention"                         # رفتارِ قدیمی: همیشه text_mention
        M.install()
        self.bot = tg.ext.ExtBot()

    def tearDown(self):
        import chat_prefs, config
        chat_prefs.get_lang, chat_prefs.is_pm_known, chat_prefs.username_of, config.MENTION_MODE = self._cp
        for k, v in self._saved.items():
            if v is None:
                sys.modules.pop(k, None)
            else:
                sys.modules[k] = v

    def run_(self, coro):
        return asyncio.new_event_loop().run_until_complete(coro)

    def test_send_message_gets_text_mention(self):
        self.run_(self.bot.send_message(1, f"نوبتِ {M.mark(42, 'علی')} است"))
        kind, chat, text, ents, _ = self.tg.Bot.calls[-1]
        self.assertEqual(text, "نوبتِ علی است")
        self.assertEqual(len(ents), 1)
        e = ents[0]
        self.assertEqual((e.type, e.user.id, e.user.first_name), ("text_mention", 42, "علی"))
        self.assertEqual(text.encode("utf-16-le")[e.offset * 2:(e.offset + e.length) * 2].decode("utf-16-le"), "علی")

    def test_positional_text_for_edit(self):
        self.run_(self.bot.edit_message_text(f"برنده: {M.mark(5, 'سارا')}", chat_id=1, message_id=2))
        _k, _c, text, ents, _ = self.tg.Bot.calls[-1]
        self.assertEqual(text, "برنده: سارا")
        self.assertEqual(ents[0].user.id, 5)

    def test_caption_and_alert(self):
        self.run_(self.bot.send_photo(1, "p", caption=f"{M.mark(1, 'الف')}"))
        self.assertEqual(self.tg.Bot.calls[-1][2], "الف")
        self.assertEqual(self.tg.Bot.calls[-1][3][0].user.id, 1)
        self.run_(self.bot.answer_callback_query("cb", text=f"سلام {M.mark(1, 'الف')}"))
        self.assertEqual(self.tg.Bot.calls[-1][2], "سلام الف")

    def test_keyboard_labels_are_plain(self):
        kb = self.tg.InlineKeyboardMarkup([[self.tg.InlineKeyboardButton(f"انتقال به {M.mark(3, 'نیما')}", callback_data="x")]])
        self.run_(self.bot.send_message(1, "متن", reply_markup=kb))
        sent = self.tg.Bot.calls[-1][4]
        self.assertEqual(sent.inline_keyboard[0][0].text, "انتقال به نیما")
        self.assertEqual(sent.inline_keyboard[0][0].callback_data, "x")

    def test_fallback_when_telegram_rejects_entities(self):
        self.tg.Bot.fail_with_entities = True
        r = self.run_(self.bot.send_message(1, f"سلام {M.mark(9, 'علی')}"))
        self.assertEqual(r, "ok")
        _k, _c, text, ents, _ = self.tg.Bot.calls[-1]
        self.assertEqual(text, "سلام علی")
        self.assertFalse(ents)

    def test_other_errors_still_raise(self):
        async def boom(self, *a, **k):
            raise RuntimeError("Forbidden: bot was blocked")
        self.tg.Bot.send_message = M._wrap(boom, "send_message", M._TEXT_METHODS["send_message"])
        with self.assertRaises(RuntimeError):
            self.run_(self.tg.Bot().send_message(1, f"x {M.mark(1, 'a')}"))

    def test_manual_entities_or_parse_mode_fall_back_to_plain(self):
        self.run_(self.bot.send_message(1, f"x {M.mark(1, 'الف')}", entities=["manual"]))
        self.assertEqual(self.tg.Bot.calls[-1][2], "x الف")
        self.assertEqual(self.tg.Bot.calls[-1][3], ["manual"])

    def test_plain_text_untouched_and_install_idempotent(self):
        self.run_(self.bot.send_message(1, "بدونِ منشن"))
        self.assertEqual(self.tg.Bot.calls[-1][2:4], ("بدونِ منشن", None))
        before = self.tg.Bot.send_message
        M.install()
        self.assertIs(before, self.tg.Bot.send_message)

    def test_auto_mode_unknown_user_gets_clickable_link(self):
        import chat_prefs, config
        config.MENTION_MODE = "auto"
        chat_prefs.is_pm_known = lambda uid: uid == 2                  # فقط ۲ تو پیوی بوده
        chat_prefs.username_of = lambda uid: "bob" if uid == 3 else None
        t = f"{M.mark(1, 'الف')} {M.mark(2, 'ب')} {M.mark(3, 'ج')}"
        self.run_(self.bot.send_message(1, t))
        ents = self.tg.Bot.calls[-1][3]
        self.assertEqual([(e.type, e.url, getattr(e.user, "id", None)) for e in ents], [
            ("text_link", "tg://openmessage?user_id=1", None),     # ناشناخته + بدونِ یوزرنیم
            ("text_mention", None, 2),                             # پیوی‌کرده
            ("text_link", "https://t.me/bob", None),               # یوزرنیم‌دار
        ])

    def test_link_fallback_chain_mention_rejected_then_link_then_plain(self):
        import chat_prefs, config
        config.MENTION_MODE = "auto"
        chat_prefs.is_pm_known = lambda uid: True
        calls = []
        orig = self.tg.Bot.send_message

        async def picky(self_, chat_id, text, parse_mode=None, entities=None, reply_markup=None):
            kinds = [e.type for e in (entities or [])]
            calls.append(kinds)
            if "text_mention" in kinds:
                raise RuntimeError("Bad Request: can't parse entities: user not found")
            return "ok"
        self.tg.Bot.send_message = M._wrap(picky, "send_message", M._TEXT_METHODS["send_message"])
        self.run_(self.tg.Bot().send_message(1, f"سلام {M.mark(9, 'علی')}"))
        self.assertEqual(calls, [["text_mention"], ["text_link"]])

    def test_english_chat_translates_text_and_buttons(self):
        import chat_prefs
        chat_prefs.get_lang = lambda cid: "en" if cid == 5 else "fa"
        kb = self.tg.InlineKeyboardMarkup([[self.tg.InlineKeyboardButton("🔙 بازگشت", callback_data="x")]])
        self.run_(self.bot.send_message(5, "❌ عملیات لغو شد.", reply_markup=kb))
        self.assertEqual(self.tg.Bot.calls[-1][2], "❌ Action cancelled.")
        self.assertEqual(self.tg.Bot.calls[-1][4].inline_keyboard[0][0].text, "🔙 Back")
        self.run_(self.bot.send_message(6, "❌ عملیات لغو شد."))            # گروهِ فارسی دست‌نخورده
        self.assertEqual(self.tg.Bot.calls[-1][2], "❌ عملیات لغو شد.")

    def test_group_reply_uses_personal_language_of_the_user(self):
        import chat_prefs, i18n
        chat_prefs.get_lang = lambda uid: "en" if uid == 77 else "fa"
        i18n.CURRENT_CHAT.set(-100)
        i18n.CURRENT_USER.set(77)                                   # کاربرِ انگلیسی تو گروهِ فارسی
        self.run_(self.bot.send_message(-100, "❌ عملیات لغو شد."))
        self.assertEqual(self.tg.Bot.calls[-1][2], "❌ Action cancelled.")
        i18n.CURRENT_USER.set(78)                                   # کاربرِ فارسی تو همون گروه
        self.run_(self.bot.send_message(-100, "❌ عملیات لغو شد."))
        self.assertEqual(self.tg.Bot.calls[-1][2], "❌ عملیات لغو شد.")
        i18n.CURRENT_CHAT.set(None); i18n.CURRENT_USER.set(None)
        self.run_(self.bot.send_message(-100, "❌ عملیات لغو شد."))   # جاب/بدونِ آپدیت → فارسی
        self.assertEqual(self.tg.Bot.calls[-1][2], "❌ عملیات لغو شد.")

    def test_entity_cap(self):
        t = " ".join(M.mark(i, f"n{i}") for i in range(130))
        self.run_(self.bot.send_message(1, t))
        self.assertEqual(len(self.tg.Bot.calls[-1][3]), M.MAX_ENTITIES)
        self.assertNotIn(M.OPEN, self.tg.Bot.calls[-1][2])


if __name__ == "__main__":
    unittest.main()
