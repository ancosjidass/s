# -*- coding: utf-8 -*-
"""تستِ سیو/بازیابیِ اکانت با جیمیل (بدونِ ایمیل/تلگرامِ واقعی).
اجرا:  python test_account_backup.py"""
import asyncio
import datetime
import os
import tempfile

_tmp = tempfile.mkdtemp()
os.environ["DB_PATH"] = os.path.join(_tmp, "t.db")
os.environ["BOT_TOKEN"] = "1:x"
os.environ["OWNER_ID"] = "999"
_tok = os.path.join(_tmp, "token.json")
open(_tok, "w").write("{}")
os.environ["GMAIL_TOKEN_PATH"] = _tok   # فقط وجودِ فایل مهمه (ارسالِ ایمیل تو تست‌ها mock می‌شه)

import db  # noqa: E402
import war_db  # noqa: E402
import war_svc as S  # noqa: E402
import account_backup as ab  # noqa: E402

db.init_db()
war_db.init_war()
ab.init_backup()

passed = []


def ok(msg):
    passed.append(msg)
    print("  ✓", msg)


def test_normalize():
    assert ab.normalize_email("A.B+tag@Gmail.com")[0] == "ab@gmail.com"
    assert ab.normalize_email("ab@googlemail.com")[0] == "ab@gmail.com"
    assert ab.normalize_email("x@yahoo.com") == (None, None)
    assert ab.normalize_email("nonsense") == (None, None)
    ok("gmail normalisation (dots / +tag / googlemail) and non-gmail rejected")


async def test_codes_and_limits():
    sent = []

    async def fake_send(to, code, purpose):
        sent.append((to, code, purpose))
        return True

    ab._send_email = fake_send
    s = db.get_session()
    code_id, err = await ab.issue_code(s, 111, "ab@gmail.com", "ab@gmail.com", "link")
    assert err is None and len(sent) == 1
    good = sent[0][1]
    # کدِ غلط
    ok_, msg = ab.check_code(s, code_id, 111, "000000" if good != "000000" else "111111")
    assert not ok_ and "اشتباه" in msg
    # کسِ دیگه نمی‌تونه از کدِ این کاربر استفاده کنه
    ok_, _ = ab.check_code(s, code_id, 222, good)
    assert not ok_
    ok_, _ = ab.check_code(s, code_id, 111, good)
    assert ok_
    ok("code: wrong rejected, other user rejected, right accepted")

    # ۵ حدسِ غلط = باطل
    cid, _ = await ab.issue_code(s, 112, "cd@gmail.com", "cd@gmail.com", "link")
    real = sent[-1][1]
    wrong = "123456" if real != "123456" else "654321"
    for _ in range(ab.MAX_WRONG_ATTEMPTS):
        ab.check_code(s, cid, 112, wrong)
    ok_, msg = ab.check_code(s, cid, 112, real)
    assert not ok_ and "معتبر نیست" in msg
    ok("code invalidated after 5 wrong guesses (even the right code afterwards)")

    # انقضا
    cid, _ = await ab.issue_code(s, 113, "ef@gmail.com", "ef@gmail.com", "link")
    real = sent[-1][1]
    row = s.get(ab.EmailCode, cid)
    row.expires_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
    s.commit()
    ok_, msg = ab.check_code(s, cid, 113, real)
    assert not ok_ and "۱۸۰" in msg
    ok("code expires after 180 seconds")

    # سقفِ ۵ کد در روز برای هر آیدی
    for i in range(ab.MAX_CODES_PER_DAY):
        c, e = await ab.issue_code(s, 300, f"u{i}@gmail.com", f"u{i}@gmail.com", "link")
        assert e is None, (i, e)
    c, e = await ab.issue_code(s, 300, "zz@gmail.com", "zz@gmail.com", "link")
    assert c is None and "محدود" in e
    ok("6th code in 24h for the same user id is refused with the 'محدود شدید' message")

    # ارسالِ ناموفق از سهمیه کم نمی‌کنه
    async def bad_send(*a):
        return False
    ab._send_email = bad_send
    n_before = ab._codes_sent(s, user_id=400)
    c, e = await ab.issue_code(s, 400, "q@gmail.com", "q@gmail.com", "link")
    assert c is None and ab._codes_sent(s, user_id=400) == n_before
    ok("failed SMTP send does not consume quota")
    s.close()


def test_migration():
    s = db.get_session()
    old = db.User(telegram_id=5001, username="old", first_name="Old", hop_points=1234.0, hop_count=50, lvl=4)
    new = db.User(telegram_id=5002, username="newname", first_name="New", hop_points=0, hop_count=0, lvl=1)
    third = db.User(telegram_id=5003, username="third", first_name="T")
    s.add_all([old, new, third])
    s.commit()
    S.get_player(s, 5001)
    S.get_player(s, 5002)        # اکانتِ جدید هم war_player داره → باید جایگزین بشه
    s.add(db.UserDebt(user_id=5001, amount=10, reason="x"))
    s.add(db.Report(reporter_id=5001, reported_user_id=5003, chat_id=1, message_id=1))
    s.add(db.Report(reporter_id=5003, reported_user_id=5001, chat_id=1, message_id=2))
    s.add(ab.AccountEmail(user_id=5001, email_norm="m@gmail.com", email_display="m@gmail.com"))
    s.commit()

    assert ab.restore_blockers(s, 5001, 5002) is None
    ab.migrate_account(s, 5001, 5002)

    s = db.get_session()
    assert s.get(db.User, 5001) is None
    u = s.get(db.User, 5002)
    assert u.hop_points == 1234.0 and u.hop_count == 50 and u.lvl == 4
    assert u.username == "newname" and u.first_name == "New"
    assert s.query(db.UserDebt).filter_by(user_id=5002).count() == 1
    assert s.query(db.UserDebt).filter_by(user_id=5001).count() == 0
    r1 = s.query(db.Report).filter_by(message_id=1).one()
    r2 = s.query(db.Report).filter_by(message_id=2).one()
    assert r1.reporter_id == 5002 and r1.reported_user_id == 5003
    assert r2.reporter_id == 5003 and r2.reported_user_id == 5002
    wp = s.query(war_db.WarPlayer).filter(war_db.WarPlayer.user_id.in_((5001, 5002))).all()
    assert [p.user_id for p in wp] == [5002]
    assert s.get(ab.AccountEmail, 5002) is not None and s.get(ab.AccountEmail, 5001) is None
    from sqlalchemy import text
    assert db.IS_PG or s.execute(text("PRAGMA foreign_key_check")).fetchall() == []   # PostgreSQL کلیدِ خارجی رو خودش اجبار می‌کنه
    ok("full migration: users, war_players (replaced), debts, reports (both columns), email link, FK check clean")

    # بلاکرها
    assert ab.restore_blockers(s, 5002, 5002) is not None
    assert ab.restore_blockers(s, 9999, 5002) is not None
    ok("restore blockers: same account / missing old account")
    s.close()


_pair = {"n": 0, "old": 0, "new": 0}


def _fresh_pair():
    """هر تست یه جفت آیدیِ تازه می‌گیره تا تست‌ها به هم گیر ندن."""
    _pair["n"] += 1
    _pair["old"], _pair["new"] = 6000 + 2 * _pair["n"], 6001 + 2 * _pair["n"]
    s = db.get_session()
    s.add_all([db.User(telegram_id=_pair["old"], username="old", hop_points=1234.0, hop_count=50, lvl=4),
               db.User(telegram_id=_pair["new"], username="newtg", first_name="N", hop_points=777.0, hop_count=3, lvl=2)])
    s.commit()
    S.get_player(s, _pair["old"]); S.get_player(s, _pair["new"]); s.commit()
    if s.query(db.Currency).first() is None:
        s.add(db.Currency(name="USD")); s.commit()
    cur = s.query(db.Currency).first()
    s.add_all([db.UserCurrency(user_id=_pair["old"], currency_id=cur.id, amount=9),
               db.UserCurrency(user_id=_pair["new"], currency_id=cur.id, amount=5)])
    s.commit()
    return s


def _state():
    s = db.get_session()
    r = {u: ((lambda x: (x.hop_points, x.hop_count, x.lvl) if x else None)(s.get(db.User, u)),
             s.query(war_db.WarPlayer).filter_by(user_id=u).count(),
             sorted(c.amount for c in s.query(db.UserCurrency).filter_by(user_id=u))) for u in (_pair["old"], _pair["new"])}
    s.close()
    return r


def test_migration_with_child_rows():
    """باگِ اصلی: وقتی اکانتِ جدید ردیفِ وابسته (ارز/محصول/...) داشت، مایگریشن با FOREIGN KEY می‌ترکید."""
    s = _fresh_pair()
    ab.migrate_account(s, _pair["old"], _pair["new"])
    r = _state()
    assert r[_pair["old"]][0] is None and r[_pair["new"]][0] == (1234.0, 50, 4)
    assert r[_pair["new"]][2] == [9.0], r        # جایگزین، نه ادغام (فقط یه ردیفِ ارز)
    ok("migration works when the NEW account already owns FK child rows (currencies) and replaces them")


def test_failure_changes_nothing():
    """هر خطا (حتی بعدِ همه‌ی نوشتن‌ها) = هیچ تغییری تو هیچ‌کدوم از اکانت‌ها."""
    s = _fresh_pair()
    before = _state()
    if db.IS_PG:
        orig_fc = ab._pg_final_check

        def boom_pg(conn):
            orig_fc(conn)
            raise RuntimeError("injected")
        ab._pg_final_check = boom_pg
        try:
            try:
                ab.migrate_account(s, _pair["old"], _pair["new"])
                assert False, "should have failed"
            except RuntimeError:
                pass
        finally:
            ab._pg_final_check = orig_fc
        assert _state() == before
        ok("failed migration (PostgreSQL): both accounts byte-identical afterwards")
        ab.migrate_account(s, _pair["old"], _pair["new"])
        assert _state()[_pair["new"]][0] == (1234.0, 50, 4)
        ok("migration succeeds on retry after a failed attempt")
        return
    orig, calls = ab._fk_violations, {"n": 0}

    def boom(cur):
        calls["n"] += 1
        if calls["n"] == 2:
            raise RuntimeError("injected")
        return orig(cur)
    ab._fk_violations = boom
    try:
        try:
            ab.migrate_account(s, _pair["old"], _pair["new"])
            assert False, "should have failed"
        except RuntimeError:
            pass
    finally:
        ab._fk_violations = orig
    assert _state() == before
    from sqlalchemy import text
    assert s.execute(text("PRAGMA foreign_keys")).scalar() == 1
    ok("failed migration: both accounts byte-identical afterwards, foreign_keys pragma restored")
    ab.migrate_account(s, _pair["old"], _pair["new"])       # و بعدش انتقالِ واقعی هنوز کار می‌کنه
    assert _state()[_pair["new"]][0] == (1234.0, 50, 4)
    ok("migration succeeds on retry after a failed attempt")


def test_preexisting_orphans_do_not_block():
    if db.IS_PG:
        return   # ردیفِ یتیم فقط تو SQLite ممکنه (PostgreSQL کلیدِ خارجی رو خودش اجبار می‌کنه)
    import sqlite3
    c = sqlite3.connect(os.environ["DB_PATH"])
    c.execute("INSERT INTO user_currencies(user_id,currency_id,amount) VALUES (424242, 99999, 1)")
    c.commit(); c.close()
    s = _fresh_pair()
    ab.migrate_account(s, _pair["old"], _pair["new"])
    assert _state()[_pair["new"]][0] == (1234.0, 50, 4)
    ok("unrelated pre-existing orphan rows in the DB do not block a restore")


def test_snapshot_written():
    s = db.get_session()
    n = s.query(ab.AccountMigrationSnapshot).count()
    assert n >= 1
    ok(f"pre-migration snapshots stored ({n})")


async def test_wrong_code_does_not_touch_data():
    sent = []

    async def fake_send(to, code, purpose):
        sent.append(code); return True
    ab._send_email = fake_send
    s = _fresh_pair()
    s.add(ab.AccountEmail(user_id=_pair["old"], email_norm="keep@gmail.com", email_display="keep@gmail.com"))
    s.commit()
    before = _state()
    cid, err = await ab.issue_code(s, _pair["new"], "keep@gmail.com", "keep@gmail.com", "restore")
    assert err is None
    for _ in range(ab.MAX_WRONG_ATTEMPTS):
        ok_, _m = ab.check_code(s, cid, _pair["new"], "000000" if sent[-1] != "000000" else "111111")
        assert not ok_
    assert _state() == before
    ok("wrong restore codes (even 5 in a row) leave both accounts completely untouched")


async def test_pv_gate():
    import types
    import main as M
    import keyboards as kb

    def upd(text=None, cb=None, chat="private", uid=123):
        u = types.SimpleNamespace()
        u.effective_chat = types.SimpleNamespace(type=chat)
        u.effective_user = types.SimpleNamespace(id=uid)
        u.message = types.SimpleNamespace(text=text, reply_to_message=None) if text is not None else None
        u.callback_query = types.SimpleNamespace(data=cb) if cb is not None else None
        return u
    s = db.get_session()
    db.cfg_set(s, "private_chat_enabled", "0")
    ctx = types.SimpleNamespace(user_data={})
    async def run(u, c=ctx):
        return await M._private_chat_blocked(u, c)
    assert (await run(upd(text="/start"))) is False
    assert (await run(upd(text="/cancel"))) is False
    assert (await run(upd(cb="acct:menu:123"))) is False
    assert (await run(upd(cb="back_main_owned:123"))) is False
    assert (await run(upd(cb="back_main:123"))) is False
    assert (await run(upd(text="/start war_abc"))) is True      # deep-link همچنان بلاک
    assert (await run(upd(text="سلام"))) is True
    assert (await run(upd(cb="hop_hop_owned:123"))) is True      # بقیه‌ی دکمه‌ها همچنان بلاک
    assert (await run(upd(cb="market_open_owned:123"))) is True
    ctx2 = types.SimpleNamespace(user_data={"acct_awaiting": {"type": "code"}})
    assert (await run(upd(text="123456"), ctx2)) is False
    db.cfg_set(s, "private_chat_enabled", "1")
    assert (await run(upd(text="سلام"))) is False
    s.close()
    # منوی محدود
    m = kb.main_private_menu(False, 1, pv_open=False)
    assert len(m.inline_keyboard) == 1 and m.inline_keyboard[0][0].callback_data == "acct:menu:1"
    assert len(kb.main_private_menu(False, 1).inline_keyboard) > 3
    ok("PV off: /start, /cancel, back_main*, acct:* and the code flow pass; all other buttons/text stay blocked; menu is acct-only")


async def main():
    test_normalize()
    await test_codes_and_limits()
    test_migration()
    test_migration_with_child_rows()
    test_failure_changes_nothing()
    test_preexisting_orphans_do_not_block()
    test_snapshot_written()
    await test_wrong_code_does_not_touch_data()
    await test_pv_gate()
    print(f"\nALL {len(passed)} CHECKS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
