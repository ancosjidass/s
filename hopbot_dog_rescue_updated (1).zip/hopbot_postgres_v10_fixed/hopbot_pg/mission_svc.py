# -*- coding: utf-8 -*-
"""
سرویسِ «مأموریت‌های هاپویی».
- پیشرفت = از جدول‌های خودِ بازی‌ها خونده می‌شه (mission_metrics)؛ هیچ Hook تو کدِ بازی‌ها نیست.
- دریافتِ پاداش Idempotent: UniqueConstraint(user, mission, period) + لجرِ war_svc.hop_apply.
- پاداش = «ساعتِ درآمدِ خودِ بازیکن» با کف/سقف و ضریبِ استریک؛ برای فقیر و پولدار هر دو معنی‌دار.
"""
import datetime
import functools
import threading

from sqlalchemy.exc import IntegrityError

import db
import mission_db as MD
import mission_engine as ME
import mission_metrics as MM

LOCK = threading.RLock()


def utcnow():
    return datetime.datetime.utcnow()


class MissionError(Exception):
    """پیامِ فارسیِ قابل‌نمایش."""


def _txn(fn):
    @functools.wraps(fn)
    def w(session, *a, **kw):
        with LOCK:
            try:
                out = fn(session, *a, **kw)
                session.commit()
                return out
            except Exception:
                session.rollback()
                raise
    return w


def gs(session, k, d=""):
    v = db.cfg_get(session, k)
    return d if v is None else str(v)


def gf(session, k, d=0.0):
    try:
        return float(db.cfg_get(session, k))
    except (TypeError, ValueError):
        return d


def gi(session, k, d=0):
    return int(gf(session, k, d))


def get_player(session, uid) -> "MD.MissionPlayer":
    p = session.get(MD.MissionPlayer, uid)
    if p is None:
        p = MD.MissionPlayer(user_id=uid)
        session.add(p)
        session.flush()
    return p


def hourly_income(user) -> float:
    return float(user.production_per_min or 0) * 60.0


def _user_level(user) -> int:
    return int(db.user_lvl(user) or 0)


# ---------------------------------------------------------------------------
# فصل
# ---------------------------------------------------------------------------
def current_season(session, now=None):
    now = now or utcnow()
    s = (session.query(MD.MissionSeason).filter(MD.MissionSeason.settled_at.is_(None), MD.MissionSeason.ends_at > now)
         .order_by(MD.MissionSeason.id.desc()).first())
    if s is None:
        days = max(1, gi(session, "ct_season_days", 30))
        s = MD.MissionSeason(started_at=now, ends_at=now + datetime.timedelta(days=days))
        session.add(s)
        session.flush()
    return s


# ---------------------------------------------------------------------------
# مأموریت‌های امروزِ یک بازیکن (سمتِ سرور؛ UI فقط نمایشش می‌ده)
# ---------------------------------------------------------------------------
def _defs(session):
    return (session.query(MD.MissionDef).filter(MD.MissionDef.enabled == True, MD.MissionDef.deleted == False)  # noqa: E712
            .order_by(MD.MissionDef.sort, MD.MissionDef.id).all())


def _dd(d):
    return {"id": d.id, "tier": d.tier, "min_level": d.min_level, "sort": d.sort}


def todays(session, user, now=None) -> list:
    """-> [{def, period, key, since, progress, done, claimed, reward}] (روزانه + هفتگی + مسیرِ تازه‌کار)."""
    now = now or utcnow()
    tz = gi(session, "ct_tz_minutes", 210)
    lvl = _user_level(user)
    defs = _defs(session)
    by_id = {d.id: d for d in defs}
    out = []
    for period, cnt_key in (("daily", "ct_daily_count"), ("weekly", "ct_weekly_count")):
        pool = [_dd(d) for d in defs if d.period == period]
        key = ME.period_key(period, now, tz)
        for pick in ME.pick_daily(pool, user.telegram_id, f"{period}|{key}", gi(session, cnt_key, 3), lvl):
            out.append((by_id[pick["id"]], period, key))
    once = [d for d in defs if d.period == "once" and (d.min_level or 0) <= lvl]
    claimed_once = {c.mission_id for c in session.query(MD.MissionClaim).filter_by(user_id=user.telegram_id, period_key="once")}
    for d in [d for d in once if d.id not in claimed_once][:max(0, gi(session, "ct_once_visible", 2))]:
        out.append((d, "once", "once"))
    res = []
    streak = get_player(session, user.telegram_id).streak
    mult = ME.streak_multiplier(streak, ME.parse_steps(gs(session, "ct_streak_steps")))
    for d, period, key in out:
        since = ME.period_start_utc(period, now, tz)
        prog = MM.measure(session, d.metric, user.telegram_id, since)
        claimed = session.query(MD.MissionClaim).filter_by(user_id=user.telegram_id, mission_id=d.id, period_key=key).first() is not None
        res.append({"def": d, "period": period, "key": key, "progress": prog, "done": prog >= d.target, "claimed": claimed,
                    "reward": _reward(session, user, d, mult)})
    return res


def _reward(session, user, d, mult) -> int:
    return ME.reward_hop(d.reward_ref_hours, d.reward_hop_abs, hourly_income(user), gf(session, "ct_floor_hourly", 60000),
                         gf(session, "ct_reward_min", 0), gf(session, "ct_reward_max", 0),
                         multiplier=mult * gf(session, "ct_reward_multiplier", 1))


def _pay(session, user, amount, reason, ref):
    import war_svc
    if amount > 0:
        war_svc.hop_apply(session, user, amount, "QUEST_REWARD", reason, ref=ref)


def _bonus_once(session, user, kind, ref, amount) -> bool:
    """بونوسِ یکتا (یک‌بار برای هر kind+ref). -> آیا پرداخت شد؟"""
    if amount <= 0:
        return False
    sp = session.begin_nested()
    try:
        session.add(MD.MissionBonus(user_id=user.telegram_id, kind=kind, ref=str(ref), hop=amount))
        session.flush()
    except IntegrityError:
        sp.rollback()
        return False
    sp.commit()
    _pay(session, user, amount, f"mission:{kind}:{ref}", ref)
    return True


@_txn
def claim(session, user, mission_id: int, chat_id=None, now=None) -> dict:
    """دریافتِ پاداشِ یه مأموریت. فقط اگه تو لیستِ امروزِ *همین* کاربر باشه و واقعاً تموم شده باشه."""
    now = now or utcnow()
    gate = db.check_module_level(session, user, "mission")
    if gate:
        raise MissionError(gate)
    if not gi(session, "ct_enabled", 1):
        raise MissionError("🎯 مأموریت‌ها فعلاً خاموشن.")
    item = next((t for t in todays(session, user, now) if t["def"].id == mission_id), None)
    if item is None:
        raise MissionError("این مأموریت برای امروزِ تو نیست.")
    if item["claimed"]:
        raise MissionError("پاداشِ این مأموریت رو قبلاً گرفتی.")
    if not item["done"]:
        raise MissionError(f"{gs(session, 'ct_msg_not_done')} ({item['progress']}/{item['def'].target})")
    tz = gi(session, "ct_tz_minutes", 210)
    today = ME.day_key(now, tz)
    p = get_player(session, user.telegram_id)
    # استریک: اولین دریافتِ روز (با حداقلِ تعدادِ تنظیمی) استریک رو جلو می‌بره
    day_start = ME.period_start_utc("daily", now, tz)
    claims_today = session.query(MD.MissionClaim).filter(MD.MissionClaim.user_id == user.telegram_id, MD.MissionClaim.created_at >= day_start).count()
    if p.last_streak_day != today and claims_today + 1 >= max(1, gi(session, "ct_streak_min_claims", 1)):
        p.streak = ME.next_streak(p.streak or 0, p.last_streak_day or "", today, gi(session, "ct_streak_grace_days", 0))
        p.best_streak = max(p.best_streak or 0, p.streak)
        p.last_streak_day = today
    mult = ME.streak_multiplier(p.streak or 0, ME.parse_steps(gs(session, "ct_streak_steps")))
    d = item["def"]
    hop = _reward(session, user, d, mult)
    pts = [int(x) for x in gs(session, "ct_season_points_per_tier", "10,25,60").split(",") if x.strip().lstrip("-").isdigit()] or [10]
    points = pts[min(max(1, d.tier), len(pts)) - 1]
    season = current_season(session, now)
    try:
        sp = session.begin_nested()
        session.add(MD.MissionClaim(user_id=user.telegram_id, mission_id=d.id, period_key=item["key"], chat_id=chat_id, tier=d.tier,
                                    hop=hop, points=points, season_id=season.id))
        session.flush()
        sp.commit()
    except IntegrityError:
        sp.rollback()
        raise MissionError("پاداشِ این مأموریت رو قبلاً گرفتی.")
    _pay(session, user, hop, f"mission:{d.id}:{item['key']}", d.id)
    p.total_claimed = (p.total_claimed or 0) + 1
    extra = 0
    if not p.welcomed:
        p.welcomed = True
        extra += _welcome_bonus(session, user)
    # تکمیلِ همه‌ی مأموریت‌های روزانه
    after = todays(session, user, now)
    daily = [t for t in after if t["period"] == "daily"]
    all_done = bool(daily) and all(t["claimed"] for t in daily)
    if all_done:
        hours = gf(session, "ct_all_done_bonus_hours", 0)
        amt = ME.reward_hop(hours, 0, hourly_income(user), gf(session, "ct_floor_hourly", 60000), 0, gf(session, "ct_reward_max", 0), multiplier=mult)
        if _bonus_once(session, user, "all_done", today, amt):
            extra += amt
    return {"hop": hop, "extra": extra, "points": points, "streak": p.streak, "mult": mult, "all_done": all_done and extra > 0,
            "title": d.title}


def _welcome_bonus(session, user) -> int:
    hours = gf(session, "ct_new_player_bonus_hours", 0)
    amt = ME.reward_hop(hours, 0, hourly_income(user), gf(session, "ct_floor_hourly", 60000), 0, gf(session, "ct_reward_max", 0))
    return amt if _bonus_once(session, user, "welcome", "1", amt) else 0


# ---------------------------------------------------------------------------
# جدول‌ها
# ---------------------------------------------------------------------------
def leaderboard(session, chat_id=None, limit=None, now=None) -> list:
    from sqlalchemy import func
    season = current_season(session, now)
    q = (session.query(MD.MissionClaim.user_id, func.sum(MD.MissionClaim.points).label("pts"))
         .filter(MD.MissionClaim.season_id == season.id))
    if chat_id is not None:
        q = q.filter(MD.MissionClaim.chat_id == chat_id)
    rows = q.group_by(MD.MissionClaim.user_id).order_by(func.sum(MD.MissionClaim.points).desc()).limit(limit or gi(session, "ct_board_size", 10)).all()
    out = []
    for uid, pts in rows:
        u = session.get(db.User, uid)
        out.append((u.display_name() if u else str(uid), int(pts or 0), uid))
    return out


@_txn
def settle_seasons(session, now=None) -> list:
    """پایانِ فصل‌های تموم‌شده: پاداشِ نفراتِ برتر (Idempotent). -> لیستِ (uid, rank, hop, chat?)"""
    now = now or utcnow()
    from sqlalchemy import func
    paid = []
    for s in session.query(MD.MissionSeason).filter(MD.MissionSeason.settled_at.is_(None), MD.MissionSeason.ends_at <= now).all():
        tops = [float(x) for x in gs(session, "ct_season_top_hours", "").split(",") if x.strip()]
        minp = gi(session, "ct_season_min_points", 0)
        rows = (session.query(MD.MissionClaim.user_id, func.sum(MD.MissionClaim.points))
                .filter(MD.MissionClaim.season_id == s.id).group_by(MD.MissionClaim.user_id)
                .order_by(func.sum(MD.MissionClaim.points).desc(), MD.MissionClaim.user_id).all())
        for rank, (uid, pts) in enumerate(rows, 1):
            if rank > len(tops) or (pts or 0) < minp:
                break
            u = session.get(db.User, uid)
            if u is None:
                continue
            amt = ME.reward_hop(tops[rank - 1], 0, hourly_income(u), gf(session, "ct_floor_hourly", 60000), 0, gf(session, "ct_reward_max", 0) * 10)
            if _bonus_once(session, u, "season", f"{s.id}:{rank}", amt):
                paid.append((uid, rank, amt))
        s.settled_at = now
    return paid


# ---------------------------------------------------------------------------
# ادمین
# ---------------------------------------------------------------------------
def _coerce(kind, raw):
    raw = str(raw).strip()
    if kind == "str":
        if not raw:
            raise MissionError("نمی‌تونه خالی باشه.")
        return raw
    if kind == "metric":
        if raw not in MM.METRICS:
            raise MissionError("معیارِ نامعتبر. یکی از: " + ", ".join(MM.METRICS))
        return raw
    if kind.startswith("enum:"):
        if raw not in kind[5:].split("|"):
            raise MissionError("فقط: " + " | ".join(kind[5:].split("|")))
        return raw
    try:
        v = float(raw)
    except ValueError:
        raise MissionError("یه عدد بفرست.")
    if v != v or v < 0 or v in (float("inf"),):
        raise MissionError("عددِ نامعتبر/منفی.")
    return int(v) if kind == "int" else v


@_txn
def admin_create_def(session, title, metric, target, period="daily", tier=1, ref_hours=1.0, abs_hop=0.0, min_level=0):
    title = _coerce("str", title)
    metric = _coerce("metric", metric)
    target = _coerce("int", target)
    if target < 1:
        raise MissionError("تعدادِ لازم حداقل ۱.")
    period = _coerce(DEF_PERIOD, period)
    tier = int(_coerce("int", tier))
    if tier not in (1, 2, 3):
        raise MissionError("رده فقط ۱ تا ۳.")
    d = MD.MissionDef(title=title, metric=metric, target=target, period=period, tier=tier, reward_ref_hours=float(ref_hours),
                      reward_hop_abs=float(abs_hop), min_level=int(min_level), sort=0, enabled=True)
    session.add(d)
    session.flush()
    return d


DEF_PERIOD = "enum:daily|weekly|once"


@_txn
def admin_set_def(session, def_id, key, raw):
    d = session.get(MD.MissionDef, def_id)
    if d is None or d.deleted:
        raise MissionError("مأموریت پیدا نشد.")
    if key not in MD.DEF_KIND:
        raise MissionError("فیلدِ نامعتبر.")
    v = _coerce(MD.DEF_KIND[key], raw)
    if key == "target" and v < 1:
        raise MissionError("حداقل ۱.")
    if key == "tier" and v not in (1, 2, 3):
        raise MissionError("رده فقط ۱ تا ۳.")
    setattr(d, key, v)
    return d


@_txn
def admin_toggle_def(session, def_id):
    d = session.get(MD.MissionDef, def_id)
    if d is None or d.deleted:
        raise MissionError("مأموریت پیدا نشد.")
    d.enabled = not d.enabled
    return d


@_txn
def admin_delete_def(session, def_id):
    d = session.get(MD.MissionDef, def_id)
    if d is None:
        raise MissionError("مأموریت پیدا نشد.")
    d.deleted = True
    d.enabled = False
    return d


STARTER_PACK = [
    # عنوان، معیار، تعداد، دوره، رده، ساعتِ درآمد
    ("🎲 یه دورِ کازینو بازی کن", "casino_played", 1, "once", 1, 3),
    ("👋 تو یه قرعه‌کشی شرکت کن", "lottery_joined", 1, "once", 1, 3),
    ("🥷 تو یه سرقتِ تیمی شرکت کن", "heist_played", 1, "once", 2, 6),
    ("🎲 ۳ دورِ کازینو بازی کن", "casino_played", 3, "daily", 1, 1),
    ("🔢 یه بازیِ حدس عدد انجام بده", "guess_played", 1, "daily", 1, 1),
    ("🎟 تو قرعه‌کشی شرکت کن", "lottery_joined", 1, "daily", 1, 1),
    ("📝 یه پست تو میاوی بذار", "myawy_posts", 1, "daily", 2, 2),
    ("❤️ ۳ پست رو لایک کن", "myawy_likes", 3, "daily", 2, 1.5),
    ("📦 یه قاچاقِ موفق انجام بده", "smuggle_success", 1, "daily", 3, 4),
    ("⚔️ تو جنگ هاپویی ۲ بار حمله کن", "war_attacks", 2, "daily", 3, 3),
    ("🥷 یه سرقتِ تیمیِ موفق", "heist_success", 1, "weekly", 3, 12),
    ("🎲 ۲۰ دورِ کازینو", "casino_played", 20, "weekly", 2, 8),
    ("🧠 ۳ بازیِ ماستر‌مایند/نبردِ دریایی", "mind_played", 3, "weekly", 2, 8),
]


@_txn
def admin_install_starter_pack(session):
    n = 0
    for title, metric, target, period, tier, hours in STARTER_PACK:
        if session.query(MD.MissionDef).filter_by(title=title, deleted=False).first():
            continue
        session.add(MD.MissionDef(title=title, metric=metric, target=target, period=period, tier=tier, reward_ref_hours=hours,
                                  reward_hop_abs=0, min_level=0, sort=n, enabled=True))
        n += 1
    return n


def validate_cfg(key, raw):
    raw = str(raw).strip()
    if key not in MD.CFG_LABEL:
        raise MissionError("کلیدِ ناشناخته.")
    if key in MD.MSG:
        if not raw:
            raise MissionError("نمی‌تونه خالی باشه.")
        return raw
    if key in ("ct_streak_steps", "ct_season_points_per_tier", "ct_season_top_hours"):
        if key == "ct_streak_steps":
            if raw and not ME.parse_steps(raw):
                raise MissionError("فرمت: روز:ضریب با کاما (مثلا 3:1.1,7:1.25)")
        else:
            for x in raw.split(","):
                try:
                    if float(x) < 0:
                        raise ValueError
                except ValueError:
                    raise MissionError("فقط عددهای نامنفی با کاما.")
        return raw
    try:
        v = float(raw)
    except ValueError:
        raise MissionError("یه عدد بفرست.")
    if v != v or v < 0:
        raise MissionError("عددِ نامعتبر/منفی.")
    if key in ("ct_enabled",) and v not in (0, 1):
        raise MissionError("فقط ۰ یا ۱.")
    if key == "ct_season_days" and v < 1:
        raise MissionError("حداقل ۱ روز.")
    return str(int(v)) if v == int(v) else str(v)


@_txn
def admin_set_cfg(session, key, raw):
    v = validate_cfg(key, raw)
    db.cfg_set(session, key, v)
    return v
