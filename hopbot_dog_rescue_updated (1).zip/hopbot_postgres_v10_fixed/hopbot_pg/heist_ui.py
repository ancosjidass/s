# -*- coding: utf-8 -*-
"""
رابطِ تلگرامیِ «دزدی تیمی هاپویی» (فقط گروه، فقط Inline Keyboard، تا حدِ ممکن Edit روی همون پیام).

امنیت: callback_data فقط «شماره‌ی پنل + اکشن» داره (ht:<panel>:<action>[:arg]). مالک/گروه/عملیاتِ پنل از
جدولِ heist_panels سمتِ سرور خونده می‌شه و برای هر کلیک User/Chat/Operation/Phase/Role/Status/Membership
دوباره چک می‌شه (heist_svc.authorize). هیچ‌وقت به ظاهرِ دکمه‌ها اعتماد نمی‌کنیم.
"""
import asyncio
import logging

import db
import heist_db as H
import heist_engine as E
import heist_svc as S
from heist_svc import HeistError, HeistEnded

logger = logging.getLogger(__name__)

NUM = {1: "1️⃣", 2: "2️⃣", 3: "3️⃣", 4: "4️⃣"}
PHASE_FA = {E.SPY: "🕵️ جاسوسی", E.SAFE: "🔓 صندوق‌دار", E.CARRIER: "📦 جابه‌جایی", E.DRIVER: "🚗 رانندگی"}


# ---------------------------------------------------------------------------
# کمک‌ها
# ---------------------------------------------------------------------------
def _markup(rows):
    from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb
    return Kb([[Btn(label, callback_data=data) for label, data in row] for row in rows]) if rows else None


def _cb(pid, action, *args):
    return ":".join(["ht", str(pid), action] + [str(a) for a in args])


def _name(m):
    return m.name or str(m.user_id)


async def _edit(bot, chat_id, message_id, text, rows):
    try:
        await bot.edit_message_text(chat_id=chat_id, message_id=message_id, text=text, reply_markup=_markup(rows))
        return True
    except Exception as e:
        if "not modified" in str(e).lower():
            return True
        logger.warning("heist edit failed: %s", e)
        return False


# ---------------------------------------------------------------------------
# ساختِ نماها (خروجی: متن + ردیف‌های (برچسب, callback_data))
# ---------------------------------------------------------------------------
def main_view(session, user, pn):
    p = S.get_player(session, user.telegram_id)
    now = S.utcnow()
    lines = ["🥷 دزدی تیمی هاپویی", "━━━━━━━━━━━━━━", "", f"⭐ XP: {E.fmt_int(S.unlock_xp(session, p))}"]
    if not S.gi(session, "heist_unlock_lifetime_xp", 1):
        lines[-1] += " (XPِ باقی‌مانده)"
    else:
        lines.append(f"🔁 XPِ قابل تبدیل به مهارت: {E.fmt_int(p.xp)}")
    lines += ["", "📊 مهارت‌ها:"]
    for r in E.ROLES:
        lines.append(f"{E.ROLE_EMOJI[r]} {E.ROLE_FA[r]}: {S.skill_of(p, r)}")
    cds = (session.query(H.HeistCooldown, H.HeistLocation)
           .join(H.HeistLocation, H.HeistLocation.id == H.HeistCooldown.location_id)
           .filter(H.HeistCooldown.user_id == user.telegram_id, H.HeistCooldown.until > now).all())
    if cds:
        lines += ["", "⏳ کول‌داون:"]
        lines += [f"{loc.name}: {E.fmt_long((cd.until - now).total_seconds())}" for cd, loc in cds]
    rows = [[("🥷 شروع سرقت", _cb(pn.id, "go")), ("📈 ارتقای مهارت‌ها", _cb(pn.id, "sk"))],
            [("📜 تاریخچه سرقت", _cb(pn.id, "hist")), ("❌ خروج", _cb(pn.id, "exit"))]]
    return "\n".join(lines), rows


def locations_view(session, user, pn):
    now = S.utcnow()
    locs = S.list_locations(session)
    lines = ["🗺️ مکان‌های سرقت", "━━━━━━━━━━━━━━", ""]
    rows = []
    if not locs:
        lines.append("هنوز هیچ مکانی توسط ادمین ساخته نشده.")
    for loc in locs:
        st = S.location_state(session, user, loc, now)
        s = st["state"]
        if s == "available":
            label, data, line = f"🟢 {loc.name}", _cb(pn.id, "loc", loc.id), f"🟢 {loc.name} — آماده"
        elif s == "locked":
            label, data = f"🔴 🔒 {loc.name} — {E.fmt_int(loc.req_xp)} XP", _cb(pn.id, "lk", loc.id)
            line = f"🔒 {loc.name}\n⭐ نیازمند {E.fmt_int(loc.req_xp)} XP\n❌ قفل"
        elif s == "cooldown":
            label, data = f"⏳ {loc.name} — {E.fmt_long(st['remain'])}", _cb(pn.id, "cd", loc.id)
            line = f"🔴 {loc.name}\n⏳ {E.fmt_long(st['remain'])}"
        elif s == "lobby":
            label, data, line = f"🟠 {loc.name} — در لابی", _cb(pn.id, "st"), f"🟠 {loc.name} — در لابی"
        elif s == "progress":
            label, data, line = f"🟡 {loc.name} — در حال انجام", _cb(pn.id, "st"), f"🟡 {loc.name} — در حال انجام"
        else:
            label, data, line = f"🚔 {loc.name} — زندان", _cb(pn.id, "pr"), f"🚔 {loc.name} — زندان"
        extra = f"   🏷 {loc.tier} | 🎁 {E.fmt_int(loc.success_xp)} XP | ⏳ {E.fmt_duration_fa(loc.cooldown_minutes)} | 🚨 {E.fmt_clock(loc.police_seconds)}"
        lines += [line, extra, ""]
        rows.append([(label, data)])
    rows.append([("🔙 بازگشت", _cb(pn.id, "main"))])
    return "\n".join(lines), rows


def skills_view(session, user, pn):
    p = S.get_player(session, user.telegram_id)
    rate = max(1, S.gi(session, "heist_xp_per_skill_point", 5))
    lines = ["🧠 مهارت‌ها", ""]
    rows = []
    for r in E.ROLES:
        lo, hi = S.skill_caps(session, r)
        cap = f" / {hi}" if hi else ""
        lines.append(f"{E.ROLE_EMOJI[r]} {E.ROLE_FA[r]}: {S.skill_of(p, r)}{cap}")
        rows.append([(f"➖ {E.ROLE_EMOJI[r]} {E.ROLE_FA[r]}", _cb(pn.id, "s-", r)), (f"➕ {E.ROLE_EMOJI[r]} {E.ROLE_FA[r]}", _cb(pn.id, "s+", r))])
    lines += ["", f"⭐ XP: {E.fmt_int(p.xp)}", f"🧠 امتیازِ قابل‌استفاده: {S.points_available(session, p)}",
              f"🎁 امتیازِ آزاد (بعد از ➖): {p.free_points or 0}", f"🔁 هر {rate} XP = ۱ امتیاز",
              "", "ℹ️ مهارتِ جدید فقط برای لابی‌هایی اعمال می‌شه که از این به بعد وارد می‌شی؛ اگه همین الان تو لابی هستی باید خارج شی و دوباره بپیوندی."]
    rows.append([("🔙 بازگشت", _cb(pn.id, "main"))])
    return "\n".join(lines), rows


def history_view(session, user, pn):
    hist = S.history(session, user.telegram_id)
    lines = ["📜 تاریخچه سرقت", ""]
    if not hist:
        lines.append("هنوز سرقتی انجام ندادی.")
    for h in hist:
        mark = "✅" if h["result"] == "success" else "❌"
        when = h["at"].strftime("%Y-%m-%d %H:%M") if h["at"] else "-"
        why = "" if h["result"] == "success" else f" | دلیل: {_reason_text(session, h['reason'])}"
        lines.append(f"{mark} {h['location']} | 💰 {E.fmt_int(h['hop'])} | ⭐ +{E.fmt_int(h['xp'])} | {when}{why}")
        lines.append("   👥 " + "، ".join(h["team"]))
    return "\n".join(lines), [[("🔙 بازگشت", _cb(pn.id, "main"))]]


def _reason_text(session, reason):
    key = {"police": "reason_police", "leave": "reason_leave"}.get(reason, "reason_failed")
    return S.msg(session, key)


def _op_header(session, op):
    cfg = S._cfg(op)
    name = cfg.get("location_name") or (session.get(H.HeistLocation, op.location_id).name)
    return name


def lobby_view(session, op, pn):
    loc = session.get(H.HeistLocation, op.location_id)
    members = S._members(session, op.id)
    by_slot = {m.slot: m for m in members}
    lines = ["🥷 سرقت تیمی", "━━━━━━━━━━━━━━", "", f"🏪 مکان:\n{loc.name}", "", "👥 تیم:", ""]
    for slot in range(1, E.TEAM_SIZE + 1):
        m = by_slot.get(slot)
        if m:
            crown = "👑 " if m.user_id == op.creator_id else ""
            lines += [f"{NUM[slot]} {crown}{_name(m)}", E.role_label(m.role), f"🧠 Skill: {m.skill}", ""]
        else:
            lines += [f"{NUM[slot]} خالی", f"({E.role_label(E.role_of_slot(slot))})", ""]
    left = E.TEAM_SIZE - len(members)
    if left > 0:
        lines.append(f"⏳ منتظر {left} نفر دیگه...")
    else:
        lines.append("✅ تیم کامل شد!")
    rows = [[("👥 پیوستن", _cb(pn.id, "join")), ("❌ خروج", _cb(pn.id, "leave")), ("📊 وضعیت", _cb(pn.id, "status"))]]
    if left == 0 and not loc.auto_start:
        rows.append([("🚨 شروع عملیات", _cb(pn.id, "start"))])
    rows.append([("🗑 لغو لابی (سازنده)", _cb(pn.id, "cancel"))])
    return "\n".join(lines), rows


def _active_header(session, op, now):
    cfg = S._cfg(op)
    members = {m.role: m for m in S._members(session, op.id)}
    role = E.PHASE_ROLE[op.status]
    items = session.query(H.HeistOpItem).filter_by(op_id=op.id).all()
    found = [i for i in items if i.found]
    lines = ["🚨 پلیس در راه است!", "", f"⏳ زمان باقی‌مانده:\n{E.fmt_clock(S.police_remaining(op, now))}", "",
             f"🏪 مکان: {cfg.get('location_name', '')}",
             f"{PHASE_FA[op.status]}", f"👤 نوبت: {_name(members[role])} ({E.role_label(role)})", "",
             f"🎒 آیتم‌های پیدا شده:\n{len(found)}/{len(items)}", f"💰 ارزش فعلی:\n{E.fmt_int(sum(i.value for i in found))}"]
    team = "  ".join(f"{E.ROLE_EMOJI[r]}{members[r].skill}" for r in E.ROLES if r in members)
    lines += ["", f"🧠 مهارت‌ها: {team}"]
    return lines


def _common_rows(pn):
    return [[("📊 وضعیت", _cb(pn.id, "status")), ("❌ خروج از سرقت", _cb(pn.id, "leave"))]]


def active_view(session, op, pn):
    now = S.utcnow()
    cfg = S._cfg(op)
    pd = S._pd(op)
    lines = _active_header(session, op, now)
    rows = []
    if op.status == E.SPY:
        pal = cfg["colors"]
        lines += ["", f"🎯 توالیِ این مرحله ({len(pd['seq'])} رنگ، از چپ به راست):", E.render_colors(pd["seq"], pal), "",
                  "✍️ انتخاب‌های تو (نمایشِ برعکس):", E.reverse_display(pd["input"], pal) if pd["input"] else "—",
                  f"({len(pd['input'])}/{len(pd['seq'])})", "", S.msg(session, "reverse_hint")]
        for i in range(0, len(pal), 4):
            rows.append([(c, _cb(pn.id, "p", i + j)) for j, c in enumerate(pal[i:i + 4])])
        rows.append([("⌫ پاک کردن آخرین رنگ", _cb(pn.id, "bs")), ("✅ تأیید", _cb(pn.id, "ok"))])
    elif op.status == E.SAFE:
        cells = int(cfg["loc"]["grid_cells"])
        items = {i.cell: i for i in session.query(H.HeistOpItem).filter_by(op_id=op.id).all()}
        opened = set(pd.get("opened", []))
        btns = []
        for c in range(cells):
            if c in opened:
                label = "🎁" if (c in items and items[c].found) else "⬜"
            else:
                label = str(c + 1)
            btns.append((label, _cb(pn.id, "c", c)))
        for i in range(0, len(btns), E.GRID_COLS):
            rows.append(btns[i:i + E.GRID_COLS])
        last = next((items[c] for c in reversed(pd.get("opened", [])) if c in items), None)
        found_lines = [f"🎁 {i.name} — {E.fmt_int(i.value)}" for i in sorted(items.values(), key=lambda x: x.cell) if i.found]
        lines += [""] + (found_lines or ["هنوز چیزی پیدا نشده."])
        rows.append([("✅ کافیه", _cb(pn.id, "enough"))])
    elif op.status == E.CARRIER:
        items = {i.id: i for i in session.query(H.HeistOpItem).filter_by(op_id=op.id).all()}
        lines.append("")
        for n, iid in enumerate(pd.get("queue", [])):
            it = items[iid]
            if it.loaded:
                lines.append(f"✅ {it.name} — منتقل شد")
            elif pd.get("loading") == iid:
                left = max(0, (op.phase_ready_at - now).total_seconds()) if op.phase_ready_at else 0
                lines.append(f"⏳ {it.name} — {E.fmt_clock(left)} مونده")
            else:
                lines.append(f"▫️ {it.name} — در انتظار")
        if pd.get("loading") is None and pd.get("idx", 0) < len(pd.get("queue", [])):
            rows.append([(f"📦 شروع انتقال آیتم {pd['idx'] + 1}", _cb(pn.id, "ci"))])
    elif op.status == E.DRIVER:
        if pd.get("driving") and op.phase_ready_at:
            lines += ["", f"🚗 ماشین در حال حرکته... {E.fmt_clock(max(0, (op.phase_ready_at - now).total_seconds()))} تا فرار"]
        else:
            lines += ["", "🚗 همه‌ی آیتم‌ها تو ماشینن؛ راننده باید حرکت کنه!"]
            rows.append([("🚗 حرکت!", _cb(pn.id, "dr"))])
    rows += _common_rows(pn)
    return "\n".join(lines), rows


def report_view(session, op):
    cfg = S._cfg(op)
    loc = cfg.get("loc", {})
    members = S._members(session, op.id)
    rewards = {r.user_id: r for r in session.query(H.HeistReward).filter_by(op_id=op.id).all()}
    name = cfg.get("location_name", "")
    if op.result == "success":
        lost = session.query(H.HeistOpItem).filter_by(op_id=op.id, lost=True).count()
        lines = [S.msg(session, "success_title"), "", f"🏪 مکان:\n{name}", "", f"💰 ارزش کل:\n{E.fmt_int(op.total_loot)} Hop", "",
                 f"👥 سهم هر نفر:\n{E.fmt_int(op.per_member)} Hop", "", f"⭐ XP هر نفر:\n+{E.fmt_int(loc.get('success_xp', 0))}"]
        if lost:
            lines += ["", f"💥 آیتم‌های از دست رفته در مسیر: {lost}"]
        lines += ["", "👥 اعضای تیم:", ""]
        for m in members:
            r = rewards.get(m.user_id)
            lines.append(f"{NUM[m.slot]} {_name(m)}\n+{E.fmt_int(r.hop if r else 0)}")
    else:
        lines = [S.msg(session, "fail_title"), "", f"🏪 مکان:\n{name}", "", f"❌ دلیل:\n{_reason_text(session, op.fail_reason)}"]
        if int(loc.get("jail_minutes", 0) or 0) > 0:
            bail = float(loc.get("bail_amount", 0) or 0)
            lines += ["", S.msg(session, "jail_line"), "", f"⏱️ مدت:\n{E.fmt_duration_fa(loc['jail_minutes'])}", "",
                      "💰 وثیقه:\n" + ("قابل پرداخت نیست" if bail < 0 else f"{E.fmt_int(bail)} Hop")]
        lines += ["", "⭐ XP:\n0"]
    return "\n".join(lines), []


def op_view(session, op, pn):
    if op.status in (E.RECRUITING, E.FULL):
        return lobby_view(session, op, pn)
    if op.status in E.ACTIVE_PHASES:
        return active_view(session, op, pn)
    if op.status == E.SETTLED:
        return report_view(session, op)
    return "🗑 این سرقت لغو شد.", []


# ---------------------------------------------------------------------------
# تریگر در گروه
# ---------------------------------------------------------------------------
async def handle_heist_trigger(update, context):
    chat = update.effective_chat
    if chat.type == "private":
        await update.message.reply_text("🥷 دزدیِ تیمی فقط توی گروه کار می‌کنه.")
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if not S.gi(session, "heist_enabled", 1):
            session.commit()
            await update.message.reply_text("🥷 بخش سرقت تیمی فعلاً خاموشه.")
            return
        pn = S.panel_create(session, chat.id, user.telegram_id)
        text, rows = main_view(session, user, pn)
        session.commit()
        sent = await update.message.reply_text(text, reply_markup=_markup(rows))
        S.panel_set_message(session, pn.id, sent.message_id)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# Callback Router
# ---------------------------------------------------------------------------
OWNER_ACTIONS = {"main", "go", "sk", "s+", "s-", "hist", "exit", "loc", "lk", "cd", "pr", "st"}


def dispatch(session, tg_user, chat_id, message_id, data):
    """منطقِ کاملِ یه کلیک (همگام). -> (toast|None, alert(bool), view|None, notify_chat_after|None)
    view = (text, rows) یا None (یعنی پیام تغییری نکنه)."""
    parts = data.split(":")
    if len(parts) < 3 or parts[0] != "ht" or not parts[1].isdigit():
        return "دکمه نامعتبره.", True, None
    pid, action, args = int(parts[1]), parts[2], parts[3:]
    pn = S.panel_get(session, pid)
    if pn is None or pn.chat_id != chat_id or (pn.message_id and pn.message_id != message_id):
        return "این پنل دیگه معتبر نیست.", True, None
    user = db.get_or_create_user(session, tg_user)
    uid = user.telegram_id

    # ---- ۱) پنلِ شخصیِ سازنده (قبل از ساختِ لابی): فقط خودش ----
    if pn.op_id is None:
        if uid != pn.owner_id:
            return S.msg(session, "not_your_panel"), True, None
        if action not in OWNER_ACTIONS:
            return "دکمه نامعتبره.", True, None
        if action == "exit":
            return None, False, ("🥷 پنل بسته شد.", [])
        gate = _gate(session, user)
        if gate:
            return gate, True, None
        return _owner_action(session, user, pn, chat_id, action, args)

    # ---- ۲) پنلِ عملیات ----
    if action in OWNER_ACTIONS:
        return "این پنل الان یه سرقتِ فعاله.", False, None
    if action != "leave":
        gate = _gate(session, user)
        if gate:
            return gate, True, None
    return _op_action(session, user, pn, chat_id, action, args)


def _gate(session, user):
    if not S.gi(session, "heist_enabled", 1):
        return "🥷 بخش سرقت تیمی فعلاً خاموشه."
    return db.check_module_level(session, user, "heist")


def _owner_action(session, user, pn, chat_id, action, args):
    uid = user.telegram_id
    if action == "main":
        return None, False, main_view(session, user, pn)
    if action == "go":
        return None, False, locations_view(session, user, pn)
    if action == "sk":
        return None, False, skills_view(session, user, pn)
    if action in ("s+", "s-"):
        role = args[0] if args else ""
        try:
            (S.skill_add if action == "s+" else S.skill_sub)(session, uid, role)
        except HeistError as e:
            return str(e), True, None
        return None, False, skills_view(session, user, pn)
    if action == "hist":
        return None, False, history_view(session, user, pn)
    if action == "lk":
        return S.msg(session, "locked_join"), True, None
    if action == "pr":
        return "🚔 تو زندانی هستی.", True, None
    if action == "st":
        return "این مکان الان درگیره.", False, None
    if action == "cd":
        loc = session.get(H.HeistLocation, int(args[0]))
        st = S.location_state(session, user, loc) if loc else {}
        return S.msg(session, "cooldown_join", remain=E.fmt_long(st.get("remain", 0))), True, None
    if action == "loc":
        try:
            op = S.create_lobby(session, user, chat_id, int(args[0]), panel_id=pn.id)
        except HeistError as e:
            return str(e), True, None
        pn = S.panel_get(session, pn.id)
        return None, False, lobby_view(session, op, pn)
    return "دکمه نامعتبره.", True, None


def _op_action(session, user, pn, chat_id, action, args):
    uid = user.telegram_id
    op_id = pn.op_id
    try:
        op = session.get(H.HeistOperation, op_id)
        if action == "join":
            op, _started = S.join_lobby(session, op_id, user, chat_id)
        elif action == "leave":
            res = S.leave_op(session, op_id, uid)
            op = session.get(H.HeistOperation, op_id)
            if res == "cancelled":
                return None, False, ("🗑 لابی لغو شد (سازنده خارج شد).", [])
        elif action == "status":
            op = S.refresh(session, op_id, chat_id)
        elif action == "cancel":
            if op.creator_id != uid:
                return "فقط سازنده می‌تونه لابی رو لغو کنه.", True, None
            if op.status not in (E.RECRUITING, E.FULL):
                return "بعد از شروع نمی‌شه لغو کرد.", True, None
            S.leave_op(session, op_id, uid)
            return None, False, ("🗑 لابی لغو شد.", [])
        elif action == "start":
            op = S.manual_start(session, op_id, uid)
        elif action == "p":
            op = S.spy_pick(session, op_id, uid, chat_id, int(args[0]))
        elif action == "bs":
            op = S.spy_backspace(session, op_id, uid, chat_id)
        elif action == "ok":
            op, ok = S.spy_confirm(session, op_id, uid, chat_id)
            if not ok:
                return "❌ اشتباه بود! ورودی پاک شد و یه توالیِ جدید ساخته شد.", False, op_view(session, op, pn)
        elif action == "c":
            op, it, _fin = S.safe_open(session, op_id, uid, chat_id, int(args[0]))
            toast = f"🎁 آیتم پیدا شد: {it.name} — {E.fmt_int(it.value)}" if it is not None else "⬜ این خونه خالی بود."
            return toast, False, op_view(session, op, pn)
        elif action == "enough":
            op = S.safe_enough(session, op_id, uid, chat_id)
        elif action == "ci":
            op = S.carrier_start_item(session, op_id, uid, chat_id)
        elif action == "dr":
            op = S.driver_start(session, op_id, uid, chat_id)
        else:
            return "دکمه نامعتبره.", True, None
    except HeistEnded:
        op = session.get(H.HeistOperation, op_id)
        return None, False, op_view(session, op, pn)
    except HeistError as e:
        return str(e), True, None
    op = session.get(H.HeistOperation, op_id)
    return None, False, op_view(session, op, pn)


async def heist_callback_router(update, context):
    q = update.callback_query
    if not (q.data or "").startswith("ht:"):
        return False
    session = db.get_session()
    try:
        toast, alert, view = dispatch(session, q.from_user, q.message.chat_id, q.message.message_id, q.data)
        session.commit()
    except Exception:
        session.rollback()
        logger.exception("heist callback failed")
        toast, alert, view = "⚠️ خطایی پیش اومد؛ دوباره امتحان کن.", True, None
    finally:
        session.close()
    try:
        await q.answer(toast or None, show_alert=bool(alert))
    except Exception:
        pass
    if view is not None:
        text, rows = view
        await _edit(context.bot, q.message.chat_id, q.message.message_id, text, rows)
    return True


# ---------------------------------------------------------------------------
# Scheduler: وضعیتِ عملیات‌ها رو جلو می‌بره و پنل‌ها رو تازه می‌کنه (بعد از ری‌استارت هم ادامه می‌ده)
# ---------------------------------------------------------------------------
async def heist_tick_job(context):
    events = await asyncio.to_thread(S.run_tick)
    for ev in events:
        try:
            session = db.get_session()
            try:
                op = session.get(H.HeistOperation, ev["op_id"])
                pn = session.get(H.HeistPanel, op.panel_id) if op and op.panel_id else None
                if not pn or not pn.message_id:
                    continue
                text, rows = op_view(session, op, pn)
                chat_id, mid = pn.chat_id, pn.message_id
            finally:
                session.close()
            await _edit(context.bot, chat_id, mid, text, rows)
        except Exception:
            logger.exception("heist notify failed")
