# -*- coding: utf-8 -*-
"""
کد جایزه‌ی هاپویی 🎁 - با تایپِ «کد جایزه هاپویی» فعال می‌شه. مالک از پنل کد
می‌سازه (متنِ کد + مقدارِ پاداش + تاریخِ انقضای اختیاری)؛ هر پلیر فقط یه‌بار
می‌تونه هر کد رو وارد کنه (ولی خودِ کد رو همه می‌تونن استفاده کنن، تا وقتی
منقضی نشده یا مالک دستی حذفش نکرده)."""
import datetime

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

import db
import keyboards as kb
from handlers import fmt, send_response, _verify_panel_owner, ask_for_input, is_reply_to_prompt


async def handle_redeem_trigger(update, context):
    await show_redeem_home(update, context)


async def show_redeem_home(update, context):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        session.commit()
        await send_response(
            update, "🎁 کدِ جایزه‌ی هاپویی\n\nاگه یه کدِ جایزه داری، وارد کن:",
            kb.redeem_home_keyboard(user.telegram_id),
        )
    finally:
        session.close()


async def cb_redeem_home(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_redeem_home(update, context)


async def cb_redeem_start(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(update, context, "🎁 کدِ جایزه رو بفرست:", {"type": "redeem_code_input"}, "redeem_awaiting")


async def redeem_awaiting_handler(update, context):
    state = context.user_data.get("redeem_awaiting")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return
    text = (update.message.text or "").strip()
    context.user_data.pop("redeem_awaiting", None)
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        norm = text.lower()
        code_row = None
        for c in session.query(db.RedeemCode).filter_by(is_active=True).all():
            if c.code.strip().lower() == norm:
                code_row = c
                break
        if not code_row:
            session.commit()
            await update.message.reply_text("❌ همچین کدِ جایزه‌ای معتبر نیست.")
            return
        nowt = datetime.datetime.utcnow()
        if code_row.expires_at and code_row.expires_at < nowt:
            session.commit()
            await update.message.reply_text("❌ این کد منقضی شده.")
            return
        already = session.query(db.RedeemCodeUse).filter_by(code_id=code_row.id, user_id=user.telegram_id).first()
        if already:
            session.commit()
            await update.message.reply_text("❌ قبلاً این کد رو استفاده کردی.")
            return
        session.commit()
        await update.message.reply_text(
            f"🎁 کدِ «{code_row.code}» معتبره - {fmt(code_row.reward_points)} 🪙 جایزه داره.\nمطمئنی می‌خوای واردش کنی؟",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("✅ بله", callback_data=f"redeem_confirm:{code_row.id}:{user.telegram_id}"),
                InlineKeyboardButton("❌ خیر", callback_data=f"redeem_cancel:{user.telegram_id}"),
            ]]),
        )
    finally:
        session.close()


async def cb_redeem_confirm(update, context):
    _, code_id, owner_id = update.callback_query.data.split(":")
    code_id, owner_id = int(code_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        code_row = session.get(db.RedeemCode, code_id)
        if not code_row or not code_row.is_active:
            session.commit()
            await update.callback_query.answer("این کد دیگه معتبر نیست.", show_alert=True)
            return
        nowt = datetime.datetime.utcnow()
        if code_row.expires_at and code_row.expires_at < nowt:
            session.commit()
            await update.callback_query.answer("این کد منقضی شده.", show_alert=True)
            return
        already = session.query(db.RedeemCodeUse).filter_by(code_id=code_row.id, user_id=owner_id).first()
        if already:
            session.commit()
            await update.callback_query.answer("قبلاً این کد رو استفاده کردی.", show_alert=True)
            return
        user = session.get(db.User, owner_id)
        if not user:
            user = db.User(telegram_id=owner_id)
            session.add(user)
        user.hop_points = (user.hop_points or 0) + code_row.reward_points
        session.add(db.RedeemCodeUse(code_id=code_row.id, user_id=owner_id))
        session.commit()
        await update.callback_query.edit_message_text(f"✅ کد وارد شد! {fmt(code_row.reward_points)} 🪙 بهت اضافه شد.")
    finally:
        session.close()


async def cb_redeem_cancel(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await update.callback_query.edit_message_text("لغو شد.")


REDEEM_PREFIX_MAP = {
    "redeem_home": cb_redeem_home,
    "redeem_start": cb_redeem_start,
    "redeem_confirm": cb_redeem_confirm,
    "redeem_cancel": cb_redeem_cancel,
}


async def redeem_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = REDEEM_PREFIX_MAP.get(prefix)
    if not handler:
        return False
    await handler(update, context)
    return True
