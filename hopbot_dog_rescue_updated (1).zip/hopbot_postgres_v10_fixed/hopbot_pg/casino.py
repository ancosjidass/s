# -*- coding: utf-8 -*-
"""
کازینو هاپویی 🎰
با تایپ «کازینو هاپویی» در گروه فعال می‌شه. شامل ۶ بازی:
🎲 تاس (در برابر «خانه» / شانس)، 🎳 بولینگ، 🎯 دارت، 🏀 بسکتبال، ⚽ فوتبال،
🎰 گردونه شانس (اسلات‌ماشینِ تک‌نفره‌ی خودِ تلگرام؛ قوانینش رو ببین توی
slot_payout_multiplier)
(بولینگ/دارت/بسکتبال/فوتبال بین خودِ بازیکن‌ها رقابتیه - هرکی امتیازش بیشتر باشه
پول بقیه رو می‌بره).

فرض‌های طراحی (چون توضیحات اولیه چندجا چند برداشتی بود):
- فوتبال به‌عنوان بازی پنجم اضافه شده چون قوانینش رو گفتی ولی تو لیست ۴تایی نبود.
- برای تاسِ چندنفره، هر تاس با ۲ عدد (مجموع دو تاس) حساب می‌شه؛ تاسِ تک‌نفره با ۱ تاس.
- در بولینگ/دارت/بسکتبال/فوتبال، «مبلغ ورودی» همه‌ی بازیکن‌ها یکسانه (همونی که
  سازنده‌ی بازی انتخاب کرده) و کل مبلغ جمع‌شده بین برنده(ها) به‌طور مساوی تقسیم می‌شه.
"""
import asyncio
import datetime
import logging

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationHandlerStop

import db
import mentions
from handlers import fmt, send_response, ask_for_input, is_reply_to_prompt, parse_amount, CANCEL_BUTTON_TEXT

logger = logging.getLogger(__name__)

GAME_EMOJI = {"dc": "🎲", "bw": "🎳", "dt": "🎯", "bk": "🏀", "fb": "⚽", "ws": "🎰"}
GAME_NAME = {"dc": "تاس", "bw": "بولینگ", "dt": "دارت", "bk": "بسکتبال", "fb": "فوتبال", "ws": "گردونه شانس"}
MIN_PLAYERS = {"dc": 1, "bw": 2, "dt": 2, "bk": 2, "fb": 2, "ws": 1}
MAX_PLAYERS = {"dc": 4, "bw": 4, "dt": 4, "bk": 2, "fb": 2, "ws": 1}
FIXED_TWO_PLAYERS = {"bk", "fb"}  # این دوتا همیشه دقیقا دونفره‌ن، نیازی به پرسیدن نیست
FIXED_ONE_PLAYER = {"ws"}  # گردونه شانس همیشه تک‌نفره‌ست (بازیکن در برابر خودِ بات)
NO_PLAYER_COUNT_CHOICE = FIXED_TWO_PLAYERS | FIXED_ONE_PLAYER

# قفلِ اختصاصیِ هر دورِ کازینو - جلوی اجرای هم‌زمانِ دو تا اکشن رو یه دور رو
# می‌گیره (مثلا کاربر پشتِ‌هم چند بار رو دکمه‌ی «شروع/پیوستن» می‌زنه، یا نتش
# بده و تلگرام همون کالبک رو دوباره می‌فرسته). بدونِ این قفل، دو تا اجرای
# هم‌زمان می‌تونستن هر دو از یه چکِ یکسان (مثلا «هنوز پیوست نکرده») رد بشن و
# هر دو کاربر رو به‌عنوانِ بازیکنِ جدا اضافه کنن - که باعث می‌شد پولش دوبار کم
# بشه یا حتی با خودش تو یه بازی بیفته. با قفل، دومی صبر می‌کنه تا اولی کامل
# تموم بشه؛ به‌محضِ تمام‌شدنِ اولی، وضعیتِ دور (status) عوض شده و دومی با یه
# پیامِ عادیِ «این بازی دیگه فعال نیست» رد می‌شه، نه با پردازشِ تکراری.
_round_locks = {}


def _get_round_lock(round_id: int) -> asyncio.Lock:
    lock = _round_locks.get(round_id)
    if lock is None:
        lock = asyncio.Lock()
        _round_locks[round_id] = lock
    return lock


def with_round_lock(func):
    """قبل از اجرای این هندلر، قفلِ همون دورِ کازینو رو می‌گیره (بر اساسِ دومین
    بخشِ callback_data که همیشه آی‌دیِ روند - rid - است) تا از پردازشِ هم‌زمانِ
    دو تا اکشن رو یه دور جلوگیری کنه (کاربر پشتِ‌هم چند بار رو دکمه می‌زنه، یا
    نتش بده و تلگرام همون کالبک رو دوباره می‌فرسته). دومی تا تمام‌شدنِ اولی
    صبر می‌کنه و چون تا اون موقع وضعیتِ دور (status) عوض شده، با یه پیامِ عادیِ
    «این بازی دیگه فعال نیست» رد می‌شه - نه با پردازشِ تکراری (که قبلاً باعث
    می‌شد پول دوبار کم بشه یا کاربر با خودش تو یه بازی بیفته)."""
    async def wrapper(update, context):
        try:
            rid = int(update.callback_query.data.split(":")[1])
        except (ValueError, IndexError, AttributeError):
            await func(update, context)
            return
        async with _get_round_lock(rid):
            await func(update, context)
        # بعدِ آزادشدنِ قفل، اگه دور تمام‌شده (resolved/cancelled)، خودِ قفل رو
        # از دیکشنری پاک می‌کنیم که حافظه بی‌نهایت جمع نشه؛ برای دورهایی که
        # هنوز فعالن (setup/lobby) قفل رو نگه می‌داریم چون بازم لازمش داریم.
        session = db.get_session()
        try:
            r = session.get(db.CasinoRound, rid)
            if not r or r.status in ("resolved", "cancelled"):
                _round_locks.pop(rid, None)
        finally:
            session.close()
    return wrapper

# گردونه شانس (🎰) از دایسِ اسلات‌ماشینِ خودِ تلگرام استفاده می‌کنه (مقدارِ خام
# ۱ تا ۶۴ که سه تا حلقه رو کدگذاری می‌کنه) - این‌طوری انیمیشنِ واقعیِ تلگرام
# دیده می‌شه، نه یه RNG جداگونه.
SLOT_SYMBOLS = ["bar", "grapes", "lemon", "seven"]
SLOT_SYMBOL_EMOJI = {"bar": "▬", "grapes": "🍇", "lemon": "🍋", "seven": "7️⃣"}
SLOT_SYMBOL_NAME = {"bar": "بار", "grapes": "انگور", "lemon": "لیمو", "seven": "۷"}
# امتیازِ هر نماد (ری‌بالانسِ بی‌طرف - ضریبِ برگشتیِ میانگین دقیقاً ۱.۰ برابره):
# بار=۰، انگور=۱، لیمو=۲، هفت=۳
SLOT_POINT_VALUE = {"bar": 0, "grapes": 1, "lemon": 2, "seven": 3}


def decode_slot(value: int):
    """مقدارِ خامِ دایسِ 🎰 تلگرام (۱ تا ۶۴) رو به سه نمادِ حلقه‌ها decode می‌کنه."""
    v = value - 1
    r1 = v % 4
    r2 = (v // 4) % 4
    r3 = (v // 16) % 4
    return [SLOT_SYMBOLS[r1], SLOT_SYMBOLS[r2], SLOT_SYMBOLS[r3]]


def slot_payout_multiplier(symbols):
    """
    قانون (بی‌طرف - EV دقیقاً ۱.۰ برابره، نه به‌نفعِ خونه نه به‌نفعِ پلیر):
    مجموعِ امتیازِ سه نماد از ۰ (سه‌تا بار) تا ۹ (سه‌تا هفت) می‌ره:
    - ۰ و ۱ (زیرِ ۲) => ۰ برابر
    - ۲ و ۳ (زیرِ ۴) => ۰.۵ برابر
    - ۴ و ۵ (زیرِ ۶) => ۱ برابر (سرِ به‌سری - نه سود نه ضرر)
    - ۶ و ۷ (زیرِ ۸) => ۱.۵ برابر
    - ۸ و ۹ (۸ به بالا) => ۲ برابر
    رو کلِ ۶۴ حالتِ ممکنِ اسلات‌ماشین، این توزیع دقیقاً متقارنه (۴،۱۶،۲۴،۱۶،۴) و
    میانگینِ ضریبِ برگشتی هم دقیقاً ۱.۰ - یعنی نه پلیر رو مدتِ طولانی می‌بره، نه
    می‌بازه؛ فقط نوسانِ کوتاه‌مدت داره (که طبیعیِ هر بازیِ شانسیه).
    """
    score = sum(SLOT_POINT_VALUE[s] for s in symbols)
    if score < 2:
        return 0.0
    if score < 4:
        return 0.5
    if score < 6:
        return 1.0
    if score < 8:
        return 1.5
    return 2.0

ROLL_DELAY_SECONDS = 3.5  # فاصله‌ی نمایشی بین پرتاب‌های پشت‌سرهم برای هیجان بیشتر


def _max_bet_limit(session):
    limit = db.cfg_get_float(session, "casino_max_bet")
    return limit if limit and limit > 0 else None


def max_bet_exceeded(session, amount) -> bool:
    """True یعنی این مبلغ از سقفِ «حداکثر مبلغِ مجازِ قمار» (تنظیمِ
    casino_max_bet تو پنل) بیشتره. این محدودیت رو همه‌ی بازی‌های کازینو (تاس،
    بولینگ، نبردِ دریایی، حدسِ عدد، رمزیاب، ...) رعایت می‌کنن - چون همه از
    همین تابع استفاده می‌کنن."""
    limit = _max_bet_limit(session)
    return bool(limit and amount > limit)


def _preset_amounts(session):
    raw = db.cfg_get(session, "casino_preset_amounts")
    out = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            out.append(int(part))
    out = out or [100, 500, 1000, 5000, 10000]
    limit = _max_bet_limit(session)
    if limit:
        out = [a for a in out if a <= limit]
    return out


def _timeout_seconds(session):
    return db.cfg_get_int(session, "casino_join_timeout_seconds")


async def _safe_answer(q, *args, **kwargs):
    """جوابِ کالبک رو می‌ده ولی خطای شبکه/تایم‌اوت (سرورِ شلوغ) کلِ هندلر رو نمی‌کشه؛
    وگرنه وسطِ «پیوستن/شروع» بعد از commit کارِ هندلر نیمه‌کاره می‌موند."""
    try:
        await q.answer(*args, **kwargs)
    except Exception as e:
        logger.warning("answerِ کالبک شکست خورد: %s", e)


_EDIT_NOT_FOUND = ("message to edit not found", "message can't be edited", "message to be edited not found")


def _retry_after_seconds(exc):
    ra = getattr(exc, "retry_after", None)
    if ra is None:
        return None
    try:
        return float(ra.total_seconds()) if hasattr(ra, "total_seconds") else float(ra)
    except Exception:
        return 2.0


async def safe_edit_message(context, chat_id, message_id, text, keyboard=None) -> bool:
    """پیامِ لابی/پنل رو مقاوم ادیت می‌کنه. خروجی True یعنی پیام الان همین متن رو نشون می‌ده.

    قبلاً هر خطایی (مثلاً فلود‌کنترلِ تلگرام یا تایم‌اوتِ نتِ سرورِ شلوغ) باعث می‌شد
    یه پیامِ *جدید* بفرستیم و پیامِ قبلی با همون دکمه‌هایِ مرده بمونه؛ بعد کاربر
    رو دکمه‌ی مرده می‌زد و «کازینو فعال نیست» می‌گرفت. الان:
    - «Retry in N seconds» (RetryAfter) رو صبر می‌کنیم و دوباره می‌زنیم
    - تایم‌اوت/خطای شبکه چند بار تکرار می‌شه
    - فقط اگه پیام واقعاً پاک شده باشه پیامِ جدید می‌فرستیم
    - اگه بازم نشد و متنِ نهایی دکمه نداره، حداقل دکمه‌ها رو برمی‌داریم (که
      دکمه‌ی مرده رویِ گروه نمونه)."""
    not_found = False
    for attempt in range(1, 5):
        try:
            await context.bot.edit_message_text(
                chat_id=chat_id, message_id=message_id, text=text, reply_markup=keyboard)
            return True
        except Exception as e:
            err = str(e).lower()
            if "not modified" in err:
                return True
            if any(x in err for x in _EDIT_NOT_FOUND):
                not_found = True
                break
            if attempt == 4:
                logger.warning("ادیتِ پیامِ کازینو شکست خورد: %s", e)
                break
            delay = _retry_after_seconds(e)
            await asyncio.sleep(min(delay, 20.0) + 0.5 if delay is not None else 0.7 * attempt)
    if not_found:
        try:
            await context.bot.send_message(chat_id=chat_id, text=text, reply_markup=keyboard)
            return True
        except Exception as e:
            logger.warning("فرستادنِ پیامِ جایگزینِ کازینو شکست خورد: %s", e)
            return False
    if keyboard is None:
        try:
            await context.bot.edit_message_reply_markup(chat_id=chat_id, message_id=message_id, reply_markup=None)
        except Exception:
            pass
    return False


async def edit_round_message(context, round_obj, text, keyboard=None):
    await safe_edit_message(context, round_obj.chat_id, round_obj.message_id, text, keyboard)


def cancel_text(r, players_count, reason=None):
    """متنِ پیامِ یه کازینوی لغوشده. اگه کسی به‌جز سازنده نیومده باشه: «هیچ هاپویی نیومد»."""
    if players_count <= 1:
        return "❌ هیچ هاپویی نیومد؛ کازینو لغو شد و پولت برگشت داده شد."
    return (f"❌ به تعداد کافی بازیکن نپیوست ({players_count}/{r.target_players})؛ "
            "کازینو لغو شد و مبلغ‌ها برگشت داده شد.")


def score_value(game_type, dice_value):
    """امتیاز قابل‌مقایسه از روی مقدار خام تاس تلگرام.
    برای بولینگ/دارت خودِ عدد ملاکه. برای بسکتبال/فوتبال فقط «گل‌شد/نشد» مهمه
    (بر اساس مستندات API تلگرام؛ اگه در تست واقعی با UI فرق داشت، همین‌جا اصلاحش کن)."""
    if game_type == "bk":
        return 1 if dice_value in (4, 5) else 0
    if game_type == "fb":
        return 1 if dice_value in (3, 4, 5) else 0
    return dice_value


# ---------------------------------------------------------------------------
# ورودی: تایپ «کازینو هاپویی»
# ---------------------------------------------------------------------------

def casino_menu_keyboard(owner_id):
    """این منو قفلِ همون کسیه که «کازینو هاپویی» رو تایپ کرده (owner_id) - قبلاً
    قفل نبود و هرکی تو گروه اول کلیک می‌کرد، صاحبِ عملاً همون پیام می‌شد و
    برای فرستنده‌ی اصلی «این بازی مالِ تو نیست» می‌اومد."""
    return InlineKeyboardMarkup([
        [InlineKeyboardButton(f"{GAME_EMOJI['bw']} بولینگ", callback_data=f"casino_game:bw:{owner_id}"),
         InlineKeyboardButton(f"{GAME_EMOJI['dt']} دارت", callback_data=f"casino_game:dt:{owner_id}")],
        [InlineKeyboardButton(f"{GAME_EMOJI['dc']} تاس", callback_data=f"casino_game:dc:{owner_id}"),
         InlineKeyboardButton(f"{GAME_EMOJI['bk']} بسکتبال", callback_data=f"casino_game:bk:{owner_id}")],
        [InlineKeyboardButton(f"{GAME_EMOJI['fb']} فوتبال", callback_data=f"casino_game:fb:{owner_id}"),
         InlineKeyboardButton(f"{GAME_EMOJI['ws']} گردونه شانس", callback_data=f"casino_game:ws:{owner_id}")],
        [InlineKeyboardButton("🚢 نبرد دریایی", callback_data=f"bship_new:{owner_id}")],
        [InlineKeyboardButton("⚔️ نبرد تن‌به‌تن", callback_data=f"duel_new:{owner_id}")],
        [InlineKeyboardButton("🔢 حدس عدد", callback_data=f"gtn_menu:{owner_id}")],
        [InlineKeyboardButton("🎨 رمزیاب", callback_data=f"mm_new:{owner_id}")],
        [InlineKeyboardButton("🃏 اونو هاپویی", callback_data=f"uno_new:{owner_id}")],
        [InlineKeyboardButton("🔫 رولت روسی", callback_data=f"rr_new:{owner_id}")],
        [InlineKeyboardButton("🕵️ مافیا/گرگینه", callback_data=f"mf_new:{owner_id}")],
        [InlineKeyboardButton("🔄 به‌روزرسانیِ لیستِ لابی‌های جهانی", callback_data=f"casino_menu_refresh:{owner_id}")],
    ])


def menu_text_and_kb(owner_id):
    """متن + دکمه‌هایِ صفحه‌ی اولِ کازینو. بالاش لیستِ لابی‌هایِ جهانیِ بازِ در
    حالِ عضوگیریه (تا ۱۰ تا؛ هرچی بیشتر پر شده‌تر، بالاتر) تا بازیکن بدونه کدوم
    میز و چندنفره رو بزنه که زودتر بازی شروع بشه. هیچ‌وقت نباید منو رو خراب کنه،
    پس هر خطایی تو ساختنِ لیست نادیده گرفته می‌شه."""
    lobbies_txt = ""
    session = db.get_session()
    try:
        import roulette  # دیرهنگام: import چرخه‌ای نشه
        import mafia
        rr_txt = roulette.global_lobbies_text(session)
        mf_txt = mafia.global_lobbies_text(session)
        lobbies_txt = "\n\n".join(t for t in (rr_txt, mf_txt) if t)
    except Exception:
        logger.exception("ساختنِ لیستِ لابی‌های جهانی شکست خورد")
    finally:
        session.close()
    text = "🎰 کازینو هاپویی\n\n"
    if lobbies_txt:
        text += lobbies_txt + "\n\n"
    text += "یکی از بازی‌ها رو انتخاب کن:"
    return text, casino_menu_keyboard(owner_id)



async def _casino_cooldown_remaining_seconds(session, user_id) -> float:
    """اگه این کاربر (نه کلِ گروه - بینِ خودِ بازیکن‌ها) هنوز تو دوره‌ی
    «محدودیتِ فاصله‌ی بینِ کازینوها»یی (تنظیم‌شده از پنلِ مدیریت،
    admin_casino_cfg) باشه، ثانیه‌های باقی‌مونده رو برمی‌گردونه؛ وگرنه ۰.
    یعنی اگه همین الان یه بازی تموم کرده باشه، خودش تا مدتی نمی‌تونه بازیِ
    جدید بسازه یا بهش بپیونده - فرقی نمی‌کنه تو کدوم گروه یا با کی. بقیه‌ی
    گروه (که تو کول‌داون نیستن) آزادانه می‌تونن بازیِ جدید بسازن. «نبردِ دریایی»
    هم جزوِ کازینو حساب می‌شه و مشمولِ همین محدودیته.

    نکته‌ی مهم: فقط بازی‌هایی که واقعاً «resolved» شدن (یعنی تا آخر بازی شد) این
    کول‌داون رو فعال می‌کنن - نه بازی‌ای که فقط ساخته شده و بعد لغو/برگشت داده
    شده (مثلاً کاربر مبلغ رو زد، بعد «برگشت» زد که نوعِ بازی رو عوض کنه). لغوکردن
    نباید محدودیت بذاره؛ فقط واقعاً بازی‌کردن."""
    cooldown_min = db.cfg_get_float(session, "casino_cooldown_minutes")
    if not cooldown_min or cooldown_min <= 0:
        return 0
    last_as_initiator = (
        session.query(db.CasinoRound)
        .filter(db.CasinoRound.initiator_id == user_id, db.CasinoRound.status == "resolved")
        .order_by(db.CasinoRound.ended_at.desc())
        .first()
    )
    last_as_player = (
        session.query(db.CasinoRound)
        .join(db.CasinoPlayer, db.CasinoPlayer.round_id == db.CasinoRound.id)
        .filter(db.CasinoPlayer.user_id == user_id, db.CasinoRound.status == "resolved")
        .order_by(db.CasinoRound.ended_at.desc())
        .first()
    )
    last_bs = (
        session.query(db.BattleshipRound)
        .filter(
            db.BattleshipRound.status == "resolved",
            (db.BattleshipRound.player1_id == user_id) | (db.BattleshipRound.player2_id == user_id),
        )
        .order_by(db.BattleshipRound.ended_at.desc())
        .first()
    )
    last_rr = (
        session.query(db.RouletteRound)
        .join(db.RoulettePlayer, db.RoulettePlayer.round_id == db.RouletteRound.id)
        .filter(db.RoulettePlayer.user_id == user_id, db.RouletteRound.status == "resolved")
        .order_by(db.RouletteRound.ended_at.desc())
        .first()
    )
    candidates = [r.ended_at for r in (last_as_initiator, last_as_player, last_bs, last_rr) if r and r.ended_at]
    if not candidates:
        return 0
    last_ended = max(candidates)
    elapsed = (datetime.datetime.utcnow() - last_ended).total_seconds()
    remaining = cooldown_min * 60 - elapsed
    return max(0.0, remaining)


# پیام‌هایِ دورهایی که به‌صورتِ لحظه‌ای (تو _expire_stale_classic_for_user) لغو شدن؛
# sweep_stale_rounds ادیتشون می‌کنه تا دکمه‌هایِ مرده رویِ گروه نمونه.
_lazy_edits = []


def _expire_stale_classic_for_user(session, user_id):
    """اگه یه کازینوی کلاسیکِ این کاربر (setup/lobby) مهلتش گذشته ولی تایمر/جاروب
    هنوز نرسیده لغوش کنه، همین‌جا (همزمان و بدونِ await) لغو و پول برگردونده
    می‌شه - تا کاربر تو فاصله‌ی «مهلت تموم شد» تا «جاروب لغوش کرد» با پیامِ
    «وسطِ کازینو هستی» گیر نکنه. دورهایی که لابیشون پر شده (داره نتیجه‌گیری
    می‌شه) دست‌نخورده می‌مونن."""
    now = datetime.datetime.utcnow()
    lobby_timeout = _timeout_seconds(session)
    mine = session.query(db.CasinoPlayer.round_id).filter(db.CasinoPlayer.user_id == user_id)
    rows = (
        session.query(db.CasinoRound)
        .filter(db.CasinoRound.status.in_(("setup", "lobby")),
                (db.CasinoRound.initiator_id == user_id) | db.CasinoRound.id.in_(mine))
        .all()
    )
    changed = False
    for r in rows:
        players = session.query(db.CasinoPlayer).filter_by(round_id=r.id).all()
        if r.status == "lobby" and r.target_players and len(players) >= r.target_players:
            continue
        if r.status == "lobby":
            ref, limit = (r.lobby_opened_at or r.created_at), lobby_timeout
        else:
            ref, limit = r.created_at, SETUP_ABANDON_TIMEOUT_SECONDS
        age = (now - r.created_at).total_seconds() if r.created_at else 0
        expired = age >= HARD_CANCEL_SECONDS or (ref and (now - ref).total_seconds() >= limit + 3)
        if not expired:
            continue
        for p in players:
            u = session.get(db.User, p.user_id)
            if u and r.entry_amount:
                u.hop_points += r.entry_amount
        r.status = "cancelled"
        r.ended_at = now
        changed = True
        if r.message_id:
            txt = cancel_text(r, len(players)) if players else "⏳ این کازینو به‌خاطرِ عدمِ فعالیت لغو شد."
            _lazy_edits.append((r.chat_id, r.message_id, txt))
    if changed:
        session.commit()


def _user_has_active_round(session, user_id) -> bool:
    """True یعنی این کاربر همین الان یه بازیِ کازینوییِ نیمه‌کاره (چه کلاسیک چه
    نبردِ دریایی، رولت روسی، اونو ...) داره - چه به‌عنوانِ سازنده، چه بازیکن. برای جلوگیری از باگِ
    «دو تا کازینو با هم استارت کردن» یا «وسطِ کازینوی اول، دومی رو بدونِ فاصله
    شروع کردن» - این چک کاملاً مستقلِ از کول‌داونه (کول‌داون فقط بعدِ تمومِ
    کاملِ یه بازی اعمال می‌شه؛ این چک برای وقتیه که هنوز حتی بازیِ اول تموم
    نشده)."""
    _expire_stale_classic_for_user(session, user_id)
    active_classic = (
        session.query(db.CasinoRound)
        .filter(
            db.CasinoRound.status.in_(("setup", "lobby")),
            (db.CasinoRound.initiator_id == user_id) |
            (db.CasinoRound.id.in_(
                session.query(db.CasinoPlayer.round_id).filter(db.CasinoPlayer.user_id == user_id)
            ))
        )
        .first()
    )
    if active_classic:
        return True
    active_bs = (
        session.query(db.BattleshipRound)
        .filter(
            db.BattleshipRound.status.in_(("setup", "lobby", "placing", "playing")),
            (db.BattleshipRound.player1_id == user_id) | (db.BattleshipRound.player2_id == user_id),
        )
        .first()
    )
    if active_bs:
        return True
    active_gtn = (
        session.query(db.GuessNumberRound)
        .filter(
            db.GuessNumberRound.status.in_(("setup", "lobby", "setting_number", "guessing")),
            (db.GuessNumberRound.initiator_id == user_id) |
            (db.GuessNumberRound.setter_id == user_id) |
            (db.GuessNumberRound.guesser_id == user_id),
        )
        .first()
    )
    if active_gtn:
        return True
    active_mm = (
        session.query(db.MastermindRound)
        .filter(
            db.MastermindRound.status.in_(("setup", "lobby", "placing", "playing")),
            (db.MastermindRound.player1_id == user_id) | (db.MastermindRound.player2_id == user_id),
        )
        .first()
    )
    if active_mm:
        return True
    # رولت روسی، اونو و مافیا/گرگینه هم جزوِ کازینوان (وارد کردنِ دیرهنگام: import چرخه‌ای نشه)
    import roulette
    import uno
    import mafia
    return bool(roulette.user_has_active_roulette(session, user_id) or uno.user_has_active_uno(session, user_id)
                or mafia.user_has_active_mafia(session, user_id))


def _format_cooldown_wait(seconds: float) -> str:
    seconds = int(seconds) + 1
    m, s = divmod(seconds, 60)
    if m and s:
        return f"{m} دقیقه و {s} ثانیه"
    if m:
        return f"{m} دقیقه"
    return f"{s} ثانیه"


SETUP_ABANDON_TIMEOUT_SECONDS = 60  # اگه کاربر نوعِ بازی رو انتخاب کنه ولی هیچ‌وقت «شروع» رو نزنه، بعدِ این‌همه ثانیه رها می‌شه

# سقفِ مطلقِ عمرِ یه دورِ نیمه‌کاره. هر کازینویی که از ساخته‌شدنش این‌قدر
# گذشته و هنوز پر نشده، در هر صورت لغو می‌شه - حتی اگه:
#   • پیامِ لابی تو گروه پاک شده باشه (که اون‌وقت هیچ دکمه‌ای براش نمی‌موند)
#   • تایمرِ درون‌حافظه‌ایش با ری‌استارتِ ربات از بین رفته باشه
#   • یا مهلتِ پیوستن رو از پنل خیلی بلند گذاشته باشی
# بدونِ این، یه لابیِ حذف‌شده برای همیشه فعال می‌موند و چون تا وقتی یه بازیِ
# نیمه‌کاره داری نمی‌تونی بازیِ جدید بسازی، اون کاربر برای همیشه قفل می‌شد.
HARD_CANCEL_SECONDS = 200


async def sweep_stale_rounds(context):
    """کازینوهایی که تو مرحله‌ی setup (نوعِ بازی انتخاب شده ولی هیچ‌وقت
    «شروع» زده نشده) یا lobby (شروع شده ولی پر نشده) بیش‌ازحد بدونِ حرکت
    موندن رو لغو می‌کنه و پولِ هرکسی که تا اون لحظه پرداخت کرده (بازیکن‌های
    lobby) رو برمی‌گردونه. لازمه چون تا وقتی یه بازیِ نیمه‌کاره داشته باشی
    نمی‌تونی بازیِ جدید بسازی/بپیوندی.

    هر دور زیرِ قفلِ خودش و با یه سشنِ تازه لغو می‌شه (قبلاً همه‌ی دورها با
    یه سشن و بدونِ قفل، و commit فقط آخرِ حلقه بود - یعنی وسطِ ادیتِ پیام، تایمرِ
    خودِ دور می‌تونست همون دور رو دوباره لغو/ریفاند کنه). پیام هم با
    safe_edit_message ادیت می‌شه تا دکمه‌ی مرده رویِ گروه نمونه."""
    while _lazy_edits:
        chat_id, message_id, text = _lazy_edits.pop()
        await safe_edit_message(context, chat_id, message_id, text, None)

    session = db.get_session()
    try:
        now = datetime.datetime.utcnow()
        lobby_timeout = _timeout_seconds(session)
        candidates = []
        for r in session.query(db.CasinoRound).filter(db.CasinoRound.status.in_(("setup", "lobby"))).all():
            if r.status == "lobby":
                ref_time, limit = (r.lobby_opened_at or r.created_at), lobby_timeout
            else:
                ref_time, limit = r.created_at, SETUP_ABANDON_TIMEOUT_SECONDS
            age = (now - r.created_at).total_seconds() if r.created_at else 0
            if age >= HARD_CANCEL_SECONDS or (ref_time and (now - ref_time).total_seconds() >= limit):
                candidates.append(r.id)
    finally:
        session.close()

    for rid in candidates:
        await _sweep_one_round(context, rid)


async def _sweep_one_round(context, rid):
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.CasinoRound, rid)
            if not r or r.status not in ("setup", "lobby"):
                return
            players = session.query(db.CasinoPlayer).filter_by(round_id=rid).all()
            if r.status == "lobby" and r.target_players and len(players) >= r.target_players:
                return  # پر شده و داره نتیجه‌گیری می‌شه
            for p in players:
                u = session.get(db.User, p.user_id)
                if u and r.entry_amount:
                    u.hop_points += r.entry_amount
            was_lobby = r.status == "lobby"
            r.status = "cancelled"
            r.ended_at = datetime.datetime.utcnow()
            session.commit()
            text = cancel_text(r, len(players)) if (was_lobby and players) else "⏳ این کازینو به‌خاطرِ عدمِ فعالیت لغو شد."
            if r.message_id:
                await safe_edit_message(context, r.chat_id, r.message_id, text, None)
        finally:
            session.close()
            _round_locks.pop(rid, None)


async def handle_casino_trigger(update, context):
    session = db.get_session()
    try:
        remaining = await _casino_cooldown_remaining_seconds(session, update.effective_user.id)
    finally:
        session.close()
    if remaining > 0:
        await update.message.reply_text(
            f"⏳ کازینوی قبلیِ این گروه تازه تموم شده. تا {_format_cooldown_wait(remaining)}ی دیگه صبر کن.")
        return
    text, kb = menu_text_and_kb(update.effective_user.id)
    await update.message.reply_text(text, reply_markup=kb)


# ---------------------------------------------------------------------------
# انتخاب بازی -> منوی تنظیمات (مبلغ / تعداد بازیکن)  [ادیت همون پیام]
# ---------------------------------------------------------------------------

def render_setup_text_and_kb(session, r):
    amount_txt = fmt(r.entry_amount) + " 🪙" if r.entry_amount else "— تنظیم نشده —"
    players_txt = str(r.target_players) if r.target_players else "— تنظیم نشده —"
    text = (
        f"{GAME_EMOJI[r.game_type]} بازی {GAME_NAME[r.game_type]}\n\n"
        f"💰 مبلغ ورودی: {amount_txt}\n"
        f"👥 تعداد بازیکن: {players_txt}"
    )
    rows = [[InlineKeyboardButton("💰 انتخاب مبلغ ورودی", callback_data=f"casino_amt_menu:{r.id}")]]
    if r.game_type not in NO_PLAYER_COUNT_CHOICE:
        rows.append([InlineKeyboardButton("👥 انتخاب تعداد بازیکن", callback_data=f"casino_plr_menu:{r.id}")])
    if r.entry_amount and r.target_players:
        rows.append([InlineKeyboardButton("▶️ شروع بازی", callback_data=f"casino_start:{r.id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت (تغییرِ نوعِ بازی)", callback_data=f"casino_back_to_types:{r.id}"),
                 InlineKeyboardButton("❌ لغو", callback_data=f"casino_cancel:{r.id}")])
    return text, InlineKeyboardMarkup(rows)


async def _check_initiator(update, r):
    if not r or update.effective_user.id != r.initiator_id:
        await _safe_answer(update.callback_query, "⛔️ این بازی مال تو نیست! برای ساختن بازی خودت بنویس «کازینو هاپویی».", show_alert=True)
        return False
    return True


async def cb_casino_game(update, context):
    parts = update.callback_query.data.split(":")
    gtype = parts[1]
    owner_id = int(parts[2]) if len(parts) > 2 else None
    if owner_id is not None and update.effective_user.id != owner_id:
        await _safe_answer(update.callback_query, 
            "⛔️ این منو مالِ تو نیست! برای بازکردنِ کازینوی خودت، بنویس «کازینو هاپویی».",
            show_alert=True)
        return
    session = db.get_session()
    try:
        if _user_has_active_round(session, update.effective_user.id):
            await _safe_answer(update.callback_query, 
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await _casino_cooldown_remaining_seconds(session, update.effective_user.id)
        if remaining > 0:
            await _safe_answer(update.callback_query, 
                f"⏳ کازینوی قبلیِ این گروه تازه تموم شده. تا {_format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        r = db.CasinoRound(
            chat_id=update.effective_chat.id,
            message_id=update.callback_query.message.message_id,
            game_type=gtype,
            initiator_id=update.effective_user.id,
            status="setup",
        )
        if gtype in FIXED_TWO_PLAYERS:
            r.target_players = 2
        elif gtype in FIXED_ONE_PLAYER:
            r.target_players = 1
        session.add(r)
        session.commit()
        text, kb = render_setup_text_and_kb(session, r)
        await send_response(update, text, kb)
    finally:
        session.close()


async def cb_casino_setup(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        text, kb = render_setup_text_and_kb(session, r)
        await send_response(update, text, kb)
    finally:
        session.close()


@with_round_lock
async def cb_casino_cancel(update, context):
    """این دکمه هم تو مرحله‌ی setup (قبل از اینکه کسی پول بده) و هم تو
    مرحله‌ی lobby (وقتی سازنده و شاید چندنفرِ دیگه پیوستن و منتظرِ پیوستنِ
    بقیه‌ان) قابل‌کلیکه - ولی فقط برای سازنده‌ی کازینو (owner_id/initiator_id).
    بقیه‌ی بازیکن‌ها - چه عضوِ کازینو باشن چه نه - نمی‌تونن این رو بزنن؛ اگه
    کازینو چندنفره باشه (۳ یا ۴ نفره) باید از دکمه‌ی «ترکِ کازینو» استفاده کنن.
    اگه تو مرحله‌ی lobby لغو بشه، پولِ همه‌ی کسایی که تا اون لحظه پیوسته بودن
    (خودِ سازنده هم جزوشونه) برمی‌گرده."""
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not r:
            await _safe_answer(update.callback_query, "⛔️ این کازینو پیدا نشد.", show_alert=True)
            return
        if update.effective_user.id != r.initiator_id:
            await _safe_answer(update.callback_query, 
                "⛔️ فقط سازنده‌ی کازینو می‌تونه لغوش کنه! اگه عضوشی و می‌خوای بری، از دکمه‌ی «ترک کازینو» استفاده کن (اگه موجود باشه).",
                show_alert=True)
            return
        if r.status not in ("setup", "lobby"):
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه قابلِ لغو نیست.", show_alert=True)
            return

        if r.status == "lobby":
            for job in (context.job_queue.get_jobs_by_name(f"casino_timeout_{r.id}") if context.job_queue else []):
                job.schedule_removal()
            players = session.query(db.CasinoPlayer).filter_by(round_id=r.id).all()
            for p in players:
                u = session.get(db.User, p.user_id)
                if u and r.entry_amount:
                    u.hop_points += r.entry_amount

        r.status = "cancelled"
        r.ended_at = datetime.datetime.utcnow()
        session.commit()
        await send_response(update, "❌ کازینو توسطِ سازنده لغو شد؛ پولِ هرکسی که پرداخت کرده بود برگشت داده شد.", None)
    finally:
        session.close()


@with_round_lock
async def cb_casino_leave(update, context):
    """فقط تو مرحله‌ی lobby و فقط برای کازینوهایی که ظرفیتشون ۳ یا ۴ نفره‌ست
    (تو render_lobby_text_and_kb این دکمه اصلاً برای ۱/۲‌نفره‌ها ساخته نمی‌شه).
    هر بازیکنی که پیوسته - جز سازنده - می‌تونه بزنتش؛ پولش برمی‌گرده و از
    لیستِ بازیکن‌ها حذف می‌شه، بدونِ اینکه کلِ کازینو لغو بشه. سازنده اگه
    بخواد بره باید کلِ کازینو رو با دکمه‌ی «لغو کازینو» لغو کنه (پولِ بقیه هم
    برمی‌گرده)."""
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not r or r.status != "lobby":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        if uid == r.initiator_id:
            await _safe_answer(update.callback_query, 
                "⛔️ تو سازنده‌ی این کازینویی! اگه می‌خوای بیخیالش بشی، رو دکمه‌ی «لغو کازینو» بزن (پولِ همه برمی‌گرده).",
                show_alert=True)
            return
        player = session.query(db.CasinoPlayer).filter_by(round_id=rid, user_id=uid).first()
        if not player:
            await _safe_answer(update.callback_query, "⛔️ تو عضوِ این کازینو نیستی.", show_alert=True)
            return

        user = session.get(db.User, uid)
        if user and r.entry_amount:
            user.hop_points += r.entry_amount
        session.delete(player)
        session.commit()
        await _safe_answer(update.callback_query, "🚪 از کازینو خارج شدی؛ پولت برگشت داده شد.")

        text, kb = render_lobby_text_and_kb(session, r)
        await edit_round_message(context, r, text, kb)
    finally:
        session.close()


async def cb_casino_back_to_types(update, context):
    """دکمه‌ی «بازگشت» رو صفحه‌ی تنظیماتِ بازی - برخلافِ «لغو» (که کلاً بازی رو
    می‌بنده)، این فقط برمی‌گرده به لیستِ انتخابِ نوعِ بازی؛ برای وقتی که کاربر
    اشتباهی نوعِ بازی رو انتخاب کرده (مثلاً دستش خورده گردونه رو زده، تاس
    می‌خواسته) و نمی‌خواد کلِ فرآیند رو از اول با تایپِ «کازینو هاپویی» شروع
    کنه. چون هنوز تو مرحله‌ی setup هستیم، پولی کم نشده - فقط دورِ فعلی رو
    cancelled می‌کنیم و منوی انتخابِ بازی رو دوباره نشون می‌دیم."""
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        r.status = "cancelled"
        r.ended_at = datetime.datetime.utcnow()
        session.commit()
        text, kb = menu_text_and_kb(r.initiator_id)
        await send_response(update, text, kb)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# انتخاب مبلغ ورودی
# ---------------------------------------------------------------------------

async def cb_casino_amt_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        rows = []
        amounts = _preset_amounts(session)
        for i in range(0, len(amounts), 2):
            chunk = amounts[i:i + 2]
            rows.append([InlineKeyboardButton(f"🪙 {fmt(a)}", callback_data=f"casino_amt_pick:{rid}:{a}") for a in chunk])
        rows.append([InlineKeyboardButton("✏️ مبلغ دلخواه", callback_data=f"casino_amt_custom:{rid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"casino_setup:{rid}")])
        await send_response(update, "💰 مبلغ ورودی رو انتخاب کن:", InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_casino_amt_pick(update, context):
    _, rid, amount = update.callback_query.data.split(":")
    rid, amount = int(rid), float(amount)
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        if max_bet_exceeded(session, amount):
            await _safe_answer(update.callback_query, 
                f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(_max_bet_limit(session))} 🪙 هست.", show_alert=True)
            return
        r.entry_amount = amount
        session.commit()
        text, kb = render_setup_text_and_kb(session, r)
        await send_response(update, text, kb)  # خودکار برمی‌گرده به منوی تنظیمات
    finally:
        session.close()


async def cb_casino_amt_custom(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        # دکمه‌ی «کنسل» زیرِ پرامپت به‌جایِ کشتنِ کلِ پنل (که دورِ بازی رو تا مدتی
        # نیمه‌کاره و بی‌دکمه رها می‌کرد)، فقط برمی‌گرده به صفحه‌ی تنظیمات
        await ask_for_input(update, context, "✏️ مبلغ ورودی دلخواه رو به عدد بفرست:",
                            {"type": "amount", "round_id": rid}, "casino_awaiting",
                            cancel_callback=f"casino_amtx:{rid}")
    finally:
        session.close()


async def cb_casino_amtx(update, context):
    """«بازگشت / کنسل» زیرِ پرامپتِ مبلغِ دلخواه: منتظرِ ورودی بودن پاک می‌شه و
    برمی‌گرده به صفحه‌ی تنظیماتِ همون بازی (دورِ بازی سرِ جاشه)."""
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        context.user_data.pop("casino_awaiting", None)
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        text, kb = render_setup_text_and_kb(session, r)
        await send_response(update, text, kb)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# انتخاب تعداد بازیکن
# ---------------------------------------------------------------------------

async def cb_casino_plr_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        lo, hi = MIN_PLAYERS[r.game_type], MAX_PLAYERS[r.game_type]
        rows = [[InlineKeyboardButton(str(n), callback_data=f"casino_plr_pick:{rid}:{n}") for n in range(lo, hi + 1)]]
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"casino_setup:{rid}")])
        await send_response(update, f"👥 تعداد بازیکن رو انتخاب کن ({lo} تا {hi}):", InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_casino_plr_pick(update, context):
    _, rid, n = update.callback_query.data.split(":")
    rid, n = int(rid), int(n)
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        r.target_players = n
        if r.game_type == "dc":
            r.dice_count = 1 if n == 1 else 2
        session.commit()
        text, kb = render_setup_text_and_kb(session, r)
        await send_response(update, text, kb)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# شروع بازی
# ---------------------------------------------------------------------------

@with_round_lock
async def cb_casino_start(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            # این دور قبلا شروع/تمام شده - یعنی این یه کالبکِ تکراریه (نتِ بد
            # باعثِ ارسالِ دوباره‌ی همون کلیک شده، یا کاربر پشتِ‌هم چند بار
            # زده)؛ بدونِ این چک، همینجا بود که «گردونه‌ی شانس» (و بقیه‌ی
            # بازی‌های این تابع) گاهی دوبار پرتاب می‌شد و نتیجه‌ی دومی حساب
            # می‌شد. الان دومی فقط با یه پیامِ عادی رد می‌شه.
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if not r.entry_amount or not r.target_players:
            await _safe_answer(update.callback_query, "اول مبلغ و تعداد بازیکن رو مشخص کن.", show_alert=True)
            return

        if r.game_type == "ws":
            user = db.get_or_create_user(session, update.effective_user)
            if user.hop_points < r.entry_amount - 0.5:
                await _safe_answer(update.callback_query, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
                return
            user.hop_points -= r.entry_amount
            session.commit()

            await _safe_answer(update.callback_query)
            try:
                msg = await context.bot.send_dice(chat_id=r.chat_id, emoji="🎰")
            except Exception:
                logger.exception("ارسالِ گردونه شکست خورد")
                user.hop_points += r.entry_amount
                r.status = "cancelled"
                r.ended_at = datetime.datetime.utcnow()
                session.commit()
                await edit_round_message(context, r, "⚠️ مشکلی تو ارتباط با تلگرام پیش اومد؛ بازی لغو شد و پولت برگشت داده شد.")
                return
            symbols = decode_slot(msg.dice.value)
            await asyncio.sleep(ROLL_DELAY_SECONDS)

            mult = slot_payout_multiplier(symbols)
            symbols_txt = " | ".join(f"{SLOT_SYMBOL_EMOJI[s]} {SLOT_SYMBOL_NAME[s]}" for s in symbols)
            if mult > 0:
                payout = r.entry_amount * mult
                user.hop_points += payout
                result = f"{symbols_txt}\n\n✅ برد با ضریبِ {mult}x! +{fmt(payout)} 🪙"
            else:
                result = f"{symbols_txt}\n\n❌ باخت! -{fmt(r.entry_amount)} 🪙"

            r.status = "resolved"
            r.ended_at = datetime.datetime.utcnow()
            session.commit()
            await edit_round_message(context, r, f"🎰 نتیجه‌ی گردونه‌ی {mentions.of(update.effective_user)}:\n\n{result}")
            return

        if r.game_type == "dc" and r.target_players == 1:
            rows = [[InlineKeyboardButton("🔵 زوج", callback_data=f"casino_solo_bet:{rid}:even"),
                     InlineKeyboardButton("🔴 فرد", callback_data=f"casino_solo_bet:{rid}:odd")]]
            await send_response(update, "🎲 زوج شرط می‌بندی یا فرد؟ (برد = ۲ برابر)", InlineKeyboardMarkup(rows))
            return

        if r.game_type == "dc":
            rows = [[InlineKeyboardButton("🔵 زوج", callback_data=f"casino_init_bet:{rid}:even"),
                     InlineKeyboardButton("🔴 فرد", callback_data=f"casino_init_bet:{rid}:odd")],
                    [InlineKeyboardButton("🔢 عدد خاص (مجموع ۲ تاس)", callback_data=f"casino_init_bet:{rid}:number")]]
            await send_response(update, "🎲 به‌عنوان سازنده‌ی بازی، شرط خودتو انتخاب کن:", InlineKeyboardMarkup(rows))
            return

        # بولینگ/دارت/بسکتبال/فوتبال: نیازی به انتخاب شرط نیست، مستقیم به‌عنوان بازیکن اول می‌پیونده
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await _safe_answer(update.callback_query, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.CasinoPlayer(round_id=r.id, user_id=user.telegram_id))
        session.commit()
        await open_lobby(update, context, r, session)
    finally:
        session.close()


@with_round_lock
async def cb_casino_solo_bet(update, context):
    _, rid, choice = update.callback_query.data.split(":")
    rid = int(rid)
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            # همون فیکسِ «کالبکِ تکراری» که بالاتر (cb_casino_start) توضیح
            # دادم، اینجا هم لازمه چون این تابع خودش تاس می‌ندازه و پول جابه‌جا
            # می‌کنه.
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await _safe_answer(update.callback_query, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.commit()

        await _safe_answer(update.callback_query)
        try:
            msg = await context.bot.send_dice(chat_id=r.chat_id, emoji="🎲")
        except Exception:
            logger.exception("ارسالِ تاس شکست خورد")
            user.hop_points += r.entry_amount
            r.status = "cancelled"
            r.ended_at = datetime.datetime.utcnow()
            session.commit()
            await edit_round_message(context, r, "⚠️ مشکلی تو ارتباط با تلگرام پیش اومد؛ بازی لغو شد و پولت برگشت داده شد.")
            return
        value = msg.dice.value
        await asyncio.sleep(ROLL_DELAY_SECONDS)

        parity = "even" if value % 2 == 0 else "odd"
        won = (choice == parity)
        if won:
            payout = r.entry_amount * 2
            user.hop_points += payout
            result = f"✅ تاس {value} اومد ({'زوج' if parity == 'even' else 'فرد'})! بردی: +{fmt(payout)} 🪙"
        else:
            result = f"❌ تاس {value} اومد ({'زوج' if parity == 'even' else 'فرد'})! باختی: -{fmt(r.entry_amount)} 🪙"

        r.status = "resolved"
        r.ended_at = datetime.datetime.utcnow()
        session.commit()
        await edit_round_message(context, r, f"🎲 نتیجه‌ی تاس {mentions.of(update.effective_user)}:\n\n{result}")
    finally:
        session.close()


@with_round_lock
async def cb_casino_init_bet(update, context):
    _, rid, choice = update.callback_query.data.split(":")
    rid = int(rid)
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if choice == "number":
            await _safe_answer(update.callback_query)
            state = {"type": "init_number", "round_id": rid}
            sent = await context.bot.send_message(
                chat_id=update.effective_chat.id,
                reply_to_message_id=update.callback_query.message.message_id,
                text=f"🔢 {mentions.of(update.effective_user)}، عدد پیش‌بینیت رو (مجموع ۲ تاس، بین ۲ تا ۱۲) بفرست:",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(CANCEL_BUTTON_TEXT, callback_data=f"cancel_any_awaiting:{update.effective_user.id}")]]),
            )
            state["_prompt_chat_id"] = sent.chat_id
            state["_prompt_message_id"] = sent.message_id
            context.user_data["casino_awaiting"] = state
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await _safe_answer(update.callback_query, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.CasinoPlayer(round_id=r.id, user_id=user.telegram_id, bet_choice=choice))
        session.commit()
        await open_lobby(update, context, r, session)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# لابی (در انتظار پیوستن بقیه)
# ---------------------------------------------------------------------------

def render_lobby_text_and_kb(session, r):
    players = session.query(db.CasinoPlayer).filter_by(round_id=r.id).all()
    names = []
    for p in players:
        u = session.get(db.User, p.user_id)
        label = u.display_name() if u else str(p.user_id)
        if r.game_type == "dc" and p.bet_choice:
            bet_txt = {"even": "زوج", "odd": "فرد"}.get(p.bet_choice, f"عدد {p.bet_number}")
            label += f" ({bet_txt})"
        names.append(f"• {label}")

    text = (
        f"{GAME_EMOJI[r.game_type]} {GAME_NAME[r.game_type]} — در انتظار بازیکن‌ها "
        f"({len(players)}/{r.target_players})\n"
        f"💰 مبلغ ورودی هرنفر: {fmt(r.entry_amount)} 🪙\n\n"
        + ("\n".join(names) if names else "هنوز کسی نیست...")
        + f"\n\n⏳ اگه تا {_timeout_seconds(session)} ثانیه تکمیل نشه، بازی لغو می‌شه."
    )

    if r.game_type == "dc":
        rows = [[InlineKeyboardButton("🔵 زوج", callback_data=f"casino_join_bet:{r.id}:even"),
                 InlineKeyboardButton("🔴 فرد", callback_data=f"casino_join_bet:{r.id}:odd")],
                [InlineKeyboardButton("🔢 عدد خاص", callback_data=f"casino_join_bet:{r.id}:number")]]
    else:
        rows = [[InlineKeyboardButton("🎮 شرکت در مسابقه", callback_data=f"casino_join:{r.id}")]]

    # دکمه‌ی «لغو» همیشه تو لابی هست (فقط سازنده می‌تونه واقعاً بزنتش - چک تو
    # خودِ هندلر انجام می‌شه) تا سازنده مجبور نباشه تا آخرِ مهلتِ پیوستن صبر
    # کنه. دکمه‌ی «ترکِ کازینو» فقط وقتی می‌آد که ظرفیتِ بازی ۳ یا ۴ نفره باشه؛
    # چون تو حالتِ ۱ یا ۲ نفره، به‌محضِ پیوستنِ نفرِ آخر بازی فوراً شروع می‌شه و
    # اصلاً فرصتی برای دیدنِ این دکمه نیست.
    rows.append([InlineKeyboardButton("❌ لغو کازینو (فقط سازنده)", callback_data=f"casino_cancel:{r.id}")])
    if r.target_players and r.target_players >= 3:
        rows.append([InlineKeyboardButton("🚪 ترک کازینو", callback_data=f"casino_leave:{r.id}")])
    return text, InlineKeyboardMarkup(rows)


async def open_lobby(update, context, r, session):
    r.status = "lobby"
    r.lobby_opened_at = datetime.datetime.utcnow()
    session.commit()

    players = session.query(db.CasinoPlayer).filter_by(round_id=r.id).all()
    if len(players) >= r.target_players:
        await resolve_round(context, r, session)
        return

    # اول تایمر، بعد پیام: اگه ادیتِ پیام به هر دلیلی خطا بده، لابی بدونِ تایمرِ لغو نمی‌مونه
    schedule_timeout(context, r.id, _timeout_seconds(session))
    text, kb = render_lobby_text_and_kb(session, r)
    await send_response(update, text, kb)


@with_round_lock
async def cb_casino_join(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not r or r.status != "lobby":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        existing = session.query(db.CasinoPlayer).filter_by(round_id=rid, user_id=uid).first()
        if existing:
            await _safe_answer(update.callback_query, "قبلا پیوستی ✅", show_alert=True)
            return
        if _user_has_active_round(session, uid):
            await _safe_answer(update.callback_query, 
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await _casino_cooldown_remaining_seconds(session, uid)
        if remaining > 0:
            await _safe_answer(update.callback_query, 
                f"⏳ خودت تازه یه کازینو تموم کردی. تا {_format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        players_count = session.query(db.CasinoPlayer).filter_by(round_id=rid).count()
        if players_count >= r.target_players:
            await _safe_answer(update.callback_query, "ظرفیت این بازی تکمیله.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await _safe_answer(update.callback_query, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.CasinoPlayer(round_id=rid, user_id=uid))
        session.commit()
        await _safe_answer(update.callback_query, "✅ پیوستی!")

        players_count += 1
        if players_count >= r.target_players:
            await resolve_round(context, r, session)
        else:
            text, kb = render_lobby_text_and_kb(session, r)
            await send_response(update, text, kb)
    finally:
        session.close()


@with_round_lock
async def cb_casino_join_bet(update, context):
    _, rid, choice = update.callback_query.data.split(":")
    rid = int(rid)
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not r or r.status != "lobby":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        existing = session.query(db.CasinoPlayer).filter_by(round_id=rid, user_id=uid).first()
        if existing:
            await _safe_answer(update.callback_query, "قبلا پیوستی ✅", show_alert=True)
            return
        if _user_has_active_round(session, uid):
            await _safe_answer(update.callback_query, 
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await _casino_cooldown_remaining_seconds(session, uid)
        if remaining > 0:
            await _safe_answer(update.callback_query, 
                f"⏳ خودت تازه یه کازینو تموم کردی. تا {_format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        players_count = session.query(db.CasinoPlayer).filter_by(round_id=rid).count()
        if players_count >= r.target_players:
            await _safe_answer(update.callback_query, "ظرفیت این بازی تکمیله.", show_alert=True)
            return

        if choice == "number":
            await _safe_answer(update.callback_query)
            state = {"type": "join_number", "round_id": rid}
            sent = await context.bot.send_message(
                chat_id=update.effective_chat.id,
                reply_to_message_id=update.callback_query.message.message_id,
                text=f"🔢 {mentions.of(update.effective_user)}، عدد پیش‌بینیت رو (مجموع ۲ تاس، بین ۲ تا ۱۲) بفرست:",
                reply_markup=InlineKeyboardMarkup([[InlineKeyboardButton(CANCEL_BUTTON_TEXT, callback_data=f"cancel_any_awaiting:{update.effective_user.id}")]]),
            )
            state["_prompt_chat_id"] = sent.chat_id
            state["_prompt_message_id"] = sent.message_id
            context.user_data["casino_awaiting"] = state
            return

        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await _safe_answer(update.callback_query, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.CasinoPlayer(round_id=rid, user_id=uid, bet_choice=choice))
        session.commit()
        await _safe_answer(update.callback_query, "✅ پیوستی!")

        players_count += 1
        if players_count >= r.target_players:
            await resolve_round(context, r, session)
        else:
            text, kb = render_lobby_text_and_kb(session, r)
            await send_response(update, text, kb)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# نتیجه‌گیری بازی
# ---------------------------------------------------------------------------

async def resolve_round(context, r, session):
    """نتیجه‌گیریِ بازیِ پر‌شده. اگه وسطِ راه (مثلاً موقعِ فرستادنِ تاس - فلودِ تلگرام
    یا سرورِ شلوغ) خطایی بیاد، قبلاً دور تا ابد «lobby» می‌موند: تایمرش برداشته
    شده بود، دکمه‌ها زنده بودن و کاربرها با «وسطِ کازینو هستی» قفل می‌شدن.
    الان دور لغو، پولِ همه برمی‌گرده و پیام با متنِ درست ادیت می‌شه."""
    try:
        await _resolve_round_inner(context, r, session)
    except Exception:
        logger.exception("خطا در نتیجه‌گیریِ کازینو (دور %s)", getattr(r, "id", None))
        try:
            session.rollback()
            session.refresh(r)
            if r.status == "lobby":
                for p in session.query(db.CasinoPlayer).filter_by(round_id=r.id).all():
                    u = session.get(db.User, p.user_id)
                    if u and r.entry_amount:
                        u.hop_points += r.entry_amount
                r.status = "cancelled"
                r.ended_at = datetime.datetime.utcnow()
                session.commit()
                await edit_round_message(
                    context, r, "⚠️ مشکلی تو ارتباط با تلگرام پیش اومد و بازی برگزار نشد؛ کازینو لغو شد و پولِ همه برگشت داده شد.")
        except Exception:
            logger.exception("بازگردانیِ پولِ کازینوی خراب‌شده هم شکست خورد")


async def _resolve_round_inner(context, r, session):
    # جلوگیری از اجرای همزمان تایم‌اوت بعد از تکمیل ظرفیت
    for job in (context.job_queue.get_jobs_by_name(f"casino_timeout_{r.id}") if context.job_queue else []):
        job.schedule_removal()

    players = session.query(db.CasinoPlayer).filter_by(round_id=r.id).all()

    if r.game_type == "dc":
        v1 = (await context.bot.send_dice(chat_id=r.chat_id, emoji="🎲")).dice.value
        await asyncio.sleep(ROLL_DELAY_SECONDS)
        v2 = (await context.bot.send_dice(chat_id=r.chat_id, emoji="🎲")).dice.value
        await asyncio.sleep(ROLL_DELAY_SECONDS)
        total = v1 + v2
        parity = "even" if total % 2 == 0 else "odd"

        lines = [f"🎲 نتیجه: {v1} + {v2} = {total} ({'زوج' if parity == 'even' else 'فرد'})\n"]
        for p in players:
            u = session.get(db.User, p.user_id)
            if p.bet_choice in ("even", "odd") and p.bet_choice == parity:
                payout = r.entry_amount * 2
                u.hop_points += payout
                lines.append(f"✅ {u.display_name()} ({'زوج' if p.bet_choice=='even' else 'فرد'}) بُرد: +{fmt(payout)} 🪙")
            elif p.bet_choice == "number" and p.bet_number == total:
                payout = r.entry_amount * 3
                u.hop_points += payout
                lines.append(f"✅ {u.display_name()} (عدد {p.bet_number}) بُرد: +{fmt(payout)} 🪙")
            else:
                bet_txt = {"even": "زوج", "odd": "فرد"}.get(p.bet_choice, f"عدد {p.bet_number}")
                lines.append(f"❌ {u.display_name()} ({bet_txt}) باخت: -{fmt(r.entry_amount)} 🪙")

        r.status = "resolved"
        r.ended_at = datetime.datetime.utcnow()
        session.commit()
        await edit_round_message(context, r, "\n".join(lines))
        return

    # بولینگ / دارت / بسکتبال / فوتبال: رقابتی بین خودِ بازیکن‌ها
    emoji = GAME_EMOJI[r.game_type]
    results = []  # (player, raw_value, score)
    for p in players:
        msg = await context.bot.send_dice(chat_id=r.chat_id, emoji=emoji)
        value = msg.dice.value
        p.score = value
        results.append((p, value, score_value(r.game_type, value)))
        await asyncio.sleep(ROLL_DELAY_SECONDS)

    max_score = max(sc for _, _, sc in results)
    winners = [p for p, _, sc in results if sc == max_score]
    pot = r.entry_amount * len(players)
    per_winner = pot / len(winners)

    lines = [f"{emoji} نتیجه‌ی {GAME_NAME[r.game_type]}:\n"]
    for p, value, sc in results:
        u = session.get(db.User, p.user_id)
        if p in winners and len(winners) < len(players):
            u.hop_points += per_winner
            lines.append(f"🏆 {u.display_name()}: {value} — برنده! +{fmt(per_winner)} 🪙")
        elif len(winners) == len(players):
            u.hop_points += r.entry_amount  # همه مساوی -> پول هرکس برگشت خودش
            lines.append(f"🤝 {u.display_name()}: {value} — مساوی، مبلغ برگشت داده شد")
        else:
            lines.append(f"💔 {u.display_name()}: {value} — باخت")

    r.status = "resolved"
    r.ended_at = datetime.datetime.utcnow()
    session.commit()
    await edit_round_message(context, r, "\n".join(lines))


def schedule_timeout(context, round_id, delay_seconds):
    """بعد از delay_seconds ثانیه چک می‌کنه که لابی به تعداد لازم بازیکن رسیده یا نه؛
    اگه نه، بازی رو لغو و مبلغ‌های واریزشده رو برمی‌گردونه.

    ترجیحا از job_queue استفاده می‌کنیم؛ ولی چون job_queue نیاز به نصب پکیج
    اضافه‌ی `python-telegram-bot[job-queue]` داره و ممکنه نصب نشده باشه (که باعث
    می‌شد این تایم‌اوت اصلا اجرا نشه و بازی هیچ‌وقت لغو نشه)، اگه job_queue در
    دسترس نبود با asyncio.create_task همون کار رو انجام می‌دیم تا این باگ قطعا
    رفع بشه، فارغ از این‌که پکیج نصب شده باشه یا نه."""
    if context.job_queue:
        context.job_queue.run_once(
            casino_timeout_job, delay_seconds, data=round_id, name=f"casino_timeout_{round_id}",
        )
    else:
        asyncio.create_task(_casino_timeout_fallback(context, round_id, delay_seconds))


async def _casino_timeout_fallback(context, round_id, delay_seconds):
    await asyncio.sleep(delay_seconds)
    await _casino_timeout_core(context, round_id)


async def casino_timeout_job(context):
    await _casino_timeout_core(context, context.job.data)


async def _casino_timeout_core(context, round_id):
    async with _get_round_lock(round_id):
        session = db.get_session()
        r = None
        try:
            r = session.get(db.CasinoRound, round_id)
            if not r or r.status != "lobby":
                return
            players = session.query(db.CasinoPlayer).filter_by(round_id=round_id).all()
            if len(players) >= r.target_players:
                return  # به هر دلیلی رزالو نشده بود، الان دیگه لازم نیست کنسل کنیم

            for p in players:
                u = session.get(db.User, p.user_id)
                if u:
                    u.hop_points += r.entry_amount
            r.status = "cancelled"
            r.ended_at = datetime.datetime.utcnow()
            session.commit()

            await edit_round_message(context, r, cancel_text(r, len(players)))
        finally:
            ended = bool(r) and r.status in ("resolved", "cancelled")
            session.close()
            if ended:
                _round_locks.pop(round_id, None)


# ---------------------------------------------------------------------------
# ورودی متنیِ منتظرِ عدد (مبلغ دلخواه / عدد پیش‌بینی تاس)
# ---------------------------------------------------------------------------

async def _amount_input_error(update, context, state, msg):
    """مبلغِ دلخواهِ نامعتبر: قبلاً فقط «عملیات لغو شد» می‌گفت و پنلِ بازی (که موقعِ
    ریپلای دکمه‌هاش برداشته شده بود) بی‌دکمه و مرده می‌موند - دورِ بازی هم تا
    جاروبِ بعدی نیمه‌کاره حساب می‌شد و کاربر با «وسطِ کازینو هستی» گیر می‌کرد.
    الان پنلِ تنظیمات با همون خطا دوباره سرِ جاش برمی‌گرده."""
    context.user_data.pop("casino_awaiting", None)
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, state["round_id"])
        if r and r.status == "setup":
            text_out, kb = render_setup_text_and_kb(session, r)
            await edit_round_message(context, r, f"{msg}\n\n{text_out}", kb)
        else:
            await update.message.reply_text(msg)
    finally:
        session.close()
    raise ApplicationHandlerStop


async def casino_awaiting_handler(update, context):
    state = context.user_data.get("casino_awaiting")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return  # این پیام ریپلای به پرامپتِ ما نیست - نادیده بگیر
    text = (update.message.text or "").strip()
    if state["type"] == "amount":
        # مبلغه - کوتاه‌نویسی‌هایی مثلِ 5k/5m/5b هم قبول می‌شه
        parsed = parse_amount(text)
        if parsed is None or parsed != int(parsed):
            await _amount_input_error(update, context, state, "❌ مقدار اشتباه است (باید عدد باشه).")
        value = int(parsed)
    else:
        if not text.isdigit():
            context.user_data.pop("casino_awaiting", None)
            await update.message.reply_text("❌ مقدار اشتباه است (باید عدد باشه)؛ عملیات لغو شد.")
            raise ApplicationHandlerStop
        value = int(text)
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, state["round_id"])
        if not r or r.status not in ("setup", "lobby"):
            await update.message.reply_text("این بازی دیگه فعال نیست.")
            context.user_data.pop("casino_awaiting", None)
            raise ApplicationHandlerStop

        if state["type"] == "amount":
            if value <= 0:
                session.close()
                await _amount_input_error(update, context, state, "❌ مقدار اشتباه است (باید بزرگ‌تر از صفر باشه).")
            if max_bet_exceeded(session, value):
                limit_txt = fmt(_max_bet_limit(session))
                session.close()
                await _amount_input_error(update, context, state, f"❌ حداکثر مبلغِ مجازِ قمار {limit_txt} 🪙 هست.")
            r.entry_amount = value
            session.commit()
            text_out, kb = render_setup_text_and_kb(session, r)
            await edit_round_message(context, r, text_out, kb)

        elif state["type"] in ("init_number", "join_number"):
            if not (2 <= value <= 12):
                context.user_data.pop("casino_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است (باید بینِ ۲ تا ۱۲ باشه)؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            uid = update.effective_user.id
            existing = session.query(db.CasinoPlayer).filter_by(round_id=r.id, user_id=uid).first()
            if existing:
                await update.message.reply_text("قبلا پیوستی ✅")
            else:
                players_count = session.query(db.CasinoPlayer).filter_by(round_id=r.id).count()
                if players_count >= r.target_players:
                    await update.message.reply_text("ظرفیت این بازی تکمیله.")
                else:
                    user = db.get_or_create_user(session, update.effective_user)
                    if user.hop_points < r.entry_amount - 0.5:
                        await update.message.reply_text(f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)")
                    else:
                        user.hop_points -= r.entry_amount
                        session.add(db.CasinoPlayer(round_id=r.id, user_id=uid, bet_choice="number", bet_number=value))
                        session.commit()
                        await update.message.reply_text(f"✅ ثبت شد! شرط تو: عدد {value}")
                        players_count += 1
                        if state["type"] == "init_number":
                            if players_count >= r.target_players:
                                await resolve_round(context, r, session)
                            else:
                                lt, lk = render_lobby_text_and_kb(session, r)
                                r.status = "lobby"
                                r.lobby_opened_at = datetime.datetime.utcnow()
                                session.commit()
                                await edit_round_message(context, r, lt, lk)
                                schedule_timeout(context, r.id, _timeout_seconds(session))
                        else:
                            if players_count >= r.target_players:
                                await resolve_round(context, r, session)
                            else:
                                lt, lk = render_lobby_text_and_kb(session, r)
                                await edit_round_message(context, r, lt, lk)
    finally:
        session.close()

    context.user_data.pop("casino_awaiting", None)
    raise ApplicationHandlerStop


# ---------------------------------------------------------------------------
# مسیریاب کال‌بک‌های کازینو
# ---------------------------------------------------------------------------

async def cb_casino_menu_refresh(update, context):
    """«🔄 به‌روزرسانی»: منو رو با لیستِ تازه‌ی لابی‌های جهانی دوباره می‌سازه."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if update.effective_user.id != owner_id:
        await _safe_answer(update.callback_query,
                           "⛔️ این منو مالِ تو نیست! برای بازکردنِ کازینوی خودت، بنویس «کازینو هاپویی».",
                           show_alert=True)
        return
    text, kb = menu_text_and_kb(owner_id)
    await send_response(update, text, kb)


CASINO_PREFIX_MAP = {
    "casino_menu_refresh": cb_casino_menu_refresh,
    "casino_game": cb_casino_game,
    "casino_setup": cb_casino_setup,
    "casino_cancel": cb_casino_cancel,
    "casino_back_to_types": cb_casino_back_to_types,
    "casino_amt_menu": cb_casino_amt_menu,
    "casino_amt_pick": cb_casino_amt_pick,
    "casino_amt_custom": cb_casino_amt_custom,
    "casino_amtx": cb_casino_amtx,
    "casino_plr_menu": cb_casino_plr_menu,
    "casino_plr_pick": cb_casino_plr_pick,
    "casino_start": cb_casino_start,
    "casino_solo_bet": cb_casino_solo_bet,
    "casino_init_bet": cb_casino_init_bet,
    "casino_join": cb_casino_join,
    "casino_join_bet": cb_casino_join_bet,
    "casino_leave": cb_casino_leave,
}

# پیشوندهایی که دومین بخشِ callback_data شون آی‌دیِ دور (rid) ـه
_ROUND_PREFIXES = {k for k in CASINO_PREFIX_MAP if k not in ("casino_game", "casino_menu_refresh")}


async def _heal_dead_panel(update, context, prefix, data) -> bool:
    """پنلی که دکمه‌هاش مرده (دورش لغو/تموم شده ولی ادیتِ پیام به‌خاطرِ فلود/نتِ کند
    جا موند): به‌جایِ فقط «کازینو فعال نیست»، همون پیام رو با وضعیتِ درستش ادیت
    می‌کنیم و دکمه‌ها رو برمی‌داریم - پس رویِ گروه دکمه‌ی مرده نمی‌مونه."""
    try:
        rid = int(data.split(":")[1])
    except (ValueError, IndexError):
        return False
    session = db.get_session()
    try:
        r = session.get(db.CasinoRound, rid)
        if not r or r.status not in ("cancelled", "resolved"):
            return False
        if r.status == "cancelled":
            n = session.query(db.CasinoPlayer).filter_by(round_id=rid).count()
            text = cancel_text(r, n) if n else "⏳ این کازینو لغو شده بود."
        else:
            text = "✅ این کازینو تموم شده."
    finally:
        session.close()
    if prefix == "casino_amtx":
        context.user_data.pop("casino_awaiting", None)
    await _safe_answer(update.callback_query, "⛔️ این کازینو دیگه فعال نیست.", show_alert=True)
    msg = update.callback_query.message
    if msg is not None:
        await safe_edit_message(context, msg.chat_id, msg.message_id, text, None)
    return True


async def casino_callback_router(update, context):
    data = update.callback_query.data
    prefix = data.split(":")[0]
    handler = CASINO_PREFIX_MAP.get(prefix)
    if handler:
        if prefix in _ROUND_PREFIXES and await _heal_dead_panel(update, context, prefix, data):
            return True
        await handler(update, context)
        return True
    return False
