# -*- coding: utf-8 -*-
"""اجرا:  python -m pytest test_mission.py -q   (به دیتابیسِ موقت دست می‌زنه، نه دیتابیسِ واقعی)"""
import datetime
import os
import tempfile
import types

os.environ.setdefault("BOT_TOKEN", "1:x")
os.environ.setdefault("OWNER_ID", "999")
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "mission_test.db")

import pytest  # noqa: E402

import db  # noqa: E402
import war_db as W  # noqa: E402
import heist_db as H  # noqa: E402
import mission_db as MD  # noqa: E402
import mission_svc as S  # noqa: E402
import mission_ui as UI  # noqa: E402
import i18n  # noqa: E402
from mission_svc import MissionError  # noqa: E402

T0 = datetime.datetime(2026, 10, 7, 9, 0, 0)       # ۱۲:۳۰ ایران


class Clock:
    def __init__(self):
        self.t = T0

    def __call__(self):
        return self.t

    def adv(self, **kw):
        self.t += datetime.timedelta(**kw)


@pytest.fixture()
def clock(monkeypatch):
    c = Clock()
    monkeypatch.setattr(S, "utcnow", c)
    return c


@pytest.fixture()
def ses(clock):
    db.Base.metadata.drop_all(db.engine)
    db.init_db()
    W.init_war()
    H.init_heist()
    MD.init_missions()
    s = db.get_session()
    yield s
    s.rollback()
    s.close()


def mkuser(s, uid, prod=1200.0, hop=0.0):
    s.add(db.User(telegram_id=uid, username=f"u{uid}", first_name=f"U{uid}", hop_points=hop, production_per_min=prod))
    s.commit()
    return s.get(db.User, uid)


def played(s, uid, n, at):
    for i in range(n):
        s.add(H.HeistReward(op_id=1000 + i + uid * 10, user_id=uid, hop=0, xp=0, created_at=at))
    s.commit()


def mkdef(s, **kw):
    base = dict(title="t", metric="heist_played", target=2, period="daily", tier=1, ref_hours=1.0, abs_hop=0.0)
    base.update(kw)
    return S.admin_create_def(s, base["title"], base["metric"], base["target"], base["period"], base["tier"], base["ref_hours"], base["abs_hop"])


def test_no_default_missions(ses):
    assert ses.query(MD.MissionDef).count() == 0


def test_starter_pack_is_manual_and_idempotent(ses):
    assert S.admin_install_starter_pack(ses) == len(S.STARTER_PACK)
    assert S.admin_install_starter_pack(ses) == 0
    for d in ses.query(MD.MissionDef):
        assert d.metric in S.MM.METRICS


def test_claim_requires_completion_and_pays_once(ses, clock):
    u = mkuser(ses, 1, prod=1200)
    d = mkdef(ses, target=2, tier=1, ref_hours=1)
    with pytest.raises(MissionError):
        S.claim(ses, u, d.id)                                  # هنوز انجام نشده
    played(ses, 1, 2, clock())
    r = S.claim(ses, u, d.id)
    ses.refresh(u)
    assert r["hop"] == 72_000 and u.hop_points == 72_000       # ۱ ساعت × (۱۲۰۰ × ۶۰)
    with pytest.raises(MissionError):
        S.claim(ses, u, d.id)                                  # دابل‌کلیک/Replay
    ses.refresh(u)
    assert u.hop_points == 72_000
    assert ses.query(W.HopTransaction).filter(W.HopTransaction.user_id == 1).count() == 1


def test_only_own_todays_missions(ses, clock):
    a, b = mkuser(ses, 1), mkuser(ses, 2)
    d = mkdef(ses)
    played(ses, 1, 5, clock())
    with pytest.raises(MissionError):
        S.claim(ses, b, d.id)                                  # پیشرفتِ نفرِ دیگه به حسابش نمیاد
    with pytest.raises(MissionError):
        S.claim(ses, a, 9999)


def test_progress_resets_next_day(ses, clock):
    u = mkuser(ses, 1)
    d = mkdef(ses, target=1)
    played(ses, 1, 1, clock())
    S.claim(ses, u, d.id)
    clock.adv(days=1)
    item = next(t for t in S.todays(ses, u, clock()) if t["def"].id == d.id)
    assert item["progress"] == 0 and not item["claimed"]
    played(ses, 1, 1, clock())
    S.claim(ses, u, d.id)                                      # روزِ بعد دوباره می‌شه


def test_reward_scales_with_wealth_but_capped(ses, clock):
    poor, rich = mkuser(ses, 1, prod=1200), mkuser(ses, 2, prod=5_000_000)
    d = mkdef(ses, target=1, ref_hours=2)
    S.admin_set_cfg(ses, "ct_reward_max", "100000000")
    played(ses, 1, 1, clock()); played(ses, 2, 1, clock())
    assert S.claim(ses, poor, d.id)["hop"] == 144_000
    assert S.claim(ses, rich, d.id)["hop"] == 100_000_000       # سقفِ ضدِ تورم


def test_floor_income_helps_idle_player(ses, clock):
    u = mkuser(ses, 1, prod=0)
    d = mkdef(ses, target=1, ref_hours=1)
    played(ses, 1, 1, clock())
    assert S.claim(ses, u, d.id)["hop"] == 60_000               # ct_floor_hourly


def test_streak_grows_resets_and_multiplies(ses, clock):
    u = mkuser(ses, 1, prod=1200)
    d = mkdef(ses, target=1, ref_hours=1)
    S.admin_set_cfg(ses, "ct_streak_steps", "2:2")
    for day in range(3):
        played(ses, 1, 1, clock())
        r = S.claim(ses, u, d.id)
        clock.adv(days=1)
    assert r["streak"] == 3 and r["mult"] == 2 and r["hop"] == 144_000
    clock.adv(days=3)
    played(ses, 1, 1, clock())
    assert S.claim(ses, u, d.id)["streak"] == 1                 # فاصله = ریست
    assert S.get_player(ses, 1).best_streak == 3


def test_all_done_bonus_once(ses, clock):
    u = mkuser(ses, 1, prod=1200)
    a, b = mkdef(ses, title="a", target=1, tier=1), mkdef(ses, title="b", target=1, tier=2)
    S.admin_set_cfg(ses, "ct_daily_count", "2")
    S.admin_set_cfg(ses, "ct_all_done_bonus_hours", "2")
    S.admin_set_cfg(ses, "ct_new_player_bonus_hours", "0")
    played(ses, 1, 3, clock())
    r1 = S.claim(ses, u, a.id)
    assert not r1["all_done"]
    r2 = S.claim(ses, u, b.id)
    assert r2["all_done"] and r2["extra"] == 144_000
    assert ses.query(MD.MissionBonus).filter_by(user_id=1, kind="all_done").count() == 1


def test_welcome_bonus_once(ses, clock):
    u = mkuser(ses, 1, prod=1200)
    d = mkdef(ses, target=1)
    S.admin_set_cfg(ses, "ct_new_player_bonus_hours", "6")
    played(ses, 1, 1, clock())
    r = S.claim(ses, u, d.id)
    assert r["extra"] == 6 * 72_000
    assert ses.query(MD.MissionBonus).filter_by(user_id=1, kind="welcome").count() == 1


def test_once_path_missions_shown_until_claimed(ses, clock):
    u = mkuser(ses, 1)
    for i in range(4):
        mkdef(ses, title=f"o{i}", period="once", target=1)
    S.admin_set_cfg(ses, "ct_once_visible", "2")
    shown = [t for t in S.todays(ses, u, clock()) if t["period"] == "once"]
    assert len(shown) == 2
    played(ses, 1, 1, clock())
    S.claim(ses, u, shown[0]["def"].id)
    clock.adv(days=40)
    shown2 = [t for t in S.todays(ses, u, clock()) if t["period"] == "once"]
    assert shown[0]["def"].id not in [t["def"].id for t in shown2] and len(shown2) == 2


def test_season_leaderboard_and_settlement_once(ses, clock):
    users = [mkuser(ses, i, prod=1200) for i in (1, 2, 3)]
    d = mkdef(ses, target=1, tier=3)
    S.admin_set_cfg(ses, "ct_season_min_points", "0")
    S.admin_set_cfg(ses, "ct_season_top_hours", "10,5")
    for u in users[:2]:
        played(ses, u.telegram_id, 1, clock())
        S.claim(ses, u, d.id, chat_id=-5)
    board = S.leaderboard(ses, chat_id=-5)
    assert [b[2] for b in board][:2] == [1, 2] or [b[2] for b in board][:2] == [2, 1]
    clock.adv(days=31)
    paid = S.settle_seasons(ses, clock())
    assert len(paid) == 2 and {r for _u, r, _h in paid} == {1, 2}
    assert S.settle_seasons(ses, clock()) == []                  # دوباره پرداخت نمی‌شه
    assert ses.query(MD.MissionBonus).filter_by(kind="season").count() == 2


def test_min_level_gate(ses, clock):
    u = mkuser(ses, 1)
    d = mkdef(ses, target=1)
    db.cfg_set(ses, "minlvl_mission", "5")
    ses.commit()
    played(ses, 1, 1, clock())
    with pytest.raises(MissionError):
        S.claim(ses, u, d.id)


def test_admin_validation(ses):
    with pytest.raises(MissionError):
        mkdef(ses, metric="nope")
    with pytest.raises(MissionError):
        mkdef(ses, target=0)
    with pytest.raises(MissionError):
        mkdef(ses, tier=7)
    with pytest.raises(MissionError):
        S.admin_set_cfg(ses, "ct_streak_steps", "garbage")
    with pytest.raises(MissionError):
        S.admin_set_cfg(ses, "ct_season_days", "0")
    with pytest.raises(MissionError):
        S.admin_set_cfg(ses, "bogus", "1")


def test_disabled_defs_hidden(ses, clock):
    u = mkuser(ses, 1)
    d = mkdef(ses)
    S.admin_toggle_def(ses, d.id)
    assert S.todays(ses, u, clock()) == []


def tgu(uid):
    return types.SimpleNamespace(id=uid, username=f"u{uid}", first_name=f"U{uid}")


def test_ui_owner_lock_and_claim_flow(ses, clock):
    mkuser(ses, 1); mkuser(ses, 2)
    d = mkdef(ses, target=1, title="کازینو")
    played(ses, 1, 1, clock())
    toast, alert, view = UI.dispatch(ses, tgu(2), -1, f"mt:1:c:{d.id}")
    assert alert and toast == i18n.t("mt_not_yours")
    toast, alert, view = UI.dispatch(ses, tgu(1), -1, f"mt:1:c:{d.id}")
    assert not alert and "هاپ" in toast and "✅" in view[0]


def test_ui_main_view_shows_progress(ses, clock):
    u = mkuser(ses, 1)
    mkdef(ses, target=4, title="چهار بار")
    played(ses, 1, 1, clock())
    text, rows = UI.main_view(ses, u, "fa")
    assert "1/4" in text and "چهار بار" in text and "استریک" in text


def test_language_switch_and_fallback(ses, tmp_path, monkeypatch):
    monkeypatch.setattr(i18n, "LOCALE_DIR", str(tmp_path))
    i18n._cache.clear()
    (tmp_path / "fa.json").write_text('{"_meta":{"name":"فارسی"},"a":"سلام {x}","b":"فقط فارسی"}', encoding="utf-8")
    (tmp_path / "en.json").write_text('{"_meta":{"name":"English"},"a":"Hello {x}"}', encoding="utf-8")
    assert i18n.t("a", "en", x="Ali") == "Hello Ali"
    assert i18n.t("b", "en") == "فقط فارسی"                      # ترجمه‌نشده → فارسی
    assert i18n.t("zzz", "en") == "zzz"
    assert i18n.missing("en") == ["b"]
    assert set(i18n.available()) == {"fa", "en"}


def test_metrics_are_safe_when_table_missing(ses, clock):
    import mission_metrics as MM
    from sqlalchemy import text
    ses.execute(text("DROP TABLE IF EXISTS myawy_posts"))
    ses.commit()
    assert MM.measure(ses, "myawy_posts", 1, None) == 0
