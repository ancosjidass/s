# Hopbot PostgreSQL optimization - handoff

## Done (all verified on real PostgreSQL; logic/economy/games unchanged)
- db.py: in-memory game_config cache (cfg_get/cfg_set/cfg_cache_clear, TTL CFG_CACHE_TTL_SECONDS); pool_pre_ping replaced by idle-only ping on checkout; pool_use_lifo; executemany_mode=values_plus_batch; track_group_chat throttled (GROUP_TRACK_WRITE_SECONDS); cat_name cache (cat_name_matches + ORM set-event); ensure_pg_indexes() (67 IF NOT EXISTS indexes, list _PG_INDEXES).
- jobs.py: _tick_bank_and_market (only supermarket/bank users, products preloaded, uniform batched UPDATEs). economy.collect_supermarket_production got optional _dynamic_products/_user_products args (default path = original code).
- handlers.py text_router: cat-name check uses db.cat_name_matches.
- main.py: db.ensure_pg_indexes() after init_*; optional CONCURRENT_UPDATES.
- war_db/heist_db/mission_db/referral: db.cfg_cache_clear() after seeding Config.
- config.py: PG_IDLE_PING_SECONDS, CFG_CACHE_TTL_SECONDS, GROUP_TRACK_WRITE_SECONDS, PG_ASYNC_COMMIT (default off), CONCURRENT_UPDATES (default off).

## Root cause still open
Handlers are async but DB calls are sync psycopg2 inside the event loop; every query to remote Supabase blocks the whole bot for one network RTT. Fewer queries is the fix path.

## Not yet reviewed (read line by line, find per-call/per-user query loops, N+1, missing indexes, hot paths)
admin.py, smuggling.py, mafia.py, casino.py, roulette.py, attack.py, myawy.py, taxi.py, cards.py, chef.py, uno.py, battleship.py, guessnum.py, mastermind.py, war_ui/war_svc/war_clan/war_battle, heist_svc/heist_ui, mission_svc/mission_db/mission_metrics, handlers.py (rest), keyboards.py, account_backup.py, db_purge.py, referral*.py.

## Known pre-existing test failures (same in original)
9 in test_mission.py/test_war_balance.py; async tests need pytest-asyncio. Compare against original zip before blaming changes.

## Rules
Do not remove or change any feature, command, menu, game, economy, war system, user data or core logic. Only reduce DB round trips / add indexes / cache safely. Cache anything only with write-through or explicit invalidation. Test on real PostgreSQL (pip install pgserver).
