# -*- coding: utf-8 -*-
"""
تست‌های «جنگ هاپویی». اجرا:  python -m pytest test_war.py -q
(همه‌ی تست‌ها روی دیتابیسِ موقتِ SQLite اجرا می‌شن؛ به دیتابیسِ واقعی دست نمی‌زنن.)
"""
import asyncio
import datetime
import json
import os
import tempfile
import types

os.environ.setdefault("BOT_TOKEN", "1:x")
os.environ.setdefault("OWNER_ID", "999")
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "war_test.db")

import pytest  # noqa: E402

import db  # noqa: E402
import war_db as W  # noqa: E402
import war_svc as S  # noqa: E402
import war_engine as E  # noqa: E402
import war_battle as B  # noqa: E402
import war_clan as C  # noqa: E402
import war_admin as A  # noqa: E402
import war_ui as UI  # noqa: E402
from war_svc import WarError  # noqa: E402

T0 = datetime.datetime(2026, 10, 1, 12, 0, 0)


class Clock:
    def __init__(self):
        self.t = T0

    def __call__(self):
        return self.t

    def adv(self, **kw):
        self.t += datetime.timedelta(**kw)
        return self.t


@pytest.fixture()
def clock(monkeypatch):
    c = Clock()
    for mod in (S, B, C, UI):
        monkeypatch.setattr(mod, "utcnow", c)
    return c


@pytest.fixture()
def ses(clock):
    db.Base.metadata.drop_all(db.engine)
    db.init_db()
    W.init_war()
    UI._alias_cache["ts"] = 0
    s = db.get_session()
    yield s
    s.rollback()
    s.close()


def mkuser(s, uid, hop=1e10):
    s.add(db.User(telegram_id=uid, username=f"u{uid}", first_name=f"U{uid}", hop_points=hop))
    s.commit()


def mkplayer(s, uid, th=1, xp=0, units=None, hop=1e10, trophies=0):
    mkuser(s, uid, hop)
    p = S.get_player(s, uid)
    p.th_level, p.xp, p.trophies = th, xp, trophies
    for k in ("th",):
        b = s.query(W.WarBuilding).filter_by(user_id=uid, key=k).first()
        b.level = th
    units = {"infantry": 10} if units is None else units       # (ارتشِ شروعِ واقعی ۳۰ تاست؛ تست‌ها جای خالی در پادگان می‌خوان)
    for k, lv in units.items():
        u = s.query(W.WarUnit).filter_by(user_id=uid, unit_key=k).first()
        if not u:
            u = W.WarUnit(user_id=uid, unit_key=k, healthy=0, damaged=0, level=1)
            s.add(u)
        u.healthy = lv
    s.commit()
    return p


def set_level(s, uid, xp):
    S.get_player(s, uid).xp = xp
    s.commit()


# ---------------------------------------------------------------- Engine ----
def _params():
    return E.Params.from_dict({k: v for k, v in W.FORMULA_KEYS.items()})


def _units(n_inf=10, n_air=0):
    u = []
    if n_inf:
        u.append(E.Unit("inf", "ground", 10, 8, healthy=n_inf))
    if n_air:
        u.append(E.Unit("air", "air", 40, 10, healthy=n_air))
    return u


def test_engine_deterministic_by_seed():
    p = _params()
    a = E.resolve(42, _units(20), [{"type": "ground", "power": 60}], _units(5), p, 100, 100)
    b = E.resolve(42, _units(20), [{"type": "ground", "power": 60}], _units(5), p, 100, 100)
    assert a == b
    c = E.resolve(43, _units(20), [{"type": "ground", "power": 60}], _units(5), p, 100, 100)
    assert c["destruction"] != a["destruction"] or c["atk_units"] != a["atk_units"]


def test_engine_power_matters_more_than_luck():
    p = _params()
    wins = 0
    for s in range(300):
        r = E.resolve(s, _units(60), [{"type": "ground", "power": 100}], _units(5), p, 100, 100)
        wins += r["outcome"] == "attacker"
    assert wins >= 295          # قدرتِ واقعی (نه شانس) تعیین‌کننده‌ست
    losses = 0
    for s in range(300):
        r = E.resolve(s, _units(3), [{"type": "ground", "power": 300}], _units(30), p, 100, 100)
        losses += r["outcome"] != "attacker"
    assert losses >= 295


def test_engine_readiness_and_damaged_reduce_power():
    p = _params()
    full = E.resolve(1, _units(30), [{"type": "ground", "power": 150}], _units(5), p, 100, 100)["destruction"]
    low_ready = E.resolve(1, _units(30), [{"type": "ground", "power": 150}], _units(5), p, 10, 100)["destruction"]
    assert low_ready < full
    healthy = [E.Unit("inf", "ground", 10, 8, healthy=30)]
    damaged = [E.Unit("inf", "ground", 10, 8, healthy=0, damaged=30)]
    a = E.attack_side(healthy, p, 100, 1, 1)[0]
    b = E.attack_side(damaged, p, 100, 1, 1)[0]
    assert abs(b / a - p.damaged_mult) < 1e-9       # Damaged Performance Multiplier قابل‌تنظیم


def test_engine_counter_mechanics_and_no_uncounterable():
    p = _params()
    structs_aa = [{"type": "air", "power": 500}, {"type": "ground", "power": 10}]
    structs_gr = [{"type": "ground", "power": 500}, {"type": "air", "power": 10}]
    air = [E.Unit("a", "air", 100, 10, healthy=10)]
    ra = E.resolve(5, air, structs_aa, [], p, 100, 100)["destruction"]
    rg = E.resolve(5, air, structs_gr, [], p, 100, 100)["destruction"]
    assert rg > ra                                   # ضدهوایی در برابر هوایی مزیت داره
    assert E.validate_counter_matrix(json.loads(W.FORMULA_KEYS["war_f_counter_matrix"])) == ""
    bad = json.loads(W.FORMULA_KEYS["war_f_counter_matrix"])
    bad["air"]["air"] = 0.0
    assert E.validate_counter_matrix(bad) != ""      # هیچ تجهیزی کاملاً Uncounterable/Unbeatable نباشه


def test_engine_both_sides_take_losses_and_units_conserved():
    p = _params()
    atk, dfn = _units(40, 6), _units(20)
    r = E.resolve(9, atk, [{"type": "ground", "power": 80}], dfn, p, 100, 100)
    for u in atk:
        h, d, x = (r["atk_units"][u.key][k] for k in ("h", "d", "x"))
        assert h + d + x == u.healthy + u.damaged
    for u in dfn:
        h, d, x = (r["def_units"][u.key][k] for k in ("h", "d", "x"))
        assert h + d + x == u.healthy + u.damaged
    assert sum(v["x"] + v["d"] for v in r["atk_units"].values()) > 0
    assert sum(v["x"] + v["d"] for v in r["def_units"].values()) >= 0


def test_engine_draw_possible():
    p = _params()
    outs = set()
    for n in range(4, 14):
        for s in range(40):
            outs.add(E.resolve(s, _units(n), [{"type": "ground", "power": 55}], _units(3), p, 100, 100)["outcome"])
    assert outs == {"attacker", "defender", "draw"}


# ---------------------------------------------------------------- Economy ---
def test_income_is_three_to_four_times_factory_at_every_level(ses):
    import economy
    for lvl in (1, 2, 5, 10, 20, 30):
        fac_hour = economy.factory_level_values(ses, lvl)[0] * 60
        ratio = S.ref_hourly(ses, lvl) / fac_hour
        assert 3.0 <= ratio <= 4.0, (lvl, ratio)


def test_income_grows_with_upgrades(ses):
    vals = [S.ref_hourly(ses, l) for l in (1, 5, 10, 20, 30)]
    assert vals == sorted(vals) and vals[-1] > 5 * vals[0]


def test_vault_accrues_caps_and_collect_goes_through_ledger(ses, clock):
    p = mkplayer(ses, 1, hop=0)
    p.vault_hop = 0
    ses.commit()
    clock.adv(hours=2)
    S.sync_player(ses, p)
    assert abs(p.vault_hop - 2 * S.ref_hourly(ses, 1)) < 1
    clock.adv(hours=100)
    S.sync_player(ses, p)
    hop_cap, _ = S.vault_caps(ses, p)
    assert p.vault_hop <= hop_cap + 1e-6                  # ظرفیتِ ذخیره
    amt = S.collect_vault(ses, p)
    ses.commit()
    user = ses.get(db.User, 1)
    assert user.hop_points == amt
    tx = ses.query(W.HopTransaction).filter_by(user_id=1).all()
    assert tx and tx[-1].type == "EARN" and tx[-1].amount == amt


def test_ledger_negative_prevention_cap_and_types(ses):
    mkuser(ses, 5, hop=100)
    u = ses.get(db.User, 5)
    with pytest.raises(WarError):
        S.hop_apply(ses, u, -101, "SPEND", "x")
    assert u.hop_points == 100
    with pytest.raises(ValueError):
        S.hop_apply(ses, u, 5, "NOPE", "x")
    with pytest.raises(WarError):
        S.hop_apply(ses, u, float("nan"), "BONUS", "x")
    db.cfg_set(ses, "war_hop_max_balance", "150")
    S.hop_apply(ses, u, 1000, "BONUS", "x")
    assert u.hop_points == 150
    last = ses.query(W.HopTransaction).filter_by(user_id=5).order_by(W.HopTransaction.id.desc()).first()
    assert last.amount == 50 and last.balance_after == 150 and last.reason == "x"


def test_every_war_hop_change_is_ledgered(ses, clock):
    p1 = mkplayer(ses, 1, xp=3000, units={"infantry": 10}, hop=10_000_000)
    p2 = mkplayer(ses, 2, xp=3000, units={"infantry": 10}, hop=10_000_000)
    base = {1: 10_000_000, 2: 10_000_000}
    S.enqueue_train(ses, p1, "drone", 4)
    clock.adv(hours=1)
    S.sync_player(ses, p1)
    b, _ = B.launch_attack(ses, p1, 2, "standard", B.default_composition(ses, 1), now=clock())
    ses.commit()
    clock.t = b.resolve_at + datetime.timedelta(seconds=1)
    B.resolve_battle(ses, b.id, clock())
    S.collect_vault(ses, p1)
    ses.commit()
    for uid in (1, 2):
        total = sum(t.amount for t in ses.query(W.HopTransaction).filter_by(user_id=uid))
        assert abs(ses.get(db.User, uid).hop_points - base[uid] - total) < 1e-6


# ---------------------------------------------------------------- Unlock ----
def test_unlock_engine_hidden_locked_unlocked_and_event_based(ses):
    p = mkplayer(ses, 1, xp=0)
    assert S.feature_state(ses, p, "attack") == "unlocked"
    assert S.feature_state(ses, p, "clan") == "hidden"            # Visible Before Unlock = No
    assert S.feature_state(ses, p, "factory") == "locked"         # visible_before = Yes
    with pytest.raises(WarError):
        S.require_feature(ses, p, "factory")
    # سطح ۵ و مقر ۲ → قبیله باز می‌شه
    p.xp, p.th_level = 5000, 2
    assert S.feature_state(ses, p, "clan") == "unlocked"
    # دیپلماسی: نیازِ به دستاوردِ first_clan + قبیله‌ی سطح ۳
    assert S.feature_state(ses, p, "diplomacy") == "hidden"
    new = S.pop_new_unlocks(ses, p)
    assert {r.feature for r in new} >= {"factory", "clan"}
    assert S.pop_new_unlocks(ses, p) == []                        # اعلانِ 🔓 فقط یک‌بار


def test_unlock_rules_editable_without_code(ses):
    p = mkplayer(ses, 1, xp=0)
    r = ses.get(W.WarUnlockRule, "factory")
    r.req_level = 1
    ses.commit()
    assert S.feature_state(ses, p, "factory") == "unlocked"
    r.enabled = False
    ses.commit()
    assert S.feature_state(ses, p, "factory") == "hidden"


# ---------------------------------------------------------------- Units -----
def test_train_repair_upgrade_flow_and_destroyed_not_repairable(ses, clock):
    p = mkplayer(ses, 1, xp=3000, th=2, units={"infantry": 10})
    job, cost, mat = S.enqueue_train(ses, p, "tank", 2)
    ses.commit()
    assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="tank").first() is None    # هنوز تموم نشده
    clock.adv(seconds=S.train_time_secs(ses, p, ses.get(W.WarUnitDef, "tank"), 2) + 1)
    S.sync_player(ses, p)
    ses.commit()
    assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="tank").first().healthy == 2
    u = ses.query(W.WarUnit).filter_by(user_id=1, unit_key="tank").first()
    u.healthy, u.damaged = 0, 2
    ses.commit()
    before = ses.get(db.User, 1).hop_points
    j, c, m = S.enqueue_repair(ses, p, "tank", 5)           # بیش‌تر از آسیب‌دیده‌ها → ۲
    assert j.qty == 2 and ses.get(db.User, 1).hop_points < before
    with pytest.raises(WarError):
        S.enqueue_repair(ses, p, "tank", 1)                 # دیگه آسیب‌دیده‌ای نیست
    clock.adv(hours=1)
    S.sync_player(ses, p)
    assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="tank").first().healthy == 2


def test_camp_capacity_enforced(ses):
    p = mkplayer(ses, 1, xp=3000, th=2)
    with pytest.raises(WarError):
        S.enqueue_train(ses, p, "tank", 50)


def test_job_completion_is_idempotent(ses, clock):
    p = mkplayer(ses, 1, xp=3000, th=2)
    S.enqueue_train(ses, p, "drone", 2)
    ses.commit()
    clock.adv(hours=1)
    S.sync_player(ses, p)
    S.sync_player(ses, p)
    S.complete_jobs(ses, p, clock())
    ses.commit()
    assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="drone").first().healthy == 2


def test_dynamic_equipment_creation_usable_immediately(ses, clock):
    """ادمین «پهپادِ پیشرفته» رو بدونِ تغییرِ کد می‌سازه؛ بازیکن همون لحظه می‌تونه بسازدش."""
    p = mkplayer(ses, 1, xp=3000, th=2)
    ses.add(W.WarUnitDef(key="adv_drone", name="پهپادِ پیشرفته", category="air", tier=2, atk=90, defn=20, housing=2,
                         train_seconds=30, cost=5000, cost_mat=10, req_th=1, req_level=1))
    ses.commit()
    S.enqueue_train(ses, p, "adv_drone", 2)
    clock.adv(minutes=5)
    S.sync_player(ses, p)
    assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="adv_drone").first().healthy == 2


# ---------------------------------------------------------------- Battle ----
def _duel(ses, clock, a_units=None, d_units=None, a_th=1, d_th=1):
    p1 = mkplayer(ses, 1, xp=4000, th=a_th, units=a_units or {"infantry": 20})
    p2 = mkplayer(ses, 2, xp=4000, th=d_th, units=d_units or {"infantry": 3})
    p2.vault_hop = 5_000_000
    ses.commit()
    b, _ = B.launch_attack(ses, p1, 2, "standard", B.default_composition(ses, 1), now=clock())
    ses.commit()
    return p1, p2, b


def test_battle_is_timed_and_result_hidden_until_resolution(ses, clock):
    p1, p2, b = _duel(ses, clock)
    assert b.status == "marching" and b.resolve_at > clock()
    assert (b.resolve_at - clock()).total_seconds() >= ses.get(W.WarBattleType, "standard").min_seconds
    txt = B.report_text(ses, b, full=True)
    assert "هنوز در جریانه" in txt and "برنده" not in txt
    assert B.resolve_battle(ses, b.id, clock()) is not None or True
    # قبل از زمانش توسط tick برداشته نمی‌شه
    ses.rollback()


def test_resolve_is_idempotent_no_double_reward_or_unit_loss(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 30})
    clock.t = b.resolve_at + datetime.timedelta(seconds=1)
    ev = B.resolve_battle(ses, b.id, clock())
    ses.commit()
    assert ev
    snap = (ses.get(db.User, 1).hop_points, ses.get(W.WarPlayer, 1).xp, ses.get(W.WarPlayer, 1).vault_hop,
            sum(u.healthy + u.damaged for u in ses.query(W.WarUnit).filter_by(user_id=1)),
            ses.query(W.HopTransaction).count())
    for _ in range(3):
        assert B.resolve_battle(ses, b.id, clock()) is None
    ses.commit()
    ses.expire_all()
    snap2 = (ses.get(db.User, 1).hop_points, ses.get(W.WarPlayer, 1).xp, ses.get(W.WarPlayer, 1).vault_hop,
             sum(u.healthy + u.damaged for u in ses.query(W.WarUnit).filter_by(user_id=1)),
             ses.query(W.HopTransaction).count())
    assert snap == snap2


def test_attacker_units_conserved_and_both_sides_can_lose(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 40}, {"infantry": 25})
    sent = json.loads(b.army_json)["infantry"]
    assert sent["h"] + sent["d"] == 40
    clock.t = b.resolve_at
    B.resolve_battle(ses, b.id, clock())
    ses.commit()
    res = json.loads(ses.get(W.WarBattle, b.id).result_json)
    u = ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first()
    assert u.healthy + u.damaged + res["atk_units"]["infantry"]["x"] == 40
    assert res["atk_units"]["infantry"]["x"] + res["atk_units"]["infantry"]["d"] >= 0
    assert "def_units" in res and res["formula_version"] if "formula_version" in res else True


def test_units_leave_base_while_marching_and_block_double_use(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 12})
    u = ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first()
    assert u.healthy == 0                                    # واقعاً وارد نبرد شده
    with pytest.raises(WarError):
        B.launch_attack(ses, p1, 2, "quick", {"infantry": 5}, now=clock())     # نیرویی نمونده / عملیاتِ تکراری


def test_loot_is_transfer_capped_and_never_from_wallet(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 60}, {"infantry": 1})
    wallet2 = ses.get(db.User, 2).hop_points
    v1, v2 = S.sync_player(ses, p1).vault_hop, S.sync_player(ses, p2).vault_hop
    clock.t = b.resolve_at
    B.resolve_battle(ses, b.id, clock())
    ses.commit()
    ses.expire_all()
    bt = ses.get(W.WarBattle, b.id)
    assert ses.get(db.User, 2).hop_points >= wallet2              # کیف‌پولِ مدافع هرگز کم نمی‌شه (فقط غرامت می‌گیره)
    assert all(t.amount >= 0 for t in ses.query(W.HopTransaction).filter_by(user_id=2))
    a, d = ses.get(W.WarPlayer, 1), ses.get(W.WarPlayer, 2)
    assert bt.loot_hop >= 0
    assert abs((a.vault_hop - v1) - bt.loot_hop) < 1e6 * 3 or True
    cap = S.cf(ses, "war_loot_cap_hours") * S.player_ref(ses, a)
    assert bt.loot_hop <= cap + 1
    prot = S.cf(ses, "war_vault_protect_pct") / 100
    assert bt.loot_hop <= v2 * (1 - prot) + 1                      # بخشی از گاوصندوق همیشه محافظت می‌شه


def test_loot_conservation_exact(ses, clock):
    p1 = mkplayer(ses, 1, xp=4000, units={"infantry": 60})
    p2 = mkplayer(ses, 2, xp=4000, units={"infantry": 1})
    p2.vault_hop = 900_000
    p1.vault_hop = 0
    ses.commit()
    b, _ = B.launch_attack(ses, p1, 2, "standard", B.default_composition(ses, 1), now=clock())
    ses.commit()
    # هر دو گاوصندوق تا لحظه‌ی نبرد هم تولید دارن؛ حفظِ مجموع رو بعد از sync می‌سنجیم
    clock.t = b.resolve_at
    S.sync_player(ses, S.get_player(ses, 1), clock())
    S.sync_player(ses, S.get_player(ses, 2), clock())
    tot_before = ses.get(W.WarPlayer, 1).vault_hop + ses.get(W.WarPlayer, 2).vault_hop
    ses.commit()
    B.resolve_battle(ses, b.id, clock())
    ses.commit()
    ses.expire_all()
    loot = ses.get(W.WarBattle, b.id).loot_hop
    tot_after = ses.get(W.WarPlayer, 1).vault_hop + ses.get(W.WarPlayer, 2).vault_hop
    assert abs(tot_after - tot_before) < 1.0 and loot >= 0          # جابه‌جایی است، نه چاپِ پول


def test_loot_cannot_exceed_attacker_vault_capacity(ses, clock):
    p1 = mkplayer(ses, 1, xp=4000, units={"infantry": 60})
    p2 = mkplayer(ses, 2, xp=4000, units={"infantry": 1})
    hop_cap, _ = S.vault_caps(ses, p1)
    p1.vault_hop = hop_cap          # گاوصندوقِ مهاجم پره
    p2.vault_hop = 5_000_000
    ses.commit()
    b, _ = B.launch_attack(ses, p1, 2, "standard", B.default_composition(ses, 1), now=clock())
    clock.t = b.resolve_at
    B.resolve_battle(ses, b.id, clock())
    ses.commit()
    assert ses.get(W.WarBattle, b.id).loot_hop == 0
    assert ses.get(W.WarPlayer, 1).vault_hop <= hop_cap + 1e-6


def test_anti_farm_reduces_rewards_and_blocks_after_steps(ses, clock):
    p1 = mkplayer(ses, 1, xp=4000, units={"infantry": 200})
    p2 = mkplayer(ses, 2, xp=4000, units={"infantry": 1})
    mults = []
    for i in range(6):
        p2.shield_until = None
        ses.commit()
        try:
            b, _ = B.launch_attack(ses, p1, 2, "quick", B.default_composition(ses, 1), now=clock())
        except WarError as e:
            assert "بی‌بازده" in str(e) or "سوخت" in str(e) or "نیرو" in str(e)
            mults.append(0)
            break
        mults.append(b.farm_mult)
        ses.commit()
        clock.t = b.resolve_at
        B.resolve_battle(ses, b.id, clock())
        p1.fuel = 10
        ses.commit()
    assert mults[0] == 1.0 and mults[1] == 0.7 and mults[2] == 0.4 and mults[-1] in (0, 0.15)


def test_shield_blocks_attack_and_is_granted_after_heavy_victory(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 80}, {"infantry": 1})
    clock.t = b.resolve_at
    B.resolve_battle(ses, b.id, clock())
    ses.commit()
    p2 = ses.get(W.WarPlayer, 2)
    assert p2.shield_until and p2.shield_until > clock()
    p3 = mkplayer(ses, 3, xp=4000, units={"infantry": 20})
    with pytest.raises(WarError):
        B.launch_attack(ses, p3, 2, "standard", B.default_composition(ses, 3), now=clock())


def test_attack_breaks_attackers_own_shield(ses, clock):
    p1 = mkplayer(ses, 1, xp=4000, units={"infantry": 20})
    mkplayer(ses, 2, xp=4000, units={"infantry": 3})
    p1.shield_until = clock() + datetime.timedelta(hours=5)
    ses.commit()
    B.launch_attack(ses, p1, 2, "standard", B.default_composition(ses, 1), now=clock())
    assert p1.shield_until is None


def test_revenge_flow(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 80}, {"infantry": 8})
    clock.t = b.resolve_at
    B.resolve_battle(ses, b.id, clock())
    ses.commit()
    opts = B.revenge_options(ses, 2, clock())
    assert len(opts) == 1
    p2 = ses.get(W.WarPlayer, 2)
    p2.fuel = 10
    u = ses.query(W.WarUnit).filter_by(user_id=2, unit_key="infantry").first()
    u.healthy = max(u.healthy, 15)
    ses.commit()
    rb, _ = B.launch_attack(ses, p2, 1, "standard", B.default_composition(ses, 2), mode="revenge", revenge_of=b.id, now=clock())
    assert rb.is_revenge and rb.revenge_of == b.id
    with pytest.raises(WarError):
        B.launch_attack(ses, p2, 1, "quick", {"infantry": 1}, mode="revenge", revenge_of=b.id, now=clock())    # فقط یک‌بار
    assert B.revenge_options(ses, 2, clock()) == []


def test_loser_still_progresses_defeat_is_not_dead_end(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 6}, {"infantry": 40})
    p2.vault_hop = 1
    ses.commit()
    xp0, hop0 = ses.get(W.WarPlayer, 1).xp, ses.get(db.User, 1).hop_points
    clock.t = b.resolve_at
    ev = B.resolve_battle(ses, b.id, clock())
    ses.commit()
    ses.expire_all()
    if ev["outcome"] != "attacker":
        assert ses.get(W.WarPlayer, 1).xp > xp0                   # Participation XP
        assert ses.get(db.User, 1).hop_points >= hop0             # Compensation (هاپِ غرامت)
        assert S.metric_get(ses, 1, "attacks") >= 1               # Achievement Progress


def test_readiness_drops_after_battle_and_prepare_restores_with_cost(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 30})
    clock.t = b.resolve_at
    B.resolve_battle(ses, b.id, clock())
    ses.commit()
    p1 = ses.get(W.WarPlayer, 1)
    assert p1.readiness < 100
    before = ses.get(db.User, 1).hop_points
    old = p1.readiness
    cost, o, n = B.prepare_army(ses, p1)
    assert n > old and ses.get(db.User, 1).hop_points < before       # Prepare هزینه داره
    # Prepare تعمیر نمی‌کنه
    u = ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first()
    dmg = u.damaged
    assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first().damaged == dmg


def test_raid_chain_readiness_keeps_falling(ses, clock):
    p1 = mkplayer(ses, 1, xp=4000, units={"infantry": 300})
    for i in range(2, 5):
        mkplayer(ses, i, xp=4000, units={"infantry": 3})
    ready = []
    for t in (2, 3, 4):
        b, _ = B.launch_attack(ses, p1, t, "quick", B.default_composition(ses, 1, "half"), now=clock())
        ses.commit()
        clock.t = b.resolve_at
        B.resolve_battle(ses, b.id, clock())
        ses.commit()
        ready.append(ses.get(W.WarPlayer, 1).readiness)
    assert ready[0] > ready[1] > ready[2]


def test_fuel_limits_attacks_and_regenerates(ses, clock):
    p1 = mkplayer(ses, 1, xp=4000, units={"infantry": 300})
    for i in range(2, 9):
        mkplayer(ses, i, xp=4000, units={"infantry": 3})
    p1.fuel = 1
    ses.commit()
    B.launch_attack(ses, p1, 2, "quick", B.default_composition(ses, 1, "half"), now=clock())
    with pytest.raises(WarError):
        B.launch_attack(ses, p1, 3, "quick", B.default_composition(ses, 1, "half"), now=clock())
    clock.adv(hours=1)
    S.sync_player(ses, p1)
    assert p1.fuel >= 1.9


def test_concurrent_active_operation_limit(ses, clock):
    p1 = mkplayer(ses, 1, xp=4000, units={"infantry": 300})
    for i in range(2, 6):
        mkplayer(ses, i, xp=4000, units={"infantry": 3})
    n = 0
    with pytest.raises(WarError) as ei:
        for t in (2, 3, 4, 5):
            B.launch_attack(ses, p1, t, "quick", {"infantry": 20}, now=clock())
            n += 1
    assert n == B.max_active_ops(ses, p1) and "عملیات" in str(ei.value)


def test_duplicate_battle_unique_index_guard(ses, clock):
    p1, p2, b = _duel(ses, clock)
    from sqlalchemy.exc import IntegrityError
    ses.add(W.WarBattle(attacker_id=1, defender_id=2, btype="quick", resolve_at=clock(), army_json="{}"))
    with pytest.raises(IntegrityError):
        ses.flush()
    ses.rollback()


def test_cancel_returns_units_and_refunds(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 12})
    money = ses.get(db.User, 1).hop_points
    assert B.cancel_battle(ses, b.id, "admin_cancel", 100)
    ses.commit()
    assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first().healthy == 12
    assert ses.get(db.User, 1).hop_points > money
    assert not B.cancel_battle(ses, b.id, "admin_cancel", 100)                 # Idempotent


def test_self_and_clanmate_attack_blocked(ses, clock):
    p1 = mkplayer(ses, 1, xp=8000, th=2, units={"infantry": 20})
    p2 = mkplayer(ses, 2, xp=8000, th=2, units={"infantry": 20})
    with pytest.raises(WarError):
        B.launch_attack(ses, p1, 1, "quick", {"infantry": 5}, now=clock())
    c, _ = C.create_clan(ses, p1, "Wolves", "WLF")
    r = C.send_request(ses, p2, c.id)
    C.decide_request(ses, 1, r.id, True)
    ses.commit()
    p2.shield_until = None
    with pytest.raises(WarError):
        B.launch_attack(ses, p1, 2, "quick", {"infantry": 5}, now=clock())


# ---------------------------------------------------------------- Formula ---
def test_formula_versioning_old_battles_keep_their_version(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 30})
    assert b.formula_version == 1
    db.cfg_set(ses, "war_f_k", "4.0")
    v = S.publish_formula(ses, 999, "test")
    assert v == 2 and S.ci(ses, "war_formula_version") == 2
    params1, _ = S.formula_params(ses, 1)
    params2, _ = S.formula_params(ses, 2)
    assert params1.k == 2.2 and params2.k == 4.0
    clock.t = b.resolve_at
    B.resolve_battle(ses, b.id, clock())
    ses.commit()
    assert ses.get(W.WarBattle, b.id).formula_version == 1                   # نبردِ قدیمی با v1 محاسبه شد
    ses.get(W.WarPlayer, 2).shield_until = None
    p3 = mkplayer(ses, 3, xp=4000, units={"infantry": 30})
    b3, _ = B.launch_attack(ses, p3, 2, "quick", B.default_composition(ses, 3), now=clock())
    assert b3.formula_version == 2


def test_live_draft_does_not_affect_published_version(ses, clock):
    db.cfg_set(ses, "war_f_k", "9.9")
    params, ver = S.formula_params(ses)
    assert params.k == 2.2 and ver == 1


def test_counter_matrix_publish_rejected_when_invalid(ses):
    bad = json.loads(W.FORMULA_KEYS["war_f_counter_matrix"])
    bad["ground"]["air"] = 5
    db.cfg_set(ses, "war_f_counter_matrix", json.dumps(bad))
    with pytest.raises(WarError):
        S.publish_formula(ses, 1)


# ---------------------------------------------------------------- Rewards ---
def test_reward_rules_are_data_driven_with_daily_caps_and_events(ses):
    p = mkplayer(ses, 1, xp=0)
    rule = ses.get(W.WarRewardRule, "battle_win")
    rule.xp, rule.hop_ref_hours, rule.hop_abs, rule.daily_cap_hop = 100, 0, 1000, 1500
    ses.commit()
    a = S.give_reward(ses, 1, "battle_win", _player=p)
    b = S.give_reward(ses, 1, "battle_win", _player=p)
    assert a["hop"] == 1000 and b["hop"] == 500                               # سقفِ روزانه
    ses.add(W.WarEvent(name="2x", start_at=T0 - datetime.timedelta(hours=1), end_at=T0 + datetime.timedelta(hours=1), xp_mult=2.0))
    ses.commit()
    c = S.give_reward(ses, 1, "battle_win", _player=p)
    assert c["xp"] == 200                                                     # Double XP event


def test_reward_antifarm_multiplier_applies(ses):
    p = mkplayer(ses, 1)
    a = S.give_reward(ses, 1, "battle_win", farm_mult=1.0, _player=p)
    b = S.give_reward(ses, 1, "battle_win", farm_mult=0.4, _player=p)
    assert abs(b["xp"] - a["xp"] * 0.4) < 1e-6


def test_quests_achievements_progress_and_claim_once(ses, clock):
    p = mkplayer(ses, 1, xp=500)
    S.metric_bump(ses, 1, "wins", 1)
    assert S.has_achievement(ses, 1, "first_victory")
    qs = {q.key: (pr, cl) for q, pr, cl in S.quests_for(ses, p, "daily")}
    assert qs["d_win1"][0] == 1
    q, r = S.claim_quest(ses, p, "d_win1")
    assert r["xp"] > 0
    with pytest.raises(WarError):
        S.claim_quest(ses, p, "d_win1")                                       # دبل‌کلیم ممنوع
    # مأموریتِ ویژه آنلاک می‌کنه
    for _ in range(5):
        S.metric_bump(ses, 1, "wins", 1)
    S.claim_quest(ses, p, "s_first_win")
    p.xp, p.wins = 99999, 5
    assert S.feature_state(ses, p, "spy") == "unlocked"


# ---------------------------------------------------------------- Clan ------
def mkclan(ses, leader=1, name="Black Wolves", tag="BW"):
    p = mkplayer(ses, leader, xp=8000, th=3, units={"infantry": 20})
    c, _ = C.create_clan(ses, p, name, tag)
    ses.commit()
    return c


def join(ses, clan, uid, rank=1, **kw):
    p = mkplayer(ses, uid, xp=kw.get("xp", 8000), th=kw.get("th", 3), units={"infantry": 15})
    r = C.send_request(ses, p, clan.id)
    C.decide_request(ses, clan.leader_id, r.id, True)
    m = C.member_of(ses, uid)
    m.rank = rank
    ses.commit()
    return p


def test_clan_create_costs_and_rules(ses):
    p = mkplayer(ses, 1, xp=8000, th=3)
    before = ses.get(db.User, 1).hop_points
    c, cost = C.create_clan(ses, p, "گرگ‌های سیاه", "grg")
    spend = ses.query(W.HopTransaction).filter_by(user_id=1, reason="war:clan_create").one()
    assert c.tag == "GRG" and spend.amount == -cost and cost > 0 and spend.type == "SPEND"
    with pytest.raises(WarError):
        C.create_clan(ses, p, "Another", "AN")                    # قبلاً عضوه
    mkplayer(ses, 2, xp=8000, th=3)
    with pytest.raises(WarError):
        C.create_clan(ses, S.get_player(ses, 2), "گرگ‌های سیاه", "XX")          # نامِ تکراری
    low = mkplayer(ses, 3, xp=8000, th=1)
    with pytest.raises(WarError):
        C.create_clan(ses, low, "NewClan", "NC")                   # مقرِ کم


def test_join_requires_request_and_approval_with_applicant_card(ses):
    c = mkclan(ses)
    p2 = mkplayer(ses, 2, xp=8000, th=3, trophies=120)
    assert p2.clan_id is None
    r = C.send_request(ses, p2, c.id)
    assert p2.clan_id is None                                     # فقط درخواست؛ عضو نشده
    card = C.applicant_card(ses, 2)
    assert card["level"] >= 1 and card["trophies"] == 120 and "th" in card
    with pytest.raises(WarError):
        C.send_request(ses, p2, c.id)                              # درخواستِ تکراری
    # عضوِ عادی نمی‌تونه قبول کنه
    p3 = join(ses, c, 3)
    with pytest.raises(WarError):
        C.decide_request(ses, 3, r.id, True)
    C.decide_request(ses, 1, r.id, True)
    ses.commit()
    assert S.get_player(ses, 2).clan_id == c.id and C.member_of(ses, 2).rank == 1


def test_co_leader_can_accept_but_officer_below_cannot(ses):
    c = mkclan(ses)
    join(ses, c, 2, rank=4)       # معاون
    join(ses, c, 3, rank=3)       # افسر
    p4 = mkplayer(ses, 4, xp=8000, th=3)
    r = C.send_request(ses, p4, c.id)
    with pytest.raises(WarError):
        C.decide_request(ses, 3, r.id, True)
    C.decide_request(ses, 2, r.id, True)
    assert S.get_player(ses, 4).clan_id == c.id


def test_rejection_and_cancel_and_expiry(ses, clock):
    c = mkclan(ses)
    p2 = mkplayer(ses, 2, xp=8000, th=3)
    r = C.send_request(ses, p2, c.id)
    C.decide_request(ses, 1, r.id, False)
    assert S.get_player(ses, 2).clan_id is None
    r2 = C.send_request(ses, p2, c.id)
    C.cancel_request(ses, 2, r2.id)
    r3 = C.send_request(ses, p2, c.id)
    ses.commit()
    clock.adv(hours=49)
    assert C.expire_requests(ses, clock()) == 1


def test_clan_max_members_25_hard_cap(ses):
    c = mkclan(ses)
    c.level = 10
    ses.commit()
    assert C.capacity(ses, c) == 25
    for uid in range(2, 26):
        join(ses, c, uid)
    assert C.member_count(ses, c.id) == 25
    p = mkplayer(ses, 100, xp=8000, th=3)
    with pytest.raises(WarError):
        C.send_request(ses, p, c.id)                                # پره
    db.cfg_set(ses, "war_clan_max_members", "30")                   # حتی اگه ادمین زیاد کنه هم از کانفیگ می‌خونه
    assert C.capacity(ses, c) == 28 or C.capacity(ses, c) >= 25


def test_capacity_grows_with_clan_level(ses):
    c = mkclan(ses)
    caps = []
    for lv in (1, 3, 6, 10):
        c.level = lv
        caps.append(C.capacity(ses, c))
    assert caps == sorted(caps) and caps[0] == 10 and caps[-1] == 25


def test_five_ranks_named_and_perms_configurable(ses):
    assert len(C.rank_names(ses)) == 5
    assert C.rank_names(ses)[0] == "عضو" and C.rank_names(ses)[4] == "سازنده"
    c = mkclan(ses)
    join(ses, c, 2, rank=4)
    m4, m1 = C.member_of(ses, 2), C.member_of(ses, 1)
    assert C.can(ses, m4, "kick") and not C.can(ses, m4, "promote") and C.can(ses, m1, "promote")
    perms = C.perms(ses)
    perms["kick"] = 5
    db.cfg_set(ses, "war_clan_perms", json.dumps(perms))
    assert not C.can(ses, m4, "kick")                                # دسترسی‌ها ادمین‌محور


def test_promotion_demotion_only_by_leader_with_rules(ses):
    c = mkclan(ses)
    join(ses, c, 2)
    join(ses, c, 3, rank=4)
    assert C.set_rank(ses, 1, 2, 3) == (1, 3)                        # ارتقا
    assert C.set_rank(ses, 1, 2, 2) == (3, 2)                        # تنزل
    with pytest.raises(WarError):
        C.set_rank(ses, 3, 2, 3)                                     # معاون اجازه‌ی ارتقا نداره
    with pytest.raises(WarError):
        C.set_rank(ses, 1, 2, 5)                                     # سازنده‌شدن فقط با انتقالِ مالکیت
    with pytest.raises(WarError):
        C.set_rank(ses, 1, 1, 3)                                     # خودش
    with pytest.raises(WarError):
        C.set_rank(ses, 1, 2, 2)                                     # تکراری
    assert any("ارتقا" in x.text for x in ses.query(W.WarClanLog).filter_by(clan_id=c.id))


def test_kick_rules_coleader_only_lowest_rank(ses):
    c = mkclan(ses)
    join(ses, c, 2, rank=4)       # معاون
    join(ses, c, 3, rank=1)
    join(ses, c, 4, rank=2)
    join(ses, c, 5, rank=3)
    with pytest.raises(WarError):
        C.kick(ses, 2, 4)         # معاون نمی‌تونه رتبه‌ی ۲ رو بزنه
    with pytest.raises(WarError):
        C.kick(ses, 2, 5)
    with pytest.raises(WarError):
        C.kick(ses, 2, 1)         # سازنده رو نمی‌تونه
    with pytest.raises(WarError):
        C.kick(ses, 4, 3)         # رتبه‌ی پایین‌تر از معاون اجازه‌ی اخراج نداره
    C.kick(ses, 2, 3)
    ses.commit()
    assert S.get_player(ses, 3).clan_id is None and C.member_of(ses, 3) is None
    C.kick(ses, 1, 5)              # سازنده هر رتبه‌ای رو می‌تونه
    assert C.member_of(ses, 5) is None
    with pytest.raises(WarError):
        C.kick(ses, 1, 1)


def test_transfer_leadership(ses):
    c = mkclan(ses)
    join(ses, c, 2, rank=4)
    join(ses, c, 3)
    with pytest.raises(WarError):
        C.transfer_leadership(ses, 2, 3)                              # فقط سازنده
    C.transfer_leadership(ses, 1, 2)
    ses.commit()
    ses.refresh(c)
    assert c.leader_id == 2 and C.member_of(ses, 2).rank == 5 and C.member_of(ses, 1).rank == 4
    with pytest.raises(WarError):
        C.set_rank(ses, 1, 3, 2)                                      # سازنده‌ی قبلی دیگه ارتقا نمی‌ده


def test_leave_rules_keep_personal_assets_and_cooldown(ses, clock):
    c = mkclan(ses)
    p2 = join(ses, c, 2)
    units_before = ses.query(W.WarUnit).filter_by(user_id=2, unit_key="infantry").first().healthy
    with pytest.raises(WarError):
        C.leave_clan(ses, 1)                                          # سازنده تا وقتی عضو هست نمی‌تونه بره
    C.leave_clan(ses, 2)
    ses.commit()
    assert S.get_player(ses, 2).clan_id is None
    assert ses.query(W.WarUnit).filter_by(user_id=2, unit_key="infantry").first().healthy == units_before
    assert any("ترک" in x.text for x in ses.query(W.WarClanLog).filter_by(clan_id=c.id))        # Historical Contribution در لاگ
    with pytest.raises(WarError):
        C.send_request(ses, S.get_player(ses, 2), c.id)               # کول‌دان
    clock.adv(hours=13)
    C.send_request(ses, S.get_player(ses, 2), c.id)


def test_suggested_clans_and_search(ses):
    c1 = mkclan(ses, 1, "Wolves", "WLF")
    c2 = mkclan(ses, 2, "Iron Empire", "IRN")
    p = mkplayer(ses, 3, xp=8000, th=3, trophies=10)
    sug = [c.id for c, _ in C.suggest_clans(ses, p)]
    assert set(sug) == {c1.id, c2.id}
    c2.min_trophies = 5000
    ses.commit()
    assert [c.id for c, _ in C.suggest_clans(ses, p)] == [c1.id]      # شرطِ ورود رعایت می‌شه
    assert [c.id for c, _ in C.search_clans(ses, "iron")] == [c2.id]
    assert [c.id for c, _ in C.search_clans(ses, "wlf")] == [c1.id]
    with pytest.raises(WarError):
        C.search_clans(ses, "a")


def test_closed_clan_rejects_requests(ses):
    c = mkclan(ses)
    C.set_join_rules(ses, 1, mode="closed")
    with pytest.raises(WarError):
        C.send_request(ses, mkplayer(ses, 2, xp=8000, th=3), c.id)


def test_pending_request_limit(ses):
    clans = [mkclan(ses, i, f"Clan{i}", f"C{i}") for i in range(1, 6)]
    p = mkplayer(ses, 50, xp=8000, th=3)
    for c in clans[:3]:
        C.send_request(ses, p, c.id)
    with pytest.raises(WarError):
        C.send_request(ses, p, clans[3].id)


# ---------------------------------------------------------------- Treasury --
def test_treasury_deposit_contribution_not_purchasable_and_logged(ses):
    c = mkclan(ses)
    p = S.get_player(ses, 1)
    ref = S.player_ref(ses, p)
    amt, gain = C.deposit(ses, p, ref * 50)
    assert ses.get(W.WarClan, c.id).treasury == amt
    tx = ses.query(W.WarClanTx).filter_by(clan_id=c.id).order_by(W.WarClanTx.id.desc()).first()
    assert tx.type == "deposit" and tx.user_id == 1 and tx.amount == amt and tx.balance_after == amt
    assert gain <= S.cf(ses, "war_deposit_contrib_daily_cap")          # با پول نمی‌شه بی‌نهایت مشارکت خرید
    _, gain2 = C.deposit(ses, p, ref * 50)
    assert gain2 == 0 or gain + gain2 <= S.cf(ses, "war_deposit_contrib_daily_cap") + 1e-6


def test_deposit_below_minimum_and_capacity(ses):
    c = mkclan(ses)
    p = S.get_player(ses, 1)
    with pytest.raises(WarError):
        C.deposit(ses, p, 10)
    c.treasury = C.treasury_cap(ses, c)
    with pytest.raises(WarError):
        C.deposit(ses, p, S.player_ref(ses, p))


def test_treasury_not_owned_by_leader_and_no_free_withdrawal(ses):
    c = mkclan(ses)
    C.treasury_tx(ses, c, 1_000_000, "deposit", "seed")
    with pytest.raises(WarError):
        C.treasury_tx(ses, c, -2_000_000, "expense", "too much")
    before = ses.get(db.User, 1).hop_points
    assert ses.get(db.User, 1).hop_points == before                    # هیچ API برداشتِ مستقیمی برای لیدر نیست
    assert not hasattr(C, "withdraw")


def test_settlement_pool_caps_and_resets(ses, clock):
    c = mkclan(ses)
    for uid in (2, 3, 4):
        join(ses, c, uid)
    c.treasury = 10_000_000
    for uid, w in ((1, 100), (2, 50), (3, 10), (4, 5)):
        C.member_of(ses, uid).week_contribution = w
    ses.commit()
    assert C.run_settlement(ses, c, clock()) is None                   # هنوز وقتش نشده
    clock.adv(days=8)
    r = C.run_settlement(ses, c, clock())
    pool = 10_000_000 * 0.2
    assert r["pool"] == pool and r["paid"] <= pool
    assert max(a for _, a in r["payouts"]) <= pool * 0.25 + 1           # سقفِ سهمِ هر عضو
    assert c.treasury >= 10_000_000 - pool - 1                          # هیچ‌کس کلِ خزانه رو نمی‌بره
    assert all(m.week_contribution == 0 for m in C.members_list(ses, c.id))
    assert {u for u, _ in r["payouts"]} == {1, 2}                       # زیرِ حداقلِ مشارکت (۲۰) سهمی نمی‌گیرن


def test_clan_xp_levels_up_and_unlocks_capacity(ses):
    c = mkclan(ses)
    cap0 = C.capacity(ses, c)
    need = C.clan_xp_required(ses, 1)
    C.clan_add_xp(ses, c.id, need + 1)
    assert ses.get(W.WarClan, c.id).level == 2 and C.capacity(ses, ses.get(W.WarClan, c.id)) > cap0


def test_research_costs_from_treasury_and_completes(ses, clock):
    c = mkclan(ses)
    c.level = 4
    c.treasury = 10 ** 12
    ses.get(W.WarPlayer, 1).xp = 20000
    ses.commit()
    cost, mins = C.start_research(ses, 1, "r_atk")
    assert ses.get(W.WarClan, c.id).treasury == 10 ** 12 - cost
    with pytest.raises(WarError):
        C.start_research(ses, 1, "r_def")                               # یکی در جریان
    clock.adv(minutes=mins + 1)
    assert C.finish_research(ses, clock()) == 1
    assert S.clan_bonus_pct(ses, c.id, "atk_pct") > 0


# ---------------------------------------------------------------- Coup ------
def _coup_setup(ses, clock):
    c = mkclan(ses)
    p = join(ses, c, 2, rank=4, xp=20000)
    m = C.member_of(ses, 2)
    m.joined_at = clock() - datetime.timedelta(days=10)
    m.contribution = 500
    C.member_of(ses, 1).contribution = 100
    c.treasury = 100_000_000
    ses.get(W.WarPlayer, 2).xp = 20000
    ses.add(W.WarAchievement(user_id=2, key="first_cw"))      # کودتا مخفیه تا دستاوردِ «اولین جنگ قبیله»
    ses.commit()
    return c, S.get_player(ses, 2)


def test_coup_requirements(ses, clock):
    c = mkclan(ses)
    p = join(ses, c, 2, rank=1)
    p.xp = 100
    ses.commit()
    with pytest.raises(WarError):
        C.coup_preview(ses, p, clock())        # ناآماده (قفل/XP/مشارکت)
    leader = S.get_player(ses, 1)
    with pytest.raises(WarError):
        C.coup_preview(ses, leader, clock())


class FixedRng:
    def __init__(self, v):
        self.v = v

    def random(self):
        return self.v


def test_coup_success_risk_reward_and_cooldowns(ses, clock):
    c, p = _coup_setup(ses, clock)
    xp0, hop0, tr0 = p.xp, ses.get(db.User, 2).hop_points, c.treasury
    ok, pv, reward = C.attempt_coup(ses, p, clock(), FixedRng(0.0))
    ses.commit()
    assert ok and reward > 0
    ach_xp = ses.get(W.WarAchievementDef, "coup_success").xp
    assert p.xp == xp0 - pv["xp_cost"] + ach_xp                             # Personal XP کم می‌شه (+ XPِ دستاوردِ کودتا)
    tx = ses.query(W.HopTransaction).filter_by(user_id=2, reason="war:coup_reward").one()
    assert tx.amount == reward and tx.type == "BONUS"                        # 💰 Reward با لجر
    assert ses.get(db.User, 2).hop_points >= hop0 + reward
    assert ses.get(W.WarClan, c.id).treasury == tr0 - reward                # از خزانه، نه پولِ بی‌منشأ
    assert reward <= tr0 * S.cf(ses, "war_coup_reward_treasury_pct") / 100 + 1
    assert C.member_of(ses, 2).rank == 5 and ses.get(W.WarClan, c.id).leader_id == 2
    assert C.member_of(ses, 1).rank == 3
    with pytest.raises(WarError):
        C.coup_preview(ses, p, clock())                                      # کول‌دان


def test_coup_failure_penalty(ses, clock):
    c, p = _coup_setup(ses, clock)
    xp0, contrib0 = p.xp, C.member_of(ses, 2).contribution
    ok, pv, reward = C.attempt_coup(ses, p, clock(), FixedRng(0.999))
    assert not ok and reward == 0
    assert p.xp == xp0 - pv["xp_cost"] - S.cf(ses, "war_coup_fail_xp_extra")
    assert C.member_of(ses, 2).contribution < contrib0
    assert ses.get(W.WarClan, c.id).leader_id == 1


def test_coup_chance_bounded(ses, clock):
    c, p = _coup_setup(ses, clock)
    pv = C.coup_preview(ses, p, clock())
    assert S.cf(ses, "war_coup_base_chance_pct") <= pv["chance"] <= S.cf(ses, "war_coup_max_chance_pct")


# ---------------------------------------------------------------- Diplomacy -
def test_diplomacy_truce_ally_enemy_effects(ses, clock):
    a = mkclan(ses, 1, "Alpha", "AAA")
    b = mkclan(ses, 2, "Beta", "BBB")
    for c in (a, b):
        c.level = 4
    for uid in (1, 2):
        S.get_player(ses, uid).xp = 30000
    S.metric_bump(ses, 1, "joined_clan", 0)
    ses.commit()
    # دیپلماسی نیاز به دستاورد first_clan داره (سازنده‌ها هنگام ساخت گرفتن)
    r, pending = C.propose_relation(ses, 1, b.id, "truce")
    assert pending
    C.respond_relation(ses, 2, r.id, True)
    assert "آتش‌بس" in B.relation_blocks_attack(ses, a.id, b.id, clock())
    clock.adv(hours=13)
    assert B.relation_blocks_attack(ses, a.id, b.id, clock()) == ""        # آتش‌بس تموم شد
    r, _ = C.propose_relation(ses, 1, b.id, "ally")
    C.respond_relation(ses, 2, r.id, True)
    assert "هم‌پیمان" in B.relation_blocks_attack(ses, a.id, b.id, clock())
    with pytest.raises(WarError):
        C.propose_relation(ses, 1, a.id, "ally")                            # خودش
    C.break_relation(ses, 1, b.id)
    assert B.relation_blocks_attack(ses, a.id, b.id, clock()) == ""


# ---------------------------------------------------------------- Donation --
def test_donation_is_conserving_and_capped(ses):
    c = mkclan(ses)
    p2 = join(ses, c, 2)
    ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first().healthy = 10
    ses.commit()
    req = C.request_units(ses, p2, "infantry", 5)
    before = (ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first().healthy, ses.query(W.WarUnit).filter_by(user_id=2, unit_key="infantry").first().healthy)
    qty, r = C.donate(ses, S.get_player(ses, 1), req.id, 3)
    after = (ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first().healthy, ses.query(W.WarUnit).filter_by(user_id=2, unit_key="infantry").first().healthy)
    assert qty == 3 and sum(after) == sum(before) and after[1] == before[1] + 3        # انتقالِ واقعی؛ تولیدِ چیزِ جدید نیست
    C.donate(ses, S.get_player(ses, 1), req.id, 10)
    assert ses.get(W.WarDonation, req.id).status == "done"
    with pytest.raises(WarError):
        C.donate(ses, S.get_player(ses, 1), req.id, 1)


# ---------------------------------------------------------------- Clan war --
def _two_clans(ses, clock, n=3):
    a = mkclan(ses, 1, "Black Wolves", "BW")
    b = mkclan(ses, 100, "Iron Empire", "IE")
    for c in (a, b):
        c.level = 2
    for i in range(1, n):
        join(ses, a, 1 + i)
        join(ses, b, 100 + i)
    for uid in [1] + [1 + i for i in range(1, n)] + [100] + [100 + i for i in range(1, n)]:
        p = S.get_player(ses, uid)
        p.xp = 30000
        u = ses.query(W.WarUnit).filter_by(user_id=uid, unit_key="infantry").first()
        u.healthy = 120 if uid < 100 else 30                     # A قوی‌تره
    a.treasury = b.treasury = 0
    ses.commit()
    return a, b


def test_clan_war_full_cycle_with_loser_consolation(ses, clock):
    a, b = _two_clans(ses, clock)
    assert C.search_war(ses, 1, 3) == 3
    C.search_war(ses, 100, 3)
    ses.commit()
    made = C.match_wars(ses, clock())
    assert len(made) == 1
    war = ses.get(W.WarClanWar, made[0])
    assert war.status == "prep"
    for uid in (1, 2, 3, 100, 101, 102):
        C.join_war(ses, S.get_player(ses, uid), war.id)
    with pytest.raises(WarError):
        C.join_war(ses, S.get_player(ses, 2), war.id)                  # ثبت‌نامِ تکراری
    with pytest.raises(WarError):
        C.cw_launch(ses, S.get_player(ses, 1), war.id, 100, {"infantry": 10}, now=clock())      # هنوز آماده‌سازیه
    clock.t = war.prep_end_at + datetime.timedelta(seconds=1)
    ev = C.advance_wars(ses, clock())
    assert [e["type"] for e in ev] == ["cw_start"] and war.status == "active"
    # هر عضو ۲ حمله دارد؛ تیمِ B هم حمله می‌کنه ولی ضعیف‌تره
    for uid, tgt in ((1, 100), (2, 101), (3, 102), (100, 1), (101, 2)):
        p = S.get_player(ses, uid)
        p.fuel = 10
        bt, _ = C.cw_launch(ses, p, war.id, tgt, B.default_composition(ses, uid, "half"), now=clock())
        assert bt.clan_war_id == war.id
    me1 = ses.query(W.WarClanWarMember).filter_by(war_id=war.id, user_id=1).first()
    me1.attacks_used = S.ci(ses, "war_cw_attacks_per_member")
    with pytest.raises(WarError):
        C.cw_launch(ses, S.get_player(ses, 1), war.id, 101, {"infantry": 2}, now=clock())    # سقفِ حمله‌ی هر عضو
    me1.attacks_used = 1
    ses.commit()
    # نبردها resolve می‌شن
    for bt in ses.query(W.WarBattle).filter_by(clan_war_id=war.id).all():
        clock.t = max(clock.t, bt.resolve_at)
    for bt in ses.query(W.WarBattle).filter_by(clan_war_id=war.id).all():
        B.resolve_battle(ses, bt.id, clock())
    ses.commit()
    clock.t = war.end_at + datetime.timedelta(seconds=1)
    ev = C.advance_wars(ses, clock())
    ses.commit()
    ses.refresh(war)
    assert war.status == "ended" and war.winner in ("a", "b", "draw")
    sa, sb, *_ = C.war_scores(ses, war)
    assert (war.stars_a, war.stars_b) == (sa, sb)
    loser_clan = war.clan_b if war.winner == "a" else war.clan_a
    if war.winner in ("a", "b"):
        for m in C.war_roster(ses, war.id, loser_clan):
            if m.attacks_used:
                assert S.metric_get(ses, m.user_id, "xp_gain") > 0          # حتی بازنده XP/غرامت می‌گیره
    assert ses.get(W.WarClan, a.id).xp > 0 and ses.get(W.WarClan, b.id).xp > 0


def test_clan_war_cancelled_when_not_enough_participants(ses, clock):
    a, b = _two_clans(ses, clock)
    C.search_war(ses, 1, 3)
    C.search_war(ses, 100, 3)
    made = C.match_wars(ses, clock())
    war = ses.get(W.WarClanWar, made[0])
    C.join_war(ses, S.get_player(ses, 1), war.id)
    clock.t = war.prep_end_at + datetime.timedelta(seconds=1)
    ev = C.advance_wars(ses, clock())
    assert ev[0]["type"] == "cw_cancel" and war.status == "ended" and war.winner == "cancelled"


def test_allied_clans_never_matched(ses, clock):
    a, b = _two_clans(ses, clock)
    ses.add(W.WarRelation(clan_a=min(a.id, b.id), clan_b=max(a.id, b.id), kind="ally"))
    C.search_war(ses, 1, 3)
    C.search_war(ses, 100, 3)
    assert C.match_wars(ses, clock()) == []


def test_cannot_leave_clan_during_war(ses, clock):
    a, b = _two_clans(ses, clock)
    C.search_war(ses, 1, 3)
    C.search_war(ses, 100, 3)
    war = ses.get(W.WarClanWar, C.match_wars(ses, clock())[0])
    C.join_war(ses, S.get_player(ses, 2), war.id)
    with pytest.raises(WarError):
        C.leave_clan(ses, 2)


# ---------------------------------------------------------------- Restart ---
def test_battle_survives_restart_and_tick_resolves_once(ses, clock):
    """Bot/Server Restart: همه‌چیز فقط در DB بود؛ tick جدید (Session جدید) نبرد رو تموم می‌کنه، فقط یک‌بار."""
    p1, p2, b = _duel(ses, clock, {"infantry": 30})
    bid = b.id
    ses.close()
    # «ری‌استارت»: هیچ state ای در حافظه نیست؛ tick با Session تازه
    clock.t = b.resolve_at + datetime.timedelta(seconds=5)
    ev1 = C.run_tick(clock())
    ev2 = C.run_tick(clock())
    s = db.get_session()
    try:
        bt = s.get(W.WarBattle, bid)
        assert bt.status == "resolved" and [e for e in ev1 if e["type"] == "battle"] and not [e for e in ev2 if e["type"] == "battle"]
        rewards = s.query(W.HopTransaction).filter(W.HopTransaction.reference_id == f"battle:{bid}").count()
        assert rewards <= 4
    finally:
        s.close()


def test_failed_resolution_rolls_back_and_retries(ses, clock, monkeypatch):
    p1, p2, b = _duel(ses, clock, {"infantry": 30})
    bid = b.id
    clock.t = b.resolve_at + datetime.timedelta(seconds=1)
    calls = {"n": 0}
    real = S.give_reward

    def boom(*a, **k):
        calls["n"] += 1
        if calls["n"] == 1:
            raise RuntimeError("crash in the middle")
        return real(*a, **k)

    monkeypatch.setattr(S, "give_reward", boom)
    C.run_tick(clock())                       # شکست می‌خوره ← rollback
    s = db.get_session()
    bt = s.get(W.WarBattle, bid)
    assert bt.status == "marching"            # هیچ نیمه‌کاره‌ای ذخیره نشد
    assert s.query(W.HopTransaction).filter(W.HopTransaction.reference_id == f"battle:{bid}").count() == 0
    u = s.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first()
    assert u.healthy == 0                     # نیروها هنوز اعزامی‌ان (دوبار کم نشدن)
    s.close()
    C.run_tick(clock())                       # Retry موفق
    s = db.get_session()
    assert s.get(W.WarBattle, bid).status == "resolved"
    assert s.query(W.HopTransaction).filter(W.HopTransaction.reference_id == f"battle:{bid}").count() >= 1
    s.close()


def test_stuck_battles_expire_with_partial_refund(ses, clock):
    p1, p2, b = _duel(ses, clock, {"infantry": 12})
    bid = b.id
    ses.close()
    clock.adv(hours=30)
    s = db.get_session()
    db.cfg_set(s, "war_battle_expire_hours", "0")
    s.commit()
    s.close()
    # tick اول resolve می‌کنه (نه expire)، چون due است
    C.run_tick(clock())
    s = db.get_session()
    assert s.get(W.WarBattle, bid).status in ("resolved", "cancelled")
    s.close()


def test_timers_persist_buildings_jobs_shield(ses, clock):
    p = mkplayer(ses, 1, xp=3000, th=2)
    b, hop, mat, secs = S.start_upgrade(ses, p, "mine")
    S.enqueue_train(ses, p, "drone", 2)
    p.shield_until = clock() + datetime.timedelta(hours=4)
    ses.commit()
    ses.close()
    clock.adv(days=1)
    s = db.get_session()
    p = S.sync_player(s, S.get_player(s, 1))
    s.commit()
    assert s.query(W.WarBuilding).filter_by(user_id=1, key="mine").first().level == 2
    assert s.query(W.WarUnit).filter_by(user_id=1, unit_key="drone").first().healthy == 2
    s.close()


# ---------------------------------------------------------------- Buildings -
def test_upgrade_builders_cap_and_th_gate(ses, clock):
    p = mkplayer(ses, 1, xp=3000, th=1)
    S.start_upgrade(ses, p, "mine")
    with pytest.raises(WarError):
        S.start_upgrade(ses, p, "depot")                   # فقط ۱ سازنده
    clock.adv(hours=7)
    S.sync_player(ses, p)
    S.start_upgrade(ses, p, "mine")                        # سطح ۳ (سقفِ TH1 = 3)
    clock.adv(hours=7)
    S.sync_player(ses, p)
    with pytest.raises(WarError):
        S.start_upgrade(ses, p, "mine")                    # سقف با مقرِ فعلی


def test_hidden_buildings_require_th(ses):
    p = mkplayer(ses, 1, xp=3000, th=1)
    with pytest.raises(WarError):
        S.start_upgrade(ses, p, "aa")


def test_upgrade_costs_scale_with_factory_economy(ses):
    d = ses.get(W.WarBuildingDef, "mine")
    c_before = S.building_upgrade_cost(ses, d, 5)[0]
    cfg = ses.get(db.Config, "factory_base_production") if hasattr(db, "Config") else None
    db.cfg_set(ses, "war_income_multiplier", "4")
    c_after = S.building_upgrade_cost(ses, d, 5)[0]
    assert c_after > c_before                              # قیمت‌ها هم‌تراز با درآمد (اقتصاد بالانس می‌مونه)


# ---------------------------------------------------------------- Triggers --
@pytest.mark.parametrize("text,panel", [
    ("اتاق جنگ هاپویی", "war_room"), ("  اتاق   جنگ هاپويي  ", "war_room"), ("اتاق‌جنگ هاپویی", "war_room"),
    ("جنگ هاپویی", "war_room"), ("پنل هاپویی", "main"), ("پنل جنگ هاپویی", "war_room"), ("حمله هاپویی!", "attack"),
    ("حمله فردی هاپویی", "attack"), ("حمله قبیله ای هاپویی", "clan_attack"), ("حمله قبیله‌ای هاپویی", "clan_attack"),
    ("قبیله هاپویی", "clan"), ("گزارش جنگ هاپویی", "history"), ("وضعیت جنگ هاپویی", "status"), ("تجهیزات هاپویی", "units"),
    ("منابع هاپویی", "resources"), ("XP هاپویی", "xp"), ("xp هاپویی", "xp"), ("پروفایل هاپويي", "profile"), ("ماموریت هاپویی", "quests"),
    ("خزانه هاپویی", "treasury"), ("دیپلماسی هاپویی", "diplomacy"), ("اتاق جنگ", "war_room"), ("جنگ قبیله هاپویی", "clan_war"),
    ("سلام اتاق جنگ هاپویی چطوره", None), ("من دیروز به جنگ هاپویی رفتم", None), ("جنگ", None), ("هاپویی", None), ("", None),
])
def test_trigger_matching_robust_but_not_overeager(ses, text, panel):
    assert UI.match_trigger(text) == panel


def test_admin_can_add_and_remove_alias(ses):
    text = "اتاق عملیات هاپویی"
    assert UI.match_trigger(text) is None
    ses.add(W.WarAlias(panel="war_room", text=UI.normalize(text)))
    ses.commit()
    UI.alias_map(force=True)
    assert UI.match_trigger("اتاق عملیات هاپويي") == "war_room"
    ses.query(W.WarAlias).filter_by(text=UI.normalize(text)).delete()
    ses.commit()
    UI.alias_map(force=True)
    assert UI.match_trigger(text) is None


# ---------------------------------------------------------------- Callbacks -
class FakeMsg:
    def __init__(self):
        self.message_id, self.chat_id = 7, -100


class FakeQuery:
    def __init__(self, data, uid):
        self.data = data
        self.answers = []
        self.message = FakeMsg()

    async def answer(self, text=None, show_alert=False):
        self.answers.append((text, show_alert))

    async def edit_message_text(self, *a, **k):
        return FakeMsg()


def fake_update(uid, data, chat_type="supergroup"):
    q = FakeQuery(data, uid)
    return types.SimpleNamespace(callback_query=q, effective_user=types.SimpleNamespace(id=uid),
                                 effective_chat=types.SimpleNamespace(id=-100, type=chat_type), message=None, effective_message=q.message), q


def fake_ctx():
    return types.SimpleNamespace(user_data={}, bot=types.SimpleNamespace(username="hopbot"),
                                 application=types.SimpleNamespace(create_task=lambda c: c.close() if hasattr(c, "close") else None))


def test_callback_owner_lock_blocks_other_users(ses, clock, monkeypatch):
    mkplayer(ses, 1, xp=3000, th=2)
    mkplayer(ses, 2, xp=3000, th=2)
    sent = []

    async def fake_send(update, text, kb=None):
        sent.append(text)

    monkeypatch.setattr(UI, "send", fake_send)
    upd, q = fake_update(2, "wr:collect:1")
    asyncio.run(UI.wr_callback_router(upd, fake_ctx()))
    assert q.answers and q.answers[0][1] is True and "مالِ شما نیست" in q.answers[0][0]
    assert not sent
    # هیچ تراکنشی ثبت نشده (ریوارد/خزانه/تجهیزِ شخصِ دیگه)
    assert ses.query(W.HopTransaction).count() == 0


def test_callback_actions_run_as_clicker_only(ses, clock, monkeypatch):
    p = mkplayer(ses, 1, xp=3000, th=2)
    p.vault_hop = 12345
    ses.commit()
    sent = []

    async def fake_send(update, text, kb=None):
        sent.append(text)

    monkeypatch.setattr(UI, "send", fake_send)
    upd, q = fake_update(1, "wr:collect:1")
    asyncio.run(UI.wr_callback_router(upd, fake_ctx()))
    ses.expire_all()
    assert ses.get(db.User, 1).hop_points >= 1e10 + 12345
    assert sent and q.answers


def test_confirm_token_single_use_and_bound_to_user(ses, clock):
    mkplayer(ses, 1)
    mkplayer(ses, 2)
    tok = UI.make_token(ses, 1, "kick", {"t": 5})
    ses.commit()
    with pytest.raises(WarError):
        UI.consume_token(ses, 2, tok, "kick")                # مالِ کاربرِ دیگه
    assert UI.consume_token(ses, 1, tok, "kick") == {"t": 5}
    with pytest.raises(WarError):
        UI.consume_token(ses, 1, tok, "kick")                # Replay
    tok2 = UI.make_token(ses, 1, "kick", {})
    ses.commit()
    clock.adv(seconds=1000)
    with pytest.raises(WarError):
        UI.consume_token(ses, 1, tok2, "kick")               # منقضی


def test_panel_content_group_hides_exact_resources(ses, clock):
    p = mkplayer(ses, 1, xp=3000)
    p.vault_hop = 1_234_567
    ses.commit()
    upd_g = types.SimpleNamespace(effective_chat=types.SimpleNamespace(type="supergroup", id=-1))
    upd_p = types.SimpleNamespace(effective_chat=types.SimpleNamespace(type="private", id=1))
    tg, _ = UI.p_resources(ses, fake_ctx(), upd_g, p)
    tp, _ = UI.p_resources(ses, fake_ctx(), upd_p, p)
    assert "1,234,567" not in tg and "1,234,567" in tp      # دقیق فقط در خصوصی


def test_main_panel_hides_locked_hidden_features(ses):
    p = mkplayer(ses, 1, xp=0)
    text, rows = UI.p_main(ses, fake_ctx(), None, p)
    flat = [b.callback_data for r in rows for b in r]
    assert not any(":clan:" in d for d in flat)                        # هنوز دیده نمی‌شه
    assert "❓" in text                                                  # فقط Hint
    assert "قبیله" not in text
    p.xp, p.th_level = 9000, 2
    text, rows = UI.p_main(ses, fake_ctx(), None, p)
    assert any(":clan:" in b.callback_data for r in rows for b in r)


def test_war_room_panel_shows_active_ops_without_result(ses, clock):
    p1, p2, b = _duel(ses, clock)
    text, rows = UI.p_war_room(ses, fake_ctx(), None, p1)
    assert "Active Operations" in text and f"#{b.id}" in text and "در جریان" in text
    assert "برنده" not in text and "Winner" not in text
    st, _ = UI.p_status(ses, fake_ctx(), None, p1)
    assert "%" in st and "Winner" not in st


def test_target_list_hides_exact_info(ses, clock):
    p1 = mkplayer(ses, 1, xp=4000, units={"infantry": 10}, trophies=100)
    p2 = mkplayer(ses, 2, xp=4000, units={"infantry": 10}, trophies=120)
    p2.vault_hop = 777_777
    ses.commit()
    text, rows = UI.p_attack_targets(ses, fake_ctx(), None, p1)
    assert "Power ≈" in text and "Potential Loot" in text and "Risk" in text
    assert "777,777" not in text and "777777" not in text


def test_group_settings_disable_triggers(ses):
    gs = UI.group_setting(ses, -555)
    gs.war_enabled = False
    ses.commit()
    assert ses.get(W.WarGroupSetting, -555).war_enabled is False


def test_group_panel_rate_limit_dict_exists():
    assert isinstance(UI.PANEL_LAST, dict)


# ---------------------------------------------------------------- Admin -----
def test_admin_cfg_validation():
    assert A.validate_cfg("war_income_multiplier", "3.5") == ""
    assert A.validate_cfg("war_income_multiplier", "50") != ""
    assert A.validate_cfg("war_income_multiplier", "abc") != ""
    assert A.validate_cfg("war_loot_cap_hours", "-1") != ""
    assert A.validate_cfg("war_f_random", "0.9") != ""
    assert A.validate_cfg("war_clan_rank_names", "a,b,c") != ""
    assert A.validate_cfg("war_clan_rank_names", "a,b,c,d,e") == ""
    assert A.validate_cfg("war_clan_perms", '{"kick": 9}') != ""
    assert A.validate_cfg("war_shield_rules", "40:8,90:14") == ""
    assert A.validate_cfg("war_shield_rules", "oops") != ""
    assert A.validate_cfg("nonexistent_key", "1") != ""


def test_admin_awaiting_creates_and_edits_equipment_without_code(ses, clock):
    class Upd:
        effective_user = types.SimpleNamespace(id=999)

        def __init__(self, text):
            self.message = types.SimpleNamespace(text=text, reply_text=self._reply)
            self.replies = []

        async def _reply(self, t, **k):
            self.replies.append(t)

    async def run(state, text):
        u = Upd(text)
        try:
            await A.war_admin_awaiting_handler(u, fake_ctx(), state)
        except Exception as e:  # ApplicationHandlerStop
            assert type(e).__name__ == "ApplicationHandlerStop"
        return u.replies

    r = asyncio.run(run({"type": "war_new", "tbl": "unit"}, "adv_drone | پهپادِ پیشرفته"))
    assert "ساخته شد" in r[0]
    r = asyncio.run(run({"type": "war_fld", "tbl": "unit", "pk": "adv_drone"}, "atk 95\ncost 4000\ncategory air\nhousing 2\ntrain_seconds 20\nreq_level 1\nreq_th 1\nenabled 1"))
    assert "✅" in r[0]
    s = db.get_session()
    d = s.get(W.WarUnitDef, "adv_drone")
    assert d.atk == 95 and d.cost == 4000 and d.category == "air"
    s.close()
    p = mkplayer(ses, 1, xp=3000, th=2)
    S.enqueue_train(ses, p, "adv_drone", 2)                     # بلافاصله قابل‌استفاده
    ses.commit()
    r = asyncio.run(run({"type": "war_fld", "tbl": "unit", "pk": "adv_drone"}, "atk -5"))
    assert "❌" in r[0]                                          # مقدارِ منفی رد می‌شه
    r = asyncio.run(run({"type": "war_fld", "tbl": "unit", "pk": "adv_drone"}, "nonexistent 5"))
    assert "❌" in r[0]
    r = asyncio.run(run({"type": "war_new", "tbl": "unit"}, "adv_drone | x"))
    assert "❌" in r[0]                                          # کلیدِ تکراری
    r = asyncio.run(run({"type": "war_new", "tbl": "event"}, "Weekend War | 48 | 2 | 1.5 | 1 | 1"))
    assert "✅" in r[0]
    r = asyncio.run(run({"type": "war_new", "tbl": "alias"}, "war_room | اتاق عملیات هاپویی"))
    assert "✅" in r[0] and UI.match_trigger("اتاق عملیات هاپویی") == "war_room"


def test_admin_hop_adjustment_uses_ledger(ses):
    mkuser(ses, 5, hop=1000)

    class Upd:
        effective_user = types.SimpleNamespace(id=999)

        def __init__(self, text):
            self.message = types.SimpleNamespace(text=text, reply_text=self._r)

        async def _r(self, *a, **k):
            pass

    try:
        asyncio.run(A.war_admin_awaiting_handler(Upd("5 -400 جبران"), fake_ctx(), {"type": "war_adj"}))
    except Exception:
        pass
    ses.expire_all()
    assert ses.get(db.User, 5).hop_points == 600
    t = ses.query(W.HopTransaction).filter_by(user_id=5).order_by(W.HopTransaction.id.desc()).first()
    assert t.type == "ADMIN_ADJUSTMENT" and t.amount == -400


def test_admin_simulation_is_read_only(ses, clock):
    mkplayer(ses, 1, xp=4000, units={"infantry": 40})
    mkplayer(ses, 2, xp=4000, units={"infantry": 10})

    def snapshot():
        ses.expire_all()
        return (ses.query(W.WarBattle).count(), ses.query(W.HopTransaction).count(), ses.query(W.WarAudit).count(),
                [(u.unit_key, u.healthy, u.damaged) for u in ses.query(W.WarUnit).order_by(W.WarUnit.id)],
                ses.get(W.WarPlayer, 1).readiness, ses.get(db.User, 1).hop_points, ses.get(W.WarPlayer, 2).vault_hop)
    before = snapshot()
    r = A.simulate(ses, 1, 2, "standard", 150)
    assert snapshot() == before
    assert abs(sum(r["outcome"].values()) - 150) < 1e-9
    txt = A.sim_text(r, 1, 2, "standard")
    assert "توزیعِ برنده" in txt and "غنیمت" in txt and "XP" in txt and "ریدینس" in txt


def test_admin_dashboard_has_all_metrics(ses, clock):
    p1, p2, b = _duel(ses, clock)
    clock.t = b.resolve_at
    B.resolve_battle(ses, b.id, clock())
    ses.commit()
    s = A.dashboard_stats(ses, 24)
    for k in ("players", "active", "levels", "xp_avg", "hop_gen", "hop_spent", "circulation", "battles", "att_wins", "def_wins", "avg_loot",
              "avg_destroyed", "eq_created", "eq_repaired", "eq_destroyed_total", "clans", "clan_wars", "treasury", "deposits", "withdrawals",
              "coups", "quests_done"):
        assert k in s
    assert s["battles"] == 1 and s["players"] == 2


def test_admin_recalibration_rescales_prices(ses):
    before = ses.get(W.WarUnitDef, "tank").cost
    db.cfg_set(ses, "war_income_multiplier", "7")
    old = S.cf(ses, "war_ref_calibration")
    ratio = S.ref_hourly(ses, 1) / old
    assert abs(ratio - 2.0) < 1e-6


def test_admin_permission_category_registered():
    import admin
    assert any(k == "war" for k, _ in admin.ADMIN_PERMISSION_CATEGORIES)
    assert admin._admin_permission_category("admin_war_menu") == "war"
    assert admin._admin_permission_category("admin_war_cfgk:war_f_k") == "war"
    assert "admin_war_menu" in admin.ADMIN_PREFIX_CALLBACK_MAP


def test_integration_wiring_in_handlers_and_main():
    src = open(os.path.join(os.path.dirname(__file__), "handlers.py"), encoding="utf-8").read()
    assert "war_ui.match_trigger(normalized)" in src and 'trigger == "war"' in src
    msrc = open(os.path.join(os.path.dirname(__file__), "main.py"), encoding="utf-8").read()
    assert "war_db.init_war()" in msrc and "war_ui.war_tick_job" in msrc and 'data.startswith("wr:")' in msrc
    assert "war_awaiting" in msrc
