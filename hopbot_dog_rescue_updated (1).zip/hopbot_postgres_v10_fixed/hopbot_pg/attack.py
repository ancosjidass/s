# -*- coding: utf-8 -*-
"""
«فروشگاه و حمله» + سیستمِ «گروگان» + بازیِ کازینوییِ «نبرد تن‌به‌تن».

معماری: از الگوهای همین پروژه استفاده شده (ask_for_input/send_response/
_verify_panel_owner از handlers.py، cfg_get_* از db.py، الگوی PREFIX_MAP مثلِ
chef.py). هیچ آیتمی پیش‌فرض ساخته نمی‌شه - همه‌چیز از پنلِ ادمین ساخته می‌شه.
"""
import datetime
import random

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationHandlerStop

import db
import economy
from handlers import fmt, send_response, _verify_panel_owner, ask_for_input, ask_for_input_reply, is_reply_to_prompt, parse_amount

CATEGORY_LABELS = {
    "guard": "🛡 محافظ",
    "gun": "🔫 گان",
    "smoke": "💨 بمب دودزا",
    "item": "🎁 آیتم",
    "booster": "⚡ بوستر",
}
CATEGORIES = ["guard", "gun", "smoke", "item", "booster"]
CHOICE_LABELS = {"a": "🅰️", "b": "🅱️", "c": "🅲️"}


def _nowt():
    return datetime.datetime.utcnow()


def _cfg(session, key):
    return db.cfg_get_float(session, key)


# ---------------------------------------------------------------------------
# کمکی‌های کوله‌پشتی/inventory
# ---------------------------------------------------------------------------

def backpack_max_slots(session):
    return db.cfg_get_int(session, "attack_backpack_max_slots")


def backpack_count(session, user_id):
    return session.query(db.InventoryItem).filter_by(user_id=user_id).count()


def add_to_inventory(session, user_id, item: db.ShopItem, qty: int = 1):
    """آیتم رو به کوله‌پشتیِ کاربر اضافه می‌کنه. آیتمِ عمومی/بوستر (تا وقتی
    مصرف/تجهیز نشدن) رو هم پشته می‌کنه (بدونِ گرفتنِ اسلاتِ جدید)؛ گان/محافظ/
    بمبِ دودزا همیشه ردیفِ جداگونه می‌سازن (uses_remaining مستقلِ خودشون رو
    دارن). برمی‌گردونه (inv, ok) - ok=False یعنی کوله‌پشتی پره."""
    stackable = item.category in ("item", "booster")
    if stackable:
        existing = (
            session.query(db.InventoryItem)
            .filter_by(user_id=user_id, shop_item_id=item.id, equipped=False)
            .first()
        )
        if existing:
            existing.quantity = (existing.quantity or 0) + qty
            if item.uses:
                existing.uses_remaining = (existing.uses_remaining or 0) + item.uses * qty
            return existing, True
    if backpack_count(session, user_id) >= backpack_max_slots(session):
        return None, False
    inv = db.InventoryItem(
        user_id=user_id, shop_item_id=item.id, quantity=qty,
        uses_remaining=(item.uses * qty) if item.uses else None,
    )
    session.add(inv)
    session.flush()
    return inv, True


def get_equipped(session, user_id, category):
    return (
        session.query(db.InventoryItem)
        .join(db.ShopItem, db.InventoryItem.shop_item_id == db.ShopItem.id)
        .filter(db.InventoryItem.user_id == user_id, db.InventoryItem.equipped == True,  # noqa: E712
                db.ShopItem.category == category)
        .first()
    )


def consume_use(session, inv: db.InventoryItem):
    """یه بارِ استفاده از یه ردیفِ inventory کم می‌کنه؛ اگه نامحدود بود
    (uses_remaining=None) کاری نمی‌کنه. اگه به صفر برسه، ردیف حذف می‌شه."""
    if inv is None:
        return
    if inv.uses_remaining is None:
        return
    inv.uses_remaining -= 1
    if inv.uses_remaining <= 0:
        session.delete(inv)


def daily_hostage_counts(session, user_id):
    """چندبار امروز (از نیمه‌شبِ UTC) این کاربر گروگان گرفته شده (victim) و
    چندبار خودش موفق به گروگان‌گیری شده (attacker)."""
    start_of_day = _nowt().replace(hour=0, minute=0, second=0, microsecond=0)
    victim_count = (
        session.query(db.Hostage)
        .filter(db.Hostage.victim_id == user_id, db.Hostage.started_at >= start_of_day)
        .count()
    )
    attacker_count = (
        session.query(db.Hostage)
        .filter(db.Hostage.attacker_id == user_id, db.Hostage.started_at >= start_of_day)
        .count()
    )
    return victim_count, attacker_count


# ---------------------------------------------------------------------------
# ورودی: تایپِ «پنل حمله»
# ---------------------------------------------------------------------------

async def handle_attack_trigger(update, context):
    await _show_attack_home(update, context)


def _attack_home_keyboard(owner_id):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🛍 فروشگاه هاپویی", callback_data=f"attack_shop:{owner_id}")],
        [InlineKeyboardButton("🎒 کوله‌پشتی", callback_data=f"attack_bag:{owner_id}")],
        [InlineKeyboardButton("🎯 حمله به کسی", callback_data=f"attack_target_ask:{owner_id}")],
        [InlineKeyboardButton("📋 وضعیتِ من", callback_data=f"attack_status:{owner_id}")],
    ])


async def _show_attack_home(update, context):
    owner_id = update.effective_user.id
    text = (
        "🗡 پنلِ حمله\n\n"
        "از «فروشگاه» گان/محافظ/بمبِ دودزا/آیتم/بوستر بخر، تو «کوله‌پشتی» تجهیزشون کن یا "
        "استفاده‌شون کن، و از «حمله به کسی» شروع کن."
    )
    await send_response(update, text, _attack_home_keyboard(owner_id))


async def cb_attack_home(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await _show_attack_home(update, context)


# ---------------------------------------------------------------------------
# فروشگاه
# ---------------------------------------------------------------------------

async def cb_attack_shop(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    rows = [[InlineKeyboardButton(CATEGORY_LABELS[c], callback_data=f"attack_shop_cat:{c}:{owner_id}")] for c in CATEGORIES]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"attack_home:{owner_id}")])
    await send_response(update, "🛍 فروشگاه هاپویی\n\nیه دسته انتخاب کن:", InlineKeyboardMarkup(rows))


def _item_summary_line(item: db.ShopItem):
    parts = [f"💵 {fmt(item.price)} 🪙"]
    if item.level:
        parts.append(f"سطح {item.level}")
    if item.power:
        parts.append(f"قدرت {fmt(item.power)}")
    if item.pct:
        parts.append(f"٪{fmt(item.pct)}")
    if item.uses:
        parts.append(f"{item.uses} استفاده")
    if item.duration_minutes:
        parts.append(f"{item.duration_minutes} دقیقه")
    return " | ".join(parts)


async def cb_attack_shop_cat(update, context):
    _, cat, owner_id = update.callback_query.data.split(":")
    owner_id = int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        items = session.query(db.ShopItem).filter_by(category=cat, active=True).order_by(db.ShopItem.price).all()
        rows = []
        for it in items:
            rows.append([InlineKeyboardButton(f"{it.name} - {fmt(it.price)} 🪙", callback_data=f"attack_shop_view:{it.id}:{owner_id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"attack_shop:{owner_id}")])
        text = f"{CATEGORY_LABELS[cat]}\n\nهیچ آیتمی فعلاً موجود نیست." if not items else f"{CATEGORY_LABELS[cat]} - یکی رو ببین:"
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_attack_shop_view(update, context):
    _, item_id, owner_id = update.callback_query.data.split(":")
    item_id, owner_id = int(item_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        it = session.get(db.ShopItem, item_id)
        if not it or not it.active:
            await send_response(update, "❌ این آیتم دیگه موجود نیست.", None)
            return
        text = f"{it.name}\n\n{it.description or ''}\n\n{_item_summary_line(it)}"
        rows = [
            [InlineKeyboardButton(f"🛒 خرید ({fmt(it.price)} 🪙)", callback_data=f"attack_shop_buy:{it.id}:{owner_id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f"attack_shop_cat:{it.category}:{owner_id}")],
        ]
        await send_response(update, text.strip(), InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_attack_shop_buy(update, context):
    _, item_id, owner_id = update.callback_query.data.split(":")
    item_id, owner_id = int(item_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        it = session.get(db.ShopItem, item_id)
        if not it or not it.active:
            await update.callback_query.answer("❌ این آیتم دیگه موجود نیست.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < it.price - 0.5:
            await update.callback_query.answer(f"❌ موجودی کافی نیست! {fmt(it.price)} 🪙 لازمه.", show_alert=True)
            return
        if backpack_count(session, owner_id) >= backpack_max_slots(session) and it.category not in ("item", "booster"):
            await update.callback_query.answer("❌ کوله‌پشتیت پره! اول یه آیتم رو بنداز دور.", show_alert=True)
            return
        user.hop_points -= it.price
        inv, ok = add_to_inventory(session, owner_id, it, 1)
        if not ok:
            session.rollback()
            await update.callback_query.answer("❌ کوله‌پشتیت پره! اول یه آیتم رو بنداز دور.", show_alert=True)
            return
        session.commit()
        await update.callback_query.answer(f"✅ {it.name} خریداری شد و به کوله‌پشتیت اضافه شد.", show_alert=True)
    finally:
        session.close()
    await cb_attack_shop_view(update, context)


# ---------------------------------------------------------------------------
# کوله‌پشتی
# ---------------------------------------------------------------------------

def _inv_line(inv: db.InventoryItem, it: db.ShopItem):
    tag = "✅ مجهز" if inv.equipped else ""
    bits = [it.name]
    if it.category in ("item",):
        bits.append(f"x{inv.quantity}")
    if inv.uses_remaining is not None:
        bits.append(f"{inv.uses_remaining} استفاده مونده")
    if tag:
        bits.append(tag)
    return " | ".join(bits)


async def cb_attack_bag(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await _render_bag(update, context, owner_id)


async def _render_bag(update, context, owner_id):
    session = db.get_session()
    try:
        items = (
            session.query(db.InventoryItem, db.ShopItem)
            .join(db.ShopItem, db.InventoryItem.shop_item_id == db.ShopItem.id)
            .filter(db.InventoryItem.user_id == owner_id)
            .order_by(db.ShopItem.category)
            .all()
        )
        cap = backpack_max_slots(session)
        rows = []
        for inv, it in items:
            rows.append([InlineKeyboardButton(_inv_line(inv, it), callback_data=f"attack_bag_view:{inv.id}:{owner_id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"attack_home:{owner_id}")])
        text = f"🎒 کوله‌پشتی ({len(items)}/{cap})\n\n" + ("خالیه." if not items else "برای دیدنِ جزئیات/استفاده رو یکی بزن:")
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_attack_bag_view(update, context):
    _, inv_id, owner_id = update.callback_query.data.split(":")
    inv_id, owner_id = int(inv_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        inv = session.get(db.InventoryItem, inv_id)
        if not inv or inv.user_id != owner_id:
            await send_response(update, "❌ این آیتم پیدا نشد.", None)
            return
        it = session.get(db.ShopItem, inv.shop_item_id)
        text = f"{it.name}\n{it.description or ''}\n\n{_item_summary_line(it)}\n\n{_inv_line(inv, it)}"
        rows = []
        if it.category in ("guard", "gun", "smoke"):
            if not inv.equipped:
                rows.append([InlineKeyboardButton("✅ استفاده (تجهیز کردن)", callback_data=f"attack_bag_equip:{inv.id}:{owner_id}")])
            else:
                rows.append([InlineKeyboardButton("❎ برداشتنِ تجهیز", callback_data=f"attack_bag_unequip:{inv.id}:{owner_id}")])
        elif it.category == "booster":
            rows.append([InlineKeyboardButton("⚡ استفاده (فعال‌سازی)", callback_data=f"attack_bag_use_booster:{inv.id}:{owner_id}")])
        elif it.category == "item":
            rows.append([InlineKeyboardButton("✅ استفاده", callback_data=f"attack_bag_use_item:{inv.id}:{owner_id}")])
        rows.append([InlineKeyboardButton("🗑 دورانداختن", callback_data=f"attack_bag_discard:{inv.id}:{owner_id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"attack_bag:{owner_id}")])
        await send_response(update, text.strip(), InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_attack_bag_equip(update, context):
    _, inv_id, owner_id = update.callback_query.data.split(":")
    inv_id, owner_id = int(inv_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        inv = session.get(db.InventoryItem, inv_id)
        if not inv or inv.user_id != owner_id:
            await update.callback_query.answer("این آیتم پیدا نشد.", show_alert=True)
            return
        it = session.get(db.ShopItem, inv.shop_item_id)
        if it.category not in ("guard", "gun", "smoke"):
            await update.callback_query.answer("این آیتم قابلِ تجهیز نیست.", show_alert=True)
            return
        if inv.uses_remaining is not None and inv.uses_remaining <= 0:
            await update.callback_query.answer("این آیتم دیگه استفاده نداره.", show_alert=True)
            return
        others = (
            session.query(db.InventoryItem)
            .join(db.ShopItem, db.InventoryItem.shop_item_id == db.ShopItem.id)
            .filter(db.InventoryItem.user_id == owner_id, db.InventoryItem.equipped == True,  # noqa: E712
                    db.ShopItem.category == it.category)
            .all()
        )
        for o in others:
            o.equipped = False
        inv.equipped = True
        session.commit()
        await update.callback_query.answer(f"✅ {it.name} تجهیز شد.", show_alert=True)
    finally:
        session.close()
    await cb_attack_bag_view(update, context)


async def cb_attack_bag_unequip(update, context):
    _, inv_id, owner_id = update.callback_query.data.split(":")
    inv_id, owner_id = int(inv_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        inv = session.get(db.InventoryItem, inv_id)
        if inv and inv.user_id == owner_id:
            inv.equipped = False
            session.commit()
    finally:
        session.close()
    await cb_attack_bag_view(update, context)


async def cb_attack_bag_use_item(update, context):
    _, inv_id, owner_id = update.callback_query.data.split(":")
    inv_id, owner_id = int(inv_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        inv = session.get(db.InventoryItem, inv_id)
        if not inv or inv.user_id != owner_id:
            await update.callback_query.answer("این آیتم پیدا نشد.", show_alert=True)
            return
        it = session.get(db.ShopItem, inv.shop_item_id)
        inv.quantity = (inv.quantity or 1) - 1
        if inv.quantity <= 0:
            session.delete(inv)
        session.commit()
        await update.callback_query.answer(f"✅ {it.name} استفاده شد.", show_alert=True)
    finally:
        session.close()
    await _render_bag(update, context, owner_id)


async def cb_attack_bag_use_booster(update, context):
    _, inv_id, owner_id = update.callback_query.data.split(":")
    inv_id, owner_id = int(inv_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        inv = session.get(db.InventoryItem, inv_id)
        if not inv or inv.user_id != owner_id:
            await update.callback_query.answer("این آیتم پیدا نشد.", show_alert=True)
            return
        it = session.get(db.ShopItem, inv.shop_item_id)
        if it.category != "booster":
            await update.callback_query.answer("این بوستر نیست.", show_alert=True)
            return
        nowt = _nowt()
        # هیچ‌وقت دوبار پشتِ‌سرِهم از همون نوع (پول/قدرت) مصرف نمی‌شه - باید
        # صبر کنی اثرِ قبلی تموم شه
        active = (
            session.query(db.ActiveBooster)
            .filter(db.ActiveBooster.user_id == owner_id, db.ActiveBooster.booster_type == it.booster_type,
                    db.ActiveBooster.ends_at > nowt)
            .first()
        )
        if active:
            remain_min = max(1, int((active.ends_at - nowt).total_seconds() // 60))
            kind = "پول" if it.booster_type == "money" else "قدرت"
            await update.callback_query.answer(
                f"❌ یه بوسترِ {kind} از قبل فعاله! {remain_min} دقیقه‌ی دیگه تموم می‌شه.", show_alert=True
            )
            return
        dur = it.duration_minutes or 0
        session.add(db.ActiveBooster(
            user_id=owner_id, booster_type=it.booster_type, pct=it.pct or 0,
            shop_item_id=it.id, started_at=nowt, ends_at=nowt + datetime.timedelta(minutes=dur),
        ))
        inv.quantity = (inv.quantity or 1) - 1
        if inv.quantity <= 0:
            session.delete(inv)
        session.commit()
        kind = "پول" if it.booster_type == "money" else "قدرت"
        await update.callback_query.answer(f"⚡ بوسترِ {kind} فعال شد! {dur} دقیقه، {fmt(it.pct or 0)}٪.", show_alert=True)
    finally:
        session.close()
    await _render_bag(update, context, owner_id)


async def cb_attack_bag_discard(update, context):
    _, inv_id, owner_id = update.callback_query.data.split(":")
    inv_id, owner_id = int(inv_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        inv = session.get(db.InventoryItem, inv_id)
        if inv and inv.user_id == owner_id:
            session.delete(inv)
            session.commit()
    finally:
        session.close()
    await _render_bag(update, context, owner_id)


# ---------------------------------------------------------------------------
# وضعیتِ من
# ---------------------------------------------------------------------------

async def cb_attack_status(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await _render_status(update, context, owner_id)


async def _render_status(update, context, owner_id):
    session = db.get_session()
    try:
        nowt = _nowt()
        lines = ["📋 وضعیتِ من\n"]
        v_count, a_count = daily_hostage_counts(session, owner_id)
        max_victim_per_day = int(_cfg(session, "attack_max_victim_hostage_per_day"))
        max_attacker_per_day = int(_cfg(session, "attack_max_hostage_per_day"))
        lines.append(f"📅 امروز: {v_count}/{max_victim_per_day} بار گروگان گرفته شدی، {a_count}/{max_attacker_per_day} بار گروگان گرفتی.")

        my_hostage = (
            session.query(db.Hostage)
            .filter(db.Hostage.victim_id == owner_id, db.Hostage.status == "active", db.Hostage.ends_at > nowt)
            .first()
        )
        rows = []
        if my_hostage:
            remain = int((my_hostage.ends_at - nowt).total_seconds() // 60)
            ransom = _cfg(session, "attack_hostage_ransom_amount")
            lines.append(f"\n🔒 الان گروگانی! {remain} دقیقه‌ی دیگه مونده (یا فرار/آزادی).")
            lines.append(f"💰 برای آزادی می‌تونی {fmt(ransom)} 🪙 بدی.")
            rows.append([InlineKeyboardButton(f"💸 پرداخت کمیسیون ({fmt(ransom)} 🪙)", callback_data=f"attack_ransom:{my_hostage.id}:{owner_id}")])

        my_capture = (
            session.query(db.Hostage)
            .filter(db.Hostage.attacker_id == owner_id, db.Hostage.status == "active", db.Hostage.ends_at > nowt)
            .first()
        )
        if my_capture:
            victim = session.get(db.User, my_capture.victim_id)
            remain = int((my_capture.ends_at - nowt).total_seconds() // 60)
            lines.append(f"\n🎯 {victim.display_name() if victim else my_capture.victim_id} رو گروگان گرفتی؛ {remain} دقیقه‌ی دیگه مونده.")

        for pk, label in (("attacker_killed", "کشته‌شدنِ مهاجم"), ("defender_fail", "شکستِ تلاش")):
            p = (
                session.query(db.ProductionPenalty)
                .filter(db.ProductionPenalty.user_id == owner_id, db.ProductionPenalty.kind == pk, db.ProductionPenalty.ends_at > nowt)
                .first()
            )
            if p:
                remain = int((p.ends_at - nowt).total_seconds() // 60)
                lines.append(f"\n⚠️ جریمه‌ی «{label}» فعاله: تولیدِ Hop Manager × {fmt(p.multiplier * 100)}٪ ({remain} دقیقه‌ی دیگه).")

        for bt, label in (("money", "پول"), ("power", "قدرت")):
            b = (
                session.query(db.ActiveBooster)
                .filter(db.ActiveBooster.user_id == owner_id, db.ActiveBooster.booster_type == bt, db.ActiveBooster.ends_at > nowt)
                .first()
            )
            if b:
                remain = int((b.ends_at - nowt).total_seconds() // 60)
                lines.append(f"\n⚡ بوسترِ {label} فعاله: +{fmt(b.pct)}٪ ({remain} دقیقه‌ی دیگه).")

        gun = get_equipped(session, owner_id, "gun")
        guard = get_equipped(session, owner_id, "guard")
        if gun:
            g_item = session.get(db.ShopItem, gun.shop_item_id)
            lines.append(f"\n🔫 گانِ مجهز: {g_item.name} (قدرت {fmt(g_item.power or 0)})")
        else:
            lines.append("\n🔫 هیچ گانی مجهز نکردی.")
        if guard:
            gd_item = session.get(db.ShopItem, guard.shop_item_id)
            lines.append(f"🛡 محافظِ مجهز: {gd_item.name} (قدرت {fmt(gd_item.power or 0)})")
        else:
            lines.append("🛡 هیچ محافظی مجهز نکردی.")

        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"attack_home:{owner_id}")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_attack_ransom(update, context):
    _, hostage_id, owner_id = update.callback_query.data.split(":")
    hostage_id, owner_id = int(hostage_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        h = session.get(db.Hostage, hostage_id)
        nowt = _nowt()
        if not h or h.victim_id != owner_id or h.status != "active" or h.ends_at <= nowt:
            await update.callback_query.answer("❌ این گروگان‌گیری دیگه فعال نیست.", show_alert=True)
            return
        ransom = _cfg(session, "attack_hostage_ransom_amount")
        victim = session.get(db.User, owner_id)
        if victim.hop_points < ransom - 0.5:
            await update.callback_query.answer(f"❌ موجودی کافی نیست! {fmt(ransom)} 🪙 لازمه.", show_alert=True)
            return
        attacker = session.get(db.User, h.attacker_id)
        victim.hop_points -= ransom
        if attacker:
            attacker.hop_points += ransom
        h.status = "freed_paid"
        session.commit()
        await update.callback_query.answer("✅ آزاد شدی!", show_alert=True)
    finally:
        session.close()
    await _render_status(update, context, owner_id)


# ---------------------------------------------------------------------------
# حمله + مینی‌گیمِ گروگان‌گیری
# ---------------------------------------------------------------------------

async def cb_attack_target_ask(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(
        update, context,
        "🎯 آیدیِ عددیِ هدف رو بفرست، یا رو پیامش ریپلای بزن و همین دکمه رو دوباره بزن.",
        {"type": "attack_target"}, "attack_awaiting",
    )


HOSTAGE_TRIGGER = "گروگان"


async def handle_hostage_reply_trigger(update, context) -> bool:
    """وقتی کاربر رو پیامِ یه نفر ریپلای بزنه و فقط بنویسه «گروگان»، به‌جایِ
    اینکه مستقیم شروع کنه، اول یه تأییدِ بله/خیر نشون می‌ده. اگه مهاجم تا
    مهلتِ تنظیم‌شده (پیش‌فرض ۶۰ ثانیه) هیچ‌کدوم از بله/خیر رو نزنه، خودکار
    لغو می‌شه (نگاه کن به tick_pending_hostage_confirms). برمی‌گردونه True
    اگه این پیام رو مدیریت کرد (تا text_router بدونه ادامه نده)."""
    text = (update.message.text or "").strip()
    if text != HOSTAGE_TRIGGER:
        return False
    reply = update.message.reply_to_message
    if not reply or not reply.from_user:
        await update.message.reply_text("❌ برای گروگان‌گیری باید رو پیامِ همون کاربر ریپلای بزنی.")
        return True
    target_id = reply.from_user.id
    attacker_id = update.effective_user.id
    if attacker_id == target_id:
        await update.message.reply_text("❌ نمی‌تونی خودتو گروگان بگیری.")
        return True
    session = db.get_session()
    try:
        attacker_user = db.get_or_create_user(session, update.effective_user)
        gate_error = db.check_module_level(session, attacker_user, "hostage")
        if gate_error:
            await update.message.reply_text(gate_error)
            return True

        nowt = _nowt()
        busy_error = db.attack_busy_check_message(session, attacker_id, nowt) or db.attack_busy_check_message(session, target_id, nowt)
        if busy_error:
            await update.message.reply_text(busy_error)
            return True

        pending = db.PendingHostageConfirm(
            attacker_id=attacker_id, target_id=target_id, chat_id=update.effective_chat.id,
        )
        session.add(pending)
        session.commit()
        rows = [[
            InlineKeyboardButton("✅ بله", callback_data=f"attack_hostage_confirm:{pending.id}"),
            InlineKeyboardButton("❌ خیر", callback_data=f"attack_hostage_cancel:{pending.id}"),
        ]]
        timeout_s = int(_cfg(session, "attack_inactivity_timeout_seconds"))
        msg = await update.message.reply_text(
            f"⚠️ آیا مطمئنی می‌خوای شروع به گروگان‌گیریِ این کاربر کنی؟\n"
            f"(اگه تا {timeout_s} ثانیه جواب ندی، خودکار لغو می‌شه)",
            reply_markup=InlineKeyboardMarkup(rows),
        )
        pending.message_id = msg.message_id
        session.commit()
    finally:
        session.close()
    return True


async def cb_attack_hostage_confirm(update, context):
    pending_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        pending = session.get(db.PendingHostageConfirm, pending_id)
        if not pending:
            await update.callback_query.answer("⌛ این درخواست منقضی/لغو شده.", show_alert=True)
            try:
                await update.callback_query.edit_message_text("⌛ این درخواست دیگه معتبر نیست.")
            except Exception:
                pass
            return
        if update.effective_user.id != pending.attacker_id:
            await update.callback_query.answer("❌ این پیامِ تو نیست.", show_alert=True)
            return
        attacker_id, target_id = pending.attacker_id, pending.target_id
        session.delete(pending)
        session.commit()

        nowt = _nowt()
        busy_error = db.attack_busy_check_message(session, attacker_id, nowt) or db.attack_busy_check_message(session, target_id, nowt)
        if busy_error:
            await update.callback_query.answer()
            await update.callback_query.edit_message_text(busy_error)
            return
    finally:
        session.close()
    await update.callback_query.answer()
    await update.callback_query.edit_message_text("🚀 عملیات شروع شد...")
    await _start_attack(update, context, attacker_id, target_id)


async def cb_attack_hostage_cancel(update, context):
    pending_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        pending = session.get(db.PendingHostageConfirm, pending_id)
        if pending:
            if update.effective_user.id != pending.attacker_id:
                await update.callback_query.answer("❌ این پیامِ تو نیست.", show_alert=True)
                return
            session.delete(pending)
            session.commit()
    finally:
        session.close()
    await update.callback_query.edit_message_text("❌ لغو شد.")
    await update.callback_query.answer()


async def tick_pending_hostage_confirms(session, context):
    """درخواست‌هایِ «بله/خیر»یِ گروگان‌گیری که مهاجم تا مهلتِ تنظیم‌شده هیچ
    جوابی بهشون نداده رو خودکار لغو می‌کنه تا طرفِ مقابل برای همیشه قفل نمونه."""
    timeout_s = int(_cfg(session, "attack_inactivity_timeout_seconds"))
    cutoff = _nowt() - datetime.timedelta(seconds=timeout_s)
    stale = session.query(db.PendingHostageConfirm).filter(db.PendingHostageConfirm.created_at < cutoff).all()
    for pending in stale:
        if pending.message_id:
            try:
                await context.bot.edit_message_text(
                    chat_id=pending.chat_id, message_id=pending.message_id,
                    text="⌛ ۶۰ ثانیه گذشت و هیچ عملیاتی انجام نشد.",
                )
            except Exception:
                pass
        session.delete(pending)
    if stale:
        session.commit()


async def tick_attack_session_timeouts(session, context):
    """نبردهایِ گروگان‌گیریِ فعالی که تا مهلتِ تنظیم‌شده هیچ حرکتی (حدسی) توشون
    ثبت نشده رو خودکار لغو می‌کنه؛ هم پنلِ ول‌شده رو می‌بنده، هم طرفِ مقابل رو
    برای همیشه «قفل» (غیرقابلِ حمله) نمی‌ذاره."""
    timeout_s = int(_cfg(session, "attack_inactivity_timeout_seconds"))
    cutoff = _nowt() - datetime.timedelta(seconds=timeout_s)
    stale = (
        session.query(db.AttackSession)
        .filter(db.AttackSession.status == "active")
        .all()
    )
    for sess in stale:
        last = sess.last_action_at or sess.created_at
        if last is None or last >= cutoff:
            continue
        sess.status = "cancelled"
        sess.resolved_at = _nowt()
        if sess.message_id:
            try:
                await context.bot.edit_message_text(
                    chat_id=sess.chat_id, message_id=sess.message_id,
                    text="⌛ ۶۰ ثانیه هیچ حرکتی ثبت نشد؛ عملیات به‌صورت خودکار پایان یافت.",
                )
            except Exception:
                pass
        session.commit()


async def attack_awaiting_handler(update, context):
    awaiting = context.user_data.get("attack_awaiting")
    if not awaiting:
        return
    if not is_reply_to_prompt(update, awaiting):
        return
    kind = awaiting["type"]
    context.user_data.pop("attack_awaiting", None)

    if kind == "attack_target":
        reply = update.message.reply_to_message
        target_id = None
        if reply and reply.from_user:
            target_id = reply.from_user.id
        else:
            text = (update.message.text or "").strip()
            if text.isdigit():
                target_id = int(text)
        if not target_id:
            await update.message.reply_text("❌ آیدی نامعتبره؛ عملیات لغو شد.")
            raise ApplicationHandlerStop
        await _start_attack(update, context, update.effective_user.id, target_id)
        raise ApplicationHandlerStop

    if kind == "duel_stake":
        text = (update.message.text or "").strip()
        amount = parse_amount(text)
        if amount is None:
            await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد.")
            raise ApplicationHandlerStop
        await attack_duel_stake_handler(update, context, amount)
        raise ApplicationHandlerStop

    raise ApplicationHandlerStop


async def _start_attack(update, context, attacker_id: int, target_id: int):
    chat_id = update.effective_chat.id
    tg_user = update.effective_user

    async def reply(text):
        await context.bot.send_message(chat_id, text)

    session = db.get_session()
    try:
        nowt = _nowt()
        if attacker_id == target_id:
            await reply("❌ نمی‌تونی خودتو هدف بگیری.")
            return
        attacker = db.get_or_create_user(session, tg_user)
        target = session.get(db.User, target_id)
        if not target:
            await reply("❌ این کاربر پیدا نشد.")
            return

        gun = get_equipped(session, attacker_id, "gun")
        if not gun or (gun.uses_remaining is not None and gun.uses_remaining <= 0):
            await reply("❌ گانی مجهز نداری! اول از فروشگاه یه گان بخر و از کوله‌پشتی تجهیزش کن.")
            return

        if (target.bank_balance or 0) + (target.hop_points or 0) < _cfg(session, "attack_min_target_wealth"):
            await reply("🔴 طرف مقابل هیچ چیز ندارد.")
            return

        already_hostage = (
            session.query(db.Hostage)
            .filter(db.Hostage.victim_id == target_id, db.Hostage.status == "active", db.Hostage.ends_at > nowt)
            .first()
        )
        if already_hostage:
            await reply("❌ این کاربر الان گروگانه؛ بعداً امتحان کن.")
            return
        busy_error = db.attack_busy_check_message(session, attacker_id, nowt) or db.attack_busy_check_message(session, target_id, nowt)
        if busy_error:
            await reply(busy_error)
            return

        v_count, a_count = daily_hostage_counts(session, target_id)
        max_victim_per_day = int(_cfg(session, "attack_max_victim_hostage_per_day"))
        if v_count >= max_victim_per_day:
            await reply("❌ خطا (محدودیتِ روزانه‌ی طرفِ مقابل)")
            return
        _, my_a_count = daily_hostage_counts(session, attacker_id)
        max_attacker_per_day = int(_cfg(session, "attack_max_hostage_per_day"))
        if my_a_count >= max_attacker_per_day:
            await reply("❌ خطا (محدودیتِ روزانه‌ی شما به سقف رسیده است)")
            return

        gun_item = session.get(db.ShopItem, gun.shop_item_id)
        power_mult = economy.power_boost_multiplier(session, attacker)
        attacker_power = (gun_item.power or 0) * power_mult

        defender_gun = get_equipped(session, target_id, "gun")
        defender_gun_power = 0.0
        if defender_gun and (defender_gun.uses_remaining is None or defender_gun.uses_remaining > 0):
            dg_item = session.get(db.ShopItem, defender_gun.shop_item_id)
            defender_gun_power = dg_item.power or 0

        defender_guard = get_equipped(session, target_id, "guard")
        defender_guard_power = 0.0
        if defender_guard and (defender_guard.uses_remaining is None or defender_guard.uses_remaining > 0):
            gd_item = session.get(db.ShopItem, defender_guard.shop_item_id)
            divisor = _cfg(session, "attack_guard_hostage_divisor") or 7
            defender_guard_power = (gd_item.power or 0) / divisor

        attacker_smoke = get_equipped(session, attacker_id, "smoke")

        base_hp = int(_cfg(session, "attack_battle_hp"))
        sess = db.AttackSession(
            attacker_id=attacker_id, target_id=target_id, chat_id=chat_id,
            attacker_hp=base_hp, defender_hp=base_hp,
            attacker_power=attacker_power, defender_gun_power=defender_gun_power,
            defender_guard_power=defender_guard_power,
            attacker_inventory_gun_id=gun.id,
            defender_inventory_guard_id=defender_guard.id if defender_guard else None,
            attacker_inventory_smoke_id=attacker_smoke.id if attacker_smoke else None,
            correct_option=random.choice(["a", "b", "c"]),
        )
        session.add(sess)
        session.commit()
        msg = await context.bot.send_message(
            chat_id,
            _battle_status_text(sess, attacker.display_name(), target.display_name(), int(_cfg(session, "attack_max_wrong_guesses"))),
            reply_markup=_battle_keyboard(sess.id, attacker_id),
        )
        sess.message_id = msg.message_id
        session.commit()
    finally:
        session.close()


def _battle_status_text(sess: db.AttackSession, attacker_name, target_name, max_wrong=3):
    return (
        f"⚔️ حمله به {target_name}\n\n"
        f"❤️ HP تو: {sess.attacker_hp} | ❤️ HP طرف: {sess.defender_hp}\n"
        f"🔫 قدرتِ مؤثرِ تو: {fmt(sess.attacker_power)}\n"
        f"🛡 دفاعِ مؤثرِ طرف (گروگان‌گیری): {fmt(sess.defender_guard_power)}\n"
        f"❌ اشتباه‌های تو: {sess.wrong_count}/{max_wrong}\n\n"
        "یکی از سه گزینه رو انتخاب کن؛ اگه درست بود بهش آسیب می‌زنی، اگه غلط بود اون بهت آسیب می‌زنه."
    )


def _battle_keyboard(session_id, owner_id):
    return InlineKeyboardMarkup([[
        InlineKeyboardButton(CHOICE_LABELS[c], callback_data=f"attack_guess:{session_id}:{c}:{owner_id}")
        for c in ("a", "b", "c")
    ]])


async def cb_attack_guess(update, context):
    _, session_id, choice, owner_id = update.callback_query.data.split(":")
    session_id, owner_id = int(session_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        sess = session.get(db.AttackSession, session_id)
        if not sess or sess.status != "active":
            await update.callback_query.answer("این نبرد دیگه فعال نیست.", show_alert=True)
            return
        if sess.attacker_id != owner_id:
            await update.callback_query.answer("این نبردِ تو نیست.", show_alert=True)
            return

        max_wrong = int(_cfg(session, "attack_max_wrong_guesses"))
        wrong_divisor = _cfg(session, "attack_wrong_guess_divisor") or 6

        correct = (choice == sess.correct_option)
        sess.last_action_at = _nowt()
        if correct:
            dmg = max(0.0, sess.attacker_power - sess.defender_guard_power)
            sess.defender_hp = max(0, sess.defender_hp - int(round(dmg)))
        else:
            sess.wrong_count += 1
            dmg = sess.defender_gun_power / wrong_divisor
            sess.attacker_hp = max(0, sess.attacker_hp - int(round(dmg)))

        attacker = session.get(db.User, sess.attacker_id)
        target = session.get(db.User, sess.target_id)

        if sess.attacker_hp <= 0:
            outcome = await _resolve_attacker_killed(session, sess)
        elif sess.defender_hp <= 0:
            outcome = await _resolve_hostage_success(session, sess)
        elif sess.wrong_count >= max_wrong:
            outcome = await _resolve_attacker_failed(session, sess)
        else:
            sess.correct_option = random.choice(["a", "b", "c"])
            session.commit()
            await update.callback_query.edit_message_text(
                _battle_status_text(sess, attacker.display_name(), target.display_name(), max_wrong),
                reply_markup=_battle_keyboard(sess.id, owner_id),
            )
            await update.callback_query.answer("✅ زدی!" if correct else "❌ اشتباه بود!")
            return

        session.commit()
        await update.callback_query.edit_message_text(outcome, reply_markup=None)
        await update.callback_query.answer()
    finally:
        session.close()


def _finalize_equipment_use(session, sess: db.AttackSession, defender_used_gun: bool):
    gun_inv = session.get(db.InventoryItem, sess.attacker_inventory_gun_id) if sess.attacker_inventory_gun_id else None
    consume_use(session, gun_inv)
    if sess.defender_inventory_guard_id:
        guard_inv = session.get(db.InventoryItem, sess.defender_inventory_guard_id)
        consume_use(session, guard_inv)
    if defender_used_gun:
        defender_gun_inv = get_equipped(session, sess.target_id, "gun")
        if defender_gun_inv:
            consume_use(session, defender_gun_inv)


async def _resolve_hostage_success(session, sess: db.AttackSession):
    nowt = _nowt()
    sess.status = "hostage_success"
    sess.resolved_at = nowt
    _finalize_equipment_use(session, sess, defender_used_gun=sess.wrong_count > 0)

    smoke_pct = 0.0
    if sess.attacker_inventory_smoke_id:
        smoke_inv = session.get(db.InventoryItem, sess.attacker_inventory_smoke_id)
        if smoke_inv:
            smoke_item = session.get(db.ShopItem, smoke_inv.shop_item_id)
            smoke_pct = smoke_item.pct or 0
            consume_use(session, smoke_inv)

    duration = int(_cfg(session, "attack_hostage_duration_minutes"))
    session.add(db.Hostage(
        victim_id=sess.target_id, attacker_id=sess.attacker_id, chat_id=sess.chat_id,
        started_at=nowt, ends_at=nowt + datetime.timedelta(minutes=duration),
        status="active", escape_checks_done=0, smoke_pct=smoke_pct,
    ))
    target = session.get(db.User, sess.target_id)
    ransom = _cfg(session, "attack_hostage_ransom_amount")
    return (
        f"🎉 موفق شدی! {target.display_name()} الان گروگانِ توئه ({duration} دقیقه).\n"
        f"تولیدِ Hop Manager اون کم می‌شه و مالِ تو زیاد می‌شه، مگر اینکه فرار کنه یا "
        f"{fmt(ransom)} 🪙 برای آزادیش بده."
    )


async def _resolve_attacker_failed(session, sess: db.AttackSession):
    nowt = _nowt()
    sess.status = "attacker_failed"
    sess.resolved_at = nowt
    _finalize_equipment_use(session, sess, defender_used_gun=sess.wrong_count > 0)

    minutes = int(_cfg(session, "attack_fail_defender_penalty_minutes"))
    pct = _cfg(session, "attack_fail_defender_penalty_pct")
    session.add(db.ProductionPenalty(
        user_id=sess.target_id, kind="defender_fail", multiplier=pct / 100.0,
        ends_at=nowt + datetime.timedelta(minutes=minutes),
    ))

    transfer = _cfg(session, "attack_fail_transfer_amount")
    defender = session.get(db.User, sess.target_id)
    attacker = session.get(db.User, sess.attacker_id)
    available = (defender.bank_balance or 0) + (defender.hop_points or 0)
    take = min(transfer, available)
    from_bank = min(take, defender.bank_balance or 0)
    from_cash = take - from_bank
    defender.bank_balance = (defender.bank_balance or 0) - from_bank
    defender.hop_points = (defender.hop_points or 0) - from_cash
    if attacker:
        attacker.hop_points = (attacker.hop_points or 0) + take

    return (
        f"❌ تلاشِ گروگان‌گیری شکست خورد.\n"
        f"💸 {fmt(take)} 🪙 از طرف به‌عنوانِ خسارت گرفتی، و تولیدِ Hop Managerِ اون "
        f"{minutes} دقیقه روی {fmt(pct)}٪ می‌مونه."
    )


async def _resolve_attacker_killed(session, sess: db.AttackSession):
    nowt = _nowt()
    sess.status = "attacker_killed"
    sess.resolved_at = nowt
    _finalize_equipment_use(session, sess, defender_used_gun=sess.wrong_count > 0)

    minutes = int(_cfg(session, "attack_killed_penalty_minutes"))
    pct = _cfg(session, "attack_killed_penalty_pct")
    session.add(db.ProductionPenalty(
        user_id=sess.attacker_id, kind="attacker_killed", multiplier=pct / 100.0,
        ends_at=nowt + datetime.timedelta(minutes=minutes),
    ))
    return f"💀 کشته شدی! تولیدِ Hop Managerِ خودت به مدتِ {minutes} دقیقه روی {fmt(pct)}٪ میفته."


# ---------------------------------------------------------------------------
# بررسیِ فرارِ گروگان - از jobs.py هر تیک صدا زده می‌شه
# ---------------------------------------------------------------------------

async def tick_hostage_escapes(session, context):
    nowt = _nowt()
    active = session.query(db.Hostage).filter_by(status="active").all()
    for h in active:
        if h.ends_at <= nowt:
            h.status = "released"
            await _notify_hostage_ended(context, h, "⏳ مدتِ گروگان‌گیری تموم شد؛ آزاد شدی.",
                                         "⏳ مدتِ گروگان‌گیریت تموم شد؛ گروگانت آزاد شد.")
            continue
        interval = _cfg(session, "attack_hostage_check_interval_minutes") or 10
        elapsed_min = (nowt - h.started_at).total_seconds() / 60.0
        due_checks = min(6, int(elapsed_min // interval))
        while h.escape_checks_done < due_checks and h.status == "active":
            h.escape_checks_done += 1
            base_pct = _cfg(session, "attack_hostage_base_escape_pct") or 70
            escape_pct = max(0.0, min(100.0, base_pct - (h.smoke_pct or 0)))
            if random.uniform(0, 100) < escape_pct:
                h.status = "escaped"
                await _notify_hostage_ended(context, h, "🏃 فرار کردی و آزاد شدی!",
                                             "🏃 گروگانت فرار کرد؛ گروگان‌گیری تموم شد.")
                break
    session.commit()


async def _notify_hostage_ended(context, h: db.Hostage, victim_text: str, attacker_text: str):
    if h.chat_id:
        try:
            await context.bot.send_message(h.chat_id, f"{victim_text} (👤 {h.victim_id})")
        except Exception:
            pass


# ---------------------------------------------------------------------------
# نبردِ تن‌به‌تن (بازیِ کازینوییِ دونفره)
# ---------------------------------------------------------------------------

DUEL_MOVES = {"atk": "⚔️ حمله", "def": "🛡 دفاع", "cnt": "🔄 ضدحمله"}


def _duel_lobby_keyboard(lobby_id, host_id):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🚪 ورود به نبرد", callback_data=f"duel_join:{lobby_id}")],
        [InlineKeyboardButton("❌ کنسل پرایوت", callback_data=f"duel_cancel:{lobby_id}:{host_id}")],
    ])


async def cb_duel_new(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(
        update, context, "💰 مبلغِ استیکِ نبرد رو بفرست (هر دو بازیکن همین‌قدر می‌ذارن):",
        {"type": "duel_stake"}, "attack_awaiting",
    )


async def attack_duel_stake_handler(update, context, amount):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if amount <= 0:
            await update.message.reply_text("❌ مقدار باید بزرگ‌تر از صفر باشه؛ عملیات لغو شد.")
            return
        if user.hop_points < amount - 0.5:
            await update.message.reply_text(f"❌ موجودی کافی نیست! {fmt(amount)} 🪙 لازمه.")
            return
        user.hop_points -= amount
        lobby = db.DuelLobby(chat_id=update.effective_chat.id, host_id=user.telegram_id, stake=amount, status="waiting")
        session.add(lobby)
        session.commit()
        msg = await update.message.reply_text(
            f"⚔️ لابیِ نبردِ تن‌به‌تنِ {user.display_name()} - استیک: {fmt(amount)} 🪙\n\nمنتظرِ نفرِ دومه...",
            reply_markup=_duel_lobby_keyboard(lobby.id, user.telegram_id),
        )
        lobby.message_id = msg.message_id
        session.commit()
    finally:
        session.close()


async def cb_duel_join(update, context):
    lobby_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        lobby = session.get(db.DuelLobby, lobby_id)
        if not lobby or lobby.status != "waiting":
            await update.callback_query.answer("❌ این لابی دیگه فعال نیست.", show_alert=True)
            return
        guest = db.get_or_create_user(session, update.effective_user)
        if guest.telegram_id == lobby.host_id:
            await update.callback_query.answer("❌ نمی‌تونی با خودت وارد لابی بشی.", show_alert=True)
            return
        if guest.hop_points < lobby.stake - 0.5:
            await update.callback_query.answer(f"❌ موجودی کافی نیست! {fmt(lobby.stake)} 🪙 لازمه.", show_alert=True)
            return
        guest.hop_points -= lobby.stake
        lobby.guest_id = guest.telegram_id
        lobby.status = "battle"
        hp = int(db.cfg_get_float(session, "duel_battle_hp"))
        lobby.hp1 = hp
        lobby.hp2 = hp
        session.commit()
        host = session.get(db.User, lobby.host_id)
        await update.callback_query.edit_message_text(
            _duel_status_text(lobby, host.display_name(), guest.display_name()),
            reply_markup=_duel_move_keyboard(lobby.id),
        )
        await update.callback_query.answer("✅ وارد شدی! نبرد شروع شد.")
    finally:
        session.close()


async def cb_duel_cancel(update, context):
    _, lobby_id, host_id = update.callback_query.data.split(":")
    lobby_id, host_id = int(lobby_id), int(host_id)
    session = db.get_session()
    try:
        lobby = session.get(db.DuelLobby, lobby_id)
        if not lobby or lobby.status != "waiting":
            await update.callback_query.answer("❌ این لابی دیگه قابلِ لغو نیست.", show_alert=True)
            return
        if update.effective_user.id != lobby.host_id:
            await update.callback_query.answer("❌ فقط سازنده‌ی لابی می‌تونه کنسلش کنه.", show_alert=True)
            return
        host = session.get(db.User, lobby.host_id)
        if host:
            host.hop_points += lobby.stake
        lobby.status = "cancelled"
        lobby.ended_at = _nowt()
        session.commit()
        await update.callback_query.edit_message_text("❌ لابی لغو شد؛ استیک برگشت.", reply_markup=None)
        await update.callback_query.answer()
    finally:
        session.close()


def _duel_status_text(lobby: db.DuelLobby, name1, name2):
    p1_locked = "✅ انتخاب کرد" if lobby.move1 else "⏳ منتظره"
    p2_locked = "✅ انتخاب کرد" if lobby.move2 else "⏳ منتظره"
    extra = "\n🔥 راندِ نهاییِ ناگهانی! فقط حمله ممکنه." if lobby.sudden_death else ""
    return (
        f"⚔️ نبردِ تن‌به‌تن - راندِ {lobby.round_no}{extra}\n\n"
        f"❤️ {name1}: {lobby.hp1}  |  {p1_locked}\n"
        f"❤️ {name2}: {lobby.hp2}  |  {p2_locked}\n\n"
        f"💰 استیک: {fmt(lobby.stake)} 🪙 هرکدوم"
    )


def _duel_move_keyboard(lobby_id, sudden_death=False):
    moves = [("atk", DUEL_MOVES["atk"])] if sudden_death else list(DUEL_MOVES.items())
    return InlineKeyboardMarkup([[InlineKeyboardButton(label, callback_data=f"duel_move:{lobby_id}:{key}")] for key, label in moves])


async def cb_duel_move(update, context):
    _, lobby_id, move = update.callback_query.data.split(":")
    lobby_id = int(lobby_id)
    session = db.get_session()
    try:
        lobby = session.get(db.DuelLobby, lobby_id)
        if not lobby or lobby.status != "battle":
            await update.callback_query.answer("❌ این نبرد دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        if uid not in (lobby.host_id, lobby.guest_id):
            await update.callback_query.answer("❌ تو تو این نبرد نیستی.", show_alert=True)
            return
        if lobby.sudden_death and move != "atk":
            await update.callback_query.answer("❌ تو راندِ نهایی فقط حمله ممکنه.", show_alert=True)
            return

        if uid == lobby.host_id:
            if lobby.move1:
                await update.callback_query.answer("قبلاً انتخاب کردی؛ منتظرِ نفرِ دوم باش.", show_alert=True)
                return
            lobby.move1 = move
        else:
            if lobby.move2:
                await update.callback_query.answer("قبلاً انتخاب کردی؛ منتظرِ نفرِ اول باش.", show_alert=True)
                return
            lobby.move2 = move

        if not (lobby.move1 and lobby.move2):
            session.commit()
            host = session.get(db.User, lobby.host_id)
            guest = session.get(db.User, lobby.guest_id)
            await update.callback_query.edit_message_text(
                _duel_status_text(lobby, host.display_name(), guest.display_name()),
                reply_markup=_duel_move_keyboard(lobby.id, lobby.sudden_death),
            )
            await update.callback_query.answer("✅ ثبت شد؛ منتظرِ حریفت باش.")
            return

        await _resolve_duel_round(update, context, session, lobby)
        await update.callback_query.answer()
    finally:
        session.close()


BASE_DUEL_DAMAGE = 250  # آسیبِ عادیِ پایه‌ی هر راند - از همون HP اولیه (۱۵۰۰) طوری تنظیم شده که نبرد چندراندی باشه


def _duel_round_damages(m1, m2):
    """برمی‌گردونه (dmg_to_2, dmg_to_1) - آسیبی که هرکدوم به‌ازای انتخابِ خودشون وارد می‌کنن."""
    base = BASE_DUEL_DAMAGE
    if m1 == "atk" and m2 == "atk":
        return base, base
    if m1 == "atk" and m2 == "def":
        return base * 0.5, 0
    if m1 == "def" and m2 == "atk":
        return 0, base * 0.5
    if m1 == "def" and m2 == "def":
        return 0, 0
    if m1 == "cnt" and m2 == "atk":
        return base * 1.25, base * 0.5  # ضدحمله دمیجِ بیشتر می‌زنه و کمتر می‌گیره
    if m1 == "atk" and m2 == "cnt":
        return base * 0.5, base * 1.25
    if m1 == "cnt" and m2 == "def":
        return 0, 0
    if m1 == "def" and m2 == "cnt":
        return 0, 0
    if m1 == "cnt" and m2 == "cnt":
        return base * 0.75, base * 0.75
    return 0, 0


async def _resolve_duel_round(update, context, session, lobby: db.DuelLobby):
    dmg_to_2, dmg_to_1 = _duel_round_damages(lobby.move1, lobby.move2)
    lobby.hp2 = max(0, lobby.hp2 - int(round(dmg_to_2)))
    lobby.hp1 = max(0, lobby.hp1 - int(round(dmg_to_1)))

    host = session.get(db.User, lobby.host_id)
    guest = session.get(db.User, lobby.guest_id)

    if lobby.hp1 <= 0 and lobby.hp2 <= 0:
        if lobby.sudden_death:
            await _finish_duel(update, context, session, lobby, winner_id=None)
            return
        lobby.sudden_death = True
        lobby.round_no += 1
        lobby.move1, lobby.move2 = None, None
        hp = int(db.cfg_get_float(session, "duel_battle_hp"))
        lobby.hp1, lobby.hp2 = hp, hp
        session.commit()
        await update.callback_query.edit_message_text(
            _duel_status_text(lobby, host.display_name(), guest.display_name()) + "\n\n🤝 راند مساوی شد؛ راندِ نهایی شروع شد!",
            reply_markup=_duel_move_keyboard(lobby.id, True),
        )
        return

    if lobby.hp1 <= 0:
        await _finish_duel(update, context, session, lobby, winner_id=lobby.guest_id)
        return
    if lobby.hp2 <= 0:
        await _finish_duel(update, context, session, lobby, winner_id=lobby.host_id)
        return

    lobby.round_no += 1
    lobby.move1, lobby.move2 = None, None
    session.commit()
    await update.callback_query.edit_message_text(
        _duel_status_text(lobby, host.display_name(), guest.display_name()),
        reply_markup=_duel_move_keyboard(lobby.id),
    )


async def _finish_duel(update, context, session, lobby: db.DuelLobby, winner_id):
    lobby.status = "finished"
    lobby.ended_at = _nowt()
    lobby.winner_id = winner_id
    total = lobby.stake * 2
    if winner_id:
        winner = session.get(db.User, winner_id)
        if winner:
            winner.hop_points += total
        winner_name = winner.display_name() if winner else str(winner_id)
        text = f"🏆 نبرد تموم شد! برنده: {winner_name} - گرفت {fmt(total)} 🪙."
    else:
        host = session.get(db.User, lobby.host_id)
        guest = session.get(db.User, lobby.guest_id)
        if host:
            host.hop_points += lobby.stake
        if guest:
            guest.hop_points += lobby.stake
        text = "🤝 نبرد مساوی شد؛ استیکِ هرکدوم بهش برگشت."
    session.commit()
    await update.callback_query.edit_message_text(text, reply_markup=None)


# ---------------------------------------------------------------------------
# مسیریاب‌ها
# ---------------------------------------------------------------------------

ATTACK_PREFIX_MAP = {
    "attack_home": cb_attack_home,
    "attack_shop": cb_attack_shop,
    "attack_shop_cat": cb_attack_shop_cat,
    "attack_shop_view": cb_attack_shop_view,
    "attack_shop_buy": cb_attack_shop_buy,
    "attack_bag": cb_attack_bag,
    "attack_bag_view": cb_attack_bag_view,
    "attack_bag_equip": cb_attack_bag_equip,
    "attack_bag_unequip": cb_attack_bag_unequip,
    "attack_bag_use_item": cb_attack_bag_use_item,
    "attack_bag_use_booster": cb_attack_bag_use_booster,
    "attack_bag_discard": cb_attack_bag_discard,
    "attack_target_ask": cb_attack_target_ask,
    "attack_guess": cb_attack_guess,
    "attack_status": cb_attack_status,
    "attack_ransom": cb_attack_ransom,
    "attack_hostage_confirm": cb_attack_hostage_confirm,
    "attack_hostage_cancel": cb_attack_hostage_cancel,
}


async def attack_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = ATTACK_PREFIX_MAP.get(prefix)
    if handler:
        await handler(update, context)
        return True
    return False


DUEL_PREFIX_MAP = {
    "duel_new": cb_duel_new,
    "duel_join": cb_duel_join,
    "duel_cancel": cb_duel_cancel,
    "duel_move": cb_duel_move,
}


async def duel_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = DUEL_PREFIX_MAP.get(prefix)
    if handler:
        await handler(update, context)
        return True
    return False
