# -*- coding: utf-8 -*-
"""
رمزیاب 🎨 - بازیِ جدیدِ کازینو هاپویی، بر اساسِ Mastermind، دقیقاً ۲نفره.

هر بازیکن یه توالیِ مخفی از رنگ (به‌طولِ code_length، از بینِ palette_size رنگ،
تکرار مجازه) می‌چینه - جدا از هم، تو پیویِ بات. بعد نوبتی سعیِ می‌کنن کدِ
همدیگه رو حدس بزنن؛ هر حدس فیدبک می‌گیره:
  ⚫ = این‌قدر رنگِ درست، دقیقاً تو جای درست
  ⚪ = این‌قدر رنگِ درست، ولی جاش اشتباهه
اولین کسی که کدِ حریف رو دقیق حدس بزنه (همه‌ش ⚫) برنده‌ست. اگه هر دو نفر
max_turns نوبت رو بدونِ برد استفاده کنن، هرکی تو بهترین حدسش ⚫یِ بیشتری
داشته (مساوی که شد، ⚪ بیشتر) برنده‌ست؛ مساویِ کامل = هر دو مبلغِ ورودیشون رو
پس می‌گیرن.
"""
import asyncio
import datetime
import json
import random

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import Forbidden, BadRequest

import db
import mentions
from handlers import fmt, send_response, is_reply_to_prompt, ask_for_input, parse_amount
import casino

COLOR_EMOJIS = ["🔴", "🟠", "🟡", "🟢", "🔵", "🟣", "🟤", "⚫"]  # حداکثر ۸ رنگ
ACTION_TIMEOUT_SECONDS = 120  # هر نوبت/مرحله (جای‌گذاری یا حدس‌زدن) اگه ۲ دقیقه کسی کاری نکنه، طرفِ مقابل برنده می‌شه
SETUP_ABANDON_TIMEOUT_SECONDS = 60

_round_locks = {}


def _get_round_lock(round_id: int) -> asyncio.Lock:
    lock = _round_locks.get(round_id)
    if lock is None:
        lock = asyncio.Lock()
        _round_locks[round_id] = lock
    return lock


def with_round_lock(func):
    async def wrapper(update, context):
        try:
            rid = int(update.callback_query.data.split(":")[1])
        except (ValueError, IndexError, AttributeError):
            await func(update, context)
            return
        async with _get_round_lock(rid):
            await func(update, context)
        session = db.get_session()
        try:
            r = session.get(db.MastermindRound, rid)
            if not r or r.status in ("resolved", "cancelled"):
                _round_locks.pop(rid, None)
        finally:
            session.close()
    return wrapper


def _load(text):
    try:
        return json.loads(text) if text else []
    except (TypeError, ValueError):
        return []


def _dump(obj):
    return json.dumps(obj)


def _touch(r):
    r.last_action_at = datetime.datetime.utcnow()


def _end_round(r, status):
    r.status = status
    r.ended_at = datetime.datetime.utcnow()


def _limits(session):
    code_length = max(2, min(6, db.cfg_get_int(session, "mm_code_length") or 4))
    palette_size = max(3, min(len(COLOR_EMOJIS), db.cfg_get_int(session, "mm_palette_size") or 6))
    max_turns = max(1, db.cfg_get_int(session, "mm_max_turns") or 10)
    return code_length, palette_size, max_turns


async def _check_initiator(update, r):
    if not r or update.effective_user.id != r.initiator_id:
        await update.callback_query.answer("⛔️ این بازی مال تو نیست! برای ساختن بازی خودت رو دکمه‌ی «رمزیاب» بزن.", show_alert=True)
        return False
    return True


async def _refund(session, r):
    for uid in (r.player1_id, r.player2_id):
        if not uid:
            continue
        u = session.get(db.User, uid)
        if u and r.entry_amount:
            u.hop_points += r.entry_amount


def score_guess(secret, guess):
    """الگوریتمِ استانداردِ Mastermind: چندتا دقیقاً درستن (رنگ+جا)، چندتا فقط
    رنگش درسته ولی جاش نه. بدونِ دوبار‌شمردنِ رنگ‌های تکراری."""
    black = sum(1 for s, g in zip(secret, guess) if s == g)
    secret_left, guess_left = {}, {}
    for s, g in zip(secret, guess):
        if s != g:
            secret_left[s] = secret_left.get(s, 0) + 1
            guess_left[g] = guess_left.get(g, 0) + 1
    white = sum(min(secret_left.get(c, 0), n) for c, n in guess_left.items())
    return black, white


def _best_score(guesses):
    """بهترین حدسِ یه بازیکن (برای مقایسه‌ی نهایی وقتی کسی برنده نشده): اول بر
    اساسِ بیشترین ⚫، بعد بیشترین ⚪."""
    best = (0, 0)
    for _, black, white in guesses:
        if (black, white) > best:
            best = (black, white)
    return best


# ---------------------------------------------------------------------------
# ساخت/تنظیمات (تو گروه)
# ---------------------------------------------------------------------------

async def cb_mm_new(update, context):
    parts = update.callback_query.data.split(":")
    owner_id = int(parts[1]) if len(parts) > 1 else None
    if owner_id is not None and update.effective_user.id != owner_id:
        await update.callback_query.answer(
            "⛔️ این منو مالِ تو نیست! برای بازکردنِ کازینوی خودت، بنویس «کازینو هاپویی».",
            show_alert=True)
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, update.effective_user.id):
            await update.callback_query.answer(
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, update.effective_user.id)
        if remaining > 0:
            await update.callback_query.answer(
                f"⏳ کازینوی قبلیِ این گروه تازه تموم شده. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        code_length, palette_size, max_turns = _limits(session)
        r = db.MastermindRound(
            chat_id=update.effective_chat.id,
            group_message_id=update.callback_query.message.message_id,
            initiator_id=update.effective_user.id,
            status="setup",
            code_length=code_length,
            palette_size=palette_size,
            max_turns=max_turns,
        )
        session.add(r)
        session.commit()
        text, kb = _render_setup(r)
        await send_response(update, text, kb)
    finally:
        session.close()


def _render_setup(r):
    amount_txt = fmt(r.entry_amount) + " 🪙" if r.entry_amount else "— تنظیم نشده —"
    palette = " ".join(COLOR_EMOJIS[:r.palette_size])
    text = (
        f"🎨 رمزیاب (۲نفره)\n\n"
        f"💰 مبلغ ورودی: {amount_txt}\n"
        f"🎨 رنگ‌ها ({r.palette_size} تا): {palette}\n"
        f"📏 طولِ کد: {r.code_length} | 🎯 حداکثر نوبت: {r.max_turns}\n\n"
        "بعدِ انتخابِ مبلغ، بازی تو گروه لابی می‌شه؛ یه نفرِ دیگه باید بپیونده. "
        "بعدش هر دو تو پیویِ بات، جدا از هم، کدِ مخفیِ خودشون رو می‌چینن."
    )
    rows = [[InlineKeyboardButton("💰 انتخاب مبلغ ورودی", callback_data=f"mm_amt_menu:{r.id}")]]
    if r.entry_amount:
        rows.append([InlineKeyboardButton("▶️ شروع بازی", callback_data=f"mm_start:{r.id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت (تغییرِ نوعِ بازی)", callback_data=f"mm_back_to_types:{r.id}"),
                 InlineKeyboardButton("❌ لغو", callback_data=f"mm_cancel:{r.id}")])
    return text, InlineKeyboardMarkup(rows)


async def cb_mm_back_to_types(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _end_round(r, "cancelled")
        session.commit()
        text, kb = casino.menu_text_and_kb(r.initiator_id)
        await send_response(update, text, kb)
    finally:
        session.close()


async def cb_mm_cancel(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status not in ("setup", "lobby"):
            await update.callback_query.answer("⛔️ این بازی دیگه قابلِ لغو نیست.", show_alert=True)
            return
        await _refund(session, r)
        _end_round(r, "cancelled")
        session.commit()
        await send_response(update, "❌ بازی لغو شد.", None)
    finally:
        session.close()


async def cb_mm_amt_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        rows = [[InlineKeyboardButton(f"{a:,}", callback_data=f"mm_amt_pick:{rid}:{a}")] for a in casino._preset_amounts(session)]
        rows.append([InlineKeyboardButton("✏️ مبلغِ دلخواه", callback_data=f"mm_amt_custom:{rid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"mm_back:{rid}")])
        await send_response(update, "💰 مبلغِ ورودی رو انتخاب کن:", InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_mm_amt_pick(update, context):
    _, rid, amount = update.callback_query.data.split(":")
    rid, amount = int(rid), float(amount)
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if casino.max_bet_exceeded(session, amount):
            await update.callback_query.answer(
                f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست.", show_alert=True)
            return
        r.entry_amount = amount
        session.commit()
        text, kb = _render_setup(r)
        await send_response(update, text, kb)
    finally:
        session.close()


async def cb_mm_amt_custom(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
    finally:
        session.close()
    await ask_for_input(update, context, "✏️ مبلغ ورودیِ دلخواه رو به عدد بفرست:", {"type": "amount", "round_id": rid}, "mm_awaiting")


async def cb_mm_back(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not await _check_initiator(update, r):
            return
        text, kb = _render_setup(r)
        await send_response(update, text, kb)
    finally:
        session.close()


async def mm_awaiting_handler(update, context):
    from telegram.ext import ApplicationHandlerStop
    state = context.user_data.get("mm_awaiting")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return
    context.user_data.pop("mm_awaiting", None)
    rid = state["round_id"]
    amount = parse_amount(update.message.text or "")
    if amount is None or amount <= 0:
        await update.message.reply_text("❌ مقدار نامعتبره؛ عملیات لغو شد.")
        raise ApplicationHandlerStop
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not r or r.status != "setup" or update.effective_user.id != r.initiator_id:
            await update.message.reply_text("این بازی دیگه فعال نیست.")
            raise ApplicationHandlerStop
        if casino.max_bet_exceeded(session, amount):
            await update.message.reply_text(f"❌ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست؛ عملیات لغو شد.")
            raise ApplicationHandlerStop
        r.entry_amount = amount
        session.commit()
        # نکته‌ی مهم (درسِ گرفته‌شده از باگِ مشابه تو نبردِ دریایی): باید همون
        # پیامِ اصلیِ بازی (group_message_id) رو ادیت کنیم، نه یه پیامِ جدید
        # بفرستیم - وگرنه پیامِ قدیمی برای همیشه رهاشده/نمایشِ‌اشتباه می‌مونه.
        text, kb = _render_setup(r)
        try:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text, reply_markup=kb)
        except Exception:
            msg = await update.message.reply_text(text, reply_markup=kb)
            r.group_message_id = msg.message_id
            session.commit()
    finally:
        session.close()
    raise ApplicationHandlerStop


# ---------------------------------------------------------------------------
# شروع / لابی / پیوستن
# ---------------------------------------------------------------------------

@with_round_lock
async def cb_mm_start(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if not r.entry_amount:
            await update.callback_query.answer("اول باید مبلغِ ورودی رو انتخاب کنی.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await update.callback_query.answer(f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        r.player1_id = update.effective_user.id
        r.status = "lobby"
        r.lobby_opened_at = datetime.datetime.utcnow()
        _touch(r)
        session.commit()
        text = (
            f"🎨 رمزیاب\n\n"
            f"💰 مبلغِ ورودی: {fmt(r.entry_amount)} 🪙\n"
            f"👤 بازیکنِ اول: {mentions.of(update.effective_user)}\n\n"
            f"⏳ منتظرِ پیوستنِ نفرِ دوم..."
        )
        rows = [
            [InlineKeyboardButton("🎨 پیوستن به بازی", callback_data=f"mm_join:{rid}")],
            [InlineKeyboardButton("❌ لغو", callback_data=f"mm_cancel:{rid}")],
        ]
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@with_round_lock
async def cb_mm_join(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not r or r.status != "lobby":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if update.effective_user.id == r.player1_id:
            await update.callback_query.answer("⛔️ نمی‌تونی با خودت بازی کنی!", show_alert=True)
            return
        if casino._user_has_active_round(session, update.effective_user.id):
            await update.callback_query.answer(
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, update.effective_user.id)
        if remaining > 0:
            await update.callback_query.answer(
                f"⏳ خودت تازه یه کازینو تموم کردی. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await update.callback_query.answer(f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        r.player2_id = update.effective_user.id
        r.status = "placing"
        _touch(r)
        session.commit()
        await update.callback_query.answer("✅ پیوستی!")
        await _start_placement_phase(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# فازِ چیدنِ کد (پیوی)
# ---------------------------------------------------------------------------

async def _start_placement_phase(context, session, r):
    text = (
        f"🎨 رمزیاب شروع شد!\n\n"
        f"💰 مبلغِ ورودی: {fmt(r.entry_amount)} 🪙\n\n"
        "هر دو بازیکن الان تو پیویِ بات دارن کدِ مخفیِ خودشون رو می‌چینن. "
        f"⏳ اگه تا {ACTION_TIMEOUT_SECONDS} ثانیه دیگه هر دو کارشون تموم نشه، بازی لغو و پول‌ها برمی‌گرده."
    )
    try:
        await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
    except Exception:
        pass

    ok1 = await _send_placement_dm(context, r, r.player1_id, is_p1=True)
    ok2 = await _send_placement_dm(context, r, r.player2_id, is_p1=False)
    if not ok1 or not ok2:
        missing = [uid for uid, ok in ((r.player1_id, ok1), (r.player2_id, ok2)) if not ok]
        await _refund(session, r)
        _end_round(r, "cancelled")
        session.commit()
        names = "، ".join(str(uid) for uid in missing)
        try:
            await context.bot.edit_message_text(
                chat_id=r.chat_id, message_id=r.group_message_id,
                text=(f"❌ رمزیاب لغو شد چون نمی‌تونم به پیویِ این آیدی(ها) پیام بدم: {names}\n"
                      "(باید اول یه‌بار تو پیویِ بات «استارت» بزنن.) پول‌ها برگشت داده شد."))
        except Exception:
            pass
        return
    session.commit()


def _palette_keyboard(rid, callback_prefix, extra_rows=None):
    row = [InlineKeyboardButton(e, callback_data=f"{callback_prefix}:{rid}:{i}") for i, e in enumerate(COLOR_EMOJIS[:8])]
    rows = [row[:4], row[4:8]]
    if extra_rows:
        rows += extra_rows
    return rows


def _placement_keyboard(r, draft):
    rows = _palette_keyboard(r.id, "mm_place")
    rows[0] = rows[0][:min(4, r.palette_size)]
    rows[1] = rows[1][:max(0, r.palette_size - 4)]
    ctrl = []
    if draft:
        ctrl.append(InlineKeyboardButton("🗑 حذفِ آخرین", callback_data=f"mm_place_undo:{r.id}"))
    if len(draft) == r.code_length:
        ctrl.append(InlineKeyboardButton("✅ تایید نهایی", callback_data=f"mm_place_confirm:{r.id}"))
    if ctrl:
        rows.append(ctrl)
    shown = " ".join(COLOR_EMOJIS[c] for c in draft) or "(خالی)"
    rows.append([InlineKeyboardButton(f"کدِ فعلی: {shown} ({len(draft)}/{r.code_length})", callback_data="noop")])
    return InlineKeyboardMarkup([row for row in rows if row])


async def _send_placement_dm(context, r, user_id, is_p1: bool) -> bool:
    draft = _load(r.player1_draft if is_p1 else r.player2_draft)
    text = (
        "🎨 رمزیاب - چیدنِ کدِ مخفی\n\n"
        f"با زدنِ رنگ‌ها، یه کدِ {r.code_length}تایی بچین (تکرارِ رنگ مجازه). "
        "این صفحه رو کسِ دیگه‌ای نمی‌بینه."
    )
    try:
        msg = await context.bot.send_message(user_id, text, reply_markup=_placement_keyboard(r, draft))
    except (Forbidden, BadRequest):
        return False
    except Exception:
        return False
    if is_p1:
        r.player1_dm_message_id = msg.message_id
    else:
        r.player2_dm_message_id = msg.message_id
    return True


@with_round_lock
async def cb_mm_place(update, context):
    _, rid, color_idx = update.callback_query.data.split(":")
    rid, color_idx = int(rid), int(color_idx)
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not r or r.status != "placing":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        is_p1 = uid == r.player1_id
        if not is_p1 and uid != r.player2_id:
            await update.callback_query.answer("⛔️ این بازی مالِ تو نیست.", show_alert=True)
            return
        if color_idx >= r.palette_size:
            await update.callback_query.answer("این رنگ تو این بازی فعال نیست.", show_alert=True)
            return
        draft = _load(r.player1_draft if is_p1 else r.player2_draft)
        if len(draft) >= r.code_length:
            await update.callback_query.answer(f"کدت همینا کافیه ({r.code_length}تا)! اول تاییدش کن یا یکی رو پاک کن.", show_alert=True)
            return
        draft.append(color_idx)
        if is_p1:
            r.player1_draft = _dump(draft)
        else:
            r.player2_draft = _dump(draft)
        _touch(r)
        session.commit()
        await update.callback_query.answer()
        try:
            await update.callback_query.edit_message_reply_markup(_placement_keyboard(r, draft))
        except Exception:
            pass
    finally:
        session.close()


@with_round_lock
async def cb_mm_place_undo(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not r or r.status != "placing":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        is_p1 = uid == r.player1_id
        if not is_p1 and uid != r.player2_id:
            await update.callback_query.answer("⛔️ این بازی مالِ تو نیست.", show_alert=True)
            return
        draft = _load(r.player1_draft if is_p1 else r.player2_draft)
        if draft:
            draft.pop()
        if is_p1:
            r.player1_draft = _dump(draft)
        else:
            r.player2_draft = _dump(draft)
        _touch(r)
        session.commit()
        await update.callback_query.answer()
        try:
            await update.callback_query.edit_message_reply_markup(_placement_keyboard(r, draft))
        except Exception:
            pass
    finally:
        session.close()


@with_round_lock
async def cb_mm_place_confirm(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not r or r.status != "placing":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        is_p1 = uid == r.player1_id
        if not is_p1 and uid != r.player2_id:
            await update.callback_query.answer("⛔️ این بازی مالِ تو نیست.", show_alert=True)
            return
        draft = _load(r.player1_draft if is_p1 else r.player2_draft)
        if len(draft) != r.code_length:
            await update.callback_query.answer(f"باید دقیقاً {r.code_length} تا رنگ انتخاب کنی.", show_alert=True)
            return
        if is_p1:
            r.player1_code = _dump(draft)
            r.player1_confirmed_at = datetime.datetime.utcnow()
            r.player1_draft = "[]"  # این باید خالی بشه وگرنه تو فازِ حدس‌زدن، اولین حدس بلافاصله «کامله» می‌گفت (باگ)
        else:
            r.player2_code = _dump(draft)
            r.player2_confirmed_at = datetime.datetime.utcnow()
            r.player2_draft = "[]"
        _touch(r)
        await update.callback_query.answer("✅ تاییدشد! منتظرِ حریف...")
        try:
            await update.callback_query.edit_message_text("✅ کدت ثبت شد. منتظرِ آماده‌شدنِ حریف...")
        except Exception:
            pass
        session.commit()

        if r.player1_confirmed_at and r.player2_confirmed_at:
            await _start_playing_phase(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# فازِ حدس‌زدن (پیوی)
# ---------------------------------------------------------------------------

def _guess_keyboard(r, draft):
    rows = _palette_keyboard(r.id, "mm_guess")
    rows[0] = rows[0][:min(4, r.palette_size)]
    rows[1] = rows[1][:max(0, r.palette_size - 4)]
    ctrl = []
    if draft:
        ctrl.append(InlineKeyboardButton("🗑 حذفِ آخرین", callback_data=f"mm_guess_undo:{r.id}"))
    if len(draft) == r.code_length:
        ctrl.append(InlineKeyboardButton("🔍 ارسالِ حدس", callback_data=f"mm_guess_submit:{r.id}"))
    if ctrl:
        rows.append(ctrl)
    shown = " ".join(COLOR_EMOJIS[c] for c in draft) or "(خالی)"
    rows.append([InlineKeyboardButton(f"حدسِ فعلی: {shown} ({len(draft)}/{r.code_length})", callback_data="noop")])
    return InlineKeyboardMarkup([row for row in rows if row])


def _history_lines(guesses):
    lines = []
    for guess, black, white in guesses:
        code_str = " ".join(COLOR_EMOJIS[c] for c in guess)
        lines.append(f"{code_str} → {'⚫' * black}{'⚪' * white}" if (black or white) else f"{code_str} → (هیچی)")
    return lines


async def _send_guess_dm(context, r, user_id, is_p1: bool, my_turn: bool):
    my_guesses = _load(r.player1_guesses if is_p1 else r.player2_guesses)
    draft = _load(r.player1_draft if is_p1 else r.player2_draft)
    header = "🎯 نوبتِ توئه! کدِ حریف رو حدس بزن:" if my_turn else "⏳ منتظرِ نوبتِ حریف..."
    lines = [f"🎨 رمزیاب - فازِ حدس‌زدن\n\n{header}\n",
             f"🎯 نوبت‌های استفاده‌شده: {len(my_guesses)}/{r.max_turns}"]
    hist = _history_lines(my_guesses)
    if hist:
        lines.append("")
        lines.extend(hist)
    text = "\n".join(lines)
    kb = _guess_keyboard(r, draft) if my_turn else InlineKeyboardMarkup([[InlineKeyboardButton("⏳ صبر کن...", callback_data="noop")]])
    dm_message_id = r.player1_dm_message_id if is_p1 else r.player2_dm_message_id
    try:
        if dm_message_id:
            await context.bot.edit_message_text(chat_id=user_id, message_id=dm_message_id, text=text, reply_markup=kb)
            return
    except Exception:
        pass
    try:
        msg = await context.bot.send_message(user_id, text, reply_markup=kb)
        if is_p1:
            r.player1_dm_message_id = msg.message_id
        else:
            r.player2_dm_message_id = msg.message_id
    except Exception:
        pass


async def _start_playing_phase(context, session, r):
    r.status = "playing"
    r.turn_user_id = random.choice([r.player1_id, r.player2_id])
    _touch(r)
    session.commit()
    try:
        await context.bot.edit_message_text(
            chat_id=r.chat_id, message_id=r.group_message_id,
            text="🎨 رمزیاب - کدها ثبت شد!\n\n🎲 شانسی مشخص شد که بازی رو کی شروع می‌کنه.\n⏳ نتیجه‌ی نهایی همینجا اعلام می‌شه.")
    except Exception:
        pass
    await _send_guess_dm(context, r, r.player1_id, True, r.turn_user_id == r.player1_id)
    await _send_guess_dm(context, r, r.player2_id, False, r.turn_user_id == r.player2_id)
    session.commit()


@with_round_lock
async def cb_mm_guess(update, context):
    _, rid, color_idx = update.callback_query.data.split(":")
    rid, color_idx = int(rid), int(color_idx)
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not r or r.status != "playing":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        is_p1 = uid == r.player1_id
        if not is_p1 and uid != r.player2_id:
            await update.callback_query.answer("⛔️ این بازی مالِ تو نیست.", show_alert=True)
            return
        if r.turn_user_id != uid:
            await update.callback_query.answer("⌛️ نوبتِ تو نیست، صبر کن.", show_alert=True)
            return
        if color_idx >= r.palette_size:
            await update.callback_query.answer("این رنگ تو این بازی فعال نیست.", show_alert=True)
            return
        draft = _load(r.player1_draft if is_p1 else r.player2_draft)
        if len(draft) >= r.code_length:
            await update.callback_query.answer("حدست کامله! یا بفرستش یا یکی رو پاک کن.", show_alert=True)
            return
        draft.append(color_idx)
        if is_p1:
            r.player1_draft = _dump(draft)
        else:
            r.player2_draft = _dump(draft)
        _touch(r)
        session.commit()
        await update.callback_query.answer()
        try:
            await update.callback_query.edit_message_reply_markup(_guess_keyboard(r, draft))
        except Exception:
            pass
    finally:
        session.close()


@with_round_lock
async def cb_mm_guess_undo(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not r or r.status != "playing" or r.turn_user_id != update.effective_user.id:
            await update.callback_query.answer("⛔️ الان نوبتِ تو نیست یا بازی فعال نیست.", show_alert=True)
            return
        is_p1 = update.effective_user.id == r.player1_id
        draft = _load(r.player1_draft if is_p1 else r.player2_draft)
        if draft:
            draft.pop()
        if is_p1:
            r.player1_draft = _dump(draft)
        else:
            r.player2_draft = _dump(draft)
        _touch(r)
        session.commit()
        await update.callback_query.answer()
        try:
            await update.callback_query.edit_message_reply_markup(_guess_keyboard(r, draft))
        except Exception:
            pass
    finally:
        session.close()


@with_round_lock
async def cb_mm_guess_submit(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.MastermindRound, rid)
        if not r or r.status != "playing":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        is_p1 = uid == r.player1_id
        if not is_p1 and uid != r.player2_id:
            await update.callback_query.answer("⛔️ این بازی مالِ تو نیست.", show_alert=True)
            return
        if r.turn_user_id != uid:
            await update.callback_query.answer("⌛️ نوبتِ تو نیست.", show_alert=True)
            return
        draft = _load(r.player1_draft if is_p1 else r.player2_draft)
        if len(draft) != r.code_length:
            await update.callback_query.answer(f"باید دقیقاً {r.code_length} تا رنگ انتخاب کنی.", show_alert=True)
            return
        my_guesses = _load(r.player1_guesses if is_p1 else r.player2_guesses)
        if len(my_guesses) >= r.max_turns:
            await update.callback_query.answer("نوبت‌هات تموم شده.", show_alert=True)
            return

        opp_code = _load(r.player2_code if is_p1 else r.player1_code)
        black, white = score_guess(opp_code, draft)
        my_guesses.append([draft, black, white])
        if is_p1:
            r.player1_guesses = _dump(my_guesses)
            r.player1_draft = "[]"
        else:
            r.player2_guesses = _dump(my_guesses)
            r.player2_draft = "[]"
        await update.callback_query.answer(f"نتیجه: {'⚫'*black}{'⚪'*white}" if (black or white) else "نتیجه: هیچی 😬")

        if black == r.code_length:
            _touch(r)
            session.commit()
            await _finish_round(context, session, r, winner_id=uid)
            return

        other_id = r.player2_id if is_p1 else r.player1_id
        other_guesses = _load(r.player2_guesses if is_p1 else r.player1_guesses)
        if len(my_guesses) >= r.max_turns and len(other_guesses) >= r.max_turns:
            _touch(r)
            session.commit()
            await _finish_round_by_score(context, session, r)
            return

        r.turn_user_id = other_id
        _touch(r)
        session.commit()
        await _send_guess_dm(context, r, uid, is_p1, my_turn=False)
        await _send_guess_dm(context, r, other_id, not is_p1, my_turn=True)
        session.commit()
    finally:
        session.close()


# ---------------------------------------------------------------------------
# پایانِ بازی
# ---------------------------------------------------------------------------

def _reveal_keyboard_text(code, enemy_guesses):
    code_str = " ".join(COLOR_EMOJIS[c] for c in code)
    lines = [f"🔑 کدِ خودت بود: {code_str}", "", "🗺 حدس‌های حریف رو کدت:"]
    lines.extend(_history_lines(enemy_guesses) or ["(هیچ حدسی نزد)"])
    return "\n".join(lines)


async def _send_final_reveal_dm(context, r, uid, result_line: str):
    is_p1 = uid == r.player1_id
    my_code = _load(r.player1_code if is_p1 else r.player2_code)
    enemy_guesses = _load(r.player2_guesses if is_p1 else r.player1_guesses)
    text = f"{result_line}\n\n" + _reveal_keyboard_text(my_code, enemy_guesses)
    dm_id = r.player1_dm_message_id if is_p1 else r.player2_dm_message_id
    try:
        if dm_id:
            await context.bot.edit_message_text(chat_id=uid, message_id=dm_id, text=text)
            return
    except Exception:
        pass
    try:
        await context.bot.send_message(uid, text)
    except Exception:
        pass


def _player_label(session, uid):
    u = session.get(db.User, uid)
    return u.display_name() if u else str(uid)


async def _finish_round(context, session, r, winner_id):
    loser_id = r.player2_id if winner_id == r.player1_id else r.player1_id
    pot = (r.entry_amount or 0) * 2
    winner = session.get(db.User, winner_id)
    if winner:
        winner.hop_points += pot
    _end_round(r, "resolved")
    session.commit()

    winner_turns = len(_load(r.player1_guesses if winner_id == r.player1_id else r.player2_guesses))
    winner_label = _player_label(session, winner_id)
    loser_label = _player_label(session, loser_id)
    text = (
        f"🏆 رمزیاب بینِ {winner_label} و {loser_label} تموم شد!\n\n"
        f"🥇 برنده: {winner_label} (تو نوبتِ {winner_turns}اُم کدِ حریف رو پیدا کرد)\n"
        f"😔 بازنده: {loser_label}\n"
        f"🎁 جایزه‌ی برنده: {fmt(pot)} 🪙"
    )
    try:
        await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
    except Exception:
        pass
    for uid in (r.player1_id, r.player2_id):
        won = uid == winner_id
        result_line = f"🎉 بردی! {fmt(pot)} 🪙 به حسابت اضافه شد." if won else "😔 باختی."
        await _send_final_reveal_dm(context, r, uid, result_line)


async def _finish_round_by_score(context, session, r):
    p1_best = _best_score(_load(r.player1_guesses))
    p2_best = _best_score(_load(r.player2_guesses))
    if p1_best == p2_best:
        await _refund(session, r)
        _end_round(r, "resolved")
        session.commit()
        p1_label = _player_label(session, r.player1_id)
        p2_label = _player_label(session, r.player2_id)
        text = (
            f"🤝 رمزیاب بینِ {p1_label} و {p2_label} مساوی شد!\n\n"
            f"بهترین حدسِ هر دو یکسان بود ({p1_best[0]}⚫ {p1_best[1]}⚪). مبلغِ ورودیِ هر دو برگشت داده شد."
        )
        try:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
        except Exception:
            pass
        for uid in (r.player1_id, r.player2_id):
            await _send_final_reveal_dm(context, r, uid, "🤝 مساوی شد! مبلغِ ورودیت برگشت داده شد.")
        return
    winner_id = r.player1_id if p1_best > p2_best else r.player2_id
    await _finish_round_score_win(context, session, r, winner_id)


async def _finish_round_score_win(context, session, r, winner_id):
    loser_id = r.player2_id if winner_id == r.player1_id else r.player1_id
    pot = (r.entry_amount or 0) * 2
    winner = session.get(db.User, winner_id)
    if winner:
        winner.hop_points += pot
    _end_round(r, "resolved")
    session.commit()
    best = _best_score(_load(r.player1_guesses if winner_id == r.player1_id else r.player2_guesses))
    winner_label = _player_label(session, winner_id)
    loser_label = _player_label(session, loser_id)
    text = (
        f"🏆 رمزیاب بینِ {winner_label} و {loser_label} تموم شد!\n\n"
        f"هیچ‌کدوم کدِ حریف رو کامل پیدا نکرد؛ نوبت‌ها تموم شد.\n"
        f"🥇 برنده: {winner_label} (بهترین حدسش: {best[0]}⚫ {best[1]}⚪)\n"
        f"😔 بازنده: {loser_label}\n"
        f"🎁 جایزه‌ی برنده: {fmt(pot)} 🪙"
    )
    try:
        await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
    except Exception:
        pass
    for uid in (r.player1_id, r.player2_id):
        won = uid == winner_id
        result_line = f"🎉 بردی! {fmt(pot)} 🪙 به حسابت اضافه شد." if won else "😔 باختی."
        await _send_final_reveal_dm(context, r, uid, result_line)


# ---------------------------------------------------------------------------
# جاروبِ تایم‌اوت
# ---------------------------------------------------------------------------

async def _resolve_timeout_forfeit(context, session, r):
    """اگه تو فازِ playing، کسی که نوبتش بود بیش‌ازحد صبر نکنه (حدس نزنه)،
    می‌بازه - حریف برنده‌ی کاملِ pot می‌شه (نه فقط لغو/برگشتِ پول)."""
    loser_id = r.turn_user_id
    winner_id = r.player2_id if loser_id == r.player1_id else r.player1_id
    pot = (r.entry_amount or 0) * 2
    winner = session.get(db.User, winner_id)
    if winner:
        winner.hop_points += pot
    _end_round(r, "resolved")
    session.commit()
    winner_label = _player_label(session, winner_id)
    loser_label = _player_label(session, loser_id)
    text = (
        f"⏳ رمزیاب بینِ {winner_label} و {loser_label} به‌خاطرِ تاخیر تموم شد!\n\n"
        f"😴 {loser_label} تو نوبتِ خودش دیر کرد و حدس نزد.\n"
        f"🏆 برنده: {winner_label}\n"
        f"🎁 جایزه‌ی برنده: {fmt(pot)} 🪙"
    )
    try:
        await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
    except Exception:
        pass
    for uid in (r.player1_id, r.player2_id):
        won = uid == winner_id
        result_line = (f"🎉 بردی! حریف به‌خاطرِ تاخیر نتونست حدس بزنه و {fmt(pot)} 🪙 به حسابت اضافه شد."
                        if won else "⏳ به‌خاطرِ تاخیر (دیر کردی و حدس نزدی) باختی!")
        await _send_final_reveal_dm(context, r, uid, result_line)


async def sweep_timeouts(context):
    session = db.get_session()
    try:
        now = datetime.datetime.utcnow()
        action_cutoff = now - datetime.timedelta(seconds=ACTION_TIMEOUT_SECONDS)
        setup_cutoff = now - datetime.timedelta(seconds=SETUP_ABANDON_TIMEOUT_SECONDS)
        # لابی/جای‌گذاری: هنوز بازیِ واقعی شروع نشده -> تایم‌اوت = لغو + برگشتِ پول
        stale = (
            session.query(db.MastermindRound)
            .filter(
                ((db.MastermindRound.status.in_(("lobby", "placing"))) & (db.MastermindRound.last_action_at < action_cutoff))
                | ((db.MastermindRound.status == "setup") & (db.MastermindRound.created_at < setup_cutoff))
            )
            .all()
        )
        for r in stale:
            await _refund(session, r)
            _end_round(r, "cancelled")
            text = "⏳ رمزیاب به‌خاطرِ عدمِ فعالیت لغو شد. مبلغِ ورودی (برای هرکی پرداخت کرده بود) برگشت داده شد."
            try:
                if r.group_message_id:
                    await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
            except Exception:
                pass
            for uid in (r.player1_id, r.player2_id):
                if not uid:
                    continue
                try:
                    await context.bot.send_message(uid, text)
                except Exception:
                    pass
        if stale:
            session.commit()

        # فازِ playing: بازیِ واقعی شروع شده -> تایم‌اوتِ نوبت = باختِ همون
        # کسی که نوبتش بود، نه لغوِ کلِ بازی
        playing_stale = (
            session.query(db.MastermindRound)
            .filter(db.MastermindRound.status == "playing", db.MastermindRound.last_action_at < action_cutoff)
            .all()
        )
        for r in playing_stale:
            async with _get_round_lock(r.id):
                session.refresh(r)
                if r.status != "playing":
                    continue
                await _resolve_timeout_forfeit(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مسیریابی
# ---------------------------------------------------------------------------

MM_PREFIX_MAP = {
    "mm_new": cb_mm_new,
    "mm_back_to_types": cb_mm_back_to_types,
    "mm_cancel": cb_mm_cancel,
    "mm_amt_menu": cb_mm_amt_menu,
    "mm_amt_pick": cb_mm_amt_pick,
    "mm_amt_custom": cb_mm_amt_custom,
    "mm_back": cb_mm_back,
    "mm_start": cb_mm_start,
    "mm_join": cb_mm_join,
    "mm_place": cb_mm_place,
    "mm_place_undo": cb_mm_place_undo,
    "mm_place_confirm": cb_mm_place_confirm,
    "mm_guess": cb_mm_guess,
    "mm_guess_undo": cb_mm_guess_undo,
    "mm_guess_submit": cb_mm_guess_submit,
}


async def mm_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = MM_PREFIX_MAP.get(prefix)
    if handler:
        await handler(update, context)
        return True
    return False
