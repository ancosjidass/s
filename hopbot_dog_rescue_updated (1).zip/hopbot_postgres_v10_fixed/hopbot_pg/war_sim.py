# -*- coding: utf-8 -*-
"""
شبیه‌سازیِ بالانسِ اقتصادِ «جنگ هاپویی» (Agent-based، ساعتِ جعلی، روی دیتابیسِ موقت).

اجرا:   python war_sim.py            ← گزارش در خروجی + war_balance_report.md
تست:    python -m pytest test_war_balance.py -q

چیزی که می‌سنجه (طبق بندِ ۹۸ مشخصات):
 ✔ اقتصاد منفجر نشه (تولید در برابر خرج، سقفِ غنیمت، جابه‌جایی نه چاپ)
 ✔ درآمدِ جنگ ≈ ۳ تا ۴ برابرِ کارخونه و با ارتقا رشد کنه
 ✔ XP / Hop Point با تکرارِ حمله بی‌نهایت فارم نشه (Anti-Farm)
 ✔ شکست باعث Quit نشه (بازنده هم پیشرفت می‌کنه)
 ✔ بازیکنِ جدید رشد کنه؛ Endgame هنوز هدف داشته باشه
 ✔ خزانه توسط یک نفر خالی نشه؛ کودتا بیش‌ازحد سودآور نباشه
"""
import datetime
import json
import os
import random
import sys
import tempfile

os.environ.setdefault("BOT_TOKEN", "1:x")
os.environ.setdefault("OWNER_ID", "999")
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "war_sim.db")

import db  # noqa: E402
import economy  # noqa: E402
import war_db as W  # noqa: E402
import war_svc as S  # noqa: E402
import war_battle as B  # noqa: E402
import war_clan as C  # noqa: E402
from war_svc import WarError  # noqa: E402

T0 = datetime.datetime(2026, 10, 1, 8, 0, 0)


class Clock:
    t = T0

    def __call__(self):
        return Clock.t


CLOCK = Clock()
for _m in (S, B, C):
    _m.utcnow = CLOCK


def _fresh():
    db.Base.metadata.drop_all(db.engine)
    db.init_db()
    W.init_war()
    Clock.t = T0
    return db.get_session()


def mk(s, uid, th=1, xp=0, units=None, hop=2_000_000, clan=None):
    s.add(db.User(telegram_id=uid, username=f"p{uid}", first_name=f"P{uid}", hop_points=hop))
    s.commit()
    p = S.get_player(s, uid)
    p.th_level, p.xp = th, xp
    s.query(W.WarBuilding).filter_by(user_id=uid, key="th").first().level = th
    for k, n in (units or {}).items():
        u = s.query(W.WarUnit).filter_by(user_id=uid, unit_key=k).first()
        if not u:
            u = W.WarUnit(user_id=uid, unit_key=k, healthy=0, damaged=0, level=1)
            s.add(u)
        u.healthy = n
    s.commit()
    return p


class Persona:
    def __init__(self, name, th, xp, units, collects, attacks, upgrade_pct=0.5, train_pct=0.3):
        self.name, self.th, self.xp, self.units = name, th, xp, units
        self.collects, self.attacks, self.upgrade_pct, self.train_pct = collects, attacks, upgrade_pct, train_pct


PERSONAS = [
    Persona("بازیکنِ جدید", 1, 0, {"infantry": 30}, 2, 2),
    Persona("میان‌رده", 3, 4000, {"infantry": 60, "drone": 10, "tank": 6}, 3, 3),
    Persona("کهنه‌کار", 6, 40000, {"infantry": 150, "drone": 30, "tank": 20, "fighter": 8}, 3, 4),
    Persona("خیلی فعال", 4, 12000, {"infantry": 80, "drone": 20, "tank": 10}, 5, 6),
    Persona("کم‌فعالیت", 3, 4000, {"infantry": 60, "drone": 10, "tank": 6}, 1, 0),
]


def ledger_totals(s, uid, since=None):
    q = s.query(W.HopTransaction).filter_by(user_id=uid)
    if since:
        q = q.filter(W.HopTransaction.created_at >= since)
    faucet = sink = 0.0
    parts = {}
    for t in q.all():
        key = t.reason.split(":")[1] if ":" in t.reason else t.reason
        parts[key] = parts.get(key, 0) + t.amount
        if t.amount > 0:
            faucet += t.amount
        else:
            sink += -t.amount
    return faucet, sink, parts


def play_day(s, p, persona, targets, rng):
    """یک روزِ بازیکن: چند بار جمع‌کردن، چند حمله، تعمیر/آماده‌سازی/ارتقا/ساخت."""
    uid = p.user_id
    start = Clock.t
    slots = [start + datetime.timedelta(hours=24 * i / max(1, persona.collects)) for i in range(persona.collects)]
    attack_slots = [start + datetime.timedelta(hours=1 + 20 * i / max(1, persona.attacks)) for i in range(persona.attacks)]
    events = sorted([(t, "collect") for t in slots] + [(t, "attack") for t in attack_slots])
    for t, kind in events:
        Clock.t = max(Clock.t, t)
        C.run_tick(Clock.t)
        s.expire_all()
        p = S.get_player(s, uid)
        try:
            if kind == "collect":
                S.collect_vault(s, p)
            else:
                if p.readiness < 45:
                    B.prepare_army(s, p)
                cands = B.find_targets(s, p, limit=5)
                if not cands:
                    cands = [{"user_id": rng.choice([x for x in targets if x != uid])}]
                tg = rng.choice(cands)["user_id"]
                tp = S.get_player(s, tg)
                tp.shield_until = None          # سناریو: هدف‌ها بدونِ شیلد (بدترین حالت برای اقتصاد)
                b, _ = B.launch_attack(s, p, tg, "standard", B.default_composition(s, uid, "all"), now=Clock.t)
            s.commit()
        except WarError:
            s.rollback()
    # پایانِ روز: تعمیر، ارتقا، ساخت
    Clock.t = start + datetime.timedelta(hours=23)
    C.run_tick(Clock.t)
    s.expire_all()
    p = S.get_player(s, uid)
    S.sync_player(s, p)
    user = s.get(db.User, uid)
    try:
        for d in S.udefs(s):
            u = S.units_of(s, uid).get(d.key)
            if u and u.damaged:
                try:
                    S.enqueue_repair(s, p, d.key, u.damaged)
                except WarError:
                    break
        budget = user.hop_points * persona.upgrade_pct
        for key in ("mine", "vault", "camp", "depot", "turret", "th"):
            try:
                d = s.get(W.WarBuildingDef, key)
                b = S.buildings_of(s, uid).get(key)
                tgt = (b.level if b else 0) + 1
                if b and b.upgrade_to:
                    continue
                hop, mat, _ = S.building_upgrade_cost(s, d, tgt)
                if hop <= budget:
                    S.start_upgrade(s, p, key)
                    budget -= hop
            except WarError:
                pass
        tb = user.hop_points * persona.train_pct
        for key in ("drone", "tank", "infantry"):
            d = s.get(W.WarUnitDef, key)
            qty = int(tb // max(1, d.cost) // 3)
            if qty:
                try:
                    S.enqueue_train(s, p, key, min(qty, 20))
                except WarError:
                    pass
        s.commit()
    except WarError:
        s.rollback()
    Clock.t = start + datetime.timedelta(days=1)


def run_personas(days=10, seed=7):
    rng = random.Random(seed)
    s = _fresh()
    uids = []
    for i, ps in enumerate(PERSONAS):
        uid = 100 + i
        mk(s, uid, ps.th, ps.xp, ps.units)
        uids.append(uid)
    for j in range(8):     # بقیه‌ی جمعیت: نیمی تازه‌کار (مثلِ جمعیتِ واقعی) و نیمی میان‌رده
        if j < 4:
            mk(s, 200 + j, 1, 0, {"infantry": 30})
        else:
            mk(s, 200 + j, rng.choice([2, 3, 4]), 3000, {"infantry": 40, "drone": 8})
        uids.append(200 + j)
    report = {}
    for d in range(days):
        for i, ps in enumerate(PERSONAS):
            p = S.get_player(s, 100 + i)
            play_day(s, p, ps, uids, rng)
    C.run_tick(Clock.t + datetime.timedelta(hours=8))
    s.expire_all()
    import economy as eco
    for i, ps in enumerate(PERSONAS):
        uid = 100 + i
        p = S.get_player(s, uid)
        f, k, parts = ledger_totals(s, uid)
        lvl = S.player_level(s, p)
        mine = S.bld_level(s, uid, "mine")
        fac_hr = eco.factory_level_values(s, max(1, mine))[0] * 60
        report[ps.name] = {
            "th": p.th_level, "level": lvl, "mine": mine, "trophies": p.trophies, "attacks": p.attacks, "wins": p.wins,
            "faucet_per_day": f / days, "sink_per_day": k / days, "sink_ratio": k / f if f else 0,
            "collected_per_day": parts.get("vault_collect", 0) / days, "reward_per_day": (f - parts.get("vault_collect", 0)) / days,
            "war_vs_factory": (S.mine_income_ph(s, p) / fac_hr) if fac_hr else 0, "xp": p.xp, "xp_per_day": p.xp / days,
        }
    s.close()
    return report


# ---------------------------------------------------------------- سناریوهای خاص
def scenario_farming(attacks=12):
    """یک حمله‌کننده ۱۲ بار به یک هدفِ ضعیف: مجموعِ پاداش باید به ~۲٫۲۵ برابرِ حمله‌ی اول برسه (نه ۱۲×)."""
    s = _fresh()
    mk(s, 1, 3, 20000, {"infantry": 300})
    mk(s, 2, 3, 3000, {"infantry": 2})
    p1, p2 = S.get_player(s, 1), S.get_player(s, 2)
    rewards, loots, blocked = [], [], 0
    for i in range(attacks):
        p2.shield_until = None
        p1.fuel = 10
        p2.vault_hop = 8_000_000
        s.commit()
        try:
            b, _ = B.launch_attack(s, p1, 2, "quick", B.default_composition(s, 1, "half"), now=Clock.t)
        except WarError:
            blocked += 1
            Clock.t += datetime.timedelta(minutes=5)
            continue
        s.commit()
        Clock.t = b.resolve_at
        B.resolve_battle(s, b.id, Clock.t)
        s.commit()
        res = json.loads(s.get(W.WarBattle, b.id).result_json)
        rewards.append((res["rew_atk"]["xp"], res["rew_atk"]["hop"]))
        loots.append(s.get(W.WarBattle, b.id).loot_hop)
        p1.readiness = 100
        s.commit()
    out = {"attacks_allowed": len(rewards), "blocked": blocked, "first_xp": rewards[0][0], "first_hop": rewards[0][1], "first_loot": loots[0],
           "total_xp": sum(r[0] for r in rewards), "total_hop": sum(r[1] for r in rewards), "total_loot": sum(loots)}
    s.close()
    return out


def scenario_losing_streak():
    """مهاجمِ ضعیف: ۵ شکست پشت‌سرهم → هنوز XP/غرامت/پیشرفت می‌گیره و ورشکسته نمی‌شه."""
    s = _fresh()
    mk(s, 1, 2, 3000, {"infantry": 12}, hop=5_000_000)
    for t in range(2, 7):
        mk(s, t, 2, 3000, {"infantry": 80, "tank": 6})
    p1 = S.get_player(s, 1)
    xp0, bal0 = p1.xp, s.get(db.User, 1).hop_points
    outcomes = []
    for t in range(2, 7):
        S.get_player(s, t).shield_until = None
        p1.fuel = 10
        p1.readiness = 100
        s.commit()
        try:
            b, _ = B.launch_attack(s, p1, t, "quick", B.default_composition(s, 1, "all_dmg"), now=Clock.t)
        except WarError:
            continue
        s.commit()
        Clock.t = b.resolve_at
        B.resolve_battle(s, b.id, Clock.t)
        s.commit()
        outcomes.append(s.get(W.WarBattle, b.id).outcome)
    s.expire_all()
    p1 = S.get_player(s, 1)
    out = {"outcomes": outcomes, "xp_gain": p1.xp - xp0, "balance_change": s.get(db.User, 1).hop_points - bal0, "ach_progress": S.metric_get(s, 1, "attacks")}
    s.close()
    return out


def scenario_treasury_and_coup():
    s = _fresh()
    mk(s, 1, 5, 30000, {"infantry": 10})
    p1 = S.get_player(s, 1)
    c, _ = C.create_clan(s, p1, "Whales", "WHL")
    c.level = 5
    for uid in range(2, 12):
        mk(s, uid, 5, 30000, {"infantry": 10})
        r = C.send_request(s, S.get_player(s, uid), c.id)
        C.decide_request(s, 1, r.id, True)
    s.commit()
    c.treasury = 5_000_000_000
    for m in C.members_list(s, c.id):
        m.week_contribution = 100 if m.user_id != 2 else 10_000      # یک عضو با مشارکتِ بسیار زیاد
    s.commit()
    Clock.t += datetime.timedelta(days=8)
    r = C.run_settlement(s, c, Clock.t)
    share_max = max(a for _, a in r["payouts"])
    out = {"treasury_before": 5_000_000_000, "pool": r["pool"], "paid": r["paid"], "max_single_share": share_max,
           "max_single_pct_of_treasury": share_max / 5_000_000_000 * 100, "treasury_after_pct": c.treasury / 5_000_000_000 * 100}
    # کودتا: پاداشِ بیشینه
    s.get(W.WarPlayer, 3).xp = 50000
    s.add(W.WarAchievement(user_id=3, key="first_cw"))
    m3 = C.member_of(s, 3)
    m3.joined_at = Clock.t - datetime.timedelta(days=30)
    m3.contribution = 9999
    s.commit()
    ok, pv, reward = C.attempt_coup(s, S.get_player(s, 3), Clock.t, type("R", (), {"random": lambda self: 0.0})())
    out.update({"coup_reward": reward, "coup_reward_pct_of_treasury": reward / 5_000_000_000 * 100,
                "coup_reward_cap_hours": S.cf(s, "war_coup_reward_cap_hours"), "coup_xp_cost": pv["xp_cost"],
                "coup_reward_in_hours_of_income": reward / S.player_ref(s, S.get_player(s, 3))})
    s.close()
    return out


def scenario_long_battle_and_draw_and_timeout():
    s = _fresh()
    mk(s, 1, 8, 90000, {"infantry": 200, "tank": 40, "fighter": 20})
    mk(s, 2, 8, 90000, {"infantry": 200, "tank": 40, "fighter": 20})
    p1 = S.get_player(s, 1)
    S.get_player(s, 2).shield_until = None
    bt = s.get(W.WarBattleType, "major")
    b, _ = B.launch_attack(s, p1, 2, "major", B.default_composition(s, 1, "half"), now=Clock.t)
    s.commit()
    dur_h = (b.resolve_at - Clock.t).total_seconds() / 3600
    bid = b.id
    s.close()
    # «ری‌استارت»: tick با Session تازه، فقط بعد از زمانش
    early = C.run_tick(Clock.t + datetime.timedelta(minutes=30))
    late = C.run_tick(Clock.t + datetime.timedelta(hours=dur_h + 0.1))
    s = db.get_session()
    row = s.get(W.WarBattle, bid)
    out = {"duration_h": dur_h, "resolved_early": any(e["type"] == "battle" for e in early), "resolved_late": any(e["type"] == "battle" for e in late),
           "outcome": row.outcome, "stars": row.stars}
    s.close()
    return out


def scenario_new_player_experience(n=60):
    """تازه‌کار در برابرِ تازه‌کار و در برابرِ یک پله قوی‌تر: شانسِ برد نباید صفر یا ۱۰۰٪ باشه."""
    import war_engine as E
    s = _fresh()
    params, _ = S.formula_params(s)
    bt = s.get(W.WarBattleType, "standard")

    def win_rate(def_units, th_def, atk_units):
        mk(s, 1, 1, 0, atk_units)
        mk(s, 2, th_def, 3000, def_units)
        atk = B.engine_units(s, 1)
        dfn = B.engine_units(s, 2)
        structs, wall = B.defense_structures(s, 2)
        w = st = 0
        for i in range(400):
            r = E.resolve(i, atk, structs, dfn, params, 100, 100, atk_mult=bt.atk_mult, casualty_mult=bt.casualty_mult, wall_mult=wall)
            w += r["outcome"] == "attacker"
            st += r["stars"]
        s.query(W.WarPlayer).delete()
        s.query(W.WarUnit).delete()
        s.query(W.WarBuilding).delete()
        s.query(db.User).delete()
        s.commit()
        return w / 400, st / 400

    out = {"جدید vs جدید": win_rate({"infantry": 30}, 1, {"infantry": 30}),
           "جدید vs کمی قوی‌تر (مقر۲ + تانک)": win_rate({"infantry": 30, "tank": 4}, 2, {"infantry": 30}),
           "جدید vs خیلی قوی‌تر (۳ برابر)": win_rate({"infantry": 70, "tank": 12}, 3, {"infantry": 30})}
    s.close()
    return out


def scenario_ratio_curve():
    """منحنیِ «نسبتِ قدرت → شانسِ برد»: نه ۷۰٪ ثابت و نه باینری؛ قدرتِ واقعی مهمه ولی نویزِ محدود هست."""
    import war_engine as E
    s = _fresh()
    params, _ = S.formula_params(s)
    rows = []
    for ratio in (0.5, 0.7, 0.85, 1.0, 1.15, 1.3, 1.6, 2.0, 3.0):
        atk = [E.Unit("a", "ground", 10, 8, healthy=int(100 * ratio))]
        dfn = [E.Unit("d", "ground", 10, 8, healthy=0)]
        structs = [{"type": "ground", "power": 1000 * 1.0}]
        w = st = 0
        N = 500
        for i in range(N):
            r = E.resolve(i, atk, structs, [], params, 100, 100)
            w += r["outcome"] == "attacker"
            st += r["stars"]
        rows.append((ratio, w / N, st / N))
    s.close()
    return rows


def scenario_many_battles_perf(n=150):
    import time
    s = _fresh()
    for uid in range(1, 61):
        mk(s, uid, 3, 5000, {"infantry": 40, "drone": 6})
    now = Clock.t
    ids = []
    for i in range(n):
        a, d = (i % 60) + 1, ((i * 7 + 3) % 60) + 1
        if a == d:
            continue
        try:
            p = S.get_player(s, a)
            p.fuel = 10
            S.get_player(s, d).shield_until = None
            b, _ = B.launch_attack(s, p, d, "quick", {"infantry": 30}, now=now)
            ids.append(b.id)
            s.commit()
        except WarError:
            s.rollback()
        except Exception:
            s.rollback()
    s.close()
    t0 = time.time()
    C.run_tick(now + datetime.timedelta(hours=2))
    dt = time.time() - t0
    s = db.get_session()
    done = s.query(W.WarBattle).filter_by(status="resolved").count()
    s.close()
    return {"launched": len(ids), "resolved": done, "seconds": round(dt, 2), "per_battle_ms": round(dt / max(1, done) * 1000, 1)}


def build_report():
    lines = ["# گزارش شبیه‌سازیِ بالانسِ جنگ هاپویی", ""]
    rep = run_personas()
    lines += ["## ۱) Personaها (۱۰ روز، با شیلدِ خاموش = بدترین حالتِ اقتصادی)", "",
              "| پرسونا | مقر | سطح | معدن | حمله/برد | تولید/روز | خرج/روز | نسبتِ خرج | درآمدِ جنگ ÷ کارخونه | XP/روز |", "|---|---|---|---|---|---|---|---|---|---|"]
    for n, r in rep.items():
        lines.append(f"| {n} | {r['th']} | {r['level']} | {r['mine']} | {r['attacks']}/{r['wins']} | {r['faucet_per_day']:,.0f} | {r['sink_per_day']:,.0f} | {r['sink_ratio'] * 100:.0f}% | ×{r['war_vs_factory']:.2f} | {r['xp_per_day']:.0f} |")
    f = scenario_farming()
    lines += ["", "## ۲) Anti-Farm (۱۲ حمله به یک هدف)", "",
              f"- حمله‌های مجاز: **{f['attacks_allowed']}** از ۱۲ (بقیه مسدود: {f['blocked']})",
              f"- XP کل = {f['total_xp']:.0f} = **×{f['total_xp'] / f['first_xp']:.2f}** حمله‌ی اول (بدونِ Anti-Farm می‌شد ×۱۲)",
              f"- هاپ‌پاداش کل = ×{f['total_hop'] / max(1, f['first_hop']):.2f} | غنیمتِ کل = ×{f['total_loot'] / max(1, f['first_loot']):.2f}"]
    l = scenario_losing_streak()
    lines += ["", "## ۳) شکستِ پشت‌سرهم (Quit نشه)", "", f"- نتایج: {l['outcomes']}", f"- XP دریافتی: **+{l['xp_gain']:.0f}** | تغییرِ موجودی: {l['balance_change']:+,.0f} | پیشرفتِ دستاورد: {l['ach_progress']:.0f} حمله"]
    t = scenario_treasury_and_coup()
    lines += ["", "## ۴) خزانه و کودتا", "",
              f"- خزانه ۵ میلیارد؛ تسویه‌ی هفتگی: Pool = {t['pool']:,.0f} (۲۰٪)، پخش‌شده {t['paid']:,.0f}",
              f"- بیشترین سهمِ یک نفر = **{t['max_single_pct_of_treasury']:.2f}٪ از کلِ خزانه** (حتی با مشارکتِ ۱۰۰ برابرِ بقیه)؛ بعد از تسویه {t['treasury_after_pct']:.1f}٪ خزانه می‌مونه",
              f"- کودتای موفق: پاداش {t['coup_reward']:,.0f} = {t['coup_reward_pct_of_treasury']:.2f}٪ خزانه ≈ {t['coup_reward_in_hours_of_income']:.1f} ساعتِ درآمد (سقف {t['coup_reward_cap_hours']:g}) | هزینه‌ی XP: {t['coup_xp_cost']:.0f}"]
    npx = scenario_new_player_experience()
    lines += ["", "## ۳-ب) تجربه‌ی بازیکنِ جدید (شانسِ برد / میانگین ستاره)", ""] + [f"- {k}: برد **{v[0] * 100:.0f}٪** | ⭐ {v[1]:.2f}" for k, v in npx.items()]
    rc = scenario_ratio_curve()
    lines += ["", "## ۳-ج) منحنیِ قدرت → شانسِ برد (Controlled Randomness)", "", "| نسبتِ قدرتِ مهاجم/مدافع | شانسِ برد | میانگین ستاره |", "|---|---|---|"] + [f"| {r:.2f} | {w * 100:.0f}٪ | {st:.2f} |" for r, w, st in rc]
    lb = scenario_long_battle_and_draw_and_timeout()
    lines += ["", "## ۵) نبردِ بلند و Restart", "", f"- «عملیات بزرگ» {lb['duration_h']:.1f} ساعت؛ قبل از زمانش Resolve شد؟ {lb['resolved_early']} | بعد از ری‌استارتِ tick: {lb['resolved_late']} ({lb['outcome']}, {lb['stars']}⭐)"]
    pf = scenario_many_battles_perf()
    lines += ["", "## ۶) کارایی", "", f"- {pf['launched']} نبردِ هم‌زمان → {pf['resolved']} resolve در {pf['seconds']}s (≈ {pf['per_battle_ms']}ms/نبرد، بدونِ بلاک‌کردنِ بات؛ داخل Job جدا)"]
    return "\n".join(lines), rep, f, l, t, lb, pf, npx, rc


if __name__ == "__main__":
    text, *_ = build_report()
    print(text)
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "war_balance_report.md")
    with open(path, "w", encoding="utf-8") as fh:
        fh.write(text + "\n")
    print("\n→", path)
    sys.exit(0)
