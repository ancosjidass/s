# -*- coding: utf-8 -*-
"""
رابطِ «بتل‌پسِ هاپویی». تریگر: «بتل پس هاپویی» (گروه و پیوی).
callback_data = bp:<آیدیِ صاحبِ پنل>:<اکشن>[:<آرگومان>] ؛ فقط صاحبِ پنل می‌تونه کلیک کنه (سمتِ سرور چک می‌شه).
(کارتِ آزادی با «bail_bpjc:<آیدی>» می‌آد تا جلویِ زندانی‌ها رو «jail_gate» نگیره.)
"""
import logging

import battlepass_db as BD
import battlepass_engine as E
import db
from battlepass_engine import BpError, fmt

logger = logging.getLogger(__name__)

TRIGGERS = {"بتل پس هاپویی", "بتل‌پس هاپویی", "بتل پس", "بتلپس هاپویی", "پس هاپویی", "هاپ پس"}
PAGE_TIERS = 5


def _markup(rows):
    from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as K
    return K([[B(a, callback_data=b) for a, b in r] for r in rows]) if rows else None


def _cb(owner, action, *args):
    return ":".join(["bp", str(owner), action] + [str(a) for a in args])


def _stars(d):
    return {1: "⭐", 2: "⭐⭐", 3: "⭐⭐⭐", 4: "💀"}.get(d, "⭐")


def _stage_name(season, tier):
    return BD.STAGES[E.stage_of(max(1, tier), season.tiers)]


# ---------------------------------------------------------------------------
# صفحه‌ها
# ---------------------------------------------------------------------------
def main_view(session, user, season, p):
    uid = user.telegram_id
    st = E.progress(session, p.xp, season.tiers)
    open_ = E.is_open(season)
    hop_pct = E.hop_bonus_pct(session, uid)
    xm = E.xp_mult(session, p, uid)
    streak_pct = E.gf(session, "bp_streak_xp_pct_per_day", 3) * min(p.streak or 0, E.gi(session, "bp_streak_max_days", 10))
    lines = [f"🎖 بتل‌پس هاپویی — {season.name}", "━━━━━━━━━━━━━━"]
    if open_:
        lines.append(f"⏳ پایانِ فصل: {E.left_text(season.ends_at - E.utcnow())} دیگه")
    else:
        lines.append("🏁 این فصل تموم شده" + (" (مهلتِ دریافتِ جایزه‌ها هنوز بازه)" if E.in_grace(session, season) else ""))
    if st["maxed"]:
        lines.append(f"🏆 تیر {season.tiers}/{season.tiers} — ♾ سطحِ مسترى: {st['mastery']}")
    else:
        lines.append(f"🎚 تیر {st['tier']}/{season.tiers} — {_stage_name(season, st['tier'] + 1)}")
    lines.append(f"{E.bar(st['into'], st['need'])} {fmt(st['into'])}/{fmt(st['need'])} XP")
    lines.append(f"⭐ مجموعِ XP: {fmt(p.xp)}   🏆 رتبه: #{E.rank_of(session, season, p)}")
    lines.append(f"👑 پریمیوم: {'✅ فعال' if p.premium else '❌ نداری'}")
    lines.append(f"🔥 استریک: {p.streak or 0} روز" + (f" (+{streak_pct:g}٪ XP)" if streak_pct else ""))
    if hop_pct > 0:
        lines.append(f"🦘 بونوسِ هاپ: +{hop_pct:g}٪ روی هر «هاپ»")
    if (xm - 1) > 0.001:
        lines.append(f"⚡️ ضریبِ XP: ×{xm:.2f}")
    titles = [t for t in (p.titles or "").split("|") if t]
    if titles:
        lines.append("🏷 " + " | ".join(titles[-3:]))
    act = E.active_boosters(session, uid)
    if act:
        lines.append("🚀 بوسترِ فعال: " + "، ".join(f"{BD.BOOSTER_LABEL[b.kind]} {b.pct:g}٪" if b.pct else BD.BOOSTER_LABEL[b.kind] for b in act))
    rows = []
    n_claim = len(E.claimable(session, season, p)) if (E.is_open(season) or E.in_grace(session, season)) else 0
    if n_claim:
        rows.append([(f"🎁 دریافتِ همه‌ی جایزه‌ها ({n_claim})", _cb(uid, "ca", season.id))])
    rows.append([("🎁 جایزه‌ها", _cb(uid, "rw", max(0, st["tier"] // PAGE_TIERS))), ("🎯 چلنج‌ها", _cb(uid, "ch"))])
    nb = len(E.my_boosters(session, uid))
    rows.append([(f"🚀 بوسترها ({nb})", _cb(uid, "bo")), ("📋 برترین‌ها", _cb(uid, "lb"))])
    if open_:
        if not p.premium:
            rows.append([(f"👑 خرید پریمیوم ({fmt(E.gf(session, 'bp_premium_price', 0))} 🪙)", _cb(uid, "pm"))])
        if not st["maxed"]:
            price, _s = E.skip_price(session, season, p)
            rows.append([(f"⏭ رد کردنِ یک تیر ({fmt(price)} 🪙)", _cb(uid, "sk"))])
    prev = E.previous_season(session, season)
    if open_ and prev is not None and E.in_grace(session, prev):
        pp = E.get_player(session, user, prev, create=False)
        if pp is not None and E.claimable(session, prev, pp):
            rows.append([("🕰 جایزه‌هایِ فصلِ قبل", _cb(uid, "cap", prev.id))])
    rows.append([("🔄 بروزرسانی", _cb(uid, "r")), ("❌ بستن", _cb(uid, "x"))])
    return "\n".join(lines), rows


def rewards_view(session, user, season, p, page):
    uid = user.telegram_id
    n = season.tiers
    pages = max(1, -(-n // PAGE_TIERS))
    page = max(0, min(page, pages - 1))
    defs = E.defs_map(session, season.id)
    claimed = E.claimed_set(session, uid, season.id)
    st = E.progress(session, p.xp, n)
    lines = [f"🎁 جایزه‌ها — صفحه‌ی {page + 1}/{pages}", "🆓 رایگان | 👑 پریمیوم", "━━━━━━━━━━━━━━"]
    rows = []
    can_claim = E.is_open(season) or E.in_grace(season=season, session=session)
    for t in range(page * PAGE_TIERS + 1, min(n, (page + 1) * PAGE_TIERS) + 0 + 1):
        if t > n:
            break
        reached = t <= st["tier"]
        head = f"{'🔓' if reached else '🔒'} تیر {t}" + (f" — {_stage_name(season, t)}" if (t - 1) % max(1, n // 5) == 0 else "")
        lines.append(head)
        for track, icon in (("free", "🆓"), ("premium", "👑")):
            d = defs.get((t, track))
            mark = "✅" if (t, track) in claimed else ("🎁" if reached and (track == "free" or p.premium) else ("🔐" if track == "premium" and not p.premium else "▫️"))
            lines.append(f"   {icon} {mark} {E.reward_text(d)}")
            if reached and can_claim and (t, track) not in claimed and d is not None and d.kind != "none" and (track == "free" or p.premium):
                rows.append([(f"🎁 تیر {t} {icon}: {E.reward_text(d)}"[:60], _cb(uid, "ct", t, track))])
    if st["maxed"]:
        lines.append(f"\n♾ مسترى: هر {fmt(E.gf(session, 'bp_mastery_cost', 3000))} XP یه جایزه‌ی نقدی (هر ۵ سطح بوستر)")
    nav = []
    if page > 0:
        nav.append(("◀️", _cb(uid, "rw", page - 1)))
    nav.append((f"{page + 1}/{pages}", _cb(uid, "rw", page)))
    if page < pages - 1:
        nav.append(("▶️", _cb(uid, "rw", page + 1)))
    rows.append(nav)
    rows.append([("🔙 بتل‌پس", _cb(uid, "r"))])
    return "\n".join(lines), rows[-8:] if len(rows) > 8 else rows


def challenges_view(session, user, season, p):
    uid = user.telegram_id
    items = E.challenge_list(session, user, season, p)
    wk = E.week_index(season)
    sc = E.scale_for(session, user, wk, "daily")
    lines = [f"🎯 چلنج‌ها — هفته‌ی {wk + 1} فصل", f"🔥 ضریبِ سختی: ×{sc:.2f}  (با هفته و لولت بالا می‌ره)", "━━━━━━━━━━━━━━"]
    rows = []
    last = None
    for c in items:
        if c["period"] != last:
            last = c["period"]
            lines.append("\n" + BD.PERIODS[last])
        mark = "✅" if c["claimed"] else ("🟢" if c["done"] else "▫️")
        lines.append(f"{mark} {_stars(c['diff'])} {c['title']}")
        lines.append(f"   {E.bar(min(c['progress'], c['target']), c['target'], 8)} {min(c['progress'], c['target'])}/{c['target']} — ⭐ {fmt(c['xp'])} XP")
        if c["done"] and not c["claimed"]:
            rows.append([(f"🎁 دریافتِ «{c['title']}»"[:60], _cb(uid, "cc", c["id"]))])
    if not items:
        lines.append("چلنجی تعریف نشده.")
    lines.append("\nℹ️ XPِ فعالیتِ روزانه (بازی کردن) هم خودکار اضافه می‌شه؛ دکمه‌ی بروزرسانی رو بزن.")
    rows.append([("🔄 بروزرسانی", _cb(uid, "ch")), ("🔙 بتل‌پس", _cb(uid, "r"))])
    return "\n".join(lines), rows


def boosters_view(session, user, season, p):
    uid = user.telegram_id
    bs = E.my_boosters(session, uid)
    lines = ["🚀 بوسترهای من", "━━━━━━━━━━━━━━"]
    rows = []
    now = E.utcnow()
    for b in bs:
        what = BD.BOOSTER_LABEL.get(b.kind, b.kind) + (f" {b.pct:g}٪" if b.pct else "")
        extra = []
        if b.uses_left is not None:
            extra.append(f"{b.uses_left} بار")
        if b.duration_min:
            extra.append(f"{b.duration_min} دقیقه")
        if b.state == "active":
            left = f" — {E.left_text(b.ends_at - now)} مونده" if b.ends_at else ""
            lines.append(f"🟢 {what} ({' / '.join(extra)}){left}")
        else:
            lines.append(f"📦 {what} ({' / '.join(extra) or '—'})")
            if b.kind != "jail_free":
                rows.append([(f"▶️ فعال‌سازیِ {what}"[:60], _cb(uid, "ba", b.id))])
    if not bs:
        lines.append("هیچ بوستری نداری؛ از جایزه‌هایِ بتل‌پس می‌گیری.")
    if any(b.kind == "jail_free" for b in bs) and user.jailed_until and user.jailed_until > now:
        rows.append([("🗝 استفاده از کارتِ آزادی (خروجِ فوری از زندان)", f"bail_bpjc:{uid}")])
    lines.append("\nℹ️ بوسترهایِ «تعدادی» (سرقت) با هر استفاده کم می‌شن؛ «زمانی» از لحظه‌ی فعال‌سازی می‌شمرن.")
    rows.append([("🔙 بتل‌پس", _cb(uid, "r"))])
    return "\n".join(lines), rows


def leaderboard_view(session, user, season, p):
    uid = user.telegram_id
    rows_ = E.leaderboard(session, season)
    lines = [f"📋 برترین‌هایِ {season.name}", "━━━━━━━━━━━━━━"]
    for i, (name, st, prem) in enumerate(rows_, 1):
        lines.append(f"{i}. {'👑' if prem else ''}{name} — تیر {st['tier']}" + (f" ♾{st['mastery']}" if st["maxed"] else ""))
    if not rows_:
        lines.append("هنوز کسی امتیاز نگرفته.")
    return "\n".join(lines), [[("🔙 بتل‌پس", _cb(uid, "r"))]]


def confirm_view(uid, text_, yes):
    return text_, [[("✅ بله", _cb(uid, yes)), ("❌ نه", _cb(uid, "r"))]]


# ---------------------------------------------------------------------------
# دیسپچ
# ---------------------------------------------------------------------------
def _fresh(session, user, force=False):
    season, p = E.sync(session, user, force)
    return season, p


def dispatch(session, tg_user, chat_id, data):
    """-> (toast|None, alert, view|None)"""
    parts = data.split(":")
    user = db.get_or_create_user(session, tg_user)
    if parts[0] == "bail_bpjc":
        if len(parts) < 2 or not parts[1].lstrip("-").isdigit() or int(parts[1]) != tg_user.id:
            return "⛔️ این دکمه مالِ تو نیست!", True, None
        try:
            E.use_jail_card(session, user)
        except BpError as e:
            return str(e), True, None
        return "🗝 کارتِ آزادی مصرف شد؛ آزاد شدی!", True, ("🔓 با کارتِ آزادیِ بتل‌پس از زندان آزاد شدی.", [])
    if len(parts) < 3 or parts[0] != "bp" or not parts[1].lstrip("-").isdigit():
        return "؟", True, None
    owner, action, args = int(parts[1]), parts[2], parts[3:]
    if tg_user.id != owner:
        return "⛔️ این پنل مالِ تو نیست!", True, None
    if not E.enabled(session):
        return "🎖 بتل‌پس فعلاً خاموشه.", True, None
    gate = db.check_module_level(session, user, "battlepass")
    if gate:
        return gate, True, None
    if action == "x":
        return None, False, ("🎖 بتل‌پس بسته شد.", [])
    season, p = _fresh(session, user, force=(action in ("r", "ch")))
    uid = user.telegram_id
    try:
        if action == "r":
            return None, False, main_view(session, user, season, p)
        if action == "rw":
            return None, False, rewards_view(session, user, season, p, int(args[0]) if args else 0)
        if action == "ch":
            return None, False, challenges_view(session, user, season, p)
        if action == "bo":
            return None, False, boosters_view(session, user, season, p)
        if action == "lb":
            return None, False, leaderboard_view(session, user, season, p)
        if action == "cc":
            r = E.claim_challenge(session, user, int(args[0]))
            toast = f"✅ +{fmt(r['xp'])} XP" + (f"  🔥 استریک {r['streak']}" if r["streak"] else "")
            if r["tier_up"]:
                toast += f"\n🎉 رفتی تیر {r['tier']}!"
            season, p = _fresh(session, user)
            return toast, False, challenges_view(session, user, season, p)
        if action == "ct":
            res = E.claim_tier(session, user, season.id, int(args[0]), args[1])
            season, p = _fresh(session, user)
            return f"🎁 {res}", False, rewards_view(session, user, season, p, (int(args[0]) - 1) // PAGE_TIERS)
        if action in ("ca", "cap"):
            sid = int(args[0]) if args else season.id
            lines = E.claim_all(session, user, sid)
            season, p = _fresh(session, user)
            body = "\n".join(lines[:12]) + (f"\n… و {len(lines) - 12} جایزه‌ی دیگه" if len(lines) > 12 else "")
            return None, False, ("🎁 جایزه‌ها دریافت شد:\n\n" + body, [[("🔙 بتل‌پس", _cb(uid, "r"))]])
        if action == "ba":
            b = E.activate_booster(session, user, int(args[0]))
            season, p = _fresh(session, user)
            return f"🚀 {BD.BOOSTER_LABEL.get(b.kind, b.kind)} فعال شد!", False, boosters_view(session, user, season, p)
        if action == "pm":
            price = E.gf(session, "bp_premium_price", 0)
            xp_pct, hop_pct = E.gf(session, "bp_xp_premium_pct", 10), E.gf(session, "bp_hop_bonus_premium_pct", 10)
            return None, False, confirm_view(uid, (
                f"👑 پریمیومِ {season.name}\n\n💰 قیمت: {fmt(price)} 🪙\n"
                f"✨ جایزه‌هایِ مسیرِ پریمیوم (برایِ تیرهایی که رسیدی هم)\n⚡️ +{xp_pct:g}٪ XP\n🦘 +{hop_pct:g}٪ هاپِ بیشتر\n\nمطمئنی؟"), "pmy")
        if action == "pmy":
            price = E.buy_premium(session, user)
            season, p = _fresh(session, user)
            return f"👑 پریمیوم فعال شد! (-{fmt(price)} 🪙)", False, main_view(session, user, season, p)
        if action == "sk":
            price, st = E.skip_price(session, season, p)
            if st["maxed"]:
                return "به آخرین تیر رسیدی.", True, None
            return None, False, confirm_view(uid, f"⏭ رد کردنِ تیر {st['tier'] + 1}\n💰 قیمت: {fmt(price)} 🪙\n\nمطمئنی؟", "sky")
        if action == "sky":
            price, tier = E.buy_skip(session, user)
            season, p = _fresh(session, user)
            return f"⏭ رفتی تیر {tier}! (-{fmt(price)} 🪙)", False, main_view(session, user, season, p)
    except BpError as e:
        return str(e), True, None
    return "؟", True, None


async def handle_trigger(update, context):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if not E.enabled(session):
            await update.message.reply_text("🎖 بتل‌پس فعلاً خاموشه.")
            return
        gate = db.check_module_level(session, user, "battlepass")
        if gate:
            await update.message.reply_text(gate)
            return
        season, p = _fresh(session, user, force=True)
        text, rows = main_view(session, user, season, p)
        session.commit()
    finally:
        session.close()
    await update.message.reply_text(text, reply_markup=_markup(rows))


async def callback_router(update, context):
    q = update.callback_query
    if not (q.data or "").startswith(("bp:", "bail_bpjc")):
        return False
    session = db.get_session()
    try:
        toast, alert, view = dispatch(session, q.from_user, q.message.chat_id, q.data)
        session.commit()
    except Exception:
        session.rollback()
        logger.exception("battlepass callback failed")
        toast, alert, view = "⚠️ خطایی پیش اومد؛ دوباره امتحان کن.", True, None
    finally:
        session.close()
    try:
        await q.answer(toast or None, show_alert=bool(alert))
    except Exception:
        pass
    if view is not None:
        text, rows = view
        try:
            await q.edit_message_text(text, reply_markup=_markup(rows))
        except Exception as e:
            if "not modified" not in str(e).lower():
                logger.warning("battlepass edit failed: %s", e)
    return True


async def tick_job(context):
    """رولِ فصل (ادامه‌دار) حتی وقتی کسی پنل رو باز نکرده؛ Idempotent."""
    import asyncio
    def _run():
        s = db.get_session()
        try:
            with E.LOCK:
                E.current_season(s)
                s.commit()
        finally:
            s.close()
    try:
        await asyncio.to_thread(_run)
    except Exception:
        logger.exception("battlepass tick")
