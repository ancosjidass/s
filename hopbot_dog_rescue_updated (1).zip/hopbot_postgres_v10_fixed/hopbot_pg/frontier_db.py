# -*- coding: utf-8 -*-
"""
🌌 HĀPOYI FRONTIER — مدل‌های دیتابیس + کانفیگ + دیتای اولیه (کاملاً Data-Driven).

اصول:
- هیچ ارز جدیدی نیست: پاداش‌های پولی فقط از war_svc.give_reward / hop_apply (لجر + سقف) می‌گذره.
  «امتیاز فتح» یه شمارنده‌ی غیرقابل‌انتقاله (FrontierContribution / FrontierClanRegion)، نه پول.
- همه‌ی اعداد: یا ستونِ جدول‌های frontier_* (قابل‌ویرایش از پنل ادمین) یا کانفیگ با پیشوند frontier_.
- همه‌ی State ها (عملیات، HP باس، فصل، باف‌ها) در دیتابیسه؛ ری‌استارت امنه.
- جدول‌های جدید با Base.metadata.create_all ساخته می‌شن؛ هیچ جدولِ قدیمی ALTER/Drop نمی‌شه.
"""
import json

from sqlalchemy import (
    Column, Integer, BigInteger, Float, String, Boolean, DateTime, Text, Index,
    UniqueConstraint, text,
)

import db
from db import Base, now

# ---------------------------------------------------------------------------
# مدل‌ها
# ---------------------------------------------------------------------------


class FrontierSeason(Base):
    __tablename__ = "frontier_seasons"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    start_at = Column(DateTime, nullable=False)
    end_at = Column(DateTime, nullable=False)
    status = Column(String, default="active")            # active / ended
    settled = Column(Boolean, default=False)
    created_by = Column(BigInteger, nullable=True)
    __table_args__ = (Index("ix_frontier_season_status", "status", "end_at"),)


class FrontierRegion(Base):
    __tablename__ = "frontier_regions"
    key = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    name_en = Column(String, default="")
    emoji = Column(String, default="🌌")
    story = Column(Text, default="")                      # چند پیامِ کوتاه با جداکننده‌ی ||
    unlock_story = Column(Text, default="")               # پیامِ بازشدنِ منطقه
    hint = Column(String, default="")
    sort = Column(Integer, default=100)
    prev_region = Column(String, default="")              # منطقه‌ی قبلی (برای شرطِ باس)
    req_th = Column(Integer, default=1)
    req_level = Column(Integer, default=1)
    req_prev_boss = Column(Boolean, default=True)         # باسِ منطقه‌ی قبلی شکست خورده باشه
    req_personal_points = Column(Integer, default=0)      # مسیرِ شخصی: امتیازِ فتحِ شخصی در منطقه‌ی قبلی
    req_clan_points = Column(Integer, default=0)          # مسیرِ قبیله: امتیازِ پیشرویِ گروهی در منطقه‌ی قبلی
    req_clan_participants = Column(Integer, default=0)    # مسیرِ قبیله: تعدادِ اعضای فعال
    reward_scale = Column(Float, default=1.0)             # ضریبِ پاداش (XP/هاپ) نسبت به منطقه‌ی ۱
    enabled = Column(Boolean, default=True)


class FrontierNode(Base):
    __tablename__ = "frontier_nodes"
    key = Column(String, primary_key=True)
    region_key = Column(String, nullable=False, index=True)
    kind = Column(String, nullable=False)                 # scout / operation / elite / secret / boss
    name = Column(String, nullable=False)
    name_en = Column(String, default="")
    story = Column(String, default="")
    difficulty = Column(Integer, default=1)               # ۱..۵
    req_level = Column(Integer, default=1)
    req_th = Column(Integer, default=1)
    power = Column(Float, default=100)                    # قدرتِ دفاعِ دشمن (هم‌مقیاسِ war_engine)
    ground_pct = Column(Integer, default=70)              # ترکیبِ دفاع: زمینی
    air_pct = Column(Integer, default=30)                 # ترکیبِ دفاع: هوایی (بقیه Generic)
    wall = Column(Float, default=1.0)
    enemy_name = Column(String, default="")
    min_seconds = Column(Integer, default=240)
    max_seconds = Column(Integer, default=360)
    fuel = Column(Float, default=1.0)
    cost_ref_hours = Column(Float, default=0.05)          # هزینه‌ی عملیات (هاپ) به ساعتِ درآمدِ مرجع
    cost_mat = Column(Float, default=0)
    readiness_loss = Column(Float, default=8)
    points = Column(Integer, default=10)                  # امتیازِ فتح (غیرقابل‌انتقال)
    reward_trigger = Column(String, default="fr_clear_scout")
    requires = Column(String, default="")                 # CSV از nodeهایی که باید قبلاً کامل شده باشن
    hidden = Column(Boolean, default=False)               # اتاقِ مخفی: تا کشف نشه دیده نمی‌شه
    reveal_clues = Column(Integer, default=3)             # تعدادِ سرنخِ لازم برای ظاهرشدنِ سیگنال
    reveal_options = Column(String, default="")           # سه گزینه با جداکننده‌ی |
    hint_clues = Column(Integer, default=5)               # با این تعداد سرنخ یک گزینه‌ی غلط حذف می‌شه
    signal_text = Column(String, default="")
    routes = Column(String, default="assault,infiltration,logistics")
    enabled = Column(Boolean, default=True)
    sort = Column(Integer, default=100)


class FrontierBossDef(Base):
    __tablename__ = "frontier_boss_defs"
    key = Column(String, primary_key=True)
    region_key = Column(String, nullable=False, index=True)
    node_key = Column(String, default="")                 # nodeِ نگهبان (برای شرطِ بازشدن) – رویدادی: خالی
    name = Column(String, nullable=False)
    name_en = Column(String, default="")
    emoji = Column(String, default="🐉")
    hp = Column(Float, default=2_000_000)                 # HPِ مشترکِ قبیله
    solo_hp_mult = Column(Float, default=0.15)            # نسخه‌ی شخصی (بازیکنِ بدونِ قبیله)
    defense = Column(Float, default=450)                  # قدرتِ پایه‌ی باس (تعیین‌کننده‌ی تلفات)
    resist_json = Column(Text, default="{}")              # {دسته: ضریبِ آسیب}
    phases_json = Column(Text, default="[]")
    skill = Column(String, default="")
    difficulty = Column(Integer, default=1)
    participation_points = Column(Integer, default=12)
    reward_trigger = Column(String, default="fr_clear_boss")
    is_event = Column(Boolean, default=False)
    enabled = Column(Boolean, default=True)
    sort = Column(Integer, default=100)


class FrontierBossState(Base):
    """نمونه‌ی زنده‌ی باس: یکی برای هر قبیله (scope=clan) یا هر بازیکنِ تک‌نفره (scope=user)."""
    __tablename__ = "frontier_boss_states"
    id = Column(Integer, primary_key=True, autoincrement=True)
    boss_key = Column(String, nullable=False)
    scope = Column(String, nullable=False)                # clan / user
    scope_id = Column(BigInteger, nullable=False)
    event_id = Column(Integer, default=0)                 # 0 = باسِ کمپین؛ >0 = باسِ رویداد
    hp_max = Column(Float, nullable=False)
    hp = Column(Float, nullable=False)
    status = Column(String, default="active")             # active / defeated / expired
    created_at = Column(DateTime, default=now)
    defeated_at = Column(DateTime, nullable=True)
    paid = Column(Boolean, default=False)
    __table_args__ = (UniqueConstraint("boss_key", "scope", "scope_id", "event_id", name="uq_frontier_boss_state"),
                      Index("ix_frontier_boss_scope", "scope", "scope_id", "status"))


class FrontierBossAttack(Base):
    __tablename__ = "frontier_boss_attacks"
    id = Column(Integer, primary_key=True, autoincrement=True)
    state_id = Column(Integer, nullable=False, index=True)
    user_id = Column(BigInteger, nullable=False)
    run_id = Column(Integer, nullable=False)
    damage = Column(Float, default=0)
    lost = Column(Integer, default=0)
    phase = Column(Integer, default=0)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("run_id", name="uq_frontier_boss_attack_run"),
                      Index("ix_frontier_boss_attack_user", "state_id", "user_id"))


class FrontierProgress(Base):
    __tablename__ = "frontier_progress"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    node_key = Column(String, nullable=False)
    clears = Column(Integer, default=0)
    fails = Column(Integer, default=0)
    best_stars = Column(Integer, default=0)
    first_clear_at = Column(DateTime, nullable=True)
    last_clear_at = Column(DateTime, nullable=True)
    __table_args__ = (UniqueConstraint("user_id", "node_key", name="uq_frontier_progress"),
                      Index("ix_frontier_progress_user", "user_id"))


class FrontierDiscovery(Base):
    __tablename__ = "frontier_discoveries"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    key = Column(String, nullable=False)                  # clue:<region>:<n> / room:<node> / region:<key> / signal:<node>
    kind = Column(String, nullable=False)                 # clue / room / region / signal
    region_key = Column(String, default="")
    at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("user_id", "key", name="uq_frontier_discovery"),
                      Index("ix_frontier_discovery_user", "user_id", "kind", "region_key"))


class FrontierClanRegion(Base):
    __tablename__ = "frontier_clan_regions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    clan_id = Column(Integer, nullable=False)
    region_key = Column(String, nullable=False)
    points = Column(Float, default=0)
    boss_down = Column(Boolean, default=False)
    first_boss_at = Column(DateTime, nullable=True)
    __table_args__ = (UniqueConstraint("clan_id", "region_key", name="uq_frontier_clan_region"),)


class FrontierSeasonScore(Base):
    __tablename__ = "frontier_season_scores"
    id = Column(Integer, primary_key=True, autoincrement=True)
    season_id = Column(Integer, nullable=False)
    clan_id = Column(Integer, nullable=False)
    points = Column(Float, default=0)
    boss_kills = Column(Integer, default=0)
    discoveries = Column(Integer, default=0)
    ops = Column(Integer, default=0)
    active_members = Column(Integer, default=0)
    members_n = Column(Integer, default=1)
    bracket = Column(String, default="small")
    total = Column(Float, default=0, index=True)
    final_rank = Column(Integer, nullable=True)
    updated_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("season_id", "clan_id", name="uq_frontier_season_score"),
                      Index("ix_frontier_score_rank", "season_id", "bracket", "total"))


class FrontierContribution(Base):
    __tablename__ = "frontier_contributions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    season_id = Column(Integer, nullable=False)
    user_id = Column(BigInteger, nullable=False)
    clan_id = Column(Integer, default=0, nullable=False)   # ۰ = بدونِ قبیله؛ امتیاز به قبیله‌ای که توش کسب شده می‌چسبه (ضدِ کلن‌هاپینگ)
    points = Column(Float, default=0)
    runs = Column(Integer, default=0)
    boss_damage = Column(Float, default=0)
    discoveries = Column(Integer, default=0)
    __table_args__ = (UniqueConstraint("season_id", "user_id", "clan_id", name="uq_frontier_contribution"),
                      Index("ix_frontier_contrib_clan", "season_id", "clan_id"))


class FrontierDaily(Base):
    __tablename__ = "frontier_daily"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    day = Column(String, nullable=False)
    points = Column(Float, default=0)
    ref_hours = Column(Float, default=0)
    runs = Column(Integer, default=0)
    boss_attacks = Column(Integer, default=0)
    __table_args__ = (UniqueConstraint("user_id", "day", name="uq_frontier_daily"),)


class FrontierRun(Base):
    __tablename__ = "frontier_runs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    node_key = Column(String, nullable=False)
    route = Column(String, nullable=False)                # assault / infiltration / logistics
    boss_state_id = Column(Integer, nullable=True)        # حمله به باس
    clan_id = Column(Integer, nullable=True)              # قبیله‌ی زمانِ اعزام
    season_id = Column(Integer, default=0)
    status = Column(String, default="marching")          # marching / resolving / resolved / cancelled
    outcome = Column(String, nullable=True)               # win / lose / support / void
    seed = Column(BigInteger, default=0)
    created_at = Column(DateTime, default=now)
    resolve_at = Column(DateTime, nullable=False)
    resolved_at = Column(DateTime, nullable=True)
    army_json = Column(Text, default="{}")
    modifiers_json = Column(Text, default="{}")           # فریزِ ضرایبِ لحظه‌ی اعزام (رویداد/باف/...)
    result_json = Column(Text, default="{}")
    formula_version = Column(Integer, default=1)
    chat_id = Column(BigInteger, nullable=True)
    __table_args__ = (
        Index("ix_frontier_runs_due", "status", "resolve_at"),
        # جلوگیری از دو اعزامِ هم‌زمانِ یکسان (دبل‌کلیک/Race) روی یک nodeِ واحد
        Index("uq_frontier_run_active", "user_id", "node_key", unique=True,
              sqlite_where=text("status = 'marching'"), postgresql_where=text("status = 'marching'")),
    )


class FrontierBuff(Base):
    __tablename__ = "frontier_buffs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    scope = Column(String, nullable=False)               # clan / user
    scope_id = Column(BigInteger, nullable=False)
    kind = Column(String, default="atk")                 # atk (قدرتِ حمله) / loot (پاداش)
    pct = Column(Float, default=0)
    charges = Column(Integer, default=0)
    expires_at = Column(DateTime, nullable=False)
    source_user = Column(BigInteger, nullable=True)
    created_at = Column(DateTime, default=now)
    __table_args__ = (Index("ix_frontier_buff_scope", "scope", "scope_id", "expires_at"),)


class FrontierRewardClaim(Base):
    """هر پاداشِ یک‌بارمصرف یک ردیفِ یکتاست (UniqueConstraint) → پرداختِ دوباره غیرممکنه؛ لاگِ پاداش هم همین‌جاست."""
    __tablename__ = "frontier_reward_claims"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    claim_key = Column(String, nullable=False)
    trigger = Column(String, default="")
    hop = Column(Float, default=0)
    xp = Column(Float, default=0)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("user_id", "claim_key", name="uq_frontier_claim"),
                      Index("ix_frontier_claim_user", "user_id", "created_at"))


class FrontierEvent(Base):
    __tablename__ = "frontier_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    kind = Column(String, nullable=False)                # storm / awakening / treasure / conquest
    name = Column(String, nullable=False)
    region_key = Column(String, default="")
    boss_key = Column(String, default="")                # awakening: باسِ رویداد
    node_key = Column(String, default="")                # treasure: اتاقِ موقتاً قابل‌دسترس
    power_mult = Column(Float, default=1.0)
    reward_mult = Column(Float, default=1.0)
    xp_mult = Column(Float, default=1.0)
    points_mult = Column(Float, default=1.0)
    start_at = Column(DateTime, nullable=False)
    end_at = Column(DateTime, nullable=False)
    enabled = Column(Boolean, default=True)
    note = Column(String, default="")
    __table_args__ = (Index("ix_frontier_event_window", "enabled", "start_at", "end_at"),)


class FrontierHonorDef(Base):
    __tablename__ = "frontier_honor_defs"
    key = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    emoji = Column(String, default="🏅")
    description = Column(String, default="")
    rarity = Column(String, default="common")            # common / rare / epic / legendary / mythic
    metric = Column(String, nullable=False)              # شمارنده‌ای که چک می‌شه (در frontier_svc.honor_metrics)
    threshold = Column(Integer, default=1)
    title = Column(String, default="")
    xp = Column(Float, default=0)
    hop_ref_hours = Column(Float, default=0)
    enabled = Column(Boolean, default=True)
    sort = Column(Integer, default=100)


class FrontierHonor(Base):
    __tablename__ = "frontier_honors"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    key = Column(String, nullable=False)
    earned_at = Column(DateTime, default=now)
    season_id = Column(Integer, default=0)
    __table_args__ = (UniqueConstraint("user_id", "key", name="uq_frontier_honor"),
                      Index("ix_frontier_honor_user", "user_id"))


class FrontierHall(Base):
    """تالارِ افتخاراتِ فصل‌ها (دائمی)."""
    __tablename__ = "frontier_hall"
    id = Column(Integer, primary_key=True, autoincrement=True)
    season_id = Column(Integer, nullable=False)
    season_name = Column(String, default="")
    bracket = Column(String, default="all")
    rank = Column(Integer, nullable=False)
    clan_id = Column(Integer, nullable=False)
    clan_name = Column(String, default="")
    clan_tag = Column(String, default="")
    score = Column(Float, default=0)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("season_id", "bracket", "rank", name="uq_frontier_hall"),)


# ---------------------------------------------------------------------------
# کانفیگ
# ---------------------------------------------------------------------------

ROUTES_DEFAULT = {
    # atk: ضریبِ قدرتِ حمله | cas: تلفات | pts: امتیازِ فتح | dur: زمان | rew: پاداش | clue: شانسِ سرنخ(٪) | pen: حداکثر کاهشِ دفاعِ دشمن با ترکیبِ پنهان‌کار
    "assault": {"name": "حمله‌ی مستقیم", "emoji": "💥", "atk": 1.20, "cas": 1.35, "pts": 1.25, "dur": 1.0, "rew": 1.0, "clue": 0, "pen": 0.0, "mat": 0.0},
    "infiltration": {"name": "نفوذ مخفیانه", "emoji": "🥷", "atk": 0.90, "cas": 0.55, "pts": 0.90, "dur": 1.35, "rew": 1.0, "clue": 35, "pen": 0.20, "mat": 0.0},
    "logistics": {"name": "پشتیبانی لجستیکی", "emoji": "📦", "atk": 0.75, "cas": 0.25, "pts": 0.70, "dur": 0.8, "rew": 0.7, "clue": 12, "pen": 0.0, "mat": 3.0},
}

FRONTIER_DEFAULT_CONFIG = {
    "frontier_enabled": "1",
    "frontier_max_runs": "2",                  # حداکثر عملیاتِ هم‌زمانِ Frontier برای هر بازیکن (+۱ به‌ازای هر ۴ سطحِ مقر)
    "frontier_routes": json.dumps(ROUTES_DEFAULT, ensure_ascii=False, separators=(",", ":")),
    # --- اقتصاد ---
    "frontier_daily_cap_ref_hours": "5",       # سقفِ روزانه‌ی پاداشِ تکرارِ هاپ (ساعتِ درآمدِ مرجع)
    "frontier_daily_cap_th_bonus": "0.5",      # + به‌ازای هر سطحِ مقر
    "frontier_repeat_steps": "1,0.7,0.45,0.25,0.1",   # ضریبِ تکرارِ هر nodeِ در روز (بازده‌ی نزولی)
    "frontier_repeat_mult": "0.8",            # پاداشِ تکرار نسبت به کلیرِ اول
    "frontier_fail_mult": "0.25",              # دلداریِ شکست
    "frontier_welcome_enabled": "1",
    "frontier_pioneer_enabled": "1",
    "frontier_launch_week_days": "7",
    "frontier_launch_reward_mult": "1.35",
    "frontier_min_war_level_rewards": "2",     # حداقل سطحِ جنگ برای پاداشِ باس/فصل (ضدِ اکانتِ دومِ خالی)
    # --- باس ---
    "frontier_dmg_scale": "200",
    "frontier_boss_attacks_daily": "8",
    "frontier_boss_share_cap_pct": "35",       # سقفِ سهمِ یک نفر از پاداشِ باس (٪)
    "frontier_boss_min_share_pct": "1",
    "frontier_boss_min_attacks": "2",
    "frontier_boss_player_cap_ref_hours": "8",
    "frontier_boss_pool_ref_hours": "6",       # استخرِ پاداشِ هر باس = N × (ساعتِ مرجع) × تعدادِ مشارکت‌کننده‌ی معتبر
    "frontier_boss_ret_k": "1.0",              # شدتِ تلافیِ باس
    # --- امتیاز/فصل ---
    "frontier_member_daily_point_cap": "600",
    "frontier_point_soft_ratio": "0.7",
    "frontier_point_soft_mult": "0.5",
    "frontier_season_days": "28",
    "frontier_season_auto_next": "1",
    "frontier_size_exponent": "0.6",
    "frontier_score_boss_kill": "500",
    "frontier_score_discovery": "40",
    "frontier_score_participation": "1000",
    "frontier_active_member_min_runs": "3",
    "frontier_season_min_runs": "5",
    "frontier_bracket_small": "8",
    "frontier_bracket_medium": "16",
    "frontier_season_reward_ref_hours": "24,14,8",
    "frontier_season_reward_xp": "1500,900,500",
    "frontier_season_part_ref_hours": "2.5",
    "frontier_season_min_points": "60",
    # --- اتاقِ مخفی ---
    "frontier_clue_pity": "3",                 # بعد از N نفوذِ بی‌سرنخ، سرنخِ بعدی تضمینیه
    "frontier_clue_stealth_bonus_pct": "25",
    "frontier_signal_retry_minutes": "30",
    "frontier_clan_hint_members": "2",
    # --- لجستیک ---
    "frontier_logi_buff_pct": "8",
    "frontier_logi_buff_charges": "3",
    "frontier_logi_buff_max_pct": "30",
    "frontier_logi_buff_hours": "12",
    # --- عملیات ---
    "frontier_run_expire_hours": "24",
    "frontier_expire_refund_pct": "50",
    "frontier_cancel_refund_pct": "50",        # لغوِ عملیات توسطِ خودِ بازیکن: ٪ بازگشتِ هزینه/سوخت/مواد (نیروها ۱۰۰٪ برمی‌گردن)
    "frontier_stealth_cats": "air,special,missile",
    "frontier_formula_version": "1",
    "frontier_notify_group_chars": "500",
}
db.DEFAULT_CONFIG.update(FRONTIER_DEFAULT_CONFIG)

TEXT_KEYS = {"frontier_routes", "frontier_repeat_steps", "frontier_season_reward_ref_hours",
             "frontier_season_reward_xp", "frontier_stealth_cats"}

# ---------------------------------------------------------------------------
# دیتای اولیه
# ---------------------------------------------------------------------------

# key,name,en,emoji,story,unlock_story,hint,sort,prev,th,lvl,prev_boss,pers_pts,clan_pts,clan_part,scale
REGIONS = [
    ("plains", "دشت فراموش‌شده", "Forgotten Plains", "🌾",
     "سرزمینی متروکه که زمانی مرکز تمدنِ قدیمیِ هاپویی بوده.||بادِ خشک لابه‌لای خرابه‌ها می‌پیچه؛ ولی هنوز بعضی دیوارها بیدارن.||هر خرابه‌ای که کشف کنی، ردی از قدرتِ گذشته‌ی هاپویی رو نشونت می‌ده.",
     "🌾 دشتِ فراموش‌شده چشم باز کرد...\nاینجا شروعِ همه‌چیزه.", "", 1, "", 1, 2, False, 0, 0, 0, 1.0),
    ("ironwood", "جنگل آهنین", "Ironwood Forest", "🌲",
     "درختانی که پوستشون از فولاده و ریشه‌هاشون زیرِ زمین به هم گره خورده.||مسیرهای پنهان، تله‌ها و منابعِ کمیاب؛ ولی نگهبانِ جنگل بیدارتر از اونیه که فکر می‌کنی.",
     "🌌 یک سرزمینِ ناشناخته کشف شد!\n\nمسیرِ جنگل آهنین باز شد. درختانِ آهنین بیدار شده‌ان...\nاما چیزی در اعماقِ جنگل منتظرِ شماست.",
     "نگهبانِ دشت رو شکست بده.", 2, "plains", 2, 4, True, 500, 2500, 3, 1.6),
    ("glass", "بیابان شیشه‌ای", "Glass Desert", "🏜",
     "شنی که زیرِ آفتاب شیشه شده و هر طوفان، خرابه‌ای مدفون رو رو می‌آره.||مسیرِ پرریسک = پاداشِ بیشتر؛ مسیرِ امن = زمانِ بیشتر. انتخاب با توئه.",
     "🏜 طوفان فروکش کرد و بیابانِ شیشه‌ای آشکار شد!\nمعبدهایی زیرِ شن‌ها منتظرِ کاوشگرانن.",
     "غولِ آهنین رو شکست بده.", 3, "ironwood", 3, 7, True, 1200, 6000, 4, 2.4),
    ("harbor", "بندر غرق‌شده", "Drowned Harbor", "⚓",
     "کشتی‌های متروکه، انبارهای گنج و مسیرهای دریایی که با جزر و مد باز و بسته می‌شن.||دشمنانِ دریایی دورِ لنگرگاهِ قدیمی می‌چرخن.",
     "⚓ مه کنار رفت و بندرِ غرق‌شده نمایان شد!\nپادشاهِ اعماق هنوز روی گنج‌هاش خوابیده.",
     "مارِ شیشه‌ای رو شکست بده.", 4, "glass", 5, 10, True, 2500, 12000, 5, 3.4),
    ("peaks", "کوهستان آذرخش", "Thunder Peaks", "⚡",
     "قله‌هایی که هر ثانیه صاعقه می‌خورن؛ تجهیزاتِ سنگین و دشمنانِ پیشرفته.||عملیات‌های چندمرحله‌ای و طوفان‌های الکتریکی.",
     "⚡ رعد غرید و کوهستانِ آذرخش راهش رو باز کرد!\nاژدهایی بالای قله‌ها منتظره.",
     "پادشاهِ اعماق رو شکست بده.", 5, "harbor", 6, 14, True, 4500, 24000, 6, 4.6),
    ("core", "هسته شهاب", "Meteor Core", "☄️",
     "جایی که آسمون به زمین خورد و چیزی زنده در دلِ سنگِ مذاب بیدار شد.||سخت‌ترین دشمنان، پیچیده‌ترین مسیرها و اتاق‌های فوق‌مخفی؛ پایانِ مرزها.",
     "☄️ هسته‌ی شهاب بیدار شد!\nآخرین مرزِ هاپویی بازه... و هر چیزی که اون پایینه، منتظرِ فاتحه.",
     "اژدهای آذرخش رو شکست بده.", 6, "peaks", 8, 20, True, 8000, 45000, 7, 6.0),
]

# nodes: key, region, kind, name, en, story, diff, req_lvl, req_th, power, ground%, air%, enemy, min_s, max_s, fuel, cost_h, cost_mat, rl, pts, trigger, requires, sort
NODE_ROWS = {
    "plains": [
        ("pl_scout", "scout", "اردوگاه متروکه", "Abandoned Camp", "چادرهای پاره و آتشِ نیمه‌خاموش؛ کسی اینجا مونده؟", 1, 2, 1, 150, 85, 10, "نگهبانانِ سنگی", 180, 240, 1, 0.04, 0, 6, 10, "fr_clear_scout", ""),
        ("pl_op", "operation", "برج دیده‌بانی", "Watchtower", "برجی که هنوز مسیرِ دشت رو زیرِ نظر داره.", 2, 2, 1, 300, 80, 15, "دیده‌بانانِ باستانی", 420, 540, 1, 0.08, 10, 8, 18, "fr_clear_operation", "pl_scout"),
        ("pl_elite", "elite", "خرابه‌های باستانی", "Ancient Ruins", "خرابه‌هایی با صدای قدم‌هایی که صاحب ندارن.", 3, 3, 1, 700, 60, 35, "واحدهای سنگیِ ویژه", 720, 900, 2, 0.15, 20, 10, 30, "fr_clear_elite", "pl_op"),
        ("pl_secret", "secret", "دروازه‌ی سنگی", "The Stone Gate", "دروازه‌ای که فقط با ردِ درست باز می‌شه.", 3, 3, 1, 900, 55, 40, "نگهبانانِ دروازه", 900, 1080, 2, 0.20, 30, 10, 45, "fr_clear_secret", "pl_scout"),
        ("pl_vault", "secret", "گنج‌خانه‌ی فراموش‌شده", "Forgotten Vault", "اتاقی که از تمدنِ قدیم هیچ‌کس خبر نداره.", 4, 4, 1, 1500, 50, 40, "نگهبانِ گنج‌خانه", 1080, 1320, 2, 0.25, 40, 12, 70, "fr_clear_secret", "pl_secret"),
    ],
    "ironwood": [
        ("ir_scout", "scout", "حاشیه‌ی جنگل", "Forest Edge", "اولین درخت‌هایِ آهنین؛ صدای فلز از لابه‌لای شاخه‌هاست.", 2, 4, 2, 650, 75, 20, "گرگ‌های زره‌پوش", 240, 300, 1, 0.05, 0, 6, 14, "fr_clear_scout", ""),
        ("ir_op", "operation", "دالانِ ریشه‌ها", "Root Corridor", "مسیری که ریشه‌ها هر لحظه جابه‌جاش می‌کنن.", 3, 4, 2, 1100, 70, 25, "نگهبانانِ ریشه‌ای", 480, 600, 1, 0.09, 12, 8, 24, "fr_clear_operation", "ir_scout"),
        ("ir_elite", "elite", "تله‌خانه‌ی آهنین", "Iron Snare", "هر قدم یه تله‌ست؛ اما غنیمتش کمیابه.", 4, 5, 2, 1800, 65, 30, "شکارچیانِ زره‌دار", 780, 960, 2, 0.16, 24, 10, 38, "fr_clear_elite", "ir_op"),
        ("ir_secret", "secret", "غارِ ریشه‌ی سرخ", "Redroot Cave", "غاری که فقط شکارچیانِ باتجربه ردش رو می‌گیرن.", 4, 5, 2, 2200, 60, 35, "نگهبانانِ غار", 960, 1140, 2, 0.22, 34, 10, 55, "fr_clear_secret", "ir_scout"),
        ("ir_vault", "secret", "قلبِ جنگل", "Heart of the Forest", "جایی که جنگل برای اولین بار بیدار شد.", 5, 6, 2, 3000, 55, 35, "قلبِ نگهبان", 1140, 1380, 2, 0.28, 44, 12, 85, "fr_clear_secret", "ir_secret"),
    ],
    "glass": [
        ("gl_scout", "scout", "حاشیه‌ی طوفان", "Storm Rim", "شنِ شیشه‌ای زیرِ پات خش‌خش می‌کنه.", 3, 7, 3, 1500, 60, 40, "عقرب‌های شیشه‌ای", 240, 300, 1, 0.05, 0, 6, 16, "fr_clear_scout", ""),
        ("gl_op", "operation", "خرابه‌های مدفون", "Buried Ruins", "شهری که طوفان نیمی از اون رو بلعیده.", 4, 7, 3, 2500, 60, 40, "نگهبانانِ شنی", 480, 600, 1, 0.09, 14, 8, 26, "fr_clear_operation", "gl_scout"),
        ("gl_elite", "elite", "معبدِ آینه‌ها", "Mirror Temple", "نورِ خورشید اینجا سلاحه.", 5, 8, 3, 3900, 55, 45, "کاهنانِ شیشه‌ای", 780, 960, 2, 0.17, 26, 10, 42, "fr_clear_elite", "gl_op"),
        ("gl_secret", "secret", "معبدِ مخفی", "Hidden Temple", "معبدی که فقط در سکوتِ طوفان پیدا می‌شه.", 5, 8, 3, 4600, 50, 50, "نگهبانانِ معبد", 960, 1140, 2, 0.24, 36, 10, 60, "fr_clear_secret", "gl_scout"),
        ("gl_vault", "secret", "گنجینه‌ی طوفان", "Storm Hoard", "هر چیزی که طوفان بلعیده اینجاست.", 5, 9, 3, 5800, 50, 50, "نگهبانِ گنجینه", 1140, 1380, 2, 0.30, 46, 12, 90, "fr_clear_secret", "gl_secret"),
    ],
    "harbor": [
        ("hb_scout", "scout", "اسکله‌ی شکسته", "Broken Pier", "الوارهای پوسیده و ریسمان‌هایی که هنوز تکون می‌خورن.", 3, 10, 5, 3200, 55, 45, "راهزنانِ دریایی", 240, 300, 1, 0.05, 0, 6, 18, "fr_clear_scout", ""),
        ("hb_op", "operation", "کشتی‌های متروکه", "Ghost Fleet", "ناوگانی که بدونِ ملوان حرکت می‌کنه.", 4, 10, 5, 4300, 55, 45, "ناخدایانِ شبح", 480, 600, 1, 0.09, 16, 8, 28, "fr_clear_operation", "hb_scout"),
        ("hb_elite", "elite", "انبارِ غرق‌شده", "Sunken Warehouse", "قفسه‌هایی پر از چیزهایی که دریا پس نداد.", 5, 11, 5, 5500, 50, 50, "غواصانِ زره‌دار", 780, 960, 2, 0.18, 28, 10, 44, "fr_clear_elite", "hb_op"),
        ("hb_secret", "secret", "غارِ مرجانی", "Coral Cave", "ورودی‌ش فقط وقتِ جزر پیداست.", 5, 11, 5, 6600, 45, 55, "نگهبانانِ مرجانی", 960, 1140, 2, 0.26, 38, 10, 62, "fr_clear_secret", "hb_scout"),
        ("hb_vault", "secret", "گنج‌خانه‌ی اعماق", "Deep Treasury", "قدیمی‌ترین گنجِ بندر.", 5, 12, 5, 7200, 45, 55, "نگهبانِ اعماق", 1140, 1380, 2, 0.32, 48, 12, 95, "fr_clear_secret", "hb_secret"),
    ],
    "peaks": [
        ("pk_scout", "scout", "گردنه‌ی رعد", "Thunder Pass", "هوا بوی اوزون می‌ده.", 4, 12, 6, 5600, 50, 50, "برج‌های الکتریکی", 240, 300, 1, 0.05, 0, 6, 20, "fr_clear_scout", ""),
        ("pk_op", "operation", "پایگاهِ قله", "Summit Base", "تجهیزاتِ سنگین بالای ابرها.", 5, 12, 6, 7000, 50, 50, "نگهبانانِ سنگین", 480, 600, 1, 0.10, 18, 8, 30, "fr_clear_operation", "pk_scout"),
        ("pk_elite", "elite", "رصدخانه‌ی طوفان", "Storm Observatory", "هر صاعقه‌ای که می‌زنه، یه سلاحِ جدید شارژ می‌شه.", 5, 13, 6, 8000, 45, 55, "مهندسانِ رعد", 780, 960, 2, 0.20, 30, 10, 46, "fr_clear_elite", "pk_op"),
        ("pk_secret", "secret", "غارِ آذرخش", "Lightning Cave", "غاری که صاعقه‌ها توش می‌خوابن.", 5, 13, 6, 9500, 45, 55, "نگهبانانِ آذرخش", 960, 1140, 2, 0.28, 40, 10, 66, "fr_clear_secret", "pk_scout"),
        ("pk_vault", "secret", "قلبِ طوفان", "Heart of the Storm", "مرکزِ همه‌ی صاعقه‌ها.", 5, 14, 6, 11500, 40, 60, "قلبِ طوفان", 1140, 1380, 2, 0.34, 50, 12, 100, "fr_clear_secret", "pk_secret"),
    ],
    "core": [
        ("co_scout", "scout", "دهانه‌ی سوزان", "Burning Crater", "سنگ مذاب و بخارِ گوگرد.", 5, 20, 8, 10500, 45, 55, "ساکنانِ دهانه", 300, 360, 1, 0.06, 0, 6, 24, "fr_clear_scout", ""),
        ("co_op", "operation", "تونل‌های مذاب", "Molten Tunnels", "تونل‌هایی که هر ساعت راهشون عوض می‌شه.", 5, 20, 8, 13500, 45, 55, "نگهبانانِ مذاب", 540, 660, 1, 0.11, 22, 8, 36, "fr_clear_operation", "co_scout"),
        ("co_elite", "elite", "تالارِ شهاب", "Meteor Hall", "تالاری که از یک سنگِ آسمونی تراشیده شده.", 5, 22, 8, 16000, 40, 60, "مهندسانِ شهاب", 840, 1020, 2, 0.22, 36, 10, 54, "fr_clear_elite", "co_op"),
        ("co_secret", "secret", "اتاقِ فوق‌مخفی", "Ultra-Secret Chamber", "اتاقی که روی هیچ نقشه‌ای نیست.", 5, 22, 8, 18000, 40, 60, "نگهبانانِ بی‌نام", 1020, 1200, 2, 0.30, 46, 10, 80, "fr_clear_secret", "co_scout"),
        ("co_vault", "secret", "گنجینه‌ی افسانه‌ای", "Legendary Hoard", "آخرین گنجِ مرزها.", 5, 24, 8, 23500, 40, 60, "نگهبانِ افسانه‌ای", 1200, 1440, 2, 0.36, 56, 14, 120, "fr_clear_secret", "co_secret"),
    ],
}

# گزینه‌های سیگنالِ اتاق‌های مخفی (۳ گزینه)
SIGNALS = {
    "pl_secret": ("🔍 سیگنالی عجیب زیرِ خرابه‌ها شناسایی شد!", "بررسیِ تونلِ شمالی|تخریبِ دیوارِ جنوبی|ارسالِ گروهِ شناسایی"),
    "pl_vault": ("🔍 ردپایی از یه گنج‌خانه‌ی قدیمی زیرِ دروازه پیدا شد!", "کندنِ زیرِ دروازه|بررسیِ کتیبه‌ها|دنبالِ ردِ نگهبان"),
    "ir_secret": ("🔍 ریشه‌های سرخ یه مسیرِ مخفی رو نشون می‌دن!", "دنبالِ ریشه‌ی سرخ|بریدنِ بوته‌های خاردار|شنودِ صدای فلز"),
    "ir_vault": ("🔍 قلبِ جنگل داره می‌تپه!", "رفتن به سمتِ تپش|دورزدنِ تله‌ها|ردیابیِ نورِ سبز"),
    "gl_secret": ("🔍 در سکوتِ طوفان، سایه‌ی یه معبد دیده شد!", "حفرِ تپه‌ی غربی|دنبالِ انعکاسِ نور|دنبالِ ردِ عقرب"),
    "gl_vault": ("🔍 شن‌ها یه گنجینه رو لو دادن!", "کاویدنِ ماسه‌های سرخ|بررسیِ ستون‌های شکسته|دنبالِ باد"),
    "hb_secret": ("🔍 جزر شروع شد و ورودیِ غار پیدا شد!", "غواصی از شمال|بازکردنِ دریچه‌ی زنگ‌زده|دنبالِ ماهی‌های نورانی"),
    "hb_vault": ("🔍 از عمقِ اسکله صدای زنگ میاد!", "غواصی به عمق|بریدنِ زنجیرِ لنگر|دنبالِ ردِ ناخدا"),
    "pk_secret": ("🔍 صاعقه‌ها همیشه به یک نقطه می‌خورن!", "رفتن به نقطه‌ی برخورد|عبور از شکافِ شرقی|نصبِ برق‌گیر"),
    "pk_vault": ("🔍 مرکزِ طوفان آروم شده...", "رفتن به چشمِ طوفان|دنبالِ ردِ سیم‌ها|بالا رفتن از دیوار"),
    "co_secret": ("🔍 دیوارِ دهانه تو یه نقطه سرده!", "شکافتنِ دیوارِ سرد|دنبالِ بخارِ آبی|فرستادنِ پهپادِ شناسایی"),
    "co_vault": ("🔍 هسته‌ی شهاب یه سیگنالِ تکرارشونده می‌فرسته!", "پیگیریِ سیگنال|قطعِ منبعِ انرژی|ارسالِ تیمِ مهندسی"),
}

# بوس: key, region, node_key, name, en, emoji, hp, defense, resist, phases, skill, diff, part_pts, sort
# resist: ضریبِ آسیبِ هر دسته (کمتر از ۱ = مقاوم). phases: at (٪ HP که از اونجا فاز شروع می‌شه) …
BOSSES = [
    ("boss_plains", "plains", "pl_boss", "نگهبانِ دشت", "Plains Guardian", "🗿", 5_000_000, 650,
     {"ground": 0.9, "armor": 0.85, "air": 1.15, "missile": 1.1},
     [{"at": 100, "name": "دفاعِ طبیعی", "def": 1.0, "ret": 1.0, "weak": "", "weak_mult": 1.0, "note": "سنگ‌ها سپرِ نگهبانن."},
      {"at": 60, "name": "خشم و افزایشِ قدرت", "def": 0.9, "ret": 1.3, "weak": "air", "weak_mult": 1.25, "note": "نگهبان خشمگینه؛ بالا آسیب‌پذیرتر!"},
      {"at": 25, "name": "حمله‌ی نهایی", "def": 0.8, "ret": 1.7, "weak": "armor", "weak_mult": 1.3, "note": "سنگ‌ها ترک خوردن؛ ضربه‌ی نهایی!"}],
     "کوبشِ زمین: تلافیِ فازِ آخر دو برابر تلفات می‌ده.", 1, 12, 5),
    ("boss_ironwood", "ironwood", "ir_boss", "غولِ آهنین", "Iron Giant", "🌳", 9_000_000, 1700,
     {"ground": 0.8, "armor": 0.75, "air": 1.1, "missile": 1.25, "naval": 1.0},
     [{"at": 100, "name": "پوسته‌ی آهنین", "def": 1.1, "ret": 1.0, "weak": "", "weak_mult": 1.0, "note": "پوستِ فولادیِ غول جلوی ضربه‌های سبک رو می‌گیره."},
      {"at": 60, "name": "بیداریِ ریشه‌ها", "def": 1.0, "ret": 1.35, "weak": "missile", "weak_mult": 1.35, "note": "ریشه‌ها بیدار شدن؛ موشک‌ها اثرِ بیشتری دارن."},
      {"at": 25, "name": "خشمِ جنگل", "def": 0.85, "ret": 1.8, "weak": "air", "weak_mult": 1.3, "note": "غول وحشی شده!"}],
     "ریشه‌گیری: تلفاتِ حمله‌ی مستقیم در فازِ ۲ بیشتره.", 2, 14, 6),
    ("boss_glass", "glass", "gl_boss", "مارِ شیشه‌ای", "Glass Serpent", "🐍", 17_500_000, 3600,
     {"ground": 1.0, "armor": 0.8, "air": 0.9, "missile": 1.2, "naval": 1.1},
     [{"at": 100, "name": "خزشِ شنی", "def": 1.0, "ret": 1.0, "weak": "", "weak_mult": 1.0, "note": "مار زیرِ شن‌ها پنهانه."},
      {"at": 60, "name": "طوفانِ شیشه", "def": 1.15, "ret": 1.4, "weak": "naval", "weak_mult": 1.3, "note": "طوفانِ شیشه‌ای می‌وزه؛ نیروهای دریایی اثر دارن."},
      {"at": 25, "name": "پوست‌اندازی", "def": 0.75, "ret": 1.9, "weak": "ground", "weak_mult": 1.35, "note": "پوستش ترک خورد؛ ضربه‌ی نهایی زمینی!"}],
     "ریزشِ شیشه: نفوذِ مخفیانه در فازِ ۲ تلفاتِ کمتری داره.", 3, 16, 7),
    ("boss_harbor", "harbor", "hb_boss", "پادشاهِ اعماق", "Abyss King", "🦑", 25_500_000, 5200,
     {"ground": 1.1, "armor": 0.9, "air": 0.85, "missile": 1.0, "naval": 0.8},
     [{"at": 100, "name": "اعماقِ تاریک", "def": 1.05, "ret": 1.0, "weak": "", "weak_mult": 1.0, "note": "پادشاه زیرِ آب‌هاست."},
      {"at": 60, "name": "مدّ خشم", "def": 1.0, "ret": 1.45, "weak": "ground", "weak_mult": 1.3, "note": "مدّ بالا اومده؛ نیروهای زمینی ضربه‌ی خوبی می‌زنن."},
      {"at": 25, "name": "گردابِ پایان", "def": 0.8, "ret": 2.0, "weak": "missile", "weak_mult": 1.4, "note": "گردابِ نهایی؛ موشک‌ها کارِ تمومه."}],
     "گرداب: تلفاتِ فازِ آخر برای ناوها بیشتره.", 4, 18, 8),
    ("boss_peaks", "peaks", "pk_boss", "اژدهای آذرخش", "Thunder Dragon", "🐉", 35_000_000, 7800,
     {"ground": 1.0, "armor": 0.9, "air": 0.75, "missile": 1.2, "naval": 1.0},
     [{"at": 100, "name": "پروازِ اول", "def": 1.1, "ret": 1.1, "weak": "", "weak_mult": 1.0, "note": "اژدها بالای ابرهاست."},
      {"at": 60, "name": "طوفانِ الکتریکی", "def": 1.0, "ret": 1.5, "weak": "armor", "weak_mult": 1.25, "note": "صاعقه می‌زنه؛ زره‌ها مقاومت می‌کنن."},
      {"at": 25, "name": "نفسِ رعدآسا", "def": 0.8, "ret": 2.1, "weak": "missile", "weak_mult": 1.45, "note": "نفسِ رعدآسا؛ موشک‌ها نجاتت می‌دن."}],
     "رعد: تلفاتِ هوایی در فازِ ۲ بیشتره.", 5, 20, 9),
    ("boss_core", "core", "co_boss", "هسته‌ی زنده‌ی شهاب", "Living Meteor Core", "☄️", 66_000_000, 15500,
     {"ground": 1.0, "armor": 1.0, "air": 1.0, "missile": 0.85, "naval": 1.0, "special": 1.1},
     [{"at": 100, "name": "هسته‌ی خفته", "def": 1.1, "ret": 1.2, "weak": "", "weak_mult": 1.0, "note": "هسته هنوز کاملاً بیدار نیست."},
      {"at": 66, "name": "بیداریِ شهاب", "def": 1.05, "ret": 1.6, "weak": "naval", "weak_mult": 1.3, "note": "هسته می‌درخشه؛ نیروی دریایی اثر داره."},
      {"at": 33, "name": "فروپاشی", "def": 0.85, "ret": 2.3, "weak": "air", "weak_mult": 1.4, "note": "فروپاشیِ نهایی؛ همه‌ی نیروها وارد بشن!"}],
     "ذوب: تلفاتِ فازِ آخر ۲٫۵ برابره؛ با پشتیبانیِ لجستیکی بیا.", 5, 24, 10),
    # باسِ رویداد (بیداریِ غولِ آهنین) — فقط با ایونتِ مربوطه فعال می‌شه
    ("boss_ironwood_awake", "ironwood", "", "غولِ آهنینِ بیدارشده", "Awakened Iron Giant", "🔥", 9_000_000, 1500,
     {"ground": 0.8, "armor": 0.75, "air": 1.15, "missile": 1.3},
     [{"at": 100, "name": "بیداری", "def": 1.0, "ret": 1.2, "weak": "", "weak_mult": 1.0, "note": "غول از خوابِ طولانی بیدار شده."},
      {"at": 50, "name": "خشمِ آهنین", "def": 0.9, "ret": 1.8, "weak": "air", "weak_mult": 1.35, "note": "خشمگینه؛ بالا آسیب‌پذیره."}],
     "رویداد: فقط تا پایانِ ایونت.", 3, 18, 11),
]

# مأموریت‌ها (بر پایه‌ی سیستمِ مأموریتِ جنگ: WarQuestDef)
# key,name,kind,metric,target,xp,hop_h,mat,clan_xp,unlock,req_level
QUESTS = [
    ("fr_d_scout", "🧭 یک عملیاتِ شناسایی انجام بده", "daily", "fr_scouts", 1, 40, 0.15, 10, 0, "", 2),
    ("fr_d_runs2", "🌌 ۲ بار در اکتشاف شرکت کن", "daily", "fr_runs", 2, 50, 0.20, 15, 10, "", 2),
    ("fr_d_dmg", "💥 ۳۰۰۰ آسیب به دشمن/باس وارد کن", "daily", "fr_damage", 3000, 60, 0.25, 15, 15, "", 2),
    ("fr_d_boss", "🐉 به باس حمله کن", "daily", "fr_boss_hits", 1, 55, 0.25, 20, 20, "", 2),
    ("fr_d_help", "🤝 به عملیاتِ قبیله کمک کن", "daily", "fr_support", 1, 45, 0.20, 10, 25, "", 5),
    ("fr_w_region", "🗺 یک منطقه رو تکمیل کن", "weekly", "fr_regions", 1, 350, 1.5, 120, 80, "", 2),
    ("fr_w_rooms", "🗝 ۵ اتاقِ مخفی کشف کن", "weekly", "fr_rooms", 5, 400, 2.0, 150, 100, "", 3),
    ("fr_w_boss3", "🐉 ۳ باس رو شکست بده", "weekly", "fr_boss_kills", 3, 450, 2.5, 180, 120, "", 4),
    ("fr_w_help5", "🤝 ۵ بار به قبیله کمک کن", "weekly", "fr_support", 5, 300, 1.2, 100, 150, "", 5),
    ("fr_s_all", "🌌 همه‌ی مناطقِ فصل رو کشف کن", "special", "fr_regions", 6, 1200, 6.0, 400, 400, "", 8),
    ("fr_s_flawless", "👑 بدونِ تلفات یک باسِ افسانه‌ای رو شکست بده", "special", "fr_flawless", 1, 900, 5.0, 300, 300, "", 6),
    ("fr_s_secretpath", "🗝 یک منطقه رو با مسیرِ مخفی تکمیل کن", "special", "fr_secret_regions", 1, 700, 4.0, 250, 200, "", 4),
]

# قوانینِ پاداش (WarRewardRule) — Reward Engine: ساعتِ درآمدِ مرجع، سقف، لجر
# trigger,label,xp,clan_xp,contrib,hop_ref_h,mat,ledger
RULES = [
    ("fr_welcome", "هدیه‌ی ورود به Frontier", 250, 0, 0, 0.8, 60, "EVENT_REWARD"),
    ("fr_pioneer_1", "پیشگامِ روزِ ۱", 120, 0, 0, 0.5, 0, "EVENT_REWARD"),
    ("fr_pioneer_2", "پیشگامِ روزِ ۲", 180, 0, 0, 0.75, 0, "EVENT_REWARD"),
    ("fr_pioneer_3", "پیشگامِ روزِ ۳", 300, 0, 0, 1.25, 100, "EVENT_REWARD"),
    ("fr_clear_scout", "کلیرِ اولِ شناسایی", 80, 15, 2, 0.30, 20, "BATTLE_REWARD"),
    ("fr_clear_operation", "کلیرِ اولِ عملیات", 140, 25, 3, 0.55, 40, "BATTLE_REWARD"),
    ("fr_clear_elite", "کلیرِ اولِ عملیاتِ پیشرفته", 240, 40, 4, 0.95, 70, "BATTLE_REWARD"),
    ("fr_clear_secret", "کلیرِ اولِ اتاقِ مخفی", 300, 50, 5, 1.30, 90, "BATTLE_REWARD"),
    ("fr_clear_boss", "شکستِ اولِ باس", 500, 120, 8, 2.00, 150, "BATTLE_REWARD"),
    ("fr_repeat", "تکرارِ عملیات", 25, 6, 1, 0.25, 8, "BATTLE_REWARD"),
    ("fr_fail", "دلداریِ شکست", 15, 0, 0, 0.03, 5, "COMPENSATION"),
    ("fr_support", "پشتیبانیِ لجستیکی", 30, 20, 3, 0.20, 0, "CLAN_REWARD"),
    ("fr_boss_hit", "مشارکت در نبردِ باس", 40, 20, 2, 0.25, 10, "BATTLE_REWARD"),
    ("fr_boss_kill", "سهمِ شکستِ باس", 300, 200, 10, 1.50, 120, "CLAN_REWARD"),
    ("fr_region_done", "تکمیلِ منطقه", 400, 100, 6, 1.00, 100, "EVENT_REWARD"),
    ("fr_room_found", "کشفِ اتاقِ مخفی", 120, 25, 3, 0.40, 40, "EVENT_REWARD"),
    ("fr_season_1", "جایزه‌ی رتبه‌ی ۱ فصل", 1500, 0, 0, 24.0, 300, "EVENT_REWARD"),
    ("fr_season_2", "جایزه‌ی رتبه‌ی ۲ فصل", 900, 0, 0, 14.0, 200, "EVENT_REWARD"),
    ("fr_season_3", "جایزه‌ی رتبه‌ی ۳ فصل", 500, 0, 0, 8.0, 120, "EVENT_REWARD"),
    ("fr_season_part", "پاداشِ مشارکتِ فصل", 150, 0, 0, 2.5, 40, "EVENT_REWARD"),
    ("fr_honor", "پاداشِ افتخار", 0, 0, 0, 0.0, 0, "EVENT_REWARD"),
]

# افتخارات: key,name,emoji,desc,rarity,metric,threshold,title,xp,hop_h
HONORS = [
    ("first_explorer", "اولین کاوشگر", "🧭", "اولین عملیاتِ Frontier رو با موفقیت انجام داده.", "common", "clears", 1, "کاوشگر", 60, 0.2),
    ("plains_conqueror", "فاتحِ دشت", "🗿", "نگهبانِ دشت رو شکست داده.", "common", "boss:plains", 1, "", 120, 0.4),
    ("ironwood_conqueror", "فاتحِ جنگل", "🌳", "غولِ آهنین رو شکست داده.", "rare", "boss:ironwood", 1, "", 200, 0.8),
    ("glass_conqueror", "فاتحِ بیابان", "🐍", "مارِ شیشه‌ای رو شکست داده.", "rare", "boss:glass", 1, "", 300, 1.2),
    ("harbor_conqueror", "فاتحِ بندر", "🦑", "پادشاهِ اعماق رو شکست داده.", "epic", "boss:harbor", 1, "", 450, 2.0),
    ("dragon_slayer", "اژدهاشکن", "🐉", "اژدهای آذرخش رو شکست داده.", "epic", "boss:peaks", 1, "اژدهاشکن", 700, 3.0),
    ("core_breaker", "شکننده‌ی هسته", "☄️", "هسته‌ی شهاب رو شکست داده.", "legendary", "boss:core", 1, "فرمانروای شهاب", 1200, 6.0),
    ("frontier_conqueror", "فاتحِ مرزها", "🌌", "تمام مناطق رو کامل کرده.", "legendary", "regions", 6, "فاتحِ مرزها", 1500, 8.0),
    ("secret_hunter", "شکارچیِ اسرار", "🗝", "تمام اتاق‌های مخفی رو کشف کرده.", "mythic", "rooms", 12, "شکارچیِ اسرار", 2000, 10.0),
    ("room_finder", "کاشفِ اتاق", "🔦", "اولین اتاقِ مخفی رو کشف کرده.", "common", "rooms", 1, "", 80, 0.3),
    ("flawless_slayer", "بی‌خدشه", "💎", "یه باس رو بدونِ هیچ تلفاتی شکست داده.", "epic", "flawless", 1, "بی‌خدشه", 600, 2.5),
    ("clan_pillar", "ستونِ قبیله", "🏰", "در شکستِ گروهیِ باس بیشترین مشارکتِ معتبر رو داشته.", "rare", "pillar", 1, "ستونِ قبیله", 300, 1.0),
    ("frontier_lord", "فرمانروای Frontier", "👑", "عضوِ قبیله‌ی رتبه‌ی اولِ یک فصل.", "mythic", "season_win", 1, "فرمانروای Frontier", 0, 0.0),
    ("season_podium", "سکوی فصل", "🏆", "عضوِ قبیله‌ی سه‌نفرِ برترِ یک فصل.", "epic", "season_top3", 1, "", 0, 0.0),
    ("pioneer", "پیشگام", "🚩", "سه روزِ اولِ Frontier رو کامل کرده.", "rare", "pioneer", 3, "پیشگام", 0, 0.0),
    ("runs_100", "۱۰۰ عملیات", "💯", "۱۰۰ عملیاتِ Frontier انجام داده.", "rare", "runs", 100, "", 400, 1.5),
]

# ایونتِ شروع (فقط یک‌بار seed می‌شه)
UNLOCK_RULE = ("frontier", "مرزهای هاپویی", "🌌", 2, 0, 0, 0, "", "", "",
               "جهانی ناشناخته بعد از سطح ۲ باز می‌شه...", True, 16)


def _seed_regions(session):
    if session.query(FrontierRegion).count() == 0:
        for (k, n, en, em, st, us, hint, sort, prev, th, lvl, pb, pp, cp, cpar, sc) in REGIONS:
            session.add(FrontierRegion(key=k, name=n, name_en=en, emoji=em, story=st, unlock_story=us, hint=hint,
                                       sort=sort, prev_region=prev, req_th=th, req_level=lvl, req_prev_boss=pb,
                                       req_personal_points=pp, req_clan_points=cp, req_clan_participants=cpar,
                                       reward_scale=sc))
    if session.query(FrontierNode).count() == 0:
        n_sort = 0
        for reg, rows in NODE_ROWS.items():
            for (k, kind, name, en, story, diff, rlv, rth, pw, gp, ap, enemy, mn, mx, fuel, ch, cm, rl, pts, trig, req) in rows:
                n_sort += 1
                sig = SIGNALS.get(k)
                session.add(FrontierNode(
                    key=k, region_key=reg, kind=kind, name=name, name_en=en, story=story, difficulty=diff,
                    req_level=rlv, req_th=rth, power=pw, ground_pct=gp, air_pct=ap, enemy_name=enemy,
                    min_seconds=mn, max_seconds=mx, fuel=fuel, cost_ref_hours=ch, cost_mat=cm, readiness_loss=rl,
                    points=pts, reward_trigger=trig, requires=req, hidden=(kind == "secret"),
                    reveal_clues=3 if k.endswith("_secret") else 4,
                    reveal_options=sig[1] if sig else "", signal_text=sig[0] if sig else "", hint_clues=5 if k.endswith("_secret") else 6,
                    sort=n_sort))
            # نگهبان (باس)
            b = [x for x in BOSSES if x[1] == reg and x[2]]
            if b:
                bx = b[0]
                n_sort += 1
                reg_row = [r for r in REGIONS if r[0] == reg][0]
                session.add(FrontierNode(
                    key=bx[2], region_key=reg, kind="boss", name=bx[3], name_en=bx[4], story="نگهبانِ منطقه؛ باید با همکاری شکست بخوره.",
                    difficulty=bx[12], req_level=rows[2][6], req_th=reg_row[9], power=bx[7], fuel=2.0, cost_ref_hours=0.12,
                    cost_mat=25, readiness_loss=14, points=bx[13], reward_trigger="fr_clear_boss",
                    requires=",".join(r[0] for r in rows if r[1] in ("scout", "operation", "elite")), hidden=False,
                    min_seconds=600, max_seconds=900, sort=n_sort))


def _seed_bosses(session):
    if session.query(FrontierBossDef).count() == 0:
        for (k, reg, nk, name, en, em, hp, dfn, res, phases, skill, diff, pp, sort) in BOSSES:
            session.add(FrontierBossDef(key=k, region_key=reg, node_key=nk, name=name, name_en=en, emoji=em, hp=hp,
                                        defense=dfn, resist_json=json.dumps(res), phases_json=json.dumps(phases, ensure_ascii=False),
                                        skill=skill, difficulty=diff, participation_points=pp, is_event=(nk == ""),
                                        enabled=True, sort=sort))


def _seed_rules(session):
    import war_db as W
    have = {r.trigger for r in session.query(W.WarRewardRule).all()}
    for (t, lab, xp, cxp, ct, hh, mat, lt) in RULES:
        if t not in have:
            session.add(W.WarRewardRule(trigger=t, label=lab, xp=xp, clan_xp=cxp, contribution=ct, hop_abs=0,
                                        hop_ref_hours=hh, materials=mat, ledger_type=lt, antifarm=False))
    qhave = {q.key for q in session.query(W.WarQuestDef).all()}
    for (k, n, kind, m, tg, xp, hh, mat, cxp, uf, rl) in QUESTS:
        if k not in qhave:
            session.add(W.WarQuestDef(key=k, name=n, kind=kind, metric=m, target=tg, xp=xp, hop_ref_hours=hh,
                                      materials=mat, clan_xp=cxp, unlock_feature=uf, req_level=rl))
    f, l, e, lv, th, cl, w, q, a, rs, h, v, s = UNLOCK_RULE
    if session.get(W.WarUnlockRule, f) is None:
        session.add(W.WarUnlockRule(feature=f, label=l, emoji=e, req_level=lv, req_th=th, req_clan_level=cl, req_wins=w,
                                    req_quest=q, req_achievement=a, req_research=rs, hint=h, visible_before=v, sort=s))
    # Alias های تریگرِ متنی (فقط اگه نباشن)
    from war_text import normalize
    for t in ("مرزهای هاپویی", "فرانتیر هاپویی", "اکتشاف هاپویی", "frontier هاپویی"):
        nt = normalize(t)
        if not session.query(W.WarAlias).filter_by(text=nt).first():
            session.add(W.WarAlias(panel="frontier", text=nt, builtin=True))


def _seed_honors(session):
    if session.query(FrontierHonorDef).count() == 0:
        for i, (k, n, em, desc, rar, met, th, title, xp, hh) in enumerate(HONORS):
            session.add(FrontierHonorDef(key=k, name=n, emoji=em, description=desc, rarity=rar, metric=met,
                                         threshold=th, title=title, xp=xp, hop_ref_hours=hh, sort=i + 1))


def seed_defaults(session):
    """فقط برای جدول‌های خالی؛ ادمین بعدش همه‌چیز رو عوض می‌کنه. هیچ ردیفِ موجودی بازنویسی نمی‌شه."""
    _seed_regions(session)
    _seed_bosses(session)
    _seed_honors(session)
    _seed_rules(session)
    session.commit()
    # ایونتِ هفته‌ی راه‌اندازی: فقط یک‌بار (کلیدِ frontier_seeded)
    if str(db.cfg_get(session, "frontier_seeded") or "0") != "1":
        days = float(db.cfg_get(session, "frontier_launch_week_days") or 7)
        mult = float(db.cfg_get(session, "frontier_launch_reward_mult") or 1.5)
        t0 = now()
        import datetime
        if days > 0:
            session.add(FrontierEvent(kind="conquest", name="🚀 هفته‌ی راه‌اندازیِ Frontier", start_at=t0,
                                      end_at=t0 + datetime.timedelta(days=days), reward_mult=mult, xp_mult=mult,
                                      points_mult=1.25, note="launch"))
        db.cfg_set(session, "frontier_seeded", "1")
        session.commit()


def init_frontier():
    """بعد از war_db.init_war() صدا زده می‌شه (جدول‌ها با Base.metadata.create_all ساخته می‌شن)."""
    Base.metadata.create_all(db.engine)
    s = db.get_session()
    try:
        existing = {c.key for c in s.query(db.Config).all()}
        for k, v in FRONTIER_DEFAULT_CONFIG.items():
            if k not in existing:
                s.add(db.Config(key=k, value=v))
        if "frontier_seeded" not in existing:
            s.add(db.Config(key="frontier_seeded", value="0"))
        s.commit()
        db.cfg_cache_clear()
        seed_defaults(s)
        db.cfg_cache_clear()
        try:                                   # آیتم‌ها/چلنج‌های Frontier در بتل‌پس (یک‌بار؛ به جایزه‌های دریافت‌شده دست نمی‌زنه)
            import frontier_svc
            frontier_svc.post_init(s)
        except Exception:
            s.rollback()
            import logging
            logging.getLogger(__name__).exception("frontier bp post_init failed")
    finally:
        s.close()
