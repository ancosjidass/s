# -*- coding: utf-8 -*-
"""
راهنمایی هاپویی 📖

یه درختِ ساده از بخش/زیربخش که خودِ مالک (یا ادمینِ فرعیِ دارای دسترسیِ
help_guide) می‌سازه تا بخش‌های مهمِ بات رو به بازیکن‌ها یاد بده. پیش‌فرض کاملاً
خالیه.

- بخشِ پلیری (این ماژول، تابعِ show_help_root/cb_help_view): با تایپِ «راهنمایی
  هاپویی»، دستورِ /help، یا زدنِ دکمه‌ی بزرگِ «📖 راهنمایی هاپویی» تو منوی
  اصلی باز می‌شه. کاملاً پرایوته (قفل به همون کسی که بازش کرده - نگاه کن به
  handlers._verify_panel_owner) و تو خودِ گروه هم اگه باز بشه، فقط خودِ همون
  کاربر می‌تونه روی دکمه‌هاش بزنه.
- بخشِ مدیریتی (cb_admin_help_*): از پنلِ مدیریت، گزینه‌ی «📖 مدیریتِ راهنمایی
  هاپویی». اونجا می‌شه بخش/زیربخشِ جدید ساخت، توضیحِ هر بخش رو تنظیم/ویرایش/حذف
  کرد، اسمِ دکمه رو ویرایش کرد، یا کلِ یه بخش (به‌همراهِ همه‌ی زیربخش‌هاش) رو حذف
  کرد.
"""
from telegram import InlineKeyboardButton, InlineKeyboardMarkup

import db
from handlers import send_response, ask_for_input, is_reply_to_prompt, _verify_panel_owner

ROOT_ID = 0  # نشونه‌ی «ریشه‌ی درخت» تو callback_data (چون هیچ HelpNode واقعی‌ای آیدیِ ۰ نداره)


# ---------------------------------------------------------------------------
# کمکی‌های مشترک
# ---------------------------------------------------------------------------

def _children(session, parent_id):
    q = session.query(db.HelpNode)
    q = q.filter(db.HelpNode.parent_id.is_(None)) if parent_id in (None, ROOT_ID) else q.filter(db.HelpNode.parent_id == parent_id)
    return q.order_by(db.HelpNode.order_index, db.HelpNode.id).all()


def _delete_node_recursive(session, node):
    for child in _children(session, node.id):
        _delete_node_recursive(session, child)
    session.delete(node)


# ---------------------------------------------------------------------------
# نمایشِ پلیری
# ---------------------------------------------------------------------------

async def show_help_root(update, context, owner_id: int):
    session = db.get_session()
    try:
        nodes = _children(session, ROOT_ID)
        if not nodes:
            text = "📖 راهنمایی هاپویی\n\nهنوز هیچ راهنمایی‌ای توسطِ مالک اضافه نشده."
            rows = []
        else:
            text = "📖 راهنمایی هاپویی\n\nیکی از بخش‌ها رو انتخاب کن:"
            rows = [[InlineKeyboardButton(n.title, callback_data=f"hguide_view:{n.id}:{owner_id}")] for n in nodes]
        rows.append([InlineKeyboardButton("🔙 بازگشت به منو", callback_data=f"back_main_owned:{owner_id}")])
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cmd_help(update, context):
    await show_help_root(update, context, update.effective_user.id)


async def handle_help_text_trigger(update, context):
    await show_help_root(update, context, update.effective_user.id)


async def cb_help_open(update, context):
    """دکمه‌ی «📖 راهنمایی هاپویی» تو منوی اصلی (main_private_menu)."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_help_root(update, context, owner_id)


async def cb_help_view(update, context):
    _, node_id, owner_id = update.callback_query.data.split(":")
    node_id, owner_id = int(node_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    if node_id == ROOT_ID:
        await show_help_root(update, context, owner_id)
        return
    session = db.get_session()
    try:
        node = session.get(db.HelpNode, node_id)
        if not node:
            await update.callback_query.answer("این بخش دیگه وجود نداره.", show_alert=True)
            await show_help_root(update, context, owner_id)
            return
        children = _children(session, node.id)
        lines = [f"📖 {node.title}"]
        if node.description:
            lines.append("")
            lines.append(node.description)
        elif not children:
            lines.append("")
            lines.append("(هنوز توضیحی برای این بخش اضافه نشده.)")
        text = "\n".join(lines)
        rows = [[InlineKeyboardButton(c.title, callback_data=f"hguide_view:{c.id}:{owner_id}")] for c in children]
        back_target = node.parent_id if node.parent_id else ROOT_ID
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"hguide_view:{back_target}:{owner_id}")])
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مدیریت (پنل مدیریت)
# ---------------------------------------------------------------------------

def _admin_node_keyboard(session, node):
    children = _children(session, node.id)
    rows = [[InlineKeyboardButton(f"📂 {c.title}", callback_data=f"admin_help_node:{c.id}")] for c in children]
    rows.append([InlineKeyboardButton("➕ افزودنِ زیربخش", callback_data=f"admin_help_add:{node.id}")])
    if node.description:
        rows.append([InlineKeyboardButton("✏️ ویرایشِ توضیح", callback_data=f"admin_help_desc_edit:{node.id}"),
                     InlineKeyboardButton("🗑 حذفِ توضیح", callback_data=f"admin_help_desc_delete:{node.id}")])
    else:
        rows.append([InlineKeyboardButton("➕ افزودنِ توضیح", callback_data=f"admin_help_desc_edit:{node.id}")])
    rows.append([InlineKeyboardButton("✏️ ویرایشِ نامِ این دکمه", callback_data=f"admin_help_title_edit:{node.id}")])
    rows.append([InlineKeyboardButton("🗑 حذفِ این دکمه (و زیربخش‌هاش)", callback_data=f"admin_help_delete_ask:{node.id}")])
    back_target = node.parent_id or ROOT_ID
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_help_node:{back_target}" if node.parent_id else "admin_help_menu")])
    return InlineKeyboardMarkup(rows)


async def cb_admin_help_menu(update, context):
    session = db.get_session()
    try:
        nodes = _children(session, ROOT_ID)
        rows = [[InlineKeyboardButton(f"📂 {n.title}", callback_data=f"admin_help_node:{n.id}")] for n in nodes]
        rows.append([InlineKeyboardButton("➕ افزودنِ بخشِ جدید", callback_data=f"admin_help_add:{ROOT_ID}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        text = (
            "📖 مدیریتِ راهنمایی هاپویی\n\n"
            "این همون راهنمایی‌ایه که پلیرا با تایپِ «راهنمایی هاپویی»، دستورِ /help، یا دکمه‌ی «📖 راهنمایی هاپویی» تو منوی اصلی می‌بینن.\n"
            + ("هنوز هیچ بخشی نساختی." if not nodes else "بخش‌های فعلی:")
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_help_node(update, context):
    node_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        node = session.get(db.HelpNode, node_id)
        if not node:
            await update.callback_query.answer("این بخش دیگه وجود نداره.", show_alert=True)
            await cb_admin_help_menu(update, context)
            return
        lines = [f"📖 مدیریتِ بخشِ «{node.title}»", ""]
        lines.append(f"📝 توضیح: {node.description}" if node.description else "📝 توضیح: (تنظیم نشده)")
        text = "\n".join(lines)
        await send_response(update, text, _admin_node_keyboard(session, node))
    finally:
        session.close()


async def cb_admin_help_add(update, context):
    parent_id = int(update.callback_query.data.split(":")[1])
    await ask_for_input(
        update, context, "✏️ اسمِ دکمه‌ی بخشِ جدید رو بفرست:",
        {"type": "help_title_new", "parent_id": parent_id}, "admin_state",
    )


async def cb_admin_help_title_edit(update, context):
    node_id = int(update.callback_query.data.split(":")[1])
    await ask_for_input(
        update, context, "✏️ اسمِ جدیدِ این دکمه رو بفرست:",
        {"type": "help_title_edit", "node_id": node_id}, "admin_state",
    )


async def cb_admin_help_desc_edit(update, context):
    node_id = int(update.callback_query.data.split(":")[1])
    await ask_for_input(
        update, context,
        "✏️ متنِ توضیح رو بفرست (می‌تونه چندخطی باشه؛ این متن دقیقاً همینی که پلیر روی این بخش کلیک می‌کنه می‌بینه):",
        {"type": "help_desc_edit", "node_id": node_id}, "admin_state",
    )


async def cb_admin_help_desc_delete(update, context):
    node_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        node = session.get(db.HelpNode, node_id)
        if node:
            node.description = None
            session.commit()
        await update.callback_query.answer("✅ توضیح حذف شد.")
        if node:
            await send_response(update, f"📖 مدیریتِ بخشِ «{node.title}»\n\n📝 توضیح: (تنظیم نشده)", _admin_node_keyboard(session, node))
    finally:
        session.close()


async def cb_admin_help_delete_ask(update, context):
    node_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        node = session.get(db.HelpNode, node_id)
        if not node:
            await update.callback_query.answer("این بخش دیگه وجود نداره.", show_alert=True)
            return
        has_children = bool(_children(session, node.id))
        warn = "\n⚠️ زیربخش‌های این بخش هم پاک می‌شن." if has_children else ""
        text = f"🗑 مطمئنی می‌خوای بخشِ «{node.title}» رو حذف کنی؟{warn}"
        rows = [
            [InlineKeyboardButton("✅ بله، حذف کن", callback_data=f"admin_help_delete_confirm:{node_id}"),
             InlineKeyboardButton("❌ انصراف", callback_data=f"admin_help_node:{node_id}")],
        ]
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_help_delete_confirm(update, context):
    node_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        node = session.get(db.HelpNode, node_id)
        if not node:
            await update.callback_query.answer("این بخش دیگه وجود نداره.", show_alert=True)
            await cb_admin_help_menu(update, context)
            return
        parent_id = node.parent_id
        _delete_node_recursive(session, node)
        session.commit()
        await update.callback_query.answer("✅ حذف شد.")
    finally:
        session.close()
    if parent_id:
        fake_data = f"admin_help_node:{parent_id}"
        update.callback_query.data = fake_data
        await cb_admin_help_node(update, context)
    else:
        await cb_admin_help_menu(update, context)


async def help_awaiting_handler(update, context, state):
    """از داخلِ admin.admin_awaiting_handler صدا زده می‌شه (stype های
    help_title_new / help_title_edit / help_desc_edit)."""
    text = (update.message.text or "").strip()
    if not text:
        await update.message.reply_text("❌ متنِ خالی قبول نیست؛ دوباره امتحان کن.")
        return
    stype = state["type"]
    session = db.get_session()
    try:
        if stype == "help_title_new":
            parent_id = state.get("parent_id") or None
            if parent_id == ROOT_ID:
                parent_id = None
            node = db.HelpNode(parent_id=parent_id, title=text[:64])
            session.add(node)
            session.commit()
            await update.message.reply_text(f"✅ بخشِ «{node.title}» ساخته شد.")
            fake_target = parent_id if parent_id else ROOT_ID
        elif stype == "help_title_edit":
            node = session.get(db.HelpNode, state["node_id"])
            if not node:
                await update.message.reply_text("این بخش دیگه وجود نداره.")
                return
            node.title = text[:64]
            session.commit()
            await update.message.reply_text("✅ اسمِ دکمه به‌روز شد.")
            fake_target = node.id
        elif stype == "help_desc_edit":
            node = session.get(db.HelpNode, state["node_id"])
            if not node:
                await update.message.reply_text("این بخش دیگه وجود نداره.")
                return
            node.description = text[:3500]
            session.commit()
            await update.message.reply_text("✅ توضیح ثبت شد.")
            fake_target = node.id
        else:
            return

        rows_target = fake_target
        session.close()
        session = db.get_session()
        if rows_target == ROOT_ID:
            nodes = _children(session, ROOT_ID)
            rows = [[InlineKeyboardButton(f"📂 {n.title}", callback_data=f"admin_help_node:{n.id}")] for n in nodes]
            rows.append([InlineKeyboardButton("➕ افزودنِ بخشِ جدید", callback_data=f"admin_help_add:{ROOT_ID}")])
            rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
            await update.message.reply_text("📖 مدیریتِ راهنمایی هاپویی", reply_markup=InlineKeyboardMarkup(rows))
        else:
            node = session.get(db.HelpNode, rows_target)
            if node:
                lines = [f"📖 مدیریتِ بخشِ «{node.title}»", ""]
                lines.append(f"📝 توضیح: {node.description}" if node.description else "📝 توضیح: (تنظیم نشده)")
                await update.message.reply_text("\n".join(lines), reply_markup=_admin_node_keyboard(session, node))
    finally:
        session.close()


ADMIN_HELP_CALLBACKS = {
    "admin_help_menu": cb_admin_help_menu,
    "admin_help_node": cb_admin_help_node,
    "admin_help_add": cb_admin_help_add,
    "admin_help_title_edit": cb_admin_help_title_edit,
    "admin_help_desc_edit": cb_admin_help_desc_edit,
    "admin_help_desc_delete": cb_admin_help_desc_delete,
    "admin_help_delete_ask": cb_admin_help_delete_ask,
    "admin_help_delete_confirm": cb_admin_help_delete_confirm,
}

PLAYER_HELP_CALLBACKS = {
    "hguide_view": cb_help_view,
    "hguide_open": cb_help_open,
}
