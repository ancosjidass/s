# -*- coding: utf-8 -*-
"""
تنظیمات پایه‌ی ربات.
مقادیر حساس (توکن و آیدی مالک) را از Environment Variable می‌خوانیم
تا مجبور نباشی مستقیم توی کد بنویسی‌شون.
"""
import os

# توکن ربات را از @BotFather بگیر و اینجا (یا در متغیر محیطی BOT_TOKEN) قرار بده
BOT_TOKEN = os.environ.get("BOT_TOKEN", "PUT-YOUR-BOT-TOKEN-HERE")

# آیدی عددی تلگرام خودت (مالک ربات / گروه). با ربات @userinfobot می‌تونی بگیریش
OWNER_ID = int(os.environ.get("OWNER_ID", "0"))

# مسیر فایل دیتابیس (SQLite). برای شروع و حجم معمولی یک گروه/چند گروه کاملا کافیه.
DB_PATH = os.environ.get("DB_PATH", "hop_bot.db")

# --- PostgreSQL (Supabase) ---
# اگه DATABASE_URL ست باشه، ربات از PostgreSQL استفاده می‌کنه و DB_PATH نادیده گرفته می‌شه.
# نمونه (Supabase → Connect → Session pooler):
#   postgresql://postgres.<ref>:<PASSWORD>@aws-0-<region>.pooler.supabase.com:5432/postgres
# اگه خالی باشه، مثلِ قبل از SQLite (DB_PATH) استفاده می‌شه.
DATABASE_URL = os.environ.get("DATABASE_URL", "").strip()
PG_POOL_SIZE = int(os.environ.get("PG_POOL_SIZE", "10"))
PG_MAX_OVERFLOW = int(os.environ.get("PG_MAX_OVERFLOW", "5"))

# --- بهینه‌سازیِ PostgreSQL (همه‌شون اختیاری‌ان؛ پیش‌فرض‌ها بدونِ تغییرِ رفتارِ ربات‌ان) ---
# کانکشنِ بی‌کارتر از این‌همه ثانیه، قبلِ استفاده با یه «SELECT 1» سالم‌بودنش چک می‌شه
# (به‌جایِ چکِ هر بار؛ هر چکِ اضافه یه رفت‌وبرگشتِ شبکه تا Supabase بود).
PG_IDLE_PING_SECONDS = float(os.environ.get("PG_IDLE_PING_SECONDS", "20"))
# کَشِ جدولِ تنظیمات (game_config) تو حافظه؛ هر cfg_set فوراً کش رو به‌روز می‌کنه، این عدد فقط
# سقفِ تأخیر برایِ تغییری‌ه که بیرون از ربات (مثلاً از داشبوردِ Supabase) تو جدول داده بشه.
CFG_CACHE_TTL_SECONDS = float(os.environ.get("CFG_CACHE_TTL_SECONDS", "20"))
# ثبتِ آخرین «دیده‌شدنِ گروه» حداکثر هر این‌همه ثانیه یه بار تو دیتابیس نوشته می‌شه (نه با هر پیامِ گروه).
GROUP_TRACK_WRITE_SECONDS = float(os.environ.get("GROUP_TRACK_WRITE_SECONDS", "300"))
# «1» = commit بدونِ انتظار برایِ فلاشِ WAL رویِ دیسکِ سرور (synchronous_commit=off). سریع‌تره؛ فقط
# در صورتِ کرشِ خودِ سرورِ دیتابیس ممکنه آخرین کسری از ثانیه تراکنش‌ها از دست برن (دیتا خراب نمی‌شه).
# پیش‌فرض خاموشه تا رفتارِ فعلی ۱۰۰٪ همون بمونه.
PG_ASYNC_COMMIT = os.environ.get("PG_ASYNC_COMMIT", "0").strip() == "1"
# تعدادِ آپدیتِ هم‌زمان (کاربرهایِ مختلف هم‌زمان، هر کاربر به ترتیب). 0 = خاموش (یکی‌یکی، مثلِ قبل).
CONCURRENT_UPDATES = int(os.environ.get("CONCURRENT_UPDATES", "64"))
# لاگِ تشخیصِ کندی (فقط وقتی چیزی کند باشه چیزی چاپ می‌کنه): UPDATE slow / TG-API slow / EVENT-LOOP blocked
PERF_LOG = os.environ.get("PERF_LOG", "1").strip() != "0"

# «1» = همه‌ی درخواست‌هایِ ربات به تلگرام (getUpdates، sendMessage، دانلودِ فایل و ...) فقط با IPv4 برن.
# مناسبِ سرورهایی که IPv6 ندارن. این فقط روی ارتباط با تلگرام اثر داره؛ اتصال به دیتابیس
# (Supabase) و بقیه‌ی چیزها مثلِ قبل و با انتخابِ خودِ سیستم (IPv4 یا IPv6) برقرار می‌شه.
# برایِ خاموش‌کردن: FORCE_TELEGRAM_IPV4=0
FORCE_TELEGRAM_IPV4 = os.environ.get("FORCE_TELEGRAM_IPV4", "1").strip() != "0"

# فاصله‌ی کول‌داون دکمه‌ی هاپ‌هاپ (ثانیه) = ۵ دقیقه
HOP_COOLDOWN_SECONDS = 5 * 60

# بازه‌ی امتیاز هر هاپ
HOP_MIN_REWARD = 100
HOP_MAX_REWARD = 1000


# ایمیلِ کدِ تایید (سیو/بازیابیِ اکانت با جیمیل) — از طریقِ Gmail API با OAuth2، نه SMTP.
# GMAIL_TOKEN_PATH = مسیرِ token.json (با اسکریپتِ get_token.py یک‌بار می‌سازیش).
# GMAIL_CREDENTIALS_PATH = مسیرِ credentials.json (فایلی که از Google Cloud Console دانلود کردی؛
#   فقط برایِ refresh لازم می‌شه، خودِ token.json معمولاً کافیه).
# GMAIL_SENDER = آدرسِ جیمیلِ فرستنده برایِ هدرِ From (اختیاری؛ اگه خالی باشه از "me" استفاده می‌شه).
GMAIL_TOKEN_PATH = os.environ.get("GMAIL_TOKEN_PATH", "token.json")
GMAIL_CREDENTIALS_PATH = os.environ.get("GMAIL_CREDENTIALS_PATH", "credentials.json")
GMAIL_SENDER = os.environ.get("GMAIL_SENDER", "")


# نوعِ منشنِ قابل‌کلیک:
#   auto    = کاربرِ «پیوی‌کرده» → text_mention؛ بقیه → لینکِ t.me/یوزرنیم یا tg://openmessage?user_id=
#   mention = همیشه text_mention (فقط برای کسایی کار می‌کنه که قبلاً با بات پیوی کردن)
#   link    = همیشه لینک (بدونِ نوتیفِ منشن)
MENTION_MODE = os.environ.get("MENTION_MODE", "auto")
