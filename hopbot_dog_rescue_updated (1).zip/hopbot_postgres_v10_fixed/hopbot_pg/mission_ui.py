# -*- coding: utf-8 -*-
"""
رابطِ «مأموریت‌های هاپویی». تریگر: «مأموریت هاپویی» (گروه و پیوی).
callback_data = mt:<آیدیِ صاحبِ پنل>:<اکشن>[:<آرگومان>] ؛ فقط صاحبِ پنل می‌تونه کلیک کنه (سمتِ سرور چک می‌شه).
تمام متن‌های ثابت از i18n (locales/*.json) می‌آد و زبانِ هر بازیکن جداست.
"""
import logging

import db
import i18n
import mission_db as MD
import mission_engine as ME
import mission_svc as S
from mission_svc import MissionError

logger = logging.getLogger(__name__)

TRIGGERS = {"ماموریت هاپویی", "مأموریت هاپویی", "ماموریت های هاپویی", "مأموریت های هاپویی", "ماموریتای هاپویی", "ماموریت‌های هاپویی"}


def fmt(n):
    return f"{int(round(n)):,}"


def _markup(rows):
    from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as K
    return K([[B(a, callback_data=b) for a, b in r] for r in rows]) if rows else None


def _cb(owner, action, *args):
    return ":".join(["mt", str(owner), action] + [str(a) for a in args])


def _lang(session, uid):
    """زبانِ پنل = زبانِ چتی که پنل توشه (پیوی: انتخابِ خودِ کاربر، گروه: انتخابِ ادمینِ گروه) - مثلِ بقیه‌ی بات."""
    return i18n.lang_of_chat(None)


def _left(delta):
    s = max(0, int(delta.total_seconds()))
    return f"{s // 86400}d {(s % 86400) // 3600}h" if s >= 86400 else f"{s // 3600:02d}:{(s % 3600) // 60:02d}"


def main_view(session, user, lang):
    tt = lambda k, **kw: i18n.t(k, lang, **kw)
    p = S.get_player(session, user.telegram_id)
    season = S.current_season(session)
    board = S.leaderboard(session, limit=10 ** 6)
    me = next(((i + 1, pts) for i, (_n, pts, uid) in enumerate(board) if uid == user.telegram_id), (None, 0))
    mult = ME.streak_multiplier(p.streak or 0, ME.parse_steps(S.gs(session, "ct_streak_steps")))
    lines = [tt("mt_title"), "",
             tt("mt_streak", streak=p.streak or 0, mult=f"{mult:g}"),
             tt("mt_season", pts=me[1], rank=me[0] if me[0] else "—"),
             tt("mt_season_left", left=_left(season.ends_at - S.utcnow())), ""]
    items = S.todays(session, user)
    rows = []
    if not items:
        lines.append(tt("mt_empty"))
    for period, head in (("once", "mt_once"), ("daily", "mt_daily"), ("weekly", "mt_weekly")):
        grp = [t for t in items if t["period"] == period]
        if not grp:
            continue
        lines.append(tt(head))
        for t in grp:
            d = t["def"]
            mark = "✅" if t["claimed"] else ("🟢" if t["done"] else "▫️")
            lines.append(f"{mark} {d.title}")
            lines.append(f"   {ME.progress_bar(t['progress'], d.target)} {min(t['progress'], d.target)}/{d.target} — "
                         + (tt("mt_claimed") if t["claimed"] else tt("mt_reward", amount=fmt(t["reward"]))))
            if t["done"] and not t["claimed"]:
                rows.append([(tt("mt_btn_claim", title=d.title)[:60], _cb(user.telegram_id, "c", d.id))])
        lines.append("")
    langs = i18n.available()
    last = [(tt("mt_btn_board"), _cb(user.telegram_id, "board")), (tt("mt_btn_refresh"), _cb(user.telegram_id, "r"))]
    rows.append(last)
    rows.append([(tt("mt_btn_close"), _cb(user.telegram_id, "x"))])
    return "\n".join(lines).strip(), rows


def board_view(session, user, lang, chat_id):
    tt = lambda k, **kw: i18n.t(k, lang, **kw)
    lines = [tt("mt_board_title"), ""]
    for head, cid in ((tt("mt_board_group"), chat_id), (tt("mt_board_global"), None)):
        if cid is None and (chat_id is None or chat_id > 0):
            pass
        rows = S.leaderboard(session, chat_id=cid)
        lines.append(head)
        lines += [f"{i}. {n} — {pts}" for i, (n, pts, _u) in enumerate(rows, 1)] or [tt("mt_board_empty")]
        lines.append("")
    return "\n".join(lines).strip(), [[(tt("mt_btn_back"), _cb(user.telegram_id, "r"))]]


def lang_view(session, user, lang):
    tt = lambda k, **kw: i18n.t(k, lang, **kw)
    rows = [[(name, _cb(user.telegram_id, "setlang", code))] for code, name in i18n.available().items()]
    rows.append([(tt("mt_btn_back"), _cb(user.telegram_id, "r"))])
    return tt("mt_lang_pick"), rows


def dispatch(session, tg_user, chat_id, data):
    """-> (toast|None, alert, view|None)"""
    parts = data.split(":")
    if len(parts) < 3 or parts[0] != "mt" or not parts[1].lstrip("-").isdigit():
        return "؟", True, None
    owner, action, args = int(parts[1]), parts[2], parts[3:]
    user = db.get_or_create_user(session, tg_user)
    lang = _lang(session, user.telegram_id)
    if tg_user.id != owner:
        return i18n.t("mt_not_yours", lang), True, None
    gate = db.check_module_level(session, user, "mission")
    if gate:
        return gate, True, None
    if action == "x":
        return None, False, (i18n.t("mt_closed", lang), [])
    if action == "r":
        return None, False, main_view(session, user, lang)
    if action == "board":
        return None, False, board_view(session, user, lang, chat_id)
    if action == "lang":
        return None, False, lang_view(session, user, lang)
    if action == "setlang":
        code = args[0] if args else ""
        if code not in i18n.available():
            return "؟", True, None
        S.get_player(session, user.telegram_id).lang = code
        session.commit()
        return i18n.t("mt_lang_set", code), False, main_view(session, user, code)
    if action == "c":
        try:
            r = S.claim(session, user, int(args[0]), chat_id)
        except MissionError as e:
            return str(e), True, None
        extra = i18n.t("mt_got_extra", lang, extra=fmt(r["extra"])) if r["extra"] else ""
        toast = i18n.t("mt_got", lang, hop=fmt(r["hop"]), extra=extra)
        if r["all_done"]:
            toast += "\n" + S.gs(session, "ct_msg_all_done")
        return toast, False, main_view(session, user, lang)
    return "؟", True, None


async def handle_mission_trigger(update, context):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if not S.gi(session, "ct_enabled", 1):
            await update.message.reply_text("🎯 مأموریت‌ها فعلاً خاموشن.")
            return
        gate = db.check_module_level(session, user, "mission")
        if gate:
            await update.message.reply_text(gate)
            return
        S.get_player(session, user.telegram_id)
        first = not session.get(MD.MissionPlayer, user.telegram_id).welcomed
        session.commit()
        text, rows = main_view(session, user, _lang(session, user.telegram_id))
        if first:
            text = S.gs(session, "ct_msg_new_player") + "\n\n" + text
        session.commit()
    finally:
        session.close()
    await update.message.reply_text(text, reply_markup=_markup(rows))


async def mission_callback_router(update, context):
    q = update.callback_query
    if not (q.data or "").startswith("mt:"):
        return False
    session = db.get_session()
    try:
        toast, alert, view = dispatch(session, q.from_user, q.message.chat_id, q.data)
        session.commit()
    except Exception:
        session.rollback()
        logger.exception("mission callback failed")
        toast, alert, view = "⚠️ خطایی پیش اومد؛ دوباره امتحان کن.", True, None
    finally:
        session.close()
    try:
        await q.answer(toast or None, show_alert=bool(alert))
    except Exception:
        pass
    if view is not None:
        text, rows = view
        try:
            await q.edit_message_text(text, reply_markup=_markup(rows))
        except Exception as e:
            if "not modified" not in str(e).lower():
                logger.warning("mission edit failed: %s", e)
    return True


async def mission_tick_job(context):
    """پایانِ فصل‌ها و پاداشِ برترین‌ها (Idempotent؛ بعد از ری‌استارت هم امنه)."""
    session = db.get_session()
    try:
        paid = S.settle_seasons(session)
        langs = {uid: _lang(session, uid) for uid, _r, _h in paid}
    finally:
        session.close()
    for uid, rank, hop in paid:
        try:
            await context.bot.send_message(uid, i18n.t("mt_season_paid", langs.get(uid, ""), rank=rank, hop=fmt(hop)))
        except Exception:
            pass
