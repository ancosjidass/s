# -*- coding: utf-8 -*-
import datetime
import logging
import random
import re
import secrets

from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ApplicationHandlerStop

import config
import db
import mentions
import ui_style
import economy
import keyboards as kb
import antispam

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# ابزارهای کمکی
# ---------------------------------------------------------------------------

def fmt(n):
    try:
        return f"{n:,.0f}"
    except (TypeError, ValueError):
        return str(n)


_FA_DIGITS_MAP = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")

# ترتیب مهمه: پسوندهای بلندتر/خاص‌تر باید زودتر چک بشن تا با پسوندهای کوتاه‌تر
# قاطی نشن (مثلا «میلیارد» باید قبل از «میل» چک بشه).
_AMOUNT_SUFFIXES = [
    ("میلیارد", 1_000_000_000),
    ("میلیون", 1_000_000),
    ("میل", 1_000_000),
    ("هزار", 1_000),
    ("کا", 1_000),
    ("b", 1_000_000_000),
    ("m", 1_000_000),
    ("k", 1_000),
    ("ن", 1_000),
    ("م", 1_000_000),
]


def parse_amount(text: str):
    """عددی که ممکنه با یه کوتاه‌نویسیِ رایج نوشته شده باشه رو تجزیه می‌کنه:
    k / کا / ن = هزار، m / میل / م = میلیون، b / میلیارد = میلیارد. مثلا
    «4k» یا «4کا» یا «4ن» = 4000، «4m» یا «4میل» یا «4م» = 4,000,000. اگه
    هیچ پسوندی نداشت، همون عددِ ساده رو برمی‌گردونه. خروجی float یا None
    (اگه اصلاً قابل‌تجزیه نبود)."""
    if text is None:
        return None
    raw = text.strip().translate(_FA_DIGITS_MAP)
    if not raw:
        return None
    raw = raw.replace(",", "").replace("،", "").replace("٬", "").replace(" ", "")  # جداکننده‌ی هزارگان (چه لاتین چه فارسی) رو نادیده بگیر
    if not raw:
        return None
    lower = raw.lower()
    for suffix, mult in _AMOUNT_SUFFIXES:
        suf = suffix.lower()
        if lower.endswith(suf) and len(raw) > len(suffix):
            num_part = raw[: len(raw) - len(suffix)].strip()
            try:
                return float(num_part) * mult
            except ValueError:
                return None
    try:
        return float(raw)
    except ValueError:
        return None


async def send_response(update: Update, text: str, keyboard=None):
    """چه از دکمه شیشه‌ای اومده باشیم چه از یک پیام متنی، جواب رو درست می‌فرستیم.
    پیامِ فرستاده/ویرایش‌شده رو برمی‌گردونه (برای ردیابیِ ریپلای تو پرامپت‌های
    ورودی لازمه - نگاه کن به ask_for_input).

    نکته‌ی مهم: اگه edit شکست بخوره فقط به این خاطر که محتوا/دکمه‌ها همونیه که
    از قبل بوده (خطای معروفِ تلگرام «Message is not modified» - دقیقاً همون
    اتفاقی که با کلیک‌های پشتِ‌سرهمِ رو یه دکمه‌ی پنل می‌افته، چون هر بار همون
    متن دوباره ساخته می‌شه)، نباید یه پیامِ جدید بفرستیم؛ وگرنه هر پنل، هر بار
    که رو دکمه‌هاش می‌زنی، یه پیامِ تازه‌ی جداگونه می‌سازه (که دقیقاً همون باگیه
    که قبلاً گزارش شد: «هر پیام باید یه پنل بمونه»، نه چندتا پیامِ تکراری).
    فقط برای خطاهای واقعیِ دیگه (مثلاً خودِ پیام پاک شده) به فرستادنِ پیامِ
    جدید برمی‌گردیم."""
    if update.callback_query:
        q = update.callback_query
        try:
            await q.answer()
        except Exception as e:
            # خطای شبکه/تایم‌اوت موقعِ جواب‌دادن به کالبک نباید کلِ ادیتِ پنل رو بکشه
            logger.warning("answerِ کالبک شکست خورد: %s", e)
        try:
            return await q.edit_message_text(text, reply_markup=keyboard)
        except Exception as e:
            err = str(e).lower()
            if "not modified" in err:
                return q.message
            if "message to edit not found" in err or "message can't be edited" in err or "message to be edited not found" in err:
                # پیامِ اصلی واقعاً از بین رفته (مثلاً تو گروه پاک شده) - این
                # تنها حالتیه که واقعاً مجبوریم یه پیامِ تازه بفرستیم.
                return await q.message.reply_text(text, reply_markup=keyboard)
            # هر خطایِ دیگه (تایم‌اوتِ شبکه، کندیِ سرور و امثالش) معمولاً موقتیه؛
            # یه بار دیگه هم امتحان می‌کنیم، ولی اگه بازم نشد، برای جلوگیری از
            # اسپم‌شدنِ پنل با پیام‌های تکراری، دیگه پیامِ جدید نمی‌فرستیم - همون
            # پیامِ قبلی سرِ جاش می‌مونه و کاربر می‌تونه دوباره امتحان کنه.
            try:
                return await q.edit_message_text(text, reply_markup=keyboard)
            except Exception:
                logger.warning("ادیتِ پیامِ پنل دوباره هم شکست خورد؛ برای جلوگیریِ از اسپم، پیامِ جدید نمی‌فرستیم: %s", e)
                return None
    else:
        return await update.message.reply_text(text, reply_markup=keyboard)


CANCEL_BUTTON_TEXT = "🔙 بازگشت / کنسل"


def _cancel_callback_for(update: Update) -> str:
    """کنسلِ هر پرامپتی رو به آیدیِ کسی که پرامپت مالِ اونه قفل می‌کنه - وگرنه
    تو گروه هرکسی می‌تونست رو دکمه‌ی کنسلِ زیرِ پرامپتِ یه نفرِ دیگه بزنه و
    عملیاتش رو (با ادیت‌شدنِ پیام به «لغو شد») خراب کنه."""
    return f"cancel_any_awaiting:{update.effective_user.id}"


async def ask_for_input(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str,
                         state: dict, state_key: str, cancel_callback: str = None):
    """
    یه پرامپتِ «فلان مقدار رو بفرست» می‌فرسته و آی‌دیِ همون پیام رو تو خودِ
    state ذخیره می‌کنه - این‌طوری بعداً می‌شه چک کرد که جوابِ کاربر واقعاً
    ریپلای‌شده رو همین پرامپته، نه یه پیامِ نامربوطِ دیگه (که قبلاً باعث می‌شد
    پیام‌های بی‌ربط اشتباهی به‌عنوانِ جواب پردازش بشن). یه دکمه‌ی «بازگشت/کنسل»
    هم زیرش می‌ذاره - این دکمه با آیدیِ همین کاربر قفل می‌شه (نگاه کن به
    _cancel_callback_for) تا بقیه‌ی گروه نتونن رو کنسلِ عملیاتِ این یکی بزنن.
    """
    if cancel_callback is None:
        cancel_callback = _cancel_callback_for(update)
    kb_rows = [[InlineKeyboardButton(CANCEL_BUTTON_TEXT, callback_data=cancel_callback)]]
    msg = await send_response(update, text, InlineKeyboardMarkup(kb_rows))
    if msg:
        state["_prompt_chat_id"] = msg.chat_id
        state["_prompt_message_id"] = msg.message_id
    context.user_data[state_key] = state


def is_reply_to_prompt(update: Update, state: dict) -> bool:
    """True یعنی این پیام رو باید جوابِ همین پرامپت در نظر بگیریم.

    قبلاً این تابع سخت‌گیرانه بود: اگه کاربر دقیقاً رو پیامِ سوالِ بات ریپلای
    نمی‌زد (که خیلی‌ها تو گروه اصلاً این کارو نمی‌کنن، مستقیم عدد رو تایپ
    می‌کنن)، بی‌سروصدا هیچ اتفاقی نمی‌افتاد - مثلاً کسی می‌نوشت «3 گیگ نت
    میخوام» و خریدِ اینترنتش بی‌هیچ خطایی رد می‌شد. الان: اگه کاربر اصلاً به
    هیچ پیامی ریپلای نزده باشه (یعنی مستقیم تایپ کرده)، قبولش می‌کنیم. فقط
    وقتی رد می‌کنیم که مشخصاً رو یه پیامِ دیگه (نه پرامپتِ خودِ بات) ریپلای زده
    باشه - چون اون قوی‌ترین نشونه‌ست که پیامش اصلاً جوابِ سوالِ ما نبوده."""
    prompt_id = state.get("_prompt_message_id")
    if not prompt_id:
        return True
    reply = update.message.reply_to_message if update.message else None
    if reply is None:
        return True
    return reply.message_id == prompt_id


async def ask_for_input_reply(update: Update, context: ContextTypes.DEFAULT_TYPE, text: str,
                               state: dict, state_key: str, cancel_callback: str = None):
    """مثلِ ask_for_input، ولی برای وقتی که از داخلِ یه awaiting-handler (یعنی از
    رویِ یه پیامِ متنی، نه دکمه‌ی شیشه‌ای) داریم سوالِ بعدیِ یه فلوی چندمرحله‌ای
    رو می‌پرسیم."""
    if cancel_callback is None:
        cancel_callback = _cancel_callback_for(update)
    kb_rows = [[InlineKeyboardButton(CANCEL_BUTTON_TEXT, callback_data=cancel_callback)]]
    msg = await update.message.reply_text(text, reply_markup=InlineKeyboardMarkup(kb_rows))
    if msg:
        state["_prompt_chat_id"] = msg.chat_id
        state["_prompt_message_id"] = msg.message_id
    context.user_data[state_key] = state


async def clear_prompt_keyboard(context: ContextTypes.DEFAULT_TYPE, state: dict):
    """به‌محضِ اینکه کاربر به یه پرامپت جواب داد (چه معتبر چه نامعتبر)، دکمه‌ی
    «بازگشت/کنسل» زیرِ همون پیامِ پرامپت رو برمی‌داره - چون از این به بعد دیگه
    منطقی نیست (عملیات یا ادامه پیدا کرده یا رد شده)؛ اگه این دکمه دستِ‌نخورده
    می‌موند، هم امکانِ کلیکِ اشتباهیِ بعدی رو می‌داد هم (قبل از قفل‌شدنش به
    کاربر) امکانِ خراب‌کردنِ عملیات توسطِ بقیه‌ی گروه رو."""
    chat_id = state.get("_prompt_chat_id")
    message_id = state.get("_prompt_message_id")
    if not chat_id or not message_id:
        return
    try:
        await context.bot.edit_message_reply_markup(chat_id=chat_id, message_id=message_id, reply_markup=None)
    except Exception:
        pass


async def cb_cancel_any_awaiting(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دکمه‌ی «بازگشت/کنسل» زیرِ هر پرامپتِ ورودی - هر کدوم از حالت‌های منتظرِ
    ورودی (تو هر ماژولی) رو پاک می‌کنه. این دکمه به آیدیِ صاحبِ پرامپت قفله
    (نگاه کن به _cancel_callback_for)؛ اگه یه‌نفرِ دیگه تو گروه روش بزنه، فقط
    یه هشدار می‌بینه و پیام دست‌نخورده می‌مونه - قبلاً هرکسی می‌تونست با زدنِ
    این دکمه، عملیاتِ بازِ یه‌نفرِ دیگه رو (با ادیت‌شدنِ پیام به «لغو شد») خراب
    کنه."""
    data = update.callback_query.data or ""
    parts = data.split(":")
    if len(parts) > 1:
        try:
            owner_id = int(parts[1])
        except ValueError:
            owner_id = None
        if owner_id is not None and update.effective_user.id != owner_id:
            await update.callback_query.answer("🚫 این عملیات مالِ شما نیست.", show_alert=True)
            return
    for key in ("awaiting", "admin_state", "myawy_awaiting", "chef_awaiting", "casino_awaiting", "uno_awaiting", "rr_awaiting", "mf_awaiting", "cards_awaiting", "redeem_awaiting", "bship_awaiting", "gtn_awaiting", "acct_awaiting"):
        context.user_data.pop(key, None)
    await send_response(update, "❌ عملیات لغو شد.", None)


def is_owner(user_id: int) -> bool:
    return config.OWNER_ID and user_id == config.OWNER_ID


def can_access_admin_panel(user_id: int) -> bool:
    """True یعنی این کاربر باید دکمه‌ی «⚙️ پنل مدیریت» رو تو منوی اصلیِ پیوی
    ببینه: یا خودِ مالکِ اصلیه، یا یه ادمینِ فرعیِ ثبت‌شده‌ست (فارغ از اینکه چه
    دسترسی‌ای بهش داده شده - حتی با یه دسترسی هم باید بتونه پنل رو باز کنه،
    چون داخلِ خودِ پنل، admin_menu_keyboard فقط همون دسترسی‌هایی که داره رو
    نشونش می‌ده، نه پنلِ کاملِ مالک را)."""
    if is_owner(user_id):
        return True
    session = db.get_session()
    try:
        return db.is_any_admin(session, user_id)
    finally:
        session.close()


async def _verify_panel_owner(update: Update, owner_id: int) -> bool:
    """چک می‌کنه که کلیک‌کننده‌ی روی دکمه‌ی «هاپ منیج» همون کسیه که پنل مالِ
    اونه (owner_id که تو callback_data قفل شده)؛ اگه نبود، به‌جای اجرای عمل، یه
    هشدار نشون می‌ده و اجازه نمی‌ده کسی از روی پنلِ باز شده‌ی یه نفر دیگه، اکانت
    خودش رو مدیریت کنه."""
    if update.effective_user.id != owner_id:
        await update.callback_query.answer(
            "🚫 این پنل مالِ شما نیست! برای باز کردنِ پنلِ خودت، همون دستور رو "
            "خودت تو گروه بفرست.",
            show_alert=True,
        )
        return False
    return True


# ---------------------------------------------------------------------------
# /start
# ---------------------------------------------------------------------------

def pv_full_menu_allowed(update: Update) -> bool:
    """False یعنی تو پیوی هستیم، پیویِ عمومی خاموشه و کاربر ادمین نیست؛ پس منوی اصلی فقط باید
    «سیو / بازیابی اکانت» رو نشون بده. تو گروه یا وقتی پیوی روشنه (یا کاربر ادمینه) همیشه True."""
    chat = update.effective_chat
    user = update.effective_user
    if not chat or chat.type != "private" or not user:
        return True
    session = db.get_session()
    try:
        if db.is_any_admin(session, user.id):
            return True
        return db.cfg_get(session, "private_chat_enabled") == "1"
    finally:
        session.close()


async def cmd_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        existed_before = session.get(db.User, update.effective_user.id) is not None   # برای «فقط کاربرِ تازه» در دعوت
        db.get_or_create_user(session, update.effective_user)
    finally:
        session.close()
    import referral_ui
    await referral_ui.handle_referral_start(update, context, existed_before)
    if update.effective_chat and update.effective_chat.type != "private" and (getattr(context, "args", None) or [""])[0] == "hopadd":
        await update.message.reply_text(
            "🦘 ربات هاپ تو گروه فعال شد!\n━━━━━━━━━━━━━━\n"
            "بنویس:\n• «هاپ هاپ» ← شروعِ بازی\n• «مأموریت هاپویی» ← مأموریتِ روزانه\n• «دزدی تیمی هاپویی» ← سرقتِ ۴ نفره\n"
            "• «راهنمایی هاپویی» ← همه‌ی بخش‌ها\n\n💡 برای کارکردِ کامل، ربات رو ادمینِ گروه کن.")
        return
    import war_ui  # Deep Link گروه → خصوصی: /start war_<panel>
    if await war_ui.handle_start_deeplink(update, context):
        return
    if not pv_full_menu_allowed(update):
        await update.message.reply_text(
            "🦘 به ربات هاپ خوش اومدی!\n" + ui_style.RULE + "\n"
            "🎮 بازی‌ها تو گروه انجام می‌شن؛ دکمه‌ی «➕ افزودنِ من به گروه» رو بزن و بات رو تو گروهت ادمین کن.\n"
            "🔗 لینک دعوتت رو بگیر و برای هر دوستِ تازه پاداش بگیر.\n"
            "💾 «سیو / بازیابی اکانت» از همین‌جا کار می‌کنه 👇",
            reply_markup=kb.main_private_menu(False, update.effective_user.id, pv_open=False),
        )
        return
    await update.message.reply_text(
        "🦘 به ربات هاپ خوش اومدی!\n" + ui_style.RULE + "\n"
        "➕ منو به گروهت اضافه کن و تو گروه بنویس «هاپ هاپ» تا شروع کنی.\n"
        "🎯 هر روز «مأموریت هاپویی» رو بنویس و جایزه بگیر.\n"
        "🥷 با ۳ دوستت «دزدی تیمی هاپویی» رو امتحان کن.\n"
        "🔗 دوستت رو دعوت کن و هاپ بگیر 👇",
        reply_markup=kb.main_private_menu(can_access_admin_panel(update.effective_user.id), update.effective_user.id),
    )


async def cb_back_main(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not pv_full_menu_allowed(update):
        await send_response(update, "🏠 منوی اصلی:\n(پیویِ ربات برایِ بازی خاموشه؛ فقط سیو/بازیابیِ اکانت فعاله)",
                            kb.main_private_menu(False, update.effective_user.id, pv_open=False))
        return
    await send_response(update, "🏠 منوی اصلی:", kb.main_private_menu(can_access_admin_panel(update.effective_user.id), update.effective_user.id))


async def cb_back_main_owned(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """نسخه‌ی قفل‌شده‌ی «بازگشت» - وقتی از داخلِ پنلِ «هاپ منیج» زده می‌شه، فقط
    صاحبِ همون پنل بتونه ازش استفاده کنه (وگرنه یه نفرِ دیگه با زدنِ بازگشت،
    پیامِ کاربر رو به منوی اصلیِ خودش تغییر می‌داد و باعثِ دخالت/سردرگمی می‌شد)."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await cb_back_main(update, context)


async def cb_hop_hop_owned(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دکمه‌ی «هاپ هاپ» زیرِ نتیجه‌ی هاپِ قبلی - فقط برای همون کسی که خودش
    هاپ کرده کار می‌کنه، نه هر کسی که تو گروه اون پیام رو می‌بینه."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await process_hop(update, context)


async def cb_hop_manage_owned(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دکمه‌ی «هاپ منیج» زیرِ نتیجه‌ی هاپِ قبلی - قفل‌شده به همون کاربر."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_hop_manage(update, context)


async def track_group_chat_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """هر پیامی که تو یه گروه بیاد رو رصد می‌کنه تا بدونیم ربات کجاها فعاله؛
    این فهرست برای اعلامِ «قرعه‌کشیِ سراسری» به همه‌ی گروه‌ها لازمه. هیچ‌وقت
    جلوی هندلرهای بعدی رو نمی‌گیره (ApplicationHandlerStop نمی‌ده)."""
    chat = update.effective_chat
    if not chat or chat.type == "private":
        return
    session = db.get_session()
    try:
        db.track_group_chat(session, chat)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# هاپ هاپ
# ---------------------------------------------------------------------------

async def process_hop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        nowt = datetime.datetime.utcnow()
        if user.last_hop_at:
            elapsed = (nowt - user.last_hop_at).total_seconds()
            if elapsed < config.HOP_COOLDOWN_SECONDS:
                remain = int(config.HOP_COOLDOWN_SECONDS - elapsed)
                m, s = divmod(remain, 60)
                await send_response(
                    update,
                    f"⏳ هنوز زوده! {m} دقیقه و {s} ثانیه دیگه می‌تونی دوباره هاپ کنی.",
                    kb.hop_hop_keyboard(update.effective_user.id),
                )
                return

        reward = random.randint(config.HOP_MIN_REWARD, config.HOP_MAX_REWARD)
        bp_pct = 0.0
        try:
            import battlepass_engine as _bp
            reward, bp_pct = _bp.on_hop(session, user, reward)   # «درصدِ هاپِ بیشتر» (بتل‌پس/ایونت/پریمیوم)
        except Exception:
            logger.exception("battlepass on_hop")
        user.hop_points += reward
        user.hop_count = (user.hop_count or 0) + 1
        user.last_hop_at = nowt
        leveled_up = economy.apply_xp_gain(session, user, reward)
        lvl_up = db.register_hop_for_lvl(user)
        session.commit()

        text = (f"{ui_style.title('🦘', 'هاپ هاپ!!')}\n👤 {mentions.of(update.effective_user)}\n"
                f"✨ +{fmt(reward)} 🪙 هاپ پوینت" + (f"  (🎖 +{bp_pct:g}٪ بتل‌پس)" if bp_pct > 0 else ""))
        if leveled_up:
            text += f"\n🎉 تبریک! رفتی سطح {user.level}!"
        if lvl_up:
            text += f"\n🆙 لولت رفت بالا! لولِ فعلی: {user.lvl}"
        text += (f"\n{ui_style.THIN}\n📈 سطح: {user.level}   🆙 لول: {db.user_lvl(user)}"
                 f"\n💰 موجودی: {fmt(user.hop_points)} 🪙")
        await send_response(update, text, kb.hop_hop_keyboard(update.effective_user.id))
    finally:
        session.close()


async def cb_hop_hop(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await process_hop(update, context)


# ---------------------------------------------------------------------------
# هاپ منیج (کارخونه)
# ---------------------------------------------------------------------------

async def show_hop_manage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        # فقط تولیدِ جدید رو محاسبه و به «منتظرِ برداشت» اضافه می‌کنیم؛ به هاپ پوینت
        # واریز نمی‌شه مگراینکه کاربر خودش دکمه‌ی برداشت رو بزنه
        pending, cap = economy.sync_factory_pending(session, user)
        session.commit()

        total_levels_char = db.cfg_get_int(session, "total_levels")
        rank = economy.current_rank(session, user)
        rank_name = rank.name if rank else "—"
        can_upgrade = not economy.factory_is_maxed(session, user)
        will_advance_rank = economy.factory_can_advance_rank(session, user)
        cost = None if will_advance_rank else (economy.factory_next_upgrade_cost(session, user) if can_upgrade else None)

        prod_mult = economy.factory_production_multiplier(session, user)
        effective_prod = user.production_per_min * prod_mult
        prod_line = f"⚙️ تولید: {fmt(effective_prod)} 🪙 در دقیقه"
        if abs(prod_mult - 1.0) > 0.001:
            prod_line += f" (پایه {fmt(user.production_per_min)} × {fmt(prod_mult)})"

        lines = [
            ui_style.title("🏭", "هاپ منیج") + "\n",
            f"🎖️ مقام: {rank_name} | سطح: {user.factory_level}" + (f"/{rank.num_levels}" if rank else ""),
            prod_line,
            f"📦 منتظرِ برداشت: {fmt(pending)} / {fmt(cap)} 🪙" + (" (پر شده 🧯)" if pending >= cap else ""),
            f"🐕 غذای سگ: {economy.format_minutes(user.dog_food)} از {economy.format_minutes(economy.dog_food_capacity_minutes(session, user))}" + (" - گشنشه، نه تولید می‌کنه نه برداشت می‌تونی بزنی!" if (user.dog_food or 0) <= 0 else ""),
        ]
        if will_advance_rank:
            lines.append("⬆️ به آخرِ سطوحِ این مقام رسیدی - برای رفتن به مقامِ بعد دکمه‌ی ارتقا رو بزن.")
        elif can_upgrade:
            lines.append(f"💵 هزینه‌ی ارتقای سطحِ بعدی: {fmt(cost)} 🪙")
        else:
            lines.append("🏆 به بالاترین سطح و مقام کارخونه رسیدی!")
        lines.append(ui_style.THIN)
        lines.append(f"👤 سطح شخصیت: {user.level}/{total_levels_char}")
        lines.append(f"💰 موجودی: {fmt(user.hop_points)} 🪙")

        await send_response(update, "\n".join(lines), kb.hop_manage_keyboard(can_upgrade, user.telegram_id))
    finally:
        session.close()


async def cb_hop_manage(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_hop_manage(update, context)


async def cb_factory_collect(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """تنها راهِ واریزِ تولیدِ کارخونه به هاپ پوینت؛ هیچ‌جای دیگه‌ای (نه بازکردنِ
    منو، نه جابِ پس‌زمینه) این کار رو خودکار انجام نمی‌ده. سگت باید غذا داشته
    باشه وگرنه این برداشت قفله (باید از «مارکت هاپویی» غذا بخری)."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        # اول همیشه هماهنگ کن (غذا هم اینجا زمانی کم می‌شه) تا چکِ گشنگی بر
        # اساسِ مقدارِ واقعیِ الان باشه، نه مقدارِ کهنه‌ی قبل از این تیک
        economy.sync_factory_pending(session, user)
        if (user.dog_food or 0) <= 0:
            session.commit()
            await send_response(
                update,
                "🐕 سگت گشنشه و نمی‌تونی برداشت کنی! از «مارکت هاپویی» تو گروه براش غذا بخر.",
                kb.hop_manage_keyboard(not economy.factory_is_maxed(session, user), user.telegram_id),
            )
            return
        economy.collect_factory_production(session, user)
        session.commit()
    finally:
        session.close()
    await show_hop_manage(update, context)


async def cb_factory_upgrade(update: Update, context: ContextTypes.DEFAULT_TYPE):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        rank = economy.current_rank(session, user)
        if not rank:
            await send_response(
                update,
                "❌ هنوز هیچ مقامی برای کارخونه تعریف نشده؛ به مالک اطلاع بده.",
                kb.hop_manage_keyboard(False, user.telegram_id),
            )
            return

        if economy.factory_can_advance_rank(session, user):
            # چون رفتن به مقامِ بعد سطح رو به ۱ برمی‌گردونه و تولید ریست می‌شه،
            # اول یه تاییدِ صریح از کاربر می‌گیریم
            economy.sync_factory_pending(session, user)
            session.commit()
            next_rank = economy.get_rank_by_order(session, user.factory_rank_order + 1)
            text = (
                f"⚠️ به آخرین سطحِ مقامِ «{rank.name}» رسیدی!\n"
                f"اگه بری مقامِ بعدی («{next_rank.name}»)، سطحت به ۱ برمی‌گرده و "
                "تولید در دقیقه‌ات ریست می‌شه (از پایین‌ترین مقدارِ مقامِ جدید دوباره "
                "شروع می‌کنی، ولی می‌تونی از اون بالاتر بری).\n\n"
                "مطمئنی می‌خوای بری مقامِ بعد؟"
            )
            await send_response(update, text, kb.factory_rank_confirm_keyboard(user.telegram_id))
            return

        if economy.factory_is_maxed(session, user):
            await send_response(
                update,
                "🏆 کارخونه‌ت به بالاترین سطح و مقام ممکن رسیده؛ فعلا ارتقای بیشتری وجود نداره.",
                kb.hop_manage_keyboard(False, user.telegram_id),
            )
            return

        # ارتقای عادیِ سطح، داخلِ همون مقام
        economy.sync_factory_pending(session, user)
        cost = economy.factory_next_upgrade_cost(session, user)
        if cost is None:
            await send_response(
                update,
                "❌ سطح بعدی تعریف نشده؛ به مالک اطلاع بده.",
                kb.hop_manage_keyboard(False, user.telegram_id),
            )
            return
        if user.hop_points < cost:
            await send_response(
                update,
                f"❌ موجودی کافی نیست! برای ارتقا {fmt(cost)} 🪙 لازمه ولی فقط {fmt(user.hop_points)} 🪙 داری.",
                kb.hop_manage_keyboard(True, user.telegram_id),
            )
            return
        user.hop_points -= cost
        economy.factory_upgrade_level(session, user)
        session.commit()

        can_upgrade_now = not economy.factory_is_maxed(session, user)
        prod_mult = economy.factory_production_multiplier(session, user)
        await send_response(
            update,
            f"✅ کارخونه ارتقا یافت! سطح جدید: {user.factory_level}/{rank.num_levels} ({rank.name})\n"
            f"🏭 تولید: {fmt(user.production_per_min * prod_mult)} 🪙 در دقیقه\n"
            f"📦 ظرفیت: {fmt(economy.factory_capacity(session, user))} 🪙",
            kb.hop_manage_keyboard(can_upgrade_now, user.telegram_id),
        )
    finally:
        session.close()


async def cb_factory_rank_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if not economy.factory_can_advance_rank(session, user):
            await send_response(update, "❌ الان امکانِ رفتن به مقامِ بعد نیست.", kb.hop_manage_keyboard(False, user.telegram_id))
            return
        economy.factory_advance_rank(session, user)
        session.commit()
        new_rank = economy.current_rank(session, user)
        can_upgrade_now = not economy.factory_is_maxed(session, user)
        prod_mult = economy.factory_production_multiplier(session, user)
        await send_response(
            update,
            f"🎉 تبریک! به مقام «{new_rank.name}» رسیدی!\n"
            f"🏭 تولید از سطح ۱ این مقام دوباره شروع شد: {fmt(user.production_per_min * prod_mult)} 🪙 در دقیقه",
            kb.hop_manage_keyboard(can_upgrade_now, user.telegram_id),
        )
    finally:
        session.close()


async def cb_factory_rank_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_hop_manage(update, context)


# ---------------------------------------------------------------------------
# تغییر اسم سگ (نام مستعار برای صدا زدن منو به‌جای «هاپ منیج»)
# ---------------------------------------------------------------------------

RESERVED_TRIGGER_WORDS = {
    "هاپ هاپ", "هاپ‌هاپ", "هاپ", "هاپ منیج", "قرعه کشی هاپ",
    "ارز هاپ", "کازینو هاپویی", "لیگ برتر", "هاپ هام", "هاپ هاش", "گوشی هاپویی",
    "رای گیری هاپویی", "مارکت هاپویی", "تاکسی هاپویی", "کارت هاپویی", "کد جایزه هاپویی",
    "پنل حمله", "قاچاق هاپویی",
}


async def _show_hop_stats_for(update: Update, context: ContextTypes.DEFAULT_TYPE, target_tg_user):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, target_tg_user)
        rank = economy.current_rank(session, user)
        rank_line = f"{rank.name} (سطح {user.factory_level}/{rank.num_levels})" if rank else f"سطح {user.factory_level}"
        text = (
            f"📋 آمارِ {user.display_name()}\n\n"
            f"🪙 هاپ پوینت: {fmt(user.hop_points)}\n"
            f"🦘 تعداد هاپ‌هاپ: {fmt(user.hop_count)} بار\n"
            f"🆙 لول: {db.user_lvl(user)}/{db.MAX_LVL}\n"
            f"🎖️ مقامِ کارخونه: {rank_line}"
        )
        await update.message.reply_text(text)
    finally:
        session.close()


async def show_my_hop_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """با تایپِ «هاپ هام» تو هر گروهی، ریپلای می‌کنه: هاپ پوینت، تعداد دفعاتِ
    هاپ‌هاپ، و مقامِ کارخونه‌ی خودِ فرستنده."""
    await _show_hop_stats_for(update, context, update.effective_user)


async def show_other_hop_stats(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """با ریپلای‌کردن رو پیامِ یه نفرِ دیگه و تایپِ «هاپ هاش»، همون آمار رو برای
    طرفِ ریپلای‌شده نشون می‌ده، نه خودِ فرستنده."""
    reply = update.message.reply_to_message
    if not reply or not reply.from_user:
        await update.message.reply_text(
            "❌ برای دیدنِ هاپِ یه نفرِ دیگه، باید رو پیامِ خودش ریپلای بزنی و «هاپ هاش» رو بنویسی."
        )
        return
    target = reply.from_user
    if target.is_bot:
        await update.message.reply_text("❌ نمی‌شه آمارِ یه بات رو دید.")
        return
    await _show_hop_stats_for(update, context, target)


async def cb_cat_name_ask(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(
        update, context,
        "🐕 اسم دلخواه‌ت رو برای سگ بفرست (بعد از این می‌تونی به‌جای «هاپ منیج» "
        "همین اسم رو صدا بزنی تا منو باز شه):",
        {"type": "cat_name"}, "awaiting",
    )


# ---------------------------------------------------------------------------
# سوپرمارکت
# ---------------------------------------------------------------------------

async def show_market(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if not user.has_supermarket:
            cost = db.cfg_get_float(session, "supermarket_open_cost")
            text = (
                "🛒 سوپرمارکت\n\n"
                f"هنوز سوپرمارکت نساختی. هزینه‌ی ساخت: {fmt(cost)} 🪙\n"
                "بعد از ساخت می‌تونی سرعت تولید رو بالا ببری و "
                "🐱 گوشت گربه، 🥒 دارچین خیار، 🍌 موز و 🥚 تخم سگ تولید و با قیمت روز بفروشی."
            )
            await send_response(update, text, kb.market_keyboard(False, update.effective_user.id))
            return

        gained = economy.collect_supermarket_production(session, user)
        session.commit()
        p_cat = db.cfg_get_float(session, "price_cat_meat")
        p_cin = db.cfg_get_float(session, "price_cinnamon_cucumber")
        p_ban = db.cfg_get_float(session, "price_banana")
        p_egg = db.cfg_get_float(session, "price_dog_egg")
        upgrade_cost = economy.supermarket_upgrade_cost(session, user.supermarket_level)
        threshold = db.cfg_get_float(session, "market_produce_per_level")

        lines = [
            f"🛒 سوپرمارکت من (سطح ارتقا: {user.supermarket_level} | سطح محصولات: {user.market_product_level})\n",
            f"⚙️ سرعت تولید: {fmt(user.supermarket_prod_per_hour)} کالا در ساعت",
            f"📥 از آخرین بار: +{fmt(gained)} کالا جمع شد",
            f"📈 تا سطح محصولات بعدی: {fmt(user.market_produce_progress)}/{fmt(threshold)}\n",
            f"🐱 گوشت گربه: {fmt(user.cat_meat)} (قیمت روز: {fmt(p_cat)} 🪙)",
            f"🥒 دارچین خیار: {fmt(user.cinnamon_cucumber)} (قیمت روز: {fmt(p_cin)} 🪙)",
            f"🍌 موز: {fmt(user.banana)} (قیمت روز: {fmt(p_ban)} 🪙)",
            f"🥚 تخم سگ: {fmt(user.dog_egg)} (قیمت روز: {fmt(p_egg)} 🪙)",
        ]
        # محصولات دینامیکی‌ای که مالک از پنل تعریف کرده و برای این کاربر باز شدن
        for prod in economy.unlocked_dynamic_products(session, user):
            up = session.query(db.UserProduct).filter_by(user_id=user.telegram_id, product_id=prod.id).first()
            amount = up.amount if up else 0
            lines.append(f"{prod.emoji} {prod.name}: {fmt(amount)} (قیمت روز: {fmt(prod.daily_price)} 🪙)")

        lines.append(f"\n⬆️ ارتقای بعدی سرعت تولید: {fmt(upgrade_cost)} 🪙")
        lines.append(f"💰 موجودی: {fmt(user.hop_points)} 🪙")
        await send_response(update, "\n".join(lines), kb.market_keyboard(True, update.effective_user.id))
    finally:
        session.close()


async def cb_market_open_owned(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_market(update, context)


async def cb_market_buy(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        cost = db.cfg_get_float(session, "supermarket_open_cost")
        if user.has_supermarket:
            await send_response(update, "قبلا سوپرمارکت ساختی 🙂", kb.market_keyboard(True, owner_id))
            return
        if user.hop_points < cost:
            await send_response(update, f"❌ موجودی کافی نیست! {fmt(cost)} 🪙 لازمه.", kb.market_keyboard(False, owner_id))
            return
        user.hop_points -= cost
        user.has_supermarket = True
        user.supermarket_prod_per_hour = 0
        user.last_market_collect_at = datetime.datetime.utcnow()
        session.commit()
        await send_response(update, "✅ سوپرمارکت ساخته شد! حالا می‌تونی سرعت تولید رو ارتقا بدی.", kb.market_keyboard(True, owner_id))
    finally:
        session.close()


async def cb_market_upgrade(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        economy.collect_supermarket_production(session, user)
        cost = economy.supermarket_upgrade_cost(session, user.supermarket_level)
        if user.hop_points < cost:
            await send_response(update, f"❌ موجودی کافی نیست! {fmt(cost)} 🪙 لازمه.", kb.market_keyboard(True, owner_id))
            return
        user.hop_points -= cost
        user.supermarket_level += 1
        inc = db.cfg_get_float(session, "supermarket_prod_increment")
        user.supermarket_prod_per_hour += inc
        session.commit()
        await send_response(update, f"✅ سرعت تولید سوپرمارکت ارتقا یافت! سرعت جدید: {fmt(user.supermarket_prod_per_hour)}/ساعت", kb.market_keyboard(True, owner_id))
    finally:
        session.close()


async def cb_market_collect(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_market(update, context)


async def cb_market_sell_all(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        economy.collect_supermarket_production(session, user)
        p_cat = db.cfg_get_float(session, "price_cat_meat")
        p_cin = db.cfg_get_float(session, "price_cinnamon_cucumber")
        p_ban = db.cfg_get_float(session, "price_banana")
        p_egg = db.cfg_get_float(session, "price_dog_egg")
        total = (user.cat_meat * p_cat + user.cinnamon_cucumber * p_cin +
                 user.banana * p_ban + user.dog_egg * p_egg)
        user.cat_meat = 0
        user.cinnamon_cucumber = 0
        user.banana = 0
        user.dog_egg = 0

        for prod in economy.unlocked_dynamic_products(session, user):
            up = session.query(db.UserProduct).filter_by(user_id=user.telegram_id, product_id=prod.id).first()
            if up and up.amount:
                total += up.amount * prod.daily_price
                up.amount = 0

        total *= economy.money_income_multiplier(session, user)
        user.hop_points += total
        session.commit()
        await send_response(update, f"💵 همه‌ی محصولات فروخته شد! +{fmt(total)} 🪙", kb.market_keyboard(True, owner_id))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# بانک هاپویی
# ---------------------------------------------------------------------------

async def show_bank(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if not user.has_bank:
            cost = db.cfg_get_float(session, "bank_open_cost")
            cap = db.cfg_get_float(session, "bank_interest_cap")
            text = (
                "🏦 بانک هاپویی\n\n"
                f"هنوز حساب بانکی نداری. هزینه‌ی افتتاح: {fmt(cost)} 🪙\n"
                f"بعد از افتتاح، هر هاپ پوینتی که واریز کنی هر روز ساعتِ ۹ صبح "
                f"{fmt(db.cfg_get_float(session,'bank_daily_interest_pct'))}٪ سود می‌ده"
                + (f" (فقط تا سقفِ {fmt(cap)} 🪙 از بالانس)." if cap and cap > 0 else ".")
            )
            await send_response(update, text, kb.bank_keyboard(False, update.effective_user.id))
            return
        gained = economy.apply_bank_interest_if_due(session, user)
        session.commit()
        pct = db.cfg_get_float(session, "bank_daily_interest_pct")
        cap = db.cfg_get_float(session, "bank_interest_cap")
        text = (
            "🏦 بانک هاپویی\n\n"
            f"💼 موجودی سپرده: {fmt(user.bank_balance)} 🪙\n"
            f"📈 نرخ سود روزانه (ساعت ۹ صبح): {fmt(pct)}٪\n"
        )
        if cap and cap > 0:
            text += f"🧢 سقفِ مشمولِ سود: {fmt(cap)} 🪙 (مازادش سود نمی‌گیره)\n"
        if gained:
            text += f"🎁 سود جدید اضافه شد: +{fmt(gained)} 🪙\n"
        if user.bank_last_interest_amount and user.bank_last_interest_at:
            text += (
                f"🗓 آخرین سودِ بانک: {fmt(user.bank_last_interest_amount)} 🪙 "
                f"در تاریخِ {user.bank_last_interest_at.strftime('%Y-%m-%d %H:%M')} (UTC)\n"
            )
        text += f"\n💰 موجودی نقدی: {fmt(user.hop_points)} 🪙"
        text += (
            "\n\nℹ️ همچنین می‌تونی مستقیم بنویسی «واریز <مقدار>» یا «واریز همه»، "
            "و «برداشت <مقدار>» یا «برداشت همه»."
        )
        await send_response(update, text, kb.bank_keyboard(True, update.effective_user.id))
    finally:
        session.close()


async def cb_bank_open_owned(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_bank(update, context)


async def cb_bank_create(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        cost = db.cfg_get_float(session, "bank_open_cost")
        if user.has_bank:
            await send_response(update, "قبلا بانک داشتی 🙂", kb.bank_keyboard(True, owner_id))
            return
        if user.hop_points < cost:
            await send_response(update, f"❌ موجودی کافی نیست! {fmt(cost)} 🪙 لازمه.", kb.bank_keyboard(False, owner_id))
            return
        user.hop_points -= cost
        user.has_bank = True
        user.bank_last_interest_at = datetime.datetime.utcnow()
        session.commit()
        await send_response(update, "✅ حساب بانکی افتتاح شد!", kb.bank_keyboard(True, owner_id))
    finally:
        session.close()


async def cb_bank_deposit_ask(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(update, context, "📥 چند تا هاپ پوینت می‌خوای واریز کنی؟ عدد رو بفرست.", {"type": "bank_deposit"}, "awaiting")


async def cb_bank_withdraw_ask(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(update, context, "📤 چند تا هاپ پوینت می‌خوای از بانک برداشت کنی؟ عدد رو بفرست.", {"type": "bank_withdraw"}, "awaiting")


BANK_DEPOSIT_TRIGGER = "واریز"
BANK_WITHDRAW_TRIGGER = "برداشت"
_BANK_ALL_WORDS = {"همه", "همش", "هم", "کل", "کلش", "کلا"}


async def _handle_bank_command(update: Update, context: ContextTypes.DEFAULT_TYPE, normalized: str) -> bool:
    """واریز/برداشتِ مستقیم به بانکِ هاپویی با نوشتنِ متن (بدونِ نیاز به بازکردنِ
    پنلِ بانک/دکمه‌ها): «واریز <مقدار>» یا «واریز همه» (کلِ نقدیِ بیرون از
    بانک)، و «برداشت <مقدار>» یا «برداشت همه» (کلِ موجودیِ بانک - یعنی سقفِ
    برداشت با این دستور همیشه دقیقاً همون چیزیه که تو بانک داری). مقدار می‌تونه
    با کوتاه‌نویسیِ رایج (k/m/b یا کا/میل/میلیارد و...) هم نوشته بشه، چون از
    همون parse_amount استفاده می‌کنیم. اگه مقدارِ بعدِ کلمه، نه یه عددِ معتبره
    نه یکی از کلماتِ «همه»، اصلاً دخالت نمی‌کنیم - چون ممکنه کاربر داشته یه
    جمله‌ی عادیِ گروه می‌نوشته که تصادفاً با همین کلمه شروع می‌شده."""
    if normalized == BANK_DEPOSIT_TRIGGER or normalized.startswith(BANK_DEPOSIT_TRIGGER + " "):
        kind = "deposit"
        rest = normalized[len(BANK_DEPOSIT_TRIGGER):].strip()
    elif normalized == BANK_WITHDRAW_TRIGGER or normalized.startswith(BANK_WITHDRAW_TRIGGER + " "):
        kind = "withdraw"
        rest = normalized[len(BANK_WITHDRAW_TRIGGER):].strip()
    else:
        return False

    is_all = rest in _BANK_ALL_WORDS
    parsed_amount = None if is_all else parse_amount(rest)
    if not is_all and parsed_amount is None:
        return False  # به‌احتمالِ زیاد یه پیامِ عادیِ نامربوطه؛ کاری نداشته باشیم

    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        gate_error = db.check_module_level(session, user, "bank")
        if gate_error:
            await update.message.reply_text(gate_error)
            return True
        if not user.has_bank:
            await update.message.reply_text("❌ هنوز حساب بانکی نداری؛ اول از «هاپ منیج» بانک هاپویی رو باز کن.")
            return True

        economy.apply_bank_interest_if_due(session, user)

        if kind == "deposit":
            amount = user.hop_points if is_all else parsed_amount
            if amount <= 0:
                await update.message.reply_text("❌ نقدیِ بیرون از بانک نداری برای واریز.")
                return True
            if user.hop_points < amount - 0.5:
                await update.message.reply_text(
                    f"❌ شما پول کافی برای ثبتِ این واریز را ندارید! (نقدی: {fmt(user.hop_points)} 🪙)"
                )
                return True
            user.hop_points = round(user.hop_points - amount)
            user.bank_balance = round(user.bank_balance + amount)
            session.commit()
            await update.message.reply_text(f"✅ {fmt(amount)} 🪙 واریز شد. موجودی بانک: {fmt(user.bank_balance)} 🪙")
        else:
            amount = user.bank_balance if is_all else parsed_amount
            if amount <= 0:
                await update.message.reply_text("❌ موجودیِ بانکت صفره.")
                return True
            if user.bank_balance < amount - 0.5:
                await update.message.reply_text(
                    f"❌ شما پول کافی برای ثبتِ این برداشت را ندارید! (موجودی بانک: {fmt(user.bank_balance)} 🪙)"
                )
                return True
            user.bank_balance = round(user.bank_balance - amount)
            user.hop_points = round(user.hop_points + amount)
            session.commit()
            await update.message.reply_text(f"✅ {fmt(amount)} 🪙 برداشت شد. موجودی نقدی: {fmt(user.hop_points)} 🪙")
    finally:
        session.close()
    return True


# ---------------------------------------------------------------------------
# ارز دیجیتال
# ---------------------------------------------------------------------------

async def show_crypto_list(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        # چک سبک: اگه بروزرسانی خودکار روشنه و زمانش رسیده، همینجا قیمت‌ها رو
        # عوض می‌کنیم - این‌طوری حتی اگه جاب پس‌زمینه به هر دلیلی اجرا نشه،
        # با باز کردن لیست ارزها قیمت‌ها قطعا آپدیت می‌شن.
        await economy.tick_crypto_prices(session, context)
        session.commit()
        currencies = session.query(db.Currency).all()
        owner_id = update.effective_user.id
        if not currencies:
            await send_response(update, "💱 فعلا هیچ ارزی توسط مالک تعریف نشده.", kb.main_private_menu(can_access_admin_panel(owner_id), owner_id))
            return
        await send_response(update, "💱 لیست ارزهای هاپ:", kb.crypto_list_keyboard(currencies, owner_id))
    finally:
        session.close()


async def cb_crypto_open_owned(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_crypto_list(update, context)


async def cb_crypto_view(update, context):
    _, currency_id, owner_id = update.callback_query.data.split(":")
    currency_id, owner_id = int(currency_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        await economy.tick_crypto_prices(session, context)
        session.commit()
        c = session.get(db.Currency, currency_id)
        if not c:
            await send_response(update, "این ارز دیگه وجود نداره.", kb.main_private_menu(can_access_admin_panel(owner_id), owner_id))
            return
        user = db.get_or_create_user(session, update.effective_user)
        uc = session.query(db.UserCurrency).filter_by(user_id=user.telegram_id, currency_id=c.id).first()
        owned = uc.amount if uc else 0
        text = (
            f"{c.emoji} {c.name}\n\n"
            f"🟢 قیمت خرید: {fmt(c.buy_price)} 🪙\n"
            f"🔴 قیمت فروش: {fmt(c.sell_price)} 🪙\n"
            f"📦 موجودی تو: {fmt(owned)} {c.name}\n"
            f"💰 هاپ پوینت تو: {fmt(user.hop_points)} 🪙"
        )
        await send_response(update, text, kb.crypto_action_keyboard(c.id, owner_id))
    finally:
        session.close()


async def cb_crypto_buy_ask(update, context):
    _, currency_id, owner_id = update.callback_query.data.split(":")
    currency_id, owner_id = int(currency_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(update, context, "🟢 چند واحد می‌خوای بخری؟ عدد رو بفرست.", {"type": "crypto_buy", "currency_id": currency_id}, "awaiting")


async def cb_crypto_sell_ask(update, context):
    _, currency_id, owner_id = update.callback_query.data.split(":")
    currency_id, owner_id = int(currency_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(update, context, "🔴 چند واحد می‌خوای بفروشی؟ عدد رو بفرست.", {"type": "crypto_sell", "currency_id": currency_id}, "awaiting")


# ---------------------------------------------------------------------------
# آلارمِ قیمتِ ارز (یک‌بارمصرف)
# ---------------------------------------------------------------------------

async def cb_crypto_alarm_menu(update, context):
    _, currency_id, owner_id = update.callback_query.data.split(":")
    currency_id, owner_id = int(currency_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        c = session.get(db.Currency, currency_id)
        if not c:
            await update.callback_query.answer("این ارز دیگه وجود نداره.", show_alert=True)
            return
        alarms = session.query(db.CurrencyAlarm).filter_by(user_id=owner_id, currency_id=currency_id).order_by(db.CurrencyAlarm.target_price).all()
        lines = [f"🔔 آلارم‌های {c.emoji} {c.name}\n", f"💰 قیمتِ الان: {fmt(c.buy_price)} 🪙\n"]
        if alarms:
            lines.append("آلارم‌های فعال (بزن رو یکی تا حذفش کنی):")
        else:
            lines.append("هنوز آلارمی نساختی.")
        lines.append("\nℹ️ هر آلارم یک‌بارمصرفه: وقتی قیمت بهش برسه، بهت پیام می‌دم و خودش حذف می‌شه.")
        await send_response(update, "\n".join(lines), kb.crypto_alarm_menu_keyboard(alarms, currency_id, owner_id))
    finally:
        session.close()


async def cb_crypto_alarm_add(update, context):
    _, currency_id, owner_id = update.callback_query.data.split(":")
    currency_id, owner_id = int(currency_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        c = session.get(db.Currency, currency_id)
        if not c:
            await update.callback_query.answer("این ارز دیگه وجود نداره.", show_alert=True)
            return
        text = f"🔔 قیمتِ هدف رو بفرست (قیمتِ الان: {fmt(c.buy_price)} 🪙):"
    finally:
        session.close()
    await ask_for_input(update, context, text, {"type": "alarm_price", "currency_id": currency_id}, "awaiting")


async def cb_crypto_alarm_del(update, context):
    _, alarm_id, owner_id = update.callback_query.data.split(":")
    alarm_id, owner_id = int(alarm_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        a = session.get(db.CurrencyAlarm, alarm_id)
        if not a or a.user_id != owner_id:
            await update.callback_query.answer("این آلارم پیدا نشد.", show_alert=True)
            return
        currency_id = a.currency_id
        session.delete(a)
        session.commit()
        alarms = session.query(db.CurrencyAlarm).filter_by(user_id=owner_id, currency_id=currency_id).order_by(db.CurrencyAlarm.target_price).all()
        c = session.get(db.Currency, currency_id)
        await update.callback_query.answer("🗑 حذف شد.")
        lines = [f"🔔 آلارم‌های {c.emoji} {c.name}\n", f"💰 قیمتِ الان: {fmt(c.buy_price)} 🪙\n"]
        lines.append("آلارم‌های فعال (بزن رو یکی تا حذفش کنی):" if alarms else "هنوز آلارمی نساختی.")
        await send_response(update, "\n".join(lines), kb.crypto_alarm_menu_keyboard(alarms, currency_id, owner_id))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# سفارشِ خرید/فروشِ ارز با قیمتِ هدف (Limit Order)
# ---------------------------------------------------------------------------

async def cb_crypto_order_menu(update, context):
    _, currency_id, owner_id = update.callback_query.data.split(":")
    currency_id, owner_id = int(currency_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        c = session.get(db.Currency, currency_id)
        if not c:
            await update.callback_query.answer("این ارز دیگه وجود نداره.", show_alert=True)
            return
        orders = session.query(db.CurrencyOrder).filter_by(user_id=owner_id, currency_id=currency_id, status="pending").all()
        lines = [
            f"📋 سفارش‌های {c.emoji} {c.name}\n",
            f"💰 قیمتِ الان: {fmt(c.buy_price)} 🪙\n",
            "ℹ️ سفارشِ خرید وقتی قیمت به هدف *برسه یا پایین‌تر* بیاد پر می‌شه؛ "
            "سفارشِ فروش وقتی قیمت به هدف *برسه یا بالاتر* بره. پول/ارز موقعِ ثبتِ سفارش رزرو می‌شه.",
        ]
        if orders:
            lines.append("\nسفارش‌های بازِ تو (بزن رو یکی تا لغوش کنی):")
        else:
            lines.append("\nسفارشِ بازی نداری.")
        await send_response(update, "\n".join(lines), kb.crypto_order_menu_keyboard(orders, currency_id, owner_id))
    finally:
        session.close()


async def cb_crypto_order_buy_ask(update, context):
    _, currency_id, owner_id = update.callback_query.data.split(":")
    currency_id, owner_id = int(currency_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        c = session.get(db.Currency, currency_id)
        if not c:
            await update.callback_query.answer("این ارز دیگه وجود نداره.", show_alert=True)
            return
        text = f"📋 سفارشِ خرید - قیمتِ هدف رو بفرست (قیمتِ الان: {fmt(c.buy_price)} 🪙):"
    finally:
        session.close()
    await ask_for_input(update, context, text, {"type": "order_price", "currency_id": currency_id, "kind": "buy"}, "awaiting")


async def cb_crypto_order_sell_ask(update, context):
    _, currency_id, owner_id = update.callback_query.data.split(":")
    currency_id, owner_id = int(currency_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        c = session.get(db.Currency, currency_id)
        if not c:
            await update.callback_query.answer("این ارز دیگه وجود نداره.", show_alert=True)
            return
        text = f"📋 سفارشِ فروش - قیمتِ هدف رو بفرست (قیمتِ الان: {fmt(c.buy_price)} 🪙):"
    finally:
        session.close()
    await ask_for_input(update, context, text, {"type": "order_price", "currency_id": currency_id, "kind": "sell"}, "awaiting")


async def cb_crypto_order_cancel(update, context):
    _, order_id, owner_id = update.callback_query.data.split(":")
    order_id, owner_id = int(order_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        o = session.get(db.CurrencyOrder, order_id)
        if not o or o.user_id != owner_id or o.status != "pending":
            await update.callback_query.answer("این سفارش دیگه فعال نیست.", show_alert=True)
            return
        currency_id = o.currency_id
        u = session.get(db.User, owner_id)
        if o.kind == "buy":
            # پولی که موقعِ ثبت رزرو شده بود رو برگردون
            if u:
                u.hop_points = round(u.hop_points + o.target_price * o.quantity)
        else:
            # ارزی که موقعِ ثبت رزرو شده بود رو برگردون
            uc = session.query(db.UserCurrency).filter_by(user_id=owner_id, currency_id=currency_id).first()
            if not uc:
                uc = db.UserCurrency(user_id=owner_id, currency_id=currency_id, amount=0)
                session.add(uc)
            uc.amount += o.quantity
        o.status = "cancelled"
        session.commit()
        await update.callback_query.answer("✅ سفارش لغو شد و رزروش برگشت.")
        c = session.get(db.Currency, currency_id)
        orders = session.query(db.CurrencyOrder).filter_by(user_id=owner_id, currency_id=currency_id, status="pending").all()
        lines = [f"📋 سفارش‌های {c.emoji} {c.name}\n", f"💰 قیمتِ الان: {fmt(c.buy_price)} 🪙\n"]
        lines.append("سفارش‌های بازِ تو (بزن رو یکی تا لغوش کنی):" if orders else "سفارشِ بازی نداری.")
        await send_response(update, "\n".join(lines), kb.crypto_order_menu_keyboard(orders, currency_id, owner_id))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# ولتِ ارز دیجیتال (ساختن ولت + انتقالِ ارز بینِ کاربرها با آدرسِ ولت)
# ---------------------------------------------------------------------------

def _generate_wallet_address() -> str:
    return "HOP" + secrets.token_hex(8).upper()


async def cb_wallet_open(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        cost = db.cfg_get_float(session, "wallet_cost")
        if user.wallet_address:
            text = f"💼 ولتِ تو\n\n📬 آدرس: {user.wallet_address}\n\nاین آدرس رو به دوستات بده تا بتونن ارز برات بفرستن."
        else:
            text = f"💼 هنوز ولت نداری.\n\nهزینه‌ی ساختِ ولت: {fmt(cost)} 🪙"
        await send_response(update, text, kb.wallet_menu_keyboard(owner_id, bool(user.wallet_address)))
    finally:
        session.close()


async def cb_wallet_buy(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if user.wallet_address:
            await send_response(update, "قبلا ولت ساختی 🙂", kb.wallet_menu_keyboard(owner_id, True))
            return
        cost = db.cfg_get_float(session, "wallet_cost")
        if user.hop_points < cost:
            await send_response(update, f"❌ موجودی کافی نیست! {fmt(cost)} 🪙 لازمه.", kb.wallet_menu_keyboard(owner_id, False))
            return
        user.hop_points -= cost
        # آدرس با گشتنِ تصادفی تا یکتا بودنش (احتمالِ برخورد عملاً صفره، ولی
        # این‌طوری قطعیه) تولید می‌شه
        address = _generate_wallet_address()
        while session.query(db.User).filter_by(wallet_address=address).first():
            address = _generate_wallet_address()
        user.wallet_address = address
        session.commit()
        await send_response(
            update,
            f"✅ ولتت ساخته شد!\n\n📬 آدرس: {address}\n\nاین آدرس رو به دوستات بده تا بتونن ارز برات بفرستن.",
            kb.wallet_menu_keyboard(owner_id, True),
        )
    finally:
        session.close()


async def cb_wallet_transfer_ask(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if not user.wallet_address:
            await send_response(update, "❌ اول باید ولت بسازی.", kb.wallet_menu_keyboard(owner_id, False))
            return
    finally:
        session.close()
    await ask_for_input(update, context, "📬 آدرسِ ولتِ دوستت رو بفرست:", {"type": "wallet_transfer_address"}, "awaiting")


async def cb_wallet_pick_currency(update, context):
    _, currency_id, target_user_id, owner_id = update.callback_query.data.split(":")
    currency_id, target_user_id, owner_id = int(currency_id), int(target_user_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        c = session.get(db.Currency, currency_id)
        if not c:
            await send_response(update, "این ارز دیگه وجود نداره.", kb.wallet_menu_keyboard(owner_id, True))
            return
    finally:
        session.close()
    await ask_for_input(
        update, context, f"🔢 چند تا {c.name} می‌خوای بفرستی؟ عدد رو بفرست.",
        {"type": "wallet_transfer_amount", "currency_id": currency_id, "target_user_id": target_user_id}, "awaiting",
    )


async def cb_wallet_confirm(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    pending = context.user_data.get("wallet_pending_transfer")
    if not pending:
        await send_response(update, "❌ چیزی برای تایید نیست؛ دوباره از اول شروع کن.", kb.wallet_menu_keyboard(owner_id, True))
        return
    session = db.get_session()
    try:
        sender = db.get_or_create_user(session, update.effective_user)
        target = session.get(db.User, pending["target_user_id"])
        c = session.get(db.Currency, pending["currency_id"])
        amount = pending["amount"]
        if not target or not c:
            await send_response(update, "❌ این تراکنش دیگه معتبر نیست.", kb.wallet_menu_keyboard(owner_id, True))
            context.user_data.pop("wallet_pending_transfer", None)
            return
        sender_uc = session.query(db.UserCurrency).filter_by(user_id=sender.telegram_id, currency_id=c.id).first()
        owned = sender_uc.amount if sender_uc else 0
        if owned < amount:
            await send_response(update, f"❌ موجودی کافی نیست! (داری: {fmt(owned)} {c.name})", kb.wallet_menu_keyboard(owner_id, True))
            context.user_data.pop("wallet_pending_transfer", None)
            return
        sender_uc.amount -= amount
        target_uc = session.query(db.UserCurrency).filter_by(user_id=target.telegram_id, currency_id=c.id).first()
        if not target_uc:
            target_uc = db.UserCurrency(user_id=target.telegram_id, currency_id=c.id, amount=0)
            session.add(target_uc)
        target_uc.amount += amount
        session.commit()
        context.user_data.pop("wallet_pending_transfer", None)
        await send_response(
            update,
            f"✅ {fmt(amount)} {c.name} به ولتِ {target.display_name()} فرستاده شد!",
            kb.wallet_menu_keyboard(owner_id, True),
        )
        try:
            await context.bot.send_message(target.telegram_id, f"📬 {fmt(amount)} {c.name} از {sender.display_name()} به ولتت رسید!")
        except Exception:
            pass
    finally:
        session.close()


# ---------------------------------------------------------------------------
# پروفایل
# ---------------------------------------------------------------------------

async def cb_profile_open_owned(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        # فقط سینک می‌کنیم تا اعداد به‌روز باشن؛ برداشتِ واقعی فقط با دکمه‌ی
        # «برداشت تولید» تو هاپ منیج انجام می‌شه، نه با بازکردنِ پروفایل
        economy.sync_factory_pending(session, user)
        session.commit()
        total_levels = db.cfg_get_int(session, "total_levels")
        need = economy.xp_required_for_level(session, user.level) if user.level < total_levels else 0
        rank = economy.current_rank(session, user)
        rank_line = f"{rank.name} - سطح {user.factory_level}/{rank.num_levels}" if rank else f"سطح {user.factory_level}"
        prod_mult = economy.factory_production_multiplier(session, user)
        text = (
            f"📊 پروفایل {user.display_name()}\n\n"
            f"👤 سطح: {user.level}/{total_levels}\n"
            f"✨ تجربه: {fmt(user.xp)}/{fmt(need) if need else '—'}\n"
            f"💰 هاپ پوینت: {fmt(user.hop_points)} 🪙\n"
            f"🏭 تولید: {fmt(user.production_per_min * prod_mult)}/دقیقه ({rank_line})\n"
            f"📦 منتظرِ برداشت در کارخونه: {fmt(user.factory_pending)} 🪙\n"
            f"🛒 سوپرمارکت: {'دارد ✅' if user.has_supermarket else 'ندارد ❌'}\n"
            + (f"🏦 بانک: {fmt(user.bank_balance)} 🪙" if user.has_bank else "🏦 بانک: ندارد ❌")
        )
        await send_response(update, text, kb.main_private_menu(can_access_admin_panel(owner_id), owner_id))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# لیگ برتر (لیدربورد هاپ هاپ و هاپ پوینت)
# ---------------------------------------------------------------------------

RANK_EMOJI = ["🥇", "🥈", "🥉"]


def _rank_prefix(i):
    return RANK_EMOJI[i] if i < len(RANK_EMOJI) else f"{i + 1}."


async def show_league_menu(update: Update, context: ContextTypes.DEFAULT_TYPE, owner_id: int):
    await send_response(
        update,
        "🏆 لیگ برتر هاپ\n\nیکی از لیدربوردها رو ببین 👇",
        kb.league_menu_keyboard(owner_id),
    )


async def cb_league_menu(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_league_menu(update, context, owner_id)


async def cb_league_hops(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        top = (
            session.query(db.User)
            .filter(db.User.hop_count > 0)
            .order_by(db.User.hop_count.desc())
            .limit(10)
            .all()
        )
        viewer = db.get_or_create_user(session, update.effective_user)
        my_rank = session.query(db.User).filter(db.User.hop_count > viewer.hop_count).count() + 1
        if not top:
            text = "🏆 لیدربورد هاپ هاپ\n\nهنوز کسی هاپ هاپ نکرده! 🦘"
        else:
            lines = ["🏆 لیدربورد هاپ هاپ (پرافتخارترین هاپرها)\n"]
            for i, u in enumerate(top):
                lines.append(f"{_rank_prefix(i)} {u.display_name()} — {fmt(u.hop_count)} بار 🦘")
            text = "\n".join(lines)
        text += f"\n\n📍 رتبه‌ی شما: {my_rank}"
        await send_response(update, text, kb.league_result_keyboard(owner_id))
    finally:
        session.close()


async def cb_league_points(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        top = session.query(db.User).order_by(db.User.hop_points.desc()).limit(10).all()
        viewer = db.get_or_create_user(session, update.effective_user)
        my_rank = session.query(db.User).filter(db.User.hop_points > viewer.hop_points).count() + 1
        if not top:
            text = "🪙 لیدربورد هاپ پوینت\n\nهنوز هیچ کاربری ثبت نشده."
        else:
            lines = ["🪙 لیدربورد هاپ پوینت (ثروتمندترین‌ها)\n"]
            for i, u in enumerate(top):
                lines.append(f"{_rank_prefix(i)} {u.display_name()} — {fmt(u.hop_points)} 🪙")
            text = "\n".join(lines)
        text += f"\n\n📍 رتبه‌ی شما: {my_rank}"
        await send_response(update, text, kb.league_result_keyboard(owner_id))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# انتقال هاپ (ریپلای در گروه)
# ---------------------------------------------------------------------------

TRANSFER_RE = re.compile(r"^\s*انتقال\s*هاپ\s+(\S+)\s*$")


async def handle_transfer_request(update: Update, context: ContextTypes.DEFAULT_TYPE):
    msg = update.message
    m = TRANSFER_RE.match(msg.text or "")
    if not m or not msg.reply_to_message:
        return False
    amount = parse_amount(m.group(1))
    if amount is None or amount <= 0:
        await msg.reply_text("❌ مبلغ رو درست ننوشتی. مثلا: «انتقال هاپ 5000» یا «انتقال هاپ 5k».")
        return True
    session = db.get_session()
    try:
        min_amount = db.cfg_get_float(session, "bank_transfer_min_amount")
    finally:
        session.close()
    if min_amount and amount < min_amount:
        await msg.reply_text(f"❌ انتقال ناموفق. حداقل مبلغِ انتقال {fmt(min_amount)} 🪙 هست.")
        return True
    sender = update.effective_user
    target = msg.reply_to_message.from_user
    if target.id == sender.id:
        await msg.reply_text("😅 نمی‌تونی به خودت هاپ انتقال بدی!")
        return True
    if target.is_bot:
        await msg.reply_text("🤖 نمی‌تونی به ربات‌ها هاپ انتقال بدی!")
        return True

    cb_yes = f"transfer_confirm:{sender.id}:{target.id}:{amount}"
    await msg.reply_text(
        f"❓ آیا مطمئنی می‌خوای {fmt(amount)} 🪙 هاپ پوینت به "
        f"{mentions.of(target)} انتقال بدی؟",
        reply_markup=kb.confirm_keyboard(cb_yes),
    )
    return True


async def cb_transfer_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    _, sender_id, target_id, amount = q.data.split(":")
    sender_id, target_id, amount = int(sender_id), int(target_id), float(amount)

    if update.effective_user.id != sender_id:
        await q.answer("این تایید مال شما نیست!", show_alert=True)
        return

    session = db.get_session()
    try:
        sender = session.get(db.User, sender_id)
        target = session.get(db.User, target_id)
        if sender is None or target is None:
            await q.answer()
            await q.edit_message_text("❌ خطا: کاربر پیدا نشد.")
            return
        if sender.hop_points < amount:
            await q.answer()
            await q.edit_message_text(f"❌ موجودی کافی نیست! (موجودی فعلی: {fmt(sender.hop_points)} 🪙)")
            return
        sender.hop_points -= amount
        target.hop_points += amount
        session.commit()
        await q.answer("✅ انجام شد!")
        await q.edit_message_text(
            f"✅ {fmt(amount)} 🪙 هاپ پوینت با موفقیت از {sender.display_name()} "
            f"به {target.display_name()} منتقل شد."
        )
    finally:
        session.close()


async def cb_cancel_action(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    await q.answer("لغو شد.")
    await q.edit_message_text("❌ عملیات لغو شد.")


# ---------------------------------------------------------------------------
# قرعه‌کشی هاپ (سراسری - فقط مالک از پیوی شروعش می‌کنه، نه با تایپ تو گروه)
# ---------------------------------------------------------------------------

async def handle_lottery_trigger(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """این تابع دیگه هیچ‌وقت قرعه‌کشیِ جدید نمی‌سازه - فقط وضعیتِ ایونتِ فعلی رو
    نشون می‌ده. قرعه‌کشی فقط از پیویِ مالک (پنل مدیریت) شروع می‌شه و بعدش تو
    همه‌ی گروه‌ها اعلام می‌شه."""
    session = db.get_session()
    try:
        event = session.query(db.LotteryEvent).filter_by(is_active=True).first()
        if not event:
            await update.message.reply_text("❌ این ایونت الان فعال نیست.")
            return
        parts = event.participants()
        text = (
            "🎉 قرعه‌کشی سراسری هاپ فعاله!\n"
            f"🎁 جایزه‌ی برنده: {fmt(event.prize_amount)} 🪙\n"
            f"👥 تعداد شرکت‌کننده تا الان: {len(parts)}\n\n"
            "برای شرکت روی دکمه‌ی زیر بزن 👇"
        )
        await update.message.reply_text(text, reply_markup=kb.lottery_join_keyboard(event.id))
    finally:
        session.close()


async def cb_lottery_join(update: Update, context: ContextTypes.DEFAULT_TYPE):
    q = update.callback_query
    event_id = int(q.data.split(":")[1])
    session = db.get_session()
    try:
        event = session.get(db.LotteryEvent, event_id)
        if not event or not event.is_active:
            await q.answer("این قرعه‌کشی دیگه فعال نیست ❌", show_alert=True)
            return
        parts = event.participants()
        uid = update.effective_user.id
        if uid in parts:
            await q.answer("قبلا ثبت‌نام کردی ✅", show_alert=True)
            return
        parts.append(uid)
        event.set_participants(parts)
        session.commit()
        await q.answer("🎉 ثبت شدی! موفق باشی")
    finally:
        session.close()


# ---------------------------------------------------------------------------
# ورودی متنیِ منتظرِ عدد (واریز/برداشت بانک، خرید/فروش ارز)
# ---------------------------------------------------------------------------

async def awaiting_number_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    awaiting = context.user_data.get("awaiting")
    if not awaiting:
        return  # کاری نداریم، بقیه‌ی هندلرها ادامه بدن
    if not is_reply_to_prompt(update, awaiting):
        return  # این پیام ریپلای به پرامپتِ ما نیست - نادیده بگیر، حالت رو هم پاک نکن

    text = (update.message.text or "").strip()
    kind = awaiting["type"]

    if kind == "wallet_transfer_address":
        address = text.strip().upper()
        session = db.get_session()
        try:
            sender = db.get_or_create_user(session, update.effective_user)
            target = session.query(db.User).filter_by(wallet_address=address).first()
            if not target:
                context.user_data.pop("awaiting", None)
                await update.message.reply_text("❌ ولتی با این آدرس پیدا نشد؛ عملیات لغو شد. دوباره از «💼 ولت» شروع کن.")
                raise ApplicationHandlerStop
            if target.telegram_id == sender.telegram_id:
                context.user_data.pop("awaiting", None)
                await update.message.reply_text("❌ نمی‌تونی به ولتِ خودت بفرستی! عملیات لغو شد.")
                raise ApplicationHandlerStop
            currencies = session.query(db.Currency).all()
            if not currencies:
                await update.message.reply_text("❌ فعلا هیچ ارزی تعریف نشده.")
                context.user_data.pop("awaiting", None)
                raise ApplicationHandlerStop
            context.user_data.pop("awaiting", None)
            await update.message.reply_text(
                f"👤 گیرنده: {target.display_name()}\nکدوم ارز رو می‌خوای بفرستی؟",
                reply_markup=kb.wallet_currency_picker_keyboard(currencies, target.telegram_id, sender.telegram_id),
            )
        finally:
            session.close()
        raise ApplicationHandlerStop

    if kind == "cat_name":
        name = text[:30]
        if not name:
            context.user_data.pop("awaiting", None)
            await update.message.reply_text("❌ مقدارِ اشتباه (اسم نمی‌تونه خالی باشه)؛ عملیات لغو شد.")
            raise ApplicationHandlerStop
        if name in RESERVED_TRIGGER_WORDS:
            context.user_data.pop("awaiting", None)
            await update.message.reply_text(
                "❌ این اسم با یکی از دستورات ربات تداخل داره؛ عملیات لغو شد. دوباره از «🐕 تغییر اسم سگ» امتحان کن."
            )
            raise ApplicationHandlerStop
        session = db.get_session()
        try:
            user = db.get_or_create_user(session, update.effective_user)
            user.cat_name = name
            session.commit()
        finally:
            session.close()
        context.user_data.pop("awaiting", None)
        await update.message.reply_text(
            f"✅ اسم سگ روی «{name}» ست شد! 🐾\n"
            f"از این به بعد به‌جای تایپ «هاپ منیج» فقط بنویس «{name}» تا منو باز شه.",
            reply_markup=kb.hop_manage_keyboard(True, user.telegram_id),
        )
        raise ApplicationHandlerStop

    parsed = parse_amount(text)
    if parsed is None:
        context.user_data.pop("awaiting", None)
        await update.message.reply_text("❌ مقدار اشتباه است (باید عدد صحیح باشه)؛ عملیات لغو شد.")
        raise ApplicationHandlerStop
    amount = parsed
    context.user_data.pop("awaiting", None)
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)

        if kind == "bank_deposit":
            # نکته: به‌خاطرِ اینکه hop_points از نوعِ float ذخیره می‌شه، بعدِ کلی
            # عملیاتِ ریاضیِ پیاپی (سود، پورسانت، ضرایبِ کازینو و ...) ممکنه یه
            # خطای فوق‌ریزِ اعشاری (مثلاً 143999999999.9999998 به‌جای
            # 144000000000) تو موجودی جمع بشه که با چشم دیده نمی‌شه (fmt همیشه
            # بدونِ اعشار نشون می‌ده) ولی باعث می‌شد دقیقاً کلِ موجودی رو که
            # می‌خوای واریز/برداشت کنی، به‌اشتباه «موجودی کافی نیست» بده. با یه
            # تلورانسِ خیلی کوچیک (۰.۰۰۰۰۰۱) این مشکل رفع می‌شه.
            if user.hop_points < amount - 0.5:
                await update.message.reply_text(f"❌ موجودی کافی نیست! (موجودی: {fmt(user.hop_points)} 🪙)")
            else:
                user.hop_points = round(user.hop_points - amount)
                user.bank_balance = round(user.bank_balance + amount)
                session.commit()
                await update.message.reply_text(f"✅ {fmt(amount)} 🪙 واریز شد. موجودی بانک: {fmt(user.bank_balance)} 🪙")

        elif kind == "bank_withdraw":
            if user.bank_balance < amount - 0.5:
                await update.message.reply_text(f"❌ موجودی بانک کافی نیست! (موجودی: {fmt(user.bank_balance)} 🪙)")
            else:
                user.bank_balance = round(user.bank_balance - amount)
                user.hop_points = round(user.hop_points + amount)
                session.commit()
                await update.message.reply_text(f"✅ {fmt(amount)} 🪙 برداشت شد. موجودی نقدی: {fmt(user.hop_points)} 🪙")

        elif kind == "crypto_buy":
            c = session.get(db.Currency, awaiting["currency_id"])
            cost = c.buy_price * amount
            if user.hop_points < cost - 0.5:
                await update.message.reply_text(f"❌ موجودی کافی نیست! نیاز: {fmt(cost)} 🪙")
            else:
                user.hop_points = round(user.hop_points - cost)
                uc = session.query(db.UserCurrency).filter_by(user_id=user.telegram_id, currency_id=c.id).first()
                if not uc:
                    uc = db.UserCurrency(user_id=user.telegram_id, currency_id=c.id, amount=0)
                    session.add(uc)
                uc.amount += amount
                session.commit()
                await update.message.reply_text(f"✅ {fmt(amount)} {c.name} خریدی! هزینه: {fmt(cost)} 🪙")

        elif kind == "crypto_sell":
            c = session.get(db.Currency, awaiting["currency_id"])
            uc = session.query(db.UserCurrency).filter_by(user_id=user.telegram_id, currency_id=c.id).first()
            owned = uc.amount if uc else 0
            if owned < amount - 0.5:
                await update.message.reply_text(f"❌ موجودی کافی نیست! (داری: {fmt(owned)} {c.name})")
            else:
                uc.amount = round(uc.amount - amount, 6)
                revenue = c.sell_price * amount
                user.hop_points = round(user.hop_points + revenue)
                session.commit()
                await update.message.reply_text(f"✅ {fmt(amount)} {c.name} فروختی! دریافتی: {fmt(revenue)} 🪙")

        elif kind == "alarm_price":
            c = session.get(db.Currency, awaiting["currency_id"])
            if not c:
                await update.message.reply_text("این ارز دیگه وجود نداره.")
                raise ApplicationHandlerStop
            if amount <= 0:
                await update.message.reply_text("❌ قیمت باید بزرگ‌تر از صفر باشه؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            direction = "up" if amount >= c.buy_price else "down"
            session.add(db.CurrencyAlarm(user_id=user.telegram_id, currency_id=c.id, target_price=amount, direction=direction))
            session.commit()
            arrow = "📈 رسیدنِ قیمت به" if direction == "up" else "📉 افتادنِ قیمت به"
            await update.message.reply_text(f"✅ آلارم ست شد! وقتی {arrow} {fmt(amount)} 🪙 برسه بهت پیام می‌دم.")

        elif kind == "order_price":
            c = session.get(db.Currency, awaiting["currency_id"])
            if not c:
                await update.message.reply_text("این ارز دیگه وجود نداره.")
                raise ApplicationHandlerStop
            if amount <= 0:
                await update.message.reply_text("❌ قیمت باید بزرگ‌تر از صفر باشه؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            order_kind = awaiting["kind"]
            label = "خرید" if order_kind == "buy" else "فروش"
            await ask_for_input_reply(
                update, context, f"📋 سفارشِ {label} با قیمتِ {fmt(amount)} 🪙 - حالا چند واحد بفرست:",
                {"type": "order_qty", "currency_id": c.id, "kind": order_kind, "target_price": amount}, "awaiting",
            )

        elif kind == "order_qty":
            c = session.get(db.Currency, awaiting["currency_id"])
            order_kind = awaiting["kind"]
            target_price = awaiting["target_price"]
            if not c:
                await update.message.reply_text("این ارز دیگه وجود نداره.")
                raise ApplicationHandlerStop
            if amount <= 0:
                await update.message.reply_text("❌ مقدار باید بزرگ‌تر از صفر باشه؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            if order_kind == "buy":
                cost = target_price * amount
                if user.hop_points < cost - 0.5:
                    await update.message.reply_text(f"❌ موجودی کافی نیست! برای این سفارش {fmt(cost)} 🪙 لازمه.")
                    raise ApplicationHandlerStop
                # پول همین الان رزرو (کم) می‌شه - وگرنه می‌شد چندتا سفارش با
                # پولِ یکسان ثبت کرد، یا با پولی که هنوز نداری سفارش گذاشت.
                user.hop_points = round(user.hop_points - cost)
                session.add(db.CurrencyOrder(user_id=user.telegram_id, currency_id=c.id, kind="buy",
                                              target_price=target_price, quantity=amount, status="pending"))
                session.commit()
                await update.message.reply_text(
                    f"✅ سفارشِ خریدِ {fmt(amount)} {c.name} با قیمتِ {fmt(target_price)} 🪙 ثبت شد.\n"
                    f"💰 {fmt(cost)} 🪙 رزرو شد؛ وقتی قیمت به این حد برسه/پایین‌تر بیاد، خودکار خریده می‌شه.")
            else:
                uc = session.query(db.UserCurrency).filter_by(user_id=user.telegram_id, currency_id=c.id).first()
                owned = uc.amount if uc else 0
                if owned < amount - 0.5:
                    await update.message.reply_text(f"❌ موجودی کافی نیست! (داری: {fmt(owned)} {c.name})")
                    raise ApplicationHandlerStop
                # همینجا خودِ ارز رو کم می‌کنیم (رزرو) - این‌طوری اگه هنوز
                # واقعاً خریده نشده (مثلاً یه سفارشِ خریدِ pending دیگه داری)،
                # نمی‌تونی روش سفارشِ فروش هم بذاری چون owned=0 هست.
                uc.amount = round(uc.amount - amount, 6)
                session.add(db.CurrencyOrder(user_id=user.telegram_id, currency_id=c.id, kind="sell",
                                              target_price=target_price, quantity=amount, status="pending"))
                session.commit()
                await update.message.reply_text(
                    f"✅ سفارشِ فروشِ {fmt(amount)} {c.name} با قیمتِ {fmt(target_price)} 🪙 ثبت شد.\n"
                    f"وقتی قیمت به این حد برسه/بالاتر بره، خودکار فروخته می‌شه.")

        elif kind == "wallet_transfer_amount":
            c = session.get(db.Currency, awaiting["currency_id"])
            target = session.get(db.User, awaiting["target_user_id"])
            uc = session.query(db.UserCurrency).filter_by(user_id=user.telegram_id, currency_id=c.id).first()
            owned = uc.amount if uc else 0
            if not target:
                await update.message.reply_text("❌ این گیرنده دیگه معتبر نیست.")
            elif owned < amount:
                await update.message.reply_text(f"❌ موجودی کافی نیست! (داری: {fmt(owned)} {c.name})")
            else:
                context.user_data["wallet_pending_transfer"] = {
                    "currency_id": c.id, "target_user_id": target.telegram_id, "amount": amount,
                }
                await update.message.reply_text(
                    f"🔄 انتقالِ {fmt(amount)} {c.name} به {target.display_name()}\n\nمطمئنی؟",
                    reply_markup=kb.wallet_confirm_keyboard(user.telegram_id),
                )
    finally:
        session.close()

    # نکته‌ی مهم: اینجا نباید دوباره bی‌قیدوشرط "awaiting" رو پاک کنیم - چون
    # "awaiting" همین بالاتر (بعدِ parse_amount) یه‌بار پاک شده، و اگه یکی از
    # حالت‌های بالا (مثلاً order_price) یه پرامپتِ ادامه‌دار تازه (order_qty)
    # ساخته باشه، اون از طریقِ ask_for_input_reply دوباره "awaiting" رو ست
    # کرده تا مرحله‌ی بعد پردازش بشه. پاک‌کردنِ بی‌قیدوشرط همین‌جا باعث می‌شد
    # اون پرامپتِ تازه بلافاصله از بین بره و مرحله‌ی بعدیِ فلو (مثلاً واردکردنِ
    # تعدادِ سفارش بعدِ قیمت) اصلاً پردازش نشه - انگار ربات هیچ جوابی نمی‌داد.
    raise ApplicationHandlerStop


async def cmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("awaiting", None)
    await update.message.reply_text("لغو شد.")


# ---------------------------------------------------------------------------
# مسیریاب متن‌های ساده‌ی گروه/پیوی (هاپ هاپ / هاپ منیج / قرعه‌کشی / ارز هاپ / انتقال)
# ---------------------------------------------------------------------------

JAIL_TRIGGER = "زندان هاپویی"
REPORT_TRIGGER = "گزارش هاپویی"


async def _handle_jail_command(update: Update, context: ContextTypes.DEFAULT_TYPE, normalized: str) -> bool:
    """دستورِ مالک یا ادمین‌هایی که دسترسیِ «گزارش‌های هاپویی» دارن، برای
    فرستادنِ کسی به زندانِ هاپویی، یا اگه از قبل تو زندان باشه، آزادکردنش. یا
    با ریپلای‌زدن رو پیامِ فرد («زندان هاپویی 20» یا «زندان هاپویی L» برای
    لایف‌تایم)، یا بدونِ ریپلای با نوشتنِ آیدیِ عددی («زندان هاپویی 123456789
    20»). اگه فردِ موردنظر همین الان زندانیه، مدت/L لازم نیست - فقط یه تاییدِ
    «آزادش کنم؟» نشون داده می‌شه. نکته‌ی مهم: مالک یا آدمینِ دیگه رو نمی‌شه
    هدف گرفت مگراینکه خودِ مالکِ اصلی این دستور رو بزنه - ادمین‌های فرعی فقط
    رو پلیرهای عادی می‌تونن این دستور رو اجرا کنن. برمی‌گردونه True یعنی این
    پیام برای همین دستور بود و نباید ادامه‌ی مسیریابیِ معمولی انجام بشه."""
    if not normalized.startswith(JAIL_TRIGGER):
        return False
    issuer_id = update.effective_user.id
    issuer_is_owner = is_owner(issuer_id)
    session = db.get_session()
    try:
        issuer_allowed = issuer_is_owner or db.has_admin_permission(session, issuer_id, "reports")
        session.commit()
    finally:
        session.close()
    if not issuer_allowed:
        await update.message.reply_text("⛔️ فقط مالک یا ادمین‌هایی که دسترسیِ «گزارش‌های هاپویی» رو دارن می‌تونن این دستور رو استفاده کنن.")
        return True

    usage_text = (
        "فرمتِ درست:\n"
        "• با ریپلای: «زندان هاپویی <دقیقه یا L> [وثیقه]»\n"
        "• بدونِ ریپلای: «زندان هاپویی <آیدیِ عددی> <دقیقه یا L> [وثیقه]»\n\n"
        "مثال‌ها:\n"
        "• «زندان هاپویی 20» ← ۲۰ دقیقه، با وثیقه‌ی پیش‌فرض\n"
        "• «زندان هاپویی 20 5m» ← ۲۰ دقیقه، وثیقه ۵ میلیون\n"
        "• «زندان هاپویی L 50m» ← همیشگی، وثیقه ۵۰ میلیون\n"
        "• «زندان هاپویی 30 -» ← ۳۰ دقیقه، بدونِ امکانِ وثیقه (با پول آزاد نمی‌شه)\n"
        "(اگه فرد از قبل زندانیه، نیازی به مدت نیست - فقط تاییدِ آزادکردن نشون داده می‌شه.)"
    )

    rest = normalized[len(JAIL_TRIGGER):].strip()
    reply = update.message.reply_to_message
    if reply and reply.from_user:
        target_id = reply.from_user.id
        target_name = mentions.of(reply.from_user)
        duration_text = rest  # ممکنه خالی باشه (وقتی صرفاً می‌خواد چک/آزاد کنه)
    else:
        parts = rest.split()
        if not parts or not parts[0].isdigit():
            await update.message.reply_text(usage_text)
            return True
        target_id = int(parts[0])
        target_name = str(target_id)
        duration_text = " ".join(parts[1:]).strip()

    if target_id == update.effective_user.id:
        await update.message.reply_text("نمی‌تونی رو خودت این دستور رو بزنی!")
        return True

    session = db.get_session()
    try:
        u = session.get(db.User, target_id)
        if u:
            target_name = u.display_name()
        currently_jailed = bool(u and u.jailed_until and u.jailed_until > datetime.datetime.utcnow())
        target_is_protected = db.is_any_admin(session, target_id)
        session.commit()
    finally:
        session.close()

    if target_is_protected and not issuer_is_owner:
        await update.message.reply_text("❌ نمی‌تونی مالک یا ادمین‌های دیگه رو زندانی/آزاد کنی؛ فقط مالکِ اصلی این کارو می‌تونه بکنه.")
        return True

    if currently_jailed:
        await update.message.reply_text(
            f"{target_name} الان تو زندان هاپویی هست. می‌خوای آزادش کنی؟",
            reply_markup=InlineKeyboardMarkup([[
                InlineKeyboardButton("✅ بله، آزادش کن", callback_data=f"jailcmd_release:{target_id}"),
                InlineKeyboardButton("❌ نه", callback_data="jailcmd_cancel:0:0"),
            ]]),
        )
        return True

    # ورودی: «<دقیقه|L> [وثیقه|-]»
    bits = duration_text.split()
    duration_norm = (bits[0].strip().lower() if bits else "")
    bail_text = (bits[1].strip() if len(bits) > 1 else "")

    if duration_norm == "l":
        desc = "برای همیشه"
    elif duration_norm.isdigit() and int(duration_norm) > 0:
        desc = f"{duration_norm} دقیقه"
    else:
        await update.message.reply_text(usage_text)
        return True

    # وثیقه: خالی = پیش‌فرضِ کانفیگ | «-» = اصلاً وثیقه قبول نشه | عدد = همون
    if not bail_text:
        session = db.get_session()
        try:
            bail_value = db.cfg_get_float(session, "jail_default_bail") or 0
        finally:
            session.close()
        bail_desc = f"وثیقه: {fmt(bail_value)} 🪙 (پیش‌فرض)"
    elif bail_text == "-":
        bail_value = -1
        bail_desc = "⛔️ بدونِ امکانِ وثیقه (با پول آزاد نمی‌شه)"
    else:
        parsed = parse_amount(bail_text)
        if parsed is None or parsed < 0:
            await update.message.reply_text("❌ مقدارِ وثیقه نامعتبره.\n\n" + usage_text)
            return True
        bail_value = float(parsed)
        bail_desc = f"وثیقه: {fmt(bail_value)} 🪙"

    await update.message.reply_text(
        f"آیا می‌خواهید {target_name} را {desc} به زندان هاپویی ببرید؟\n{bail_desc}",
        reply_markup=InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله", callback_data=f"jailcmd_confirm:{target_id}:{duration_norm}:{bail_value}"),
            InlineKeyboardButton("❌ خیر", callback_data="jailcmd_cancel:0:0"),
        ]]),
    )
    return True


async def cb_jailcmd_release(update: Update, context: ContextTypes.DEFAULT_TYPE):
    issuer_id = update.effective_user.id
    target_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        issuer_is_owner = is_owner(issuer_id)
        issuer_allowed = issuer_is_owner or db.has_admin_permission(session, issuer_id, "reports")
        if not issuer_allowed:
            session.commit()
            await update.callback_query.answer("⛔️ اجازه‌ی این کارو نداری.", show_alert=True)
            return
        if not issuer_is_owner and db.is_any_admin(session, target_id):
            session.commit()
            await update.callback_query.answer("❌ فقط مالکِ اصلی می‌تونه رو مالک/ادمین‌های دیگه این کارو بکنه.", show_alert=True)
            return
        u = session.get(db.User, target_id)
        if u:
            u.jailed_until = None
            u.jail_bail_amount = None
            u.jail_reason = None
            name = u.display_name()
        else:
            name = str(target_id)
        session.commit()
    finally:
        session.close()
    antispam.release(target_id)  # اگه به‌خاطرِ اسپم زندانی شده بود، اون زندانِ جداگونه‌ی درون‌حافظه‌ای رو هم آزاد کن
    await update.callback_query.edit_message_text(f"🔓 {name} از زندان هاپویی آزاد شد.")


async def cb_jailcmd_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    issuer_id = update.effective_user.id
    parts = update.callback_query.data.split(":")
    target_id = int(parts[1])
    duration_arg = parts[2]
    bail_arg = float(parts[3]) if len(parts) > 3 else 0.0
    session = db.get_session()
    try:
        issuer_is_owner = is_owner(issuer_id)
        issuer_allowed = issuer_is_owner or db.has_admin_permission(session, issuer_id, "reports")
        if not issuer_allowed:
            session.commit()
            await update.callback_query.answer("⛔️ اجازه‌ی این کارو نداری.", show_alert=True)
            return
        if not issuer_is_owner and db.is_any_admin(session, target_id):
            session.commit()
            await update.callback_query.answer("❌ فقط مالکِ اصلی می‌تونه رو مالک/ادمین‌های دیگه این کارو بکنه.", show_alert=True)
            return
        u = session.get(db.User, target_id)
        if not u:
            u = db.User(telegram_id=target_id)
            session.add(u)
        if duration_arg == "l":
            u.jailed_until = db.JAIL_FOREVER
            desc = "برای همیشه"
        else:
            u.jailed_until = datetime.datetime.utcnow() + datetime.timedelta(minutes=int(duration_arg))
            desc = f"{duration_arg} دقیقه"
        u.jail_bail_amount = bail_arg
        u.jail_reason = "admin"
        name = u.display_name()
        session.commit()
    finally:
        session.close()
    if bail_arg < 0:
        bail_line = "\n⛔️ بدونِ امکانِ وثیقه."
    else:
        bail_line = f"\n💸 وثیقه‌ی آزادی: {fmt(bail_arg)} 🪙 (با نوشتنِ «وثیقه»)"
    await update.callback_query.edit_message_text(f"🔒 {name} به زندان هاپویی فرستاده شد ({desc}).{bail_line}")


async def cb_jailcmd_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await update.callback_query.edit_message_text("لغو شد.")


# ---------------------------------------------------------------------------
# وثیقه - خریدنِ آزادی از زندانِ هاپویی
# ---------------------------------------------------------------------------

BAIL_TRIGGER = "وثیقه"

NOT_JAILED_TEXT = "🐶 تو سگ پشمالو و خوبی هستی، پس زندانی نیستی!"


def _effective_bail(session, u) -> float:
    """وثیقه‌ی مؤثرِ این کاربر:
       عددِ منفی -> اصلاً وثیقه قبول نمی‌شه
       None -> از کانفیگ (بسته به دلیلِ زندانی‌شدن) خونده می‌شه
    """
    if u.jail_bail_amount is not None:
        return float(u.jail_bail_amount)
    if (u.jail_reason or "") == "smuggling":
        return db.cfg_get_float(session, "smuggling_fail_jail_bail") or 0
    if (u.jail_reason or "") == "spam":
        return db.cfg_get_float(session, "jail_spam_bail") or 0
    return db.cfg_get_float(session, "jail_default_bail") or 0


def _fmt_remain_line(forever, remain) -> str:
    if forever:
        return "⏳ مدت: برای همیشه"
    h = int(remain.total_seconds() // 3600)
    m = int((remain.total_seconds() % 3600) // 60)
    return f"⏳ باقی‌مونده: {h} ساعت و {m} دقیقه"


def _bail_source_menu(uid, bail, pocket, bank, time_line):
    """اکثرِ پلیرها پولشون تو بانکه، نه جیب - برای همین به‌جای کم‌کردنِ مستقیم از
    جیب، اول می‌پرسیم از کجا پرداخت کنه."""
    text = (
        f"🔒 تو زندانِ هاپویی هستی.\n{time_line}\n\n"
        f"💸 وثیقه‌ی آزادی: {fmt(bail)} 🪙\n"
        f"💵 موجودیِ جیب: {fmt(pocket)} 🪙\n"
        f"🏦 موجودیِ بانکِ هاپویی: {fmt(bank)} 🪙\n\n"
        "از کجا پرداخت کنم؟"
    )
    rows = [
        [InlineKeyboardButton("💵 پرداخت از جیب", callback_data=f"bail_src:{uid}:pocket")],
        [InlineKeyboardButton("🏦 پرداخت از بانک هاپویی", callback_data=f"bail_src:{uid}:bank")],
        [InlineKeyboardButton("❌ بیخیال", callback_data=f"bail_cancel:{uid}")],
    ]
    try:
        import battlepass_engine as _bp
        if _bp.has_jail_card(uid):
            rows.insert(0, [InlineKeyboardButton("🗝 کارتِ آزادیِ بتل‌پس (آزادیِ فوری)", callback_data=f"bail_bpjc:{uid}")])
    except Exception:
        pass
    return text, InlineKeyboardMarkup(rows)


async def _handle_bail_command(update: Update, context: ContextTypes.DEFAULT_TYPE, normalized: str) -> bool:
    """با نوشتنِ «وثیقه» صفحه‌ی پرداختِ آزادی میاد. اگه اصلاً زندانی نباشه،
    همون جوابِ طعنه‌آمیز رو می‌گیره."""
    if normalized.strip() != BAIL_TRIGGER:
        return False
    uid = update.effective_user.id
    session = db.get_session()
    try:
        u = db.get_or_create_user(session, update.effective_user)
        nowt = datetime.datetime.utcnow()
        jailed = bool(u.jailed_until and u.jailed_until > nowt)
        if not jailed:
            session.commit()
            await update.message.reply_text(NOT_JAILED_TEXT)
            return True
        forever = u.jailed_until >= db.JAIL_FOREVER
        remain = None if forever else (u.jailed_until - nowt)
        bail = _effective_bail(session, u)
        pocket = u.hop_points or 0
        bank = u.bank_balance or 0
        session.commit()
    finally:
        session.close()

    time_line = _fmt_remain_line(forever, remain)

    if bail < 0:
        await update.message.reply_text(
            f"🔒 تو زندانِ هاپویی هستی.\n{time_line}\n\n"
            "❌ وثیقه‌ای تعیین نشده است؛ باید مدتش تموم شه یا یه ادمین آزادت کنه."
        )
        return True

    text, kb = _bail_source_menu(uid, bail, pocket, bank, time_line)
    await update.message.reply_text(text, reply_markup=kb)
    return True


async def cb_bail_src(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """اولین کلیک: انتخابِ محلِ پرداخت (جیب/بانک) - بعدش یه تاییدِ نهایی می‌خواد،
    هنوز پولی کم نمی‌شه."""
    _, owner_id, source = update.callback_query.data.split(":")
    owner_id = int(owner_id)
    if update.effective_user.id != owner_id:
        await update.callback_query.answer("⛔️ این پیام مالِ تو نیست!", show_alert=True)
        return
    session = db.get_session()
    try:
        u = db.get_or_create_user(session, update.effective_user)
        nowt = datetime.datetime.utcnow()
        if not (u.jailed_until and u.jailed_until > nowt):
            session.commit()
            await update.callback_query.answer("تو الان زندانی نیستی!", show_alert=True)
            return
        bail = _effective_bail(session, u)
        if bail < 0:
            session.commit()
            await update.callback_query.answer("❌ وثیقه‌ای تعیین نشده است.", show_alert=True)
            return
        balance = (u.hop_points or 0) if source == "pocket" else (u.bank_balance or 0)
        session.commit()
    finally:
        session.close()

    src_label = "جیب" if source == "pocket" else "بانکِ هاپویی"
    if balance < bail:
        await update.callback_query.answer(
            f"❌ موجودیِ {src_label} کافی نیست! {fmt(bail - balance)} 🪙 کم داری.", show_alert=True)
        return

    rows = [[
        InlineKeyboardButton("✅ بله مطمئنم", callback_data=f"bail_confirm:{owner_id}:{source}"),
        InlineKeyboardButton("🔙 برگشت", callback_data=f"bail_back:{owner_id}"),
    ]]
    await update.callback_query.edit_message_text(
        f"با پرداختِ {fmt(bail)} 🪙 از {src_label} همین الان آزاد می‌شی. مطمئنی؟",
        reply_markup=InlineKeyboardMarkup(rows),
    )


async def cb_bail_back(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دکمه‌ی «🔙 برگشت» زیرِ تاییدِ نهایی - برمی‌گرده به صفحه‌ی انتخابِ جیب/بانک."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if update.effective_user.id != owner_id:
        await update.callback_query.answer("⛔️ این پیام مالِ تو نیست!", show_alert=True)
        return
    session = db.get_session()
    try:
        u = db.get_or_create_user(session, update.effective_user)
        nowt = datetime.datetime.utcnow()
        if not (u.jailed_until and u.jailed_until > nowt):
            session.commit()
            await update.callback_query.answer("تو الان زندانی نیستی!", show_alert=True)
            return
        forever = u.jailed_until >= db.JAIL_FOREVER
        remain = None if forever else (u.jailed_until - nowt)
        bail = _effective_bail(session, u)
        pocket = u.hop_points or 0
        bank = u.bank_balance or 0
        session.commit()
    finally:
        session.close()
    time_line = _fmt_remain_line(forever, remain)
    text, kb = _bail_source_menu(owner_id, bail, pocket, bank, time_line)
    await update.callback_query.edit_message_text(text, reply_markup=kb)


async def cb_bail_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """تاییدِ نهایی («✅ بله مطمئنم») - این‌جا واقعاً پول کم می‌شه و آزاد می‌شه."""
    _, owner_id, source = update.callback_query.data.split(":")
    owner_id = int(owner_id)
    if update.effective_user.id != owner_id:
        await update.callback_query.answer("⛔️ این پیام مالِ تو نیست!", show_alert=True)
        return
    session = db.get_session()
    try:
        u = db.get_or_create_user(session, update.effective_user)
        nowt = datetime.datetime.utcnow()
        if not (u.jailed_until and u.jailed_until > nowt):
            session.commit()
            await update.callback_query.answer("تو الان زندانی نیستی!", show_alert=True)
            return
        bail = _effective_bail(session, u)
        if bail < 0:
            session.commit()
            await update.callback_query.answer("❌ وثیقه‌ای تعیین نشده است.", show_alert=True)
            return
        src_label = "جیب" if source == "pocket" else "بانکِ هاپویی"
        if source == "pocket":
            if (u.hop_points or 0) < bail:
                session.commit()
                await update.callback_query.answer(f"❌ موجودیِ جیب کافی نیست! {fmt(bail)} 🪙 لازمه.", show_alert=True)
                return
            u.hop_points -= bail
            remaining_balance = u.hop_points
        else:
            if (u.bank_balance or 0) < bail:
                session.commit()
                await update.callback_query.answer(f"❌ موجودیِ بانک کافی نیست! {fmt(bail)} 🪙 لازمه.", show_alert=True)
                return
            u.bank_balance -= bail
            remaining_balance = u.bank_balance
        u.jailed_until = None
        u.jail_bail_amount = None
        u.jail_reason = None
        session.commit()
    finally:
        session.close()
    # زندانِ درون‌حافظه‌ایِ ضدِاسپم هم باید آزاد شه، وگرنه با اینکه پول داده،
    # همچنان تا آخرِ ۲۰ دقیقه بلاک می‌موند
    antispam.release(owner_id)
    await update.callback_query.edit_message_text(
        f"🔓 وثیقه پرداخت شد و آزاد شدی!\n\n"
        f"💸 پرداختی: {fmt(bail)} 🪙 (از {src_label})\n"
        f"💰 موجودیِ جدیدِ {src_label}: {fmt(remaining_balance)} 🪙"
    )


async def cb_bail_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    owner_id = int(update.callback_query.data.split(":")[1])
    if update.effective_user.id != owner_id:
        await update.callback_query.answer("⛔️ این پیام مالِ تو نیست!", show_alert=True)
        return
    await update.callback_query.edit_message_text("باشه، تو زندان می‌مونی. 🔒")


async def _handle_report_command(update: Update, context: ContextTypes.DEFAULT_TYPE, normalized: str) -> bool:
    """گزارشِ یه پلیرِ عادی از یه پلیرِ دیگه - با ریپلای‌زدن رو پیامِ موردنظر.
    برمی‌گردونه True یعنی این پیام برای همین دستور بود."""
    if not normalized.startswith(REPORT_TRIGGER):
        return False
    reply = update.message.reply_to_message
    if not reply or not reply.from_user:
        await update.message.reply_text(
            "برای گزارش‌دادن، رو پیامِ موردنظر ریپلای بزن و بنویس «گزارش هاپویی <دلیل>»."
        )
        return True
    reported_id = reply.from_user.id
    if reported_id == update.effective_user.id:
        await update.message.reply_text("نمی‌تونی خودتو گزارش بدی!")
        return True
    session = db.get_session()
    try:
        is_protected = db.is_any_admin(session, reported_id)
        session.commit()
    finally:
        session.close()
    if is_protected:
        await update.message.reply_text("❌ نمی‌تونی مالک یا ادمین‌ها رو گزارش بدی.")
        return True
    reason = normalized[len(REPORT_TRIGGER):].strip()
    chat = update.effective_chat
    if chat.username:
        link = f"https://t.me/{chat.username}/{reply.message_id}"
    else:
        cid_str = str(chat.id)
        internal_id = cid_str[4:] if cid_str.startswith("-100") else cid_str.lstrip("-")
        link = f"https://t.me/c/{internal_id}/{reply.message_id}"
    session = db.get_session()
    try:
        reporter = db.get_or_create_user(session, update.effective_user)
        db.get_or_create_user(session, reply.from_user)  # مطمئن شو گزارش‌شده هم تو دیتابیس ثبت شده
        report = db.Report(
            reporter_id=reporter.telegram_id, reported_user_id=reported_id,
            chat_id=chat.id, message_id=reply.message_id, message_link=link,
            reason=reason or None,
        )
        session.add(report)
        session.commit()
    finally:
        session.close()
    await update.message.reply_text("✅ گزارشت ثبت شد؛ مالک بررسیش می‌کنه.")
    return True


async def text_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    if not update.message or not update.message.text:
        return
    text = update.message.text.strip()
    normalized = text.replace("‌", " ").strip()

    # «وثیقه» باید قبل از هر چکِ دیگه‌ای (مخصوصاً قبل از بلاکِ زندانی‌ها پایین‌تر)
    # بررسی شه - وگرنه دقیقاً کسی که زندانیه و می‌خواد وثیقه بده، با پیامِ
    # «تو زندانی هستی» رد می‌شد و هیچ‌وقت به صفحه‌ی پرداخت نمی‌رسید.
    if await _handle_bail_command(update, context, normalized):
        return

    if await _handle_jail_command(update, context, normalized):
        return
    if await _handle_report_command(update, context, normalized):
        return
    if await _handle_bank_command(update, context, normalized):
        return
    import attack  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
    if await attack.handle_hostage_reply_trigger(update, context):
        return

    is_transfer = bool(TRANSFER_RE.match(text) and update.message.reply_to_message)

    trigger = None
    if normalized in ("هاپ هاپ", "هاپ‌هاپ", "هاپ"):
        trigger = "hop"
    elif normalized == "هاپ منیج":
        trigger = "hop_manage"
    elif normalized == "قرعه کشی هاپ":
        trigger = "lottery"
    elif normalized == "ارز هاپ":
        trigger = "crypto"
    elif normalized == "کازینو هاپویی":
        trigger = "casino"
    elif normalized == "لیگ برتر":
        trigger = "league"
    elif normalized == "هاپ هام":
        trigger = "my_stats"
    elif normalized == "هاپ هاش":
        trigger = "other_stats"
    elif normalized == "گوشی هاپویی":
        trigger = "myawy"
    elif normalized == "رای گیری هاپویی":
        trigger = "chef_election"
    elif normalized == "مارکت هاپویی":
        trigger = "chef_market"
    elif normalized == "تاکسی هاپویی":
        trigger = "taxi"
    elif normalized == "کارت هاپویی":
        trigger = "cards"
    elif normalized == "کد جایزه هاپویی":
        trigger = "redeem"
    elif normalized == "پنل حمله":
        trigger = "attack_panel"
    elif normalized == "قاچاق هاپویی":
        trigger = "smuggling_panel"
    elif normalized == "منوی اصلی هاپویی":
        trigger = "main_menu"
    elif normalized == "راهنمایی هاپویی":
        trigger = "help_guide"
    elif normalized == "دزدی تیمی هاپویی":
        trigger = "heist"
    elif normalized.replace("‌", " ") in {"لینک دعوت", "لینک دعوت هاپویی", "دعوت هاپویی", "لینک رفرال"}:
        trigger = "referral"
    elif normalized.replace("‌", " ") in {"بتل پس هاپویی", "بتل پس", "بتلپس هاپویی", "پس هاپویی", "هاپ پس"}:
        trigger = "battlepass"
    elif normalized.replace("‌", " ") in {"ماموریت هاپویی", "مأموریت هاپویی", "ماموریت های هاپویی", "مأموریت های هاپویی", "ماموریتای هاپویی"}:
        trigger = "mission"
    else:
        import war_ui  # تریگرهای «جنگ هاپویی» (Alias دیتابیسی، مقاوم به ی/ی، نیم‌فاصله و ...)
        if war_ui.match_trigger(normalized):
            trigger = "war"

    if not trigger and not is_transfer:
        # شاید کاربر به‌جای «هاپ منیج» اسم دلخواهِ خودشو (اسم سگ) صدا زده باشه.
        # (از کشِ درون‌حافظه می‌خونه - نگاه کن به db.cat_name_matches - تا هر پیامِ عادیِ گروه
        # یه کوئری به دیتابیسِ ریموت نزنه؛ شرطِ مقایسه عیناً همون قبلیه.)
        if db.cat_name_matches(update.effective_user.id, normalized):
            trigger = "hop_manage"

    if not trigger and not is_transfer:
        return  # پیام عادی گروه، کاری نداریم

    # --- زندانِ سراسریِ هاپویی (مثلا بابتِ ندادنِ فیِ پلتفرمِ گوشی هاپویی سرِ
    # وقت) - فارغ از گروه، رو کل ربات اثر داره؛ با زندانِ ضدِاسپمِ antispam.py
    # (که فقط تو حافظه و مخصوصِ یه گروهه) فرق داره
    session = db.get_session()
    try:
        jailed_user = db.get_or_create_user(session, update.effective_user)
        is_jailed = jailed_user.jailed_until and jailed_user.jailed_until > datetime.datetime.utcnow()
        forever = bool(is_jailed and jailed_user.jailed_until >= db.JAIL_FOREVER)
        remain = (jailed_user.jailed_until - datetime.datetime.utcnow()) if (is_jailed and not forever) else None
        session.commit()
    finally:
        session.close()
    if is_jailed:
        if forever:
            await update.message.reply_text("🔒 شما برای همیشه در زندان هاپویی هستید.\n💸 برای بررسیِ امکانِ وثیقه بنویس «وثیقه».")
        else:
            h = int(remain.total_seconds() // 3600)
            m = int((remain.total_seconds() % 3600) // 60)
            await update.message.reply_text(f"🔒 شما در زندان هاپویی هستید! {h} ساعت و {m} دقیقه‌ی دیگه آزاد می‌شید.\n💸 برای آزادیِ زودهنگام بنویس «وثیقه».")
        return

    # --- ضدِ اسپم: فقط برای دستورات واقعی ربات، فقط داخل گروه‌ها، و فقط برای
    # کاربرهای عادی (نه مالک/ادمین‌ها - قبلاً ادمین‌ها هم با کلیک‌های پشتِ‌سرِهم
    # موقعِ مدیریت ممکن بود اشتباهی ۲۰دقیقه زندانیِ اسپم بشن) ---
    if update.effective_chat.type != "private":
        session = db.get_session()
        try:
            is_privileged = is_owner(update.effective_user.id) or db.is_any_admin(session, update.effective_user.id)
        finally:
            session.close()
        if not is_privileged:
            blocked, jail_text = antispam.register_and_check(
                update.effective_chat.id, update.effective_user.id
            )
            if blocked:
                if jail_text == antispam.JAIL_ENTER_TEXT:
                    # همین الان زندانی شد - تو دیتابیس (User.jailed_until) هم
                    # ثبتش می‌کنیم، وگرنه «زندان هاپویی <آیدی>» و دکمه‌های
                    # شیشه‌ای (jail_gate) از این زندان خبر نداشتن، چون قبلاً
                    # این زندان کاملاً جدا و فقط تو حافظه بود.
                    session = db.get_session()
                    try:
                        u = db.get_or_create_user(session, update.effective_user)
                        u.jailed_until = datetime.datetime.utcnow() + datetime.timedelta(seconds=antispam.JAIL_DURATION_SECONDS)
                        # وثیقه‌ی زندانِ اسپم (پیش‌فرض ۴.۵ میلیون، از پنل قابلِ تغییر)
                        u.jail_bail_amount = db.cfg_get_float(session, "jail_spam_bail") or 0
                        u.jail_reason = "spam"
                        session.commit()
                    finally:
                        session.close()
                await update.message.reply_text(jail_text)
                return

    if is_transfer:
        if await handle_transfer_request(update, context):
            return

    # --- حداقلِ سطح (lvl) لازم برای این بخش - از پنلِ ادمین قابلِ تنظیمه؛ ۰
    # یعنی بدونِ محدودیت. «هاپ» (trigger == "hop") از این قاعده مستثناست، چون
    # لولِ کاربر خودش از رو همین هاپ کردن ساخته می‌شه.
    if trigger and trigger != "hop":
        session = db.get_session()
        try:
            gate_user = db.get_or_create_user(session, update.effective_user)
            gate_error = db.check_module_level(session, gate_user, trigger)
        finally:
            session.close()
        if gate_error:
            await update.message.reply_text(gate_error)
            return

    if trigger == "hop":
        await process_hop(update, context)
    elif trigger == "hop_manage":
        await show_hop_manage(update, context)
    elif trigger == "lottery":
        await handle_lottery_trigger(update, context)
    elif trigger == "crypto":
        await show_crypto_list(update, context)
    elif trigger == "casino":
        import casino  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await casino.handle_casino_trigger(update, context)
    elif trigger == "league":
        await show_league_menu(update, context, update.effective_user.id)
    elif trigger == "my_stats":
        await show_my_hop_stats(update, context)
    elif trigger == "other_stats":
        await show_other_hop_stats(update, context)
    elif trigger == "myawy":
        import myawy  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await myawy.handle_myawy_trigger(update, context)
    elif trigger == "chef_election":
        import chef  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await chef.handle_election_trigger(update, context)
    elif trigger == "chef_market":
        import chef  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await chef.handle_market_trigger(update, context)
    elif trigger == "taxi":
        import taxi  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await taxi.handle_taxi_trigger(update, context)
    elif trigger == "cards":
        import cards  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await cards.handle_cards_trigger(update, context)
    elif trigger == "redeem":
        import redeem  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await redeem.handle_redeem_trigger(update, context)
    elif trigger == "attack_panel":
        import attack  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await attack.handle_attack_trigger(update, context)
    elif trigger == "smuggling_panel":
        import smuggling  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await smuggling.handle_smuggling_trigger(update, context)
    elif trigger == "referral":
        import referral_ui
        await referral_ui.show_panel(update, context)
    elif trigger == "battlepass":
        import battlepass_ui
        await battlepass_ui.handle_trigger(update, context)
    elif trigger == "mission":
        import mission_ui
        await mission_ui.handle_mission_trigger(update, context)
    elif trigger == "heist":
        import heist_ui  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await heist_ui.handle_heist_trigger(update, context)
    elif trigger == "main_menu":
        await update.message.reply_text(
            "🏠 منوی اصلی:",
            reply_markup=kb.main_private_menu(can_access_admin_panel(update.effective_user.id), update.effective_user.id),
        )
    elif trigger == "help_guide":
        import guide  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
        await guide.handle_help_text_trigger(update, context)
    elif trigger == "war":
        import war_ui
        await war_ui.handle_trigger(update, context, normalized)


# ---------------------------------------------------------------------------
# مسیریاب دکمه‌های شیشه‌ای
# ---------------------------------------------------------------------------

CALLBACK_MAP = {
    "hop_hop": cb_hop_hop,
    "hop_manage": cb_hop_manage,
    "back_main": cb_back_main,
    "cancel_action": cb_cancel_action,
}

PREFIX_CALLBACK_MAP = {
    "cancel_any_awaiting": cb_cancel_any_awaiting,
    "league_menu": cb_league_menu,
    "league_hops": cb_league_hops,
    "league_points": cb_league_points,
    "crypto_view": cb_crypto_view,
    "crypto_buy_ask": cb_crypto_buy_ask,
    "crypto_sell_ask": cb_crypto_sell_ask,
    "crypto_alarm_menu": cb_crypto_alarm_menu,
    "crypto_alarm_add": cb_crypto_alarm_add,
    "crypto_alarm_del": cb_crypto_alarm_del,
    "crypto_order_menu": cb_crypto_order_menu,
    "crypto_order_buy_ask": cb_crypto_order_buy_ask,
    "crypto_order_sell_ask": cb_crypto_order_sell_ask,
    "crypto_order_cancel": cb_crypto_order_cancel,
    "wallet_open": cb_wallet_open,
    "wallet_buy": cb_wallet_buy,
    "wallet_transfer_ask": cb_wallet_transfer_ask,
    "wallet_pick_currency": cb_wallet_pick_currency,
    "wallet_confirm": cb_wallet_confirm,
    "transfer_confirm": cb_transfer_confirm,
    "lottery_join": cb_lottery_join,
    # همه‌ی این‌ها مالِ منویی‌ان که با تایپِ «هاپ منیج»/اسمِ سگ/«هاپ هاپ» تو
    # گروه باز می‌شن؛ owner_id تو خودِ callback_data قفل شده تا کسی نتونه از
    # روی پیامِ باز شده‌ی یه نفرِ دیگه (چه با «بازگشت»، چه با دکمه‌های سوپرمارکت/
    # بانک/ارز/پروفایل) اکانتِ خودش رو مدیریت کنه.
    "factory_collect": cb_factory_collect,
    "factory_upgrade": cb_factory_upgrade,
    "factory_rank_confirm": cb_factory_rank_confirm,
    "factory_rank_cancel": cb_factory_rank_cancel,
    "cat_name_ask": cb_cat_name_ask,
    "back_main_owned": cb_back_main_owned,
    "hop_hop_owned": cb_hop_hop_owned,
    "hop_manage_owned": cb_hop_manage_owned,
    "market_open_owned": cb_market_open_owned,
    "market_buy": cb_market_buy,
    "market_upgrade": cb_market_upgrade,
    "market_collect": cb_market_collect,
    "market_sell_all": cb_market_sell_all,
    "bank_open_owned": cb_bank_open_owned,
    "bank_create": cb_bank_create,
    "bank_deposit_ask": cb_bank_deposit_ask,
    "bank_withdraw_ask": cb_bank_withdraw_ask,
    "crypto_open_owned": cb_crypto_open_owned,
    "profile_open_owned": cb_profile_open_owned,
    "jailcmd_confirm": cb_jailcmd_confirm,
    "jailcmd_cancel": cb_jailcmd_cancel,
    "jailcmd_release": cb_jailcmd_release,
    "bail_src": cb_bail_src,
    "bail_back": cb_bail_back,
    "bail_confirm": cb_bail_confirm,
    "bail_cancel": cb_bail_cancel,
}


async def callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = update.callback_query.data
    prefix = data.split(":")[0]
    handler = CALLBACK_MAP.get(data) or PREFIX_CALLBACK_MAP.get(prefix)
    if handler:
        await handler(update, context)
    else:
        await update.callback_query.answer()
