# -*- coding: utf-8 -*-
"""اجرا:  python -m pytest test_referral.py -q   (دیتابیسِ موقت)"""
import datetime
import os
import tempfile
import types

os.environ.setdefault("BOT_TOKEN", "1:x")
os.environ.setdefault("OWNER_ID", "999")
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "ref_test.db")

import pytest  # noqa: E402

import db  # noqa: E402
import war_db as W  # noqa: E402
import referral as R  # noqa: E402
import referral_ui as UI  # noqa: E402

BOT = "HopBot"


@pytest.fixture()
def ses():
    db.Base.metadata.drop_all(db.engine)
    db.init_db()
    W.init_war()
    R.init_referral()
    s = db.get_session()
    yield s
    s.rollback()
    s.close()


def mkuser(s, uid, **kw):
    s.add(db.User(telegram_id=uid, username=f"u{uid}", first_name=f"U{uid}", hop_points=kw.pop("hop", 0.0), **kw))
    s.commit()


def tg(uid):
    return types.SimpleNamespace(id=uid, username=f"u{uid}", first_name=f"U{uid}", is_bot=False)


def test_new_user_pays_inviter_once(ses):
    mkuser(ses, 1)
    info = R.register(ses, tg(2), "1", existed_before=False)
    assert info and info["hop"] == 250_000_000_000 and info["count"] == 1
    assert ses.get(db.User, 1).hop_points == 250_000_000_000
    assert ses.query(W.HopTransaction).filter_by(user_id=1).count() == 1
    assert R.register(ses, tg(2), "1", existed_before=False) is None          # دوباره حساب نمی‌شه
    assert ses.get(db.User, 1).hop_points == 250_000_000_000


def test_existing_user_not_counted(ses):
    mkuser(ses, 1); mkuser(ses, 2)
    assert R.register(ses, tg(2), "1", existed_before=True) is None
    assert ses.get(db.User, 1).hop_points == 0


def test_never_hopped_rule(ses):
    mkuser(ses, 1); mkuser(ses, 2); mkuser(ses, 3, hop_count=5)
    db.cfg_set(ses, "ref_new_rule", "never_hopped")
    assert R.register(ses, tg(2), "1", existed_before=True)                   # حسابِ قدیمی ولی هیچ‌وقت هاپ نزده
    assert R.register(ses, tg(3), "1", existed_before=True) is None           # قبلاً هاپ کرده


def test_self_bot_and_unknown_inviter(ses):
    mkuser(ses, 1)
    assert R.register(ses, tg(1), "1", False) is None
    assert R.register(ses, tg(5), "777", False) is None                       # دعوت‌کننده وجود نداره
    assert R.register(ses, tg(6), "abc", False) is None
    b = tg(7); b.is_bot = True
    assert R.register(ses, b, "1", False) is None


def test_reward_configurable_and_disable(ses):
    mkuser(ses, 1)
    db.cfg_set(ses, "ref_reward_hop", "1000")
    assert R.register(ses, tg(2), "1", False)["hop"] == 1000
    db.cfg_set(ses, "ref_enabled", "0")
    assert R.register(ses, tg(3), "1", False) is None
    assert ses.get(db.User, 1).hop_points == 1000


def test_caps(ses):
    mkuser(ses, 1)
    db.cfg_set(ses, "ref_daily_cap", "2")
    assert R.register(ses, tg(2), "1", False) and R.register(ses, tg(3), "1", False)
    assert R.register(ses, tg(4), "1", False) is None
    db.cfg_set(ses, "ref_daily_cap", "0"); db.cfg_set(ses, "ref_total_cap", "2")
    assert R.register(ses, tg(5), "1", False) is None


def test_stats_and_links(ses):
    mkuser(ses, 1)
    R.register(ses, tg(2), "1", False); R.register(ses, tg(3), "1", False)
    st = R.stats(ses, 1)
    assert st["count"] == 2 and st["hop"] == 500_000_000_000 and len(st["last"]) == 2
    assert R.link(BOT, 1) == "https://t.me/HopBot?start=ref_1"
    url = R.add_group_url(BOT, ses)
    assert url.startswith("https://t.me/HopBot?startgroup=hopadd&admin=") and "delete_messages" in url and " " not in url
    assert "t.me/share/url?" in R.share_url(BOT, 1, ses)


def test_panel_shows_link_stats_and_mentions(ses):
    mkuser(ses, 1); mkuser(ses, 2)
    R.register(ses, tg(2), "1", False)
    text, rows = UI.panel_view(ses, 1, BOT)
    assert "start=ref_1" in text and "250,000,000,000" in text and "دعوت‌شده‌ها: 1" in text
    import mentions
    assert mentions.has(text)                                                 # اسم به‌صورتِ منشن
    labels = [b[0] for r in rows for b in r]
    assert any("افزودنِ من به گروه" in l for l in labels)
    assert any(b[1].startswith("url:https://t.me/HopBot?startgroup") for r in rows for b in r)


def test_validate_cfg():
    assert R.validate_cfg("ref_reward_hop", "5000") == "5000"
    for k, v in (("ref_reward_hop", "-1"), ("ref_new_rule", "x"), ("ref_add_admin_rights", "Bad Rights!"), ("ref_msg_inviter", "{خراب"), ("bogus", "1"),
                 ("ref_enabled", "2")):
        with pytest.raises(ValueError):
            R.validate_cfg(k, v)


def test_display_name_is_mention_not_username(ses):
    import mentions
    mkuser(ses, 1)
    u = ses.get(db.User, 1)
    assert "@" not in mentions.plain(u.display_name())
    assert mentions.plain(u.display_name()) == "U1"
    mkuser(ses, 2, )
    u2 = ses.get(db.User, 2); u2.first_name = None; ses.commit()
    assert mentions.plain(u2.display_name()) == "u2"
