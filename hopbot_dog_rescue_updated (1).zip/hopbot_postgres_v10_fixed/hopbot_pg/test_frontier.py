# -*- coding: utf-8 -*-
"""
تست‌های «🌌 Frontier». اجرا:  python -m pytest test_frontier.py -q -o asyncio_mode=auto
روی SQLite موقت اجرا می‌شن؛ با DATABASE_URL=postgresql://... روی PostgreSQL هم اجرا می‌شن (همین فایل).
"""
import asyncio
import datetime
import json
import os
import tempfile
import types

os.environ.setdefault("BOT_TOKEN", "1:x")
os.environ.setdefault("OWNER_ID", "999")
if not os.environ.get("DATABASE_URL"):
    os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "frontier_test.db")

import pytest  # noqa: E402

import db  # noqa: E402
import war_db as W  # noqa: E402
import war_svc as S  # noqa: E402
import war_battle as B  # noqa: E402
import war_clan as C  # noqa: E402
import war_ui as UI  # noqa: E402
import frontier_db as F  # noqa: E402
import frontier_engine as FE  # noqa: E402
import frontier_svc as FS  # noqa: E402
import frontier_ui as FUI  # noqa: E402
import frontier_admin as FA  # noqa: E402
from war_svc import WarError  # noqa: E402

T0 = datetime.datetime(2026, 10, 1, 12, 0, 0)


class Clock:
    def __init__(self):
        self.t = T0

    def __call__(self):
        return self.t

    def adv(self, **kw):
        self.t += datetime.timedelta(**kw)
        return self.t


@pytest.fixture()
def clock(monkeypatch):
    c = Clock()
    for mod in (S, B, C, UI):
        monkeypatch.setattr(mod, "utcnow", c)
    return c


@pytest.fixture()
def ses(clock):
    db.Base.metadata.drop_all(db.engine)
    db.init_db()
    W.init_war()
    F.init_frontier()
    s = db.get_session()
    ev = s.query(F.FrontierEvent).filter_by(note="launch").first()      # هفته‌ی راه‌اندازی، هم‌زمان با ساعتِ تست
    ev.start_at, ev.end_at = T0 - datetime.timedelta(days=1), T0 + datetime.timedelta(days=6)
    s.commit()
    yield s
    s.rollback()
    s.close()


def mkplayer(s, uid, th=1, xp=8000, units=None, lvl=1, hop=1e10):
    s.add(db.User(telegram_id=uid, username=f"u{uid}", first_name=f"U{uid}", hop_points=hop))
    s.commit()
    p = S.get_player(s, uid)
    p.th_level, p.xp = th, xp
    for k in ("th",):
        b = s.query(W.WarBuilding).filter_by(user_id=uid, key=k).first()
        b.level = th
    for k, n in ({"infantry": 10} if units is None else units).items():
        u = s.query(W.WarUnit).filter_by(user_id=uid, unit_key=k).first()
        if not u:
            u = W.WarUnit(user_id=uid, unit_key=k, healthy=0, damaged=0, level=lvl)
            s.add(u)
        u.healthy, u.level = n, lvl
    p.fuel = 10
    s.commit()
    return p


def strong(s, uid, **kw):
    return mkplayer(s, uid, units={"drone": 15}, **kw)


def clear(s, uid, keys, clears=1):
    for k in keys:
        r = FS._prog(s, uid, k)
        r.clears = clears
    s.commit()


def go(s, clock, uid, node, route="assault", pct=100, resolve=True):
    p = S.get_player(s, uid)
    p.fuel = 10
    comp = FS.preset_comp(s, uid, pct)
    run, cost = FS.launch_run(s, p, node, route, comp)
    s.commit()
    if not resolve:
        return run, None, None
    clock.t = run.resolve_at + datetime.timedelta(seconds=1)
    ev = FS.resolve_run(s, run.id, clock.t)
    s.commit()
    return run, json.loads(s.get(F.FrontierRun, run.id).result_json or "{}"), ev


def mkclan(s, leader=1, name="Wolves", tag="WLF"):
    p = mkplayer(s, leader, th=3, units={"infantry": 20})
    c, _ = C.create_clan(s, p, name, tag)
    s.commit()
    return c


def join(s, clan, uid, units=None, xp=8000):
    p = mkplayer(s, uid, th=3, units=units or {"drone": 15}, xp=xp)
    r = C.send_request(s, p, clan.id)
    C.decide_request(s, clan.leader_id, r.id, True)
    s.commit()
    return p


# ------------------------------------------------------------------ ساختار / داده ----
def test_data_driven_content(ses):
    assert ses.query(F.FrontierRegion).count() >= 6
    for r in ses.query(F.FrontierRegion).all():
        kinds = {n.kind for n in FS.nodes_in(ses, r.key, enabled_only=False)}
        assert {"scout", "operation", "elite", "secret", "boss"} <= kinds
        assert sum(1 for n in FS.nodes_in(ses, r.key) if n.hidden) >= 2        # حداقل ۲ اتاقِ مخفی
    assert ses.query(F.FrontierBossDef).filter_by(is_event=False).count() == 6
    for b in ses.query(F.FrontierBossDef).all():
        assert len(FS.boss_phases(b)) >= 2
    assert ses.query(F.FrontierBossDef).filter_by(is_event=False).first() is not None
    assert len(FS.boss_phases(ses.get(F.FrontierBossDef, "boss_plains"))) >= 3


def test_init_is_idempotent_and_keeps_data(ses):
    mkplayer(ses, 1)
    n_nodes = ses.query(F.FrontierNode).count()
    F.init_frontier()
    F.init_frontier()
    assert ses.query(F.FrontierNode).count() == n_nodes
    assert ses.query(F.FrontierEvent).filter_by(note="launch").count() == 1      # ایونتِ راه‌اندازی فقط یک‌بار
    assert S.get_player(ses, 1, create=False) is not None                          # دیتای بازیکن دست‌نخورده


def test_admin_edits_survive_reinit(ses):
    ses.get(F.FrontierNode, "pl_scout").power = 123
    ses.commit()
    F.init_frontier()
    ses.expire_all()
    assert ses.get(F.FrontierNode, "pl_scout").power == 123


# ------------------------------------------------------------------ بازشدن مناطق ----
def test_first_region_open_second_locked(ses):
    p = mkplayer(ses, 1)
    assert FS.region_requirements(ses, p, FS.region_of(ses, "plains"))["open"]
    req = FS.region_requirements(ses, p, FS.region_of(ses, "ironwood"))
    assert not req["open"] and any(not ok for _t, ok in req["personal"] + req["base"])


def test_second_region_unlock_personal_path(ses):
    p = mkplayer(ses, 1, th=2)
    clear(ses, 1, ["pl_scout", "pl_op", "pl_elite", "pl_boss"])
    assert not FS.region_requirements(ses, p, FS.region_of(ses, "ironwood"))["open"]       # امتیاز کافی نیست
    FS._add_personal_points(ses, 1, "plains", 500)
    ses.commit()
    assert FS.region_requirements(ses, p, FS.region_of(ses, "ironwood"))["open"]
    assert [r.key for r in FS.pop_region_unlocks(ses, p)] == ["plains", "ironwood"]
    assert FS.pop_region_unlocks(ses, p) == []                                              # پیامِ بازشدن فقط یک‌بار


def test_second_region_needs_th(ses):
    p = mkplayer(ses, 1, th=1)
    clear(ses, 1, ["pl_scout", "pl_op", "pl_elite", "pl_boss"])
    FS._add_personal_points(ses, 1, "plains", 500)
    ses.commit()
    req = FS.region_requirements(ses, p, FS.region_of(ses, "ironwood"))
    assert not req["open"] and any(not ok for _t, ok in req["base"])


def test_clan_path_unlock_and_conditions_shown(ses):
    c = mkclan(ses, 1)
    ps = [join(ses, c, u) for u in (2, 3, 4)]
    for p in ps:
        p.th_level = 2
    ses.commit()
    for u in (1, 2, 3, 4):
        clear(ses, u, ["pl_scout"])
    cr = FS.clan_region_row(ses, c.id, "plains", create=True)
    cr.boss_down, cr.points = True, 2600
    ses.commit()
    req = FS.region_requirements(ses, ps[0], FS.region_of(ses, "ironwood"))
    assert req["open"] and req["via"] in ("clan", "personal")
    assert all(ok for _t, ok in req["clan"])
    cr.points = 100
    ses.commit()
    assert not FS.region_requirements(ses, ps[0], FS.region_of(ses, "ironwood"))["open"]
    assert any("امتیاز" in t for t, ok in FS.region_requirements(ses, ps[0], FS.region_of(ses, "ironwood"))["clan"])


def test_node_gating_requires_previous(ses):
    p = mkplayer(ses, 1)
    with pytest.raises(WarError):
        FS.launch_run(ses, p, "pl_elite", "assault", FS.preset_comp(ses, 1, 100))          # pl_op کلیر نشده
    with pytest.raises(WarError):
        FS.launch_run(ses, p, "pl_secret", "assault", FS.preset_comp(ses, 1, 100))         # اتاقِ مخفی کشف نشده


# ------------------------------------------------------------------ عملیات ----
def test_win_node_rewards_fuel_cost_units(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 30})
    hop0 = ses.get(db.User, 1).hop_points
    fuel0 = p.fuel
    mat0 = p.vault_mat
    run, res, ev = go(ses, clock, 1, "pl_scout")
    assert res["outcome"] == "win" and res["first_clear"]
    ses.expire_all()
    p = S.get_player(ses, 1)
    assert abs((fuel0 - 1.0) - (p.fuel - 0)) < 0.5 or p.fuel <= fuel0                      # سوخت کسر شد (بعدش ریژن)
    u = ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first()
    assert u.healthy + u.damaged == 30 - res["lost"]                                         # نیروها برگشتن، فقط تلفات کم شد
    assert ses.get(F.FrontierRun, run.id).status == "resolved"
    assert ses.query(F.FrontierProgress).filter_by(user_id=1, node_key="pl_scout").first().clears == 1
    assert res["rewards"]["hop"] > 0 and res["rewards"]["xp"] > 0
    assert ses.get(db.User, 1).hop_points != hop0                                            # هزینه کسر و پاداش واریز شده


def test_fuel_and_cost_deducted_on_launch(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 30})
    hop0 = ses.get(db.User, 1).hop_points
    run, cost = FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 100))
    ses.commit()
    assert abs(p.fuel - 9.0) < 1e-6
    assert cost > 0 and ses.get(db.User, 1).hop_points == hop0 - cost
    u = ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first()
    assert u.healthy == 0                                                                    # همه‌ی نیروها تو عملیات‌ان


def test_materials_deducted_for_logistics(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 30})
    p.vault_mat = 500
    ses.commit()
    run, _c = FS.launch_run(ses, p, "pl_scout", "logistics", FS.preset_comp(ses, 1, 100))
    ses.commit()
    assert p.vault_mat < 500 and (500 - p.vault_mat) >= 30                                  # حداقل ۱۰×۳ مواد


def test_insufficient_fuel_or_money(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 30})
    p.fuel = 0.2
    ses.commit()
    with pytest.raises(WarError):
        FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 100))
    p.fuel = 10
    ses.get(db.User, 1).hop_points = 0
    ses.commit()
    with pytest.raises(WarError):
        FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 100))


def test_defeat_returns_units_with_losses_and_consolation(ses, clock):
    mkplayer(ses, 1, units={"infantry": 3})
    clear(ses, 1, ["pl_scout", "pl_op"])
    run, res, _ = go(ses, clock, 1, "pl_elite")
    assert res["outcome"] == "lose"
    assert ses.query(F.FrontierProgress).filter_by(user_id=1, node_key="pl_elite").first().clears == 0
    u = ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first()
    assert u.healthy + u.damaged + res["lost"] == 3                                          # مصرفِ درستِ نیرو
    assert "first_clear" not in res


def test_routes_have_real_effects(ses, clock):
    p = strong(ses, 1)
    node = ses.get(F.FrontierNode, "pl_op")
    clear(ses, 1, ["pl_scout"])
    comp = FS.preset_comp(ses, 1, 100)
    a = FS.estimate(ses, p, comp, node, "assault")
    i = FS.estimate(ses, p, comp, node, "infiltration")
    l = FS.estimate(ses, p, comp, node, "logistics")
    assert a > i > l                                                                         # قدرتِ مؤثر: مستقیم > نفوذ > لجستیک
    rc = FS.routes_cfg(ses)
    assert rc["infiltration"]["cas"] < rc["assault"]["cas"] and rc["assault"]["pts"] > rc["infiltration"]["pts"]
    # نفوذ با ترکیبِ هوایی دفاعِ دشمن رو کم می‌کنه
    defs = {d.key: d for d in S.udefs(ses, enabled_only=False)}
    army_air = B.materialize(ses, 1, {"drone": 10})
    army_ground = {"infantry": {"h": 10, "d": 0}}
    assert FE.stealth_factor(army_air, defs, FS.stealth_cats(ses)) == 1.0
    assert FE.stealth_factor(army_ground, defs, FS.stealth_cats(ses)) == 0.0


def test_assault_more_points_infiltration_fewer_losses(ses, clock):
    mkplayer(ses, 1, units={"drone": 15})
    mkplayer(ses, 2, units={"drone": 15})
    _r1, r_a, _ = go(ses, clock, 1, "pl_scout", "assault")
    _r2, r_i, _ = go(ses, clock, 2, "pl_scout", "infiltration")
    assert r_a["outcome"] == r_i["outcome"] == "win"
    assert r_a["points"] > r_i["points"]


def test_logistics_creates_buff_and_next_run_uses_it(ses, clock):
    mkplayer(ses, 1, units={"infantry": 30})
    ses.query(W.WarPlayer).filter_by(user_id=1).first().vault_mat = 500
    ses.commit()
    _r, res, _ = go(ses, clock, 1, "pl_scout", "logistics")
    assert res["outcome"] == "support" and res["buff"]["pct"] > 0
    b = ses.query(F.FrontierBuff).filter_by(scope="user", scope_id=1).first()
    assert b and b.charges == 3
    run, _res, _ = go(ses, clock, 1, "pl_scout", "assault", resolve=False)
    assert json.loads(run.modifiers_json)["atk_extra"] > 1.0
    ses.expire_all()
    assert ses.query(F.FrontierBuff).filter_by(scope="user", scope_id=1).first().charges == 2


def test_logistics_buff_is_clan_wide(ses, clock):
    c = mkclan(ses, 1)
    join(ses, c, 2)
    ses.query(W.WarPlayer).filter_by(user_id=1).first().vault_mat = 500
    ses.commit()
    go(ses, clock, 1, "pl_scout", "logistics")
    assert ses.query(F.FrontierBuff).filter_by(scope="clan", scope_id=c.id).first() is not None
    run, _r, _e = go(ses, clock, 2, "pl_scout", "assault", resolve=False)
    assert json.loads(run.modifiers_json)["atk_extra"] > 1.0                                # عضوِ دیگه هم از باف استفاده می‌کنه


# ------------------------------------------------------------------ ایمنی / تکرار ----
def test_no_double_payment_on_double_resolve(ses, clock):
    mkplayer(ses, 1, units={"drone": 15})
    run, res, ev = go(ses, clock, 1, "pl_scout")
    hop = ses.get(db.User, 1).hop_points
    assert FS.resolve_run(ses, run.id, clock.t) is None                                      # Job دوم هیچ‌کاری نمی‌کنه
    ses.commit()
    assert ses.get(db.User, 1).hop_points == hop
    assert ses.query(F.FrontierRewardClaim).filter_by(user_id=1, claim_key="first:pl_scout").count() == 1


def test_tick_idempotent_and_restart_recovery(ses, clock):
    mkplayer(ses, 1, units={"drone": 15})
    run, _, _ = go(ses, clock, 1, "pl_scout", resolve=False)
    rid = run.id
    ses.close()                                                                              # «ری‌استارتِ ربات»: همه‌چیز فقط تو دیتابیسه
    clock.t = run.resolve_at + datetime.timedelta(seconds=5)
    ev1 = FS.run_tick(clock.t)
    ev2 = FS.run_tick(clock.t)
    assert any(e["type"] == "fr_run" and e["run_id"] == rid for e in ev1)
    assert not any(e["type"] == "fr_run" for e in ev2)
    s2 = db.get_session()
    try:
        assert s2.get(F.FrontierRun, rid).status == "resolved"
        assert s2.query(F.FrontierRewardClaim).filter_by(user_id=1, claim_key="first:pl_scout").count() == 1
    finally:
        s2.close()


def test_runs_not_due_are_untouched(ses, clock):
    mkplayer(ses, 1)
    run, _, _ = go(ses, clock, 1, "pl_scout", resolve=False)
    ev = FS.run_tick(clock.t)                                                                # هنوز موعدش نرسیده
    assert not any(e["type"] == "fr_run" for e in ev)
    ses.expire_all()
    assert ses.get(F.FrontierRun, run.id).status == "marching"


def test_no_parallel_runs_same_node_and_max_runs(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 30})
    FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 50))
    ses.commit()
    with pytest.raises(WarError):
        FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 50))            # همون مرحله، هم‌زمان
    clear(ses, 1, ["pl_scout"])
    FS.launch_run(ses, p, "pl_op", "assault", FS.preset_comp(ses, 1, 40))
    ses.commit()
    clear(ses, 1, ["pl_op"])
    with pytest.raises(WarError):
        FS.launch_run(ses, p, "pl_elite", "assault", FS.preset_comp(ses, 1, 20))            # سقفِ عملیاتِ هم‌زمان (۲)


def test_no_double_use_of_units(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 10})
    FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 100))
    ses.commit()
    clear(ses, 1, ["pl_scout"])
    with pytest.raises(WarError):
        FS.launch_run(ses, p, "pl_op", "assault", FS.preset_comp(ses, 1, 100))             # نیرویی نمونده


def test_housing_counts_units_on_frontier_run(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 10})
    before = S.housing_used(ses, 1)
    FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 100))
    ses.commit()
    assert S.housing_used(ses, 1) == before


def test_repeat_rewards_diminish_and_daily_cap(ses, clock):
    db.cfg_set(ses, "frontier_daily_cap_ref_hours", "0.3")                                   # سقفِ کوچک تا تو چند اجرا برسیم بهش
    db.cfg_set(ses, "frontier_daily_cap_th_bonus", "0")
    ses.commit()
    mkplayer(ses, 1, units={"drone": 15})
    go(ses, clock, 1, "pl_scout")                                                            # کلیرِ اول
    ref = S.player_ref(ses, S.get_player(ses, 1))
    cap_h = FS.daily_cap_hours(ses, S.get_player(ses, 1))
    hops = []
    for _ in range(30):
        ses.query(W.WarUnit).filter_by(user_id=1, unit_key="drone").first().healthy = 15      # (تلفات رو جبران می‌کنیم تا فقط سقف تست بشه)
        ses.commit()
        _r, res, _e = go(ses, clock, 1, "pl_scout")
        hops.append(res["rewards"].get("hop", 0))
    assert hops[1] < hops[0] and hops[3] < hops[1]                                           # بازده‌ی نزولی
    total_h = sum(hops) / ref
    assert total_h <= cap_h + 0.01                                                           # سقفِ روزانه
    assert hops[-1] == 0                                                                     # بعد از سقف: هاپ صفر (فارمِ نامحدود ممکن نیست)
    clock.adv(days=1)
    ses.query(W.WarUnit).filter_by(user_id=1, unit_key="drone").first().healthy = 15
    ses.commit()
    _r, res, _e = go(ses, clock, 1, "pl_scout")
    assert res["rewards"]["hop"] > 0                                                         # فردا دوباره


def test_member_daily_point_cap(ses, clock):
    p = mkplayer(ses, 1)
    season = FS.current_season(ses)
    total = sum(FS.add_points(ses, p, season, "plains", 100) for _ in range(30))
    assert total <= 600.0 + 1e-6
    clock.adv(days=1)
    assert FS.add_points(ses, p, season, "plains", 100) > 0


def test_capped_points_function():
    assert FE.capped_points(0, 100, 600, 0.7, 0.5) == 100
    assert FE.capped_points(400, 100, 600, 0.7, 0.5) == pytest.approx(20 + 40)               # ۲۰ کامل + ۸۰×۰٫۵
    assert FE.capped_points(600, 50, 600, 0.7, 0.5) == 0


# ------------------------------------------------------------------ باس ----
def prep_boss_ready(ses, uid):
    clear(ses, uid, ["pl_scout", "pl_op", "pl_elite"])


def test_boss_requires_prerequisites(ses, clock):
    p = strong(ses, 1)
    with pytest.raises(WarError):
        FS.launch_boss(ses, p, "boss_plains", "assault", FS.preset_comp(ses, 1, 100))


def test_boss_damage_hp_and_phase(ses, clock):
    p = strong(ses, 1)
    prep_boss_ready(ses, 1)
    run, _c = FS.launch_boss(ses, p, "boss_plains", "assault", FS.preset_comp(ses, 1, 100))
    ses.commit()
    st = ses.get(F.FrontierBossState, run.boss_state_id)
    assert st.scope == "user" and st.hp_max == 5_000_000 * 0.15                             # نسخه‌ی شخصی
    clock.t = run.resolve_at + datetime.timedelta(seconds=1)
    FS.resolve_run(ses, run.id, clock.t)
    ses.commit()
    ses.expire_all()
    st = ses.get(F.FrontierBossState, st.id)
    res = json.loads(ses.get(F.FrontierRun, run.id).result_json)
    assert res["damage"] > 0 and st.hp == pytest.approx(st.hp_max - res["damage"])
    assert ses.query(F.FrontierBossAttack).filter_by(run_id=run.id).count() == 1
    ph = FS.boss_phases(ses.get(F.FrontierBossDef, "boss_plains"))
    assert FE.phase_of(ph, st.hp_max, st.hp_max)[0] == 0 and FE.phase_of(ph, st.hp_max * 0.5, st.hp_max)[0] == 1 \
        and FE.phase_of(ph, st.hp_max * 0.1, st.hp_max)[0] == 2


def test_boss_phase_weakness_changes_damage():
    boss = {"defense": 650, "resist": {"air": 1.15, "armor": 0.85}}
    p = FE.E.Params.from_dict({k: v for k, v in W.FORMULA_KEYS.items()})
    units = lambda: [FE.E.Unit("drone", "air", 42, 14, healthy=15)]
    fx = FE.route_effects(F.ROUTES_DEFAULT["assault"], 0.0)
    base = {"name": "a", "def": 1.0, "ret": 1.0, "weak": "", "weak_mult": 1.0}
    weak = dict(base, weak="air", weak_mult=1.5)
    d1 = FE.boss_attack(7, units(), boss, base, p, 100, fx)["damage"]
    d2 = FE.boss_attack(7, units(), boss, weak, p, 100, fx)["damage"]
    assert d2 > d1 * 1.3


def test_boss_kill_unlocks_and_pays_once(ses, clock):
    p = strong(ses, 1, th=2)
    prep_boss_ready(ses, 1)
    bd = ses.get(F.FrontierBossDef, "boss_plains")
    st = FS.get_boss_state(ses, bd, p)
    st.hp = 10.0
    ses.commit()
    run, _c = FS.launch_boss(ses, p, "boss_plains", "assault", FS.preset_comp(ses, 1, 100))
    ses.commit()
    clock.t = run.resolve_at + datetime.timedelta(seconds=1)
    ev = FS.resolve_run(ses, run.id, clock.t)
    ses.commit()
    res = json.loads(ses.get(F.FrontierRun, run.id).result_json)
    assert res["killed"]
    assert any(e["type"] == "fr_boss_down" for e in ev)
    ses.expire_all()
    st = ses.get(F.FrontierBossState, st.id)
    assert st.status == "defeated" and st.paid
    pr = ses.query(F.FrontierProgress).filter_by(user_id=1, node_key="pl_boss").first()
    assert pr and pr.clears == 1
    claims = {c.claim_key for c in ses.query(F.FrontierRewardClaim).filter_by(user_id=1).all()}
    assert {"first:pl_boss", f"kill:{st.id}", "region:plains"} <= claims
    assert ses.query(F.FrontierHonor).filter_by(user_id=1, key="plains_conqueror").count() == 1
    FS._add_personal_points(ses, 1, "plains", 500)
    ses.commit()
    assert FS.region_requirements(ses, S.get_player(ses, 1), FS.region_of(ses, "ironwood"))["open"]      # منطقه‌ی بعدی باز شد
    with pytest.raises(WarError):
        FS.launch_boss(ses, S.get_player(ses, 1), "boss_plains", "assault", FS.preset_comp(ses, 1, 100))  # شکست‌خورده؛ حمله‌ی مجدد نه
    n = ses.query(F.FrontierRewardClaim).filter_by(user_id=1).count()
    FS._boss_defeated(ses, st, bd, FS.region_of(ses, "plains"), FS.current_season(ses), clock.t)        # فراخوانیِ دوباره
    ses.commit()
    assert ses.query(F.FrontierRewardClaim).filter_by(user_id=1).count() == n                         # پاداشِ تکراری نیست


def test_clan_boss_shared_hp_and_simultaneous_kill_pays_once(ses, clock):
    c = mkclan(ses, 1)
    ps = [join(ses, c, u) for u in (2, 3)]
    for u in (1, 2, 3):
        mkplayer if False else None
    ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first().healthy = 0
    s1 = S.get_player(ses, 1)
    ses.add(W.WarUnit(user_id=1, unit_key="drone", healthy=15, damaged=0, level=1))
    ses.commit()
    for u in (1, 2, 3):
        prep_boss_ready(ses, u)
    bd = ses.get(F.FrontierBossDef, "boss_plains")
    st = FS.get_boss_state(ses, bd, S.get_player(ses, 1))
    assert st.scope == "clan" and st.hp_max == 5_000_000                                    # یک HPِ مشترک
    st.hp = 20.0
    ses.commit()
    runs = []
    for u in (1, 2, 3):
        r, _c = FS.launch_boss(ses, S.get_player(ses, u), "boss_plains", "assault", FS.preset_comp(ses, u, 100))
        runs.append(r)
    ses.commit()
    assert len({r.boss_state_id for r in runs}) == 1
    clock.t = max(r.resolve_at for r in runs) + datetime.timedelta(seconds=1)
    evs = []
    for r in runs:
        evs += FS.resolve_run(ses, r.id, clock.t) or []
        ses.commit()
    assert sum(1 for e in evs if e["type"] == "fr_boss_down") == 1                           # فقط یک‌بار شکست
    outs = [json.loads(ses.get(F.FrontierRun, r.id).result_json)["outcome"] for r in runs]
    assert outs.count("void") >= 1                                                           # بعد از مرگ، حمله‌ها لغو و برگشتی
    ses.expire_all()
    for u in (1, 2, 3):
        assert ses.query(F.FrontierRewardClaim).filter_by(user_id=u, claim_key=f"kill:{st.id}").count() <= 1
    assert FS.clan_region_row(ses, c.id, "plains").boss_down


def test_boss_void_refunds_when_left_clan(ses, clock):
    c = mkclan(ses, 1)
    p2 = join(ses, c, 2)
    prep_boss_ready(ses, 2)
    run, cost = FS.launch_boss(ses, p2, "boss_plains", "assault", FS.preset_comp(ses, 2, 100))
    ses.commit()
    m = C.member_of(ses, 2)
    ses.delete(m)
    p2.clan_id = None
    ses.commit()
    clock.t = run.resolve_at + datetime.timedelta(seconds=1)
    FS.resolve_run(ses, run.id, clock.t)
    ses.commit()
    res = json.loads(ses.get(F.FrontierRun, run.id).result_json)
    assert res["outcome"] == "void"
    ses.expire_all()
    refund = ses.query(W.HopTransaction).filter_by(user_id=2, type="REFUND").all()
    assert len(refund) == 1 and refund[0].amount == cost                                      # هزینه کامل برگشت
    assert ses.query(W.WarUnit).filter_by(user_id=2, unit_key="drone").first().healthy == 15  # نیروها برگشت


def test_boss_reward_share_cap_and_min_level(ses, clock):
    c = mkclan(ses, 1)
    for u in (2, 3, 4):
        join(ses, c, u)
    join(ses, c, 5)
    S.get_player(ses, 5).xp = 0                                                              # حسابِ تازه‌ساز: سطحِ ۱
    ses.commit()
    bd = ses.get(F.FrontierBossDef, "boss_plains")
    st = FS.get_boss_state(ses, bd, S.get_player(ses, 1))
    for uid, dmg in ((1, 700.0), (2, 100.0), (3, 100.0), (4, 100.0), (5, 100.0)):
        for i in range(2):
            ses.add(F.FrontierBossAttack(state_id=st.id, user_id=uid, run_id=uid * 100 + i, damage=dmg / 2, lost=0))
    st.hp, st.status = 0.0, "defeated"
    ses.commit()
    FS._boss_defeated(ses, st, bd, FS.region_of(ses, "plains"), FS.current_season(ses), clock.t)
    ses.commit()
    k = {u: ses.query(F.FrontierRewardClaim).filter_by(user_id=u, claim_key=f"kill:{st.id}").first() for u in (1, 2, 5)}
    assert k[5] is None                                                                      # حسابِ دوم/خالی: پاداش نمی‌گیره
    assert k[1].hop / k[2].hop < 1.7                                                         # سقفِ سهم (۳۵٪) → ۷۰٪ سهمِ خام ۲٫۴ برابر نمی‌شه


# ------------------------------------------------------------------ اتاق مخفی ----
def test_infiltration_gives_clue_with_pity(ses, clock):
    db.cfg_set(ses, "frontier_clue_pity", "1")
    ses.commit()
    mkplayer(ses, 1, units={"drone": 15})
    _r, res, _e = go(ses, clock, 1, "pl_scout", "infiltration")
    assert res["outcome"] == "win"
    assert FS.clue_count(ses, 1, "plains") >= 1
    _r, res, _e = go(ses, clock, 1, "pl_scout", "assault")                                    # حمله‌ی مستقیم سرنخ نمی‌ده
    assert FS.clue_count(ses, 1, "plains") == 1


def test_signal_flow_hint_correct_and_wrong(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 10})
    node = ses.get(F.FrontierNode, "pl_secret")
    for _ in range(3):
        FS.add_clue(ses, 1, "plains")
    ses.commit()
    info = FS.signal_info(ses, p, node)
    assert info["ready"] and info["hint"] is None and len(info["opts"]) == 3
    ans = FE.signal_answer(1, "pl_secret", 3)
    wrong = (ans + 1) % 3
    r = FS.answer_signal(ses, p, "pl_secret", wrong)
    ses.commit()
    assert not r["ok"] and FS.clue_count(ses, 1, "plains") == 2                              # تصمیمِ غلط یک سرنخ می‌سوزونه
    with pytest.raises(WarError):
        FS.answer_signal(ses, p, "pl_secret", ans)                                           # هنوز تیم برنگشته
    clock.adv(minutes=31)
    for _ in range(3):
        FS.add_clue(ses, 1, "plains")
    ses.commit()
    info = FS.signal_info(ses, p, node)
    assert info["hint"] is not None and info["hint"] != ans                                  # با سرنخِ کافی یک گزینه‌ی غلط حذف می‌شه
    r = FS.answer_signal(ses, p, "pl_secret", ans)
    ses.commit()
    assert r["ok"] and FS.has_room(ses, 1, "pl_secret")
    assert ses.query(F.FrontierRewardClaim).filter_by(user_id=1, claim_key="room:pl_secret").count() == 1
    with pytest.raises(WarError):
        FS.answer_signal(ses, p, "pl_secret", ans)                                           # دوباره کشف نمی‌شه
    # اتاقِ کشف‌شده قابل‌انتخابه (حالا requires pl_scout)
    clear(ses, 1, ["pl_scout"])
    st, _m = FS.node_state(ses, p, node, FS.progress_map(ses, 1), {"pl_secret"}, True, set())
    assert st == "open"


def test_signal_answer_depends_on_player_and_hidden_nodes_hidden(ses):
    answers = {FE.signal_answer(u, "pl_secret", 3) for u in range(1, 40)}
    assert len(answers) > 1                                                                  # پاسخ‌ها بینِ بازیکن‌ها فرق می‌کنه
    p = mkplayer(ses, 1)
    v = FS.region_view(ses, p, FS.region_of(ses, "plains"))
    assert all(not x["node"].hidden for x in v["nodes"])                                    # اتاق‌های مخفی تو نقشه نیستن


def test_clan_shared_intel_gives_hint(ses, clock):
    c = mkclan(ses, 1)
    join(ses, c, 2)
    p1 = S.get_player(ses, 1)
    for u in (1, 2):
        for _ in range(3):
            FS.add_clue(ses, u, "plains")
    ses.commit()
    info = FS.signal_info(ses, p1, ses.get(F.FrontierNode, "pl_secret"))
    assert info["clan_hint"] and info["hint"] is not None


# ------------------------------------------------------------------ رویدادها ----
def test_events_storm_treasure_and_launch_week(ses, clock):
    p = strong(ses, 1)
    node = ses.get(F.FrontierNode, "pl_op")
    clear(ses, 1, ["pl_scout"])
    base = FS.estimate(ses, p, FS.preset_comp(ses, 1, 100), node, "assault")
    ses.add(F.FrontierEvent(kind="storm", name="🌪", region_key="plains", power_mult=2.0, start_at=clock.t, end_at=clock.t + datetime.timedelta(hours=6)))
    ses.commit()
    storm = FS.estimate(ses, p, FS.preset_comp(ses, 1, 100), node, "assault")
    assert storm == pytest.approx(base / 2, rel=0.01)
    clock.adv(hours=7)
    assert FS.estimate(ses, p, FS.preset_comp(ses, 1, 100), node, "assault") == pytest.approx(base, rel=0.01)   # بعد از پایان: برمی‌گرده
    # گنجینه‌ی باستانی: اتاقِ مخفی بدونِ کشف باز می‌شه
    prog = FS.progress_map(ses, 1)
    assert FS.node_state(ses, p, ses.get(F.FrontierNode, "pl_vault"), prog, set(), True, set())[0] == "hidden"
    ses.add(F.FrontierEvent(kind="treasure", name="💎", node_key="pl_vault", region_key="plains", start_at=clock.t, end_at=clock.t + datetime.timedelta(hours=3)))
    ses.commit()
    assert "pl_vault" in FS.treasure_open_nodes(ses, clock.t)
    # هفته‌ی راه‌اندازی: پاداشِ کلیرِ اول ×۱٫۳۵
    ses.query(F.FrontierEvent).filter_by(kind="treasure").delete()
    ses.commit()
    mods = FS.event_mods(ses, "plains", clock.t)
    assert mods["reward"] == pytest.approx(1.35) and mods["xp"] == pytest.approx(1.35)


def test_event_disabled_and_awakening_boss(ses, clock):
    p = strong(ses, 1)
    prep_boss_ready(ses, 1)
    clear(ses, 1, ["ir_scout", "ir_op", "ir_elite"])
    e = F.FrontierEvent(kind="awakening", name="🔥", region_key="ironwood", boss_key="boss_ironwood_awake",
                        start_at=clock.t, end_at=clock.t + datetime.timedelta(hours=24))
    ses.add(e)
    ses.commit()
    assert FS.awakened_bosses(ses, clock.t)
    run, _c = FS.launch_boss(ses, p, "boss_ironwood_awake", "assault", FS.preset_comp(ses, 1, 100), event_id=e.id)
    ses.commit()
    st = ses.get(F.FrontierBossState, run.boss_state_id)
    assert st.event_id == e.id
    e.enabled = False
    ses.commit()
    clock.t = run.resolve_at + datetime.timedelta(seconds=1)
    FS.run_tick(clock.t)                                                                      # رویداد خاموش → باس منقضی
    ses.expire_all()
    assert ses.get(F.FrontierBossState, st.id).status == "expired"
    with pytest.raises(WarError):
        FS.launch_boss(ses, S.get_player(ses, 1), "boss_ironwood_awake", "assault", FS.preset_comp(ses, 1, 100), event_id=e.id)


# ------------------------------------------------------------------ فصل ----
def _score(ses, season, clan_id, uid, pts, runs=6):
    c = FS._contrib(ses, season.id, uid, clan_id)
    c.points, c.runs = pts, runs
    ses.commit()


def test_season_lifecycle_extend_and_new(ses, clock):
    s1 = FS.current_season(ses)
    assert s1.status == "active" and (s1.end_at - s1.start_at).days == 28
    FS.extend_season(ses, 1, s1.id, 7, "test")
    ses.commit()
    assert (s1.end_at - s1.start_at).days == 35
    clock.adv(days=36)
    FS.run_tick(clock.t)                                                                      # فصل تموم و فصلِ بعدی خودکار
    ses.expire_all()
    assert ses.get(F.FrontierSeason, s1.id).status == "ended"
    s2 = FS.current_season(ses)
    assert s2.id != s1.id and s2.status == "active"


def test_season_settlement_ranks_pays_once_and_keeps_permanent(ses, clock):
    c1 = mkclan(ses, 1, "Alpha", "AAA")
    join(ses, c1, 2)
    c2 = mkclan(ses, 10, "Bravo", "BBB")
    join(ses, c2, 11)
    season = FS.current_season(ses)
    for u in (1, 2):
        _score(ses, season, c1.id, u, 300)
    for u in (10, 11):
        _score(ses, season, c2.id, u, 100)
    clear(ses, 1, ["pl_scout"])
    ses.commit()
    hop1 = ses.get(db.User, 1).hop_points
    clock.adv(days=29)
    ev = FS.settle_season(ses, season, clock.t)
    ses.commit()
    assert ev and ev[0]["type"] == "fr_season_end"
    halls = ses.query(F.FrontierHall).filter_by(season_id=season.id).all()
    assert {h.clan_name for h in halls if h.bracket == "all"} == {"Alpha", "Bravo"}
    assert [h for h in halls if h.bracket == "all" and h.rank == 1][0].clan_name == "Alpha"
    assert ses.get(db.User, 1).hop_points > hop1                                              # جایزه‌ی رتبه‌ی ۱
    assert ses.query(F.FrontierHonor).filter_by(user_id=1, key="frontier_lord").count() == 1
    again = FS.settle_season(ses, ses.get(F.FrontierSeason, season.id), clock.t, force=True)
    ses.commit()
    assert again == []                                                                        # تسویه‌ی دوباره پرداخت نمی‌کنه
    assert ses.query(F.FrontierRewardClaim).filter_by(user_id=1, claim_key=f"season:{season.id}:rank").count() == 1
    assert ses.query(F.FrontierProgress).filter_by(user_id=1, node_key="pl_scout").first().clears == 1   # پیشرفتِ دائمی پاک نشد
    s2 = FS.current_season(ses)
    assert s2.id != season.id
    assert FS.leaderboard(ses, s2, None) == []                                                # امتیازِ رقابتی ریست


def test_season_requires_real_participation(ses, clock):
    c1 = mkclan(ses, 1, "Alpha", "AAA")
    season = FS.current_season(ses)
    _score(ses, season, c1.id, 1, 300, runs=1)                                                # فقط ۱ عملیات
    hop = ses.get(db.User, 1).hop_points
    clock.adv(days=29)
    FS.settle_season(ses, season, clock.t)
    ses.commit()
    assert ses.get(db.User, 1).hop_points == hop                                              # مفتخور جایزه نمی‌گیره


def test_clan_ranking_fair_to_small_clans_and_brackets():
    small = FE.clan_rating(3000, 5, 0.6, 1, 2, 5, 500, 40, 1000)
    big = FE.clan_rating(5000, 25, 0.6, 1, 2, 8, 500, 40, 1000)
    assert small > big                                                                       # قبیله‌ی کوچکِ فعال می‌تونه ببره
    assert FE.bracket_of(5, 8, 16) == "small" and FE.bracket_of(12, 8, 16) == "medium" and FE.bracket_of(25, 8, 16) == "large"


def test_leaderboard_brackets_and_my_rank(ses, clock):
    c1 = mkclan(ses, 1, "Alpha", "AAA")
    join(ses, c1, 2)
    c2 = mkclan(ses, 10, "Bravo", "BBB")
    season = FS.current_season(ses)
    _score(ses, season, c1.id, 1, 5000)
    _score(ses, season, c2.id, 10, 2000)
    rows = FS.leaderboard(ses, season, None)
    assert [r.clan_id for r in rows][0] == c1.id
    rk, row = FS.my_rank(ses, season, c2.id)
    assert rk == 2 and row.bracket == "small"


# ------------------------------------------------------------------ دستاورد / پیشگام / پاداش ----
def test_honors_unique_with_rarity(ses, clock):
    mkplayer(ses, 1, units={"drone": 15})
    go(ses, clock, 1, "pl_scout")
    assert ses.query(F.FrontierHonor).filter_by(user_id=1, key="first_explorer").count() == 1
    assert FS.grant_honor(ses, 1, "first_explorer") is None                                   # دستاوردِ تکراری صادر نمی‌شه
    hd = ses.get(F.FrontierHonorDef, "first_explorer")
    assert hd.rarity and hd.description
    h = ses.query(F.FrontierHonor).filter_by(user_id=1, key="first_explorer").first()
    assert h.earned_at is not None


def test_welcome_once_and_pioneer_ladder(ses, clock):
    p = mkplayer(ses, 1, units={"drone": 15})
    p.fuel = 2
    r = FS.welcome(ses, p)
    ses.commit()
    assert r and r["hop"] > 0 and p.fuel >= 10
    assert FS.welcome(ses, p) is None                                                         # فقط یک‌بار
    ps = {n: st for n, st, _d in FS.pioneer_state(ses, p)}
    assert ps[1] == "today" and ps[2] == "future"
    go(ses, clock, 1, "pl_scout")
    ps = {n: st for n, st, _d in FS.pioneer_state(ses, p)}
    assert ps[1] == "ready"
    FS.claim_pioneer(ses, p, 1)
    ses.commit()
    with pytest.raises(WarError):
        FS.claim_pioneer(ses, p, 1)
    clock.adv(days=4)
    assert {n: st for n, st, _d in FS.pioneer_state(ses, p)}[3] == "missed"


def test_quests_use_war_quest_system(ses, clock):
    mkplayer(ses, 1, units={"drone": 15})
    go(ses, clock, 1, "pl_scout")
    qs = {q.key: prog for q, prog, _c in S.quests_for(ses, S.get_player(ses, 1), "daily") if q.metric.startswith("fr_")}
    assert qs.get("fr_d_scout") == 1 and qs.get("fr_d_runs2") == 1


# ------------------------------------------------------------------ بتل‌پس / بخش‌های دیگر ----
def test_battlepass_items_and_injection(ses):
    import battlepass_db as BD
    BD.init_battlepass()
    s = db.get_session()
    try:
        import battlepass_engine as _EN0
        _EN0.current_season(s)
        s.commit()
        s.query(db.Config).filter(db.Config.key.in_(["_fr_bp_ch_v1", "_fr_bp_inject_v1"])).delete(synchronize_session=False)
        s.commit()
        n = FS.post_init(s)
        assert n > 0
        assert s.query(BD.BpChallengeDef).filter(BD.BpChallengeDef.metric.like("frontier_%")).count() >= 6
        assert s.query(BD.BpTierDef).filter(BD.BpTierDef.kind.like("fr_%")).count() > 0
        assert FS.post_init(s) == 0                                                           # یک‌بار؛ دوباره اضافه نمی‌کنه
    finally:
        s.close()
    mkplayer(ses, 5, units={"drone": 5})
    u = ses.get(db.User, 5)
    d = types.SimpleNamespace
    assert "سوخت" in FS.bp_deliver(ses, u, d(kind="fr_fuel", amount=6, pct=0, uses=0, minutes=0, label=""), "t")
    assert "قدرتِ" in FS.bp_deliver(ses, u, d(kind="fr_atk", amount=0, pct=15, uses=3, minutes=0, label=""), "t")
    assert ses.query(F.FrontierBuff).filter_by(scope="user", scope_id=5, kind="atk").first().pct == 15
    assert "مواد" in FS.bp_deliver(ses, u, d(kind="fr_mats", amount=150, pct=0, uses=0, minutes=0, label=""), "t")
    assert "سرنخ" in FS.bp_deliver(ses, u, d(kind="fr_clue", amount=1, pct=0, uses=0, minutes=0, label=""), "t")
    assert FS.clue_count(ses, 5, "plains") == 1
    import battlepass_engine as EN
    assert "frontier_runs" in EN.SOURCES and "fr_atk" in BD.KINDS


def test_purge_section_registered_and_rollup():
    import db_purge
    s = db.get_session()
    try:
        import datetime as dt
        names = [x[0] for x in db_purge._sections(s, dt.datetime(2026, 10, 1))]
        assert "frontier_run" in names
    finally:
        s.close()
    got = []
    acc = types.SimpleNamespace(add=lambda m, u, t: got.append((m, u)))
    db_purge._roll_frontier(acc, types.SimpleNamespace(user_id=3, created_at=T0, outcome="win", boss_state_id=None), {})
    assert ("frontier_runs", 3) in got and ("frontier_wins", 3) in got


def test_stuck_run_expiry_refunds(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 30})
    run, cost = FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 100))
    ses.commit()
    hop = ses.get(db.User, 1).hop_points
    clock.adv(hours=30)
    assert FS.expire_stuck(ses, clock.t) == 1
    ses.commit()
    assert ses.get(F.FrontierRun, run.id).status == "cancelled"
    assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first().healthy == 30
    assert ses.get(db.User, 1).hop_points == hop + cost * 0.5


# ------------------------------------------------------------------ UI / امنیت ----
class FakeQ:
    def __init__(self, data):
        self.data = data
        self.answers = []

    async def answer(self, text=None, show_alert=False):
        self.answers.append((text, show_alert))


def fake_update(uid, data):
    q = FakeQ(data)
    return types.SimpleNamespace(callback_query=q, effective_user=types.SimpleNamespace(id=uid),
                                 effective_chat=types.SimpleNamespace(id=uid, type="private"), message=None), q


def test_callback_owner_validation(ses):
    mkplayer(ses, 1)
    upd, q = fake_update(2, "fr:map:1")
    assert asyncio.run(FUI.fr_callback_router(upd, types.SimpleNamespace())) is True
    assert q.answers and q.answers[0][1] is True and "🚫" in q.answers[0][0]                  # پنلِ دیگری
    upd, q = fake_update(1, "fr:garbage")
    assert asyncio.run(FUI.fr_callback_router(upd, types.SimpleNamespace())) is True


def test_other_users_cannot_read_my_report(ses, clock):
    mkplayer(ses, 1, units={"drone": 15})
    mkplayer(ses, 2)
    run, _res, _ = go(ses, clock, 1, "pl_scout")
    p2 = S.get_player(ses, 2)
    with pytest.raises(WarError):
        FUI.p_report(ses, p2, run_id=run.id)
    text, _kb = FUI.p_report(ses, S.get_player(ses, 1), run_id=run.id)
    assert "گزارش" in text or "عملیات" in text


def test_launch_via_ui_token_is_single_use_and_server_validated(ses, clock):
    mkplayer(ses, 1, units={"infantry": 30})
    p = S.get_player(ses, 1)
    text, kb = FUI.p_confirm(ses, p, key="pl_scout", route="assault", pct=100, boss=0, event=0)
    ses.commit()
    tok = kb[0][0].callback_data.split(":")[3]
    upd, _q = fake_update(1, "x")
    toast, nxt = asyncio.run(FUI._act(ses, types.SimpleNamespace(), upd, p, "go", [tok]))
    ses.commit()
    assert "آغاز" in toast and nxt == "ops"
    with pytest.raises(WarError):
        asyncio.run(FUI._act(ses, types.SimpleNamespace(), upd, p, "go", [tok]))              # توکن یک‌بارمصرف
    with pytest.raises(WarError):
        asyncio.run(FUI._act(ses, types.SimpleNamespace(), upd, p, "confirm", ["pl_scout", "hack", "100", "0", "0"]))   # مسیرِ نامعتبر
    with pytest.raises(WarError):
        asyncio.run(FUI._act(ses, types.SimpleNamespace(), upd, p, "confirm", ["pl_scout", "assault", "999", "0", "0"]))


def test_all_panels_render_and_buttons_are_real(ses, clock):
    p = strong(ses, 1)
    c = mkclan(ses, 5)
    for name in ("home", "map", "explore", "ops", "boss", "clan", "board", "honors", "lore", "locked", "rewards"):
        text, kb = FUI.PANELS[name](ses, p)
        assert text
        for row in kb:
            for b in row:
                assert b.callback_data.startswith("fr:") and len(b.callback_data.encode()) <= 64
                assert b.callback_data.split(":")[1] in set(FUI.PANELS) | {"go", "sig", "pio", "qclaim", "cancel", "war", "warclan"}
    text, kb = FUI.p_region(ses, p, key="plains")
    assert "اردوگاه متروکه" in text
    text, kb = FUI.p_node(ses, p, key="pl_scout")
    text, kb = FUI.p_route(ses, p, key="pl_scout")
    text, kb = FUI.p_army(ses, p, key="pl_scout", route="assault", boss=0, event=0)
    text, kb = FUI.p_confirm(ses, p, key="pl_scout", route="assault", pct=100, boss=0, event=0)
    assert any("go" in b.callback_data for r in kb for b in r)
    clear(ses, 1, ["pl_scout", "pl_op", "pl_elite"])
    text, kb = FUI.p_bossview(ses, p, key="boss_plains")
    assert "نگهبانِ دشت" in text and "فازِ" in text
    text, kb = FUI.p_route(ses, p, key="boss_plains", boss=True)
    assert len(kb) >= 3


def test_locked_feature_shown_with_condition(ses):
    p = mkplayer(ses, 1, xp=0)
    text, kb = FUI.p_home(ses, p)
    assert "قفل" in text and "سطح" in text


# ------------------------------------------------------------------ ادمین ----
def test_admin_event_boss_run_tools_require_reason_and_audit(ses, clock):
    p = strong(ses, 1)
    prep_boss_ready(ses, 1)
    upd = types.SimpleNamespace(message=types.SimpleNamespace(get_bot=lambda: None))

    def h(kind, text):
        return asyncio.run(FA.handle_input(ses, upd, {"kind": kind}, text, 999))

    out = h("event", "storm glass 6 1.25 1.3 1")
    ses.commit()
    assert "فعال شد" in out and ses.query(F.FrontierEvent).filter_by(kind="storm").count() == 1
    with pytest.raises(WarError):
        h("event", "storm nowhere 6 1 1 1")
    run, _c = FS.launch_boss(ses, p, "boss_plains", "assault", FS.preset_comp(ses, 1, 100))
    ses.commit()
    sid = run.boss_state_id
    with pytest.raises(WarError):
        h("boss", f"hp {sid} 1000")                                                           # دلیل لازمه
    assert "HP" in h("boss", f"hp {sid} 1000 کالیبراسیون")
    ses.commit()
    assert ses.get(F.FrontierBossState, sid).hp == 1000
    assert "لغو" in h("run", f"{run.id} باگ")
    ses.commit()
    assert ses.get(F.FrontierRun, run.id).status == "cancelled"
    audits = ses.query(W.WarAudit).filter(W.WarAudit.action.like("admin_frontier%")).count()
    assert audits >= 3
    out = h("season_new", "14 فصلِ تازه")
    ses.commit()
    assert "شروع شد" in out
    assert FS.current_season(ses).end_at - FS.current_season(ses).start_at == datetime.timedelta(days=14)


def test_admin_config_validation_and_toggle(ses):
    import war_admin as WA
    assert WA.validate_cfg("frontier_routes", "{bad") != ""
    assert WA.validate_cfg("frontier_daily_cap_ref_hours", "abc") != ""
    assert WA.validate_cfg("frontier_daily_cap_ref_hours", "6") == ""
    assert "admin_war_fr" in WA.ADMIN_WAR_CALLBACKS and "admin_war_tbl" in WA.ADMIN_WAR_CALLBACKS
    assert "fr_region" in WA.TABLES and "fr_node" in WA.TABLES and "fr_boss" in WA.TABLES
    db.cfg_set(ses, "frontier_enabled", "0")
    ses.commit()
    p = mkplayer(ses, 1)
    with pytest.raises(WarError):
        FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 100))


# ------------------------------------------------------------------ لغوِ بازیکن / تمرکزِ ارتش ----
def test_player_cancel_refunds_partially_and_is_owner_only(ses, clock):
    p = mkplayer(ses, 1, units={"infantry": 30})
    mkplayer(ses, 2)
    hop0 = ses.get(db.User, 1).hop_points
    run, cost = FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 100))
    ses.commit()
    with pytest.raises(WarError):
        FS.player_cancel(ses, S.get_player(ses, 2), run.id)                                  # عملیاتِ دیگری
    FS.player_cancel(ses, p, run.id)
    ses.commit()
    ses.expire_all()
    assert ses.get(F.FrontierRun, run.id).status == "cancelled"
    assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first().healthy == 30   # نیروها ۱۰۰٪
    assert ses.get(db.User, 1).hop_points == pytest.approx(hop0 - cost / 2)                  # فقط ۵۰٪ هزینه برمی‌گرده
    assert p.fuel == pytest.approx(9.5)
    with pytest.raises(WarError):
        FS.player_cancel(ses, p, run.id)                                                     # دوباره نه
    clock.t = run.resolve_at + datetime.timedelta(seconds=5)
    assert FS.resolve_run(ses, run.id, clock.t) is None                                      # لغوشده حل نمی‌شه
    ses.commit()
    assert not any(e["type"] == "fr_run" for e in FS.run_tick(clock.t))


def test_army_focus_modes_filter_by_category(ses):
    mkplayer(ses, 1, units={"infantry": 10, "drone": 6, "tank": 2})
    air = FS.preset_comp(ses, 1, 100, mode="air")
    ground = FS.preset_comp(ses, 1, 100, mode="ground")
    assert set(air) == {"drone"} and set(ground) == {"infantry", "tank"}
    assert set(FS.preset_comp(ses, 1, 100)) == {"infantry", "drone", "tank"}
    assert FS.preset_comp(ses, 1, 50, mode="air") == {"drone": 3}


def test_ui_full_click_flow_through_router(ses, clock):
    mkplayer(ses, 1, units={"infantry": 20, "drone": 5})
    log = []

    async def fake_send(update, text, kb=None):
        log.append((text, kb))

    orig = UI.send
    UI.send = fake_send
    try:
        def click(data):
            upd, q = fake_update(1, data)
            asyncio.run(FUI.fr_callback_router(upd, types.SimpleNamespace()))
            return q, log[-1] if log else (None, None)

        def buttons():
            return [b.callback_data for r in log[-1][1].inline_keyboard for b in r]

        click("fr:home:1")
        assert "مرزهای هاپویی" in log[-1][0] and any(d.startswith("fr:map") for d in buttons())
        click("fr:region:1:plains")
        assert any(d.startswith("fr:node:1:pl_scout") for d in buttons())
        click("fr:node:1:pl_scout")
        click("fr:route:1:pl_scout")
        assert sum(1 for d in buttons() if d.startswith("fr:army")) == 3                     # سه مسیر
        click("fr:army:1:pl_scout:assault:0:0")
        assert any("fr:army" in d and d.endswith(":air") for d in buttons())                  # دکمه‌ی تمرکزِ هوایی
        click("fr:army:1:pl_scout:assault:0:0:air")
        assert "هوایی" in log[-1][0]
        click("fr:confirm:1:pl_scout:assault:100:0:0:air")
        tok = [d for d in buttons() if d.startswith("fr:go")][0]
        q, _ = click(tok)
        assert q.answers and "آغاز" in q.answers[0][0]
        assert ses.query(F.FrontierRun).filter_by(user_id=1, status="marching").count() == 1
        ses.expire_all()
        assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="drone").first().healthy == 0   # فقط هوایی‌ها رفتن
        assert ses.query(W.WarUnit).filter_by(user_id=1, unit_key="infantry").first().healthy == 20
        click("fr:ops:1")
        cancel = [d for d in buttons() if d.startswith("fr:cancel")]
        assert cancel
        q, _ = click(cancel[0])
        assert q.answers and "لغو" in q.answers[0][0]
        ses.expire_all()
        assert ses.query(F.FrontierRun).filter_by(user_id=1, status="marching").count() == 0
        q, _ = click("fr:confirm:1:pl_scout:assault:100:0:0:hack")                           # حالتِ نامعتبر سمتِ سرور رد می‌شه
        assert q.answers and q.answers[0][1] is True
    finally:
        UI.send = orig


def test_full_lock_below_unlock_level(ses):
    """زیرِ سطحِ آنلاک فقط «صفحه‌ی اصلی» و «مناطق قفل‌شده» (با شرط‌ها) در دسترسه؛ هیچ اقدام/پنلِ دیگه‌ای نه."""
    p = mkplayer(ses, 1, xp=0)
    assert S.player_level(ses, p) < 2 and S.feature_state(ses, p, "frontier") == "locked"
    upd, _q = fake_update(1, "x")
    ctx = types.SimpleNamespace()
    for a, args in (("home", []), ("locked", [])):
        asyncio.run(FUI._act(ses, ctx, upd, p, a, args))                                      # مجازه
    for a, args in (("map", []), ("lore", []), ("explore", []), ("region", ["plains"]), ("node", ["pl_scout"]), ("route", ["pl_scout"]),
                    ("boss", []), ("ops", []), ("clan", []), ("board", []), ("honors", []), ("rewards", []), ("go", ["x"]),
                    ("cancel", ["1"]), ("sig", ["pl_secret", "0"]), ("pio", ["1"])):
        with pytest.raises(WarError) as e:
            asyncio.run(FUI._act(ses, ctx, upd, p, a, args))
        assert "قفل" in str(e.value) and "سطح" in str(e.value)                                  # شرط به بازیکن گفته می‌شه
    with pytest.raises(WarError):
        FS.launch_run(ses, p, "pl_scout", "assault", FS.preset_comp(ses, 1, 100))             # سرویس هم جداگانه قفله
    S.get_player(ses, 1).xp = 8000
    ses.commit()
    asyncio.run(FUI._act(ses, ctx, upd, S.get_player(ses, 1), "map", []))                      # بعد از سطح ۲ باز می‌شه
