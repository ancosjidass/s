# -*- coding: utf-8 -*-
"""رویداد گروهیِ «سگ زندانی را نجات بده»؛ پایدار بین ری‌استارت‌ها."""
from __future__ import annotations

import asyncio
import datetime
import html
import logging
import random
import secrets
import threading
import weakref
from pathlib import Path

from sqlalchemy import (
    Column, Integer, BigInteger, Float, String, Boolean, DateTime,
    ForeignKey, UniqueConstraint, Index, text, select, func,
)
from sqlalchemy.exc import IntegrityError

import db
from db import Base, now

log = logging.getLogger(__name__)

# تنظیمات مرکزی
TICK_SECONDS = 180
SPAWN_CHANCE = 0.30
GROUP_COOLDOWN_MINUTES = 30
EVENT_DURATION_MINUTES = 5
WIN_COOLDOWN_HOURS = 6
COSTS = (100, 1000, 4000)
CHANCES = {100: 0.45, 1000: 0.50, 4000: 0.55}
BP_XP_BASE = {100: 25, 1000: 35, 4000: 45}
ASSET_DIR = Path(__file__).resolve().parent / "assets" / "dog_rescue"
IMAGES = {
    "prisoner": ASSET_DIR / "prisoner.png",
    "sad": ASSET_DIR / "sad.png",
    "happy": ASSET_DIR / "happy.png",
}
_EVENT_LOCK = threading.RLock()
_MESSAGE_LOCKS = weakref.WeakValueDictionary()
_LAST_PRUNE_AT = None
_MESSAGE_LOCKS_GUARD = threading.Lock()


def _message_lock(event_id: int):
    with _MESSAGE_LOCKS_GUARD:
        lock = _MESSAGE_LOCKS.get(int(event_id))
        if lock is None:
            lock = asyncio.Lock()
            _MESSAGE_LOCKS[int(event_id)] = lock
        return lock


class DogRescueEvent(Base):
    __tablename__ = "dog_rescue_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger, nullable=False, index=True)
    message_id = Column(BigInteger, nullable=True)
    status = Column(String(16), nullable=False, default="active", index=True)
    created_at = Column(DateTime, nullable=False, default=now, index=True)
    expires_at = Column(DateTime, nullable=False)
    closed_at = Column(DateTime, nullable=True)
    attempts_total = Column(Integer, nullable=False, default=0)
    attempts_100 = Column(Integer, nullable=False, default=0)
    attempts_1000 = Column(Integer, nullable=False, default=0)
    attempts_4000 = Column(Integer, nullable=False, default=0)
    won_by = Column(BigInteger, nullable=True)
    winner_name = Column(String(128), nullable=True)
    reward_xp = Column(Float, nullable=False, default=0)
    __table_args__ = (
        Index("uq_dog_rescue_one_active_per_chat", "chat_id", unique=True,
              sqlite_where=text("status = 'active'"),
              postgresql_where=text("status = 'active'")),
        Index("ix_dog_rescue_chat_created", "chat_id", "created_at"),
    )


class DogRescueAttempt(Base):
    __tablename__ = "dog_rescue_attempts"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("dog_rescue_events.id", ondelete="CASCADE"), nullable=False)
    user_id = Column(BigInteger, nullable=False)
    cost = Column(Integer, nullable=False)
    success = Column(Boolean, nullable=False, default=False)
    roll = Column(Float, nullable=False, default=0)
    created_at = Column(DateTime, nullable=False, default=now)
    __table_args__ = (
        UniqueConstraint("event_id", "user_id", name="uq_dog_rescue_event_user"),
        Index("ix_dog_rescue_attempt_user_created", "user_id", "created_at"),
    )


class DogRescueCooldown(Base):
    __tablename__ = "dog_rescue_cooldowns"
    user_id = Column(BigInteger, primary_key=True, autoincrement=False)
    last_win_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, nullable=False, default=now)


def init_dog_rescue():
    """ساخت افزایشیِ فقط جدول‌های این رویداد؛ داده‌های قبلی دست‌نخورده می‌مانند."""
    Base.metadata.create_all(
        db.engine,
        tables=[DogRescueEvent.__table__, DogRescueAttempt.__table__, DogRescueCooldown.__table__],
    )


def _keyboard(event_id: int):
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🪙 تلاش با ۱۰۰ هاپ | شانس ۴۵٪", callback_data=f"dogrescue:{event_id}:100")],
        [InlineKeyboardButton("🪙 تلاش با ۱۰۰۰ هاپ | شانس ۵۰٪", callback_data=f"dogrescue:{event_id}:1000")],
        [InlineKeyboardButton("🪙 تلاش با ۴۰۰۰ هاپ | شانس ۵۵٪", callback_data=f"dogrescue:{event_id}:4000")],
    ])


def _counts(event) -> str:
    return (f"🎯 تعداد تلاش‌ها: <b>{event.attempts_total}</b>\n"
            f"۱۰۰ هاپ: <b>{event.attempts_100}</b>  |  "
            f"۱۰۰۰ هاپ: <b>{event.attempts_1000}</b>  |  "
            f"۴۰۰۰ هاپ: <b>{event.attempts_4000}</b>")


def _caption(event, state="active") -> str:
    counts = _counts(event)
    if state == "rescued":
        name = html.escape(event.winner_name or "یک بازیکن")
        reward = f"\n🎖️ جایزه: <b>+{event.reward_xp:g} XP بتل‌پس</b>" if event.reward_xp > 0 else ""
        return f"🐶 <b>تموم شد! سگ نجات پیدا کرد!</b>\n🏆 نجات‌دهنده: {name}{reward}\n\n{counts}"
    if state == "lonely":
        return f"😢 <b>سگ تنها ماند...</b>\n۵ دقیقه گذشت و هیچ‌کس نتونست نجاتش بده.\n\n{counts}"
    return ("🐕 <b>سگ زندانی رو نجات بده!</b>\n"
            "⏳ فقط ۵ دقیقه فرصت داری؛ اولین تلاش موفق برنده می‌شه.\n"
            "هر بازیکن در این رویداد فقط یک‌بار می‌تونه تلاش کنه.\n\n" + counts)


def _snapshot(event, state=None):
    state = state or event.status
    return {"id": event.id, "chat_id": event.chat_id, "message_id": event.message_id,
            "caption": _caption(event, state)}


async def _edit_photo(bot, event_data: dict, state: str):
    from telegram import InputMediaPhoto
    image_path = IMAGES["happy" if state == "rescued" else "sad"]
    if not image_path.is_file():
        log.error("Dog Rescue image missing: %s", image_path)
        return
    with image_path.open("rb") as photo:
        media = InputMediaPhoto(media=photo, caption=event_data["caption"], parse_mode="HTML")
        await bot.edit_message_media(
            chat_id=event_data["chat_id"], message_id=event_data["message_id"],
            media=media, reply_markup=_keyboard(event_data["id"]) if state == "active" else None,
        )


async def _edit_latest(bot, event_id: int):
    """با قفلِ پیام، آخرین شمارنده/وضعیتِ دیتابیس را ادیت می‌کند تا ادیتِ قدیمی دیرتر ننشیند."""
    async with _message_lock(event_id):
        s = db.get_session()
        try:
            event = s.get(DogRescueEvent, event_id)
            if not event or event.message_id is None:
                return
            snapshot = _snapshot(event)
            state = event.status
        finally:
            s.close()
        if state in ("active", "rescued", "lonely"):
            await _edit_photo(bot, snapshot, state)


def _mark_send_failed(event_id: int):
    s = db.get_session()
    try:
        event = s.get(DogRescueEvent, event_id)
        if event and event.status == "active":
            event.status, event.closed_at = "send_failed", now()
            s.commit()
    except Exception:
        s.rollback()
        log.exception("Dog Rescue: could not mark failed send")
    finally:
        s.close()


async def _send_event(bot, event_id: int, chat_id: int):
    from telegram import InputFile
    path = IMAGES["prisoner"]
    if not path.is_file():
        log.error("Dog Rescue prisoner image missing: %s", path)
        _mark_send_failed(event_id)
        return
    s = db.get_session()
    try:
        event = s.get(DogRescueEvent, event_id)
        if not event or event.status != "active":
            return
        caption, keyboard = _caption(event), _keyboard(event_id)
    finally:
        s.close()
    try:
        with path.open("rb") as photo:
            msg = await bot.send_photo(chat_id=chat_id,
                photo=InputFile(photo, filename="dog_prisoner.png"),
                caption=caption, parse_mode="HTML", reply_markup=keyboard)
        should_refresh = False
        s = db.get_session()
        try:
            event = s.get(DogRescueEvent, event_id)
            if event:
                event.message_id = msg.message_id
                if event.status == "active" and event.expires_at <= now():
                    event.status, event.closed_at = "lonely", now()
                should_refresh = event.status in ("lonely", "rescued")
                s.commit()
        finally:
            s.close()
        if should_refresh:
            await _edit_latest(bot, event_id)
    except Exception:
        log.exception("Dog Rescue: failed to publish event in chat %s", chat_id)
        _mark_send_failed(event_id)


def _expire_events(session, nowt):
    rows = (session.query(DogRescueEvent)
            .filter(DogRescueEvent.status == "active", DogRescueEvent.expires_at <= nowt).all())
    snapshots = []
    for event in rows:
        event.status, event.closed_at = "lonely", nowt
        snapshots.append(_snapshot(event, "lonely"))
    if rows:
        session.commit()
    return snapshots


async def expire_job(context):
    """مهلت را هر ۱۰ ثانیه بررسی می‌کند تا پایانِ پنج‌دقیقه‌ای دقیق نمایش داده شود."""
    s = db.get_session()
    try:
        expired = _expire_events(s, now())
        expired_ids = [item["id"] for item in expired if item.get("message_id") is not None]
    except Exception:
        s.rollback()
        log.exception("Dog Rescue: expiry check failed")
        return
    finally:
        s.close()
    for event_id in expired_ids:
        try:
            await _edit_latest(context.bot, event_id)
        except Exception:
            log.exception("Dog Rescue: could not edit expired event %s", event_id)


def _prune_old_events(session, nowt):
    """نگه‌داریِ ۳۰روزه برایِ تاریخچه؛ جدول‌های رویداد/تلاش بی‌نهایت بزرگ نمی‌شوند."""
    global _LAST_PRUNE_AT
    if _LAST_PRUNE_AT and (nowt - _LAST_PRUNE_AT).total_seconds() < 86400:
        return
    cutoff = nowt - datetime.timedelta(days=30)
    stale_ids = select(DogRescueEvent.id).where(
        DogRescueEvent.created_at < cutoff, DogRescueEvent.status != "active")
    session.query(DogRescueAttempt).filter(DogRescueAttempt.event_id.in_(stale_ids)).delete(synchronize_session=False)
    session.query(DogRescueEvent).filter(DogRescueEvent.id.in_(stale_ids)).delete(synchronize_session=False)
    session.commit()
    _LAST_PRUNE_AT = nowt


async def tick_job(context):
    """هر سه دقیقه برای هر گروه، مستقل از بقیه، شانسِ ۳۰٪ ظهور را بررسی می‌کند."""
    nowt = now()
    s = db.get_session()
    new_events = []
    try:
        _prune_old_events(s, nowt)
        groups = s.query(db.GroupChat).all()
        last_by_chat = dict(s.query(DogRescueEvent.chat_id, func.max(DogRescueEvent.created_at))
                            .group_by(DogRescueEvent.chat_id).all())
        cooldown = datetime.timedelta(minutes=GROUP_COOLDOWN_MINUTES)
        for group in groups:
            last_created = last_by_chat.get(group.chat_id)
            if last_created and nowt - last_created < cooldown:
                continue
            if random.random() >= SPAWN_CHANCE:
                continue
            event = DogRescueEvent(chat_id=group.chat_id, status="active", created_at=nowt,
                expires_at=nowt + datetime.timedelta(minutes=EVENT_DURATION_MINUTES))
            s.add(event)
            try:
                s.commit()
            except IntegrityError:
                s.rollback()  # یک پردازه‌ی دیگر برای همین گروه رویداد ساخته است.
                continue
            new_events.append((event.id, group.chat_id))
    except Exception:
        s.rollback()
        log.exception("Dog Rescue: spawn tick failed")
    finally:
        s.close()
    for event_id, chat_id in new_events:
        await _send_event(context.bot, event_id, chat_id)


def _record_attempt(event_id: int, chat_id: int, message_id: int, tg_user, cost: int, roll=None, nowt=None):
    """ثبت اتمیک تلاش و خرج/جایزه؛ مستقل از تلگرام و قابل تست."""
    if cost not in COSTS:
        return {"status": "invalid_cost"}
    nowt = nowt or now()
    roll = secrets.randbelow(10000) / 10000.0 if roll is None else float(roll)
    with _EVENT_LOCK:
        s = db.get_session()
        try:
            event = (s.query(DogRescueEvent).filter_by(id=event_id)
                     .with_for_update().one_or_none())
            if event is None or event.chat_id != chat_id or event.message_id != message_id:
                return {"status": "invalid_event"}
            if event.status != "active":
                return {"status": event.status, "snapshot": _snapshot(event)}
            if event.expires_at <= nowt:
                event.status, event.closed_at = "lonely", nowt
                snap = _snapshot(event, "lonely")
                s.commit()
                return {"status": "lonely", "snapshot": snap}

            cd = (s.query(DogRescueCooldown).filter_by(user_id=tg_user.id)
                  .with_for_update().one_or_none())
            if cd is None:
                cd = DogRescueCooldown(user_id=tg_user.id, updated_at=nowt)
                s.add(cd)
                try:
                    s.flush()
                except IntegrityError:
                    s.rollback()
                    return {"status": "retry"}
            if cd.last_win_at and nowt - cd.last_win_at < datetime.timedelta(hours=WIN_COOLDOWN_HOURS):
                remain = datetime.timedelta(hours=WIN_COOLDOWN_HOURS) - (nowt - cd.last_win_at)
                return {"status": "win_cooldown", "remaining_seconds": max(1, int(remain.total_seconds()))}

            previous = s.query(DogRescueAttempt).filter_by(event_id=event_id, user_id=tg_user.id).first()
            if previous:
                return {"status": "already_tried"}

            user = (s.query(db.User).filter_by(telegram_id=tg_user.id)
                    .with_for_update().one_or_none())
            if user is None:
                user = db.User(telegram_id=tg_user.id, username=tg_user.username,
                               first_name=tg_user.first_name, hop_points=0)
                s.add(user)
                s.flush()
            balance = float(user.hop_points or 0)
            if balance < cost:
                return {"status": "insufficient", "balance": balance, "cost": cost}

            import war_svc
            try:
                war_svc.hop_apply(s, user, -float(cost), "SPEND", "DOG_RESCUE_ATTEMPT",
                                  ref=f"dog_rescue:{event_id}:{tg_user.id}")
            except war_svc.WarError:
                return {"status": "insufficient", "balance": float(user.hop_points or 0), "cost": cost}

            success = roll < CHANCES[cost]
            s.add(DogRescueAttempt(event_id=event_id, user_id=tg_user.id, cost=cost,
                                   success=success, roll=roll, created_at=nowt))
            event.attempts_total = (event.attempts_total or 0) + 1
            if cost == 100:
                event.attempts_100 = (event.attempts_100 or 0) + 1
            elif cost == 1000:
                event.attempts_1000 = (event.attempts_1000 or 0) + 1
            else:
                event.attempts_4000 = (event.attempts_4000 or 0) + 1

            result = {"status": "lost", "cost": cost, "balance": float(user.hop_points or 0)}
            if success:
                event.status, event.closed_at = "rescued", nowt
                event.won_by = tg_user.id
                event.winner_name = tg_user.first_name or tg_user.username or str(tg_user.id)
                cd.last_win_at, cd.updated_at = nowt, nowt
                base_xp, gained_xp = BP_XP_BASE[cost], 0.0
                import battlepass_engine as bp
                if bp.enabled(s):
                    season = bp.current_season(s)
                    if bp.is_open(season):
                        player = bp.get_player(s, user, season)
                        gained_xp = round(base_xp * bp.xp_mult(s, player, tg_user.id), 2)
                        bp.add_xp(s, player, gained_xp)
                        bp.invalidate(tg_user.id)
                event.reward_xp = gained_xp
                result = {"status": "won", "cost": cost, "balance": float(user.hop_points or 0),
                          "base_xp": base_xp, "reward_xp": gained_xp}
            s.commit()
            result["snapshot"] = _snapshot(event)
            return result
        except Exception:
            s.rollback()
            log.exception("Dog Rescue: attempt transaction failed")
            return {"status": "error"}
        finally:
            s.close()


async def callback_router(update, context):
    query = update.callback_query
    if query is None:
        return False
    try:
        _prefix, event_s, cost_s = (query.data or "").split(":", 2)
        event_id, cost = int(event_s), int(cost_s)
    except (ValueError, TypeError):
        await query.answer("درخواست نامعتبره.", show_alert=True)
        return True
    chat, message = update.effective_chat, query.message
    if not chat or chat.type not in ("group", "supergroup") or message is None:
        await query.answer("این رویداد فقط داخل گروه قابل استفاده است.", show_alert=True)
        return True
    if cost not in COSTS:
        await query.answer("مقدار تلاش نامعتبره.", show_alert=True)
        return True

    result = _record_attempt(event_id, chat.id, message.message_id, query.from_user, cost)
    status = result.get("status")
    responses = {
        "invalid_event": ("این رویداد معتبر نیست.", True),
        "already_tried": ("تو قبلاً در این رویداد تلاش کردی؛ هر نفر فقط یک شانس داره.", True),
        "insufficient": (f"هاپ کافی نداری؛ برای این تلاش {cost:,} هاپ لازمه.", True),
        "win_cooldown": ("بعد از برد، تا ۶ ساعت نمی‌تونی دوباره جایزه نجات بگیری.", True),
        "retry": ("درخواست هم‌زمان شد؛ یک بار دیگه امتحان کن.", True),
        "error": ("ثبت تلاش ناموفق بود؛ هاپی از حسابت کم نشد. دوباره امتحان کن.", True),
        "active": ("این رویداد هنوز فعاله.", False),
        "rescued": ("این سگ قبلاً نجات داده شده! 🐶", True),
        "lonely": ("مهلت تموم شد؛ سگ تنها موند. 😢", True),
        "send_failed": ("این رویداد در دسترس نیست.", True),
    }
    if status in responses:
        msg, alert = responses[status]
        await query.answer(msg, show_alert=alert)
        if status == "lonely":
            try:
                await _edit_latest(context.bot, event_id)
            except Exception:
                log.exception("Dog Rescue: timeout edit failed")
        return True
    if status == "lost":
        await query.answer("😢 تلاش ناموفق بود؛ سگ هنوز منتظر نجاته.")
        try:
            await _edit_latest(context.bot, event_id)
        except Exception:
            log.exception("Dog Rescue: failed-attempt edit failed")
        return True
    if status == "won":
        await query.answer("🎉 موفق شدی! سگ رو نجات دادی!")
        try:
            await _edit_latest(context.bot, event_id)
        except Exception:
            log.exception("Dog Rescue: winner edit failed")
        return True
    await query.answer("درخواست پردازش نشد.", show_alert=True)
    return True
