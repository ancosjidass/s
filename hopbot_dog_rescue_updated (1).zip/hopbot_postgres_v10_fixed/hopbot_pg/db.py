# -*- coding: utf-8 -*-
"""
لایه‌ی دیتابیس ربات.

چرا SQLite + SQLAlchemy؟
- SQLite نیاز به سرور جدا نداره، توی همون سرور ربات یک فایله و برای یک/چند گروه
  و ترافیک معمولیِ این نوع بازی‌ها (چند صد تا چند هزار کاربر) کاملا کافی و پایداره.
- چون از SQLAlchemy (ORM) استفاده کردیم، اگر روزی ترافیک بالا رفت و خواستی بری
  روی PostgreSQL (که برای نوشتن هم‌زمان زیاد بهتره)، فقط کافیه رشته‌ی اتصال
  (DB_PATH / engine) رو عوض کنی؛ کدهای بالای اون دست‌نخورده می‌مونه.
- تراکنش‌های حساس (مثل انتقال هاپ بین دو نفر) داخل session.commit() اتمیک انجام
  می‌شن که از منفی‌شدن یا گم‌شدن پوینت جلوگیری می‌کنه.
"""
import datetime
import json
import threading
import time as _time

from sqlalchemy import (
    create_engine, event, Column, Integer, BigInteger, Float, String, Boolean,
    DateTime, Text, ForeignKey, UniqueConstraint, or_
)
from sqlalchemy.orm import declarative_base, sessionmaker
from sqlalchemy.pool import QueuePool
from sqlalchemy import exc as _sa_exc

import config

# poolِ واقعی (نه یه کانکشنِ تکی) + WAL: پیش‌فرضِ SQLite (journal_mode=DELETE)
# رو هر نوشتن، کلِ فایل رو قفل می‌کنه - یعنی حتی خوندنِ یه پلیرِ دیگه هم باید
# صبر کنه تا نوشتنِ پلیرِ اول کامل تموم بشه؛ زیرِ بار (چند پلیر هم‌زمان) دقیقاً
# همین باعثِ کندیِ محسوس می‌شه. با WAL، نوشتن‌ها می‌رن تو یه فایلِ جداگونه
# (-wal) و خوندن‌های هم‌زمان اصلاً بلاک نمی‌شن؛ فقط دو نوشتنِ هم‌زمان هنوز صف
# می‌شن (این محدودیتِ خودِ SQLite‌ه، نه چیزی که این‌جا قابلِ دورزدن باشه - اگه
# روزی واقعاً چندین نوشتنِ هم‌زمانِ سنگین لازم شد، طبق توضیحِ بالای فایل باید
# رفت رو PostgreSQL).
def _build_url() -> str:
    url = (config.DATABASE_URL or "").strip()
    if not url:
        return f"sqlite:///{config.DB_PATH}"
    if url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://"):]
    if url.startswith("postgresql://"):
        url = "postgresql+psycopg2://" + url[len("postgresql://"):]
    return url


DATABASE_URL = _build_url()
IS_PG = DATABASE_URL.startswith("postgresql")
IS_SQLITE = not IS_PG

if IS_PG:
    # PostgreSQL (Supabase): هم‌زمانیِ واقعیِ نوشتن؛ poolِ کوچک‌تر از SQLite چون
    # Supabase سقفِ کانکشن داره.
    #
    # نکته‌یِ سرعت: قبلاً pool_pre_ping=True بود، یعنی *هر* بار که یه Session کانکشن
    # می‌گرفت، یه «SELECT 1» اضافه تا سرورِ ریموت می‌رفت و برمی‌گشت (یه رفت‌وبرگشتِ
    # کامل). چون ربات برایِ هر پیام/دکمه چندین Session باز می‌کنه، این رفت‌وبرگشت‌هایِ
    # اضافه جمع می‌شدن و ربات رو کند می‌کردن. الان فقط وقتی کانکشن بیشتر از
    # PG_IDLE_PING_SECONDS بی‌کار بوده (که احتمالِ بسته‌شدنش از سمتِ Supabase هست) پینگ
    # می‌شه؛ کانکشنِ «گرم» مستقیم استفاده می‌شه. ایمنی همون قبلیه: کانکشنِ مرده قبل از
    # استفاده تشخیص داده و عوض می‌شه، نه اینکه وسطِ بازی خطا بده.
    engine = create_engine(
        DATABASE_URL,
        echo=False,
        future=True,
        poolclass=QueuePool,
        pool_size=config.PG_POOL_SIZE,
        max_overflow=config.PG_MAX_OVERFLOW,
        pool_timeout=30,
        pool_pre_ping=False,
        pool_use_lifo=True,      # همیشه «گرم‌ترین» کانکشن استفاده می‌شه؛ بقیه بی‌کار می‌مونن و تازه‌سازی می‌شن
        pool_recycle=900,
        # آپدیتِ/حذفِ چندردیفیِ ORM (مثلاً سودِ بانکِ همه‌ی کاربرها) تو دسته‌هایِ ۱۰۰تایی و با
        # یه رفت‌وبرگشت فرستاده می‌شه، نه یکی‌یکی.
        executemany_mode="values_plus_batch",
        connect_args={
            "connect_timeout": 15,
            "keepalives": 1,
            "keepalives_idle": 30,
            "keepalives_interval": 10,
            "keepalives_count": 5,
            "application_name": "hopbot",
        },
    )

    @event.listens_for(engine, "connect")
    def _pg_on_connect(dbapi_connection, connection_record):
        connection_record.info["last_used"] = _time.monotonic()
        if config.PG_ASYNC_COMMIT:
            cur = dbapi_connection.cursor()
            try:
                cur.execute("SET synchronous_commit TO OFF")
            finally:
                cur.close()
            dbapi_connection.commit()

    @event.listens_for(engine, "checkout")
    def _pg_on_checkout(dbapi_connection, connection_record, connection_proxy):
        """فقط کانکشنِ مدتی‌بی‌کار رو پینگ می‌کنه؛ اگه مرده بود DisconnectionError می‌ده
        و SQLAlchemy خودش یه کانکشنِ تازه می‌سازه (دقیقاً همون رفتارِ pre_ping)."""
        last = connection_record.info.get("last_used")
        now_m = _time.monotonic()
        if last is not None and (now_m - last) > config.PG_IDLE_PING_SECONDS:
            cur = dbapi_connection.cursor()
            try:
                cur.execute("SELECT 1")
            except Exception as exc:
                raise _sa_exc.DisconnectionError() from exc
            finally:
                try:
                    cur.close()
                except Exception:
                    pass
            try:
                dbapi_connection.rollback()   # SELECT 1 یه تراکنش باز کرده؛ تمیزش کن
            except Exception as exc:
                raise _sa_exc.DisconnectionError() from exc
        connection_record.info["last_used"] = now_m

    @event.listens_for(engine, "checkin")
    def _pg_on_checkin(dbapi_connection, connection_record):
        connection_record.info["last_used"] = _time.monotonic()
else:
    # SQLite + WAL (توضیحِ کاملِ دلیلِ این تنظیمات تو نسخه‌ی قبلیِ این فایل بود)
    engine = create_engine(
        DATABASE_URL,
        echo=False,
        future=True,
        poolclass=QueuePool,
        pool_size=20,
        max_overflow=40,
        pool_timeout=30,
        connect_args={"check_same_thread": False, "timeout": 30},
    )

    @event.listens_for(engine, "connect")
    def _set_sqlite_pragmas(dbapi_connection, connection_record):
        """PRAGMAها per-connection‌ان، پس هر کانکشنِ جدید باید دوباره ست بشن."""
        cursor = dbapi_connection.cursor()
        cursor.execute("PRAGMA journal_mode=WAL")
        cursor.execute("PRAGMA synchronous=NORMAL")
        cursor.execute("PRAGMA busy_timeout=30000")
        cursor.execute("PRAGMA cache_size=-64000")
        cursor.execute("PRAGMA temp_store=MEMORY")
        cursor.execute("PRAGMA foreign_keys=ON")
        cursor.close()


SessionLocal = sessionmaker(bind=engine, expire_on_commit=False, future=True)
Base = declarative_base()


def now():
    return datetime.datetime.utcnow()


class User(Base):
    __tablename__ = "users"

    telegram_id = Column(BigInteger, primary_key=True)
    username = Column(String, nullable=True)
    first_name = Column(String, nullable=True)

    hop_points = Column(Float, default=0)
    level = Column(Integer, default=1)
    xp = Column(Float, default=0)  # پیشرفت داخل سطح فعلی

    # لولِ جدید (lvl) - کاملاً جدا از «سطح شخصیت» (level/xp) بالاست. همه از ۱
    # شروع می‌کنن، سقفش ۵۰۰۰ هست و با هر ۱۳ بار «هاپ هاپ» یک لول بالا می‌ره
    # (نگاه کن به db.HOPS_PER_LVL / db.MAX_LVL و منطقش تو handlers.process_hop).
    # از پنلِ «ویرایش پلیر» هم مستقیم قابلِ تغییره؛ چون منطقِ ارتقا «۱۳تایی
    # اضافه‌کن» هست نه «از رو hop_count از نو حساب کن»، تغییرِ دستی همیشه حفظ
    # می‌مونه و هاپِ بعدی از همون‌جا +۱ می‌کنه.
    lvl = Column(Integer, default=1)

    last_hop_at = Column(DateTime, nullable=True)
    hop_count = Column(Integer, default=0)  # تعداد کل دفعاتی که «هاپ هاپ» کرده (برای لیگ برتر)

    # اسم دلخواهی که کاربر برای سگ/ربات انتخاب می‌کنه؛ اگه ست بشه، به‌جای تایپ
    # «هاپ منیج» می‌تونه همین اسم رو بنویسه تا منو باز شه
    # (نام ستون به تاریخی cat_name مونده، ولی تو کل ربات به‌عنوان «اسم سگ» نمایش داده می‌شه)
    cat_name = Column(String, nullable=True)

    # کارخونه / تولید هاپ در دقیقه
    production_per_min = Column(Float, default=1200)
    # ستونِ قدیمیِ سطحِ پیوسته/سراسری - دیگه تو منطقِ جدید استفاده نمی‌شه، فقط
    # برای مهاجرتِ یک‌بارِ داده‌ی کاربرهای قدیمی نگه داشته شده (نگاه کن به
    # _migrate_factory_ranks_v2 پایینِ همین فایل)
    production_level = Column(Integer, default=0)
    factory_rank_order = Column(Integer, default=1)  # کدوم مقامه (FactoryRank.order)
    factory_level = Column(Integer, default=1)  # سطحِ نسبی داخلِ همون مقام (از ۱ شروع می‌شه)
    last_collect_at = Column(DateTime, default=now)
    # تولیدی که جمع شده ولی هنوز با دکمه‌ی «برداشت» برداشت نشده (تا سقف ظرفیتِ
    # سطح فعلی رشد می‌کنه و بعدش دیگه بالا نمی‌ره تا برداشت بشه)
    factory_pending = Column(Float, default=0)

    # سوپرمارکت
    has_supermarket = Column(Boolean, default=False)
    supermarket_level = Column(Integer, default=0)
    supermarket_prod_per_hour = Column(Float, default=0)  # مجموع تولید ۴ کالا در ساعت
    last_market_collect_at = Column(DateTime, nullable=True)
    cat_meat = Column(Float, default=0)
    cinnamon_cucumber = Column(Float, default=0)
    banana = Column(Float, default=0)
    dog_egg = Column(Float, default=0)

    # سطح‌بندیِ محصولات سوپرمارکت (جدا از سطح ارتقای پولیِ سرعت تولید):
    # هر ۳۰ واحد محصول تولیدشده (پیش‌فرض، در پنل قابل تغییر) یک سطح بالا میره
    # و محصولات جدیدی که مالک برای اون سطح تعریف کرده باز می‌شن.
    market_product_level = Column(Integer, default=1)
    market_produce_progress = Column(Float, default=0)

    # بانک هاپویی
    has_bank = Column(Boolean, default=False)
    bank_balance = Column(Float, default=0)
    bank_last_interest_at = Column(DateTime, nullable=True)
    bank_last_interest_amount = Column(Float, nullable=True)  # مقدارِ آخرین سودی که بانک داده (برای نمایش تو پنلِ بانک)

    # گوشی هاپویی (شبکه‌های اجتماعی) - اینترنت و محدودیتِ روزیِ درخواستِ پلتفرم
    internet_gb = Column(Float, default=0)  # گیگابایتِ باقی‌مونده برای دیدن/گذاشتنِ پست
    operator_id = Column(Integer, nullable=True)  # آخرین اپراتوری که ازش اینترنت خریده (سرعتِ آپلود بر اساسِ همینه)
    # ولتِ ارز دیجیتال - با خریدش یه آدرسِ یکتا می‌گیره که بقیه می‌تونن باهاش
    # براش ارز بفرستن (نگاه کن به «انتقالِ ارز» تو منوی ارز دیجیتال)
    wallet_address = Column(String, unique=True, nullable=True)
    myawy_requests_today = Column(Integer, default=0)  # چند تا درخواستِ پلتفرمِ جدید امروز فرستاده
    myawy_requests_reset_at = Column(DateTime, nullable=True)  # از کِی شمارشِ امروز شروع شده
    # زندانِ سراسری (فارغ از گروه) - مثلاً بابتِ پرداخت‌نکردنِ فیِ پلتفرم تا مهلت.
    # با زندانِ ضدِاسپمِ antispam.py فرق داره: اون در حافظه و مخصوصِ یک گروهه،
    # این تو دیتابیسه و رو همه‌ی گروه‌ها اثر داره (چون ربات ری‌استارت هم بشه باید بمونه)
    jailed_until = Column(DateTime, nullable=True)
    # وثیقه‌ی آزادیِ زندانِ هاپویی:
    #   None  -> از مقدارِ پیش‌فرضِ کانفیگ استفاده می‌شه (بسته به دلیلِ زندانی‌شدن)
    #   عددِ مثبت -> دقیقاً همین‌قدر هاپ پوینت بده تا آزاد شه
    #   عددِ منفی (-1) -> اصلاً وثیقه قبول نمی‌شه؛ باید مدتش تموم شه یا ادمین آزادش کنه
    jail_bail_amount = Column(Float, nullable=True)
    jail_reason = Column(String, nullable=True)  # spam / smuggling / admin - فقط برای نمایش
    # غذای سگ - ظرفیتش از رتبه‌ی کارخونه میاد (هر مقام +۲)؛ اگه صفر بشه،
    # برداشتِ تولیدِ کارخونه (واریز) قفل می‌شه تا دوباره غذا بخره
    dog_food = Column(Float, default=0)  # دقیقه‌ی غذای باقی‌مونده (نه تعدادِ واحد) - نگاه کن به economy.sync_dog_food
    dog_food_last_check_at = Column(DateTime, nullable=True)  # آخرین باری که کم‌شدنِ زمانیِ غذا حساب شده

    # تاکسیِ هاپویی
    taxi_car_model_id = Column(Integer, ForeignKey("taxi_car_models.id"), nullable=True)
    taxi_engine_level = Column(Integer, default=1)
    taxi_rank_order = Column(Integer, default=1)   # مقامِ محبوبیت (مشترک بینِ همه‌ی ماشین‌ها - نگاه کن به TaxiRank)
    taxi_level = Column(Integer, default=1)        # سطحِ نسبیِ محبوبیت داخلِ همون مقام
    taxi_gas_liters = Column(Float, default=0)
    taxi_last_wash_at = Column(DateTime, nullable=True)
    taxi_state = Column(String, default="idle")    # idle/at_station/en_route/returning/shift_complete/resting
    taxi_state_until = Column(DateTime, nullable=True)   # پایانِ مرحله‌ی فعلیِ چرخه
    taxi_shift_until = Column(DateTime, nullable=True)   # سقفِ زمانیِ کلِ شیفت (بعدِ اتمامِ چرخه‌ی جاری چک می‌شه)
    taxi_resting_until = Column(DateTime, nullable=True)
    taxi_current_passengers = Column(Integer, default=0)
    taxi_shift_earnings = Column(Float, default=0)  # درآمدِ تسویه‌نشده‌ی همین شیفت - با «برداشت» می‌ره رو hop_points

    def display_name(self):
        # منشنِ قابل‌کلیک (text_mention) به‌جای @یوزرنیم؛ نشانه‌اش موقعِ ارسال به منشنِ واقعی تبدیل می‌شه (mentions.py)
        import mentions
        return mentions.mark(self.telegram_id, self.first_name or self.username or str(self.telegram_id))


class Operator(Base):
    """
    اپراتورهای اینترنت تو «گوشی هاپویی» - فقط مالک از پنل می‌سازه/مدیریت می‌کنه.
    هر اپراتور قیمتِ هر گیگ داره و دو تا عددِ سرعت:
    - speed_mbps: سقفِ نهایی/حداکثرِ ارتقا داده‌شده (فقط با پرداختِ هاپ پوینت
      بالا می‌ره، هیچ‌وقت خودش کم نمی‌شه).
    - active_speed_mbps: سرعتِ فعلاً «فعال» که واقعا تو محاسبه‌ی زمانِ آپلود
      استفاده می‌شه؛ می‌تونه هر مقداری بینِ ۰ تا speed_mbps باشه (مالک می‌تونه
      بدونِ پرداختِ اضافه، فقط بخشی از ظرفیتِ ارتقاداده‌شده رو فعال نگه داره).
      پیش‌فرض و بعد از هر ارتقا، خودکار برابرِ speed_mbps می‌شه.
    """
    __tablename__ = "operators"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    price_per_gb = Column(Float, nullable=False, default=1000)
    speed_mbps = Column(Float, nullable=False, default=100)  # سقفِ نهایی (حداکثرِ ارتقا داده‌شده)
    active_speed_mbps = Column(Float, nullable=False, default=100)  # سرعتِ فعلاً فعال (<= speed_mbps)
    is_active = Column(Boolean, default=True)


class Platform(Base):
    """
    پلتفرم‌های شبکه‌ی اجتماعیِ «گوشی هاپویی» (مثل اینستا و بقیه). هر پلتفرم نرخِ
    پاداشِ خودشو داره: reward_amount هاپ پوینت به‌ازای هر likes_threshold لایک
    (مثلا می‌شه گفت هر ۲ لایک ۵۰۰,۰۰۰ تا، نه لزوما هر ۱۰ تا یه‌مقدارِ ثابت).
    اگه is_bot_funded باشه، خودِ بات پاداشِ لایک‌ها رو مستقیم به کاربر واریز
    می‌کنه؛ وگرنه پاداش به‌صورتِ «بدهیِ مالک» ثبت می‌شه و مالک باید دستی از
    پنل پرداختش کنه.
    """
    __tablename__ = "platforms"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    reward_amount = Column(Float, nullable=False, default=0)  # هاپ پوینتِ پاداش
    likes_threshold = Column(Integer, nullable=False, default=10)  # به‌ازای هر چند لایک
    is_bot_funded = Column(Boolean, default=False)
    owner_user_id = Column(BigInteger, nullable=True)  # اگه از طریقِ درخواستِ یه پلیر ساخته شده
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)
    # اگه True باشه، این پلتفرم رو گوشیِ «ممنوع‌شده» (نسلِ خیلی قدیمی) هم لود
    # می‌شه - یعنی از قانونِ عمومیِ «نسلِ قدیمی پلتفرمِ عادی نمی‌بینه» مستثناست.
    # فقط برای پلتفرم‌هایی که خودِ مالک مستقیم از پنل ساخته (owner_user_id خالیه)
    # قابل‌تنظیمه؛ پلتفرمی که از درخواستِ یه پلیر ساخته شده این گزینه رو نداره.
    works_on_all_phones = Column(Boolean, default=False)


class PlatformRequest(Base):
    """
    درخواستِ یه پلیر برای ساختِ پلتفرمِ جدید. محدودیت: هر پلیر حداکثر ۲۵ درخواست
    در روز. اگه مالک قبول کنه، یه مبلغِ «فی» تعیین می‌کنه که کاربر باید ظرفِ ۳
    روز (با استفاده از خودِ گوشی هاپویی) بپردازه؛ یک ساعت مونده به مهلت یه
    اخطار تو پیویش می‌گیره، و اگه سرِ وقت پرداخت نکنه هم درخواست کنسل می‌شه هم
    ۱ روز می‌ره زندانِ هاپویی (User.jailed_until).
    """
    __tablename__ = "platform_requests"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    platform_name = Column(String, nullable=False)
    requested_reward_amount = Column(Float, nullable=False)
    requested_likes_threshold = Column(Integer, nullable=False, default=10)
    status = Column(String, default="pending")  # pending / awaiting_payment / approved / rejected / expired
    fee_amount = Column(Float, nullable=True)
    fee_paid_amount = Column(Float, default=0)
    warned_1h = Column(Boolean, default=False)  # اخطارِ «۱ ساعت مونده» فرستاده شده یا نه
    fee_deadline = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=now)


class MyawyPost(Base):
    """پست‌های متنیِ کاربرها تو یکی از پلتفرم‌های گوشی هاپویی."""
    __tablename__ = "myawy_posts"
    id = Column(Integer, primary_key=True, autoincrement=True)
    platform_id = Column(Integer, ForeignKey("platforms.id"))
    user_id = Column(BigInteger, nullable=False)
    content = Column(Text, nullable=False)
    likes = Column(Integer, default=0)
    paid_likes = Column(Integer, default=0)  # چندتا از لایک‌ها قبلا حساب/پرداخت شدن
    ready_at = Column(DateTime, nullable=False)  # قبل از این زمان، پست هنوز «در حالِ آپلود»ه
    created_at = Column(DateTime, default=now)


class MyawyPostLike(Base):
    """هر کاربر فقط یه بار می‌تونه هر پست رو لایک کنه."""
    __tablename__ = "myawy_post_likes"
    id = Column(Integer, primary_key=True, autoincrement=True)
    post_id = Column(Integer, ForeignKey("myawy_posts.id"))
    user_id = Column(BigInteger, nullable=False)
    created_at = Column(DateTime, default=now)


class UserDebt(Base):
    """بدهیِ مالک به یه کاربر - فقط بابتِ لایک‌های پلتفرم‌هایی که خودِ مالک ساخته
    (نه بات‌فاندد، نه ساخته‌شده توسطِ یه پلیر) که هنوز از پنل پرداخت نشده.
    برای پلتفرم‌های پلیرساخته، پرداخت خودکاره (نگاه کن به myawy._grant_like_rewards)."""
    __tablename__ = "user_debts"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    amount = Column(Float, nullable=False)
    reason = Column(String, nullable=True)
    is_paid = Column(Boolean, default=False)
    created_at = Column(DateTime, default=now)
    paid_at = Column(DateTime, nullable=True)


# زندانِ ابدی (لایف‌تایم) با ستِ‌کردنِ jailed_until به یه تاریخِ خیلی دور تو
# آینده نشون داده می‌شه - همون فیلد/همون منطقِ چک‌کردن، بدونِ نیاز به ستونِ جدا.
JAIL_FOREVER = datetime.datetime(2999, 1, 1)


class Report(Base):
    """گزارشِ یه پلیرِ عادی از یه پلیرِ دیگه (با ریپلای‌زدن رو پیامِ موردنظر تو
    گروه). مالک از پنلِ ادمین بررسی می‌کنه (همراهِ لینکِ پیام) و قبول/رد می‌کنه؛
    قبول‌کردن دقیقا مثلِ دستورِ «زندان هاپویی» یه مدت یا برای همیشه می‌فرستدش
    زندان (نگاه کن به db.JAIL_FOREVER)."""
    __tablename__ = "reports"
    id = Column(Integer, primary_key=True, autoincrement=True)
    reporter_id = Column(BigInteger, nullable=False)
    reported_user_id = Column(BigInteger, nullable=False)
    chat_id = Column(BigInteger, nullable=False)
    message_id = Column(BigInteger, nullable=False)
    message_link = Column(String, nullable=True)
    reason = Column(String, nullable=True)
    status = Column(String, default="pending")  # pending / accepted / rejected
    created_at = Column(DateTime, default=now)
    resolved_at = Column(DateTime, nullable=True)


# ---------------------------------------------------------------------------
# گوشی‌های هاپویی: خط تولید / نسل / مالکیتِ پلیر / بازارِ سیاه
# ---------------------------------------------------------------------------

class PhoneLine(Base):
    """یه «خط تولید» گوشی داخلِ گوشی هاپویی (مثلا «سامسونگ»، «آیفون»، یا زیرمجموعه‌ی
    خودِ مالک مثلِ «هاپ»). هر خط شاملِ چند نسل/سریِ پیاپیه (S1, S2, ... یا هاپ۱،
    هاپ۲، ...) که مالک هر چند وقت یه‌بار (مثلا هر ۲ هفته) از پنل یکی جدید اضافه
    می‌کنه. is_fake یعنی این خط جزوِ دسته‌ی «گوشیِ فیک»ه: قوانینِ متفاوتی داره -
    هیچ‌وقت به‌خاطرِ قدیمی‌بودنِ نسل از پلتفرم‌های جدید منع نمی‌شه (چون خودِ
    فلسفه‌ی فیک همینه که همیشه هرچی جدیده روش بیاد)، در عوض معمولاً خیلی بیشتر و
    زودتر از گوشیِ اصل خراب می‌شه."""
    __tablename__ = "phone_lines"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    is_fake = Column(Boolean, default=False)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)


class PhoneGeneration(Base):
    """یه مدل/سریِ مشخص داخلِ یه PhoneLine (مثلا «S1» داخلِ خطِ سامسونگ، یا «هاپ
    فیک ۱» داخلِ خطِ فیک هاپ). gen_index ترتیبِ ساختِ این نسل داخلِ همون خطه (۱،
    ۲، ۳، ...).

    - validity_days: هم مدتِ «موجود بودن تو بازار برای خریدِ پلیرِ جدید» از لحظه‌ی
      ساختِ این نسل، هم طولِ عمرِ هر گوشیِ خریداری‌شده (بعدش خودِ گوشی برای اون
      خریدار منقضی می‌شه).
    - breakdown_grace_days: از لحظه‌ی خریدِ یه گوشی، چند روز طول می‌کشه تا
      شانسِ روزانه‌ی خراب‌شدنِ قطعات (daily_break_chance_pct) براش شروع بشه.
    - banned_from_platforms: خودکار True می‌شه وقتی به‌اندازه‌ی کافی (پیش‌فرض ۳
      بار) نسلِ جدیدتر از همین خط ساخته شده باشه - نگاه کن به
      myawy._recompute_generation_bans. برای خط‌های فیک هیچ‌وقت اعمال نمی‌شه.
    """
    __tablename__ = "phone_generations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    line_id = Column(Integer, ForeignKey("phone_lines.id"))
    name = Column(String, nullable=False)
    gen_index = Column(Integer, nullable=False, default=1)
    price = Column(Float, nullable=False, default=0)
    validity_days = Column(Integer, nullable=False, default=14)
    breakdown_grace_days = Column(Integer, nullable=False, default=14)
    daily_break_chance_pct = Column(Float, nullable=False, default=30)
    repair_lcd_price = Column(Float, nullable=False, default=5000000)
    repair_battery_price = Column(Float, nullable=False, default=12000000)
    repair_cpu_price = Column(Float, nullable=False, default=18000000)
    is_market_available = Column(Boolean, default=True)  # الان تو بازار قابلِ خریدِ پلیرِ جدید هست یا «ناموجود»
    banned_from_platforms = Column(Boolean, default=False)  # نسلِ خیلی قدیمی - پلتفرمِ عادی روش لود نمی‌شه
    manual_ban = Column(Boolean, default=False)  # مدیر دستی «ممنوعِ فوری» زده - قانونِ خودکارِ ۳نسل دیگه روش اثر نداره
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)


class UserPhone(Base):
    """یه گوشیِ متعلق به یه پلیر - چه از بازارِ رسمی خریده باشه چه از بازارِ سیاه.
    هر پلیر می‌تونه هرچقدر بخواد گوشی تو «کشو»ش نگه داره، ولی همیشه حداکثر یکیش
    is_equipped=True داره - فقط همون یکی برای دیدن/پستِ پلتفرم‌ها استفاده می‌شه."""
    __tablename__ = "user_phones"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    generation_id = Column(Integer, ForeignKey("phone_generations.id"))
    bought_at = Column(DateTime, default=now)
    expires_at = Column(DateTime, nullable=False)
    is_equipped = Column(Boolean, default=False)
    broken_lcd = Column(Boolean, default=False)
    broken_battery = Column(Boolean, default=False)
    broken_cpu = Column(Boolean, default=False)
    last_break_check_at = Column(DateTime, nullable=True)
    original_price = Column(Float, nullable=False, default=0)  # قیمتِ خریدِ همین گوشی - سقفِ قیمتِ بازارِ سیاه
    is_discarded = Column(Boolean, default=False)


class BlackMarketListing(Base):
    """آگهیِ فروشِ یه گوشی بینِ خودِ پلیرها. قیمت باید حتماً کمتر از
    original_price همون گوشی باشه (حتی ۱ هاپ پوینت هم مجازه)."""
    __tablename__ = "black_market_listings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    phone_id = Column(Integer, ForeignKey("user_phones.id"))
    seller_id = Column(BigInteger, nullable=False)
    price = Column(Float, nullable=False)
    created_at = Column(DateTime, default=now)
    is_sold = Column(Boolean, default=False)


# ---------------------------------------------------------------------------
# سرآشپز و غذای سگ (رای‌گیری هاپویی / مارکت هاپویی)
# ---------------------------------------------------------------------------

class DogFood(Base):
    """نوعِ غذای سگ که فقط مالک از پنل تعریف می‌کنه (اسم، قیمتِ هر واحد، زمانِ
    آماده‌سازیِ هر واحد به دقیقه، و اینکه هر واحدش چند تا از ظرفیتِ غذای سگ رو
    پر می‌کنه - مثلا یه تنقلاتِ ساده ۱ واحد، یه استیک ۲ واحد)."""
    __tablename__ = "dog_foods"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    price = Column(Float, nullable=False, default=0)
    prep_minutes = Column(Float, nullable=False, default=3.5)  # هر ۱ واحد چقدر آماده‌سازی زمان می‌بره
    feed_value = Column(Integer, nullable=False, default=1)  # هر ۱ واحدش چند واحد از ظرفیتِ غذای سگ رو پر می‌کنه
    is_active = Column(Boolean, default=True)


class GroupChef(Base):
    """سرآشپزِ فعلیِ یه گروه (اگه انتخابات برنده داشته باشه) - هر گروه در هر
    لحظه حداکثر یک سرآشپزِ فعال داره، به مدتِ ۷ روز."""
    __tablename__ = "group_chefs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger, nullable=False, unique=True)
    user_id = Column(BigInteger, nullable=False)
    tax_pct = Column(Float, default=0)  # حداکثر مقدارش از پنل قابل‌تنظیمه (پیش‌فرض سقف ۲۰٪)
    term_started_at = Column(DateTime, default=now)
    term_ends_at = Column(DateTime, nullable=False)


class ChefElection(Base):
    """یه دوره‌ی انتخاباتِ سرآشپز تو یه گروه."""
    __tablename__ = "chef_elections"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger, nullable=False)
    status = Column(String, default="open")  # open / closed
    created_at = Column(DateTime, default=now)
    closes_at = Column(DateTime, nullable=True)


class ChefCandidate(Base):
    """کاندیدهای یه انتخابات (حداکثر تعدادشون از پنل قابل‌تنظیمه، پیش‌فرض ۱۵)."""
    __tablename__ = "chef_candidates"
    id = Column(Integer, primary_key=True, autoincrement=True)
    election_id = Column(Integer, ForeignKey("chef_elections.id"))
    user_id = Column(BigInteger, nullable=False)
    slogan = Column(Text, nullable=True)
    votes = Column(Integer, default=0)


class ChefVote(Base):
    """هر کاربر فقط یه بار می‌تونه تو هر انتخابات رای بده."""
    __tablename__ = "chef_votes"
    id = Column(Integer, primary_key=True, autoincrement=True)
    election_id = Column(Integer, ForeignKey("chef_elections.id"))
    candidate_id = Column(Integer, ForeignKey("chef_candidates.id"))
    user_id = Column(BigInteger, nullable=False)


class ChefRecallVote(Base):
    """رای‌های «درخواستِ برکناری» برای سرآشپزِ فعلیِ یه گروه؛ با رسیدن به سقف
    (پیش‌فرض ۲۰ رای، از پنل قابل‌تنظیم)، سرآشپز فوراً برکنار می‌شه."""
    __tablename__ = "chef_recall_votes"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger, nullable=False)
    chef_user_id = Column(BigInteger, nullable=False)
    voter_user_id = Column(BigInteger, nullable=False)
    created_at = Column(DateTime, default=now)


class GroupFoodStock(Base):
    """موجودیِ غذای هر گروه که سرآشپز تهیه کرده (بعد از ready_at قابل‌خریده).
    مالیات مالِ خودِ دوره‌ی سرآشپزیه (GroupChef.tax_pct)، نه مالِ هر بچِ غذا."""
    __tablename__ = "group_food_stock"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger, nullable=False)
    food_id = Column(Integer, ForeignKey("dog_foods.id"))
    quantity = Column(Integer, default=0)
    ready_at = Column(DateTime, nullable=True)


class Config(Base):
    """تنظیمات سراسری بازی که مالک می‌تونه از پنل بدون تغییر کد عوضشون کنه."""
    __tablename__ = "game_config"
    key = Column(String, primary_key=True)
    value = Column(Text)


class Currency(Base):
    __tablename__ = "currencies"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, unique=True)
    emoji = Column(String, default="💱")
    buy_price = Column(Float, default=0)   # قیمت خرید هر واحد (به هاپ پوینت)
    sell_price = Column(Float, default=0)  # قیمت فروش هر واحد
    # برای موتورِ نوسانِ قیمتِ جدید (economy.tick_crypto_prices) - نگاه کن به
    # توضیحاتِ اونجا. period_anchor_price = قیمتِ لنگرِ شروعِ دوره‌ی فعلی،
    # period_started_at = کِی این دوره شروع شده.
    period_anchor_price = Column(Float, nullable=True)
    period_started_at = Column(DateTime, nullable=True)


class UserCurrency(Base):
    __tablename__ = "user_currencies"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.telegram_id", deferrable=True, initially="DEFERRED"))
    currency_id = Column(Integer, ForeignKey("currencies.id"))
    amount = Column(Float, default=0)


class CurrencyAlarm(Base):
    """آلارمِ قیمتِ ارز - یک‌بارمصرف. وقتی قیمت (تو تیکِ به‌روزرسانی) واقعاً از
    مسیرِ بینِ قیمتِ قبلی و جدید عبور کنه و بهِ target_price برسه/رد بشه، به
    کاربر پیام می‌ره و خودِ همین ردیف حذف می‌شه - اگه بعداً دوباره قیمت به
    همون‌جا برسه ولی آلارمِ جدیدی ست نشده باشه، دیگه پیامی نمی‌ره."""
    __tablename__ = "currency_alarms"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.telegram_id", deferrable=True, initially="DEFERRED"))
    currency_id = Column(Integer, ForeignKey("currencies.id"))
    target_price = Column(Float)
    direction = Column(String)  # "up" (منتظرِ رسیدنِ قیمت از پایین به بالا) یا "down" (از بالا به پایین)
    created_at = Column(DateTime, default=now)


class CurrencyOrder(Base):
    """سفارشِ خرید/فروشِ ارز با قیمتِ هدف (Limit Order). موقعِ ثبتِ سفارش،
    پول (برای buy) یا خودِ ارز (برای sell) بلافاصله از کاربر کم می‌شه
    (به‌صورتِ امانی نگه داشته می‌شه) - این‌طوری هم نمی‌شه دوبار همون پول/ارز رو
    قفل کرد، هم نمی‌شه ارزی که هنوز واقعاً خریداری نشده رو فروخت. اگه سفارش
    لغو بشه، همون مقدار برمی‌گرده."""
    __tablename__ = "currency_orders"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.telegram_id", deferrable=True, initially="DEFERRED"))
    currency_id = Column(Integer, ForeignKey("currencies.id"))
    kind = Column(String)  # "buy" یا "sell"
    target_price = Column(Float)
    quantity = Column(Float)
    status = Column(String, default="pending")  # pending / filled / cancelled
    created_at = Column(DateTime, default=now)
    filled_at = Column(DateTime, nullable=True)


# ---------------------------------------------------------------------------
# کد جایزه‌ی هاپویی
# ---------------------------------------------------------------------------

class RedeemCode(Base):
    """کدِ جایزه‌ای که مالک از پنل می‌سازه. هر کد یه پاداشِ هاپ‌پوینتِ ثابت داره
    و می‌تونه تاریخِ انقضا داشته باشه (یا نداشته باشه = همیشه معتبر تا مالک
    دستی حذفش کنه). هر کاربر فقط یه‌بار می‌تونه هر کد رو وارد کنه (نگاه کن به
    RedeemCodeUse) - ولی خودِ کد رو همه می‌تونن استفاده کنن."""
    __tablename__ = "redeem_codes"
    id = Column(Integer, primary_key=True, autoincrement=True)
    code = Column(String, unique=True, nullable=False)
    reward_points = Column(Float, nullable=False)
    expires_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=now)
    is_active = Column(Boolean, default=True)


class RedeemCodeUse(Base):
    __tablename__ = "redeem_code_uses"
    id = Column(Integer, primary_key=True, autoincrement=True)
    code_id = Column(Integer, ForeignKey("redeem_codes.id"))
    user_id = Column(BigInteger, nullable=False)
    used_at = Column(DateTime, default=now)


# ---------------------------------------------------------------------------
# کارتِ هاپویی (ایونتِ موقتِ جمع‌آوریِ کارت)
# ---------------------------------------------------------------------------

class CardEvent(Base):
    """یه دورِ ایونتِ کارت هاپویی. مالک هر بار که از پنل شروع می‌کنه یه ردیفِ
    جدید ساخته می‌شه؛ فقط یکی می‌تونه هم‌زمان is_active=True باشه."""
    __tablename__ = "card_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    started_at = Column(DateTime, default=now)
    ends_at = Column(DateTime, nullable=False)
    is_active = Column(Boolean, default=True)
    ended_manually = Column(Boolean, default=False)


class CardSlot(Base):
    """یه خونه‌ی مشخص تو یکی از ۳ لیستِ کارت (مثلا خونه‌ی ۵ی لیستِ کمیاب).
    ایموجی/درصد/ویژه‌بودنش از پنل تنظیم می‌شه. list_no: 1=کمیاب، 2=جنگلی
    (خیلی‌کمیاب)، 3=لجند. is_special یعنی گرفتنِ این کارت (برای اولین بار) یه
    پیامِ پیویِ ویژه با پاداشِ هاپ‌پوینتِ جداگونه (special_reward_points) می‌ده."""
    __tablename__ = "card_slots"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("card_events.id"))
    list_no = Column(Integer, nullable=False)
    slot_index = Column(Integer, nullable=False)
    emoji = Column(String, nullable=False, default="🎴")
    base_percent = Column(Float, nullable=False, default=1.0)
    is_special = Column(Boolean, default=False)
    special_reward_points = Column(Float, nullable=True)


class UserCard(Base):
    """مالکیتِ یه پلیر رو یه کارت، تو یه ایونتِ مشخص. count=1 یعنی فقط اصلی
    داره؛ بیشتر از ۱ یعنی تکراری هم داره (count-1 عدد تکراری)."""
    __tablename__ = "user_cards"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, nullable=False)
    user_id = Column(BigInteger, nullable=False)
    slot_id = Column(Integer, ForeignKey("card_slots.id"))
    count = Column(Integer, default=1)


class UserCardTokens(Base):
    """موجودیِ توکن‌های امروزِ یه پلیر تو یه ایونت. day_key (مثلا
    "2026-09-01") باعثِ ریست‌شدنِ خودکارِ روزانه می‌شه - نگاه کن به
    cards._sync_daily_tokens."""
    __tablename__ = "user_card_tokens"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, nullable=False)
    user_id = Column(BigInteger, nullable=False)
    day_key = Column(String, nullable=False)
    free_rare = Column(Integer, default=0)
    free_wild = Column(Integer, default=0)
    free_legend = Column(Integer, default=0)
    paid_used = Column(Integer, default=0)


class UserCardProgress(Base):
    """آیا پلیر پاداشِ کاملِ هر کدوم از ۳ لیست رو تو این ایونت گرفته یا نه -
    برای جلوگیری از دوبار دادنِ پاداش."""
    __tablename__ = "user_card_progress"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, nullable=False)
    user_id = Column(BigInteger, nullable=False)
    list1_reward_claimed = Column(Boolean, default=False)
    list2_reward_claimed = Column(Boolean, default=False)
    list3_reward_claimed = Column(Boolean, default=False)


class CardListing(Base):
    """آگهیِ فروشِ یه کارت بینِ خودِ پلیرها - فروشنده هر قیمتی که بخواد می‌ذاره،
    هر کارتی (حتی اگه تنها نسخه‌ش باشه) قابل‌فروشه. با ثبتِ آگهی، همون لحظه
    یه واحد از خودِ کارت از کشوی فروشنده کم می‌شه (امانتی پیشِ بازار می‌مونه)
    تا نشه بیشتر از چیزی که داره بفروشه؛ اگه لغو کنه، برمی‌گرده بهش."""
    __tablename__ = "card_listings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, nullable=False)
    seller_id = Column(BigInteger, nullable=False)
    slot_id = Column(Integer, ForeignKey("card_slots.id"))
    price = Column(Float, nullable=False)
    created_at = Column(DateTime, default=now)
    is_sold = Column(Boolean, default=False)
    buyer_id = Column(BigInteger, nullable=True)
    sold_at = Column(DateTime, nullable=True)


# ---------------------------------------------------------------------------
# ادمین‌های فرعی (زیرِ مالکِ اصلی)
# ---------------------------------------------------------------------------

class AdminUser(Base):
    """ادمینِ فرعی که مالک از پنل اضافه کرده. permissions یه لیستِ JSON از
    کلیدهای دسته‌بندیِ اجازه‌داده‌شده‌ست (نگاه کن به admin.ADMIN_PERMISSION_CATEGORIES)
    - پیش‌فرض خالیه (هیچ‌چی باز نیست) تا مالک خودش دستی هرکدوم رو که خواست باز کنه.
    مالکِ اصلی (config.OWNER_ID) هیچ‌وقت این‌جا نیست و همیشه به همه‌چیز دسترسیِ
    کامل داره؛ خودِ این جدول (افزودن/حذف/تغییرِ دسترسیِ ادمین) هم همیشه فقط
    دستِ مالکِ اصلیه، حتی اگه یه ادمین همه‌ی دسترسی‌ها رو داشته باشه."""
    __tablename__ = "admin_users"
    user_id = Column(BigInteger, primary_key=True)
    added_at = Column(DateTime, default=now)
    added_by = Column(BigInteger, nullable=True)
    permissions = Column(Text, default="[]")


class GroupChat(Base):
    """
    رجیستریِ گروه‌هایی که ربات توشون فعاله. هر بار پیامی از یک گروه بیاد این
    رکورد بروز می‌شه؛ این فهرست برای اعلامِ «قرعه‌کشیِ سراسری» به همه‌ی گروه‌ها
    لازمه (چون قرعه‌کشی دیگه مخصوصِ یک گروه نیست).
    """
    __tablename__ = "group_chats"
    chat_id = Column(BigInteger, primary_key=True)
    title = Column(String, nullable=True)
    last_seen_at = Column(DateTime, default=now)


class LotteryEvent(Base):
    """
    قرعه‌کشیِ سراسریِ هاپ: فقط مالک از پیوی ربات می‌تونه شروعش کنه (نه با تایپ
    تو گروه)، اول باید جایزه‌ی خودکارِ هر برنده و تعداد برنده‌ها رو مشخص کنه،
    بعد بات این ایونت رو تو همه‌ی گروه‌های شناخته‌شده (GroupChat) اعلام می‌کنه.
    مالک بعدا از پیوی برنده‌ها رو دستی (با تیک‌زدنِ چندتایی) یا شانسی انتخاب
    می‌کنه و جایزه‌ی هرکدوم خودکار به حسابش واریز می‌شه. در هر لحظه حداکثر یک
    قرعه‌کشیِ فعال وجود داره.
    """
    __tablename__ = "lottery_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    prize_amount = Column(Float, default=0)  # جایزه‌ای که خودکار به هر برنده داده می‌شه
    winner_count = Column(Integer, default=1)  # چند نفر قراره برنده بشن
    is_active = Column(Boolean, default=True)
    participants_json = Column(Text, default="[]")
    winner_id = Column(BigInteger, nullable=True)  # قدیمی/تک‌برنده - برای سازگاری نگه داشته شده
    winners_json = Column(Text, default="[]")  # فهرستِ آی‌دیِ همه‌ی برنده‌ها
    created_at = Column(DateTime, default=now)
    finished_at = Column(DateTime, nullable=True)

    def participants(self):
        return json.loads(self.participants_json or "[]")

    def set_participants(self, ids):
        self.participants_json = json.dumps(ids)

    def winners(self):
        return json.loads(self.winners_json or "[]")

    def set_winners(self, ids):
        self.winners_json = json.dumps(ids)


class LotteryBroadcastMessage(Base):
    """هر پیامِ اعلامِ قرعه‌کشیِ سراسری که تو یک گروهِ مشخص فرستاده شده (یک ردیف
    به‌ازای هر گروه) - برای اینکه بعدا بشه اعلامِ برنده رو تو همون گروه‌ها فرستاد."""
    __tablename__ = "lottery_broadcast_messages"
    id = Column(Integer, primary_key=True, autoincrement=True)
    event_id = Column(Integer, ForeignKey("lottery_events.id"))
    chat_id = Column(BigInteger)
    chat_title = Column(String, nullable=True)
    message_id = Column(BigInteger, nullable=True)


class Product(Base):
    """محصولات اضافی‌ای که مالک از پنل مدیریت برای سوپرمارکت تعریف می‌کنه
    (علاوه بر ۴ محصول پیش‌فرض: گوشت گربه/دارچین خیار/موز/تخم سگ که ثابت می‌مونن).
    هر محصول از یک سطحِ مشخصِ «سطح محصولات سوپرمارکت» به بعد قابل تولید می‌شه."""
    __tablename__ = "products"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, unique=True)
    emoji = Column(String, default="📦")
    unlock_level = Column(Integer, default=1)  # از چه سطحی از market_product_level باز می‌شه
    daily_price = Column(Float, default=10)    # قیمت روز (به هاپ پوینت)، توسط مالک قابل تغییره
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)


class UserProduct(Base):
    __tablename__ = "user_products"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, ForeignKey("users.telegram_id", deferrable=True, initially="DEFERRED"))
    product_id = Column(Integer, ForeignKey("products.id"))
    amount = Column(Float, default=0)


class FactoryRank(Base):
    """
    «مقام»های کارخونه (مثلا سگ تازه‌کار / سگ حرفه‌ای / سگ افسانه‌ای). هر مقام از
    سطح ۱ تا num_levels رو داره. سطح‌ها بین مقام‌ها «مشترک»ان: سطح ۵ مقامِ اول
    دقیقا همون مقدارِ تولید/ظرفیتِ سطح ۵ مقامِ دومه (نگاه کن به FactoryLevelDef)؛
    تنها فرقِ مقام‌ها اینه که هر کدوم چند سطح داره - مقامی که سطح بیشتری داره
    امکانِ رسیدن به سطوحِ بالاتر (و در نتیجه تولیدِ بیشتر) رو می‌ده. وقتی کاربر
    به آخرِ سطوحِ مقامِ فعلیش برسه و بره مقامِ بعد، سطحش به ۱ برمی‌گرده و تولیدش
    ریست می‌شه (بعد از تاییدِ خودش). مالک از پنل می‌تونه مقام اضافه/حذف/تغییرنام
    بده یا تعداد سطح‌هاش رو کم‌وزیاد کنه.
    """
    __tablename__ = "factory_ranks"
    id = Column(Integer, primary_key=True, autoincrement=True)
    order = Column(Integer, nullable=False, unique=True)  # ترتیب مقام: ۱، ۲، ۳...
    name = Column(String, nullable=False)
    num_levels = Column(Integer, nullable=False, default=5)  # این مقام از سطح ۱ تا این عدد رو داره


class FactoryLevelDef(Base):
    """
    مقدارِ سطحِ «نسبیِ مشترک» شماره‌ی level_number. این سطح فارغ از اینکه کاربر
    تو کدوم مقامیه همیشه همین تولید/ظرفیت/هزینه رو داره (سطح ۵ مقامِ اول ==
    سطح ۵ مقامِ دوم). اگه مالک برای این سطح چیزی دستی ست نکرده باشه، از فرمولِ
    پیش‌فرضِ پنل (production_base/increment و...) محاسبه می‌شه؛ این‌طوری لازم
    نیست همه‌ی سطوح رو دستی پر کنه.
    """
    __tablename__ = "factory_level_defs"
    level_number = Column(Integer, primary_key=True)  # سطحِ نسبی (از ۱ شروع می‌شه)
    production_per_min = Column(Float, nullable=True)
    capacity = Column(Float, nullable=True)
    upgrade_cost = Column(Float, nullable=True)


# ---------------------------------------------------------------------------
# تاکسیِ هاپویی
# ---------------------------------------------------------------------------

class TaxiCarModel(Base):
    """مدلِ ماشینِ تاکسی که مالک از پنل می‌سازه. پیش‌فرض هیچ ماشینی وجود نداره؛
    پلیر باید یکی از این مدل‌ها رو بخره تا بتونه تاکسی‌رانی کنه. قیمت و مصرفِ
    بنزین/ظرفیتِ باک/سقفِ موتور مالِ خودِ مدل‌ان؛ بقیه‌ی قوانینِ تاکسی (نرخِ
    کرایه، سقفِ ارتقایِ مقام/محبوبیت، کارواش، ساعتِ کار/استراحت و...) سراسری‌ان
    و از game_config میان (نگاه کن به taxi.py) تا مالک یه‌جا همه رو تنظیم کنه."""
    __tablename__ = "taxi_car_models"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    price = Column(Float, nullable=False, default=80000000)
    gas_tank_liters = Column(Float, nullable=False, default=40)
    gas_use_per_hour = Column(Float, nullable=False, default=4)
    engine_max_level = Column(Integer, nullable=False, default=20)
    is_active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)


class TaxiRank(Base):
    """«مقام»های محبوبیتِ راننده‌ی تاکسی - دقیقا مثلِ FactoryRank: سطح‌ها بینِ
    مقام‌ها مشترکن (سطح ۵ مقامِ اول == سطح ۵ مقامِ دوم، نگاه کن به TaxiLevelDef)؛
    تنها فرقِ مقام‌ها تعداد سطح‌هاشونه. این محبوبیت مالِ خودِ راننده‌ست، نه
    ماشین - عوض‌کردنِ ماشین چیزی رو ازش کم نمی‌کنه."""
    __tablename__ = "taxi_ranks"
    id = Column(Integer, primary_key=True, autoincrement=True)
    order = Column(Integer, nullable=False, unique=True)
    name = Column(String, nullable=False)
    num_levels = Column(Integer, nullable=False, default=5)


class TaxiLevelDef(Base):
    """مقدارِ سطحِ نسبیِ مشترکِ محبوبیت. اگه مالک دستی ست نکرده باشه، از فرمولِ
    پیش‌فرضِ پنل (taxi_appeal_*) محاسبه می‌شه - دقیقا مثلِ FactoryLevelDef."""
    __tablename__ = "taxi_level_defs"
    level_number = Column(Integer, primary_key=True)
    fare_bonus_per_min = Column(Float, nullable=True)
    wait_min_minutes = Column(Float, nullable=True)
    wait_max_minutes = Column(Float, nullable=True)
    upgrade_cost = Column(Float, nullable=True)


class CasinoRound(Base):
    """یک دور بازیِ کازینو هاپویی (تاس/بولینگ/دارت/بسکتبال/فوتبال)."""
    __tablename__ = "casino_rounds"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger)
    message_id = Column(BigInteger, nullable=True)
    game_type = Column(String)  # dc, bw, dt, bk, fb
    initiator_id = Column(BigInteger)
    entry_amount = Column(Float, nullable=True)
    target_players = Column(Integer, nullable=True)
    dice_count = Column(Integer, default=1)
    # setup -> در حال انتخاب مبلغ/تعداد | lobby -> منتظر پیوستن بازیکن‌ها
    # resolved -> تمام‌شده | cancelled -> لغوشده (کسی نپیوست)
    status = Column(String, default="setup")
    lobby_opened_at = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=now)
    ended_at = Column(DateTime, nullable=True)  # وقتی resolved/cancelled شد - برای محدودیتِ فاصله‌ی بینِ دو کازینو


class CasinoPlayer(Base):
    __tablename__ = "casino_players"
    id = Column(Integer, primary_key=True, autoincrement=True)
    round_id = Column(Integer, ForeignKey("casino_rounds.id"))
    user_id = Column(BigInteger)
    bet_choice = Column(String, nullable=True)   # even / odd / number (فقط تاس)
    bet_number = Column(Integer, nullable=True)  # فقط وقتی bet_choice == number
    score = Column(Integer, nullable=True)       # نتیجه‌ی تاس/بولینگ/دارت/بسکتبال/فوتبال
    joined_at = Column(DateTime, default=now)


class UnoRound(Base):
    """یک دورِ بازیِ «اونو هاپویی».

    چرخه: setup (سازنده مبلغ/تعدادِ نفرات رو می‌چینه) -> lobby (تو گروه، بقیه
    می‌پیوندن) -> playing (تو پیویِ هر بازیکن، نوبتی) -> resolved/cancelled.

    خودِ دست‌ها و دسته‌ی کارت به‌صورتِ JSON نگه داشته می‌شن (نه جدولِ جدا) چون
    همیشه یکجا خونده/نوشته می‌شن و این‌طوری هر حرکت فقط یه رفت‌وبرگشتِ دیتابیس
    داره - مهم برای همون نگرانیِ سرعتِ زیرِ بار.
    """
    __tablename__ = "uno_rounds"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger)
    message_id = Column(BigInteger, nullable=True)
    initiator_id = Column(BigInteger)
    entry_amount = Column(Float, nullable=True)
    target_players = Column(Integer, nullable=True)
    status = Column(String, default="setup")
    lobby_opened_at = Column(DateTime, nullable=True)

    draw_pile_json = Column(Text, default="[]")    # کارت‌هایِ روی هم (کشیدنی - مخفی)
    discard_top = Column(String, nullable=True)    # آخرین کارتِ روشده (برای همه معلومه)
    active_color = Column(String, nullable=True)   # رنگِ جاری (بعد از کارتِ ویژه ممکنه عوض شه)
    pending_draw = Column(Integer, default=0)      # جریمه‌ی تجمعیِ +۲..+۶ که به نفرِ بعدی می‌رسه
    direction = Column(Integer, default=1)         # ۱ یا ۱- (کارتِ برعکس)
    turn_user_id = Column(BigInteger, nullable=True)
    turn_started_at = Column(DateTime, nullable=True)
    turn_deadline_at = Column(DateTime, nullable=True)
    turn_seq = Column(Integer, default=0)          # شماره‌ی نوبت - جلوی اجرایِ دوباره‌ی تایمرِ یه نوبتِ گذشته رو می‌گیره

    created_at = Column(DateTime, default=now)
    ended_at = Column(DateTime, nullable=True)
    last_action_at = Column(DateTime, default=now)
    winner_id = Column(BigInteger, nullable=True)


class UnoPlayer(Base):
    __tablename__ = "uno_players"
    id = Column(Integer, primary_key=True, autoincrement=True)
    round_id = Column(Integer, ForeignKey("uno_rounds.id"), index=True)
    user_id = Column(BigInteger, index=True)
    seat = Column(Integer, default=0)             # ترتیبِ نشستن سرِ میز
    hand_json = Column(Text, default="[]")        # دستِ خودِ بازیکن - فقط خودش می‌بینه
    dm_message_id = Column(BigInteger, nullable=True)
    missed_turns = Column(Integer, default=0)     # دو بار ردشدنِ نوبت => حذف از بازی
    eliminated = Column(Boolean, default=False)
    finished_rank = Column(Integer, nullable=True)
    joined_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("round_id", "user_id", name="uq_uno_round_player"),)


class RouletteRound(Base):
    """یک دورِ «رولت روسی 🔫» (از منویِ کازینو هاپویی).

    دو حالت داره:
    - mode="group": لابی تو همین گپ (ساختنِ مبلغ/تعدادِ نفرات مثلِ بقیه‌ی بازی‌ها،
      سازنده داره، همه تو یه پیامِ مشترک بازی می‌کنن).
    - mode="global": لابیِ جهانی - میزِ بی‌صاحبه؛ هر بازیکن پنلِ خودش رو تو گپِ
      خودش داره (RoulettePlayer.chat_id/message_id) و کسایی که همون مبلغ و همون
      تعدادِ نفر رو انتخاب کردن با هم می‌افتن.

    چرخه: setup (فقط group) -> lobby (group: منتظرِ پیوستن | global: منتظرِ
    حریف) -> playing -> resolved/cancelled.
    """
    __tablename__ = "roulette_rounds"
    id = Column(Integer, primary_key=True, autoincrement=True)
    mode = Column(String, default="group")  # group / global
    chat_id = Column(BigInteger)
    message_id = Column(BigInteger, nullable=True)
    initiator_id = Column(BigInteger, nullable=True)  # فقط تو حالتِ group
    entry_amount = Column(Float, nullable=True)
    target_players = Column(Integer, nullable=True)
    status = Column(String, default="setup", index=True)
    lobby_opened_at = Column(DateTime, nullable=True)

    # تپانچه: خشابِ ۶ خونه‌ای با یه تیر. bullet_pos جای تیر، chamber_idx خونه‌ای
    # که ماشه‌ی بعدی رو می‌زنه. بعد از هر کُشته‌شدن خشاب دوباره پر و چرخونده می‌شه.
    bullet_pos = Column(Integer, default=0)  # (قدیمی - خشابِ تک‌تیر) الان از chambers استفاده می‌شه
    chamber_idx = Column(Integer, default=0)
    # چیدمانِ کاملِ خشاب: رشته‌ای از B (مشقی) و L (جنگی)، مثلاً "BBLBBLB"؛ chamber_idx اشاره‌گرِ
    # خونه‌ی بعدیه. تعدادِ مشقی/جنگی از تنظیماتِ پنلِ ادمین (casino_rr_*) می‌آد.
    chambers = Column(Text, nullable=True)
    turn_user_id = Column(BigInteger, nullable=True)
    turn_seq = Column(Integer, default=0)  # جلوی دکمه‌ی قدیمی/تایمرِ نوبتِ گذشته رو می‌گیره
    turn_started_at = Column(DateTime, nullable=True)
    turn_ready_at = Column(DateTime, nullable=True)     # تا قبلش «انتظار برای چرخاندنِ خشاب» ـه و شلیک ممکن نیست
    turn_deadline_at = Column(DateTime, nullable=True)  # = turn_ready_at + مهلتِ شلیک؛ ردشدنش یعنی حذف
    log_text = Column(Text, default="")  # چندخطِ آخرِ اتفاق‌ها برای نمایش تو پنل
    winner_id = Column(BigInteger, nullable=True)

    created_at = Column(DateTime, default=now)
    last_action_at = Column(DateTime, default=now)
    ended_at = Column(DateTime, nullable=True)


class MafiaRound(Base):
    """یه دورِ «مافیا/گرگینه» (کازینو هاپویی). لابیِ همیشه تو گروه؛ نقش‌ها با پیامِ
    خصوصی به هر بازیکن گفته می‌شه (دقیقاً مثلِ الگویِ اونو/نبردِ دریایی)."""
    __tablename__ = "mafia_rounds"
    id = Column(Integer, primary_key=True, autoincrement=True)
    mode = Column(String, default="group")  # group / global
    chat_id = Column(BigInteger)
    message_id = Column(BigInteger, nullable=True)
    initiator_id = Column(BigInteger, nullable=True)
    scenario = Column(String, nullable=True)     # classic/advanced/quick/psycho
    entry_amount = Column(Float, nullable=True)
    target_players = Column(Integer, nullable=True)   # ۵ تا ۸
    status = Column(String, default="setup", index=True)  # setup/lobby/night/day/resolved/cancelled
    lobby_opened_at = Column(DateTime, nullable=True)

    phase_seq = Column(Integer, default=0)     # جلوی اکشن/تایمرِ فازِ گذشته رو می‌گیره
    day_number = Column(Integer, default=0)    # شمارشِ شب/روز (هر دو یه عدد؛ «شبِ ۲» یعنی بعدِ «روزِ ۱»)
    phase_started_at = Column(DateTime, nullable=True)
    phase_deadline_at = Column(DateTime, nullable=True)

    # شیفتِ صحبتِ روز (فقط لابیِ محلی/گروهی): تا وقتی day_speak_active روشنه، فازِ
    # روز صرفاً یه چرخِ نوبتیِ صحبته - رای‌گیریِ واقعی (phase_deadline_at بالا) بعدِ
    # تمومِ این چرخ شروع می‌شه. day_speak_order لیستِ JSON از user_id هاست (ترتیبِ
    # تصادفیِ همون روز)، day_speak_index نفرِ فعلی تو اون لیسته.
    day_speak_active = Column(Boolean, default=False)
    day_speak_order = Column(Text, nullable=True)
    day_speak_index = Column(Integer, default=0)
    day_speak_seq = Column(Integer, default=0)         # جلوی تایم‌اوتِ نوبتِ قبلی رو می‌گیره
    day_speak_message_id = Column(BigInteger, nullable=True)
    day_speak_deadline_at = Column(DateTime, nullable=True)
    # حرف‌هایِ امروز: JSON {"day": N, "items": [{"u": uid, "t": متن یا "", "o": spoke/skipped/done/timeout}]}
    # تا آخرِ شبِ N تو پنلِ همه می‌مونه و با شروعِ روزِ N+1 پاک/جایگزین می‌شه.
    day_speeches = Column(Text, nullable=True)

    log_text = Column(Text, default="")        # چندخطِ آخرِ اتفاق‌ها (برایِ پنلِ گروه)
    winner_side = Column(String, nullable=True)  # mafia/town/psycho/draw

    created_at = Column(DateTime, default=now)
    last_action_at = Column(DateTime, default=now)
    ended_at = Column(DateTime, nullable=True)


class MafiaPlayer(Base):
    __tablename__ = "mafia_players"
    id = Column(Integer, primary_key=True, autoincrement=True)
    round_id = Column(Integer, ForeignKey("mafia_rounds.id"), index=True)
    user_id = Column(BigInteger, index=True)
    role = Column(String, nullable=True)    # mafia/doctor/detective/bodyguard/sniper/psycho/citizen
    alive = Column(Boolean, default=True)
    out_reason = Column(Text, nullable=True)
    chat_id = Column(BigInteger)             # = user_id؛ پیوی
    dm_message_id = Column(BigInteger, nullable=True)
    sniper_used = Column(Boolean, default=False)
    night_target_id = Column(BigInteger, nullable=True)  # 0 = رد کرد، None = هنوز تصمیم نگرفته
    day_vote_id = Column(BigInteger, nullable=True)       # 0 = رای نداد/ابستین، None = هنوز رای نداده
    joined_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("round_id", "user_id", name="uq_mafia_round_player"),)


class RoulettePlayer(Base):
    __tablename__ = "roulette_players"
    id = Column(Integer, primary_key=True, autoincrement=True)
    round_id = Column(Integer, ForeignKey("roulette_rounds.id"), index=True)
    user_id = Column(BigInteger, index=True)
    chat_id = Column(BigInteger)              # گپی که پنلِ این بازیکن توشه
    message_id = Column(BigInteger, nullable=True)  # پیامِ پنلِ این بازیکن
    alive = Column(Boolean, default=True)
    out_reason = Column(Text, nullable=True)  # دلیلِ حذف/مرگ که تو پنل کنارِ اسمش نوشته می‌شه
    joined_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("round_id", "user_id", name="uq_roulette_round_player"),)


class HelpNode(Base):
    """درختِ «راهنمایی هاپویی» - هر گره یه بخش/زیربخشه. گره‌های ریشه (parent_id
    خالی) همونایی هستن که مستقیم زیرِ «📖 راهنمایی هاپویی» نشون داده می‌شن.
    هر گره می‌تونه هم توضیح (description) داشته باشه هم زیربخش (بچه)."""
    __tablename__ = "help_nodes"
    id = Column(Integer, primary_key=True, autoincrement=True)
    parent_id = Column(Integer, ForeignKey("help_nodes.id"), nullable=True)
    title = Column(String)
    description = Column(Text, nullable=True)
    order_index = Column(Integer, default=0)
    created_at = Column(DateTime, default=now)


class GuessNumberRound(Base):
    """بازیِ «حدسِ عدد» تو کازینو هاپویی.
    - تک‌نفره (mode="solo"): بات یه عددِ مخفی بینِ ۱ تا max_number انتخاب
      می‌کنه، بازیکن با ریپلای‌کردنِ عدد رو پیامِ بازی حدس می‌زنه (حداکثر
      max_guesses بار)، هر بار جواب «بزرگتر/کوچیک‌تر/درسته» می‌گیره.
    - دونفره (mode="duo"): سازنده (initiator) تو پیویِ بات یه عدد مخفی
      انتخاب می‌کنه، نفرِ دوم (که بهش پیوسته) تو خودِ گروه حدس می‌زنه."""
    __tablename__ = "guessnum_rounds"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger)
    message_id = Column(BigInteger, nullable=True)
    mode = Column(String, default="solo")  # solo / duo
    initiator_id = Column(BigInteger)
    entry_amount = Column(Float, nullable=True)
    # setup -> lobby(فقط duo) -> setting_number(فقط duo، تو پیوی) -> guessing -> resolved/cancelled
    status = Column(String, default="setup")
    setter_id = Column(BigInteger, nullable=True)
    guesser_id = Column(BigInteger, nullable=True)
    secret_number = Column(Integer, nullable=True)
    max_number = Column(Integer, default=1000)
    max_guesses = Column(Integer, default=5)
    guesses = Column(Text, default="[]")  # JSON لیستِ [عدد, "bigger"/"smaller"/"correct"]
    setter_dm_message_id = Column(BigInteger, nullable=True)
    lobby_opened_at = Column(DateTime, nullable=True)
    last_action_at = Column(DateTime, default=now)
    created_at = Column(DateTime, default=now)
    ended_at = Column(DateTime, nullable=True)


class MastermindRound(Base):
    """بازیِ «رمزیاب» (کدِ مخفی، بر اساسِ Mastermind) - ۲نفره. هر بازیکن یه
    توالیِ مخفیِ رنگی می‌چینه، بعد نوبتی سعی می‌کنن کدِ همدیگه رو حدس بزنن.
    هر حدس فیدبک می‌گیره: چندتا رنگِ درست تو جای درست (⚫) و چندتا رنگِ درست
    ولی جای اشتباه (⚪). مثلِ نبردِ دریایی، چیدنِ کد و حدس‌زدن از طریقِ پیویِ
    بات انجام می‌شه که مخفی بمونه."""
    __tablename__ = "mastermind_rounds"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger)
    group_message_id = Column(BigInteger, nullable=True)
    initiator_id = Column(BigInteger)
    entry_amount = Column(Float, nullable=True)
    code_length = Column(Integer, default=4)
    palette_size = Column(Integer, default=6)
    max_turns = Column(Integer, default=10)
    # setup -> lobby -> placing -> playing -> resolved -> cancelled
    status = Column(String, default="setup")
    player1_id = Column(BigInteger, nullable=True)
    player2_id = Column(BigInteger, nullable=True)
    player1_dm_message_id = Column(BigInteger, nullable=True)
    player2_dm_message_id = Column(BigInteger, nullable=True)
    player1_code = Column(Text, default="[]")       # JSON لیستِ نهاییِ رنگ (ایندکس)
    player2_code = Column(Text, default="[]")
    player1_draft = Column(Text, default="[]")       # کدِ نیمه‌ساخته (چه موقعِ چیدن، چه موقعِ ساختنِ حدسِ فعلی)
    player2_draft = Column(Text, default="[]")
    player1_confirmed_at = Column(DateTime, nullable=True)
    player2_confirmed_at = Column(DateTime, nullable=True)
    player1_guesses = Column(Text, default="[]")    # JSON [[[رنگ‌ها],black,white], ...]
    player2_guesses = Column(Text, default="[]")
    turn_user_id = Column(BigInteger, nullable=True)
    lobby_opened_at = Column(DateTime, nullable=True)
    last_action_at = Column(DateTime, default=now)
    created_at = Column(DateTime, default=now)
    ended_at = Column(DateTime, nullable=True)


class BattleshipRound(Base):
    """بازیِ «نبردِ دریایی» تو کازینو هاپویی - ۲نفره، صفحه‌ی ۵×۵، هرکس ۴ نقطه
    (کشتی) مخفی می‌ذاره و نوبتی نقطه‌ی همدیگه رو حدس می‌زنن. چون باید مخفی
    بمونه، جای‌گذاریِ کشتی‌ها و حدس‌زدن از طریقِ پیویِ خودِ بات با هرکدوم از
    بازیکن‌ها انجام می‌شه (تو پیامِ گروه فقط وضعیتِ کلی/برد‌وباخت اعلام می‌شه)."""
    __tablename__ = "battleship_rounds"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger)
    group_message_id = Column(BigInteger, nullable=True)
    initiator_id = Column(BigInteger)
    entry_amount = Column(Float, nullable=True)
    ships_per_player = Column(Integer, default=4)  # از تنظیماتِ کازینو موقعِ ساختِ بازی خونده می‌شه - وسطِ بازی عوض نمی‌شه
    max_turns = Column(Integer, default=12)
    # setup -> lobby -> placing -> playing -> resolved -> cancelled
    status = Column(String, default="setup")
    player1_id = Column(BigInteger, nullable=True)
    player2_id = Column(BigInteger, nullable=True)
    player1_dm_message_id = Column(BigInteger, nullable=True)
    player2_dm_message_id = Column(BigInteger, nullable=True)
    player1_ships = Column(Text, default="[]")     # JSON لیستِ [row,col] - دقیقاً ۴تا
    player2_ships = Column(Text, default="[]")
    player1_confirmed_at = Column(DateTime, nullable=True)  # وقتی خودِ پلیر روی «تایید نهایی»‌ی جای‌گذاری زد
    player2_confirmed_at = Column(DateTime, nullable=True)
    player1_guesses = Column(Text, default="[]")   # JSON لیستِ [row,col,hit]
    player2_guesses = Column(Text, default="[]")
    turn_user_id = Column(BigInteger, nullable=True)
    lobby_opened_at = Column(DateTime, nullable=True)
    last_action_at = Column(DateTime, default=now)
    created_at = Column(DateTime, default=now)
    ended_at = Column(DateTime, nullable=True)


# ---------------------------------------------------------------------------
# فروشگاه هاپویی + سیستمِ حمله/گروگان («فروشگاه و حمله»)
# ---------------------------------------------------------------------------

class ShopItem(Base):
    """تعریفِ یه آیتمِ فروشگاهِ هاپویی که فقط ادمین از پنل می‌سازه. دسته‌ها:
    guard (محافظ) / gun (گان) / smoke (بمبِ دودزا) / item (آیتمِ عمومی) /
    booster (بوستر - با booster_type مشخص می‌شه: money یا power).
    هیچ ردیفی از این جدول به‌صورتِ پیش‌فرض ساخته نمی‌شه."""
    __tablename__ = "shop_items"
    id = Column(Integer, primary_key=True, autoincrement=True)
    category = Column(String, nullable=False)          # guard / gun / smoke / item / booster
    booster_type = Column(String, nullable=True)        # money / power (فقط وقتی category == booster)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    price = Column(Float, nullable=False, default=0)
    level = Column(Integer, nullable=True)
    power = Column(Float, nullable=True)                # قدرتِ حمله(گان)/دفاع(محافظ)
    pct = Column(Float, nullable=True)                   # درصدِ اثر: محافظت/کاهشِ فرار/افزایشِ درآمد/افزایشِ قدرت
    uses = Column(Integer, nullable=True)                 # تعداد دفعاتِ استفاده (None = نامحدود)
    duration_minutes = Column(Integer, nullable=True)     # فقط بوستر: مدتِ ماندگاری
    active = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)


class InventoryItem(Base):
    """یه نسخه/ردیف از آیتمِ خریداری‌شده تو کوله‌پشتیِ کاربر. برای گان/محافظ/
    بمبِ دودزا هر خرید معمولاً ردیفِ جداگونه می‌سازه (uses_remaining خودش رو
    داره)؛ برای آیتمِ عمومی و بوستر (تا وقتی مصرف/فعال نشدن) رویِ هم پشته
    می‌شن (quantity). equipped فقط برای گان/محافظ/بمبِ دودزا معنا داره: یعنی
    الان «مجهز»شه (برای گان و محافظ همزمان فقط یکی می‌تونه مجهز باشه)."""
    __tablename__ = "inventory_items"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    shop_item_id = Column(Integer, ForeignKey("shop_items.id"), nullable=False)
    quantity = Column(Integer, default=1)
    uses_remaining = Column(Integer, nullable=True)
    equipped = Column(Boolean, default=False)
    acquired_at = Column(DateTime, default=now)


class ActiveBooster(Base):
    """بوسترِ فعالِ کاربر (پول یا قدرت) - فقط یکی از هر نوع می‌تونه هم‌زمان
    فعال باشه؛ با تمومِ‌شدنِ ends_at خودکار بی‌اثر می‌شه (نیازی به پاک‌کردنِ
    دستی نیست، همه‌جا با مقایسه‌ی ends_at > الان چک می‌شه)."""
    __tablename__ = "active_boosters"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    booster_type = Column(String, nullable=False)  # money / power
    pct = Column(Float, nullable=False, default=0)
    shop_item_id = Column(Integer, nullable=True)
    started_at = Column(DateTime, default=now)
    ends_at = Column(DateTime, nullable=False)


class Hostage(Base):
    """وضعیتِ فعلیِ گروگان‌گیریِ موفق (بعدِ بردِ مهاجم تو مینی‌گیم). هر کاربر
    در آنِ واحد فقط می‌تونه گروگانِ یک نفر باشه."""
    __tablename__ = "hostages"
    id = Column(Integer, primary_key=True, autoincrement=True)
    victim_id = Column(BigInteger, nullable=False, index=True)
    attacker_id = Column(BigInteger, nullable=False, index=True)
    chat_id = Column(BigInteger, nullable=True)
    started_at = Column(DateTime, default=now)
    ends_at = Column(DateTime, nullable=False)
    status = Column(String, default="active")  # active / freed_paid / escaped / released
    escape_checks_done = Column(Integer, default=0)
    smoke_pct = Column(Float, default=0)  # مجموعِ اثرِ بمبِ دودزاییِ مصرف‌شده رو این گروگان‌گیری


class ProductionPenalty(Base):
    """جریمه‌ی موقتِ تولیدِ Hop Manager (کارخونه) - kind: defender_fail (۴۰
    دقیقه، ۷۰٪) یا attacker_killed (۱۵ دقیقه، ۲۵٪)."""
    __tablename__ = "production_penalties"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    kind = Column(String, nullable=False)
    multiplier = Column(Float, nullable=False)
    ends_at = Column(DateTime, nullable=False)


class AttackSession(Base):
    """یه تلاشِ درحال‌انجامِ حمله/گروگان‌گیری (مینی‌گیمِ سه‌گزینه‌ای). بعدِ
    رسیدن به نتیجه (موفقیت/شکست/کشته‌شدنِ مهاجم/لغو)، status عوض می‌شه و دیگه
    فعال نیست - دکمه‌های قدیمی‌ش دیگه اثر ندارن."""
    __tablename__ = "attack_sessions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    attacker_id = Column(BigInteger, nullable=False)
    target_id = Column(BigInteger, nullable=False)
    chat_id = Column(BigInteger, nullable=False)
    message_id = Column(BigInteger, nullable=True)
    attacker_hp = Column(Integer, default=1500)
    defender_hp = Column(Integer, default=1500)
    attacker_power = Column(Float, default=0)         # قدرتِ مؤثرِ گانِ مهاجم (با بوسترِ قدرت)
    defender_gun_power = Column(Float, default=0)      # قدرتِ گانِ مجهزِ مدافع (برای ضدحمله رو انتخابِ غلط)
    defender_guard_power = Column(Float, default=0)    # قدرتِ مؤثرِ محافظِ مدافع (تقسیم‌بر۷ همینجا اعمال شده)
    attacker_inventory_gun_id = Column(Integer, nullable=True)
    defender_inventory_guard_id = Column(Integer, nullable=True)
    attacker_inventory_smoke_id = Column(Integer, nullable=True)
    correct_option = Column(String, nullable=True)
    wrong_count = Column(Integer, default=0)
    status = Column(String, default="active")  # active / hostage_success / attacker_failed / attacker_killed / cancelled
    created_at = Column(DateTime, default=now)
    resolved_at = Column(DateTime, nullable=True)
    last_action_at = Column(DateTime, default=now)  # آخرین حرکتِ ثبت‌شده - برای لغوِ خودکار بعدِ بی‌حرکتی


class PendingHostageConfirm(Base):
    """مرحله‌ی «آیا مطمئنی؟» قبل از شروعِ واقعیِ گروگان‌گیری. اگه مهاجم تا
    ۶۰ ثانیه هیچ‌کدوم از دکمه‌های بله/خیر رو نزنه، خودکار لغو می‌شه تا هیچ‌وقت
    طرفِ مقابل به‌خاطرِ یه تأییدِ ول‌شده برای همیشه قفل نمونه."""
    __tablename__ = "pending_hostage_confirms"
    id = Column(Integer, primary_key=True, autoincrement=True)
    attacker_id = Column(BigInteger, nullable=False, index=True)
    target_id = Column(BigInteger, nullable=False, index=True)
    chat_id = Column(BigInteger, nullable=False)
    message_id = Column(BigInteger, nullable=True)
    created_at = Column(DateTime, default=now)


class DuelLobby(Base):
    """لابیِ خصوصیِ «نبردِ تن‌به‌تن» (بازیِ کازینو دونفره‌ی سه‌حرکتی: حمله/
    دفاع/ضدحمله). همه‌ی پیام‌ها و دکمه‌ها تو همون یه پیامِ گروهی مدیریت می‌شه
    که ادیت می‌شه - چیزی تکراری/جدا ساخته نمی‌شه."""
    __tablename__ = "duel_lobbies"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger, nullable=False)
    message_id = Column(BigInteger, nullable=True)
    host_id = Column(BigInteger, nullable=False)
    guest_id = Column(BigInteger, nullable=True)
    stake = Column(Float, default=0)
    status = Column(String, default="waiting")  # waiting / battle / finished / cancelled
    hp1 = Column(Integer, default=1500)
    hp2 = Column(Integer, default=1500)
    round_no = Column(Integer, default=1)
    move1 = Column(String, nullable=True)
    move2 = Column(String, nullable=True)
    sudden_death = Column(Boolean, default=False)
    winner_id = Column(BigInteger, nullable=True)
    created_at = Column(DateTime, default=now)
    ended_at = Column(DateTime, nullable=True)


# ---------------------------------------------------------------------------
# قاچاق هاپویی («فروشگاه/حمله» ازش کاملاً جداست؛ فقط «اسلحه» می‌تونه روش اثر
# بذاره - اونم فقط با تنظیمِ صریحِ ادمین در SmugglingGunRule). سیستم در ابتدا
# کاملاً خالیه؛ هیچ کالا/مرحله/گزینه/نیرویی پیش‌فرض ساخته نمی‌شه.
# ---------------------------------------------------------------------------

class SmugglingGood(Base):
    """یه کالای قاچاق. هر کالا مراحل/گزینه/ریسک/پاداش/جریمه/محدودیتِ روزانه‌ی
    کاملاً مستقلِ خودش رو داره - هیچ‌کدوم از این تنظیمات بینِ کالاها به اشتراک
    گذاشته نمی‌شه مگر با یه Ruleِ صریحِ نیرو که ادمین خودش می‌سازه."""
    __tablename__ = "smuggling_goods"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    cost = Column(Float, default=0)
    reward = Column(Float, default=0)
    overall_risk_display = Column(Float, nullable=True)
    min_level = Column(Integer, nullable=True)
    duration_minutes = Column(Integer, nullable=True)
    daily_limit_per_user = Column(Integer, default=1)
    active = Column(Boolean, default=True)
    show_in_today = Column(Boolean, default=True)
    created_at = Column(DateTime, default=now)


class SmugglingStage(Base):
    """یکی از حداکثر ۲۵ اسلاتِ ۵×۵ (فقط برای ترتیب - هیچ معنایِ جغرافیایی
    نداره). فقط مراحلی که ادمین active=True کرده به کاربر نشون داده می‌شن."""
    __tablename__ = "smuggling_stages"
    id = Column(Integer, primary_key=True, autoincrement=True)
    good_id = Column(Integer, ForeignKey("smuggling_goods.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    slot_index = Column(Integer, default=0)  # 1..25 - جایگاهِ خام تو شبکه‌ی ۵×۵
    order_index = Column(Integer, default=0)  # ترتیبِ واقعیِ نمایش به کاربر
    active = Column(Boolean, default=True)


class SmugglingOption(Base):
    """گزینه‌ی یه مرحله. good_id عمداً تکرار (denormalized) شده روی همین ردیف
    تا فیلترها و ایزوله‌سازیِ good+stage+option بدونِ جوینِ اضافه سریع باشه."""
    __tablename__ = "smuggling_options"
    id = Column(Integer, primary_key=True, autoincrement=True)
    stage_id = Column(Integer, ForeignKey("smuggling_stages.id"), nullable=False, index=True)
    good_id = Column(Integer, nullable=False, index=True)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    risk_pct = Column(Float, default=0)
    success_pct = Column(Float, nullable=False, default=50)
    reward_bonus = Column(Float, default=0)
    penalty_amount = Column(Float, default=0)
    penalty_pct = Column(Float, default=0)
    time_minutes = Column(Integer, nullable=True)
    success_text = Column(Text, default="")
    fail_text = Column(Text, default="")
    active = Column(Boolean, default=True)


class SmugglingStageTemplateGroup(Base):
    """«دسته‌مرحله»: یه قالبِ آماده از چند مرحله+گزینه که ادمین یه‌بار می‌سازه
    (تویِ پنلِ «دسته‌مرحله‌ها») و بعد موقعِ ساختن یا مدیریتِ هر کالا، به‌جایِ
    از نو ساختنِ تک‌تکِ مرحله/گزینه، فقط آیدیِ همین دسته رو می‌ده تا یه کپیِ
    کاملِ مستقل از مرحله‌ها/گزینه‌هاش رو تو مراحلِ اون کالا بسازه. بعدِ کپی‌شدن،
    هر کالا نسخه‌ی خودشِ کاملاً مستقل رو داره - پس مثلاً شانسِ موفقیتِ یه گزینه
    رو می‌شه تو هر کالا که همین دسته رو گرفته، جدا و متفاوت تنظیم کرد، بدونِ
    اینکه رو کالاهایِ دیگه‌ای که از همون دسته استفاده کردن اثر بذاره."""
    __tablename__ = "smuggling_stage_template_groups"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    created_at = Column(DateTime, default=now)


class SmugglingStageTemplate(Base):
    """یه مرحله‌یِ داخلِ یه «دسته‌مرحله» - دقیقاً هم‌شکلِ SmugglingStage، با این
    فرق که مستقیم به هیچ کالایی وصل نیست؛ فقط موقعِ کپی‌شدنِ دسته رو یه کالا،
    از روش یه SmugglingStageِ واقعی ساخته می‌شه."""
    __tablename__ = "smuggling_stage_templates"
    id = Column(Integer, primary_key=True, autoincrement=True)
    group_id = Column(Integer, ForeignKey("smuggling_stage_template_groups.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    slot_index = Column(Integer, default=0)
    order_index = Column(Integer, default=0)


class SmugglingOptionTemplate(Base):
    """گزینه‌یِ داخلِ یه مرحله‌یِ قالب - دقیقاً هم‌شکلِ SmugglingOption (همون
    فیلدهای ریسک/شانسِ موفقیت/پاداش/جریمه/متن)، فقط به‌جایِ stage_id واقعی به
    یه SmugglingStageTemplate وصله."""
    __tablename__ = "smuggling_option_templates"
    id = Column(Integer, primary_key=True, autoincrement=True)
    stage_template_id = Column(Integer, ForeignKey("smuggling_stage_templates.id"), nullable=False, index=True)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    risk_pct = Column(Float, default=0)
    success_pct = Column(Float, nullable=False, default=50)
    reward_bonus = Column(Float, default=0)
    penalty_amount = Column(Float, default=0)
    penalty_pct = Column(Float, default=0)
    time_minutes = Column(Integer, nullable=True)
    success_text = Column(Text, default="")
    fail_text = Column(Text, default="")


class SmugglingOperation(Base):
    """یه عملیاتِ قاچاقِ مستقل برایِ یه کاربر. وضعیت‌ها: pending/active/success/
    failed/cancelled/expired - بعدِ رسیدن به هرکدوم از حالت‌های پایانی، دیگه
    قابلِ ادامه نیست (چک می‌شه تو هر callback)."""
    __tablename__ = "smuggling_operations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    good_id = Column(Integer, nullable=False, index=True)
    chat_id = Column(BigInteger, nullable=True)
    message_id = Column(BigInteger, nullable=True)
    started_at = Column(DateTime, default=now)
    ended_at = Column(DateTime, nullable=True)
    current_stage_order = Column(Integer, default=1)
    total_stages = Column(Integer, default=1)
    status = Column(String, default="active")
    cost_paid = Column(Float, default=0)
    reward_total = Column(Float, default=0)
    penalty_total = Column(Float, default=0)
    result_note = Column(Text, default="")
    last_action_at = Column(DateTime, default=now)  # آخرین حرکتِ ثبت‌شده - برای لغوِ خودکار بعدِ بی‌حرکتی
    # وقتی یه گزینه‌ی زمان‌دار (SmugglingOption.time_minutes) انتخاب می‌شه، تا این
    # لحظه عملیات «در انتظار» می‌مونه و مرحله‌ی بعدی اصلاً باز نمی‌شه. تا وقتی این
    # پر باشه و هنوز نرسیده، مهلتِ بی‌حرکتی هم اعمال نمی‌شه (وگرنه یه مسیرِ ۵۰
    # دقیقه‌ای همیشه قبل از رسیدنش خودکار لغو می‌شد).
    stage_ready_at = Column(DateTime, nullable=True)
    pending_note = Column(Text, default="")  # متنِ موفقیتِ گزینه‌ی زمان‌دار، تا بعدِ اتمامِ انتظار نشون داده شه


class SmugglingOperationStage(Base):
    """لاگِ هر مرحله‌ای که واقعاً طی شده - برای گزارش/بررسیِ اقتصادی (بخشِ ۳۴)."""
    __tablename__ = "smuggling_operation_stages"
    id = Column(Integer, primary_key=True, autoincrement=True)
    operation_id = Column(Integer, ForeignKey("smuggling_operations.id"), nullable=False, index=True)
    stage_id = Column(Integer, nullable=False)
    option_id = Column(Integer, nullable=True)
    success_chance_used = Column(Float, nullable=True)
    success_roll = Column(Float, nullable=True)
    passed = Column(Boolean, nullable=True)
    helpers_used_json = Column(Text, default="[]")
    gun_rule_id = Column(Integer, nullable=True)
    created_at = Column(DateTime, default=now)


class SmugglingHelper(Base):
    """تعریفِ یه نوع نیرویِ کمکی (خبرچین/وکیل/... - هرچی ادمین بخواد بسازه).
    هیچ نیرویی پیش‌فرض ساخته نمی‌شه."""
    __tablename__ = "smuggling_helpers"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    price = Column(Float, default=0)
    level = Column(Integer, nullable=True)
    power = Column(Float, nullable=True)
    uses = Column(Integer, nullable=True)
    duration_minutes = Column(Integer, nullable=True)
    active = Column(Boolean, default=True)
    trust_initial = Column(Float, default=0)
    trust_min = Column(Float, default=0)
    trust_max = Column(Float, default=100)
    trust_gain_per_payment = Column(Float, default=0)
    payment_amount_for_gain = Column(Float, nullable=True)
    trust_gain_per_use = Column(Float, default=0)
    inactivity_days_for_decay = Column(Float, nullable=True)
    trust_decay_amount = Column(Float, default=0)
    effect_combination_mode = Column(String, default="sum")  # sum / strongest / capped_sum
    effect_cap_pct = Column(Float, nullable=True)
    created_at = Column(DateTime, default=now)


class SmugglingUserHelper(Base):
    """مالکیتِ نیروی کمکی توسطِ کاربر (خریدشده از پنلِ قاچاق) + استفاده/انقضایِ
    باقی‌مونده."""
    __tablename__ = "smuggling_user_helpers"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    helper_id = Column(Integer, nullable=False, index=True)
    uses_remaining = Column(Integer, nullable=True)
    expires_at = Column(DateTime, nullable=True)
    acquired_at = Column(DateTime, default=now)


class SmugglingHelperTrust(Base):
    """Trustِ مستقلِ هر کاربر برایِ هر نیرویِ کمکی."""
    __tablename__ = "smuggling_helper_trust"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    helper_id = Column(Integer, nullable=False, index=True)
    trust = Column(Float, default=0)
    last_used_at = Column(DateTime, nullable=True)
    updated_at = Column(DateTime, default=now)


class SmugglingHelperRule(Base):
    """محدوده‌ی اثرِ یه نیرو رو به یه (کالا/مرحله/گزینه)ی خاص محدود می‌کنه.
    good_id/stage_id/option_id = None یعنی «همه‌ی...» همون سطح - اما یه نیرو
    فقط جایی مجازه که حداقل یه Ruleِ فعال براش تعریف شده باشه (پیش‌فرض ممنوعه)."""
    __tablename__ = "smuggling_helper_rules"
    id = Column(Integer, primary_key=True, autoincrement=True)
    helper_id = Column(Integer, nullable=False, index=True)
    good_id = Column(Integer, nullable=True)
    stage_id = Column(Integer, nullable=True)
    option_id = Column(Integer, nullable=True)
    min_trust = Column(Float, default=0)
    effect_success_pct = Column(Float, default=0)
    effect_risk_pct = Column(Float, default=0)
    effect_reward_pct = Column(Float, default=0)
    effect_penalty_pct = Column(Float, default=0)
    active = Column(Boolean, default=True)


class SmugglingTrustThreshold(Base):
    """آستانه‌های Trust - وقتی Trustِ کاربر برایِ اون نیرو به min_trust رسید،
    این اثرهایِ اضافه (سوایِ خودِ Rule) اعمال می‌شه. می‌تونه به‌ازای هر
    کالا/مرحله/گزینه فرق کنه."""
    __tablename__ = "smuggling_trust_thresholds"
    id = Column(Integer, primary_key=True, autoincrement=True)
    helper_id = Column(Integer, nullable=False, index=True)
    good_id = Column(Integer, nullable=True)
    stage_id = Column(Integer, nullable=True)
    option_id = Column(Integer, nullable=True)
    min_trust = Column(Float, nullable=False)
    effect_success_pct = Column(Float, default=0)
    effect_reward_pct = Column(Float, default=0)
    effect_risk_pct = Column(Float, default=0)
    effect_penalty_pct = Column(Float, default=0)
    active = Column(Boolean, default=True)


class SmugglingGunRule(Base):
    """تنها موردِ مجاز از سیستم‌های قبلی که اجازه داره رو قاچاق اثر بذاره - اونم
    فقط اگه ادمین صریحاً برایِ همون کالا/مرحله/گزینه فعالش کرده باشه. تبدیلِ
    قدرتِ اسلحه به Trustِ معادل کاملاً قابلِ‌تنظیمه (نه هاردکد)."""
    __tablename__ = "smuggling_gun_rules"
    id = Column(Integer, primary_key=True, autoincrement=True)
    good_id = Column(Integer, nullable=True)
    stage_id = Column(Integer, nullable=True)
    option_id = Column(Integer, nullable=True)
    power_per_trust = Column(Float, nullable=True)
    effect_success_pct_per_trust = Column(Float, default=0)
    effect_risk_pct_per_trust = Column(Float, default=0)
    consumes_use = Column(Boolean, default=False)
    active = Column(Boolean, default=True)


class SmugglingDailyUsage(Base):
    """محدودیتِ روزانه‌ی مستقل به‌ازایِ هر (کاربر + کالا + روز). UniqueConstraint
    تضمین می‌کنه حتی تو شرایطِ Race Condition هم دو تلاشِ هم‌زمان نتونن هر دو
    برایِ همون کالا/همون روز ثبت بشن (یکی با IntegrityError رد می‌شه)."""
    __tablename__ = "smuggling_daily_usage"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    good_id = Column(Integer, nullable=False)
    usage_date = Column(String, nullable=False)  # 'YYYY-MM-DD' (UTC - نگاه کن به توضیحِ smuggling.py)
    operation_id = Column(Integer, nullable=True)
    status = Column(String, default="used")
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("user_id", "good_id", "usage_date", name="uq_smuggling_daily_usage"),)


# ---------------------------------------------------------------------------
# سیستمِ «لول» (lvl) و حداقلِ سطحِ لازم برای هر بخشِ ربات
# ---------------------------------------------------------------------------
HOPS_PER_LVL = 13   # هر چند بار «هاپ هاپ» یک لول بالا می‌ره
MAX_LVL = 5000      # سقفِ لول

# کلید داخلی <- برچسبِ فارسیِ نمایشی. کلیدِ کانفیگِ مربوط به هرکدوم می‌شه
# f"minlvl_{کلید}" و از پنلِ ادمین (بخشِ «حداقل سطحِ بخش‌ها») قابلِ تنظیمه.
# ۰ یعنی بدونِ محدودیت. تنها استثنا خودِ نوشتنِ «هاپ» (هاپ‌هاپ) هست که اصلاً
# اینجا نیست و همیشه برای همه آزاده.
MODULE_LEVEL_GATES = {
    "hop_manage": "🐕 هاپ منیج",
    "bank": "🏦 بانک هاپویی (واریز/برداشتِ متنی)",
    "lottery": "🎉 قرعه‌کشی هاپ",
    "crypto": "💱 ارز دیجیتال",
    "casino": "🎰 کازینو هاپویی",
    "league": "🏆 لیگ برتر",
    "my_stats": "📋 هاپ هام",
    "other_stats": "📋 هاپ هاش",
    "myawy": "📱 گوشی هاپویی",
    "chef_election": "🗳 رای‌گیری هاپویی",
    "chef_market": "🛒 مارکت هاپویی",
    "taxi": "🚕 تاکسی هاپویی",
    "cards": "🎴 کارت هاپویی",
    "redeem": "🎁 کد جایزه هاپویی",
    "attack_panel": "🗡 پنل حمله",
    "hostage": "🔫 گروگان‌گیری",
    "smuggling_panel": "📦 قاچاق هاپویی",
    "main_menu": "🏠 منوی اصلی هاپویی",
    "help_guide": "📖 راهنمایی هاپویی",
    "war": "⚔️ جنگ هاپویی (کل بخش‌ها)",
    "heist": "🥷 سرقت تیمی هاپویی (کل بخش‌ها)",
    "mission": "🎯 مأموریت‌های هاپویی",
}


class ActivityCounter(Base):
    """خلاصه‌ی فعالیتِ بازیکن‌ها (برایِ ماموریت‌ها/آمار) بعد از پاک‌شدنِ ردیف‌های ریزِ بازی‌ها.

    db_purge وقتی یه عملیاتِ تمام‌شده (کازینو/جنگ/سرقت/...) رو از دیتابیس پاک می‌کنه،
    قبلش «چند بار شرکت کرده» رو اینجا جمع می‌کنه تا ماموریت‌ها (mission_metrics) خراب نشن.
    هر ردیف = یه بازیکن + یه معیار + یه بازه‌ی ۱۵دقیقه‌ای؛ یعنی حجمش با تعدادِ بازی‌ها
    رشد نمی‌کنه، فقط با تعدادِ (بازیکن×معیار×بازه)."""
    __tablename__ = "activity_counters"

    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    metric = Column(String, nullable=False)
    bucket = Column(DateTime, nullable=False)
    n = Column(Integer, default=0, nullable=False)

    __table_args__ = (UniqueConstraint("user_id", "metric", "bucket", name="uq_activity_counter"),)


DEFAULT_CONFIG = {
    "total_levels": "100",
    "level_base_xp": "400",
    "level_growth": "140",
    "level_quad": "0.6",

    "production_base": "1200",
    "production_increment": "350",
    "production_upgrade_base_cost": "300000",
    "production_upgrade_growth": "1.15",  # ضریب رشد هزینه‌ی ارتقا در هر بار
    "factory_capacity_base": "500000",       # ظرفیت کارخونه در سطح ۱ (هاپ پوینت)
    "factory_capacity_increment": "300000",  # افزایش ظرفیت به‌ازای هر سطح

    "supermarket_open_cost": "1500000",
    "supermarket_upgrade_base_cost": "500000",
    "supermarket_upgrade_growth": "1.2",
    "supermarket_prod_increment": "40",  # افزایش تولید کل در ساعت به ازای هر ارتقا

    "bank_open_cost": "1200000",
    "bank_daily_interest_pct": "40",   # درصدِ سودی که هر روز ساعت ۹ صبح (به وقتِ ایران) به بانک تعلق می‌گیره
    "bank_interest_cap": "10000000000",  # فقط تا این‌قدر از بالانس سود می‌گیره؛ مازادش بدونِ سوده (۰ یا خالی = بدونِ سقف)
    "bank_transfer_min_amount": "5000",  # حداقلِ مبلغی که با «انتقال هاپ» می‌شه فرستاد

    "price_cat_meat": "50",
    "price_cinnamon_cucumber": "35",
    "price_banana": "20",
    "price_dog_egg": "80",

    # سطح‌بندیِ محصولات سوپرمارکت
    "market_produce_per_level": "30",  # هر چند واحد محصول تولیدشده، یک سطح بالا میره

    # کازینو هاپویی
    "casino_join_timeout_seconds": "60",
    "casino_preset_amounts": "100,500,1000,5000,10000",
    "premium_emoji_enabled": "1",  # ایموجیِ پریمیومِ تلگرام (۱=روشن، ۰=خاموش)؛ فرمان‌هایِ مالک: /emoji
    "purge_enabled": "1",         # پاک‌سازیِ خودکارِ دیتای عملیات‌های تمام‌شده (۱=روشن، ۰=خاموش)
    "purge_grace_minutes": "30",  # بعد از پایانِ هر بازی/عملیات چند دقیقه دیتاش بمونه (برایِ دکمه‌های دیرکلیک‌شده)
    "purge_log_days": "14",       # لاگ‌هایِ ریز (audit جنگ و ...) چند روز نگه داشته بشن
    "casino_cooldown_minutes": "0",  # فاصله‌ی اجباری بینِ پایانِ یه کازینو (برای هر بازیکن) و شروع/پیوستنِ کازینوی بعدی (۰ یعنی خاموش)

    # اونو هاپویی
    "uno_turn_seconds": "80",          # مهلتِ هر نوبت؛ بعدش نوبت رد می‌شه
    "uno_max_missed_turns": "2",       # چند بار ردشدنِ نوبت => حذف از بازی
    "uno_lobby_timeout_seconds": "200",  # اگه لابی تو این مدت پر نشد، کازینو لغو و پول‌ها برگشت
    "uno_start_hand_size": "7",        # تعدادِ کارتِ اولیه‌ی هر بازیکن
    "uno_special_cards_total": "4",    # تعدادِ کلِ کارتِ «ویژه» تو بازی (۱ دستِ یه پلیر + بقیه تو دسته)
    "uno_max_turns": "20",             # سقفِ کلِ نوبت‌های بازی؛ رسیدن بهش یعنی مقایسه‌ی تعدادِ کارت و پایانِ بازی

    # زندانِ هاپویی - وثیقه
    "jail_spam_bail": "4500000",     # وثیقه‌ی پیش‌فرضِ کسی که به‌خاطرِ اسپم زندانی شده
    "jail_default_bail": "4500000",  # وثیقه‌ی پیش‌فرض وقتی ادمین موقعِ زندانی‌کردن عددی نداده
    "bship_ships_per_player": "4",  # تعدادِ کشتی/نقطه‌ی هر بازیکن تو «نبردِ دریایی»
    "bship_max_turns": "12",  # حداکثر نوبتِ حدس‌زدن برای هر بازیکن تو «نبردِ دریایی»
    "gtn_max_number": "1000",  # سقفِ بازه‌ی عددِ مخفی تو بازیِ «حدسِ عدد» (از ۱ تا این عدد)
    "gtn_max_guesses": "5",  # حداکثر تعدادِ حدسِ مجاز تو بازیِ «حدسِ عدد»
    "mm_code_length": "4",  # طولِ کدِ مخفی تو «رمزیاب»
    "mm_palette_size": "6",  # تعدادِ رنگ‌های قابل‌استفاده تو «رمزیاب» (حداکثر 8)
    "mm_max_turns": "10",  # حداکثر نوبتِ حدس‌زدنِ هر بازیکن تو «رمزیاب»
    # مافیا/گرگینه (تنظیم از پنلِ ادمین ← تنظیماتِ کازینو هاپویی)
    "casino_mafia_night_seconds": "60",   # مهلتِ فازِ شب (اقدامِ نقش‌ها)
    "casino_mafia_day_seconds": "90",     # مهلتِ فازِ روز (رای‌گیری)
    "casino_mafia_day_speak_seconds": "180",  # مهلتِ هر نوبتِ صحبتِ روز (هر دو حالتِ گروهی/جهانی)

    # رولت روسی (تنظیم از پنلِ ادمین ← تنظیماتِ کازینو هاپویی)
    "casino_rr_blank_bullets": "5",       # تعدادِ تیرِ مشقی تو خشاب
    "casino_rr_live_bullets": "1",        # تعدادِ تیرِ جنگی تو خشاب
    "casino_rr_spin_wait_seconds": "40",  # «انتظار برای چرخاندنِ خشاب» اولِ هر نوبت (ثانیه)؛ تو این مدت شلیک ممکن نیست
    "casino_rr_turn_seconds": "120",      # مهلتِ شلیک: از بعدِ تمومِ انتظارِ چرخاندن حساب می‌شه؛ ردشد = حذف
    "casino_max_bet": "0",  # حداکثر مبلغِ مجاز برای مبلغِ ورودیِ هر بازیِ کازینویی (هر نوعی) - ۰ یعنی بدونِ محدودیت
    "lottery_channel_id": "-1004348785748",  # آیدیِ چنلی که قرعه‌کشیِ سراسری فقط توش اعلام می‌شه (نه تو همه‌ی گروه‌ها - وگرنه فشارِ زیادی رو بات میاره). خالی/۰ یعنی اصلاً اعلام نشه.

    # بروزرسانی خودکار قیمت ارزهای دیجیتال
    "crypto_auto_enabled": "0",             # 0 = خاموش، 1 = روشن
    "crypto_auto_interval_hours": "6",       # هر چند ساعت یک‌بار قیمت‌ها عوض شن
    "crypto_auto_last_update_at": "",        # آخرین باری که خودکار عوض شده (ISO datetime) - قدیمی، دیگه استفاده نمی‌شه
    "crypto_auto_last_tick_at": "",          # آخرین قدمِ کوچیکِ موتورِ نوسانِ جدید (ISO datetime)
    "crypto_auto_max_change_pct": "8",       # حداکثر درصد تغییر قیمت در هر بار (بالا یا پایین)

    # گوشی هاپویی (شبکه‌های اجتماعی)
    "myawy_gb_per_post_cost": "0.5",           # هر پست گذاشتن چقدر گیگ مصرف می‌کنه (۲ پست در هر گیگ)
    "myawy_gb_per_view_cost": "0.05",          # هر پست دیدن چقدر گیگ مصرف می‌کنه (۲۰ پست در هر گیگ)
    "myawy_default_upload_seconds": "600",     # زمانِ آپلودِ پست با سرعتِ پیش‌فرض (۱۰ دقیقه)
    "myawy_upload_seconds_reduction_per_10mbps": "3",  # به‌ازای هر ۱۰ مگابیت بیشتر از پیش‌فرض، این‌قدر ثانیه از زمانِ آپلود کم می‌شه
    "myawy_operator_default_speed_mbps": "100",        # سرعتِ پیش‌فرضِ هر اپراتورِ تازه‌ساخته‌شده
    "myawy_speed_boost_cost": "1000000",       # هزینه‌ی هر بار افزایشِ ۱۰ مگابیتیِ سرعتِ یه اپراتور
    "myawy_speed_boost_mbps": "10",            # هر بار افزایش، چند مگابیت اضافه می‌کنه
    "myawy_max_requests_per_day": "25",        # حداکثر تعداد درخواستِ پلتفرمِ جدید در روز برای هر پلیر (نه کلِ بازیکن‌ها)
    "myawy_platform_fee_days": "3",            # چند روز فرصت برای پرداختِ فیِ پلتفرمِ تاییدشده
    "myawy_fee_jail_days": "1",                # اگه فیِ پلتفرم سرِ وقت پرداخت نشه، چند روز بره زندانِ هاپویی
    "myawy_creator_commission_pct": "28",      # سازنده‌ی پلتفرمِ پلیرساخته، به‌ازای هر پرداختِ لایک، این‌قدر درصدِ اضافه هم به‌عنوانِ کمیسیون خودکار می‌گیره
    "myawy_total_internet_revenue": "0",       # مجموعِ کل هاپ پوینتی که تا حالا بابتِ فروشِ اینترنت جمع شده (نمایشی، هیچ‌وقت صفر نمی‌شه)
    "myawy_pending_internet_revenue": "0",     # موجودیِ در صفِ برداشت - با هر خرید بالا می‌ره، با «برداشت درآمد اپراتور» صفر می‌شه

    # سرآشپز و غذای سگ
    "chef_dog_food_capacity_per_rank": "2",    # هر مقامِ کارخونه چقدر به ظرفیتِ غذای سگ اضافه می‌کنه (مقامِ اول = همین عدد، مقامِ دوم = ۲برابرش و...)
    "chef_dog_food_minutes_per_unit": "30",    # هر ۱ واحد ظرفیتِ غذا چند دقیقه طول می‌کشه تموم بشه (غذا زمانی کم می‌شه، نه با کلیک)
    "chef_term_days": "7",                     # سرآشپزِ برنده چند روز سرِ کاره
    "chef_max_tax_pct": "20",                  # حداکثر درصدِ مالیاتی که سرآشپز می‌تونه رو غذا بذاره
    "chef_max_candidates": "15",               # حداکثر تعداد کاندیدِ هر انتخابات
    "chef_election_hours": "24",               # هر انتخابات چند ساعت بازه (بعدش برنده بر اساسِ رای مشخص می‌شه)
    "chef_recall_votes_needed": "20",          # چند رایِ برکناری لازمه تا سرآشپز فوراً برکنار بشه

    # ولتِ ارز دیجیتال
    "wallet_cost": "600000",                   # هزینه‌ی ساختِ ولت

    # روشن/خاموش‌کردنِ پیوی برای عمومِ کاربرها (مالک همیشه دسترسی داره)
    "private_chat_enabled": "1",               # 1 = روشن (پیش‌فرض)، 0 = خاموش

    # گوشی‌های هاپویی: خط تولید/نسل/کشو/تعمیرات/بازارِ سیاه
    "myawy_phone_ban_window": "3",              # بعدِ ساختِ چندمین نسلِ جدیدتر تو یه خط، نسلِ قدیمی از پلتفرم‌ها ممنوع می‌شه

    # تاکسیِ هاپویی
    "taxi_drive_hours_per_day": "10",           # سقفِ زمانیِ هر شیفتِ تاکسی‌رانی (ساعت)
    "taxi_rest_hours_after": "12",              # بعدِ اتمام/برداشتِ هر شیفت، تا این‌قدر باید استراحت کنه
    "taxi_station_return_minutes": "5",         # زمانِ برگشت به ایستگاه بعدِ هر مسافرکشی
    "taxi_min_passengers_per_trip": "1",
    "taxi_max_passengers_per_trip": "4",
    "taxi_gas_price_min_per_liter": "194",      # قیمتِ هر لیتر بنزین نوسان داره - هر بار تو همین بازه رندوم می‌شه
    "taxi_gas_price_max_per_liter": "1070",
    "taxi_dirty_after_hours": "48",             # بعدِ این‌قدر ساعت از آخرین کارواش، ماشین کثیف می‌شه
    "taxi_carwash_cost": "13000",
    "taxi_dirty_fare_multiplier": "0.3",        # ماشینِ کثیف کرایه‌ش ضربِ این عدد می‌شه (یعنی ۷۰٪ کرایه رو از دست می‌ده)
    "taxi_dirty_extra_wait_minutes": "3",       # ماشینِ کثیف این‌قدر دقیقه هم به مدتِ پرشدنش اضافه می‌شه
    # موتور (کاهشِ مدتِ مسیر) - سطح ۱ تا engine_max_level هرمدل، فرمول مشترک
    "taxi_engine_base_trip_min": "5",           # سطح ۱: مسیر ۵ تا ۷ دقیقه
    "taxi_engine_base_trip_max": "7",
    "taxi_engine_floor_trip_min": "2",          # سطحِ آخرِ همون مدل: مسیر ۲ تا ۴ دقیقه
    "taxi_engine_floor_trip_max": "4",
    "taxi_engine_upgrade_base_cost": "100000",  # هزینه‌ی سطح۱->۲
    "taxi_engine_upgrade_growth": "1.7",        # نسبتِ رشدِ هزینه به‌ازای هر سطح
    # محبوبیت/جذابیت (نرخِ کرایه + کاهشِ مدتِ انتظار تو ایستگاه) - سیستمِ مقام/سطحِ
    # مشترک مثلِ هاپ‌منیج (نگاه کن به TaxiRank/TaxiLevelDef)
    "taxi_appeal_base_fare_per_min": "40",      # سطح ۱: هر دقیقه هر مسافر ۴۰ هاپ پوینت
    "taxi_appeal_fare_increment": "37",         # هر سطحِ محبوبیت که بالاتر بره، ۳۷ تا به نرخِ هر دقیقه اضافه می‌شه
    "taxi_appeal_base_wait_min": "5",           # سطح ۱: پرشدنِ ماشین ۵ تا ۱۵ دقیقه
    "taxi_appeal_base_wait_max": "15",
    "taxi_appeal_floor_wait_min": "1",          # سطحِ مرجع (پایین) به بعد: ۱ تا ۳ دقیقه
    "taxi_appeal_floor_wait_max": "3",
    "taxi_appeal_reference_max_level": "20",    # تو کدوم سطح، زمانِ انتظار به کفش می‌رسه
    "taxi_appeal_upgrade_base_cost": "100000",
    "taxi_appeal_upgrade_growth": "1.7",

    # کارتِ هاپویی (ایونتِ موقت)
    "card_default_event_days": "30",             # مهلتِ پیش‌فرضِ ایونت وقتی از پنل شروعش می‌کنی
    "card_daily_free_rare": "3",                 # تعدادِ توکنِ رایگانِ روزانه‌ی لیستِ کمیاب
    "card_daily_free_wild": "1",                 # تعدادِ توکنِ رایگانِ روزانه‌ی لیستِ جنگلی
    "card_daily_free_legend": "2",                # تعدادِ توکنِ رایگانِ روزانه‌ی لیستِ لجند
    "card_daily_paid_max": "4",                   # سقفِ توکنِ خریدنیِ روزانه (جمعِ هر سه لیست)
    "card_paid_price_rare": "500000",             # قیمتِ هر توکنِ خریدنیِ لیستِ کمیاب
    "card_paid_price_wild": "2000000",            # قیمتِ هر توکنِ خریدنیِ لیستِ جنگلی
    "card_paid_price_legend": "8000000",          # قیمتِ هر توکنِ خریدنیِ لیستِ لجند
    "card_duplicate_cap_pct": "70",               # سقفِ احتمالِ گرفتنِ کارتِ تکراری (بعدِ اون، بقیه‌ش برمی‌گرده به کارتِ جدید)
    "card_duplicate_max_extra_copies": "1",        # سقفِ تعدادِ کارتِ تکراری که با توکنِ رایگان می‌شه از یه کارت گرفت (پیش‌فرض ۱ یعنی حداکثر ۲ نسخه: اصلی+۱تکراری)
    "card_list1_reward_crypto_units": "35",       # پاداشِ کاملِ لیستِ کمیاب: این‌قدر واحد از یه ارزِ دیجیتالِ شانسی
    "card_list2_reward_food_units": "50",         # پاداشِ کاملِ لیستِ جنگلی: این‌قدر واحد به ظرفیتِ غذای سگ اضافه می‌شه
    "card_list3_reward_bank_points": "300000000000",  # پاداشِ کاملِ لیستِ لجند: این‌قدر هاپ پوینت به بانکِ کاربر
    "card_duplicate_sell_price": "50000",         # بعدِ اتمامِ ایونت، هر کارتِ تکراری این‌قدر هاپ پوینت می‌ارزه

    # فروشگاه هاپویی + سیستمِ حمله/گروگان
    "attack_backpack_max_slots": "20",              # سقفِ ردیف‌های کوله‌پشتی
    "attack_hostage_duration_minutes": "60",        # مدتِ گروگان‌گیری
    "attack_hostage_check_interval_minutes": "10",  # هر چند دقیقه یه بررسیِ شانسِ فرار
    "attack_hostage_base_escape_pct": "70",         # شانسِ پایه‌ی فرار در هر بررسی
    "attack_hostage_ransom_amount": "500000000",    # مبلغِ «پرداختِ کمیسیون» برای آزادیِ گروگان
    "attack_hostage_victim_production_mult": "25",  # تولیدِ Hop Manager قربانی به این درصد کاهش پیدا می‌کنه (۲۵٪ = ۱/۴)
    "attack_hostage_attacker_production_mult": "400",  # تولیدِ Hop Manager مهاجم به این درصد افزایش پیدا می‌کنه (۴۰۰٪ = ۴ برابر)
    "attack_fail_defender_penalty_minutes": "40",   # جریمه‌ی شکستِ تلاشِ گروگان‌گیری: مدت
    "attack_fail_defender_penalty_pct": "70",       # جریمه‌ی شکستِ تلاش: تولیدِ مدافع به این درصد
    "attack_fail_transfer_amount": "1000000000",    # مبلغِ انتقالِ مدافع←مهاجم بعدِ شکستِ تلاش
    "attack_killed_penalty_minutes": "15",          # جریمه‌ی کشته‌شدنِ مهاجم: مدت
    "attack_killed_penalty_pct": "25",              # جریمه‌ی کشته‌شدنِ مهاجم: تولیدِ مهاجم به این درصد
    "attack_guard_hostage_divisor": "7",            # ضریبِ استفاده از قدرتِ محافظ در دفاعِ گروگان‌گیری (۱/۷)
    "attack_max_hostage_per_day": "2",              # مکس تعدادِ گروگان‌گیریِ موفقِ هر مهاجم در روز
    "attack_max_victim_hostage_per_day": "3",       # مکس تعدادی که یه نفر تو یه روز می‌تونه گروگان گرفته بشه
    "attack_inactivity_timeout_seconds": "60",      # بعدِ این‌همه ثانیه بی‌حرکتی، تأیید/نبردِ ناتموم خودکار لغو می‌شه
    "attack_wrong_guess_divisor": "6",              # آسیبِ هر انتخابِ غلط = قدرتِ گانِ مدافع ÷ این عدد
    "attack_min_target_wealth": "2000000000",       # حداقلِ مجموعِ (بانک+نقدیِ) هدف برای اینکه اصلاً بشه بهش حمله کرد
    "attack_max_wrong_guesses": "23",                # حداکثر تعدادِ خطای مجازِ مهاجم تو مینی‌گیم
    "attack_battle_hp": "1500",                     # HP اولیه‌ی هر دو طرف تو مینی‌گیمِ گروگان‌گیری و نبردِ تن‌به‌تن
    "duel_battle_hp": "1500",                       # HP اولیه‌ی هر بازیکن تو «نبردِ تن‌به‌تن»
    "duel_counter_attack_bonus_pct": "125",         # ضدحمله در برابرِ حمله: این‌درصدِ دمیجِ عادی
    "duel_defend_reduction_pct": "50",              # حمله در برابرِ دفاع: مدافع این‌درصدِ دمیجِ عادی رو می‌گیره
    "duel_counter_vs_counter_pct": "75",            # ضدحمله در برابرِ ضدحمله: هر دو این‌درصدِ دمیجِ عادی رو می‌گیرن

    # قاچاق هاپویی
    "smuggling_allow_concurrent_operations": "0",   # 0 = فقط یه عملیاتِ فعال هم‌زمان مجازه، 1 = چندتا مجازه
    "smuggling_inactivity_timeout_seconds": "120",  # بعدِ این‌همه ثانیه بی‌حرکتی تو هر مرحله/صفحه، عملیات خودکار لغو می‌شه
    # شکستِ عملیاتِ قاچاق -> زندانِ هاپویی (هردو از پنل قابلِ تغییرن؛ دقیقه‌ی ۰ یعنی اصلاً زندان نره)
    "smuggling_fail_jail_minutes": "30",
    "smuggling_fail_jail_bail": "14500000",
}

# حداقلِ سطحِ (lvl) پیش‌فرضِ هر بخش - همه صفر (بدونِ محدودیت) تا وقتی خودِ
# مالک از پنل چیزی روش تنظیم کنه.
DEFAULT_CONFIG.update({f"minlvl_{key}": "0" for key in MODULE_LEVEL_GATES})


def _pg_add_missing_columns():
    """PostgreSQL: هر ستونی که تو مدل‌ها هست ولی تو جدولِ واقعی نیست رو با
    ALTER TABLE ... ADD COLUMN اضافه می‌کنه (جایگزینِ لیستِ دستیِ SQLite).
    یعنی از این به بعد هر وقت تو کد ستونِ جدید به یه مدل اضافه کنی، با اولین
    استارتِ ربات خودکار تو دیتابیس ساخته می‌شه. ستون حذف/تغییرنوع نمی‌شه (عمداً)."""
    from sqlalchemy import inspect as _inspect
    from sqlalchemy.schema import CreateColumn
    insp = _inspect(engine)
    existing_tables = set(insp.get_table_names())
    with engine.begin() as conn:
        for table in Base.metadata.sorted_tables:
            if table.name not in existing_tables:
                continue
            have = {c["name"] for c in insp.get_columns(table.name)}
            for col in table.columns:
                if col.name in have:
                    continue
                ddl = str(CreateColumn(col).compile(dialect=engine.dialect))
                # ستونِ جدیدِ NOT NULL بدونِ default رو روی جدولِ پر نمی‌شه اضافه کرد؛ nullable می‌سازیمش
                if "NOT NULL" in ddl and col.server_default is None and col.default is None:
                    ddl = ddl.replace(" NOT NULL", "")
                conn.exec_driver_sql(f'ALTER TABLE "{table.name}" ADD COLUMN {ddl}')


def _pg_fix_datetime_column_types():
    """PostgreSQL: ستون‌هایی که تو مدل DateTime ان ولی تو دیتابیسِ واقعی TEXT/VARCHAR ساخته شدن
    (مثلاً از مایگریشنِ قدیمیِ SQLite که ستون‌ها رو «TEXT» اضافه می‌کرد) رو به TIMESTAMP تبدیل می‌کنه.
    علامتِ مشکل: «TypeError: unsupported operand type(s) for -: 'datetime.datetime' and 'str'».
    دیتا حفظ می‌شه (CAST)؛ هر ستون جدا و در تراکنشِ خودش انجام می‌شه تا خطای یکی جلوی بقیه رو نگیره."""
    with engine.connect() as conn:
        rows = conn.exec_driver_sql(
            "SELECT table_name, column_name, data_type FROM information_schema.columns "
            "WHERE table_schema = current_schema()").fetchall()
        conn.rollback()
    actual = {(t, c): d for t, c, d in rows}
    for table in Base.metadata.sorted_tables:
        for col in table.columns:
            if isinstance(col.type, DateTime) and actual.get((table.name, col.name)) in ("text", "character varying"):
                try:
                    with engine.begin() as conn:
                        conn.exec_driver_sql(
                            f'ALTER TABLE "{table.name}" ALTER COLUMN "{col.name}" TYPE TIMESTAMP '
                            f'USING NULLIF(BTRIM("{col.name}"), \'\')::timestamp')
                    print(f"[db] ستونِ {table.name}.{col.name} از TEXT به TIMESTAMP تبدیل شد")
                except Exception as e:
                    print(f"[db] تبدیلِ {table.name}.{col.name} به TIMESTAMP ناموفق بود: {e}")


def _migrate_new_columns():
    """اگر دیتابیس از قبل وجود داشته باشه (نسخه‌ی قدیمی‌تر ربات)، ستون‌های جدید رو
    با ALTER TABLE اضافه می‌کنه تا دیتای قبلی از بین نره یا کرش نکنه."""
    if not IS_SQLITE:
        _pg_add_missing_columns()
        _pg_fix_datetime_column_types()
        return
    needed = {
        "users": [
            ("market_product_level", "INTEGER DEFAULT 1"),
            ("market_produce_progress", "REAL DEFAULT 0"),
            ("hop_count", "INTEGER DEFAULT 0"),
            ("lvl", "INTEGER DEFAULT 1"),
            ("jail_bail_amount", "REAL"),
            ("jail_reason", "TEXT"),
            ("cat_name", "TEXT"),
            ("factory_pending", "REAL DEFAULT 0"),
            ("factory_rank_order", "INTEGER DEFAULT 1"),
            ("factory_level", "INTEGER DEFAULT 1"),
            ("internet_gb", "REAL DEFAULT 0"),
            ("operator_id", "INTEGER"),
            ("myawy_requests_today", "INTEGER DEFAULT 0"),
            ("myawy_requests_reset_at", "TEXT"),
            ("jailed_until", "TEXT"),
            ("dog_food", "REAL DEFAULT 0"),
            ("dog_food_last_check_at", "TEXT"),
            ("wallet_address", "TEXT"),
            ("taxi_car_model_id", "INTEGER"),
            ("taxi_engine_level", "INTEGER DEFAULT 1"),
            ("taxi_rank_order", "INTEGER DEFAULT 1"),
            ("taxi_level", "INTEGER DEFAULT 1"),
            ("taxi_gas_liters", "REAL DEFAULT 0"),
            ("taxi_last_wash_at", "TEXT"),
            ("taxi_state", "TEXT DEFAULT 'idle'"),
            ("taxi_state_until", "TEXT"),
            ("taxi_shift_until", "TEXT"),
            ("taxi_resting_until", "TEXT"),
            ("taxi_current_passengers", "INTEGER DEFAULT 0"),
            ("taxi_shift_earnings", "REAL DEFAULT 0"),
            ("bank_last_interest_amount", "REAL"),
        ],
        "lottery_events": [
            ("prize_amount", "REAL DEFAULT 0"),
            ("winner_id", "INTEGER"),
            ("finished_at", "TEXT"),
            ("winner_count", "INTEGER DEFAULT 1"),
            ("winners_json", "TEXT DEFAULT '[]'"),
        ],
        "factory_ranks": [
            ("num_levels", "INTEGER DEFAULT 5"),
        ],
        "platforms": [
            ("reward_amount", "REAL DEFAULT 0"),
            ("likes_threshold", "INTEGER DEFAULT 10"),
            ("works_on_all_phones", "INTEGER DEFAULT 0"),
        ],
        "phone_generations": [
            ("manual_ban", "INTEGER DEFAULT 0"),
        ],
        "card_listings": [
            ("seller_id", "INTEGER"),
            ("price", "REAL DEFAULT 0"),
            ("is_sold", "INTEGER DEFAULT 0"),
            ("buyer_id", "INTEGER"),
            ("sold_at", "TEXT"),
        ],
        "platform_requests": [
            ("requested_reward_amount", "REAL DEFAULT 0"),
            ("requested_likes_threshold", "INTEGER DEFAULT 10"),
            ("warned_1h", "INTEGER DEFAULT 0"),
        ],
        "operators": [
            ("active_speed_mbps", "REAL DEFAULT 100"),
        ],
        "dog_foods": [
            ("feed_value", "INTEGER DEFAULT 1"),
        ],
        "casino_rounds": [
            ("ended_at", "TEXT"),
        ],
        "attack_sessions": [
            ("last_action_at", "TEXT"),
        ],
        "smuggling_operations": [
            ("last_action_at", "TEXT"),
            ("stage_ready_at", "TEXT"),
            ("pending_note", "TEXT"),
        ],
        "battleship_rounds": [
            ("ships_per_player", "INTEGER DEFAULT 4"),
            ("max_turns", "INTEGER DEFAULT 12"),
        ],
        "guessnum_rounds": [
            ("last_action_at", "TEXT"),
        ],
        "roulette_players": [
            ("out_reason", "TEXT"),
        ],
        "roulette_rounds": [
            ("chambers", "TEXT"),
            ("turn_ready_at", "DATETIME"),
        ],
        "mafia_players": [
            ("night_target_id", "BIGINT"),
            ("day_vote_id", "BIGINT"),
        ],
        "mafia_rounds": [
            ("mode", "TEXT"),
            ("day_speak_active", "BOOLEAN DEFAULT 0"),
            ("day_speak_order", "TEXT"),
            ("day_speak_index", "INTEGER DEFAULT 0"),
            ("day_speak_seq", "INTEGER DEFAULT 0"),
            ("day_speak_message_id", "BIGINT"),
            ("day_speak_deadline_at", "DATETIME"),
            ("day_speeches", "TEXT"),
        ],
        "currencies": [
            ("period_anchor_price", "REAL"),
            ("period_started_at", "TEXT"),
        ],
    }
    with engine.connect() as conn:
        for table, cols in needed.items():
            existing_cols = {row[1] for row in conn.exec_driver_sql(f"PRAGMA table_info({table})")}

            if table == "card_listings" and "requester_id" in existing_cols:
                # طراحیِ قدیمیِ این جدول «آگهیِ درخواست/اهدا» بود (requester_id،
                # is_fulfilled، fulfilled_by/at)؛ الان یه «خرید/فروشِ واقعی»
                # بینِ پلیرهاست با ساختارِ کاملاً متفاوت (seller_id/price/...).
                # چون قیمتی تو طراحیِ قدیمی ثبت نمی‌شد، دیتای قبلی تو ساختارِ
                # جدید معنایی نداره - کل جدول رو از نو می‌سازیم (دیتای این
                # جدول ذاتاً مالِ یه دورِ ایونتِ موقته، ماندگاریِ حیاتی نداره).
                conn.exec_driver_sql("DROP TABLE card_listings")
                conn.exec_driver_sql(
                    """
                    CREATE TABLE card_listings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        event_id INTEGER NOT NULL,
                        seller_id INTEGER NOT NULL,
                        slot_id INTEGER,
                        price FLOAT NOT NULL,
                        created_at DATETIME,
                        is_sold BOOLEAN,
                        buyer_id INTEGER,
                        sold_at DATETIME,
                        FOREIGN KEY(slot_id) REFERENCES card_slots (id)
                    )
                    """
                )
                continue

            newly_added = []
            for col_name, col_def in cols:
                if col_name not in existing_cols:
                    conn.exec_driver_sql(f"ALTER TABLE {table} ADD COLUMN {col_name} {col_def}")
                    newly_added.append(col_name)
            # طراحیِ قدیمی این ستون رو «level_count» صدا می‌زد و NOT NULL بود. اگه
            # هنوز وجود داشته باشه (چه همین الان num_levels اضافه شده باشه، چه از
            # قبل - مثلا یه بارِ قبلی این مهاجرت نصفه‌ونیمه اجرا شده بود)، بایدش
            # حذف کنیم - وگرنه چون NOT NULL بود و کدِ جدید دیگه مقداری براش
            # نمی‌فرسته، هر INSERT جدید (مثلا افزودنِ مقامِ جدید از پنل) با خطای
            # NOT NULL constraint شکست می‌خوره.
            if table == "factory_ranks" and "level_count" in existing_cols:
                if "num_levels" in newly_added:
                    conn.exec_driver_sql("UPDATE factory_ranks SET num_levels = level_count")
                try:
                    conn.exec_driver_sql("ALTER TABLE factory_ranks DROP COLUMN level_count")
                except Exception:
                    # نسخه‌ی قدیمیِ SQLite که DROP COLUMN رو پشتیبانی نمی‌کنه (قبل از
                    # 3.35) - با بازسازیِ کاملِ جدول همون نتیجه رو می‌گیریم
                    conn.exec_driver_sql("""
                        CREATE TABLE factory_ranks_new (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            "order" INTEGER NOT NULL UNIQUE,
                            name VARCHAR NOT NULL,
                            num_levels INTEGER NOT NULL DEFAULT 5
                        )
                    """)
                    conn.exec_driver_sql(
                        'INSERT INTO factory_ranks_new (id, "order", name, num_levels) '
                        'SELECT id, "order", name, num_levels FROM factory_ranks'
                    )
                    conn.exec_driver_sql("DROP TABLE factory_ranks")
                    conn.exec_driver_sql("ALTER TABLE factory_ranks_new RENAME TO factory_ranks")

            # همین باگِ «ستونِ قدیمیِ NOT NULL جا مونده» رو برای پلتفرم‌های گوشی
            # هاپویی هم رفع می‌کنیم (وقتی نرخِ پاداش از «هر ۱۰ لایکِ ثابت» به
            # «قابل‌تنظیم» تغییر کرد و ستون‌ها rename شدن)
            if table == "platforms" and "reward_per_10_likes" in existing_cols:
                if "reward_amount" in newly_added:
                    conn.exec_driver_sql("UPDATE platforms SET reward_amount = reward_per_10_likes")
                try:
                    conn.exec_driver_sql("ALTER TABLE platforms DROP COLUMN reward_per_10_likes")
                except Exception:
                    conn.exec_driver_sql("""
                        CREATE TABLE platforms_new (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            name VARCHAR NOT NULL,
                            reward_amount REAL NOT NULL DEFAULT 0,
                            likes_threshold INTEGER NOT NULL DEFAULT 10,
                            is_bot_funded BOOLEAN,
                            owner_user_id BIGINT,
                            is_active BOOLEAN,
                            created_at DATETIME
                        )
                    """)
                    conn.exec_driver_sql(
                        "INSERT INTO platforms_new (id, name, reward_amount, likes_threshold, is_bot_funded, "
                        "owner_user_id, is_active, created_at) "
                        "SELECT id, name, reward_amount, likes_threshold, is_bot_funded, owner_user_id, "
                        "is_active, created_at FROM platforms"
                    )
                    conn.exec_driver_sql("DROP TABLE platforms")
                    conn.exec_driver_sql("ALTER TABLE platforms_new RENAME TO platforms")

            if table == "platform_requests" and "requested_reward_per_10_likes" in existing_cols:
                if "requested_reward_amount" in newly_added:
                    conn.exec_driver_sql(
                        "UPDATE platform_requests SET requested_reward_amount = requested_reward_per_10_likes"
                    )
                try:
                    conn.exec_driver_sql("ALTER TABLE platform_requests DROP COLUMN requested_reward_per_10_likes")
                except Exception:
                    conn.exec_driver_sql("""
                        CREATE TABLE platform_requests_new (
                            id INTEGER PRIMARY KEY AUTOINCREMENT,
                            user_id BIGINT NOT NULL,
                            platform_name VARCHAR NOT NULL,
                            requested_reward_amount REAL NOT NULL DEFAULT 0,
                            requested_likes_threshold INTEGER NOT NULL DEFAULT 10,
                            status VARCHAR,
                            fee_amount REAL,
                            fee_paid_amount REAL,
                            fee_deadline DATETIME,
                            created_at DATETIME
                        )
                    """)
                    conn.exec_driver_sql(
                        "INSERT INTO platform_requests_new (id, user_id, platform_name, requested_reward_amount, "
                        "requested_likes_threshold, status, fee_amount, fee_paid_amount, fee_deadline, created_at) "
                        "SELECT id, user_id, platform_name, requested_reward_amount, requested_likes_threshold, "
                        "status, fee_amount, fee_paid_amount, fee_deadline, created_at FROM platform_requests"
                    )
                    conn.exec_driver_sql("DROP TABLE platform_requests")
                    conn.exec_driver_sql("ALTER TABLE platform_requests_new RENAME TO platform_requests")

            # اپراتورهایی که از قبل بودن و سرعتشون بیشتر از پیش‌فرض بود، باید
            # سرعتِ فعالشون هم همون مقدارِ ارتقاداده‌شده باشه، نه پیش‌فرضِ ۱۰۰
            if table == "operators" and "active_speed_mbps" in newly_added:
                conn.exec_driver_sql("UPDATE operators SET active_speed_mbps = speed_mbps")
        conn.commit()


def _migrate_factory_ranks_v2():
    """
    یه‌بار مصرف: تا قبل از این آپدیت، سطح‌بندیِ کارخونه پیوسته/سراسری بود
    (مقام‌ها بازه‌های غیرهم‌پوشانِ یک شماره‌گذاریِ سراسری رو اشغال می‌کردن، مثلا
    مقامِ اول سطح ۱ تا ۵، مقامِ دوم سطح ۶ تا ۱۵). حالا سطح‌ها بینِ مقام‌ها
    مشترکن (سطح ۵ مقامِ اول == سطح ۵ مقامِ دوم) و هر کاربر یک (مقام، سطحِ نسبی)
    جدا داره. این تابع با همون منطقِ قدیمی (والک‌کردنِ رو مقام‌ها به ترتیب و
    کم‌کردنِ num_levels) پیشرفتِ قبلیِ هر کاربر رو به مختصاتِ جدید تبدیل می‌کنه؛
    با یه فلگ تو game_config فقط یک‌بار اجرا می‌شه.
    """
    session = SessionLocal()
    try:
        if cfg_get(session, "_migrated_factory_ranks_v2") == "1":
            return
        ranks = session.query(FactoryRank).order_by(FactoryRank.order).all()
        if ranks:
            for user in session.query(User).all():
                absolute_level = (user.production_level or 0) + 1  # قبلا صفر-پایه بود
                remaining = absolute_level
                assigned_rank = ranks[-1]
                assigned_level = ranks[-1].num_levels
                for rank in ranks:
                    if remaining <= rank.num_levels:
                        assigned_rank, assigned_level = rank, remaining
                        break
                    remaining -= rank.num_levels
                user.factory_rank_order = assigned_rank.order
                user.factory_level = max(1, assigned_level)
        cfg_set(session, "_migrated_factory_ranks_v2", "1")
        session.commit()
    finally:
        session.close()


def _migrate_forced_config_overrides():
    """بعضی مقادیرِ پیش‌فرضِ کانفیگ، بعدِ یه آپدیتِ کد لازمه عوض شن، ولی چون
    init_db فقط کلیدهایی که اصلاً تو دیتابیس وجود ندارن رو از DEFAULT_CONFIG
    seed می‌کنه (نه کلیدهای از قبل موجود)، فقط عوض‌کردنِ مقدار تو DEFAULT_CONFIG
    رو نصب‌های قدیمی (که این کلید قبلاً توشون ست شده) اثر نمی‌کنه. این تابع یه
    لیست از این‌جور override های اجباری رو (هرکدوم فقط یک‌بار، با یه فلگ) اجرا
    می‌کنه تا آپدیتِ کد رو نصب‌های قدیمی هم واقعاً اثر بذاره."""
    forced_overrides = {
        # کلید -> (فلگِ یک‌باره، مقدارِ جدید)
        "attack_max_wrong_guesses": ("_forced_attack_max_wrong_guesses_v1", "23"),
        "casino_mafia_day_speak_seconds": ("_forced_mafia_day_speak_180_v1", "180"),
    }
    session = SessionLocal()
    try:
        for key, (flag, value) in forced_overrides.items():
            if cfg_get(session, flag) != "1":
                cfg_set(session, key, value)
                cfg_set(session, flag, "1")
    finally:
        session.close()


def _migrate_weekly_to_daily_bank_interest():
    """سودِ بانک از هفتگی به روزانه (ساعتِ ۹ صبح) عوض شد؛ اگه ادمین قبلاً درصدِ
    هفتگی رو از پنل عوض کرده بود، همون عدد رو عیناً به‌عنوانِ درصدِ روزانه‌ی
    جدید منتقل می‌کنیم (نه تبدیلِ ریاضی‌ای بینِ نرخ‌ها) - چون خودِ درخواست این
    بود که همون درصد از این به بعد هر روز اعمال شه، نه هفته‌ای."""
    session = SessionLocal()
    try:
        if cfg_get(session, "_migrated_bank_interest_daily_v1") == "1":
            return
        old_row = session.get(Config, "bank_weekly_interest_pct")
        if old_row is not None and session.get(Config, "bank_daily_interest_pct") is None:
            cfg_set(session, "bank_daily_interest_pct", old_row.value)
        cfg_set(session, "_migrated_bank_interest_daily_v1", "1")
    finally:
        session.close()


DEFAULT_FACTORY_RANKS = [
    (1, "🐶 سگ تازه‌کار", 5),
    (2, "🐕 سگ حرفه‌ای", 10),
    (3, "🐕‍🦺 سگ افسانه‌ای", 10),
]


def no_autoincrement_for_natural_keys():
    """کلیدهایِ اصلیِ «طبیعی» (telegram_id، chat_id، user_id، level_number ...) نباید شمارنده‌ی
    خودکار (SERIAL) بگیرن؛ فقط ستون‌هایِ id. روی SQLite اثری نداره، روی PostgreSQL از ساختِ
    sequenceِ بی‌معنی (و خطا با chat_idِ منفیِ گروه‌ها) جلوگیری می‌کنه. قبلِ create_all صدا زده می‌شه."""
    for t in Base.metadata.tables.values():
        pk = list(t.primary_key.columns)
        if len(pk) == 1 and pk[0].name != "id":
            pk[0].autoincrement = False


def init_db():
    no_autoincrement_for_natural_keys()
    Base.metadata.create_all(engine)
    _migrate_new_columns()
    _migrate_weekly_to_daily_bank_interest()  # قبلِ seedِ پیش‌فرض‌ها، وگرنه کلیدِ جدید همیشه با مقدارِ پیش‌فرض پر می‌شه و مهاجرت هیچ‌وقت چیزی برای انتقال پیدا نمی‌کنه
    session = SessionLocal()
    try:
        existing = {c.key for c in session.query(Config).all()}
        for k, v in DEFAULT_CONFIG.items():
            if k not in existing:
                session.add(Config(key=k, value=v))
        if session.query(FactoryRank).count() == 0:
            for order, name, num_levels in DEFAULT_FACTORY_RANKS:
                session.add(FactoryRank(order=order, name=name, num_levels=num_levels))
        session.commit()
        cfg_cache_clear()   # سیدِ بالا مستقیم Config اضافه کرد
    finally:
        session.close()
    _migrate_factory_ranks_v2()
    _migrate_forced_config_overrides()


def get_session():
    return SessionLocal()


def is_any_admin(session, user_id: int) -> bool:
    """True یعنی مالکِ اصلیه یا یه ادمینِ فرعیِ ثبت‌شده‌ست (فارغ از اینکه چه
    دسترسی‌هایی داره - فقط برای «آیا اصلاً ادمینه» استفاده می‌شه)."""
    if config.OWNER_ID and user_id == config.OWNER_ID:
        return True
    return session.get(AdminUser, user_id) is not None


def admin_permissions(session, user_id: int) -> set:
    au = session.get(AdminUser, user_id)
    if not au:
        return set()
    try:
        return set(json.loads(au.permissions or "[]"))
    except (ValueError, TypeError):
        return set()


def has_admin_permission(session, user_id: int, category) -> bool:
    """category می‌تونه None باشه (یعنی این بخش برای هر ادمینی، فارغ از
    دسترسیِ خاص، آزاده - مثلاً خودِ صفحه‌ی اصلیِ پنل)."""
    if config.OWNER_ID and user_id == config.OWNER_ID:
        return True
    if category is None:
        return is_any_admin(session, user_id)
    return category in admin_permissions(session, user_id)


def get_or_create_user(session, tg_user) -> User:
    user = session.get(User, tg_user.id)
    if user is None:
        user = User(
            telegram_id=tg_user.id,
            username=tg_user.username,
            first_name=tg_user.first_name,
            last_collect_at=now(),
        )
        session.add(user)
        session.commit()
    else:
        # همیشه یوزرنیم/نام رو به‌روز نگه داریم
        changed = False
        if user.username != tg_user.username:
            user.username = tg_user.username
            changed = True
        if user.first_name != tg_user.first_name:
            user.first_name = tg_user.first_name
            changed = True
        if changed:
            session.commit()
    return user


# کَشِ جدولِ تنظیمات (game_config).
#
# قبلاً هر cfg_get* یه کوئریِ جدا به دیتابیس بود. تو ربات ده‌ها بار تو هر دکمه/پیام
# (و صدها بار تو هر تیکِ پس‌زمینه) cfg_get صدا زده می‌شه؛ رویِ SQLite محلی ارزون بود، ولی
# رویِ PostgreSQLِ ریموت هر کدوم یه رفت‌وبرگشتِ شبکه (۲۰ تا ۱۰۰ میلی‌ثانیه) و چون
# هندلرها async-ان ولی DB همگامه، همه‌ی کاربرها پشتِ همون انتظار گیر می‌کردن.
# حالا کلِ جدول (چند صد ردیفِ کوچیک) یک‌جا تو حافظه نگه داشته می‌شه:
#   • cfg_set فوراً هم دیتابیس هم کش رو به‌روز می‌کنه (رفتارِ پنلِ ادمین عیناً همون قبلیه)؛
#   • اگه کسی بیرون از ربات جدول رو عوض کنه، حداکثر بعد از CFG_CACHE_TTL_SECONDS دیده می‌شه؛
#   • کلیدی که تو جدول نیست مثلِ قبل مقدارِ DEFAULT_CONFIG رو برمی‌گردونه.
_CFG_LOCK = threading.Lock()
_CFG_CACHE = {}          # key -> value (دقیقاً همون چیزی که تو ستونِ value هست، حتی None)
_CFG_LOADED_AT = -1e9    # «هیچ‌وقت بارگیری نشده» (نه صفر: monotonic ممکنه بعد از بوتِ تازه کوچیک باشه)
_CFG_VERSION = 0         # با هر cfg_set/cfg_cache_clear زیاد می‌شه؛ تا بارگیریِ قدیمی روی تغییرِ جدید ننویسه


def cfg_cache_clear():
    """بعد از هر جایی که مستقیم (بدونِ cfg_set) ردیفِ Config اضافه/عوض می‌کنه صدا بزن."""
    global _CFG_LOADED_AT, _CFG_VERSION
    with _CFG_LOCK:
        _CFG_VERSION += 1
        _CFG_LOADED_AT = -1e9


def _cfg_refresh(session):
    global _CFG_LOADED_AT
    with _CFG_LOCK:
        ver = _CFG_VERSION
    with session.no_autoflush:
        rows = session.query(Config.key, Config.value).all()
    fresh = {k: v for k, v in rows}
    with _CFG_LOCK:
        if ver == _CFG_VERSION:     # وسطِ خوندن cfg_set/clear نیومده باشه
            _CFG_CACHE.clear()
            _CFG_CACHE.update(fresh)
            _CFG_LOADED_AT = _time.monotonic()
            return True
    return False


def cfg_get(session, key: str) -> str:
    fresh = (_time.monotonic() - _CFG_LOADED_AT) < config.CFG_CACHE_TTL_SECONDS
    if not fresh:
        try:
            _cfg_refresh(session)
        except Exception:
            # دیتابیس لحظه‌ای در دسترس نبود: اگه کش داریم همون رو بده، وگرنه مثلِ قبل خطا بده
            if not _CFG_CACHE:
                row = session.get(Config, key)
                return row.value if row else DEFAULT_CONFIG.get(key)
    if key in _CFG_CACHE:
        return _CFG_CACHE[key]
    # کلیدی که تو جدول نیست -> مثلِ قبل مقدارِ پیش‌فرضِ کد (سیدهایِ تازه با cfg_cache_clear دیده می‌شن)
    return DEFAULT_CONFIG.get(key)


def cfg_get_float(session, key: str) -> float:
    return float(cfg_get(session, key))


def cfg_get_int(session, key: str) -> int:
    return int(float(cfg_get(session, key)))


def cfg_set(session, key: str, value):
    global _CFG_VERSION
    row = session.get(Config, key)
    if row is None:
        row = Config(key=key, value=str(value))
        session.add(row)
    else:
        row.value = str(value)
    session.commit()
    with _CFG_LOCK:
        _CFG_VERSION += 1
        _CFG_CACHE[key] = str(value)


def user_lvl(user) -> int:
    """لولِ فعلیِ کاربر (پیش‌فرض ۱ اگه هنوز چیزی ست نشده)."""
    return user.lvl or 1


def register_hop_for_lvl(user):
    """بعدِ هر «هاپ هاپ» صدا زده می‌شه (hop_count از قبل +۱ شده باشه). هر ۱۳ تا
    هاپ، یه لول اضافه می‌کنه (نه اینکه از رو فرمول از نو حساب کنه)، تا اگه
    مالک دستی لولِ کسی رو از پنل عوض کرده باشه، اون تغییر حفظ بمونه و هاپِ
    بعدی درست از همون‌جا +۱ کنه. برمی‌گردونه True اگه همین الان لول‌آپ شده.
    """
    if (user.hop_count or 0) % HOPS_PER_LVL == 0 and user_lvl(user) < MAX_LVL:
        user.lvl = user_lvl(user) + 1
        return True
    return False


def get_module_min_level(session, module_key: str) -> int:
    return cfg_get_int(session, f"minlvl_{module_key}")


def check_module_level(session, user, module_key: str):
    """اگه سطحِ (lvl) کاربر برای این بخش کافی نباشه، متنِ خطا رو برمی‌گردونه؛
    وگرنه None (یعنی مجازه). حداقل سطحِ ۰ یعنی بدونِ محدودیت."""
    need = get_module_min_level(session, module_key)
    if need and user_lvl(user) < need:
        label = MODULE_LEVEL_GATES.get(module_key, module_key)
        return (
            f"❌ سطح شما کافی نیست!\n"
            f"سطحِ شما: {user_lvl(user)} | سطحِ موردنیاز برای «{label}»: {need}"
        )
    return None


def attack_busy_check_message(session, user_id: int, nowt=None) -> str:
    """اگه این کاربر (چه به‌عنوانِ مهاجم چه هدف) الان تو یه عملیاتِ فعالِ
    گروگان‌گیری/حمله باشه، پیامِ خطا رو برمی‌گردونه؛ وگرنه None. این هم
    جلویِ گیرکردنِ همیشگیِ یه نفر رو می‌گیره و هم جلویِ باگِ «دو نفر هم‌زمان
    همدیگه رو گروگان بگیرن» رو (چون تا وقتی یکی‌شون آزاد نشه، اون یکی
    «عملیات‌هاش پر» حساب می‌شه و نمی‌شه روش گروگان زد)."""
    if nowt is None:
        nowt = now()
    holding = (
        session.query(Hostage)
        .filter(Hostage.attacker_id == user_id, Hostage.status == "active", Hostage.ends_at > nowt)
        .first()
    )
    if holding:
        return "❌ عملیات‌هایِ این شخص پر است؛ خودش الان داره یه نفرِ دیگه رو گروگان نگه می‌داره."
    being_held = (
        session.query(Hostage)
        .filter(Hostage.victim_id == user_id, Hostage.status == "active", Hostage.ends_at > nowt)
        .first()
    )
    if being_held:
        return "❌ این کاربر الان گروگانه؛ بعداً امتحان کن."
    mid_battle = (
        session.query(AttackSession)
        .filter(
            or_(AttackSession.attacker_id == user_id, AttackSession.target_id == user_id),
            AttackSession.status == "active",
        )
        .first()
    )
    if mid_battle:
        return "❌ عملیات‌هایِ این شخص پر است؛ الان وسطِ یه عملیاتِ دیگه‌ست."
    pending = (
        session.query(PendingHostageConfirm)
        .filter(or_(PendingHostageConfirm.attacker_id == user_id, PendingHostageConfirm.target_id == user_id))
        .first()
    )
    if pending:
        return "❌ عملیات‌هایِ این شخص پر است؛ یه درخواستِ گروگان‌گیریِ دیگه براش بازه."
    return None


_GROUP_TRACK = {}   # chat_id -> (title, آخرین زمانی که تو دیتابیس نوشتیم)


def track_group_chat(session, chat):
    """هر بار پیامی از یه گروه بیاد صدا زده می‌شه تا فهرستِ گروه‌هایی که ربات
    توشون فعاله به‌روز بمونه (برای اعلامِ قرعه‌کشیِ سراسری لازمه).

    سرعت: این تابع قبلاً با *هر* پیامِ هر گروه یه SELECT + UPDATE + COMMIT به دیتابیسِ
    ریموت می‌زد (حتی برایِ پیامِ «سلام» ساده). چیزی که واقعاً لازمه (وجودِ گروه + عنوانش)
    بین پیام‌ها تغییر نمی‌کنه؛ پس فقط وقتی می‌نویسیم که گروه تازه باشه، عنوان عوض شده باشه، یا
    از آخرین نوشتن GROUP_TRACK_WRITE_SECONDS گذشته باشه (last_seen_at تو هیچ منطقی خونده
    نمی‌شه و فقط یه نشونه‌ست؛ با همین دقتِ چنددقیقه‌ای کاملاً کافیه)."""
    if not chat or chat.type == "private":
        return
    title = chat.title or getattr(chat, "first_name", None) or str(chat.id)
    mono = _time.monotonic()
    seen = _GROUP_TRACK.get(chat.id)
    if seen is not None and seen[0] == title and (mono - seen[1]) < config.GROUP_TRACK_WRITE_SECONDS:
        return
    gc = session.get(GroupChat, chat.id)
    if gc is None:
        session.add(GroupChat(chat_id=chat.id, title=title, last_seen_at=now()))
    else:
        gc.title = title
        gc.last_seen_at = now()
    session.commit()
    _GROUP_TRACK[chat.id] = (title, mono)


# ---------------------------------------------------------------------------
# «اسمِ دلخواهِ سگ» (User.cat_name) تو حافظه
# ---------------------------------------------------------------------------
# handlers.text_router برایِ *هر* پیامِ عادیِ هر گروه (که هیچ تریگری نیست) باید چک کنه
# «شاید این آدم اسمِ سگش رو صدا زده». قبلاً این یعنی یه SELECT به دیتابیسِ ریموت برایِ
# هر پیامِ گروه. حالا فقط ردیف‌هایی که اسم دارن (تعدادشون کمه) تو یه دیکشنری نگه داشته می‌شن:
#   • هر تغییرِ ORM رویِ cat_name (از هر جایِ کد: هندلرِ تغییرِ اسم، پنلِ ادمین، ریستور) فوراً
#     همین‌جا ثبت می‌شه (event listener پایین)؛
#   • یه بازخوانیِ کامل هر ۱۲۰ ثانیه هم هست تا چیزی جا نمونه (مثلاً rollback یا تغییرِ بیرونی).
_CATNAME = {}
_CATNAME_LOADED_AT = -1e9
_CATNAME_TTL = 120.0
_CATNAME_LOCK = threading.Lock()


def _catname_reload():
    global _CATNAME_LOADED_AT
    s = SessionLocal()
    try:
        rows = s.query(User.telegram_id, User.cat_name).filter(User.cat_name.isnot(None), User.cat_name != "").all()
    finally:
        s.close()
    with _CATNAME_LOCK:
        _CATNAME.clear()
        _CATNAME.update({int(uid): name for uid, name in rows})
        _CATNAME_LOADED_AT = _time.monotonic()


def cat_name_matches(user_id: int, text: str) -> bool:
    """True اگه کاربر اسمِ دلخواهِ سگ داره و متن دقیقاً همونه (همون شرطِ قبلیِ text_router)."""
    if (_time.monotonic() - _CATNAME_LOADED_AT) >= _CATNAME_TTL:
        try:
            _catname_reload()
        except Exception:
            # دیتابیس در دسترس نبود: مثلِ قبل مستقیم از ردیفِ کاربر بخون
            s = SessionLocal()
            try:
                u = s.get(User, user_id)
                return bool(u and u.cat_name and text == u.cat_name)
            finally:
                s.close()
    name = _CATNAME.get(int(user_id))
    return bool(name and text == name)


@event.listens_for(User.cat_name, "set")
def _catname_on_set(target, value, oldvalue, initiator):
    uid = getattr(target, "telegram_id", None)
    if uid is None:
        return   # کاربرِ تازه‌ساخته‌شده؛ بازخوانیِ دوره‌ای می‌گیردش
    with _CATNAME_LOCK:
        if value:
            _CATNAME[int(uid)] = value
        else:
            _CATNAME.pop(int(uid), None)


# ---------------------------------------------------------------------------
# ایندکس‌هایِ PostgreSQL
# ---------------------------------------------------------------------------
# SQLite با ایندکس‌هایِ محلی کند نبود، ولی رویِ PostgreSQL هر کوئریِ فیلتر روی ستونِ بدونِ
# ایندکس (وضعیتِ دورهای بازی، user_id تو جدول‌هایِ کارت/گوشی/بدهی، ...) کلِ جدول رو
# می‌خونه. این لیست فقط ایندکسِ اضافه می‌کنه (هیچ جدول/ستون/دیتایی عوض نمی‌شه) و
# چون «IF NOT EXISTS»ه هر چندبار اجرا بشه بی‌اثره. ستون/جدولی که تو این نسخه نباشه ردّ می‌شه.
_PG_INDEXES = [
    # (جدول, (ستون‌ها...))
    ("user_cards", ("user_id",)), ("user_cards", ("event_id",)),
    ("user_card_tokens", ("user_id",)), ("user_card_progress", ("user_id",)),
    ("card_listings", ("event_id", "is_sold")), ("card_listings", ("seller_id",)),
    ("black_market_listings", ("is_sold",)), ("black_market_listings", ("seller_id",)),
    ("hostages", ("status", "ends_at")), ("hostages", ("chat_id",)),
    ("attack_sessions", ("status",)), ("attack_sessions", ("attacker_id",)), ("attack_sessions", ("target_id",)),
    ("platform_requests", ("user_id",)), ("platform_requests", ("status", "fee_deadline")),
    ("user_debts", ("user_id", "is_paid")),
    ("user_phones", ("user_id",)), ("user_phones", ("is_discarded",)),
    ("myawy_posts", ("user_id",)), ("myawy_post_likes", ("post_id", "user_id")), ("myawy_post_likes", ("user_id",)),
    ("casino_players", ("user_id",)),
    ("casino_rounds", ("status",)), ("casino_rounds", ("chat_id", "status")),
    ("battleship_rounds", ("status",)), ("battleship_rounds", ("chat_id", "status")),
    ("mastermind_rounds", ("status",)), ("mastermind_rounds", ("chat_id", "status")),
    ("guessnum_rounds", ("status",)), ("guessnum_rounds", ("chat_id", "status")),
    ("guessnum_rounds", ("setter_id",)), ("guessnum_rounds", ("guesser_id",)),
    ("uno_rounds", ("status",)), ("uno_rounds", ("chat_id", "status")),
    ("roulette_rounds", ("chat_id", "status")), ("mafia_rounds", ("chat_id", "status")),
    ("smuggling_operations", ("status",)), ("smuggling_operations", ("chat_id", "status")),
    ("duel_lobbies", ("status",)), ("duel_lobbies", ("chat_id", "status")),
    ("chef_elections", ("status", "closes_at")), ("chef_elections", ("chat_id", "status")),
    ("chef_recall_votes", ("chat_id", "chef_user_id")), ("chef_votes", ("user_id",)), ("chef_candidates", ("user_id",)),
    ("group_chefs", ("user_id",)), ("group_food_stock", ("chat_id",)),
    ("lottery_events", ("is_active",)), ("currency_orders", ("status",)),
    ("reports", ("status",)),
    ("activity_counters", ("metric", "bucket")),
    ("heist_operations", ("status",)), ("heist_operations", ("panel_id",)),
    ("heist_cooldowns", ("until",)), ("heist_cooldowns", ("op_id",)), ("heist_rewards", ("user_id",)),
    ("war_clan_requests", ("status",)), ("war_clans", ("disbanded",)),
    ("war_clan_war_members", ("user_id",)), ("war_clan_war_members", ("clan_id",)),
    ("war_clan_treasury_tx", ("user_id",)), ("war_confirms", ("user_id",)),
    ("war_battles", ("status", "resolve_at")), ("war_donations", ("status",)),
    ("war_players", ("last_seen_at",)), ("war_jobs", ("finish_at",)),
    ("war_quest_progress", ("period", "quest_key")),
]


def ensure_pg_indexes():
    """بعد از همه‌ی init_*ها (main.py) صدا زده می‌شه، چون جدول‌هایِ جنگ/سرقت/ماموریت دیرتر ساخته می‌شن."""
    if not IS_PG:
        return 0
    from sqlalchemy import inspect as _inspect
    made = 0
    try:
        insp = _inspect(engine)
        tables = set(insp.get_table_names())
        with engine.connect() as conn:
            have = {r[0] for r in conn.exec_driver_sql(
                "SELECT indexname FROM pg_indexes WHERE schemaname = current_schema()")}
            conn.rollback()
        cols_cache = {}
        for table, cols in _PG_INDEXES:
            if table not in tables:
                continue
            if table not in cols_cache:
                cols_cache[table] = {c["name"] for c in insp.get_columns(table)}
            if not all(c in cols_cache[table] for c in cols):
                continue
            name = ("ix_hb_" + table + "_" + "_".join(cols))[:63]
            if name in have:
                continue
            try:
                with engine.begin() as conn:
                    conn.exec_driver_sql(
                        f'CREATE INDEX IF NOT EXISTS "{name}" ON "{table}" ({", ".join(chr(34) + c + chr(34) for c in cols)})')
                made += 1
            except Exception:
                import logging as _lg
                _lg.getLogger(__name__).exception("ساختِ ایندکسِ %s ناموفق بود (ردّ شد)", name)
    except Exception:
        import logging as _lg
        _lg.getLogger(__name__).exception("ensure_pg_indexes")
    return made
