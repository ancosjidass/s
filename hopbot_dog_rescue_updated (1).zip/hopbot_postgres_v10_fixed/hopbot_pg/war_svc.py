# -*- coding: utf-8 -*-
"""
لایه‌ی سرویسِ جنگ هاپویی (بخش ۱): کانفیگ، لجر، بازیکن/پایگاه، ساختمان، نیرو،
Reward Engine، Unlock Engine، مأموریت/دستاورد/ایونت.

قانون: هیچ Handler تلگرامی مستقیم هاپ پوینت رو تغییر نمی‌ده؛ همه چیز از hop_apply می‌گذره.
هر تابع با session گرفته‌شده کار می‌کنه و commit رو به فراخوان (یا نبرد/tick) می‌سپره؛
پس هر «عملِ کاربر» یک تراکنشِ اتمیک (همه یا هیچ) می‌مونه.
"""
import datetime
import json
import math
import random

import db
import economy
import war_db as W


class WarError(Exception):
    """خطای قابل‌نمایش به کاربر (متنِ فارسی)."""


def utcnow():
    return datetime.datetime.utcnow()


# ---------------------------------------------------------------------------
# کانفیگ
# ---------------------------------------------------------------------------

def cf(session, key, default=0.0) -> float:
    v = db.cfg_get(session, key)
    try:
        return float(v)
    except (TypeError, ValueError):
        return float(default)


def ci(session, key, default=0) -> int:
    return int(cf(session, key, default))


def cs(session, key, default="") -> str:
    v = db.cfg_get(session, key)
    return default if v is None else str(v)


def csv_floats(session, key, default="") -> list:
    out = []
    for x in cs(session, key, default).split(","):
        x = x.strip()
        if x:
            try:
                out.append(float(x))
            except ValueError:
                pass
    return out


def formula_params(session, version=None):
    """پارامترهای «منتشرشده»ی فرمول (Snapshot). نبردها همیشه با Snapshot محاسبه می‌شن، نه پیش‌نویسِ زنده."""
    import war_engine
    if version is None:
        version = ci(session, "war_formula_version", 1)
    row = session.get(W.WarFormulaVersion, version)
    d = json.loads(row.params_json) if row else {k: db.cfg_get(session, k) for k in W.FORMULA_KEYS}
    return war_engine.Params.from_dict(d), version


def publish_formula(session, actor_id, note=""):
    """Battle Formula vN+1: از روی مقادیرِ زنده (پیش‌نویس) یه Snapshot می‌سازه و فعالش می‌کنه."""
    import war_engine
    cm = cs(session, "war_f_counter_matrix", "{}")
    try:
        err = war_engine.validate_counter_matrix(json.loads(cm))
    except ValueError:
        err = "JSON نامعتبر"
    if err:
        raise WarError(f"ماتریسِ کانتر نامعتبره: {err}")
    last = session.query(W.WarFormulaVersion).order_by(W.WarFormulaVersion.version.desc()).first()
    new_v = (last.version if last else 0) + 1
    params = {k: db.cfg_get(session, k) for k in W.FORMULA_KEYS}
    session.add(W.WarFormulaVersion(version=new_v, params_json=json.dumps(params, ensure_ascii=False), note=note))
    db.cfg_set(session, "war_formula_version", new_v)
    audit(session, actor_id, "formula_publish", version=new_v)
    session.commit()
    return new_v


# ---------------------------------------------------------------------------
# لجر و آدیت
# ---------------------------------------------------------------------------

LEDGER_TYPES = {"EARN", "SPEND", "BONUS", "PENALTY", "COMPENSATION", "REFUND", "ADMIN_ADJUSTMENT",
                "EVENT_REWARD", "BATTLE_REWARD", "CLAN_REWARD", "QUEST_REWARD"}


def audit(session, actor_id, action, **detail):
    session.add(W.WarAudit(actor_id=actor_id, action=action, detail=json.dumps(detail, ensure_ascii=False, default=str)))


def hop_apply(session, user, amount: float, ttype: str, reason: str, ref=None) -> float:
    """
    تنها راهِ تغییرِ هاپ پوینت در سیستمِ جنگ. علامت‌دار: + دریافت، - پرداخت.
    Negative Prevention + سقفِ موجودی (Integer/Float Overflow) + ثبتِ Transaction.
    """
    if ttype not in LEDGER_TYPES:
        raise ValueError(f"نوعِ تراکنشِ نامعتبر: {ttype}")
    if amount != amount or amount in (float("inf"), float("-inf")):
        raise WarError("مقدارِ نامعتبر.")
    amount = float(amount)
    if abs(amount) < 1e-9:
        return user.hop_points
    new_bal = (user.hop_points or 0) + amount
    if new_bal < -1e-6:
        raise WarError("💸 موجودیِ هاپ پوینتت کافی نیست.")
    max_bal = cf(session, "war_hop_max_balance", 1e15)
    if new_bal > max_bal:
        amount -= (new_bal - max_bal)
        new_bal = max_bal
    user.hop_points = new_bal
    session.add(W.HopTransaction(user_id=user.telegram_id, amount=amount, type=ttype, reason=reason,
                                 reference_id=None if ref is None else str(ref), balance_after=new_bal))
    return new_bal


# ---------------------------------------------------------------------------
# درآمدِ مرجع (اتصال به اقتصادِ فعلی: ۳ تا ۴ برابرِ کارخونه)
# ---------------------------------------------------------------------------

def factory_ref_per_min(session, level: int) -> float:
    prod, _, _ = economy.factory_level_values(session, max(1, int(level)))
    return prod


def ref_hourly(session, level: int) -> float:
    """درآمدِ ساعتیِ مرجعِ سطحِ level = ضریبِ جنگ × تولیدِ ساعتیِ کارخونه در همون سطح.
    چون از خودِ فرمولِ کارخونه می‌خونه، اگه ادمین اقتصادِ کارخونه رو عوض کنه، جنگ خودکار هم‌تراز می‌مونه."""
    return cf(session, "war_income_multiplier", 3.5) * 60.0 * factory_ref_per_min(session, level)


def mat_per_hour(session, level: int) -> float:
    return cf(session, "war_mat_base_per_hour", 120) * (cf(session, "war_mat_growth", 1.1) ** (max(1, level) - 1))


# ---------------------------------------------------------------------------
# ایونت
# ---------------------------------------------------------------------------

def event_mults(session, player_level=99, battle_type="", now=None) -> dict:
    now = now or utcnow()
    out = {"xp": 1.0, "loot": 1.0, "hop": 1.0, "income": 1.0}
    rows = session.query(W.WarEvent).filter(W.WarEvent.enabled == True, W.WarEvent.start_at <= now,  # noqa: E712
                                            W.WarEvent.end_at > now).all()
    for e in rows:
        if e.min_level and player_level < e.min_level:
            continue
        if e.battle_type and battle_type and e.battle_type != battle_type:
            continue
        out["xp"] *= e.xp_mult
        out["loot"] *= e.loot_mult
        out["hop"] *= e.hop_mult
        out["income"] *= e.income_mult
    return out


# ---------------------------------------------------------------------------
# بازیکن / XP / سطح
# ---------------------------------------------------------------------------

def xp_required(session, level: int) -> float:
    n = level - 1
    return cf(session, "war_level_base_xp", 250) + n * cf(session, "war_level_growth", 110) + \
        cf(session, "war_level_quad", 0.6) * n * n


def level_from_xp(session, xp: float):
    """(سطح، XP داخلِ سطح، XP لازم برای سطحِ بعد)."""
    mx = ci(session, "war_max_level", 100)
    lvl, rem = 1, float(xp)
    while lvl < mx:
        need = xp_required(session, lvl)
        if rem >= need:
            rem -= need
            lvl += 1
        else:
            return lvl, rem, need
    return lvl, 0.0, 0.0


def player_level(session, player) -> int:
    return level_from_xp(session, player.xp)[0]


def get_player(session, uid: int, create=True):
    p = session.get(W.WarPlayer, uid)
    if p is None and create:
        if session.get(db.User, uid) is None:
            raise WarError("کاربر پیدا نشد؛ اول در ربات ثبت‌نام کن.")
        now = utcnow()
        p = W.WarPlayer(user_id=uid, fuel=cf(session, "war_start_fuel", 10), fuel_at=now, readiness=100,
                        readiness_at=now, vault_at=now, created_at=now, last_seen_at=now)
        session.add(p)
        session.flush()
        for d in session.query(W.WarBuildingDef).filter_by(free_start=True, enabled=True).all():
            session.add(W.WarBuilding(user_id=uid, key=d.key, level=1))
        inf = session.get(W.WarUnitDef, "infantry")
        if inf:
            session.add(W.WarUnit(user_id=uid, unit_key="infantry", healthy=ci(session, "war_start_infantry", 20), damaged=0, level=1))
        p.vault_hop = 0.5 * ref_hourly(session, 1)   # هدیه‌ی شروع: نیم ساعت درآمدِ معدن، فقط داخل گاوصندوقِ جنگ
        p.vault_mat = mat_per_hour(session, 1) * cf(session, "war_start_mat_hours", 8)   # کافی برای اولین ارتقا
        audit(session, uid, "player_created")
        session.flush()
    return p


def add_xp(session, player, amount: float):
    if amount <= 0:
        return 0
    before = player_level(session, player)
    player.xp = (player.xp or 0) + amount
    metric_bump(session, player.user_id, "xp_gain", amount, _skip_ach=False)
    return player_level(session, player) - before


def level_of(session, uid) -> int:
    p = session.get(W.WarPlayer, uid)
    return player_level(session, p) if p else 1


# ---------------------------------------------------------------------------
# ساختمان‌ها
# ---------------------------------------------------------------------------

def bdefs(session, enabled_only=True):
    q = session.query(W.WarBuildingDef)
    if enabled_only:
        q = q.filter_by(enabled=True)
    return q.order_by(W.WarBuildingDef.sort, W.WarBuildingDef.key).all()


def buildings_of(session, uid) -> dict:
    return {b.key: b for b in session.query(W.WarBuilding).filter_by(user_id=uid).all()}


def bld_level(session, uid, key) -> int:
    b = session.query(W.WarBuilding).filter_by(user_id=uid, key=key).first()
    return b.level if b else 0


def building_value(d, level: int) -> float:
    if level <= 0:
        return 0.0
    return d.value_base * (d.value_growth ** (level - 1)) + d.value_add * (level - 1)


def kind_level(session, uid, kind) -> int:
    d = session.query(W.WarBuildingDef).filter_by(kind=kind, enabled=True).first()
    return bld_level(session, uid, d.key) if d else 0


def kind_def(session, kind):
    return session.query(W.WarBuildingDef).filter_by(kind=kind, enabled=True).first()


def building_cap(session, player, d) -> int:
    if d.kind == "th":
        return d.max_level
    return min(d.max_level, max(1, player.th_level) * ci(session, "war_level_step", 3))


def upgrade_hours(session, target_level: int) -> float:
    return cf(session, "war_upgrade_h0", 1.5) + cf(session, "war_upgrade_h1", 1.2) * max(0, target_level - 2)


def building_upgrade_cost(session, d, target_level: int):
    """(هاپ، مواد، ثانیه) برای رسیدن به target_level - همه بر پایه‌ی درآمدِ مرجع (خودکار هم‌تراز با اقتصاد)."""
    lvl_for_ref = target_level * 3 - 2 if d.kind == "th" else target_level
    hours = upgrade_hours(session, target_level if d.kind != "th" else target_level * 3)
    hop = d.cost_weight * hours * ref_hourly(session, lvl_for_ref)
    # مواد: وزنِ هزینه برای مواد حداکثر ۱ (وگرنه از ظرفیتِ انبار بیشتر می‌شد و ارتقا غیرممکن)، بدونِ ضریبِ اضافه
    mat = min(d.cost_weight, 1.0) * cf(session, "war_mat_upgrade_hours", 5) * mat_per_hour(session, lvl_for_ref)
    secs = cf(session, "war_build_time_base_min", 5) * 60 * (cf(session, "war_build_time_growth", 1.32) ** (target_level - 1)) * d.time_weight
    secs = min(secs, cf(session, "war_build_time_max_hours", 72) * 3600)
    return round(hop, -1), round(mat), int(secs)


def builders_total(session, player) -> int:
    per = max(1, ci(session, "war_builders_per_th", 3))
    return ci(session, "war_builders_base", 1) + (max(1, player.th_level) - 1) // per


def builders_busy(session, uid) -> int:
    return session.query(W.WarBuilding).filter(W.WarBuilding.user_id == uid,
                                               W.WarBuilding.upgrade_to.isnot(None)).count()


def clan_bonus_pct(session, clan_id, effect) -> float:
    if not clan_id:
        return 0.0
    tot = 0.0
    rows = session.query(W.WarClanResearch, W.WarResearchDef).join(
        W.WarResearchDef, W.WarClanResearch.key == W.WarResearchDef.key).filter(
        W.WarClanResearch.clan_id == clan_id, W.WarResearchDef.effect == effect,
        W.WarResearchDef.enabled == True).all()  # noqa: E712
    for cr, rd in rows:
        tot += cr.level * rd.effect_per_level
    return tot


def mine_income_ph(session, player, now=None) -> float:
    d = kind_def(session, "mine")
    if not d:
        return 0.0
    lvl = bld_level(session, player.user_id, d.key)
    if lvl <= 0:
        return 0.0
    base = ref_hourly(session, lvl) * d.value_base
    ev = event_mults(session, player_level(session, player), now=now)["income"]
    return base * ev * (1 + clan_bonus_pct(session, player.clan_id, "income_pct") / 100.0)


def mat_income_ph(session, player) -> float:
    d = kind_def(session, "depot")
    lvl = bld_level(session, player.user_id, d.key) if d else 0
    return mat_per_hour(session, lvl) * (d.value_base if d else 1) if lvl > 0 else 0.0


def maintenance_ph(session, uid) -> float:
    tot = 0.0
    rows = session.query(W.WarUnit, W.WarUnitDef).join(W.WarUnitDef, W.WarUnit.unit_key == W.WarUnitDef.key).filter(
        W.WarUnit.user_id == uid, W.WarUnitDef.maint_per_hour > 0).all()
    for u, d in rows:
        tot += (u.healthy + u.damaged) * d.maint_per_hour
    return tot


def vault_caps(session, player):
    d = kind_def(session, "vault")
    lvl = bld_level(session, player.user_id, d.key) if d else 1
    lvl = max(1, lvl)
    hop_cap = ref_hourly(session, lvl) * cf(session, "war_vault_cap_hours", 8)
    mat_cap = mat_per_hour(session, lvl) * cf(session, "war_mat_cap_hours", 12)
    return hop_cap, mat_cap


def _accrue(session, p, until, mine, mats, maint, hop_cap, mat_cap):
    hours = max(0.0, (until - p.vault_at).total_seconds() / 3600.0)
    if hours <= 0:
        return
    net = max(0.0, mine - maint)
    p.vault_hop = max(p.vault_hop, min(hop_cap, p.vault_hop + net * hours))
    p.vault_mat = max(p.vault_mat, min(mat_cap, p.vault_mat + mats * hours))
    p.vault_at = until


def sync_player(session, p, now=None):
    """همه‌ی وضعیتِ «تنبل» (lazy) رو تا الان به‌روز می‌کنه: ارتقاها، تولیدِ معدن، سوخت، ریدینس، صف‌ها."""
    now = now or utcnow()
    uid = p.user_id
    # 1) ارتقاهای تموم‌شده به ترتیبِ زمان؛ قبل از هرکدوم تولید تا همون لحظه حساب می‌شه
    done = session.query(W.WarBuilding).filter(W.WarBuilding.user_id == uid, W.WarBuilding.upgrade_to.isnot(None),
                                               W.WarBuilding.upgrade_finish_at <= now).order_by(
        W.WarBuilding.upgrade_finish_at).all()
    for b in done:
        hop_cap, mat_cap = vault_caps(session, p)
        _accrue(session, p, b.upgrade_finish_at, mine_income_ph(session, p, b.upgrade_finish_at),
                mat_income_ph(session, p), maintenance_ph(session, uid), hop_cap, mat_cap)
        b.level = b.upgrade_to
        b.upgrade_to = None
        b.upgrade_finish_at = None
        d = session.get(W.WarBuildingDef, b.key)
        if d and d.kind == "th":
            p.th_level = b.level
        give_reward(session, uid, "upgrade_done", ref=f"upgrade:{b.key}:{b.level}", _player=p)
        metric_bump(session, uid, "upgrades", 1)
        session.flush()
    # 2) تولید تا الان
    hop_cap, mat_cap = vault_caps(session, p)
    _accrue(session, p, now, mine_income_ph(session, p, now), mat_income_ph(session, p), maintenance_ph(session, uid),
            hop_cap, mat_cap)
    # 3) سوخت و ریدینس
    fmax = cf(session, "war_fuel_max", 10)
    regen_min = max(1.0, cf(session, "war_fuel_regen_minutes", 30))
    if p.fuel < fmax:
        gained = (now - p.fuel_at).total_seconds() / 60.0 / regen_min
        p.fuel = min(fmax, p.fuel + gained)
    p.fuel_at = now
    rec = cf(session, "war_readiness_recovery_per_hour", 6) * (1 + clan_bonus_pct(session, p.clan_id, "readiness_pct") / 100)
    if p.readiness < 100:
        p.readiness = min(100.0, p.readiness + rec * (now - p.readiness_at).total_seconds() / 3600.0)
    p.readiness_at = now
    # 4) صف ساخت/تعمیر
    complete_jobs(session, p, now)
    p.last_seen_at = now
    return p


def collect_vault(session, p):
    """برداشتِ هاپِ گاوصندوقِ جنگ به کیف‌پولِ اصلی (لجر: EARN)."""
    sync_player(session, p)
    amt = math.floor(p.vault_hop)
    if amt <= 0:
        raise WarError("گاوصندوق خالیه.")
    user = session.get(db.User, p.user_id)
    p.vault_hop -= amt
    hop_apply(session, user, amt, "EARN", "war:vault_collect", ref=f"vault:{p.user_id}:{int(utcnow().timestamp())}")
    audit(session, p.user_id, "vault_collect", amount=amt)
    return amt


def start_upgrade(session, p, key):
    sync_player(session, p)
    d = session.get(W.WarBuildingDef, key)
    if not d or not d.enabled:
        raise WarError("این ساختمان وجود نداره.")
    b = session.query(W.WarBuilding).filter_by(user_id=p.user_id, key=key).first()
    lvl = player_level(session, p)
    if b is None:
        if p.th_level < d.unlock_th:
            raise WarError(f"برای ساختِ این ساختمان مقر باید سطح {d.unlock_th} باشه.")
        if lvl < d.req_level:
            raise WarError(f"سطحِ شخصیت باید {d.req_level} باشه.")
        target = 1
    else:
        if b.upgrade_to:
            raise WarError("این ساختمان الان در حالِ ارتقاست.")
        target = b.level + 1
    cap = building_cap(session, p, d)
    if target > cap:
        if d.kind != "th":
            raise WarError(f"سقفِ سطح با مقرِ فعلی {cap} ـه؛ اول مقر رو ارتقا بده.")
        raise WarError("به آخرین سطح رسیدی.")
    if d.kind == "th":
        need_lvl = (target - 1) * ci(session, "war_th_level_req_step", 3)
        if lvl < need_lvl:
            raise WarError(f"برای مقرِ سطح {target} باید سطحِ شخصیتت حداقل {need_lvl} باشه (الان {lvl}).")
    if builders_busy(session, p.user_id) >= builders_total(session, p):
        raise WarError("همه‌ی سازنده‌هات مشغولن. صبر کن یا مقر رو ارتقا بده تا سازنده‌ی بیشتر داشته باشی.")
    hop, mat, secs = building_upgrade_cost(session, d, target)
    _, mat_cap = vault_caps(session, p)
    if mat > mat_cap:
        raise WarError("🔩 ظرفیتِ گاوصندوق از مواد لازم برای این ارتقا کمتره؛ اول «گاوصندوق» رو ارتقا بده.")
    if p.vault_mat < mat:
        raise WarError(f"🔩 مواد کافی نیست (نیاز: {int(mat):,} | موجود: {int(p.vault_mat):,}).")
    user = session.get(db.User, p.user_id)
    hop_apply(session, user, -hop, "SPEND", f"war:upgrade:{key}:{target}", ref=f"upgrade:{key}:{target}")
    p.vault_mat -= mat
    finish = utcnow() + datetime.timedelta(seconds=secs)
    if b is None:
        b = W.WarBuilding(user_id=p.user_id, key=key, level=0, upgrade_to=target, upgrade_finish_at=finish)
        session.add(b)
    else:
        b.upgrade_to = target
        b.upgrade_finish_at = finish
    audit(session, p.user_id, "upgrade_start", key=key, target=target, hop=hop, mat=mat)
    return b, hop, mat, secs


# ---------------------------------------------------------------------------
# نیروها (Equipment)
# ---------------------------------------------------------------------------

def udefs(session, enabled_only=True):
    q = session.query(W.WarUnitDef)
    if enabled_only:
        q = q.filter_by(enabled=True)
    return q.order_by(W.WarUnitDef.sort, W.WarUnitDef.key).all()


def units_of(session, uid) -> dict:
    return {u.unit_key: u for u in session.query(W.WarUnit).filter_by(user_id=uid).all()}


def unit_level_mult(d, level: int) -> float:
    return 1.0 + d.upg_stat_pct / 100.0 * (max(1, level) - 1)


def camp_capacity(session, p) -> int:
    d = kind_def(session, "camp")
    lvl = bld_level(session, p.user_id, d.key) if d else 1
    return int(building_value(d, max(1, lvl))) if d else 20


def housing_used(session, uid) -> int:
    used = 0
    defs = {d.key: d for d in udefs(session, enabled_only=False)}
    for u in session.query(W.WarUnit).filter_by(user_id=uid).all():
        d = defs.get(u.unit_key)
        if d:
            used += (u.healthy + u.damaged) * d.housing
    for j in session.query(W.WarJob).filter_by(user_id=uid, status="queued").all():
        d = defs.get(j.unit_key)
        if d and j.kind == "train":
            used += j.qty * d.housing
    for b in session.query(W.WarBattle).filter_by(attacker_id=uid, status="marching").all():
        try:
            army = json.loads(b.army_json or "{}")
        except ValueError:
            army = {}
        for k, v in army.items():
            d = defs.get(k)
            if d:
                used += (v.get("h", 0) + v.get("d", 0)) * d.housing
    try:                                    # 🌌 نیروهای در حالِ عملیاتِ Frontier هم ظرفیتِ پادگان رو اشغال می‌کنن
        import frontier_db as _F
        for r in session.query(_F.FrontierRun).filter(_F.FrontierRun.user_id == uid, _F.FrontierRun.status.in_(("marching", "resolving"))).all():
            try:
                army = json.loads(r.army_json or "{}")
            except ValueError:
                army = {}
            for k, v in army.items():
                d = defs.get(k)
                if d and not k.startswith("_"):
                    used += (v.get("h", 0) + v.get("d", 0)) * d.housing
    except Exception:
        pass
    return used


def check_req(session, p, level=0, th=0, clan_level=0, wins=0, quest="", ach="", research=""):
    """Unlock Engine: (ok, متنِ شرط‌های ناقص)."""
    missing = []
    lv = player_level(session, p)
    if level and lv < level:
        missing.append(f"سطح {level}")
    if th and p.th_level < th:
        missing.append(f"مقرِ سطح {th}")
    if clan_level:
        cl = session.get(W.WarClan, p.clan_id) if p.clan_id else None
        if not cl or cl.level < clan_level:
            missing.append(f"قبیله‌ی سطح {clan_level}")
    if wins and p.wins < wins:
        missing.append(f"{wins} پیروزی")
    if quest and not quest_done(session, p.user_id, quest):
        qd = session.get(W.WarQuestDef, quest)
        missing.append(f"مأموریتِ «{qd.name if qd else quest}»")
    if ach and not has_achievement(session, p.user_id, ach):
        ad = session.get(W.WarAchievementDef, ach)
        missing.append(f"دستاوردِ «{ad.name if ad else ach}»")
    if research:
        cr = session.query(W.WarClanResearch).filter_by(clan_id=p.clan_id or -1, key=research).first() if p.clan_id else None
        if not cr or cr.level < 1:
            missing.append("تحقیقِ قبیله")
    return (not missing), "، ".join(missing)


def unit_unlocked(session, p, d):
    return check_req(session, p, level=d.req_level, th=d.req_th, clan_level=d.req_clan_level,
                     ach=d.req_achievement, research=d.req_research)


def feature_rule(session, feature):
    return session.get(W.WarUnlockRule, feature)


def feature_state(session, p, feature) -> str:
    """unlocked / locked / hidden  (Visible Before Unlock)."""
    r = feature_rule(session, feature)
    if r is None or not r.enabled:
        return "unlocked" if r is None else "hidden"
    ok, _ = check_req(session, p, r.req_level, r.req_th, r.req_clan_level, r.req_wins, r.req_quest,
                      r.req_achievement, r.req_research)
    if ok:
        return "unlocked"
    return "locked" if r.visible_before else "hidden"


def feature_missing(session, p, feature) -> str:
    r = feature_rule(session, feature)
    if not r:
        return ""
    return check_req(session, p, r.req_level, r.req_th, r.req_clan_level, r.req_wins, r.req_quest,
                     r.req_achievement, r.req_research)[1]


def require_feature(session, p, feature):
    if feature_state(session, p, feature) != "unlocked":
        r = feature_rule(session, feature)
        if r and r.visible_before:
            raise WarError(f"🔒 «{r.label}» هنوز قفله. شرط: {feature_missing(session, p, feature)}")
        raise WarError("🔒 این قابلیت هنوز برات باز نشده.")


def pop_new_unlocks(session, p):
    """featureهایی که تازه باز شدن (فقط یک‌بار اعلام می‌شن) → 🔓 NEW SYSTEM UNLOCKED."""
    seen = set(x for x in (p.seen_unlocks or "").split(",") if x)
    new = []
    for r in session.query(W.WarUnlockRule).filter_by(enabled=True).order_by(W.WarUnlockRule.sort).all():
        if r.feature in seen:
            continue
        if feature_state(session, p, r.feature) == "unlocked":
            seen.add(r.feature)
            if r.feature not in ("war_room",):
                new.append(r)
    if new or len(seen) != len([x for x in (p.seen_unlocks or "").split(",") if x]):
        p.seen_unlocks = ",".join(sorted(seen))
    return new


def train_time_secs(session, p, d, qty: int) -> int:
    bd = kind_def(session, "barracks")
    lvl = bld_level(session, p.user_id, bd.key) if bd else 1
    speed = building_value(bd, max(1, lvl)) if bd else 1.0
    speed *= 1 + clan_bonus_pct(session, p.clan_id, "train_speed_pct") / 100.0
    return max(1, int(d.train_seconds * qty / max(0.1, speed)))


def queue_slots(session, p) -> int:
    bd = kind_def(session, "barracks")
    lvl = bld_level(session, p.user_id, bd.key) if bd else 1
    return 1 + lvl // max(1, ci(session, "war_queue_per_barracks_levels", 3))


def _last_finish(session, uid, kind):
    j = session.query(W.WarJob).filter_by(user_id=uid, kind=kind, status="queued").order_by(
        W.WarJob.finish_at.desc()).first()
    return j.finish_at if j else None


def enqueue_train(session, p, key, qty: int):
    sync_player(session, p)
    require_feature(session, p, "factory")
    d = session.get(W.WarUnitDef, key)
    if not d or not d.enabled:
        raise WarError("این تجهیز وجود نداره.")
    ok, miss = unit_unlocked(session, p, d)
    if not ok:
        raise WarError(f"🔒 هنوز باز نشده: {miss}")
    qty = int(qty)
    if qty <= 0:
        raise WarError("تعدادِ نامعتبر.")
    if session.query(W.WarJob).filter_by(user_id=p.user_id, status="queued").count() >= queue_slots(session, p):
        raise WarError("صفِ ساخت پره. صبر کن تا یکی تموم شه یا کارخونه رو ارتقا بده.")
    if housing_used(session, p.user_id) + qty * d.housing > camp_capacity(session, p):
        raise WarError("🏕 ظرفیتِ پادگان کافی نیست.")
    cost, mat = d.cost * qty, d.cost_mat * qty
    if p.vault_mat < mat:
        raise WarError(f"🔩 مواد کافی نیست (نیاز: {int(mat):,}).")
    user = session.get(db.User, p.user_id)
    hop_apply(session, user, -cost, "SPEND", f"war:train:{key}x{qty}")
    p.vault_mat -= mat
    now = utcnow()
    start = max(now, _last_finish(session, p.user_id, "train") or now)
    job = W.WarJob(user_id=p.user_id, kind="train", unit_key=key, qty=qty, start_at=start,
                   finish_at=start + datetime.timedelta(seconds=train_time_secs(session, p, d, qty)))
    session.add(job)
    audit(session, p.user_id, "train_start", key=key, qty=qty, cost=cost, mat=mat)
    return job, cost, mat


def repair_discount(session, p) -> float:
    wd = kind_def(session, "workshop")
    lvl = bld_level(session, p.user_id, wd.key) if wd else 0
    disc = min(cf(session, "war_repair_workshop_max_pct", 50), lvl * cf(session, "war_repair_workshop_disc_pct", 2))
    disc += clan_bonus_pct(session, p.clan_id, "repair_disc_pct")
    return min(90.0, disc) / 100.0


def repair_cost(session, p, d, qty: int):
    f = d.repair_pct / 100.0 * (1 - repair_discount(session, p))
    return d.cost * f * qty, d.cost_mat * f * qty


def enqueue_repair(session, p, key, qty: int):
    sync_player(session, p)
    require_feature(session, p, "repair")
    d = session.get(W.WarUnitDef, key)
    u = session.query(W.WarUnit).filter_by(user_id=p.user_id, unit_key=key).first()
    if not d or not u or not d.repairable:
        raise WarError("این تجهیز قابلِ تعمیر نیست.")
    qty = min(int(qty), u.damaged)
    if qty <= 0:
        raise WarError("چیزی برای تعمیر نیست (نابودشده‌ها تعمیر نمی‌شن).")
    if session.query(W.WarJob).filter_by(user_id=p.user_id, status="queued").count() >= queue_slots(session, p) + 1:
        raise WarError("صفِ تعمیر پره.")
    cost, mat = repair_cost(session, p, d, qty)
    if p.vault_mat < mat:
        raise WarError(f"🔩 مواد کافی نیست (نیاز: {int(mat):,}).")
    user = session.get(db.User, p.user_id)
    hop_apply(session, user, -cost, "SPEND", f"war:repair:{key}x{qty}")
    p.vault_mat -= mat
    u.damaged -= qty                     # تا پایانِ تعمیر از ارتش خارجه
    now = utcnow()
    start = max(now, _last_finish(session, p.user_id, "repair") or now)
    speed = 1 + 0.05 * (bld_level(session, p.user_id, "workshop") or 0)
    job = W.WarJob(user_id=p.user_id, kind="repair", unit_key=key, qty=qty, start_at=start,
                   finish_at=start + datetime.timedelta(seconds=max(1, int(d.repair_seconds * qty / speed))))
    session.add(job)
    audit(session, p.user_id, "repair_start", key=key, qty=qty, cost=cost)
    return job, cost, mat


def complete_jobs(session, p, now):
    jobs = session.query(W.WarJob).filter(W.WarJob.user_id == p.user_id, W.WarJob.status == "queued",
                                          W.WarJob.finish_at <= now).order_by(W.WarJob.finish_at).all()
    for j in jobs:
        # اتمیک: فقط اگه هنوز queued باشه (Idempotent)
        n = session.query(W.WarJob).filter(W.WarJob.id == j.id, W.WarJob.status == "queued").update(
            {"status": "done"}, synchronize_session=False)
        if n != 1:
            continue
        u = session.query(W.WarUnit).filter_by(user_id=p.user_id, unit_key=j.unit_key).first()
        if u is None:
            u = W.WarUnit(user_id=p.user_id, unit_key=j.unit_key, healthy=0, damaged=0, level=1)
            session.add(u)
            session.flush()
        u.healthy += j.qty
        trig = "train_done" if j.kind == "train" else "repair_done"
        give_reward(session, p.user_id, trig, scale=max(1, j.qty) ** 0.5, ref=f"job:{j.id}", _player=p)
        metric_bump(session, p.user_id, "trained" if j.kind == "train" else "repaired", j.qty)


def upgrade_unit(session, p, key):
    sync_player(session, p)
    d = session.get(W.WarUnitDef, key)
    u = session.query(W.WarUnit).filter_by(user_id=p.user_id, unit_key=key).first()
    if not d or not u or not d.upgradeable:
        raise WarError("این تجهیز رو نداری یا قابلِ ارتقا نیست.")
    if u.level >= d.max_level:
        raise WarError("به سقفِ ارتقا رسیده.")
    cost = d.cost * cf(session, "war_unit_upgrade_cost_mult", 3) * u.level * max(1, (u.healthy + u.damaged)) ** 0.5 \
        * cf(session, "war_unit_upgrade_ref_hours", 0.15) / 0.15
    mat = d.cost_mat * cf(session, "war_unit_upgrade_cost_mult", 3) * u.level
    if p.vault_mat < mat:
        raise WarError(f"🔩 مواد کافی نیست (نیاز: {int(mat):,}).")
    user = session.get(db.User, p.user_id)
    hop_apply(session, user, -cost, "SPEND", f"war:unit_upgrade:{key}:{u.level + 1}")
    p.vault_mat -= mat
    u.level += 1
    metric_bump(session, p.user_id, "upgrades", 1)
    audit(session, p.user_id, "unit_upgrade", key=key, level=u.level, cost=cost)
    return u, cost, mat


def sell_units(session, p, key, qty):
    if not ci(session, "war_sell_enabled", 1):
        raise WarError("فروش غیرفعاله.")
    d = session.get(W.WarUnitDef, key)
    u = session.query(W.WarUnit).filter_by(user_id=p.user_id, unit_key=key).first()
    if not d or not u:
        raise WarError("این تجهیز رو نداری.")
    qty = min(int(qty), u.healthy)
    if qty <= 0:
        raise WarError("واحدِ سالمی برای فروش نیست.")
    u.healthy -= qty
    amt = d.cost * d.sell_pct / 100.0 * qty
    hop_apply(session, session.get(db.User, p.user_id), amt, "EARN", f"war:sell:{key}x{qty}")
    return amt


# ---------------------------------------------------------------------------
# Reward Engine
# ---------------------------------------------------------------------------

def _today():
    return utcnow().strftime("%Y-%m-%d")


def player_ref(session, p) -> float:
    d = kind_def(session, "mine")
    lvl = bld_level(session, p.user_id, d.key) if d else 1
    return ref_hourly(session, max(1, lvl))


def give_reward(session, uid, trigger, scale=1.0, ref=None, farm_mult=1.0, xp_mult=1.0, hop_mult=1.0, _player=None,
                battle_type="", clan_xp_scale=1.0):
    """
    تنها مسیرِ پاداش. همه‌ی مقادیر از جدولِ WarRewardRule (پنلِ ادمین). سقفِ روزانه، ضد‌فارم،
    ایونت و لجر اینجا اعمال می‌شن. برمی‌گردونه: {'xp','hop','clan_xp','mat','contribution'}.
    """
    out = {"xp": 0.0, "hop": 0.0, "clan_xp": 0.0, "mat": 0.0, "contribution": 0.0}
    rule = session.get(W.WarRewardRule, trigger)
    if not rule or not rule.enabled:
        return out
    p = _player or get_player(session, uid)
    m = rule.multiplier * scale * (farm_mult if rule.antifarm else 1.0)
    if m <= 0:
        return out
    ev = event_mults(session, player_level(session, p), battle_type=battle_type)
    xp = rule.xp * m * ev["xp"] * xp_mult
    if rule.xp_min:
        xp = max(xp, rule.xp_min)
    if rule.xp_max:
        xp = min(xp, rule.xp_max)
    hop = (rule.hop_abs + rule.hop_ref_hours * player_ref(session, p)) * m * ev["hop"] * hop_mult
    if rule.hop_min and hop > 0:
        hop = max(hop, rule.hop_min)
    if rule.hop_max:
        hop = min(hop, rule.hop_max)
    day = _today()
    cnt = session.query(W.WarRewardCounter).filter_by(user_id=uid, trigger=trigger, day=day).first()
    if cnt is None:
        cnt = W.WarRewardCounter(user_id=uid, trigger=trigger, day=day, hop_total=0, xp_total=0, count=0)
        session.add(cnt)
        session.flush()
    if rule.daily_cap_hop:
        hop = max(0.0, min(hop, rule.daily_cap_hop - cnt.hop_total))
    if rule.daily_cap_xp:
        xp = max(0.0, min(xp, rule.daily_cap_xp - cnt.xp_total))
    cnt.hop_total += hop
    cnt.xp_total += xp
    cnt.count += 1
    hop = math.floor(hop)
    if xp > 0:
        add_xp(session, p, xp)
        out["xp"] = xp
    if hop > 0:
        hop_apply(session, session.get(db.User, uid), hop, rule.ledger_type if rule.ledger_type in LEDGER_TYPES else "BONUS",
                  f"war:{trigger}", ref=ref)
        out["hop"] = hop
    if rule.materials:
        _, mat_cap = vault_caps(session, p)
        add = max(0.0, min(rule.materials * m, mat_cap - p.vault_mat))
        p.vault_mat += add
        out["mat"] = add
    cxp = rule.clan_xp * m * clan_xp_scale
    if cxp > 0 and p.clan_id:
        import war_clan as WB
        WB.clan_add_xp(session, p.clan_id, cxp)
        out["clan_xp"] = cxp
    if rule.contribution and p.clan_id:
        import war_clan as WB
        WB.add_contribution(session, uid, rule.contribution * m)
        out["contribution"] = rule.contribution * m
    return out


# ---------------------------------------------------------------------------
# متریک / مأموریت / دستاورد
# ---------------------------------------------------------------------------

def metric_get(session, uid, metric) -> float:
    m = session.query(W.WarMetric).filter_by(user_id=uid, metric=metric).first()
    return m.value if m else 0.0


def period_key(kind: str) -> str:
    n = utcnow()
    if kind == "daily":
        return n.strftime("%Y-%m-%d")
    if kind == "weekly":
        y, w, _ = n.isocalendar()
        return f"{y}-W{w:02d}"
    return "once"


def metric_bump(session, uid, metric, n=1.0, _skip_ach=False):
    row = session.query(W.WarMetric).filter_by(user_id=uid, metric=metric).first()
    if row is None:
        row = W.WarMetric(user_id=uid, metric=metric, value=0)
        session.add(row)
        session.flush()
    row.value += n
    if metric == "attacks":
        y, w, _ = utcnow().isocalendar()
        metric_bump(session, uid, f"wk_attacks_{y}-W{w:02d}", n, _skip_ach=True)
    lvl = level_of(session, uid)
    for q in session.query(W.WarQuestDef).filter_by(metric=metric, enabled=True).all():
        if lvl < q.req_level:
            continue
        pk = period_key(q.kind)
        prog = session.query(W.WarQuestProgress).filter_by(user_id=uid, quest_key=q.key, period=pk).first()
        if prog is None:
            prog = W.WarQuestProgress(user_id=uid, quest_key=q.key, period=pk, progress=0, claimed=False)
            session.add(prog)
            session.flush()
        prog.progress = min(q.target, prog.progress + int(math.ceil(n)))
    if not _skip_ach:
        _check_achievements(session, uid, metric, row.value)
    return row.value


def has_achievement(session, uid, key) -> bool:
    return session.query(W.WarAchievement).filter_by(user_id=uid, key=key).first() is not None


def _check_achievements(session, uid, metric, value):
    new = []
    for a in session.query(W.WarAchievementDef).filter_by(metric=metric, enabled=True).all():
        if value >= a.threshold and not has_achievement(session, uid, a.key):
            session.add(W.WarAchievement(user_id=uid, key=a.key))
            session.flush()
            p = session.get(W.WarPlayer, uid)
            if p:
                if a.xp:
                    add_xp(session, p, a.xp)
                if a.hop_ref_hours:
                    hop_apply(session, session.get(db.User, uid), math.floor(a.hop_ref_hours * player_ref(session, p)),
                              "BONUS", f"war:achievement:{a.key}", ref=f"ach:{a.key}")
                if a.materials:
                    _, mc = vault_caps(session, p)
                    p.vault_mat = min(mc, p.vault_mat + a.materials)
            new.append(a)
    return new


def quest_done(session, uid, key) -> bool:
    return session.query(W.WarQuestProgress).filter_by(user_id=uid, quest_key=key, claimed=True).first() is not None


def quests_for(session, p, kind):
    lvl = player_level(session, p)
    pk = period_key(kind)
    out = []
    for q in session.query(W.WarQuestDef).filter_by(kind=kind, enabled=True).all():
        if lvl < q.req_level:
            continue
        prog = session.query(W.WarQuestProgress).filter_by(user_id=p.user_id, quest_key=q.key, period=pk).first()
        out.append((q, prog.progress if prog else 0, bool(prog and prog.claimed)))
    return out


def claim_quest(session, p, key):
    q = session.get(W.WarQuestDef, key)
    if not q or not q.enabled:
        raise WarError("مأموریت پیدا نشد.")
    pk = period_key(q.kind)
    prog = session.query(W.WarQuestProgress).filter_by(user_id=p.user_id, quest_key=key, period=pk).first()
    if not prog or prog.progress < q.target:
        raise WarError("هنوز تموم نشده.")
    n = session.query(W.WarQuestProgress).filter(W.WarQuestProgress.id == prog.id,
                                                 W.WarQuestProgress.claimed == False).update(  # noqa: E712
        {"claimed": True}, synchronize_session=False)
    if n != 1:
        raise WarError("قبلاً دریافت کردی.")
    r = {"xp": 0, "hop": 0, "mat": 0}
    if q.xp:
        add_xp(session, p, q.xp)
        r["xp"] = q.xp
    if q.hop_ref_hours:
        ev = event_mults(session, player_level(session, p))
        amt = math.floor(q.hop_ref_hours * player_ref(session, p) * ev["hop"])
        hop_apply(session, session.get(db.User, p.user_id), amt, "QUEST_REWARD", f"war:quest:{key}", ref=f"quest:{key}:{pk}")
        r["hop"] = amt
    if q.materials:
        _, mc = vault_caps(session, p)
        add = max(0, min(q.materials, mc - p.vault_mat))
        p.vault_mat += add
        r["mat"] = add
    if q.clan_xp and p.clan_id:
        import war_clan as WB
        WB.clan_add_xp(session, p.clan_id, q.clan_xp)
    audit(session, p.user_id, "quest_claim", key=key, period=pk)
    return q, r
