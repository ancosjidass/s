# -*- coding: utf-8 -*-
"""
🔫 رولت روسی

از منویِ «کازینو هاپویی» ← «🔫 رولت روسی». دو حالت داره:

🏠 لابی تو همین گپ
   مثلِ بقیه‌ی بازی‌ها: مبلغِ ورودی (از پیش‌تنظیم‌ها یا «✏️ مبلغ دلخواه» - فقط
   همین‌جا) و تعدادِ نفرات (۲/۳/۴) رو می‌چینی، «شروع» رو می‌زنی و لابی تو گپ
   باز می‌شه. ۱۸۰ ثانیه وقت داره پر بشه، وگرنه لغو و پولِ همه برمی‌گرده.

🌍 لابیِ جهانی
   میزِ ثابت (۱ میلیون / ۱۰۰ میلیون / ۵۰۰ میلیون - بدونِ مبلغِ دلخواه) و تعدادِ
   نفرات (۲/۳/۴) رو انتخاب می‌کنی و تو صفِ جهانی منتظر می‌مونی؛ هر بازیکنی از هر
   گپی که همون میز و همون تعداد رو انتخاب کرده باشه با هم می‌افتن. تا ۶ دقیقه
   منتظر می‌مونه؛ پر نشه خودکار لغو و پولت برمی‌گرده. هر لحظه هم با «🚪 منصرف
   شدم» می‌تونی بری (فقط خودِ همون کسی که پنل مالِ اونه می‌تونه بزنه؛ برای بقیه
   انگار لفت داده و شمارنده‌ی لابی (مثلاً ۲/۴) کم می‌شه).

خودِ بازی (تو هر دو حالت یکیه):
- تپانچه: خشابی با تعدادِ دلخواهِ تیرِ «مشقی» و «جنگی» (پیش‌فرض ۵ مشقی + ۱ جنگی؛ از
  پنلِ ادمین ← 🎰 تنظیماتِ کازینو هاپویی قابلِ تغییره). نوبتیِ ثابت نیست: هر بار
  تپانچه شانسی می‌افته دستِ یکی از بازیکن‌های زنده.
- تو نوبتت دو انتخاب داری:
    🔫 شلیک به خودت: جنگی = می‌میری | مشقی = زنده می‌مونی
    🎯 شلیک به یکی دیگه: جنگی = اون می‌میره و تو زنده می‌مونی |
                         مشقی = خودت حذف می‌شی («به دلیل شلیک ناموفق به X»)
  دلیلِ مرگ/حذفِ هر نفر کنارِ اسمش تو پنل نوشته می‌شه.
- اولِ هر نوبت «انتظار برای چرخاندنِ خشاب» (پیش‌فرض ۴۰ ثانیه) هست: تو این مدت شلیک
  ممکن نیست (پیامِ «هنوز ۴۰ ثانیه نشده»). *بعدِ* تمومِ انتظار، مهلتِ شلیک (پیش‌فرض ۱۲۰
  ثانیه) شروع می‌شه؛ شلیک نکنی از بازی حذف می‌شی (ورودیت می‌سوزه) و بازی بینِ بقیه
  ادامه داره؛ اگه فقط یه نفر بمونه همون‌جا برنده‌ست. بالایِ پنل مقدارِ فعلیِ انتظار
  نوشته می‌شه و همه‌ی این عددها (تعدادِ تیرها، انتظار، مهلت) از تنظیماتِ ادمین
  می‌آد و از نوبتِ بعدی اعمال می‌شه.
- پنل همیشه نشون می‌ده «نوبتِ کیه»؛ دکمه‌هایِ شلیک فقط برای همون نفره - برای
  بقیه پیغامِ «نوبتِ تو نیست» می‌ده (تو لابیِ جهانی اصلاً دکمه‌ی شلیک نمی‌بینن).
- هر بار یکی کشته شد، خشاب (با تنظیماتِ همون لحظه) دوباره پر و چرخونده می‌شه. هرکی
  آخر زنده موند برنده‌ست و کلِ پولِ میز رو می‌بره.

منطقِ تک‌تکِ مراحل (وضعیت‌ها، تایمرها، بازگشتِ پول) دقیقاً همون الگویِ اونو
هاپویی/کازینوِ کلاسیک رو داره: قفلِ per-round، تایمرِ درون‌حافظه‌ای + جاروبِ
دوره‌ایِ دیتابیس (برایِ وقتی که ربات وسطِ بازی ری‌استارت می‌شه).
"""
import asyncio
import datetime
import logging
import math
import random

from telegram import InlineKeyboardButton, InlineKeyboardMarkup, ReplyParameters
from telegram.ext import ApplicationHandlerStop

import casino
import db
from handlers import fmt, send_response, ask_for_input, is_reply_to_prompt, parse_amount

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# تنظیمات (اگه خواستی عوضشون کنی، فقط همین عددها)
# ---------------------------------------------------------------------------
GLOBAL_TIERS = (1_000_000, 100_000_000, 500_000_000)  # میزهای ثابتِ لابیِ جهانی
PLAYER_CHOICES = (2, 3, 4)
GROUP_LOBBY_SECONDS = 180      # مهلتِ پُرشدنِ لابی تو گپ
GLOBAL_WAIT_SECONDS = 360      # مهلتِ پیدا کردنِ حریف تو لابیِ جهانی (۶ دقیقه)
SETUP_ABANDON_SECONDS = 90     # اگه کسی مبلغ/تعداد رو نچینه و ول کنه، خودکار لغو می‌شه
LEGACY_CHAMBERS = 6            # فقط برایِ بازی‌هایِ نیمه‌کاره‌ی نسخه‌هایِ قبل (خشابِ ۶ خونه‌ایِ تک‌تیر)
ALLOW_SAME_SHOOTER_TWICE = False  # False: بعد از هر شلیک تپانچه شانسی می‌افته دستِ یکی از *بقیه‌ی* زنده‌ها (نوبت همیشه جابه‌جا می‌شه)
LOG_KEEP = 6                   # چندخطِ آخرِ اتفاق‌ها تو پنل
GLOBAL_JOIN_MIN_REMAINING = 15  # میزِ جهانی‌ای که کمتر از این‌قدر ثانیه به لغوش مونده، به آدمِ جدید داده نمی‌شه

ACTIVE_STATUSES = ("setup", "lobby", "playing")
_rng = random.SystemRandom()

# ---------------------------------------------------------------------------
# تنظیماتِ تپانچه (از پنلِ ادمین ← 🎰 تنظیماتِ کازینو هاپویی)
# ---------------------------------------------------------------------------
# (حداقل، حداکثر) - هم موقعِ ذخیره از پنل چک می‌شه (validate_cfg) هم موقعِ خوندن
# clamp می‌شه، تا مقدارِ اشتباه هیچ‌وقت بازی رو نشکنه.
RR_CFG_LIMITS = {
    "casino_rr_blank_bullets": (0, 20),
    "casino_rr_live_bullets": (1, 10),
    "casino_rr_spin_wait_seconds": (0, 600),
    "casino_rr_turn_seconds": (10, 3600),
}
_RR_CFG_DEFAULTS = {
    "casino_rr_blank_bullets": 5,
    "casino_rr_live_bullets": 1,
    "casino_rr_spin_wait_seconds": 40,
    "casino_rr_turn_seconds": 120,
}


def rr_settings(session):
    """{'blank','live','wait','turn'} - تنظیماتِ فعلیِ رولت (همیشه تو بازه‌ی مجاز)."""
    def get(key):
        lo, hi = RR_CFG_LIMITS[key]
        try:
            v = int(float(db.cfg_get(session, key)))
        except Exception:
            v = _RR_CFG_DEFAULTS[key]
        return max(lo, min(hi, v))
    return {"blank": get("casino_rr_blank_bullets"), "live": get("casino_rr_live_bullets"),
            "wait": get("casino_rr_spin_wait_seconds"), "turn": get("casino_rr_turn_seconds")}


def _settings_now():
    session = db.get_session()
    try:
        return rr_settings(session)
    finally:
        session.close()


def validate_cfg(key, text):
    """برایِ پنلِ ادمین: None یعنی مقدار معتبره، وگرنه متنِ خطا."""
    lim = RR_CFG_LIMITS.get(key)
    if not lim:
        return None
    try:
        v = float(text)
    except (TypeError, ValueError):
        return "❌ باید یه عدد بفرستی."
    if v != int(v):
        return "❌ باید یه عددِ صحیح بفرستی."
    if not (lim[0] <= int(v) <= lim[1]):
        return f"❌ این مقدار باید بینِ {lim[0]} تا {lim[1]} باشه."
    return None


# ---------------------------------------------------------------------------
# خشاب: رشته‌ای از B (مشقی) و L (جنگی)
# ---------------------------------------------------------------------------

def _new_layout(blank, live):
    cells = ["B"] * blank + ["L"] * live
    _rng.shuffle(cells)
    return "".join(cells)


def _layout(r):
    if r.chambers:
        return r.chambers
    # بازیِ نیمه‌کاره‌ی نسخه‌هایِ قبل: خشابِ ۶ خونه‌ای با یه تیر تو bullet_pos
    return "".join("L" if i == (r.bullet_pos or 0) else "B" for i in range(LEGACY_CHAMBERS))


def _cyl_counts(layout):
    live = layout.count("L")
    return len(layout) - live, live


def _reload_cylinder(session, r, cfg=None):
    cfg = cfg or rr_settings(session)
    r.chambers = _new_layout(cfg["blank"], cfg["live"])
    r.chamber_idx = 0


def _sync_cylinder(session, r, cfg):
    """اگه ادمین تعدادِ تیرها رو عوض کرده باشه، از نوبتِ بعدی اعمال می‌شه: خشابِ
    این بازی هم با ترکیبِ جدید دوباره پر و چرخونده می‌شه (محتوایِ خشاب مخفیه، پس
    هیچ‌کس با این کار امتیازی نمی‌گیره)."""
    if _cyl_counts(_layout(r)) != (cfg["blank"], cfg["live"]):
        _reload_cylinder(session, r, cfg)
        _log(r, f"🔧 تنظیماتِ خشاب عوض شد؛ خشاب با {cfg['blank']} مشقی و {cfg['live']} جنگی دوباره پر و چرخونده شد.")


def _turn_wait(r):
    """«انتظار برای چرخاندنِ خشابِ» همین نوبت (ثانیه) - همون مقداری که موقعِ شروعِ نوبت اعمال شده."""
    if r.turn_started_at and r.turn_ready_at:
        return max(0, int(round((r.turn_ready_at - r.turn_started_at).total_seconds())))
    return _settings_now()["wait"]


def _turn_len(r):
    """مهلتِ شلیکِ همین نوبت (ثانیه) - از بعدِ تمومِ انتظارِ چرخاندن."""
    if r.turn_ready_at and r.turn_deadline_at:
        return max(1, int(round((r.turn_deadline_at - r.turn_ready_at).total_seconds())))
    return _settings_now()["turn"]


def _is_ready(r, now=None):
    return (not r.turn_ready_at) or (now or _now()) >= r.turn_ready_at


def _start_turn(r, holder_uid, cfg, now):
    """شروعِ یه نوبت: اول «انتظار برای چرخاندنِ خشاب» (cfg['wait'] ثانیه، بدونِ امکانِ شلیک)
    و *بعدش* مهلتِ شلیک (cfg['turn'] ثانیه). ساعتِ حذف (deadline) فقط بعد از تمومِ
    انتظار شروع می‌شه، نه از لحظه‌ی رسیدنِ نوبت."""
    r.turn_user_id = holder_uid
    r.turn_seq = (r.turn_seq or 0) + 1
    r.turn_started_at = now
    r.turn_ready_at = now + datetime.timedelta(seconds=cfg["wait"])
    r.turn_deadline_at = r.turn_ready_at + datetime.timedelta(seconds=cfg["turn"])
    r.last_action_at = now


def _now():
    return datetime.datetime.utcnow()


# ---------------------------------------------------------------------------
# قفل‌ها و تایمرها
# ---------------------------------------------------------------------------
_round_locks = {}
_mm_lock = None  # قفلِ سراسریِ «پیدا کردنِ میزِ جهانی» - جلوی ساختنِ دو میزِ هم‌زمان برایِ دو نفرِ هم‌مبلغ رو می‌گیره


def _get_round_lock(round_id: int) -> asyncio.Lock:
    lock = _round_locks.get(round_id)
    if lock is None:
        lock = asyncio.Lock()
        _round_locks[round_id] = lock
    return lock


def _get_mm_lock() -> asyncio.Lock:
    global _mm_lock
    if _mm_lock is None:
        _mm_lock = asyncio.Lock()
    return _mm_lock


def with_round_lock(func):
    """مثلِ casino.with_round_lock: آی‌دیِ دور همیشه دومین بخشِ callback_data ـه."""
    async def wrapper(update, context):
        try:
            rid = int(update.callback_query.data.split(":")[1])
        except (ValueError, IndexError, AttributeError):
            await func(update, context)
            return
        async with _get_round_lock(rid):
            await func(update, context)
        session = db.get_session()
        try:
            r = session.get(db.RouletteRound, rid)
            if not r or r.status in ("resolved", "cancelled"):
                _round_locks.pop(rid, None)
        finally:
            session.close()
    return wrapper


_bg_tasks = set()


def _schedule(coro_fn, delay, *args):
    """تایمرِ درون‌حافظه‌ای (ری‌استارتِ ربات ازشون می‌گذره؛ اون‌وقت tick_roulette
    از رویِ deadline های ذخیره‌شده تو دیتابیس جمعشون می‌کنه)."""
    async def runner():
        try:
            await asyncio.sleep(delay)
            await coro_fn(*args)
        except asyncio.CancelledError:
            raise
        except Exception:
            logger.exception("خطا در تایمرِ رولت روسی")
    task = asyncio.create_task(runner())
    _bg_tasks.add(task)
    task.add_done_callback(_bg_tasks.discard)


# ---------------------------------------------------------------------------
# کمکی‌های دیتابیس
# ---------------------------------------------------------------------------

def _name(session, uid):
    u = session.get(db.User, uid)
    return u.display_name() if u else str(uid)


def _all_players(session, rid):
    return (session.query(db.RoulettePlayer)
            .filter_by(round_id=rid).order_by(db.RoulettePlayer.id).all())


def _alive_players(session, rid):
    return [p for p in _all_players(session, rid) if p.alive]


def _get_player(session, rid, uid):
    return session.query(db.RoulettePlayer).filter_by(round_id=rid, user_id=uid).first()


def _log(r, line):
    lines = [x for x in (r.log_text or "").split("\n") if x]
    lines.append(line)
    r.log_text = "\n".join(lines[-LOG_KEEP:])


def _lobby_limit(r):
    return GROUP_LOBBY_SECONDS if r.mode == "group" else GLOBAL_WAIT_SECONDS


def _expiry(r):
    """(زمانِ مرجع، حدِ مجاز به ثانیه) برایِ دورهایی که هنوز نباید بازی شده باشن؛ None برایِ بقیه."""
    if r.status == "setup":
        return (r.last_action_at or r.created_at, SETUP_ABANDON_SECONDS)
    if r.status == "lobby":
        return (r.lobby_opened_at or r.created_at, _lobby_limit(r))
    return None


def _is_expired(r, now, grace=0):
    e = _expiry(r)
    if not e or not e[0]:
        return False
    return (now - e[0]).total_seconds() >= e[1] + grace


def _targets(session, r):
    """[(chat_id, message_id, uid_or_None)] - پیام‌هایی که باید ادیت بشن.
    group: یه پیامِ مشترک. global: پنلِ خودِ هر بازیکن."""
    if r.mode == "group":
        return [(r.chat_id, r.message_id, None)] if r.message_id else []
    return [(p.chat_id, p.message_id, p.user_id) for p in _all_players(session, r.id) if p.message_id]


def _refund_all(session, r):
    if not r.entry_amount:
        return
    for p in _all_players(session, r.id):
        u = session.get(db.User, p.user_id)
        if u:
            u.hop_points = (u.hop_points or 0) + r.entry_amount


def _cancel_text(r, n, kind="timeout"):
    """متنِ نهاییِ پیامِ یه رولتِ لغوشده. اگه کسی به‌جز خودِ سازنده/اولین نفر نیومده:
    «هیچ هاپویی نیومد»."""
    if kind == "creator":
        return "❌ رولت توسطِ سازنده لغو شد؛ پولِ هرکسی که پرداخت کرده بود برگشت داده شد."
    if kind == "inactive":
        return "⏳ این رولت به‌خاطرِ عدمِ فعالیت لغو شد."
    if kind == "empty":
        return "❌ همه از لابی رفتن؛ لابی لغو شد."
    if n <= 1:
        when = f"{GLOBAL_WAIT_SECONDS // 60} دقیقه" if r.mode == "global" else f"{GROUP_LOBBY_SECONDS} ثانیه"
        return f"⏳ {when} گذشت و هیچ هاپویی نیومد؛ بازی لغو شد و پولت برگشت داده شد."
    if r.mode == "global":
        return (f"⏳ {GLOBAL_WAIT_SECONDS // 60} دقیقه گذشت و میزِ جهانی پر نشد ({n}/{r.target_players})؛ "
                "بازی لغو شد و پولت برگشت داده شد.")
    return (f"❌ به تعدادِ کافی بازیکن نپیوست ({n}/{r.target_players})؛ "
            "بازی لغو شد و مبلغ‌ها برگشت داده شد.")


def _cancel_db(session, r, text=None):
    """پول رو برمی‌گردونه و دور رو cancelled می‌کنه (بدونِ commit). فقط برایِ
    setup/lobby - وقتی بازی شروع شده هیچ‌وقت «لغو و ریفاند» نداریم (حذف/برنده داریم).
    text: پیامِ نهایی؛ تو log_text ذخیره می‌شه تا دکمه‌ی مرده‌ی یه پنلِ جا‌مونده هم
    بعداً با همین متن درست بشه. خروجی: targetهایِ پیام‌ها که باید ادیت بشن."""
    targets = _targets(session, r)
    if text is None:
        text = _cancel_text(r, len(_all_players(session, r.id)))
    _refund_all(session, r)
    r.log_text = text
    r.status = "cancelled"
    r.ended_at = _now()
    r.turn_user_id = None
    r.turn_deadline_at = None
    return targets


def _finish_db(session, r, winner_uid):
    """برنده رو تعیین و کلِ پات رو بهش می‌ده (بدونِ commit)."""
    players = _all_players(session, r.id)
    pot = (r.entry_amount or 0) * len(players)
    r.status = "resolved"
    r.ended_at = _now()
    r.winner_id = winner_uid
    r.turn_user_id = None
    r.turn_deadline_at = None
    if winner_uid:
        u = session.get(db.User, winner_uid)
        if u:
            u.hop_points = (u.hop_points or 0) + pot
        _log(r, f"🏆 {_name(session, winner_uid)} آخرین بازمانده بود و {fmt(pot)} 🪙 برد!")
    else:
        # (عملاً نباید پیش بیاد) اگه به هر دلیلی برنده‌ای نبود، پولِ هیچ‌کس نباید بسوزه
        _refund_all(session, r)
        _log(r, "🤝 بازی بدونِ برنده تموم شد؛ مبلغِ همه برگشت داده شد.")
    return pot


# ---------------------------------------------------------------------------
# آیا این کاربر وسطِ یه رولتِ فعاله؟ (+ پاک‌سازیِ لحظه‌ایِ دورهای منقضی)
# ---------------------------------------------------------------------------

_lazy_edits = []  # [(chat_id, message_id, text)] - پیام‌هایی که tick_roulette ادیتشون می‌کنه


def expire_stale_for_user(session, user_id):
    """اگه دورِ setup/lobby ـیِ این کاربر مهلتش گذشته ولی هنوز تایمر/جاروب
    نرسیده لغوش کنه، همین‌جا (همزمان و بدونِ await) لغوش می‌کنیم و پول رو
    برمی‌گردونیم - تا کسی تو فاصله‌ی چندثانیه‌ایِ «مهلت تموم شد» تا «تایمر لغوش
    کرد» با پیامِ «وسطِ کازینو هستی» گیر نکنه."""
    now = _now()
    mine = session.query(db.RoulettePlayer.round_id).filter(db.RoulettePlayer.user_id == user_id)
    rows = (session.query(db.RouletteRound)
            .filter(db.RouletteRound.status.in_(("setup", "lobby")),
                    (db.RouletteRound.initiator_id == user_id) | db.RouletteRound.id.in_(mine))
            .all())
    changed = False
    for r in rows:
        if r.status == "lobby" and len(_all_players(session, r.id)) >= (r.target_players or 99):
            continue  # پر شده و داره شروع می‌شه
        if _is_expired(r, now, grace=3):
            n = len(_all_players(session, r.id))
            text = _cancel_text(r, n, "inactive" if r.status == "setup" else "timeout")
            for chat_id, message_id, _uid in _cancel_db(session, r, text):
                _lazy_edits.append((chat_id, message_id, text))
            changed = True
    if changed:
        session.commit()


def user_has_active_roulette(session, user_id) -> bool:
    """setup/lobby: سازنده یا بازیکنِ دور. playing: فقط بازیکنِ *زنده* - کسی که
    حذف شده دیگه وسطِ کازینو حساب نمی‌شه و می‌تونه بازیِ دیگه‌ای شروع کنه
    (پنلش همچنان تماشاچیِ بازیِ جاری رو نشون می‌ده)."""
    expire_stale_for_user(session, user_id)
    mine = session.query(db.RoulettePlayer.round_id).filter(db.RoulettePlayer.user_id == user_id)
    row = (session.query(db.RouletteRound)
           .filter(db.RouletteRound.status.in_(("setup", "lobby")),
                   (db.RouletteRound.initiator_id == user_id) | db.RouletteRound.id.in_(mine))
           .first())
    if row:
        return True
    alive_mine = (session.query(db.RoulettePlayer.round_id)
                  .filter(db.RoulettePlayer.user_id == user_id, db.RoulettePlayer.alive == True))  # noqa: E712
    return bool(session.query(db.RouletteRound)
                .filter(db.RouletteRound.status == "playing", db.RouletteRound.id.in_(alive_mine))
                .first())


# ---------------------------------------------------------------------------
# ادیتِ پیام‌ها
# ---------------------------------------------------------------------------
_RESEND_ERRORS = ("message to edit not found", "message can't be edited", "message to be edited not found")
_PERMANENT_ERRORS = ("chat not found", "bot was blocked", "bot was kicked", "user is deactivated",
                     "forbidden", "have no rights", "chat_write_forbidden")


def _retry_after_seconds(exc):
    ra = getattr(exc, "retry_after", None)
    if ra is None:
        return None
    try:
        return float(ra.total_seconds()) if hasattr(ra, "total_seconds") else float(ra)
    except Exception:
        return 2.0


async def _safe_answer(q, *args, **kwargs):
    """جوابِ کالبک؛ خطای شبکه/تایم‌اوت (سرورِ شلوغ) کارِ هندلر رو نصفه نمی‌ذاره."""
    try:
        await q.answer(*args, **kwargs)
    except Exception as e:
        logger.warning("answerِ کالبک شکست خورد: %s", e)


async def _edit_msg_ex(context, chat_id, message_id, text, kb=None):
    """پیام رو مقاوم ادیت می‌کنه. خروجی: (آی‌دیِ پیامِ نهایی, موفق؟).
    موفق=False فقط برایِ خطاهایِ *موقتی* (فلودِ تلگرام/تایم‌اوت) که بعد از چند تلاش
    هم درست نشدن - _broadcast اون‌وقت یه همگام‌سازیِ دوباره زمان‌بندی می‌کنه.
    خطاهایِ دائمی (بات از گروه اخراج شده و ...) تلاشِ بی‌فایده نمی‌شن.
    فلود (RetryAfter) رو صبر می‌کنیم و دوباره می‌زنیم، نه اینکه رها کنیم (قبلاً همین،
    پنلِ بعضی بازیکن‌ها رو رویِ صفحه‌ی «عضوگیری» جا می‌ذاشت)."""
    if message_id:
        not_found = False
        for attempt in range(1, 5):
            try:
                await context.bot.edit_message_text(
                    chat_id=chat_id, message_id=message_id, text=text, reply_markup=kb)
                return message_id, True
            except Exception as e:
                err = str(e).lower()
                if "not modified" in err:
                    return message_id, True
                if any(x in err for x in _RESEND_ERRORS):
                    not_found = True
                    break
                if any(x in err for x in _PERMANENT_ERRORS):
                    logger.warning("ادیتِ پیامِ رولت (خطای دائمی): %s", e)
                    return message_id, True
                if attempt == 4:
                    logger.warning("ادیتِ پیامِ رولت بعد از چند تلاش شکست خورد: %s", e)
                    return message_id, False
                delay = _retry_after_seconds(e)
                await asyncio.sleep(min(delay, 20.0) + 0.5 if delay is not None else 0.6 * attempt)
        if not not_found:
            return message_id, False
    try:
        msg = await context.bot.send_message(chat_id=chat_id, text=text, reply_markup=kb)
        return msg.message_id, True
    except Exception as e:
        logger.warning("فرستادنِ پیامِ رولت شکست خورد: %s", e)
        return message_id, False


async def _edit_msg(context, chat_id, message_id, text, kb=None):
    new_id, _ok = await _edit_msg_ex(context, chat_id, message_id, text, kb)
    return new_id


_dirty = {}  # rid -> تعدادِ تلاش‌هایِ همگام‌سازی


async def _broadcast(context, session, r):
    """وضعیتِ فعلیِ دور رو رویِ همه‌ی پنل‌ها می‌ذاره (هر پنل با محتوایِ شخصیِ خودش).
    پنل‌ها هم‌زمان ادیت می‌شن (یه پنلِ کند بقیه رو عقب نمی‌ندازه) و اگه ادیتِ
    بعضی‌ها به‌خاطرِ خطایِ موقتی نشد، دوباره همگام‌سازی زمان‌بندی می‌شه - پس
    پنلِ «عضوگیری» رویِ صفحه‌ی بعضیا نمی‌مونه وقتی بازی برایِ بقیه شروع شده."""
    targets = _targets(session, r)
    views = [_view(session, r, uid) for _c, _m, uid in targets]
    results = await asyncio.gather(
        *[_edit_msg_ex(context, c, m, v[0], v[1]) for (c, m, _uid), v in zip(targets, views)],
        return_exceptions=True)
    changed = False
    failed = False
    for (chat_id, message_id, uid), res in zip(targets, results):
        if isinstance(res, Exception):
            logger.warning("ادیتِ پنلِ رولت: %s", res)
            failed = True
            continue
        new_id, ok = res
        if not ok:
            failed = True
        if new_id and new_id != message_id:
            changed = True
            if r.mode == "group":
                r.message_id = new_id
                for p in _all_players(session, r.id):
                    if p.message_id == message_id:
                        p.message_id = new_id
            else:
                p = _get_player(session, r.id, uid)
                if p:
                    p.message_id = new_id
    if changed:
        session.commit()
    if failed and _dirty.get(r.id, 0) < 6:
        _dirty[r.id] = _dirty.get(r.id, 0) + 1
        _schedule(_resync, 4 * _dirty[r.id], context, r.id)
    elif not failed:
        _dirty.pop(r.id, None)


async def _resync(context, rid):
    """پنل‌هایِ یه دور رو دوباره با وضعیتِ فعلی همگام می‌کنه (بعد از ادیتِ ناموفق)."""
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.RouletteRound, rid)
            if not r or r.status not in ("lobby", "playing", "resolved", "cancelled"):
                return
            await _broadcast(context, session, r)
        finally:
            session.close()


# «نوبتِ توئه» - ادیتِ پیام نوتیف نمی‌ده، پس برایِ کسی که نوبتشه یه پیامِ کوتاهِ
# ریپلای می‌فرستیم و تو نوبتِ بعد پاکش می‌کنیم.
_pings = {}


async def _clear_ping(context, rid):
    ref = _pings.pop(rid, None)
    if ref:
        try:
            await context.bot.delete_message(chat_id=ref[0], message_id=ref[1])
        except Exception:
            pass


def _ping_text(session, r):
    wait, turn = _turn_wait(r), _turn_len(r)
    who = _name(session, r.turn_user_id)
    if wait > 0:
        return (f"🔔 {who} نوبتِ توئه! خشاب تا {wait} ثانیه‌ی دیگه می‌چرخه؛ بعدش {turn} ثانیه وقت داری "
                "شلیک کنی (به خودت یا یکی دیگه)، وگرنه از بازی حذف می‌شی.")
    return (f"🔔 {who} نوبتِ توئه! {turn} ثانیه وقت داری "
            "شلیک کنی (به خودت یا یکی دیگه)، وگرنه از بازی حذف می‌شی.")


async def _send_ping(context, session, r):
    await _clear_ping(context, r.id)
    if not r.turn_user_id:
        return
    if r.mode == "group":
        chat_id, panel_id = r.chat_id, r.message_id
    else:
        p = _get_player(session, r.id, r.turn_user_id)
        if not p:
            return
        chat_id, panel_id = p.chat_id, p.message_id
    try:
        msg = await context.bot.send_message(
            chat_id=chat_id,
            text=_ping_text(session, r),
            reply_parameters=ReplyParameters(message_id=panel_id, allow_sending_without_reply=True),
        )
        _pings[r.id] = (chat_id, msg.message_id)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# نمایش‌ها (متن + دکمه)
# ---------------------------------------------------------------------------

def _view(session, r, for_uid=None):
    if r.status == "setup":
        return _setup_view(r)
    if r.status == "lobby":
        return _lobby_view(session, r, for_uid)
    if r.status == "playing":
        return _playing_view(session, r, for_uid)
    if r.status == "resolved":
        return _final_view(session, r, for_uid)
    return (r.log_text or "❌ این رولت لغو شد."), None


def _gun_text(cfg):
    """توضیحِ عمومیِ تپانچه (تعدادِ تیرها + زمان‌ها) که تو منو/لابی/پنل دیده می‌شه.
    همه از تنظیماتِ پنلِ ادمین می‌آد، پس هر تغییری همه‌جا اعمال می‌شه."""
    b, l = cfg["blank"], cfg["live"]
    line = f"🔫 تپانچه: {b} تیرِ مشقی + {l} تیرِ جنگی (مجموع {b + l} تیر)"
    if cfg["wait"] > 0:
        line += (f"\n⏳ اولِ هر نوبت {cfg['wait']} ثانیه انتظار برای چرخاندنِ خشابِ تفنگ "
                 f"(تو این مدت شلیک ممکن نیست)، بعدش {cfg['turn']} ثانیه وقتِ شلیک")
    else:
        line += f"\n⏳ هر نوبت {cfg['turn']} ثانیه وقتِ شلیک"
    return line


def _mode_menu_view(owner_id):
    cfg = _settings_now()
    text = ("🔫 رولت روسی\n\n"
            f"هر بار شانسی می‌افته دستِ یکی از بازیکن‌های زنده و باید شلیک کنه (به خودش یا یه حریف). "
            "هرکی آخر زنده بمونه کلِ پولِ میز رو می‌بره.\n\n"
            f"{_gun_text(cfg)}\n\n"
            "کجا بازی کنیم؟")
    kb = InlineKeyboardMarkup([
        [InlineKeyboardButton("🏠 لابی تو همین گپ", callback_data=f"rr_mode_group:{owner_id}")],
        [InlineKeyboardButton("🌍 پیدا کردن لابی جهانی", callback_data=f"rr_mode_global:{owner_id}")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data=f"rr_menu:{owner_id}")],
    ])
    return text, kb


def _tier_menu_view(session, owner_id, in_group):
    tiers = [a for a in GLOBAL_TIERS if not casino.max_bet_exceeded(session, a)]
    if not tiers:
        text = "🌍 لابیِ جهانی\n\n⛔️ الان هیچ میزی با سقفِ مجازِ قمار جور نیست."
    else:
        text = ("🌍 لابیِ جهانی\n\nیکی از میزها رو انتخاب کن. هر بازیکنی (از هر گپی) که همین میز و "
                "همین تعدادِ نفر رو انتخاب کنه با تو می‌افته.")
    rows = [[InlineKeyboardButton(f"🪙 {fmt(a)}", callback_data=f"rr_gtier:{owner_id}:{a}")] for a in tiers]
    back = f"rr_mode_menu:{owner_id}" if in_group else f"rr_menu:{owner_id}"
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=back)])
    return text, InlineKeyboardMarkup(rows)


def _count_menu_view(owner_id, amount):
    text = (f"🌍 میزِ {fmt(amount)} 🪙\n\nچند نفره بازی کنیم؟ (هرکی همین مبلغ و همین تعداد رو "
            "انتخاب کنه با تو می‌افته)")
    rows = [[InlineKeyboardButton(f"👥 {n} نفره", callback_data=f"rr_gjoin:{owner_id}:{amount}:{n}") for n in PLAYER_CHOICES]]
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"rr_mode_global:{owner_id}")])
    return text, InlineKeyboardMarkup(rows)


def _setup_view(r):
    amount_txt = fmt(r.entry_amount) + " 🪙" if r.entry_amount else "— تنظیم نشده —"
    players_txt = str(r.target_players) if r.target_players else "— تنظیم نشده —"
    text = ("🔫 رولت روسی — لابی تو همین گپ\n\n"
            f"💰 مبلغ ورودی: {amount_txt}\n"
            f"👥 تعداد بازیکن: {players_txt}\n\n"
            f"{_gun_text(_settings_now())}")
    rows = [[InlineKeyboardButton("💰 انتخاب مبلغ ورودی", callback_data=f"rr_amt_menu:{r.id}")],
            [InlineKeyboardButton("👥 انتخاب تعداد بازیکن", callback_data=f"rr_plr_menu:{r.id}")]]
    if r.entry_amount and r.target_players:
        rows.append([InlineKeyboardButton("▶️ شروع بازی", callback_data=f"rr_start:{r.id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"rr_back:{r.id}"),
                 InlineKeyboardButton("❌ لغو", callback_data=f"rr_cancel:{r.id}")])
    return text, InlineKeyboardMarkup(rows)


def _lobby_view(session, r, for_uid=None):
    players = _all_players(session, r.id)
    names = "\n".join(f"• {_name(session, p.user_id)}" for p in players) or "هنوز کسی نیست..."
    pot = (r.entry_amount or 0) * (r.target_players or 0)
    if r.mode == "group":
        text = (f"🔫 رولت روسی — در انتظار بازیکن‌ها ({len(players)}/{r.target_players})\n"
                f"💰 مبلغ ورودی هرنفر: {fmt(r.entry_amount)} 🪙 — 🏆 جایزه‌ی کل: {fmt(pot)} 🪙\n"
                f"{_gun_text(rr_settings(session))}\n\n"
                f"{names}\n\n"
                f"⏳ اگه تا {GROUP_LOBBY_SECONDS} ثانیه پر نشه، بازی لغو و پولِ همه برگشت داده می‌شه.")
        rows = [[InlineKeyboardButton("🎮 پیوستن به بازی", callback_data=f"rr_join:{r.id}")],
                [InlineKeyboardButton("❌ لغو (فقط سازنده)", callback_data=f"rr_cancel:{r.id}")]]
        if r.target_players and r.target_players >= 3:
            rows.append([InlineKeyboardButton("🚪 ترک بازی", callback_data=f"rr_leave:{r.id}")])
        return text, InlineKeyboardMarkup(rows)
    mins = GLOBAL_WAIT_SECONDS // 60
    text = (f"🔫 رولت روسی — 🌍 لابیِ جهانی ({len(players)}/{r.target_players})\n"
            f"💰 ورودی: {fmt(r.entry_amount)} 🪙 — 🏆 جایزه‌ی کل: {fmt(pot)} 🪙\n"
            f"{_gun_text(rr_settings(session))}\n\n"
            f"{names}\n\n"
            f"🔎 در حالِ پیدا کردنِ حریف... هرکی همین میز رو انتخاب کنه با شما می‌افته.\n"
            f"⏳ اگه تا {mins} دقیقه پر نشه خودکار لغو می‌شه و پولت برمی‌گرده.")
    rows = []
    if for_uid:
        rows.append([InlineKeyboardButton("🚪 منصرف شدم", callback_data=f"rr_gleave:{r.id}:{for_uid}")])
    return text, InlineKeyboardMarkup(rows) if rows else None


def _players_lines(session, r, players, holder_uid=None):
    lines = []
    for p in players:
        n = _name(session, p.user_id)
        if not p.alive:
            lines.append(f"☠️ {n} — {p.out_reason or 'حذف شد'}")
        elif p.user_id == holder_uid:
            lines.append(f"🔫 {n}  ← تپانچه دستِ اینه")
        else:
            lines.append(f"🟢 {n}")
    return lines


def _playing_view(session, r, for_uid=None):
    players = _all_players(session, r.id)
    pot = (r.entry_amount or 0) * len(players)
    head = "🔫 رولت روسی" + (" — 🌍 جهانی" if r.mode == "global" else "")
    layout = _layout(r)
    blank, live = _cyl_counts(layout)
    total = len(layout)
    idx = min(r.chamber_idx or 0, max(0, total - 1))
    wait = _turn_wait(r)
    turn = _turn_len(r)
    ready = _is_ready(r)
    lines = [head]
    if wait > 0:
        lines.append(f"⏳ {wait} ثانیه انتظار برای چرخاندنِ خشابِ تفنگ")
    lines += [f"💰 ورودی هرنفر: {fmt(r.entry_amount)} 🪙 — 🏆 جایزه‌ی کل: {fmt(pot)} 🪙", ""]
    lines += _players_lines(session, r, players, r.turn_user_id)
    lines += ["",
              f"🔘 خشاب: {blank} مشقی + {live} جنگی (مجموع {total} تیر) — {idx} خونه شلیک شده؛ "
              f"شانسِ تیرِ جنگیِ بعدی: {live} از {total - idx}"]
    if r.log_text:
        lines += ["", "📜 آخرین اتفاق‌ها:", r.log_text]
    holder = _name(session, r.turn_user_id) if r.turn_user_id else "—"
    lines.append("")
    mine = for_uid is not None and for_uid == r.turn_user_id
    if mine:
        lines.append("👉 نوبتِ توئه!")
    else:
        lines.append(f"👉 نوبتِ {holder} ـه؛ فقط خودش می‌تونه شلیک کنه.")
    if wait > 0:
        if ready:
            lines.append("✅ خشاب چرخید؛ شلیک آزاده.")
        else:
            lines.append(f"🔄 خشاب در حالِ چرخیدنه؛ تا {wait} ثانیه بعد از شروعِ نوبت شلیک ممکن نیست.")
    if for_uid is None or mine:
        lines += ["🔫 شلیک به خودت: تیرِ جنگی = می‌میری | مشقی = زنده می‌مونی",
                  "🎯 شلیک به دیگری: تیرِ جنگی = اون می‌میره | مشقی = خودت حذف می‌شی"]
    lines.append(f"⏳ بعد از چرخیدنِ خشاب {turn} ثانیه وقت داره؛ شلیک نکنه از بازی حذف می‌شه.")
    names = {p.user_id: _name(session, p.user_id) for p in players}
    return "\n".join(lines), _turn_keyboard(r, players, names, holder, for_uid)


def _turn_keyboard(r, players, names, holder_name, for_uid):
    """دکمه‌هایِ شلیک. تو لابیِ جهانی (پنلِ شخصی) فقط کسی که نوبتشه دکمه می‌بینه؛ تو
    پنلِ مشترکِ گروه همه می‌بینن ولی سرور فقط از نوبت‌دار می‌پذیره."""
    if for_uid is not None and for_uid != r.turn_user_id:
        return InlineKeyboardMarkup([[InlineKeyboardButton(f"⏳ نوبتِ {holder_name}", callback_data="rr_noop")]])
    seq = r.turn_seq or 0
    self_label = "🔫 شلیک به خودم" if for_uid is not None else f"🔫 شلیک به خودش ({holder_name})"
    rows = [[InlineKeyboardButton(self_label, callback_data=f"rr_fire:{r.id}:{seq}")]]
    for p in players:
        if p.alive and p.user_id != r.turn_user_id:
            rows.append([InlineKeyboardButton(
                f"🎯 شلیک به {names.get(p.user_id, p.user_id)}", callback_data=f"rr_shoot:{r.id}:{seq}:{p.user_id}")])
    return InlineKeyboardMarkup(rows)


def _final_view(session, r, for_uid=None):
    players = _all_players(session, r.id)
    pot = (r.entry_amount or 0) * len(players)
    lines = ["🔫 رولت روسی — پایان بازی", f"💰 جایزه‌ی کل: {fmt(pot)} 🪙", ""]
    for p in players:
        n = _name(session, p.user_id)
        lines.append(f"🏆 {n} — برنده" if p.user_id == r.winner_id
                     else f"☠️ {n} — {p.out_reason or 'حذف شد'}")
    if r.log_text:
        lines += ["", "📜 آخرین اتفاق‌ها:", r.log_text]
    if for_uid is not None and r.mode == "global":
        lines.append("")
        lines.append(f"🎉 تبریک! تو برنده شدی و {fmt(pot)} 🪙 گرفتی." if for_uid == r.winner_id
                     else "💔 این دفعه نشد؛ ورودیت سوخت.")
    return "\n".join(lines), None


# ---------------------------------------------------------------------------
# لیستِ لابی‌هایِ جهانیِ بازِ در حالِ عضوگیری (بالایِ منویِ کازینو)
# ---------------------------------------------------------------------------
GLOBAL_LIST_LIMIT = 10


def global_lobbies(session, limit=GLOBAL_LIST_LIMIT):
    """لابی‌هایِ جهانیِ بازی که هنوز جا دارن و می‌شه بهشون پیوست. پرهایی که بازیشون
    شروع شده (status عوض شده) و اونایی که دارن منقضی می‌شن خودبه‌خود نیستن.
    ترتیب: هرچی بازیکنِ بیشتری تو خودش داره (۳/۴ بالایِ ۱/۴) و بینِ هم‌تعدادها هرکدوم که
    زودتر شروع به عضوگیری کرده؛ مبلغ تو ترتیب نقشی نداره. حداکثر limit تا."""
    now = _now()
    rows = (session.query(db.RouletteRound)
            .filter(db.RouletteRound.mode == "global", db.RouletteRound.status == "lobby").all())
    out = []
    for r in rows:
        ref = r.lobby_opened_at or r.created_at or now
        if (now - ref).total_seconds() > GLOBAL_WAIT_SECONDS - GLOBAL_JOIN_MIN_REMAINING:
            continue
        cnt = len(_all_players(session, r.id))
        if cnt <= 0 or cnt >= (r.target_players or 0):
            continue
        out.append((cnt, ref, r.id, r.entry_amount, r.target_players))
    out.sort(key=lambda x: (-x[0], x[1], x[2]))
    return out[:limit]


def global_lobbies_text(session):
    rows = global_lobbies(session)
    head = "🌍 لابی‌های جهانیِ رولت روسی که در حالِ عضوگیری‌ان:"
    if not rows:
        return (f"{head}\nفعلاً هیچ لابی‌ای باز نیست؛ «🔫 رولت روسی ← 🌍 لابی جهانی» رو بزن و "
                "اولین لابی رو خودت باز کن.")
    lines = [head]
    for i, (cnt, _ref, _rid, amount, target) in enumerate(rows, 1):
        lines.append(f"{i}. 🔫 {target} نفره — {fmt(amount)} 🪙 — {cnt}/{target}")
    lines.append("(لابی‌ای که پر بشه و بازیش شروع بشه از این لیست حذف می‌شه.)")
    return "\n".join(lines)


# ---------------------------------------------------------------------------
# منوی کازینو → رولت
# ---------------------------------------------------------------------------

def _is_private(update):
    chat = update.effective_chat
    return bool(chat and chat.type == "private")


async def _check_owner(update, owner_id):
    if update.effective_user.id != owner_id:
        await _safe_answer(update.callback_query, 
            "⛔️ این منو مالِ تو نیست! برای بازکردنِ کازینوی خودت، بنویس «کازینو هاپویی».",
            show_alert=True)
        return False
    return True


async def _check_initiator(update, r):
    if not r or update.effective_user.id != r.initiator_id:
        await _safe_answer(update.callback_query, 
            "⛔️ این بازی مال تو نیست! برای ساختنِ بازی خودت بنویس «کازینو هاپویی».", show_alert=True)
        return False
    return True


BUSY_MSG = "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن."


async def cb_rr_new(update, context):
    """دکمه‌ی «🔫 رولت روسی» تو منوی کازینو."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, owner_id):
            await _safe_answer(update.callback_query, BUSY_MSG, show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, owner_id)
        if remaining > 0:
            await _safe_answer(update.callback_query, 
                f"⏳ خودت تازه یه کازینو تموم کردی. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        if _is_private(update):
            text, kb = _tier_menu_view(session, owner_id, in_group=False)
        else:
            text, kb = _mode_menu_view(owner_id)
        await send_response(update, text, kb)
    finally:
        session.close()


async def cb_rr_menu(update, context):
    """برگشت به منوی اصلیِ کازینو."""
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    text, kb = casino.menu_text_and_kb(owner_id)
    await send_response(update, text, kb)


async def cb_rr_mode_menu(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    text, kb = _mode_menu_view(owner_id)
    await send_response(update, text, kb)


async def cb_rr_mode_global(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        text, kb = _tier_menu_view(session, owner_id, in_group=not _is_private(update))
    finally:
        session.close()
    await send_response(update, text, kb)


async def cb_rr_gtier(update, context):
    _, owner_id, amount = update.callback_query.data.split(":")
    owner_id, amount = int(owner_id), int(amount)
    if not await _check_owner(update, owner_id):
        return
    if amount not in GLOBAL_TIERS:
        await _safe_answer(update.callback_query, "❌ این میز معتبر نیست.", show_alert=True)
        return
    text, kb = _count_menu_view(owner_id, amount)
    await send_response(update, text, kb)


# ---------------------------------------------------------------------------
# لابیِ جهانی
# ---------------------------------------------------------------------------

def _global_join_db(session, tg_user, chat_id, message_id, amount, n):
    """(بدونِ await - اتمیک نسبت به بقیه‌ی هندلرها) پولِ ورودی رو کم می‌کنه و
    کاربر رو به یه میزِ منتظرِ هم‌مبلغ/هم‌تعداد وصل می‌کنه (یا میزِ جدید می‌سازه).
    خروجی: (پیامِ خطا یا None, آی‌دیِ دور, میزِ جدید ساخته شد؟)"""
    uid = tg_user.id
    if casino._user_has_active_round(session, uid):
        return BUSY_MSG, None, False
    if casino.max_bet_exceeded(session, amount):
        return f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست.", None, False
    user = db.get_or_create_user(session, tg_user)
    if (user.hop_points or 0) < amount - 0.5:
        return f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", None, False

    now = _now()
    table = None
    candidates = (session.query(db.RouletteRound)
                  .filter(db.RouletteRound.mode == "global", db.RouletteRound.status == "lobby",
                          db.RouletteRound.entry_amount == amount, db.RouletteRound.target_players == n)
                  .order_by(db.RouletteRound.created_at).all())
    for c in candidates:
        ref = c.lobby_opened_at or c.created_at
        if (now - ref).total_seconds() > GLOBAL_WAIT_SECONDS - GLOBAL_JOIN_MIN_REMAINING:
            continue  # داره لغو می‌شه؛ به آدمِ جدید نمی‌دیمش
        if len(_all_players(session, c.id)) >= n:
            continue  # پره و داره شروع می‌شه
        table = c
        break
    is_new = table is None
    if is_new:
        table = db.RouletteRound(mode="global", chat_id=chat_id, message_id=message_id, initiator_id=None,
                                 entry_amount=amount, target_players=n, status="lobby",
                                 lobby_opened_at=now, last_action_at=now)
        session.add(table)
        session.flush()
    user.hop_points -= amount
    session.add(db.RoulettePlayer(round_id=table.id, user_id=uid, chat_id=chat_id, message_id=message_id))
    table.last_action_at = now
    session.commit()
    return None, table.id, is_new


async def cb_rr_gjoin(update, context):
    q = update.callback_query
    _, owner_id, amount, n = q.data.split(":")
    owner_id, amount, n = int(owner_id), int(amount), int(n)
    if not await _check_owner(update, owner_id):
        return
    if amount not in GLOBAL_TIERS or n not in PLAYER_CHOICES:
        await _safe_answer(q, "❌ انتخاب معتبر نیست.", show_alert=True)
        return
    uid = update.effective_user.id
    session = db.get_session()
    try:
        remaining = await casino._casino_cooldown_remaining_seconds(session, uid)
    finally:
        session.close()
    if remaining > 0:
        await _safe_answer(q, f"⏳ خودت تازه یه کازینو تموم کردی. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                       show_alert=True)
        return

    async with _get_mm_lock():
        session = db.get_session()
        try:
            err, rid, is_new = _global_join_db(
                session, update.effective_user, update.effective_chat.id, q.message.message_id, amount, n)
        finally:
            session.close()
    if err:
        await _safe_answer(q, err, show_alert=True)
        return
    if is_new:
        # اول تایمرِ لغو، بعد هر کارِ تلگرامی: میزِ جهانی هیچ‌وقت بدونِ تایمر نمی‌مونه
        _schedule(_lobby_timeout, GLOBAL_WAIT_SECONDS + 1, context, rid)
    await _safe_answer(q, "✅ تو صفِ لابیِ جهانی هستی!")
    await _after_join(context, rid)


async def _after_join(context, rid):
    """بعد از هر پیوستن: اگه میز پر شد بازی شروع می‌شه، وگرنه پنلِ همه به‌روز می‌شه."""
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.RouletteRound, rid)
            if not r or r.status != "lobby":
                return
            if len(_all_players(session, rid)) >= (r.target_players or 99):
                await _begin_game(context, session, r)
            else:
                await _broadcast(context, session, r)
        finally:
            session.close()


@with_round_lock
async def cb_rr_gleave(update, context):
    """«🚪 منصرف شدم» تو لابیِ جهانی - فقط برای صاحبِ همون پنل (uid تو callback_data)."""
    q = update.callback_query
    _, rid, owner_id = q.data.split(":")
    rid, owner_id = int(rid), int(owner_id)
    if update.effective_user.id != owner_id:
        await _safe_answer(q, "⛔️ این دکمه مالِ تو نیست.", show_alert=True)
        return
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not r or r.mode != "global" or r.status != "lobby":
            await _safe_answer(q, "⛔️ این لابی دیگه فعال نیست.", show_alert=True)
            return
        p = _get_player(session, rid, owner_id)
        if not p:
            await _safe_answer(q, "⛔️ تو تو این لابی نیستی.", show_alert=True)
            return
        my_chat, my_msg = p.chat_id, p.message_id
        u = session.get(db.User, owner_id)
        if u and r.entry_amount:
            u.hop_points = (u.hop_points or 0) + r.entry_amount
        session.delete(p)
        session.flush()
        others = len(_all_players(session, rid))
        if others == 0:
            r.status = "cancelled"
            r.log_text = _cancel_text(r, 0, "empty")
            r.ended_at = _now()
        r.last_action_at = _now()
        session.commit()

        await _safe_answer(q, "🚪 منصرف شدی؛ پولت برگشت داده شد.")
        await _edit_msg(context, my_chat, my_msg,
                        "🚪 از لابیِ جهانی خارج شدی؛ پولت برگشت داده شد.",
                        InlineKeyboardMarkup([[InlineKeyboardButton("🎰 بازگشت به کازینو", callback_data=f"rr_menu:{owner_id}")]]))
        if others:
            await _broadcast(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# لابی تو گپ (ساختِ بازی توسطِ سازنده)
# ---------------------------------------------------------------------------

async def cb_rr_mode_group(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _check_owner(update, owner_id):
        return
    if _is_private(update):
        await _safe_answer(update.callback_query, "⛔️ لابیِ گروهی فقط تو گروه ممکنه؛ تو پیوی از لابیِ جهانی استفاده کن.",
                                           show_alert=True)
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, owner_id):
            await _safe_answer(update.callback_query, BUSY_MSG, show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, owner_id)
        if remaining > 0:
            await _safe_answer(update.callback_query, 
                f"⏳ خودت تازه یه کازینو تموم کردی. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        r = db.RouletteRound(mode="group", chat_id=update.effective_chat.id,
                             message_id=update.callback_query.message.message_id,
                             initiator_id=owner_id, status="setup")
        session.add(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


def _touch(r):
    r.last_action_at = _now()


@with_round_lock
async def cb_rr_setup(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_rr_amt_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
        amounts = casino._preset_amounts(session)
        rows = []
        for i in range(0, len(amounts), 2):
            rows.append([InlineKeyboardButton(f"🪙 {fmt(a)}", callback_data=f"rr_amt_pick:{rid}:{a}")
                         for a in amounts[i:i + 2]])
        rows.append([InlineKeyboardButton("✏️ مبلغ دلخواه", callback_data=f"rr_amt_custom:{rid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"rr_setup:{rid}")])
    finally:
        session.close()
    await send_response(update, "💰 مبلغ ورودی رو انتخاب کن:", InlineKeyboardMarkup(rows))


@with_round_lock
async def cb_rr_amt_pick(update, context):
    _, rid, amount = update.callback_query.data.split(":")
    rid, amount = int(rid), float(amount)
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        if casino.max_bet_exceeded(session, amount):
            await _safe_answer(update.callback_query, 
                f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست.", show_alert=True)
            return
        r.entry_amount = amount
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_rr_amt_custom(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
    finally:
        session.close()
    # دکمه‌ی «کنسل» زیرِ پرامپت به‌جایِ کشتنِ کلِ پنل، فقط برمی‌گرده به صفحه‌ی تنظیمات
    await ask_for_input(update, context,
                        "✏️ مبلغ ورودی دلخواه رو به عدد بفرست (مثلاً 5m یا 2b):",
                        {"type": "amount", "round_id": rid}, "rr_awaiting",
                        cancel_callback=f"rr_amtx:{rid}")


@with_round_lock
async def cb_rr_amtx(update, context):
    """«بازگشت / کنسل» زیرِ پرامپتِ مبلغِ دلخواه: منتظرِ ورودی بودن رو پاک می‌کنه و
    برمی‌گرده به پنلِ تنظیمات (دورِ بازی سرِ جاشه)."""
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not await _check_initiator(update, r):
            return
        context.user_data.pop("rr_awaiting", None)
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_rr_plr_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _touch(r)
        session.commit()
    finally:
        session.close()
    rows = [[InlineKeyboardButton(f"{n} نفره", callback_data=f"rr_plr_pick:{rid}:{n}") for n in PLAYER_CHOICES],
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f"rr_setup:{rid}")]]
    await send_response(update, "👥 تعداد بازیکن رو انتخاب کن:", InlineKeyboardMarkup(rows))


@with_round_lock
async def cb_rr_plr_pick(update, context):
    _, rid, n = update.callback_query.data.split(":")
    rid, n = int(rid), int(n)
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup" or n not in PLAYER_CHOICES:
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        r.target_players = n
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_rr_back(update, context):
    """«🔙 بازگشت» رو صفحه‌ی تنظیمات: دورِ setup بسته می‌شه (پولی کم نشده) و برمی‌گرده
    به انتخابِ «گپ یا جهانی»."""
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        r.status = "cancelled"
        r.ended_at = _now()
        session.commit()
        text, kb = _mode_menu_view(r.initiator_id)
    finally:
        session.close()
    await send_response(update, text, kb)


@with_round_lock
async def cb_rr_cancel(update, context):
    """لغوِ بازی توسطِ سازنده - هم تو setup هم تو lobby. تو lobby پولِ همه برمی‌گرده."""
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not r:
            await _safe_answer(update.callback_query, "⛔️ این بازی پیدا نشد.", show_alert=True)
            return
        if update.effective_user.id != r.initiator_id:
            await _safe_answer(update.callback_query, 
                "⛔️ فقط سازنده‌ی بازی می‌تونه لغوش کنه! اگه عضوی و می‌خوای بری، از «🚪 ترک بازی» استفاده کن (اگه موجود باشه).",
                show_alert=True)
            return
        if r.status not in ("setup", "lobby"):
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه قابلِ لغو نیست.", show_alert=True)
            return
        cancel_msg = _cancel_text(r, 0, "creator")
        _cancel_db(session, r, cancel_msg)
        session.commit()
    finally:
        session.close()
    await send_response(update, cancel_msg, None)


@with_round_lock
async def cb_rr_start(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.mode != "group" or r.status != "setup":
            await _safe_answer(update.callback_query, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if not r.entry_amount or not r.target_players:
            await _safe_answer(update.callback_query, "اول مبلغ و تعدادِ بازیکن رو مشخص کن.", show_alert=True)
            return
        if casino.max_bet_exceeded(session, r.entry_amount):
            await _safe_answer(update.callback_query, 
                f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if (user.hop_points or 0) < r.entry_amount - 0.5:
            await _safe_answer(update.callback_query, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.RoulettePlayer(round_id=r.id, user_id=user.telegram_id,
                                      chat_id=r.chat_id, message_id=r.message_id))
        r.status = "lobby"
        r.lobby_opened_at = _now()
        _touch(r)
        session.commit()
        text, kb = _lobby_view(session, r)
    finally:
        session.close()
    _schedule(_lobby_timeout, GROUP_LOBBY_SECONDS + 1, context, rid)  # اول تایمر، بعد پیام
    await send_response(update, text, kb)


@with_round_lock
async def cb_rr_join(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    uid = update.effective_user.id
    q = update.callback_query
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not r or r.mode != "group" or r.status != "lobby":
            await _safe_answer(q, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if _get_player(session, rid, uid):
            await _safe_answer(q, "قبلا پیوستی ✅", show_alert=True)
            return
        if casino._user_has_active_round(session, uid):
            await _safe_answer(q, BUSY_MSG, show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, uid)
        if remaining > 0:
            await _safe_answer(q, f"⏳ خودت تازه یه کازینو تموم کردی. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                           show_alert=True)
            return
        if _is_expired(r, _now()):
            await _safe_answer(q, "⏳ مهلتِ این لابی تموم شده و داره لغو می‌شه.", show_alert=True)
            return
        count = len(_all_players(session, rid))
        if count >= r.target_players:
            await _safe_answer(q, "ظرفیت این بازی تکمیله.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if (user.hop_points or 0) < r.entry_amount - 0.5:
            await _safe_answer(q, f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.RoulettePlayer(round_id=rid, user_id=uid, chat_id=r.chat_id, message_id=r.message_id))
        _touch(r)
        session.commit()
        full = (count + 1) >= r.target_players
        await _safe_answer(q, "✅ پیوستی!")
        if full:
            await _begin_game(context, session, r)
        else:
            await _broadcast(context, session, r)
    finally:
        session.close()


@with_round_lock
async def cb_rr_leave(update, context):
    """«🚪 ترک بازی» - فقط تو لابیِ گروهیِ ۳/۴ نفره، برای بازیکنی که سازنده نیست."""
    rid = int(update.callback_query.data.split(":")[1])
    uid = update.effective_user.id
    q = update.callback_query
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not r or r.mode != "group" or r.status != "lobby":
            await _safe_answer(q, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if uid == r.initiator_id:
            await _safe_answer(q, "⛔️ تو سازنده‌ی این بازی‌ای! اگه می‌خوای بیخیالش بشی، رو «❌ لغو» بزن (پولِ همه برمی‌گرده).",
                           show_alert=True)
            return
        p = _get_player(session, rid, uid)
        if not p:
            await _safe_answer(q, "⛔️ تو عضوِ این بازی نیستی.", show_alert=True)
            return
        u = session.get(db.User, uid)
        if u and r.entry_amount:
            u.hop_points = (u.hop_points or 0) + r.entry_amount
        session.delete(p)
        _touch(r)
        session.commit()
        await _safe_answer(q, "🚪 از بازی خارج شدی؛ پولت برگشت داده شد.")
        await _broadcast(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# متنِ منتظرِ مبلغِ دلخواه (فقط لابیِ گروهی)
# ---------------------------------------------------------------------------

async def rr_awaiting_handler(update, context):
    state = context.user_data.get("rr_awaiting")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return
    # پیامی که تو یه گپِ دیگه (غیر از گپِ همین پرامپت) نوشته شده، جوابِ این سوال نیست
    prompt_chat = state.get("_prompt_chat_id")
    if prompt_chat is not None and update.effective_chat.id != prompt_chat:
        return
    uid = update.effective_user.id
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, state["round_id"])
        context.user_data.pop("rr_awaiting", None)
        if not r or r.status != "setup" or r.initiator_id != uid:
            # دورِ بازی دیگه تو مرحله‌ی تنظیمات نیست (مثلاً به‌خاطرِ عدمِ فعالیت لغو شده) - پیامِ
            # کاربر یه حرفِ معمولیِ گروه حساب می‌شه، نه یه جوابِ اشتباه؛ ساکت رد می‌شیم.
            return
        parsed = parse_amount((update.message.text or "").strip())
        err = None
        if parsed is None or parsed != int(parsed) or parsed <= 0:
            err = "❌ مقدار اشتباه است (باید یه عددِ صحیحِ بزرگ‌تر از صفر باشه)."
        elif casino.max_bet_exceeded(session, parsed):
            err = f"❌ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست."
        else:
            r.entry_amount = int(parsed)
        _touch(r)
        session.commit()
        text, kb = _setup_view(r)
        if err:
            text = f"{err}\n\n{text}"
        # پنل (که دکمه‌هاش موقعِ ریپلای پاک شده بود) همیشه سرِ جاش برمی‌گرده؛ حتی اگه مبلغ اشتباه بود
        new_id = await _edit_msg(context, r.chat_id, r.message_id, text, kb)
        if new_id and new_id != r.message_id:
            r.message_id = new_id
            session.commit()
    finally:
        session.close()
    raise ApplicationHandlerStop


# ---------------------------------------------------------------------------
# شروعِ بازی
# ---------------------------------------------------------------------------

async def _begin_game(context, session, r):
    """(زیرِ قفلِ دور صدا زده بشه) خشاب رو پر می‌کنه و تپانچه رو شانسی می‌ده دستِ یکی."""
    session.refresh(r)
    if r.status != "lobby":
        return  # وسطِ راه لغو/تموم شده (مثلاً تایم‌اوت) - هیچ‌وقت بازیِ لغوشده رو زنده نمی‌کنیم
    players = _all_players(session, r.id)
    if len(players) < 2:
        return
    for p in players:
        p.alive = True
        p.out_reason = None
    now = _now()
    cfg = rr_settings(session)
    r.status = "playing"
    _reload_cylinder(session, r, cfg)
    holder = _rng.choice(players)
    r.turn_seq = 0
    _start_turn(r, holder.user_id, cfg, now)
    r.log_text = ""
    _log(r, f"🔫 خشاب با {cfg['blank']} مشقی و {cfg['live']} جنگی پر شد و چرخید.")
    _log(r, f"🎲 تپانچه افتاد دستِ {_name(session, holder.user_id)}.")
    session.commit()
    await _broadcast(context, session, r)
    await _send_ping(context, session, r)
    _schedule_turn_timers(context, r, cfg)


async def _advance_turn(context, session, r, prev_uid):
    """تپانچه شانسی می‌افته دستِ یکی از *بقیه‌ی* بازیکن‌هایِ زنده (نه همونی که همین الان شلیک
    کرد) - تا نوبت واقعاً جابه‌جا بشه؛ با انتظارِ چرخاندنِ خشاب، اینکه یه نفر پشتِ‌هم چند
    بار نوبت بگیره و هربار ۴۰ ثانیه منتظر بمونه اصلاً قابلِ‌تحمل نیست. تو بازیِ دونفره
    نوبت دقیقاً یکی‌درمیون می‌شه؛ تو ۳/۴ نفره بینِ بقیه شانسیه."""
    alive = _alive_players(session, r.id)
    if not alive:
        return
    pool = alive
    if not ALLOW_SAME_SHOOTER_TWICE and len(alive) > 1:
        pool = [p for p in alive if p.user_id != prev_uid] or alive
    nxt = _rng.choice(pool)
    now = _now()
    cfg = rr_settings(session)   # تغییراتِ پنلِ ادمین از همین نوبت اعمال می‌شه
    _sync_cylinder(session, r, cfg)
    _start_turn(r, nxt.user_id, cfg, now)
    _log(r, f"🎲 تپانچه افتاد دستِ {_name(session, nxt.user_id)}.")
    session.commit()
    await _broadcast(context, session, r)
    await _send_ping(context, session, r)
    _schedule_turn_timers(context, r, cfg)


def _schedule_turn_timers(context, r, cfg):
    """دو تایمر: (۱) وقتی انتظارِ چرخاندنِ خشاب تموم شد پنل رو «شلیک آزاده» می‌کنه،
    (۲) بعد از انتظار + مهلتِ شلیک، اگه شلیک نشده بود بازیکن حذف می‌شه."""
    if cfg["wait"] > 0:
        _schedule(_ready_notice, cfg["wait"] + 0.5, context, r.id, r.turn_seq)
    _schedule(_turn_timeout, cfg["wait"] + cfg["turn"] + 1, context, r.id, r.turn_seq)


async def _ready_notice(context, rid, seq):
    """انتظارِ چرخاندنِ خشاب تموم شد: پنل «✅ خشاب چرخید؛ شلیک آزاده» رو نشون می‌ده."""
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.RouletteRound, rid)
            if not r or r.status != "playing" or (r.turn_seq or 0) != seq:
                return
            if not _is_ready(r):
                return
            await _broadcast(context, session, r)
        finally:
            session.close()


async def _finish_render(context, session, r):
    await _clear_ping(context, r.id)
    await _broadcast(context, session, r)
    _round_locks.pop(r.id, None)


# ---------------------------------------------------------------------------
# شلیک
# ---------------------------------------------------------------------------

def _shot_db(session, r, shooter, target=None):
    """(بدونِ await) یه بار ماشه رو می‌کشه.
    target=None: شلیک به خودش | target: شلیک به یه بازیکنِ زنده‌ی دیگه.
    - جنگی: هدف (یا خودش، اگه به خودش زده) می‌میره و خشاب (با تنظیماتِ فعلیِ پنل) دوباره پر و چرخونده می‌شه.
    - مشقی: به خودش = زنده می‌مونه؛ به دیگری = خودِ شلیک‌کننده حذف می‌شه (خونه مصرف می‌شه).
    خشاب می‌تونه چند تیرِ جنگی/مشقی داشته باشه؛ چون هر تیرِ جنگی که شلیک بشه یه نفر می‌میره و
    خشاب ری‌لود می‌شه، همیشه یه تیرِ جنگی جلوتر تو خشابه و اشاره‌گر هیچ‌وقت از خشاب بیرون نمی‌زنه.
    خروجی: (kind, تموم شد؟, برنده)  kind یکی از self_blank/self_live/other_live/other_blank"""
    layout = _layout(r)
    idx = r.chamber_idx or 0
    if idx >= len(layout) or "L" not in layout[idx:]:
        _reload_cylinder(session, r)      # (دفاعی) نباید پیش بیاد
        layout, idx = r.chambers, 0
    live = layout[idx] == "L"
    sname = _name(session, shooter.user_id)
    if target is None:
        if not live:
            r.chamber_idx = idx + 1
            _log(r, f"🔘 کلیک! {sname} زنده موند.")
            return "self_blank", False, None
        kind = "self_live"
        shooter.alive = False
        shooter.out_reason = "کشته شد (تیرِ جنگی به خودش)"
        _log(r, f"💥 بانگ! {sname} با شلیکِ {idx + 1}ام خودش رو کشت.")
    else:
        tname = _name(session, target.user_id)
        if live:
            kind = "other_live"
            target.alive = False
            target.out_reason = f"کشته شد (شلیک موفق جنگی از طرف {sname})"
            _log(r, f"🎯💥 {sname} به {tname} شلیک کرد؛ تیرِ جنگی بود و {tname} کشته شد.")
        else:
            kind = "other_blank"
            shooter.alive = False
            shooter.out_reason = f"حذف شد (به دلیل شلیک ناموفق به {tname})"
            r.chamber_idx = idx + 1  # خونه‌ی مشقی مصرف شد؛ تیرهای جنگی هنوز تو بقیه‌ی خونه‌هان
            _log(r, f"🎯❌ {sname} به {tname} شلیک کرد؛ تیرِ مشقی بود و {sname} حذف شد.")
    session.flush()
    alive = _alive_players(session, r.id)
    if len(alive) <= 1:
        return kind, True, (alive[0].user_id if alive else None)
    if live:
        _reload_cylinder(session, r)
        _log(r, "🔄 خشاب دوباره پر و چرخونده شد.")
    return kind, False, None


_SHOT_TOAST = {
    "self_blank": "🔘 کلیک! زنده موندی.",
    "self_live": "💥 بانگ! تیر خوردی.",
    "other_live": "🎯💥 تیرِ جنگی بود! هدف کشته شد.",
    "other_blank": "🎯❌ تیرِ مشقی بود؛ تو حذف شدی.",
}


async def _take_shot(update, context, target_uid):
    """منطقِ مشترکِ «شلیک به خودم» و «شلیک به فلانی»؛ زیرِ قفلِ دور اجرا می‌شه."""
    q = update.callback_query
    parts = q.data.split(":")
    try:
        rid, seq = int(parts[1]), int(parts[2])
    except (ValueError, IndexError):
        await _safe_answer(q)
        return
    uid = update.effective_user.id
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not r or r.status != "playing":
            await _safe_answer(q, "⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        p = _get_player(session, rid, uid)
        if not p:
            await _safe_answer(q, "⛔️ تو تو این بازی نیستی.", show_alert=True)
            return
        if not p.alive:
            await _safe_answer(q, "☠️ تو از بازی حذف شدی.", show_alert=True)
            return
        if r.turn_user_id != uid:
            await _safe_answer(q, f"⏳ الان نوبتِ {_name(session, r.turn_user_id)} ـه، نه تو!", show_alert=True)
            return
        if seq != (r.turn_seq or 0):
            await _safe_answer(q, "⌛️ این نوبت تموم شده؛ پنلِ جدید رو ببین.")
            # پنلی که دکمه‌ی نوبتِ قدیمی رو نشون می‌ده = ادیتِ نوبتِ جدید بهش نرسیده؛ همین‌جا درستش می‌کنیم
            await _refresh_pressed_panel(context, session, r, q, uid)
            return
        if not _is_ready(r):
            left = max(1, int(math.ceil((r.turn_ready_at - _now()).total_seconds())))
            await _safe_answer(
                q, f"⏳ هنوز {_turn_wait(r)} ثانیه نشده! خشابِ تفنگ در حالِ چرخیدنه؛ "
                   f"{left} ثانیه‌ی دیگه صبر کن.", show_alert=True)
            return
        target = None
        if target_uid is not None:
            target = _get_player(session, rid, target_uid)
            if target_uid == uid or not target or not target.alive:
                await _safe_answer(q, "⛔️ این هدف معتبر نیست (شاید قبلاً حذف شده).", show_alert=True)
                return

        kind, finished, winner = _shot_db(session, r, p, target)
        r.last_action_at = _now()
        if finished:
            _finish_db(session, r, winner)
        session.commit()

        await _safe_answer(q, _SHOT_TOAST[kind])
        if finished:
            await _finish_render(context, session, r)
        else:
            await _advance_turn(context, session, r, prev_uid=uid)
    finally:
        session.close()


@with_round_lock
async def cb_rr_fire(update, context):
    """🔫 شلیک به خودم."""
    await _take_shot(update, context, None)


@with_round_lock
async def cb_rr_shoot(update, context):
    """🎯 شلیک به یه بازیکنِ دیگه (rr_shoot:{rid}:{seq}:{target_uid})."""
    try:
        target_uid = int(update.callback_query.data.split(":")[3])
    except (ValueError, IndexError):
        await _safe_answer(update.callback_query)
        return
    await _take_shot(update, context, target_uid)


# ---------------------------------------------------------------------------
# تایم‌اوت‌ها
# ---------------------------------------------------------------------------

async def _turn_timeout(context, rid, seq):
    """نوبتی که تو مهلت شلیک نشد: بازیکن حذف می‌شه؛ اگه فقط یه نفر بمونه بازی
    همون‌جا تموم و اون نفر برنده‌ست. seq تضمین می‌کنه تایمرِ یه نوبتِ قدیمی
    نتونه نوبتِ فعلی رو اشتباهی حذف کنه."""
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.RouletteRound, rid)
            if not r or r.status != "playing" or (r.turn_seq or 0) != seq:
                return
            if r.turn_deadline_at and r.turn_deadline_at > _now() + datetime.timedelta(seconds=2):
                return  # هنوز وقتش نشده
            p = _get_player(session, rid, r.turn_user_id)
            if not p or not p.alive:
                return
            turn_len = _turn_len(r)
            p.alive = False
            p.out_reason = f"حذف شد (عدم شلیک در مهلتِ {turn_len} ثانیه)"
            _log(r, f"⏱ {_name(session, p.user_id)} تو {turn_len} ثانیه شلیک نکرد و از بازی حذف شد.")
            session.flush()
            alive = _alive_players(session, rid)
            if len(alive) <= 1:
                _finish_db(session, r, alive[0].user_id if alive else None)
                session.commit()
                await _finish_render(context, session, r)
                return
            session.commit()
            await _advance_turn(context, session, r, prev_uid=p.user_id)
        finally:
            session.close()


async def _lobby_timeout(context, rid):
    """لابیِ گروهی (۱۸۰ ثانیه) یا لابیِ جهانی (۶ دقیقه) که پر نشد: لغو و ریفاند.
    اگه لابی پر شده ولی بازی به هر دلیلی (خطای موقتِ تلگرام/کرشِ هندلر) شروع نشده
    بود، به‌جایِ رها کردن، همین‌جا بازی رو شروع می‌کنیم - هیچ لابیِ پری نباید
    برای همیشه رویِ «عضوگیری» بمونه."""
    async with _get_round_lock(rid):
        session = db.get_session()
        r = None
        try:
            r = session.get(db.RouletteRound, rid)
            if not r or r.status != "lobby":
                return
            players = _all_players(session, rid)
            if len(players) >= (r.target_players or 99):
                await _begin_game(context, session, r)
                return
            if not _is_expired(r, _now()):
                return
            n = len(players)
            text = _cancel_text(r, n)
            targets = _cancel_db(session, r, text)
            session.commit()
            await asyncio.gather(*[_edit_msg(context, c, m, text, None) for c, m, _u in targets],
                                 return_exceptions=True)
        finally:
            ended = bool(r) and r.status in ("resolved", "cancelled")
            session.close()
            if ended:
                _round_locks.pop(rid, None)


async def _setup_timeout(context, rid):
    async with _get_round_lock(rid):
        session = db.get_session()
        r = None
        try:
            r = session.get(db.RouletteRound, rid)
            if not r or r.status != "setup" or not _is_expired(r, _now()):
                return
            text = _cancel_text(r, 0, "inactive")
            targets = _cancel_db(session, r, text)
            session.commit()
            for chat_id, message_id, _uid in targets:
                await _edit_msg(context, chat_id, message_id, text, None)
        finally:
            ended = bool(r) and r.status in ("resolved", "cancelled")
            session.close()
            if ended:
                _round_locks.pop(rid, None)


# ---------------------------------------------------------------------------
# جاروکشِ دوره‌ای (از jobs.tick_job هر ۶۰ ثانیه صدا زده می‌شه)
# ---------------------------------------------------------------------------

async def tick_roulette(session, context):
    """اگه ربات وسطِ بازی ری‌استارت شده باشه تایمرهایِ درون‌حافظه‌ای از بین می‌رن؛
    این جاروب همه‌چیز رو بر اساسِ زمان‌هایِ ذخیره‌شده تو دیتابیس جمع می‌کنه:
    setup/لابیِ منقضی، نوبتِ ردشده، و پیام‌هایِ دورهایی که به‌صورتِ لحظه‌ای لغو شدن."""
    while _lazy_edits:
        chat_id, message_id, text = _lazy_edits.pop()
        await _edit_msg(context, chat_id, message_id, text, None)

    now = _now()
    rows = (session.query(db.RouletteRound.id, db.RouletteRound.status, db.RouletteRound.turn_seq,
                          db.RouletteRound.turn_deadline_at)
            .filter(db.RouletteRound.status.in_(ACTIVE_STATUSES)).all())
    for rid, status, seq, deadline in rows:
        try:
            if status == "setup":
                await _setup_timeout(context, rid)
            elif status == "lobby":
                await _lobby_timeout(context, rid)
            elif status == "playing" and deadline and deadline < now:
                await _turn_timeout(context, rid, seq or 0)
        except Exception:
            logger.exception("خطا در جاروبِ رولت روسی (دور %s)", rid)

    # پنل‌هایی که بعد از چند تلاشِ فوری هم همگام نشدن: هر تیک یه بار دیگه (تا ۶ بار)
    for rid, n in list(_dirty.items()):
        if n >= 12:
            _dirty.pop(rid, None)
        elif n >= 6:
            _dirty[rid] = n + 1
            try:
                await _resync(context, rid)
            except Exception:
                logger.exception("خطا در همگام‌سازیِ پنل‌هایِ رولت (دور %s)", rid)


# ---------------------------------------------------------------------------
# مسیریاب
# ---------------------------------------------------------------------------

async def cb_rr_noop(update, context):
    await _safe_answer(update.callback_query)


RR_PREFIX_MAP = {
    "rr_new": cb_rr_new,
    "rr_menu": cb_rr_menu,
    "rr_mode_menu": cb_rr_mode_menu,
    "rr_mode_group": cb_rr_mode_group,
    "rr_mode_global": cb_rr_mode_global,
    "rr_gtier": cb_rr_gtier,
    "rr_gjoin": cb_rr_gjoin,
    "rr_gleave": cb_rr_gleave,
    "rr_setup": cb_rr_setup,
    "rr_amt_menu": cb_rr_amt_menu,
    "rr_amt_pick": cb_rr_amt_pick,
    "rr_amt_custom": cb_rr_amt_custom,
    "rr_amtx": cb_rr_amtx,
    "rr_plr_menu": cb_rr_plr_menu,
    "rr_plr_pick": cb_rr_plr_pick,
    "rr_back": cb_rr_back,
    "rr_cancel": cb_rr_cancel,
    "rr_start": cb_rr_start,
    "rr_join": cb_rr_join,
    "rr_leave": cb_rr_leave,
    "rr_fire": cb_rr_fire,
    "rr_shoot": cb_rr_shoot,
    "rr_noop": cb_rr_noop,
}


# پیشوندهایی که دومین بخشِ callback_data شون آی‌دیِ دور (rid) ـه
_ROUND_PREFIXES = {
    "rr_gleave", "rr_setup", "rr_amt_menu", "rr_amt_pick", "rr_amt_custom", "rr_amtx", "rr_plr_menu",
    "rr_plr_pick", "rr_back", "rr_cancel", "rr_start", "rr_join", "rr_leave", "rr_fire", "rr_shoot",
}
# دکمه‌هایِ مرحله‌ی «قبل از بازی»؛ وقتی دور دیگه تو lobby/setup نیست یعنی پنل کهنه‌ست
_PRE_GAME_PREFIXES = _ROUND_PREFIXES - {"rr_fire", "rr_shoot"}


async def _refresh_pressed_panel(context, session, r, q, uid):
    """پیامی که کاربر روش دکمه زده رو با وضعیتِ فعلیِ دور ادیت می‌کنه."""
    msg = q.message
    if msg is None:
        return
    for_uid = uid if (r.mode == "global" and _get_player(session, r.id, uid)) else None
    text, kb = _view(session, r, for_uid)
    await _edit_msg(context, msg.chat_id, msg.message_id, text, kb)


async def _heal_stale_panel(update, context, prefix, data) -> bool:
    """پنلِ کهنه/مرده (مثلاً ادیتِ شروعِ بازی به‌خاطرِ فلود/سرورِ شلوغ فقط برایِ بعضی از
    بازیکن‌ها رسیده و بقیه هنوز «عضوگیری» می‌بینن): به‌جایِ فقط یه هشدارِ خشک،
    همون پیامِ کاربر رو با وضعیتِ واقعیِ دور ادیت می‌کنیم."""
    try:
        rid = int(data.split(":")[1])
    except (ValueError, IndexError):
        return False
    q = update.callback_query
    uid = update.effective_user.id
    session = db.get_session()
    try:
        r = session.get(db.RouletteRound, rid)
        if not r:
            return False
        dead = r.status in ("cancelled", "resolved")
        stale_pre_game = r.status == "playing" and prefix in _PRE_GAME_PREFIXES
        if r.status == "lobby" and r.mode == "global" and prefix in ("rr_fire", "rr_shoot"):
            stale_pre_game = True
        if not (dead or stale_pre_game):
            return False
        if prefix == "rr_amtx":
            context.user_data.pop("rr_awaiting", None)
        if r.mode == "global" and not _get_player(session, rid, uid):
            await _safe_answer(q, "⛔️ این لابی دیگه فعال نیست.", show_alert=True)
            return True
        await _safe_answer(q, "⛔️ این پنل کهنه بود؛ وضعیتِ واقعیِ بازی رو نشونت دادم.", show_alert=True)
        await _refresh_pressed_panel(context, session, r, q, uid)
        return True
    finally:
        session.close()


async def rr_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = RR_PREFIX_MAP.get(prefix)
    if handler:
        if prefix in _ROUND_PREFIXES and await _heal_stale_panel(update, context, prefix, data):
            return True
        await handler(update, context)
        return True
    return False
