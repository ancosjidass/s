# -*- coding: utf-8 -*-
"""تستِ موتورِ بتل‌پس (بدونِ تلگرام). اجرا:  python -m pytest -q test_battlepass.py
روی sqlite موقت؛ برایِ Postgres:  DATABASE_URL=postgresql://... python -m pytest -q test_battlepass.py"""
import datetime
import os
import tempfile

_TMP = tempfile.mkdtemp()
os.environ.setdefault("DB_PATH", os.path.join(_TMP, "bp_test.db"))
os.environ.setdefault("BOT_TOKEN", "1:a")
os.environ.setdefault("OWNER_ID", "1")

import pytest

import battlepass_db as BD
import battlepass_engine as E
import db
import chat_prefs, referral, mission_db, heist_db, war_db


@pytest.fixture(scope="module", autouse=True)
def _init():
    db.init_db(); chat_prefs.init(); referral.init_referral(); mission_db.init_missions()
    heist_db.init_heist(); war_db.init_war(); BD.init_battlepass()
    yield


_uid = [5000]


@pytest.fixture()
def S():
    s = db.get_session()
    yield s
    s.close()


def mkuser(S, hop=0.0, lvl=1):
    _uid[0] += 1
    u = db.User(telegram_id=_uid[0], username=f"t{_uid[0]}", first_name="T", hop_points=hop, lvl=lvl, hop_count=0)
    S.add(u); S.commit()
    return u


def fresh_season(S, **cfg):
    for k, v in cfg.items():
        E.admin_set_cfg(S, k, v)
    s = E.admin_new_season(S)
    E.invalidate()
    return s


def test_progress_and_difficulty_stages(S):
    n = 100
    costs = E.stage_costs(S)
    assert len(costs) == 5 and costs == sorted(costs), "هرچی مرحله‌ی سختی بالاتر، XPِ لازم بیشتر"
    cum = E.thresholds(S, n)
    assert E.progress(S, 0, n)["tier"] == 0
    assert E.progress(S, cum[1], n)["tier"] == 1
    assert E.progress(S, cum[1] - 1, n)["tier"] == 0
    assert E.progress(S, cum[100], n)["maxed"] and E.progress(S, cum[100], n)["mastery"] == 0
    assert E.progress(S, cum[100] + 2 * E.gf(S, "bp_mastery_cost"), n)["mastery"] == 2
    assert E.stage_of(1, n) == 0 and E.stage_of(21, n) == 1 and E.stage_of(100, n) == 4


def test_default_rewards_shape_and_economy(S):
    r = E.default_rewards(100, 100000)
    assert len([x for x in r if x["track"] == "free"]) == 100 and len([x for x in r if x["track"] == "premium"]) == 100
    free_cash = sum(x["amount"] for x in r if x["track"] == "free" and x["kind"] == "hop")
    prem_cash = sum(x["amount"] for x in r if x["track"] == "premium" and x["kind"] == "hop")
    assert 15e6 < free_cash < 45e6, free_cash            # ≈ نصفِ ماهِ درآمدِ پایه‌ی کارخونه (۵۲M)
    assert prem_cash > free_cash
    kinds = {x["kind"] for x in r}
    assert {"heist_loot", "heist_cd", "jail_free", "hop_perm", "prod_boost", "shop_money", "shop_power", "title"} <= kinds
    assert all(x["uses"] > 0 for x in r if x["kind"] in ("heist_loot", "heist_cd"))   # سرقت: تعدادی


def test_claim_idempotent_and_premium_gate(S):
    fresh_season(S)
    u = mkuser(S)
    season, p = E.sync(S, u)
    p.xp = E.thresholds(S, season.tiers)[3]
    S.commit()
    before = u.hop_points
    E.claim_tier(S, u, season.id, 1, "free")
    S.refresh(u)
    assert u.hop_points > before
    with pytest.raises(E.BpError):
        E.claim_tier(S, u, season.id, 1, "free")             # دوباره نمی‌شه
    with pytest.raises(E.BpError):
        E.claim_tier(S, u, season.id, 1, "premium")          # بدونِ پریمیوم نمی‌شه
    lines = E.claim_all(S, u, season.id)
    assert any("تیر 2" in x for x in lines) and any("تیر 3" in x for x in lines)
    with pytest.raises(E.BpError):
        E.claim_all(S, u, season.id)
    ledger = S.query(db.Config).count()                       # فقط برایِ اطمینان از زنده‌بودنِ session
    assert ledger > 0


def test_buy_premium_and_skip(S):
    s = fresh_season(S)
    price = E.gf(S, "bp_premium_price")
    poor = mkuser(S, hop=price - 1)
    with pytest.raises(E.BpError):
        E.buy_premium(S, poor)
    rich = mkuser(S, hop=price + 50_000_000)
    E.buy_premium(S, rich)
    S.refresh(rich)
    assert abs(rich.hop_points - 50_000_000) < 1
    with pytest.raises(E.BpError):
        E.buy_premium(S, rich)
    season, p = E.sync(S, rich)
    assert p.premium
    sk, st = E.skip_price(S, season, p)
    E.buy_skip(S, rich)
    p2 = E.get_player(S, rich, season)
    assert E.progress(S, p2.xp, season.tiers)["tier"] == 1
    # بعدِ پریمیوم، جایزه‌ی پریمیومِ تیرِ ۱ قابل‌دریافته
    assert (1, "premium") in E.claimable(S, season, p2)


def test_hop_bonus_percent_admin_controlled(S):
    fresh_season(S, bp_hop_bonus_global_pct=0, bp_hop_bonus_premium_pct=10, bp_hop_bonus_cap_pct=150)
    u = mkuser(S)
    assert E.hop_bonus_pct(S, u.telegram_id) == 0
    E.admin_set_cfg(S, "bp_hop_bonus_global_pct", "20")      # ایونتِ ادمین
    assert E.hop_bonus_pct(S, u.telegram_id) == 20
    r, pct = E.on_hop(S, u, 1000)
    assert pct == 20 and r == 1200
    E.admin_grant(S, u.telegram_id, "premium")
    assert E.hop_bonus_pct(S, u.telegram_id) == 30           # + پریمیوم
    E.admin_grant(S, u.telegram_id, "booster", "hop_boost", 50, 0, 60)
    b = E.my_boosters(S, u.telegram_id)[0]
    E.activate_booster(S, u, b.id)
    assert E.hop_bonus_pct(S, u.telegram_id) == 80           # + بوستر
    E.admin_set_cfg(S, "bp_hop_bonus_cap_pct", "50")
    assert E.hop_bonus_pct(S, u.telegram_id) == 50           # سقف
    E.admin_set_cfg(S, "bp_enabled", "0")
    assert E.hop_bonus_pct(S, u.telegram_id) == 0 and E.on_hop(S, u, 1000) == (1000, 0.0)
    E.admin_set_cfg(S, "bp_enabled", "1"); E.admin_set_cfg(S, "bp_hop_bonus_global_pct", "0"); E.admin_set_cfg(S, "bp_hop_bonus_cap_pct", "150")


def test_boosters_time_uses_and_one_per_kind(S):
    fresh_season(S)
    u = mkuser(S, hop=1_000_000)
    b1 = E.grant_booster(S, u.telegram_id, "prod_boost", 40, 0, 30)
    b2 = E.grant_booster(S, u.telegram_id, "prod_boost", 60, 0, 30)
    S.commit()
    E.activate_booster(S, u, b1.id)
    with pytest.raises(E.BpError):
        E.activate_booster(S, u, b2.id)                       # از هر نوع یکی هم‌زمان
    assert abs(E.production_mult(S, u.telegram_id) - 1.4) < 1e-9
    b1 = S.get(BD.BpBooster, b1.id)
    b1.ends_at = E.utcnow() - datetime.timedelta(minutes=1)   # زمانی: منقضی شد
    S.commit(); E.invalidate()
    assert E.production_mult(S, u.telegram_id) == 1.0
    assert S.get(BD.BpBooster, b1.id).state == "used"
    E.activate_booster(S, u, b2.id)                           # حالا بعدی فعال می‌شه
    assert abs(E.production_mult(S, u.telegram_id) - 1.6) < 1e-9


def test_heist_boosters_usage_based(S):
    fresh_season(S)
    u = mkuser(S, hop=0)
    E.grant_booster(S, u.telegram_id, "heist_loot", 25, 2, 0)
    E.grant_booster(S, u.telegram_id, "heist_cd", 50, 1, 0)
    S.commit()
    for b in E.my_boosters(S, u.telegram_id):
        E.activate_booster(S, u, b.id)
    assert E.heist_bonus(S, u, 1_000_000, "op1") == 250_000   # +۲۵٪ از خانه
    S.commit(); S.refresh(u)
    assert u.hop_points == 250_000
    assert E.heist_bonus(S, u, 1_000_000, "op2") == 250_000   # ۲ بار
    assert E.heist_bonus(S, u, 1_000_000, "op3") == 0          # تموم شد
    assert E.heist_cooldown(S, u.telegram_id, 480) == 240      # ۵۰٪ کمتر
    assert E.heist_cooldown(S, u.telegram_id, 480) == 480      # یک بار مصرف بود
    S.commit()


def test_jail_card(S):
    fresh_season(S)
    u = mkuser(S)
    with pytest.raises(E.BpError):
        E.use_jail_card(S, u)                                  # زندانی نیست
    u.jailed_until = E.utcnow() + datetime.timedelta(hours=5); u.jail_bail_amount = 9e9; S.commit()
    with pytest.raises(E.BpError):
        E.use_jail_card(S, u)                                  # کارت نداره
    E.grant_booster(S, u.telegram_id, "jail_free", 0, 1, 0); S.commit()
    assert E.has_jail_card(u.telegram_id)
    E.use_jail_card(S, u)
    S.refresh(u)
    assert u.jailed_until is None and not E.has_jail_card(u.telegram_id)


def test_season_rollover_continuous_and_grace(S):
    s1 = fresh_season(S, bp_grace_days=3)
    u = mkuser(S)
    season, p = E.sync(S, u)
    p.xp = E.thresholds(S, season.tiers)[2]; S.commit()
    old = S.get(BD.BpSeason, s1.id)
    old.ends_at = E.utcnow() - datetime.timedelta(hours=1); S.commit(); E._season_memo_clear()
    s2 = E.current_season(S); S.commit()
    assert s2.id != s1.id and s2.number == s1.number + 1 and E.is_open(s2)       # فصلِ بعد خودکار
    assert S.query(BD.BpTierDef).filter_by(season_id=s2.id).count() == S.query(BD.BpTierDef).filter_by(season_id=s1.id).count()
    E.claim_tier(S, u, s1.id, 1, "free")                       # مهلتِ دریافتِ فصلِ قبل
    old.ends_at = E.utcnow() - datetime.timedelta(days=5); S.commit()
    with pytest.raises(E.BpError):
        E.claim_tier(S, u, s1.id, 2, "free")                   # مهلت تموم شد
    # شروعِ فصلِ جدید: XP صفره
    _s, p2 = E.sync(S, u)
    assert p2.xp == 0


def test_reward_edits_carry_to_next_season(S):
    s1 = fresh_season(S)
    E.admin_set_tier(S, s1.id, 7, "free", "hop|777000|0|0|0|تست")
    s2 = E.admin_new_season(S)
    d = S.query(BD.BpTierDef).filter_by(season_id=s2.id, tier=7, track="free").one()
    assert d.amount == 777000                                   # فصلِ بعد از فصلِ قبل کپی می‌شه
    E.admin_set_tier(S, s2.id, 7, "free", "heist_loot|0|30|3|0")
    d1 = S.query(BD.BpTierDef).filter_by(season_id=s1.id, tier=7, track="free").one()
    assert d1.kind == "hop"                                     # تغییرِ فصلِ جدید فصلِ قبل رو عوض نمی‌کنه
    with pytest.raises(E.BpError):
        E.admin_set_tier(S, s2.id, 7, "free", "bogus|1")


def _add_casino(S, uid, n):
    rnd = db.CasinoRound(chat_id=-1, initiator_id=uid, game_type="ws", status="resolved")
    S.add(rnd); S.flush()
    for _ in range(n):
        S.add(db.CasinoPlayer(round_id=rnd.id, user_id=uid, joined_at=E.utcnow()))
    S.commit()


def test_challenge_claim_and_streak(S):
    fresh_season(S, bp_level_scale=0, bp_week_difficulty=0)
    # فقط یه چلنجِ روزانه‌ی مشخص
    S.query(BD.BpChallengeDef).update({"enabled": False}); S.commit()
    ch = E.admin_create_challenge(S, "تست کازینو", "casino_played", 2, 400, 1, "daily")
    u = mkuser(S)
    season, p = E.sync(S, u, force=True)
    item = next(c for c in E.challenge_list(S, u, season, p) if c["id"] == ch.id)
    assert item["target"] == 2 and not item["done"]
    with pytest.raises(E.BpError):
        E.claim_challenge(S, u, ch.id)
    _add_casino(S, u.telegram_id, 2)
    r = E.claim_challenge(S, u, ch.id)
    assert r["xp"] >= 400 and r["streak"] == 1
    with pytest.raises(E.BpError):
        E.claim_challenge(S, u, ch.id)                          # دوباره نمی‌شه
    S.query(BD.BpChallengeDef).update({"enabled": True}); S.commit()


def test_difficulty_scales_with_week_and_level(S):
    fresh_season(S, bp_level_scale=0.5, bp_week_difficulty=0.12, bp_level_cap=100)
    lo, hi = mkuser(S, lvl=1), mkuser(S, lvl=100)
    assert E.scale_for(S, hi, 0, "daily") > E.scale_for(S, lo, 0, "daily")
    assert E.scale_for(S, lo, 3, "weekly") > E.scale_for(S, lo, 0, "weekly")
    assert E.scale_for(S, lo, 3, "season") == E.scale_for(S, lo, 0, "season")   # فصلی با هفته سخت‌تر نمی‌شه


def test_activity_xp_capped_per_day(S):
    fresh_season(S, bp_activity_cap_day=100, bp_xp_global_pct=0, bp_xp_premium_pct=0)
    u = mkuser(S)
    season, p = E.sync(S, u, force=True)
    _add_casino(S, u.telegram_id, 30)                           # ۳۰×۱۵ = ۴۵۰ > سقفِ ۱۰۰
    season, p = E.sync(S, u, force=True)
    assert 99 <= p.xp <= 101
    season, p = E.sync(S, u, force=True)                        # دوباره‌شماری نمی‌شه
    assert 99 <= p.xp <= 101
    E.admin_set_cfg(S, "bp_activity_cap_day", "1500")


def test_admin_validation(S):
    with pytest.raises(E.BpError):
        E.admin_set_cfg(S, "nope", "1")
    with pytest.raises(E.BpError):
        E.admin_set_cfg(S, "bp_cash_unit", "abc")
    with pytest.raises(E.BpError):
        E.admin_set_cfg(S, "bp_cash_unit", "-5")
    with pytest.raises(E.BpError):
        E.admin_set_cfg(S, "bp_stage_costs", "1,2,3")
    assert E.admin_set_cfg(S, "bp_hop_bonus_global_pct", "۲۰") == "20"   # عددِ فارسی
    E.admin_set_cfg(S, "bp_hop_bonus_global_pct", "0")
    with pytest.raises(E.BpError):
        E.admin_create_challenge(S, "x", "bogus", 1, 1, 1, "daily")
    with pytest.raises(E.BpError):
        E.admin_grant(S, 99999999, "xp", 10)
