# -*- coding: utf-8 -*-
"""
شبیه‌سازیِ بالانسِ Frontier با موتورِ واقعیِ جنگ (Monte-Carlo). فقط خواندنی؛ برای تنظیمِ power/HP/پاداش.
اجرا:  python frontier_sim.py [N]      (روی یک دیتابیسِ موقت؛ به دیتای واقعی دست نمی‌زنه)
"""
import os
import sys
import tempfile

os.environ.setdefault("BOT_TOKEN", "1:x")
os.environ["DB_PATH"] = os.path.join(tempfile.mkdtemp(), "sim.db")

import db  # noqa: E402
import war_db as W  # noqa: E402
import war_svc as S  # noqa: E402
import war_battle as B  # noqa: E402
import frontier_db as F  # noqa: E402
import frontier_svc as FS  # noqa: E402
import frontier_engine as FE  # noqa: E402

N = int(sys.argv[1]) if len(sys.argv) > 1 else 200
ARCH = {"casual": (0.55, 3), "solid": (0.80, 4), "optimized": (1.00, 5)}   # (پرِ‌بودنِ پادگان, سطحِ ارتقای نیروها)


def build_army(session, th, fill, lvl):
    defs = [d for d in S.udefs(session) if d.atk > 0 and d.req_th <= th]
    cap = 30 + 12 * (min(30, 3 * th) - 1)
    budget = int(cap * fill)
    ranked = sorted(defs, key=lambda d: -(d.atk / d.housing))
    comp, left = {}, budget
    # ۶۰٪ ظرفیت بهترین واحد، ۴۰٪ دومین (ترکیبِ واقع‌بینانه‌تر)
    for share, d in zip((0.6, 0.4), ranked[:2] or ranked):
        n = int(budget * share // d.housing)
        comp[d.key] = comp.get(d.key, 0) + n
        left -= n * d.housing
    return comp, cap


def main():
    db.init_db()
    W.init_war()
    F.init_frontier()
    s = db.get_session()
    params, _v = S.formula_params(s)
    print(f"N={N} | تعدادِ شبیه‌سازی به‌ازای هر سلول")
    regs = FS.regions(s)
    for th in (1, 2, 3, 5, 6, 8):
        for arch, (fill, lvl) in ARCH.items():
            uid = 1000 + th * 10 + list(ARCH).index(arch)
            s.add(db.User(telegram_id=uid, first_name=f"t{th}{arch}", hop_points=0))
            s.flush()
            p = S.get_player(s, uid)
            p.th_level = th
            comp, cap = build_army(s, th, fill, lvl)
            for k, n in comp.items():
                u = s.query(W.WarUnit).filter_by(user_id=uid, unit_key=k).first()
                if u is None:
                    u = W.WarUnit(user_id=uid, unit_key=k, healthy=0, damaged=0, level=lvl)
                    s.add(u)
                u.healthy, u.level = n, lvl
            s.flush()
            army = B.materialize(s, uid, comp)
            line = []
            for r in regs:
                if r.req_th > th + 1:
                    continue
                for n in FS.nodes_in(s, r.key):
                    if n.kind == "boss" or n.req_th > th:
                        continue
                    fx, _st = FS._fx_for(s, "assault", army, {d.key: d for d in S.udefs(s, enabled_only=False)})
                    wins = 0
                    cas = 0
                    for i in range(N):
                        units = B.engine_units(s, uid, army)
                        res = FE.run_node(i + 1, units, {"power": n.power, "ground_pct": n.ground_pct, "air_pct": n.air_pct, "wall": n.wall},
                                          params, 100.0, fx)
                        wins += 1 if res["outcome"] == "attacker" else 0
                        cas += sum(v[2] for v in res["atk_units"].values()) if isinstance(next(iter(res["atk_units"].values())), (list, tuple)) else sum(v["x"] for v in res["atk_units"].values())
                    line.append(f"{n.key}:{100 * wins // N}%")
            print(f"TH{th} {arch:9s} housing {sum(comp.values())}u cap {cap} | " + " ".join(line))
    s.commit()


if __name__ == "__main__":
    main()
