# -*- coding: utf-8 -*-
"""
پنل مدیریت اختصاصیِ مالک ربات (فقط در پیوی و فقط برای OWNER_ID کار می‌کنه).
با این پنل، مالک بدون دست‌زدن به کد می‌تونه:
- تعداد سطوح کارخونه و فرمول تجربه/تولید رو تغییر بده
- اطلاعات هر پلیر رو در دیتابیس ویرایش کنه
- قیمت روز سوپرمارکت رو تنظیم کنه
- ارز دیجیتال جدید بسازه/حذف کنه و قیمت خرید و فروش تعیین کنه
- قرعه‌کشی‌ها رو مدیریت و برنده رو انتخاب کنه (شانسی یا دستی)
- به خودش هاپ پوینت اضافه کنه (بدون نیاز به موجودی)
"""
import random
import logging
import datetime
import json

from sqlalchemy import text as sa_text
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ContextTypes, ApplicationHandlerStop

import config
import db
import guide
import attack
import smuggling
from handlers import send_response, fmt, is_owner, ask_for_input, ask_for_input_reply, is_reply_to_prompt

logger = logging.getLogger(__name__)


def owner_only(func):
    """اجازه‌ی عبور می‌ده به مالکِ اصلی یا هر ادمینِ فرعیِ ثبت‌شده (فارغ از
    اینکه چه دسترسی‌ای داره) - محدودکردنِ دقیقِ اینکه کدوم بخش رو می‌بینه، تو
    مسیریابِ مرکزیِ admin_callback_router بر اساسِ دسته‌بندیِ هر کالبک انجام
    می‌شه، نه اینجا. برای بخش‌هایی که باید همیشه فقط دستِ خودِ مالکِ اصلی بمونه
    (مثلِ مدیریتِ خودِ ادمین‌ها)، به‌جاش از strict_owner_only استفاده کن."""
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        session = db.get_session()
        try:
            allowed = db.is_any_admin(session, update.effective_user.id)
        finally:
            session.close()
        if not allowed:
            if update.callback_query:
                await update.callback_query.answer("⛔️ این بخش فقط برای مالک ربات است.", show_alert=True)
            else:
                await update.message.reply_text("⛔️ این بخش فقط برای مالک ربات است.")
            return
        if update.effective_chat.type != "private":
            if update.callback_query:
                await update.callback_query.answer("⛔️ پنل مدیریت فقط در پیوی ربات کار می‌کند.", show_alert=True)
            return
        await func(update, context)
    return wrapper


def strict_owner_only(func):
    """برخلافِ owner_only، هیچ ادمینِ فرعی‌ای (حتی با همه‌ی دسترسی‌ها) از این
    رد نمی‌شه - فقط خودِ مالکِ اصلی. برای مدیریتِ خودِ ادمین‌ها استفاده می‌شه."""
    async def wrapper(update: Update, context: ContextTypes.DEFAULT_TYPE):
        if not is_owner(update.effective_user.id):
            if update.callback_query:
                await update.callback_query.answer("⛔️ این بخش فقط برای مالکِ اصلیِ رباته.", show_alert=True)
            else:
                await update.message.reply_text("⛔️ این بخش فقط برای مالکِ اصلیِ رباته.")
            return
        if update.effective_chat.type != "private":
            if update.callback_query:
                await update.callback_query.answer("⛔️ پنل مدیریت فقط در پیوی ربات کار می‌کند.", show_alert=True)
            return
        await func(update, context)
    return wrapper


# ترتیبِ نمایش/دسته‌بندیِ دسترسی‌های قابل‌واگذاری به ادمین‌های فرعی - دقیقاً
# منطبق با دکمه‌های پنلِ اصلی؛ پیش‌فرض برای هر ادمینِ جدید همه خاموشه، مالک
# باید دستی هرکدوم رو که می‌خواد باز کنه.
ADMIN_PERMISSION_CATEGORIES = [
    ("factory_cfg", "🏭 تنظیمات کارخونه و سطوح"),
    ("factory_ranks", "🎖️ مدیریت مقام‌های کارخونه"),
    ("player_edit", "👤 ویرایش پلیر"),
    ("market_prices", "🛒 قیمت‌های روز سوپرمارکت"),
    ("products", "📦 مدیریت محصولات سوپرمارکت"),
    ("bank_cfg", "🏦 تنظیمات بانک"),
    ("currency", "💱 مدیریت ارزها"),
    ("lottery", "🎉 مدیریت قرعه‌کشی"),
    ("myawy", "📱 مدیریت گوشی هاپویی"),
    ("chef", "👨‍🍳 سرآشپز و غذای سگ"),
    ("casino_cfg", "🎰 تنظیماتِ کازینو هاپویی"),
    ("help_guide", "📖 مدیریتِ راهنمایی هاپویی"),
    ("taxi", "🚕 مدیریتِ تاکسیِ هاپویی"),
    ("reports", "📋 گزارش‌های هاپویی (زندان/گزارش)"),
    ("cards", "🎴 مدیریتِ کارتِ هاپویی"),
    ("redeem", "🎁 مدیریتِ کدهای جایزه"),
    ("attack_shop", "🗡 فروشگاه و حمله"),
    ("smuggling", "📦 قاچاق هاپویی"),
    ("war", "⚔️ مدیریتِ جنگ هاپویی"),
    ("heist", "🥷 مدیریتِ سرقت هاپویی"),
    ("mission", "🎯 مدیریتِ مأموریت‌های هاپویی"),
    ("battlepass", "🎖 مدیریتِ بتل‌پس هاپویی"),
    ("referral", "🔗 مدیریتِ سیستمِ دعوت"),
    ("access_levels", "🔐 حداقل سطحِ بخش‌ها (lvl)"),
    ("add_points_self", "➕ افزودن هاپ پوینت به خودم"),
    ("toggle_private", "🔒 روشن/خاموش‌کردنِ پیویِ عمومی"),
]


def _admin_permission_category(callback_data: str):
    """دسته‌ی مجوزِ لازم برای این کالبک رو برمی‌گردونه. None یعنی هر ادمینی
    (فارغ از دسترسیِ خاص) بهش دسترسی داره؛ "OWNER_EXCLUSIVE" یعنی حتی
    ادمین‌های فرعی هم هیچ‌وقت بهش نمی‌رسن (فقط مالکِ اصلی)."""
    prefix = callback_data.split(":")[0]

    if prefix in ("admin_panel", "back_main"):
        return None
    if prefix.startswith("admin_admin"):
        return "OWNER_EXCLUSIVE"

    if prefix == "admin_cfg_edit":
        key = callback_data.split(":", 1)[1] if ":" in callback_data else ""
        if key.startswith("minlvl_"):
            return "access_levels"
        if key.startswith("taxi_"):
            return "taxi"
        if key.startswith("card_"):
            return "cards"
        if key.startswith("chef_"):
            return "chef"
        if key.startswith("bank_"):
            return "bank_cfg"
        if key.startswith("supermarket_"):
            return "market_prices"
        if key.startswith("casino_") or key.startswith("bship_") or key.startswith("gtn_") or key.startswith("mm_"):
            return "casino_cfg"
        if key.startswith("attack_"):
            return "attack_shop"
        if key.startswith("smuggling_"):
            return "smuggling"
        return "factory_cfg"

    direct = {
        "admin_cfg": "factory_cfg",
        "admin_factory_ranks_menu": "factory_ranks",
        "admin_factory_levels_menu": "factory_ranks",
        "admin_player_search": "player_edit",
        "admin_market_prices": "market_prices",
        "admin_products_menu": "products",
        "admin_bank_cfg": "bank_cfg",
        "admin_currency_menu": "currency",
        "admin_lottery_menu": "lottery",
        "admin_myawy_menu": "myawy",
        "admin_chef_cfg": "chef",
        "admin_taxi_menu": "taxi",
        "admin_reports_menu": "reports",
        "admin_cards_menu": "cards",
        "admin_redeem_menu": "redeem",
        "admin_add_points_self": "add_points_self",
        "admin_toggle_private": "toggle_private",
        "admin_casino_cfg": "casino_cfg",
        "admin_help_menu": "help_guide",
        "admin_access_levels_menu": "access_levels",
    }
    if prefix in direct:
        return direct[prefix]

    if prefix.startswith("admin_factory_rank") or prefix.startswith("admin_factory_level"):
        return "factory_ranks"
    if prefix.startswith("admin_player_"):
        return "player_edit"
    if prefix.startswith("admin_product"):
        return "products"
    if prefix.startswith("admin_currency"):
        return "currency"
    if prefix.startswith("admin_lottery"):
        return "lottery"
    if prefix.startswith("admin_myawy_") or prefix.startswith("admin_phone_"):
        return "myawy"
    if prefix.startswith("admin_dogfood"):
        return "chef"
    if prefix.startswith("admin_taxi_"):
        return "taxi"
    if prefix.startswith("admin_report"):
        return "reports"
    if prefix.startswith("admin_cards_"):
        return "cards"
    if prefix.startswith("admin_redeem"):
        return "redeem"
    if prefix.startswith("admin_attack"):
        return "attack_shop"
    if prefix.startswith("admin_smg"):
        return "smuggling"
    if prefix.startswith("admin_war"):
        return "war"
    if prefix.startswith("admin_heist"):
        return "heist"
    if prefix.startswith("admin_mission"):
        return "mission"
    if prefix.startswith("admin_bp_"):
        return "battlepass"
    if prefix.startswith("admin_ref"):
        return "referral"
    if prefix.startswith("admin_help"):
        return "help_guide"

    return "factory_cfg"


def admin_menu_keyboard(private_chat_enabled: bool = True, user_id: int = None):
    status_label = "🟢 پیوی برای عموم: روشن" if private_chat_enabled else "🔴 پیوی برای عموم: خاموش"
    all_items = [
        ("factory_cfg", InlineKeyboardButton("🏭 تنظیمات کارخونه و سطوح", callback_data="admin_cfg")),
        ("factory_ranks", InlineKeyboardButton("🎖️ مدیریت مقام‌های کارخونه", callback_data="admin_factory_ranks_menu")),
        ("player_edit", InlineKeyboardButton("👤 ویرایش پلیر", callback_data="admin_player_search")),
        ("market_prices", InlineKeyboardButton("🛒 قیمت‌های روز سوپرمارکت", callback_data="admin_market_prices")),
        ("products", InlineKeyboardButton("📦 مدیریت محصولات سوپرمارکت", callback_data="admin_products_menu")),
        ("bank_cfg", InlineKeyboardButton("🏦 تنظیمات بانک", callback_data="admin_bank_cfg")),
        ("currency", InlineKeyboardButton("💱 مدیریت ارزها", callback_data="admin_currency_menu")),
        ("lottery", InlineKeyboardButton("🎉 مدیریت قرعه‌کشی", callback_data="admin_lottery_menu")),
        ("myawy", InlineKeyboardButton("📱 مدیریت گوشی هاپویی", callback_data="admin_myawy_menu")),
        ("chef", InlineKeyboardButton("👨‍🍳 سرآشپز و غذای سگ", callback_data="admin_chef_cfg")),
        ("casino_cfg", InlineKeyboardButton("🎰 تنظیماتِ کازینو هاپویی", callback_data="admin_casino_cfg")),
        ("taxi", InlineKeyboardButton("🚕 مدیریتِ تاکسیِ هاپویی", callback_data="admin_taxi_menu")),
        ("reports", InlineKeyboardButton("📋 گزارش‌های هاپویی", callback_data="admin_reports_menu")),
        ("cards", InlineKeyboardButton("🎴 مدیریتِ کارتِ هاپویی", callback_data="admin_cards_menu")),
        ("redeem", InlineKeyboardButton("🎁 مدیریتِ کدهای جایزه", callback_data="admin_redeem_menu")),
        ("attack_shop", InlineKeyboardButton("🗡 فروشگاه و حمله", callback_data="admin_attack_menu")),
        ("smuggling", InlineKeyboardButton("📦 قاچاق هاپویی", callback_data="admin_smg_menu")),
        ("war", InlineKeyboardButton("⚔️ مدیریتِ جنگ هاپویی", callback_data="admin_war_menu")),
        ("heist", InlineKeyboardButton("🥷 مدیریتِ سرقت هاپویی", callback_data="admin_heist_menu")),
        ("mission", InlineKeyboardButton("🎯 مدیریتِ مأموریت‌های هاپویی", callback_data="admin_mission_menu")),
        ("battlepass", InlineKeyboardButton("🎖 مدیریتِ بتل‌پس هاپویی", callback_data="admin_bp_menu")),
        ("referral", InlineKeyboardButton("🔗 مدیریتِ سیستمِ دعوت", callback_data="admin_ref_menu")),
        ("access_levels", InlineKeyboardButton("🔐 حداقل سطحِ بخش‌ها (lvl)", callback_data="admin_access_levels_menu")),
        ("help_guide", InlineKeyboardButton("📖 مدیریتِ راهنمایی هاپویی", callback_data="admin_help_menu")),
        ("add_points_self", InlineKeyboardButton("➕ افزودن هاپ پوینت به خودم", callback_data="admin_add_points_self")),
        ("toggle_private", InlineKeyboardButton(status_label, callback_data="admin_toggle_private")),
    ]
    show_admin_mgmt = True
    if user_id is not None and not is_owner(user_id):
        session = db.get_session()
        try:
            granted = db.admin_permissions(session, user_id)
        finally:
            session.close()
        rows = [[btn] for cat, btn in all_items if cat in granted]
        show_admin_mgmt = False
    else:
        rows = [[btn] for _, btn in all_items]
    if show_admin_mgmt:
        rows.append([InlineKeyboardButton("👥 مدیریتِ ادمین‌ها", callback_data="admin_admins_menu")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="back_main")])
    return InlineKeyboardMarkup(rows)


@strict_owner_only
async def cb_admin_admins_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        admins = session.query(db.AdminUser).all()
        rows = []
        for a in admins:
            u = session.get(db.User, a.user_id)
            name = u.display_name() if u else str(a.user_id)
            perm_count = len(db.admin_permissions(session, a.user_id))
            rows.append([InlineKeyboardButton(
                f"{name} ({perm_count}/{len(ADMIN_PERMISSION_CATEGORIES)} دسترسی)",
                callback_data=f"admin_admin_view:{a.user_id}")])
        rows.append([InlineKeyboardButton("➕ افزودنِ ادمینِ جدید", callback_data="admin_admin_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        session.commit()
        text = "👥 ادمین‌های فرعی:" if admins else "👥 هنوز هیچ ادمینِ فرعی‌ای اضافه نکردی."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@strict_owner_only
async def cb_admin_admin_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(
        update, context,
        "آیدیِ عددی یا یوزرنیمِ (@username) کاربرِ موردنظر رو بفرست.\n"
        "(اگه با یوزرنیم امتحان می‌کنی، باید حداقل یه‌بار قبلاً با بات تعامل داشته باشه.)",
        {"type": "admin_add_target"}, "admin_state",
    )


@strict_owner_only
async def cb_admin_admin_add_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        if not session.get(db.AdminUser, target_id):
            session.add(db.AdminUser(user_id=target_id, added_by=update.effective_user.id, permissions="[]"))
            session.commit()
    finally:
        session.close()
    await cb_admin_admin_view(update, context)


@strict_owner_only
async def cb_admin_admin_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        au = session.get(db.AdminUser, target_id)
        if not au:
            await send_response(update, "این ادمین دیگه وجود نداره.", None)
            return
        u = session.get(db.User, target_id)
        name = u.display_name() if u else str(target_id)
        granted = db.admin_permissions(session, target_id)
        rows = []
        for key, label in ADMIN_PERMISSION_CATEGORIES:
            mark = "✅" if key in granted else "❌"
            rows.append([InlineKeyboardButton(f"{mark} {label}", callback_data=f"admin_admin_toggle:{target_id}:{key}")])
        rows.append([InlineKeyboardButton("🗑 حذفِ این ادمین", callback_data=f"admin_admin_remove_ask:{target_id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_admins_menu")])
        session.commit()
        await send_response(
            update, f"👤 {name}\n\nرو هرکدوم بزنی، بازش/بسته‌ش می‌کنه (✅=باز، ❌=بسته):",
            InlineKeyboardMarkup(rows),
        )
    finally:
        session.close()


@strict_owner_only
async def cb_admin_admin_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _, target_id, key = update.callback_query.data.split(":")
    target_id = int(target_id)
    session = db.get_session()
    try:
        au = session.get(db.AdminUser, target_id)
        if au:
            granted = db.admin_permissions(session, target_id)
            if key in granted:
                granted.discard(key)
            else:
                granted.add(key)
            au.permissions = json.dumps(list(granted))
            session.commit()
    finally:
        session.close()
    await cb_admin_admin_view(update, context)


@strict_owner_only
async def cb_admin_admin_remove_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target_id = int(update.callback_query.data.split(":")[1])
    await send_response(
        update, "مطمئنی می‌خوای این ادمین رو کامل حذف کنی؟",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله", callback_data=f"admin_admin_remove_confirm:{target_id}"),
            InlineKeyboardButton("❌ نه", callback_data=f"admin_admin_view:{target_id}"),
        ]]),
    )


@strict_owner_only
async def cb_admin_admin_remove_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    target_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        au = session.get(db.AdminUser, target_id)
        if au:
            session.delete(au)
            session.commit()
    finally:
        session.close()
    await cb_admin_admins_menu(update, context)


@owner_only
async def cb_admin_panel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        enabled = db.cfg_get(session, "private_chat_enabled") == "1"
    finally:
        session.close()
    await send_response(update, "⚙️ پنل مدیریت:", admin_menu_keyboard(enabled, update.effective_user.id))


@owner_only
async def cb_admin_toggle_private(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """روشن/خاموش‌کردنِ پیوی برای همه (به‌جز خودِ مالک، که همیشه دسترسی داره).
    وقتی خاموشه، ربات تو پیوی به هیچ‌کس (جز مالک) جواب نمی‌ده - فقط تو گروه
    کار می‌کنه. برای گروه‌هایی که می‌خوان فقط تو چت باهاش کار بشه، بدونِ اینکه
    کسی از پیوی مستقیم بره سراغِ منوها."""
    session = db.get_session()
    try:
        enabled = db.cfg_get(session, "private_chat_enabled") == "1"
        db.cfg_set(session, "private_chat_enabled", "0" if enabled else "1")
    finally:
        session.close()
    await cb_admin_panel(update, context)


# ---------------------------------------------------------------------------
# تنظیمات کارخونه / سطوح
# ---------------------------------------------------------------------------

CFG_FACTORY_KEYS = [
    ("total_levels", "🔢 تعداد کل سطوح شخصیت (جدا از سطح کارخونه)"),
    ("level_base_xp", "📐 فاصله‌ی سطح ۱ به ۲ (XP)"),
    ("level_growth", "📈 ضریب رشد خطی فاصله‌ی سطوح"),
    ("level_quad", "📊 ضریب رشد درجه‌دوم فاصله‌ی سطوح"),
    ("production_base", "🏭 تولید پایه در دقیقه (پیش‌فرض سطح‌هایی که دستی ست نشدن)"),
    ("production_increment", "⬆️ افزایش تولید به‌ازای هر سطح (پیش‌فرض)"),
    ("production_upgrade_base_cost", "💵 هزینه‌ی ارتقای اول کارخونه (پیش‌فرض)"),
    ("production_upgrade_growth", "📈 ضریب رشد هزینه‌ی ارتقا (پیش‌فرض)"),
    ("factory_capacity_base", "🧯 ظرفیت کارخونه در سطح ۱ (پیش‌فرض)"),
    ("factory_capacity_increment", "🧯 افزایش ظرفیت به‌ازای هر سطح (پیش‌فرض)"),
]


@owner_only
async def cb_admin_cfg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = ["🏭 تنظیمات فعلی کارخونه و سطوح:\n"]
        rows = []
        for key, label in CFG_FACTORY_KEYS:
            val = db.cfg_get(session, key)
            lines.append(f"• {label}: {val}")
            rows.append([InlineKeyboardButton(f"✏️ {label}", callback_data=f"admin_cfg_edit:{key}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_cfg_edit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    key = update.callback_query.data.split(":")[1]
    all_labels = dict(CFG_FACTORY_KEYS) | dict(CFG_MARKET_KEYS) | dict(CFG_BANK_KEYS) | dict(CFG_CHEF_KEYS) | dict(CFG_TAXI_KEYS) | dict(CFG_CARDS_KEYS) | dict(CFG_CASINO_KEYS) | dict(CFG_LOTTERY_KEYS) | dict(CFG_ATTACK_KEYS) | dict(CFG_ACCESS_LEVEL_KEYS) | {"smuggling_inactivity_timeout_seconds": "⏱ مهلتِ بی‌حرکتیِ قاچاق (ثانیه)", "smuggling_fail_jail_minutes": "🔒 دقیقه‌ی زندانِ بعدِ شکستِ قاچاق", "smuggling_fail_jail_bail": "💸 وثیقه‌ی زندانِ بعدِ شکستِ قاچاق", "jail_spam_bail": "💸 وثیقه‌ی زندانِ اسپم", "jail_default_bail": "💸 وثیقه‌ی پیش‌فرضِ زندان", "uno_turn_seconds": "⏱ مهلتِ هر نوبتِ اونو (ثانیه)", "uno_max_missed_turns": "❌ تعدادِ نوبتِ ردشده تا حذف از اونو", "uno_lobby_timeout_seconds": "⏳ مهلتِ لابیِ اونو (ثانیه)", "uno_start_hand_size": "🃏 تعدادِ کارتِ اولیه‌ی اونو", "uno_max_turns": "⏱ سقفِ کلِ نوبت‌هایِ اونو"}
    label = all_labels.get(key, key)
    await ask_for_input(update, context, f"✏️ مقدار جدید برای «{label}» رو بفرست (عدد):", {"type": "cfg", "key": key}, "admin_state")


# ---------------------------------------------------------------------------
# حداقلِ سطح (lvl) لازم برای هر بخشِ ربات
# ---------------------------------------------------------------------------

CFG_ACCESS_LEVEL_KEYS = [(f"minlvl_{key}", f"🔐 {label}") for key, label in db.MODULE_LEVEL_GATES.items()]


@owner_only
async def cb_admin_access_levels_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = [
            "🔐 حداقلِ سطح (lvl) لازم برای هر بخش\n",
            "روی هرکدوم بزنی می‌تونی حداقل لولِ لازم براش رو عوض کنی. عددِ ۰ یعنی "
            "بدونِ محدودیت (همه، از لولِ ۱ هم می‌تونن استفاده کنن). نوشتنِ خودِ "
            "«هاپ» هیچ‌وقت محدود نمی‌شه.\n",
        ]
        rows = []
        for key, label in CFG_ACCESS_LEVEL_KEYS:
            val = db.cfg_get(session, key)
            lines.append(f"• {label}: {val}")
            rows.append([InlineKeyboardButton(f"✏️ {label} ({val})", callback_data=f"admin_cfg_edit:{key}")])
        lines.append(
            "\n♻️ اگه کسایی قبل از اضافه‌شدنِ سیستمِ لول، هاپ زده بودن، لولشون حساب "
            "نشده. با دکمه‌ی پایین لولِ همه از رویِ تعدادِ هاپشون از نو ساخته می‌شه."
        )
        rows.append([InlineKeyboardButton("♻️ بروزرسانی لول کل بر اساس هاپ", callback_data="admin_lvl_recalc_ask")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_lvl_recalc_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """صفحه‌ی تاییدِ بازسازیِ لولِ همه‌ی پلیرها."""
    session = db.get_session()
    try:
        total = session.query(db.User).count()
    finally:
        session.close()
    text = (
        "♻️ بروزرسانی لول کل بر اساس هاپ\n\n"
        f"لولِ همه‌ی {fmt(total)} پلیر از رویِ تعدادِ «هاپ هاپ»شون از نو حساب می‌شه:\n\n"
        f"لول = تعدادِ هاپ ÷ {db.HOPS_PER_LVL}\n"
        f"(مثلا {db.HOPS_PER_LVL * 2} هاپ ⟵ لول ۲؛ حداقلِ لول همیشه ۱ می‌مونه)\n\n"
        "⚠️ توجه: این کار لولِ دستی‌ای که خودت از «ویرایش پلیر» ست کرده بودی رو هم "
        "بازنویسی می‌کنه و برگشت‌پذیر نیست.\n\n"
        "مطمئنی؟"
    )
    rows = [[
        InlineKeyboardButton("✅ بله، بازسازی کن", callback_data="admin_lvl_recalc_do"),
        InlineKeyboardButton("❌ خیر", callback_data="admin_access_levels_menu"),
    ]]
    await send_response(update, text, InlineKeyboardMarkup(rows))


@owner_only
async def cb_admin_lvl_recalc_do(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """لولِ همه رو بر اساسِ hop_count//HOPS_PER_LVL از نو می‌سازه.

    این همون باگیه که ازش گفتی: کسایی که قبل از اضافه‌شدنِ سیستمِ لول هاپ زده
    بودن، register_hop_for_lvl براشون اجرا نشده بود و رو لولِ ۱ مونده بودن.
    با یه UPDATEِ مستقیم (نه لود‌کردنِ تک‌تکِ کاربرها تو حافظه) انجام می‌شه تا
    حتی با ده‌ها هزار پلیر هم آنی تموم شه.
    """
    session = db.get_session()
    try:
        per = db.HOPS_PER_LVL
        if db.IS_PG:
            _sql = ("UPDATE users SET lvl = GREATEST(1, LEAST(:maxlvl, "
                    "FLOOR(COALESCE(hop_count, 0) / CAST(:per AS double precision))))")
        else:
            _sql = "UPDATE users SET lvl = MAX(1, MIN(:maxlvl, COALESCE(hop_count, 0) / :per))"
        session.execute(sa_text(_sql), {"maxlvl": db.MAX_LVL, "per": per})
        session.commit()
        changed = session.query(db.User).filter(db.User.lvl > 1).count()
        total = session.query(db.User).count()
    finally:
        session.close()
    await send_response(
        update,
        f"✅ لولِ همه بازسازی شد.\n\n"
        f"کلِ پلیرها: {fmt(total)}\n"
        f"پلیرهایی که الان بالای لول ۱ هستن: {fmt(changed)}",
        InlineKeyboardMarkup([[InlineKeyboardButton("🔙 بازگشت", callback_data="admin_access_levels_menu")]]),
    )


# ---------------------------------------------------------------------------
# مدیریت مقام‌ها و سطوحِ کارخونه
# ---------------------------------------------------------------------------

# ---------------------------------------------------------------------------
# مدیریت مقام‌ها و سطوحِ کارخونه
# ---------------------------------------------------------------------------

@owner_only
async def cb_admin_factory_ranks_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import economy
    session = db.get_session()
    try:
        ranks = economy.factory_ranks_ordered(session)
        rows = []
        for r in ranks:
            rows.append([InlineKeyboardButton(
                f"{r.order}. {r.name} ({r.num_levels} سطح)", callback_data=f"admin_factory_rank_view:{r.id}")])
        rows.append([InlineKeyboardButton("➕ افزودن مقام جدید", callback_data="admin_factory_rank_add")])
        rows.append([InlineKeyboardButton("📶 سطوح مشترک (تولید/ظرفیت/هزینه)", callback_data="admin_factory_levels_menu")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        text = (
            "🎖️ مدیریت مقام‌های کارخونه\n\n"
            "سطح‌ها بینِ مقام‌ها مشترکن: سطح ۵ مقامِ اول دقیقا همون مقدارِ سطح ۵ "
            "مقامِ دومه؛ تنها فرقِ مقام‌ها تعداد سطح‌هاشونه (مقامی با سطوحِ بیشتر، "
            "امکانِ رسیدن به تولیدِ بالاتر رو می‌ده). با رسیدن به آخرِ سطوحِ یه "
            "مقام و تاییدِ کاربر، می‌ره مقامِ بعد و تولیدش (چون از سطح ۱ دوباره "
            "شروع می‌شه) ریست می‌شه."
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_factory_rank_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "📝 اسم مقام جدید رو بفرست (مثلا: 🐕‍🦺 سگ افسانه‌ای):", {"type": "factory_rank_add_name"}, "admin_state")


@owner_only
async def cb_admin_factory_rank_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import economy
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        rank = session.get(db.FactoryRank, rid)
        if not rank:
            await send_response(update, "این مقام پیدا نشد.", None)
            return
        ranks = economy.factory_ranks_ordered(session)

        rows = [
            [InlineKeyboardButton("✏️ تغییر اسم مقام", callback_data=f"admin_factory_rank_rename:{rid}")],
            [InlineKeyboardButton("➕ افزودن یک سطح به این مقام", callback_data=f"admin_factory_rank_addlevel:{rid}")],
        ]
        if rank.num_levels > 1:
            rows.append([InlineKeyboardButton("➖ کم‌کردن یک سطح از این مقام", callback_data=f"admin_factory_rank_removelevel:{rid}")])
        if len(ranks) > 1:
            rows.append([InlineKeyboardButton("🗑️ حذف این مقام", callback_data=f"admin_factory_rank_delete:{rid}")])
        rows.append([InlineKeyboardButton("📶 سطوح مشترک", callback_data="admin_factory_levels_menu")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_factory_ranks_menu")])

        text = (
            f"{rank.name}\n"
            f"ترتیب مقام: {rank.order}\n"
            f"تعداد سطح: {rank.num_levels} (از سطح ۱ تا {rank.num_levels})\n\n"
            "مقدارِ هر سطح (تولید/ظرفیت/هزینه) از «سطوح مشترک» خونده می‌شه، چون "
            "بینِ همه‌ی مقام‌ها یکیه."
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_factory_rank_rename(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "✏️ اسم جدید مقام رو بفرست:", {"type": "factory_rank_rename", "id": rid}, "admin_state")


@owner_only
async def cb_admin_factory_rank_addlevel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        rank = session.get(db.FactoryRank, rid)
        if rank:
            rank.num_levels += 1
            session.commit()
    finally:
        session.close()
    await cb_admin_factory_rank_view(update, context)


@owner_only
async def cb_admin_factory_rank_removelevel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import economy
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        rank = session.get(db.FactoryRank, rid)
        if rank and rank.num_levels > 1:
            rank.num_levels -= 1
            # کاربرهایی که تو سطحِ حذف‌شده بودن رو به آخرین سطحِ معتبرِ همین مقام برمی‌گردونیم
            stuck = session.query(db.User).filter(
                db.User.factory_rank_order == rank.order,
                db.User.factory_level > rank.num_levels,
            ).all()
            for u in stuck:
                u.factory_level = rank.num_levels
                economy.sync_user_production(session, u)
            session.commit()
    finally:
        session.close()
    await cb_admin_factory_rank_view(update, context)


@owner_only
async def cb_admin_factory_rank_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import economy
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        ranks = economy.factory_ranks_ordered(session)
        rank = session.get(db.FactoryRank, rid)
        if rank and len(ranks) > 1:
            deleted_order = rank.order
            session.delete(rank)
            session.flush()
            remaining = session.query(db.FactoryRank).filter(db.FactoryRank.order > deleted_order).order_by(db.FactoryRank.order).all()
            for r in remaining:
                r.order -= 1
            new_max_order = len(ranks) - 1
            fallback_order = max(1, min(deleted_order - 1, new_max_order)) if new_max_order else 1
            # کاربرهایی که دقیقا تو مقامِ حذف‌شده بودن رو می‌بریم مقامِ قبلی (رو ماکسِ سطحش)
            stuck_users = session.query(db.User).filter(db.User.factory_rank_order == deleted_order).all()
            fallback_rank = session.query(db.FactoryRank).filter_by(order=fallback_order).first()
            for u in stuck_users:
                u.factory_rank_order = fallback_order
                u.factory_level = fallback_rank.num_levels if fallback_rank else 1
                economy.sync_user_production(session, u)
            # کاربرهایی که مقامشون بعد از حذف‌شده بود رو یکی عقب می‌کشیم (همون مقام، فقط ترتیبش عوض شده)
            shifted_users = session.query(db.User).filter(db.User.factory_rank_order > deleted_order).all()
            for u in shifted_users:
                u.factory_rank_order -= 1
            session.commit()
    finally:
        session.close()
    await cb_admin_factory_ranks_menu(update, context)


@owner_only
async def cb_admin_factory_levels_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import economy
    session = db.get_session()
    try:
        ranks = economy.factory_ranks_ordered(session)
        max_level = max((r.num_levels for r in ranks), default=0)
        rows = []
        for lvl in range(1, max_level + 1):
            ov = session.get(db.FactoryLevelDef, lvl)
            tag = " ✏️" if ov else ""
            rows.append([InlineKeyboardButton(f"سطح {lvl}{tag}", callback_data=f"admin_factory_level_view:{lvl}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_factory_ranks_menu")])
        text = (
            "📶 سطوح مشترکِ کارخونه\n\n"
            "این سطوح بینِ همه‌ی مقام‌ها مشترکن (سطح N تو هر مقامی همین مقدارِ "
            "تولید/ظرفیت/هزینه رو داره). ✏️ یعنی دستی تنظیم شده، وگرنه از "
            "فرمولِ پیش‌فرض محاسبه می‌شه.\nبرای اضافه‌کردنِ سطحِ جدید، از «➕ افزودن "
            "سطح» تو صفحه‌ی همون مقام استفاده کن."
        )
        if not rows[:-1]:
            text += "\n\n(هنوز هیچ مقامی سطح نداره.)"
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_factory_level_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lvl = int(update.callback_query.data.split(":")[1])
    await _show_factory_level(update, context, lvl)


async def _show_factory_level(update: Update, context: ContextTypes.DEFAULT_TYPE, lvl: int):
    import economy
    session = db.get_session()
    try:
        production, capacity, cost = economy.factory_level_values(session, lvl)
        ov = session.get(db.FactoryLevelDef, lvl)

        rows = [
            [InlineKeyboardButton("✏️ تولید در دقیقه", callback_data=f"admin_factory_level_edit:{lvl}:production")],
            [InlineKeyboardButton("✏️ ظرفیت", callback_data=f"admin_factory_level_edit:{lvl}:capacity")],
            [InlineKeyboardButton("✏️ هزینه‌ی ارتقا به این سطح", callback_data=f"admin_factory_level_edit:{lvl}:cost")],
        ]
        if ov:
            rows.append([InlineKeyboardButton("♻️ برگردوندن به پیش‌فرض", callback_data=f"admin_factory_level_reset:{lvl}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_factory_levels_menu")])

        source = "دستی ✏️" if ov else "فرمول پیش‌فرض"
        text = (
            f"🔧 سطح {lvl} (مشترک بینِ همه‌ی مقام‌ها) — منبع: {source}\n\n"
            f"⚙️ تولید در دقیقه: {fmt(production)} 🪙\n"
            f"🧯 ظرفیت: {fmt(capacity)} 🪙\n"
            f"💵 هزینه‌ی ارتقا به این سطح: {fmt(cost)} 🪙"
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_factory_level_edit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _, lvl, field = update.callback_query.data.split(":")
    labels = {
        "production": "مقدار تولید در دقیقه رو بفرست (عدد):",
        "capacity": "مقدار ظرفیت رو بفرست (عدد):",
        "cost": "هزینه‌ی ارتقا به این سطح رو بفرست (عدد):",
    }
    await ask_for_input(
        update, context, f"✏️ {labels.get(field, 'مقدار جدید رو بفرست:')}",
        {"type": "factory_level_edit", "level": int(lvl), "field": field}, "admin_state",
    )


@owner_only
async def cb_admin_factory_level_reset(update: Update, context: ContextTypes.DEFAULT_TYPE):
    lvl = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        ov = session.get(db.FactoryLevelDef, lvl)
        if ov:
            session.delete(ov)
            session.commit()
    finally:
        session.close()
    await _show_factory_level(update, context, lvl)


# ---------------------------------------------------------------------------
# قیمت‌های سوپرمارکت
# ---------------------------------------------------------------------------

CFG_MARKET_KEYS = [
    ("supermarket_open_cost", "🏗️ هزینه‌ی ساخت سوپرمارکت"),
    ("supermarket_upgrade_base_cost", "💵 هزینه‌ی ارتقای اول"),
    ("supermarket_upgrade_growth", "📈 ضریب رشد هزینه‌ی ارتقا"),
    ("supermarket_prod_increment", "⬆️ افزایش سرعت تولید به‌ازای هر ارتقا"),
    ("price_cat_meat", "🐱 قیمت روز گوشت گربه"),
    ("price_cinnamon_cucumber", "🥒 قیمت روز دارچین خیار"),
    ("price_banana", "🍌 قیمت روز موز"),
    ("price_dog_egg", "🥚 قیمت روز تخم سگ"),
    ("market_produce_per_level", "📈 تعداد محصول لازم برای رفتن به سطح بعدی محصولات"),
]


@owner_only
async def cb_admin_market_prices(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = ["🛒 تنظیمات فعلی سوپرمارکت:\n"]
        rows = []
        for key, label in CFG_MARKET_KEYS:
            val = db.cfg_get(session, key)
            lines.append(f"• {label}: {val}")
            rows.append([InlineKeyboardButton(f"✏️ {label}", callback_data=f"admin_cfg_edit:{key}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


CFG_BANK_KEYS = [
    ("bank_open_cost", "🏦 هزینه‌ی افتتاح بانک"),
    ("bank_daily_interest_pct", "📈 درصد سود روزانه (ساعت ۹ صبح)"),
    ("bank_interest_cap", "🧢 حداکثر سود (سقفِ بالانسِ مشمولِ سود)"),
    ("bank_transfer_min_amount", "🔁 حداقلِ مبلغِ انتقالِ هاپ‌پوینت"),
]


@owner_only
async def cb_admin_bank_cfg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = ["🏦 تنظیمات فعلی بانک:\n"]
        rows = []
        for key, label in CFG_BANK_KEYS:
            val = db.cfg_get(session, key)
            lines.append(f"• {label}: {val}")
            rows.append([InlineKeyboardButton(f"✏️ {label}", callback_data=f"admin_cfg_edit:{key}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


CFG_CHEF_KEYS = [
    ("chef_dog_food_capacity_per_rank", "🐕 ظرفیتِ غذای سگ به‌ازای هر مقام (واحد)"),
    ("chef_dog_food_minutes_per_unit", "🐕 هر واحدِ غذا چند دقیقه طول می‌کشه تموم بشه"),
    ("chef_term_days", "📅 طولِ دورهِ سرآشپزی (روز)"),
    ("chef_max_tax_pct", "💰 حداکثر درصدِ مالیاتِ سرآشپز"),
    ("chef_max_candidates", "👥 حداکثر تعدادِ کاندید"),
    ("chef_election_hours", "⏳ مدتِ رای‌گیری (ساعت)"),
    ("chef_recall_votes_needed", "🚫 تعدادِ رایِ لازم برای برکناری"),
]


@owner_only
async def cb_admin_chef_cfg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = ["👨‍🍳 تنظیماتِ سرآشپز و غذای سگ:\n"]
        rows = []
        for key, label in CFG_CHEF_KEYS:
            val = db.cfg_get(session, key)
            lines.append(f"• {label}: {val}")
            rows.append([InlineKeyboardButton(f"✏️ {label}", callback_data=f"admin_cfg_edit:{key}")])
        rows.append([InlineKeyboardButton("🍖 مدیریتِ انواعِ غذا", callback_data="admin_dogfoods_menu")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# تنظیماتِ کازینو هاپویی
# ---------------------------------------------------------------------------

CFG_CASINO_KEYS = [
    ("casino_cooldown_minutes", "⏳ فاصله‌ی اجباریِ بینِ کازینوها برای هر بازیکن (دقیقه، ۰ یعنی خاموش)"),
    ("casino_join_timeout_seconds", "⌛ مهلتِ پیوستن به لابی (ثانیه)"),
    ("casino_max_bet", "💰 حداکثر مبلغِ مجازِ قمار (۰ یعنی بدونِ محدودیت)"),
    ("casino_rr_blank_bullets", "🔫 رولت روسی: تعدادِ تیرِ مشقی (۰ تا ۲۰)"),
    ("casino_rr_live_bullets", "🔫 رولت روسی: تعدادِ تیرِ جنگی (۱ تا ۱۰)"),
    ("casino_rr_spin_wait_seconds", "🔄 رولت روسی: انتظار برای چرخاندنِ خشابِ تفنگ (ثانیه، ۰ یعنی بدونِ انتظار)"),
    ("casino_rr_turn_seconds", "⏱ رولت روسی: مهلتِ شلیکِ هر نوبت، از بعدِ چرخاندنِ خشاب (ثانیه)"),
    ("casino_mafia_night_seconds", "🌙 مافیا/گرگینه: مهلتِ فازِ شب (ثانیه)"),
    ("casino_mafia_day_seconds", "☀️ مافیا/گرگینه: مهلتِ فازِ روز/رای‌گیری (ثانیه)"),
    ("casino_mafia_day_speak_seconds", "🎙 مافیا/گرگینه: مهلتِ هر نوبتِ شیفتِ صحبتِ روز (ثانیه، فقط لابیِ محلی)"),
    ("bship_ships_per_player", "🚢 تعدادِ کشتیِ هر بازیکن تو نبردِ دریایی"),
    ("bship_max_turns", "🎯 حداکثر نوبتِ هر بازیکن تو نبردِ دریایی"),
    ("gtn_max_number", "🔢 سقفِ بازه‌ی عدد تو حدسِ عدد (۱ تا این عدد)"),
    ("gtn_max_guesses", "🔢 حداکثر تعدادِ حدس تو حدسِ عدد"),
    ("mm_code_length", "🎨 طولِ کدِ مخفی تو رمزیاب"),
    ("mm_palette_size", "🎨 تعدادِ رنگ‌های رمزیاب (حداکثر ۸)"),
    ("mm_max_turns", "🎨 حداکثر نوبتِ هر بازیکن تو رمزیاب"),
]


@owner_only
async def cb_admin_casino_cfg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = ["🎰 تنظیماتِ کازینو هاپویی:\n"]
        rows = []
        for key, label in CFG_CASINO_KEYS:
            val = db.cfg_get(session, key)
            lines.append(f"• {label}: {val}")
            rows.append([InlineKeyboardButton(f"✏️ {label}", callback_data=f"admin_cfg_edit:{key}")])
        import roulette
        import mafia
        rr = roulette.rr_settings(session)
        mf = mafia.mf_settings(session)
        lines.append(f"\n🔫 رولت روسی الان: {rr['blank']} مشقی + {rr['live']} جنگی = مجموع "
                     f"{rr['blank'] + rr['live']} تیر | {rr['wait']} ثانیه انتظارِ چرخاندنِ خشاب، بعدش {rr['turn']} ثانیه وقتِ شلیک "
                     "(تغییرات از نوبتِ بعدیِ بازی‌هایِ درحال‌اجرا و برایِ بازی‌هایِ جدید اعمال می‌شه).")
        lines.append(f"🕵️ مافیا/گرگینه الان: شب {mf['night']} ثانیه، روز {mf['day']} ثانیه، "
                     f"هر نوبتِ شیفتِ صحبت {mf['day_speak']} ثانیه "
                     "(تغییرات از فازِ بعدیِ بازی‌هایِ درحال‌اجرا اعمال می‌شه).")
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مدیریتِ انواعِ غذای سگ
# ---------------------------------------------------------------------------

@owner_only
async def cb_admin_dogfoods_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        foods = session.query(db.DogFood).all()
        rows = []
        for f in foods:
            status = "✅" if f.is_active else "⛔️"
            rows.append([InlineKeyboardButton(
                f"{status} {f.name} | {fmt(f.price)}🪙 | {fmt(f.prep_minutes)}دقیقه/واحد",
                callback_data=f"admin_dogfood_view:{f.id}")])
        rows.append([InlineKeyboardButton("➕ افزودنِ غذای جدید", callback_data="admin_dogfood_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_chef_cfg")])
        text = "🍖 انواعِ غذای سگ:" if foods else "🍖 هنوز هیچ غذایی تعریف نکردی."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_dogfood_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "📝 اسمِ غذای جدید رو بفرست (مثلا: 🥩 استیک گوشت):", {"type": "dogfood_add_name"}, "admin_state")


@owner_only
async def cb_admin_dogfood_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    fid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        f = session.get(db.DogFood, fid)
        if not f:
            await send_response(update, "این غذا پیدا نشد.", None)
            return
        rows = [
            [InlineKeyboardButton("✏️ تغییرِ قیمت", callback_data=f"admin_dogfood_editprice:{f.id}")],
            [InlineKeyboardButton("✏️ تغییرِ زمانِ آماده‌سازی (دقیقه/واحد)", callback_data=f"admin_dogfood_editprep:{f.id}")],
            [InlineKeyboardButton("✏️ تغییرِ ارزشِ سیری (واحدِ ظرفیت)", callback_data=f"admin_dogfood_editfeed:{f.id}")],
            [InlineKeyboardButton("⛔️ غیرفعال کردن" if f.is_active else "✅ فعال کردن", callback_data=f"admin_dogfood_toggle:{f.id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_dogfoods_menu")],
        ]
        text = (
            f"{f.name}\n"
            f"💵 قیمت: {fmt(f.price)} 🪙/واحد\n"
            f"⏳ زمانِ آماده‌سازی: {fmt(f.prep_minutes)} دقیقه/واحد\n"
            f"🍖 ارزشِ سیری: هر واحدش {f.feed_value} واحد از ظرفیتِ غذای سگ رو پر می‌کنه"
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_dogfood_editprice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    fid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "💵 قیمتِ جدید رو بفرست:", {"type": "dogfood_editprice", "id": fid}, "admin_state")


@owner_only
async def cb_admin_dogfood_editprep(update: Update, context: ContextTypes.DEFAULT_TYPE):
    fid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "⏳ زمانِ آماده‌سازیِ هر واحد رو به دقیقه بفرست:", {"type": "dogfood_editprep", "id": fid}, "admin_state")


@owner_only
async def cb_admin_dogfood_editfeed(update: Update, context: ContextTypes.DEFAULT_TYPE):
    fid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "🍖 هر واحدِ این غذا چند واحد از ظرفیتِ غذای سگ رو پر کنه؟ یه عدد صحیح بفرست (مثلا 1 یا 2):", {"type": "dogfood_editfeed", "id": fid}, "admin_state")


@owner_only
async def cb_admin_dogfood_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    fid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        f = session.get(db.DogFood, fid)
        if f:
            f.is_active = not f.is_active
            session.commit()
    finally:
        session.close()
    await cb_admin_dogfood_view(update, context)


# ---------------------------------------------------------------------------
# فروشگاه و حمله (نگاه کن به attack.py برای منطقِ خودِ بازی - اینجا فقط
# ساخت/ویرایش/فعال‌سازی/حذفِ آیتم‌های ShopItem از پنلِ ادمینه)
# ---------------------------------------------------------------------------

# فرمتِ فیلدهای هر دسته برای ساختِ آیتمِ جدید با یه پیامِ پیپ‌جدا (name, uses
# desc field اسمِ ستونِ واقعیِ ShopItem هستن - با ** به سازنده پاس داده می‌شن)
_ATTACK_FIELD_SPECS = {
    "guard": ["name", "description", "price", "level", "power", "uses"],
    "gun": ["name", "description", "price", "level", "power", "uses"],
    "smoke": ["name", "description", "price", "level", "pct", "uses"],
    "item": ["name", "description", "price", "uses"],
    "booster": ["name", "description", "price", "pct", "duration_minutes"],
}
_ATTACK_FIELD_HINT = {
    "guard": "نام | توضیح | قیمت | سطح(یا -) | قدرتِ دفاع | تعدادِ استفاده(یا - برای نامحدود)",
    "gun": "نام | توضیح | قیمت | سطح(یا -) | قدرتِ حمله | تعدادِ استفاده(یا - برای نامحدود)",
    "smoke": "نام | توضیح | قیمت | سطح(یا -) | درصدِ کاهشِ شانسِ فرار | تعدادِ استفاده(یا -)",
    "item": "نام | توضیح | قیمت | تعدادِ استفاده(یا - برای نامحدود)",
    "booster": "نام | توضیح | قیمت | درصدِ اثر | مدت به دقیقه",
}
_ATTACK_NUMERIC_FIELDS = {"price", "level", "power", "pct", "uses", "duration_minutes"}
_ATTACK_OPTIONAL_FIELDS = {"level", "power", "pct", "uses", "duration_minutes"}

CFG_ATTACK_KEYS = [
    ("attack_min_target_wealth", "💰 حداقلِ مجموعِ داراییِ هدف برای قابلِ‌حمله‌بودن"),
    ("attack_backpack_max_slots", "🎒 سقفِ اسلات‌هایِ کوله‌پشتی"),
    ("attack_hostage_duration_minutes", "⏳ مدتِ گروگان‌گیری (دقیقه)"),
    ("attack_hostage_check_interval_minutes", "🏃 فاصله‌ی بررسیِ شانسِ فرار (دقیقه)"),
    ("attack_hostage_base_escape_pct", "🏃 شانسِ پایه‌ی فرار (٪)"),
    ("attack_hostage_ransom_amount", "💸 مبلغِ پرداختِ کمیسیون"),
    ("attack_hostage_victim_production_mult", "🔒 تولیدِ Hop Manager قربانی (٪ از عادی)"),
    ("attack_hostage_attacker_production_mult", "🎯 تولیدِ Hop Manager مهاجم (٪ از عادی)"),
    ("attack_fail_defender_penalty_minutes", "⚠️ مدتِ جریمه‌ی شکستِ تلاش (دقیقه)"),
    ("attack_fail_defender_penalty_pct", "⚠️ تولیدِ مدافع بعدِ شکستِ تلاش (٪)"),
    ("attack_fail_transfer_amount", "💸 مبلغِ انتقالِ مدافع←مهاجم بعدِ شکستِ تلاش"),
    ("attack_killed_penalty_minutes", "💀 مدتِ جریمه‌ی کشته‌شدنِ مهاجم (دقیقه)"),
    ("attack_killed_penalty_pct", "💀 تولیدِ مهاجمِ کشته‌شده (٪ از عادی)"),
    ("attack_guard_hostage_divisor", "🛡 ضریبِ تقسیمِ قدرتِ محافظ تو گروگان‌گیری"),
    ("attack_max_hostage_per_day", "🔫 مکسِ گروگان‌گیریِ موفق در روز (برای هر مهاجم)"),
    ("attack_max_victim_hostage_per_day", "🎯 مکسِ دفعاتی که یه نفر می‌تونه در روز گروگان گرفته بشه"),
    ("attack_inactivity_timeout_seconds", "⏱ مهلتِ بی‌حرکتی قبلِ لغوِ خودکار (ثانیه)"),
    ("attack_wrong_guess_divisor", "❌ ضریبِ تقسیمِ آسیبِ حدسِ غلط"),
    ("attack_max_wrong_guesses", "❌ حداکثرِ تعدادِ خطای مجاز"),
    ("attack_battle_hp", "❤️ HP اولیه‌ی نبردِ گروگان‌گیری"),
    ("duel_battle_hp", "❤️ HP اولیه‌ی نبردِ تن‌به‌تن"),
    ("duel_counter_attack_bonus_pct", "🔄 درصدِ دمیجِ ضدحمله در برابرِ حمله"),
    ("duel_defend_reduction_pct", "🛡 درصدِ دمیجِ مدافع در برابرِ حمله"),
    ("duel_counter_vs_counter_pct", "🔄 درصدِ دمیج تو ضدحمله-به-ضدحمله"),
]


async def cb_admin_attack_cfg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = ["⚙️ تنظیماتِ کلیِ فروشگاه و حمله:\n"]
        rows = []
        for key, label in CFG_ATTACK_KEYS:
            val = db.cfg_get(session, key)
            lines.append(f"• {label}: {val}")
            rows.append([InlineKeyboardButton(f"✏️ {label}", callback_data=f"admin_cfg_edit:{key}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_attack_menu")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


def _parse_attack_fields(cat, parts):
    spec = _ATTACK_FIELD_SPECS[cat]
    parsed = {}
    for field, raw in zip(spec, parts):
        raw = raw.strip()
        if field in ("name", "description"):
            if field == "name" and not raw:
                raise ValueError("اسم نمی‌تونه خالی باشه")
            parsed[field] = raw
            continue
        parsed[field] = _parse_attack_single_field(field, raw)
    return parsed


def _parse_attack_single_field(field, raw):
    raw = raw.strip()
    if field in ("name", "description"):
        return raw
    if field in _ATTACK_OPTIONAL_FIELDS and raw == "-":
        return None
    try:
        value = float(raw)
    except ValueError:
        raise ValueError(f"مقدارِ «{raw}» برای فیلدِ {field} عددی نیست")
    if field == "level" or field == "uses":
        value = int(value)
    if field == "duration_minutes":
        value = int(value)
    if field in ("price",) and value <= 0:
        raise ValueError("قیمت باید بزرگ‌تر از صفر باشه")
    return value


def _attack_item_summary(item: db.ShopItem):
    bits = [f"💵 {fmt(item.price)} 🪙"]
    if item.level is not None:
        bits.append(f"سطح {item.level}")
    if item.power is not None:
        bits.append(f"قدرت {fmt(item.power)}")
    if item.pct is not None:
        bits.append(f"٪{fmt(item.pct)}")
    if item.uses is not None:
        bits.append(f"{item.uses} استفاده")
    else:
        bits.append("نامحدود")
    if item.duration_minutes is not None:
        bits.append(f"{item.duration_minutes} دقیقه")
    return " | ".join(bits)


async def cb_admin_attack_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = [[InlineKeyboardButton(attack.CATEGORY_LABELS[c], callback_data=f"admin_attack_cat:{c}")] for c in attack.CATEGORIES]
    rows.append([InlineKeyboardButton("⚙️ تنظیماتِ کلی", callback_data="admin_attack_cfg")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
    await send_response(update, "🗡 فروشگاه و حمله - یه دسته انتخاب کن:", InlineKeyboardMarkup(rows))


async def cb_admin_attack_cat(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cat = update.callback_query.data.split(":")[1]
    await _render_attack_cat(update, context, cat)


async def _render_attack_cat(update: Update, context: ContextTypes.DEFAULT_TYPE, cat: str):
    session = db.get_session()
    try:
        items = session.query(db.ShopItem).filter_by(category=cat).order_by(db.ShopItem.price).all()
        rows = []
        for it in items:
            status = "✅" if it.active else "⛔️"
            rows.append([InlineKeyboardButton(f"{status} {it.name} | {fmt(it.price)}🪙", callback_data=f"admin_attack_view:{it.id}")])
        rows.append([InlineKeyboardButton("➕ افزودنِ آیتمِ جدید", callback_data=f"admin_attack_add:{cat}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_attack_menu")])
        text = f"{attack.CATEGORY_LABELS[cat]}:" if items else f"{attack.CATEGORY_LABELS[cat]} - هنوز هیچ آیتمی نساختی."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_attack_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cat = update.callback_query.data.split(":")[1]
    if cat == "booster":
        rows = [
            [InlineKeyboardButton("💰 بوسترِ پول", callback_data="admin_attack_add_booster_type:money")],
            [InlineKeyboardButton("⚡ بوسترِ قدرت", callback_data="admin_attack_add_booster_type:power")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_attack_cat:{cat}")],
        ]
        await send_response(update, "⚡ اول نوعِ بوستر رو انتخاب کن:", InlineKeyboardMarkup(rows))
        return
    await ask_for_input(
        update, context, f"📝 اطلاعاتِ آیتمِ جدید رو با این فرمت بفرست (با | جدا کن):\n\n{_ATTACK_FIELD_HINT[cat]}",
        {"type": "attack_add_fields", "category": cat}, "admin_state",
    )


async def cb_admin_attack_add_booster_type(update: Update, context: ContextTypes.DEFAULT_TYPE):
    booster_type = update.callback_query.data.split(":")[1]
    await ask_for_input(
        update, context, f"📝 اطلاعاتِ بوسترِ جدید رو با این فرمت بفرست (با | جدا کن):\n\n{_ATTACK_FIELD_HINT['booster']}",
        {"type": "attack_add_fields", "category": "booster", "booster_type": booster_type}, "admin_state",
    )


async def cb_admin_attack_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    iid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        it = session.get(db.ShopItem, iid)
        if not it:
            await send_response(update, "این آیتم پیدا نشد.", None)
            return
        rows = []
        for field in _ATTACK_FIELD_SPECS[it.category]:
            if field in ("name", "description"):
                label = "✏️ تغییرِ نام" if field == "name" else "✏️ تغییرِ توضیح"
            elif field == "price":
                label = "✏️ تغییرِ قیمت"
            elif field == "level":
                label = "✏️ تغییرِ سطح"
            elif field == "power":
                label = "✏️ تغییرِ قدرت"
            elif field == "pct":
                label = "✏️ تغییرِ درصد"
            elif field == "uses":
                label = "✏️ تغییرِ تعدادِ استفاده"
            elif field == "duration_minutes":
                label = "✏️ تغییرِ مدت (دقیقه)"
            else:
                continue
            rows.append([InlineKeyboardButton(label, callback_data=f"admin_attack_edit_ask:{it.id}:{field}")])
        rows.append([InlineKeyboardButton("⛔️ غیرفعال کردن" if it.active else "✅ فعال کردن", callback_data=f"admin_attack_toggle:{it.id}")])
        rows.append([InlineKeyboardButton("🗑 حذفِ آیتم", callback_data=f"admin_attack_delete_ask:{it.id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_attack_cat:{it.category}")])
        bt = f"\n💰/⚡ نوعِ بوستر: {'پول' if it.booster_type == 'money' else 'قدرت'}" if it.booster_type else ""
        text = f"{it.name}\n{it.description or ''}\n\n{_attack_item_summary(it)}{bt}\n\n{'✅ فعاله' if it.active else '⛔️ غیرفعاله'}"
        await send_response(update, text.strip(), InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_attack_edit_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _, iid, field = update.callback_query.data.split(":")
    iid = int(iid)
    prompt = "مقدارِ جدید رو بفرست" + (" (برای فیلدهای اختیاری «-» یعنی نامحدود/بدون‌مقدار)" if field in _ATTACK_OPTIONAL_FIELDS else "") + ":"
    await ask_for_input(update, context, f"✏️ {prompt}", {"type": "attack_edit_field", "id": iid, "field": field}, "admin_state")


async def cb_admin_attack_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    iid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        it = session.get(db.ShopItem, iid)
        if it:
            it.active = not it.active
            session.commit()
    finally:
        session.close()
    await cb_admin_attack_view(update, context)


async def cb_admin_attack_delete_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    iid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        it = session.get(db.ShopItem, iid)
        if not it:
            await send_response(update, "این آیتم پیدا نشد.", None)
            return
        rows = [[
            InlineKeyboardButton("✅ بله، حذفش کن", callback_data=f"admin_attack_delete_confirm:{iid}"),
            InlineKeyboardButton("❌ نه", callback_data=f"admin_attack_view:{iid}"),
        ]]
        await send_response(update, f"آیا مطمئنی می‌خوای «{it.name}» رو حذف کنی؟", InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_attack_delete_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    iid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        it = session.get(db.ShopItem, iid)
        if it:
            cat = it.category
            session.delete(it)
            session.commit()
            await send_response(update, "✅ حذف شد.", None)
        else:
            cat = None
    finally:
        session.close()
    if cat:
        await _render_attack_cat(update, context, cat)


# ---------------------------------------------------------------------------
# مدیریت محصولات سوپرمارکت (محصولات دلخواهی که مالک تعریف می‌کنه، مثل «توپ»)
# ---------------------------------------------------------------------------

@owner_only
async def cb_admin_products_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        products = session.query(db.Product).order_by(db.Product.unlock_level).all()
        rows = []
        for p in products:
            status = "✅" if p.is_active else "⛔️"
            rows.append([InlineKeyboardButton(
                f"{status} {p.emoji} {p.name} (سطح {p.unlock_level} | {fmt(p.daily_price)} 🪙)",
                callback_data=f"admin_product_view:{p.id}")])
        rows.append([InlineKeyboardButton("➕ افزودن محصول جدید", callback_data="admin_product_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        text = ("📦 محصولات دلخواهِ سوپرمارکت:\n\n"
                "این‌ها علاوه بر ۴ محصول ثابت (گوشت گربه/دارچین خیار/موز/تخم سگ) هستن. "
                "هر کدوم از یک «سطح محصولات» به بعد برای پلیرها باز می‌شن.") if products else \
            "📦 هنوز محصول دلخواهی نساختی. با دکمه‌ی زیر یکی بساز (مثلا ⚽ توپ برای سطح ۲):"
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_product_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "📝 اسم محصول جدید رو بفرست (مثلا: توپ):", {"type": "product_add_name"}, "admin_state")


@owner_only
async def cb_admin_product_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        p = session.get(db.Product, pid)
        if not p:
            await send_response(update, "این محصول پیدا نشد.", admin_menu_keyboard())
            return
        rows = [
            [InlineKeyboardButton("✏️ تغییر قیمت روز", callback_data=f"admin_product_edit:{pid}:price")],
            [InlineKeyboardButton("✏️ تغییر سطح باز شدن", callback_data=f"admin_product_edit:{pid}:level")],
            [InlineKeyboardButton(
                ("⛔️ غیرفعال کردن" if p.is_active else "✅ فعال کردن"),
                callback_data=f"admin_product_toggle:{pid}")],
            [InlineKeyboardButton("🗑️ حذف این محصول", callback_data=f"admin_product_delete:{pid}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_products_menu")],
        ]
        text = (f"{p.emoji} {p.name}\n"
                f"🔓 از سطح محصولاتِ: {p.unlock_level}\n"
                f"💵 قیمت روز: {fmt(p.daily_price)} 🪙\n"
                f"وضعیت: {'فعال ✅' if p.is_active else 'غیرفعال ⛔️'}")
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_product_edit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _, pid, field = update.callback_query.data.split(":")
    label = "قیمت روز" if field == "price" else "سطح باز شدن"
    await ask_for_input(
        update, context, f"✏️ مقدار جدید برای «{label}» رو بفرست (عدد):",
        {"type": "product_edit", "id": int(pid), "field": field}, "admin_state",
    )


@owner_only
async def cb_admin_product_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        p = session.get(db.Product, pid)
        if p:
            p.is_active = not p.is_active
            session.commit()
        await cb_admin_product_view(update, context)
    finally:
        session.close()


@owner_only
async def cb_admin_product_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        p = session.get(db.Product, pid)
        if p:
            session.query(db.UserProduct).filter_by(product_id=pid).delete()
            session.delete(p)
            session.commit()
        await cb_admin_products_menu(update, context)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# ویرایش پلیر
# ---------------------------------------------------------------------------

PLAYER_EDITABLE_FIELDS = [
    ("hop_points", "🪙 هاپ پوینت"),
    ("level", "👤 سطح"),
    ("lvl", "🆙 لول (lvl)"),
    ("xp", "✨ تجربه (XP)"),
    ("production_per_min", "🏭 تولید در دقیقه"),
    ("factory_rank_order", "🎖️ ترتیبِ مقامِ کارخونه"),
    ("factory_level", "⬆️ سطحِ کارخونه (داخلِ مقام)"),
    ("bank_balance", "🏦 موجودی بانک"),
    ("supermarket_prod_per_hour", "🛒 سرعت تولید سوپرمارکت"),
    ("cat_meat", "🐱 گوشت گربه"),
    ("cinnamon_cucumber", "🥒 دارچین خیار"),
    ("banana", "🍌 موز"),
    ("dog_egg", "🥚 تخم سگ"),
]


@owner_only
async def cb_admin_player_search(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "👤 آیدی عددی پلیر مورد نظر رو بفرست:\n"
                                 "(اگه نمی‌دونی، از کاربر بخواه پیامی به ربات @userinfobot بده)", {"type": "player_search"}, "admin_state")


def player_edit_keyboard(uid: int):
    rows = []
    for i in range(0, len(PLAYER_EDITABLE_FIELDS), 2):
        chunk = PLAYER_EDITABLE_FIELDS[i:i + 2]
        rows.append([InlineKeyboardButton(f"✏️ {label}", callback_data=f"admin_player_edit:{field}:{uid}")
                     for field, label in chunk])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
    return InlineKeyboardMarkup(rows)


async def show_player_card(update_or_query_msg, context, uid: int, edit=False, update=None):
    import economy
    session = db.get_session()
    try:
        user = session.get(db.User, uid)
        if not user:
            await send_response(update, f"❌ پلیری با آیدی {uid} پیدا نشد.", admin_menu_keyboard())
            return
        rank = economy.current_rank(session, user)
        rank_line = f"{rank.name} - سطح {user.factory_level}/{rank.num_levels}" if rank else f"سطح {user.factory_level}"
        text = (
            f"👤 کارت پلیر {user.display_name()} ({uid})\n\n"
            f"🪙 هاپ پوینت: {fmt(user.hop_points)}\n"
            f"👤 سطح: {user.level} | ✨ XP: {fmt(user.xp)} | 🆙 لول: {db.user_lvl(user)}/{db.MAX_LVL}\n"
            f"🏭 تولید/دقیقه: {fmt(user.production_per_min)} ({rank_line})\n"
            f"🛒 سوپرمارکت: {'دارد' if user.has_supermarket else 'ندارد'} | سرعت: {fmt(user.supermarket_prod_per_hour)}\n"
            f"🏦 بانک: {'دارد' if user.has_bank else 'ندارد'} | موجودی: {fmt(user.bank_balance)}\n"
            f"🐱 {fmt(user.cat_meat)} | 🥒 {fmt(user.cinnamon_cucumber)} | 🍌 {fmt(user.banana)} | 🥚 {fmt(user.dog_egg)}"
        )
        await send_response(update, text, player_edit_keyboard(uid))
    finally:
        session.close()


@owner_only
async def cb_admin_player_edit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _, field, uid = update.callback_query.data.split(":")
    label = dict(PLAYER_EDITABLE_FIELDS).get(field, field)
    await ask_for_input(update, context, f"✏️ مقدار جدید برای «{label}» پلیر {uid} رو بفرست (عدد):", {"type": "player_field", "field": field, "uid": int(uid)}, "admin_state")


# ---------------------------------------------------------------------------
# افزودن هاپ پوینت به مالک (بدون نیاز به موجودی)
# ---------------------------------------------------------------------------

@owner_only
async def cb_admin_add_points_self(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "➕ چند تا هاپ پوینت به خودت اضافه کنم؟ عدد رو بفرست:", {"type": "add_points_self"}, "admin_state")


# ---------------------------------------------------------------------------
# مدیریت ارزها
# ---------------------------------------------------------------------------

@owner_only
async def cb_admin_currency_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        currencies = session.query(db.Currency).all()
        rows = []
        for c in currencies:
            rows.append([InlineKeyboardButton(
                f"{c.emoji} {c.name} (خرید {fmt(c.buy_price)}/فروش {fmt(c.sell_price)})",
                callback_data=f"admin_currency_view:{c.id}")])
        rows.append([InlineKeyboardButton("➕ ساخت ارز جدید", callback_data="admin_currency_add")])
        rows.append([InlineKeyboardButton("🔄 بروزرسانی خودکار قیمت‌ها", callback_data="admin_currency_auto_menu")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        text = "💱 مدیریت ارزهای هاپ:" if currencies else "💱 هنوز هیچ ارزی نساختی. با دکمه‌ی زیر بساز:"
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# بروزرسانی خودکار قیمت ارزها
# ---------------------------------------------------------------------------

@owner_only
async def cb_admin_currency_auto_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        enabled = db.cfg_get(session, "crypto_auto_enabled") == "1"
        interval = db.cfg_get(session, "crypto_auto_interval_hours")
        max_pct = db.cfg_get(session, "crypto_auto_max_change_pct")
        status_txt = "روشن ✅" if enabled else "خاموش ⛔️"
        text = (
            "🔄 بروزرسانی خودکار قیمت ارزها\n\n"
            f"وضعیت فعلی: {status_txt}\n"
            f"⏱️ فاصله‌ی زمانی: هر {interval} ساعت یک‌بار\n"
            f"📊 حداکثر درصد تغییر هر بار: ±{max_pct}٪\n\n"
            "با روشن‌کردن این گزینه، قیمت خرید/فروش همه‌ی ارزها به‌صورت خودکار و "
            "با یک درصد محدود (نه جهشی) بالا/پایین می‌ره تا واقعی به‌نظر برسه."
        )
        rows = [
            [InlineKeyboardButton(
                "⛔️ خاموش کردن" if enabled else "✅ روشن کردن",
                callback_data="admin_currency_auto_toggle",
            )],
            [InlineKeyboardButton("⏱️ تغییر فاصله‌ی زمانی (ساعت)", callback_data="admin_currency_auto_interval")],
            [InlineKeyboardButton("📊 تغییر حداکثر درصد نوسان", callback_data="admin_currency_auto_maxpct")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_currency_menu")],
        ]
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_currency_auto_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        enabled = db.cfg_get(session, "crypto_auto_enabled") == "1"
        db.cfg_set(session, "crypto_auto_enabled", "0" if enabled else "1")
    finally:
        session.close()
    await cb_admin_currency_auto_menu(update, context)


@owner_only
async def cb_admin_currency_auto_interval(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(
        update, context,
        "⏱️ هر چند ساعت یک‌بار قیمت ارزها خودکار عوض شن؟ یه عدد بفرست (مثلا 1 یعنی هر ۱ ساعت):",
        {"type": "crypto_auto_interval"}, "admin_state",
    )


@owner_only
async def cb_admin_currency_auto_maxpct(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(
        update, context,
        "📊 حداکثر درصد تغییر قیمت در هر بار چقدر باشه؟ یه عدد بفرست (مثلا 8 یعنی حداکثر ۸٪ بالا یا پایین):",
        {"type": "crypto_auto_maxpct"}, "admin_state",
    )


@owner_only
async def cb_admin_currency_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "📝 اسم ارز جدید رو بفرست (مثلا: هاپ‌کوین):", {"type": "currency_add_name"}, "admin_state")


@owner_only
async def cb_admin_currency_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        c = session.get(db.Currency, cid)
        if not c:
            await send_response(update, "این ارز پیدا نشد.", admin_menu_keyboard())
            return
        rows = [
            [InlineKeyboardButton("✏️ تغییر قیمت خرید", callback_data=f"admin_currency_edit:{cid}:buy")],
            [InlineKeyboardButton("✏️ تغییر قیمت فروش", callback_data=f"admin_currency_edit:{cid}:sell")],
            [InlineKeyboardButton("🗑️ حذف این ارز", callback_data=f"admin_currency_delete:{cid}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_currency_menu")],
        ]
        text = f"{c.emoji} {c.name}\n🟢 خرید: {fmt(c.buy_price)}\n🔴 فروش: {fmt(c.sell_price)}"
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_currency_edit(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _, cid, side = update.callback_query.data.split(":")
    label = "خرید" if side == "buy" else "فروش"
    await ask_for_input(
        update, context, f"✏️ قیمت جدید {label} رو بفرست (عدد):",
        {"type": "currency_price", "id": int(cid), "side": side}, "admin_state",
    )


@owner_only
async def cb_admin_currency_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        c = session.get(db.Currency, cid)
        if c:
            session.query(db.UserCurrency).filter_by(currency_id=cid).delete()
            session.delete(c)
            session.commit()
        await cb_admin_currency_menu(update, context)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مدیریت قرعه‌کشی (سراسری - فقط از پیویِ مالک شروع می‌شه، نه با تایپ تو گروه)
# ---------------------------------------------------------------------------

CFG_LOTTERY_KEYS = [
    ("lottery_channel_id", "📢 آیدیِ چنلِ اعلامِ قرعه‌کشی (خالی/۰ یعنی اعلام نشه)"),
]


@owner_only
async def cb_admin_lottery_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("lottery_picks", None)  # هر بار که میایم این منو، انتخاب‌های دستیِ نصفه‌ونیمه پاک شن
    session = db.get_session()
    try:
        channel_id = db.cfg_get(session, "lottery_channel_id")
        channel_row = [InlineKeyboardButton(
            f"📢 چنلِ اعلامِ قرعه‌کشی: {channel_id or '— تنظیم نشده —'}",
            callback_data="admin_cfg_edit:lottery_channel_id")]
        event = session.query(db.LotteryEvent).filter_by(is_active=True).first()
        if not event:
            rows = [
                [InlineKeyboardButton("➕ شروع قرعه‌کشی جدید", callback_data="admin_lottery_start")],
                channel_row,
                [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")],
            ]
            await send_response(update, "🎉 الان هیچ قرعه‌کشیِ فعالی وجود نداره.", InlineKeyboardMarkup(rows))
            return
        parts = event.participants()
        rows = [
            [InlineKeyboardButton("🎲 انتخاب شانسی برندگان", callback_data=f"admin_lottery_random:{event.id}")],
            [InlineKeyboardButton("✋ انتخاب دستیِ برندگان", callback_data=f"admin_lottery_manual_start:{event.id}")],
            [InlineKeyboardButton("❌ لغو این قرعه‌کشی", callback_data=f"admin_lottery_cancel:{event.id}")],
            channel_row,
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")],
        ]
        text = (
            "🎉 قرعه‌کشی سراسری فعال\n\n"
            f"🎁 جایزه‌ی خودکارِ هر برنده: {fmt(event.prize_amount)} 🪙\n"
            f"🏆 تعداد برنده: {event.winner_count} نفر\n"
            f"👥 تعداد شرکت‌کننده: {len(parts)}\n\n"
            f"📢 قرعه‌کشی فقط تو همین چنل اعلام می‌شه: {channel_id or '— تنظیم نشده، پس هیچ‌جا اعلام نمی‌شه —'}"
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_lottery_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        existing = session.query(db.LotteryEvent).filter_by(is_active=True).first()
        if existing:
            await send_response(update, "❌ یه قرعه‌کشیِ فعال از قبل وجود داره؛ اول اون رو تموم یا لغو کن.", admin_menu_keyboard())
            return
    finally:
        session.close()
    await ask_for_input(
        update, context,
        "🎁 هر برنده‌ی این قرعه‌کشی به‌صورت خودکار چقدر هاپ پوینت دریافت کنه؟ یه عدد بفرست:",
        {"type": "lottery_prize"}, "admin_state",
    )


async def _broadcast_lottery_start(context, session, event):
    """اعلامِ شروعِ قرعه‌کشی - فقط تو یه چنلِ مشخص (lottery_channel_id تو تنظیمات)،
    نه تو همه‌ی گروه‌های شناخته‌شده. قبلاً این کار به همه‌ی گروه‌هایی که بات توشون
    عضوه پیام می‌فرستاد که با زیادشدنِ تعدادِ گروه‌ها فشارِ زیادی (و کندی/ریت‌لیمیت)
    رو خودِ بات می‌آورد. اگه چنلی تنظیم نشده باشه، اصلاً هیچ پیامی فرستاده نمی‌شه."""
    channel_id_raw = db.cfg_get(session, "lottery_channel_id")
    try:
        channel_id = int(channel_id_raw) if channel_id_raw else 0
    except (TypeError, ValueError):
        channel_id = 0
    if not channel_id:
        return 0
    try:
        sent = await context.bot.send_message(
            channel_id,
            "🎉🎊 قرعه‌کشی سراسری هاپ شروع شد!\n"
            f"🎁 جایزه‌ی هر برنده: {fmt(event.prize_amount)} 🪙\n"
            f"🏆 تعداد برنده: {event.winner_count} نفر\n\n"
            "برای شرکت روی دکمه‌ی زیر بزن 👇",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("🎉 شرکت در قرعه‌کشی", callback_data=f"lottery_join:{event.id}")],
            ]),
        )
        session.add(db.LotteryBroadcastMessage(
            event_id=event.id, chat_id=channel_id, chat_title=None, message_id=sent.message_id,
        ))
        session.commit()
        return 1
    except Exception:
        logger.exception("خطا در ارسالِ اعلامِ قرعه‌کشی به چنل")
        return 0


async def _finish_lottery(context, session, event, winner_ids):
    """قرعه‌کشی رو با یک یا چند برنده تموم می‌کنه: به هرکدوم جایزه‌ی کامل
    (نه تقسیم‌شده) واریز می‌کنه و تو همه‌ی گروه‌ها اعلام می‌کنه."""
    winner_ids = list(dict.fromkeys(winner_ids))  # حذفِ تکراری‌ها با حفظِ ترتیب
    event.is_active = False
    event.set_winners(winner_ids)
    event.winner_id = winner_ids[0] if winner_ids else None  # سازگاری با فیلدِ قدیمی
    event.finished_at = db.now()

    names = []
    for uid in winner_ids:
        winner = session.get(db.User, uid)
        if winner:
            winner.hop_points += event.prize_amount
            names.append(winner.display_name())
        else:
            names.append(str(uid))
    session.commit()

    if len(names) == 1:
        text = f"🏆🎉 برنده‌ی قرعه‌کشی سراسری: {names[0]}\n🎁 {fmt(event.prize_amount)} 🪙 خودکار به حسابش واریز شد!"
    else:
        lines = [f"🏆🎉 برنده‌های قرعه‌کشی سراسری ({len(names)} نفر):"]
        lines += [f"• {n}" for n in names]
        lines.append(f"\n🎁 هرکدوم {fmt(event.prize_amount)} 🪙 خودکار به حسابشون واریز شد!")
        text = "\n".join(lines)

    # همیشه به چنلِ *فعلاً* تنظیم‌شده (lottery_channel_id) هم می‌فرستیم - صرفِ‌نظر
    # از اینکه این رویداد قبلاً (مثلاً قبل از تغییرِ این تنظیم) با چه
    # broadcast-ای ساخته شده بود؛ وگرنه اگه رویداد با نسخه‌ی قدیمی/چنلِ قبلی
    # شروع شده باشه، اعلامِ برنده به چنلِ جدید نمی‌رسید.
    sent_chat_ids = set()
    channel_id_raw = db.cfg_get(session, "lottery_channel_id")
    try:
        channel_id = int(channel_id_raw) if channel_id_raw else 0
    except (TypeError, ValueError):
        channel_id = 0
    if channel_id:
        try:
            await context.bot.send_message(channel_id, text)
            sent_chat_ids.add(channel_id)
        except Exception:
            logger.exception("خطا در ارسالِ اعلامِ برنده‌های قرعه‌کشی به چنل")

    broadcasts = session.query(db.LotteryBroadcastMessage).filter_by(event_id=event.id).all()
    for b in broadcasts:
        if b.chat_id in sent_chat_ids:
            continue
        try:
            await context.bot.send_message(b.chat_id, text)
            sent_chat_ids.add(b.chat_id)
        except Exception:
            continue


@owner_only
async def cb_admin_lottery_random(update: Update, context: ContextTypes.DEFAULT_TYPE):
    eid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        event = session.get(db.LotteryEvent, eid)
        if not event or not event.is_active:
            await send_response(update, "این قرعه‌کشی دیگه فعال نیست.", admin_menu_keyboard())
            return
        parts = event.participants()
        if not parts:
            await send_response(update, "هیچ شرکت‌کننده‌ای وجود نداره.", admin_menu_keyboard())
            return
        n = min(event.winner_count or 1, len(parts))
        winner_ids = random.sample(parts, n)
        await _finish_lottery(context, session, event, winner_ids)
        note = "" if len(parts) >= (event.winner_count or 1) else f" (فقط {len(parts)} نفر شرکت کرده بودن)"
        await send_response(update, f"✅ {n} برنده به‌صورت شانسی انتخاب، جایزه‌ها واریز و تو گروه‌ها اعلام شد.{note}", admin_menu_keyboard())
    finally:
        session.close()


# ---------------------------------------------------------------------------
# انتخاب دستیِ چند برنده (تیک‌زدنِ چندتایی + تاییدِ نهایی)
# ---------------------------------------------------------------------------

async def _show_lottery_manual_picker(update: Update, context: ContextTypes.DEFAULT_TYPE, eid: int):
    session = db.get_session()
    try:
        event = session.get(db.LotteryEvent, eid)
        if not event or not event.is_active:
            await send_response(update, "این قرعه‌کشی دیگه فعال نیست.", admin_menu_keyboard())
            context.user_data.pop("lottery_picks", None)
            return
        parts = event.participants()
        picks = context.user_data.get("lottery_picks", {}).get("picks", [])

        rows = []
        for uid in parts[:30]:  # محدودیت نمایش برای جلوگیری از کیبورد خیلی بزرگ
            user = session.get(db.User, uid)
            name = user.display_name() if user else str(uid)
            mark = "✅" if uid in picks else "⬜️"
            rows.append([InlineKeyboardButton(f"{mark} {name}", callback_data=f"admin_lottery_toggle:{eid}:{uid}")])
        rows.append([InlineKeyboardButton(f"🏁 تایید و پایان (با {len(picks)} برنده)", callback_data=f"admin_lottery_manual_confirm:{eid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_lottery_menu")])

        text = (
            f"✋ انتخاب دستیِ برندگان\n\n"
            f"🎯 تعداد برندگانِ موردنیاز: {event.winner_count} نفر\n"
            f"✅ الان انتخاب شده: {len(picks)} نفر\n\n"
            "با زدن رو اسمِ هرکس، تیکش می‌خوره یا برمی‌داره. هر وقت خواستی، با "
            "«تایید و پایان» تموم کن (لازم نیست دقیقاً به تعدادِ موردنیاز برسی)."
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_lottery_manual_start(update: Update, context: ContextTypes.DEFAULT_TYPE):
    eid = int(update.callback_query.data.split(":")[1])
    context.user_data["lottery_picks"] = {"event_id": eid, "picks": []}
    await _show_lottery_manual_picker(update, context, eid)


@owner_only
async def cb_admin_lottery_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _, eid, uid = update.callback_query.data.split(":")
    eid, uid = int(eid), int(uid)
    state = context.user_data.get("lottery_picks")
    if not state or state.get("event_id") != eid:
        state = {"event_id": eid, "picks": []}
    picks = state["picks"]
    if uid in picks:
        picks.remove(uid)
    else:
        picks.append(uid)
    context.user_data["lottery_picks"] = state
    await _show_lottery_manual_picker(update, context, eid)


@owner_only
async def cb_admin_lottery_manual_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    eid = int(update.callback_query.data.split(":")[1])
    state = context.user_data.get("lottery_picks") or {}
    picks = state.get("picks", []) if state.get("event_id") == eid else []
    if not picks:
        await update.callback_query.answer("حداقل باید یه نفر رو انتخاب کنی.", show_alert=True)
        return
    session = db.get_session()
    try:
        event = session.get(db.LotteryEvent, eid)
        if not event or not event.is_active:
            await send_response(update, "این قرعه‌کشی دیگه فعال نیست.", admin_menu_keyboard())
            return
        await _finish_lottery(context, session, event, picks)
        context.user_data.pop("lottery_picks", None)
        await send_response(update, f"✅ {len(picks)} برنده انتخاب، جایزه‌ها واریز و تو گروه‌ها اعلام شد.", admin_menu_keyboard())
    finally:
        session.close()


@owner_only
async def cb_admin_lottery_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    context.user_data.pop("lottery_picks", None)
    eid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        event = session.get(db.LotteryEvent, eid)
        if event and event.is_active:
            event.is_active = False
            event.finished_at = db.now()
            session.commit()
            sent_chat_ids = set()
            channel_id_raw = db.cfg_get(session, "lottery_channel_id")
            try:
                channel_id = int(channel_id_raw) if channel_id_raw else 0
            except (TypeError, ValueError):
                channel_id = 0
            if channel_id:
                try:
                    await context.bot.send_message(channel_id, "❌ قرعه‌کشیِ سراسری هاپ لغو شد.")
                    sent_chat_ids.add(channel_id)
                except Exception:
                    pass
            broadcasts = session.query(db.LotteryBroadcastMessage).filter_by(event_id=event.id).all()
            for b in broadcasts:
                if b.chat_id in sent_chat_ids:
                    continue
                try:
                    await context.bot.send_message(b.chat_id, "❌ قرعه‌کشیِ سراسری هاپ لغو شد.")
                except Exception:
                    continue
        await send_response(update, "✅ قرعه‌کشی لغو شد.", admin_menu_keyboard())
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مدیریتِ گوشی هاپویی (اپراتورها، پلتفرم‌ها، درخواست‌ها، بدهی‌ها)
# ---------------------------------------------------------------------------

def myawy_admin_menu_keyboard(pending_revenue: float = 0):
    rows = [
        [InlineKeyboardButton("📶 مدیریتِ اپراتورها", callback_data="admin_myawy_operators")],
        [InlineKeyboardButton("📱 مدیریتِ پلتفرم‌ها", callback_data="admin_myawy_platforms")],
        [InlineKeyboardButton("📨 درخواست‌های پلتفرمِ جدید", callback_data="admin_myawy_requests")],
        [InlineKeyboardButton("💳 بدهی‌های پرداخت‌نشده", callback_data="admin_myawy_debts")],
        [InlineKeyboardButton("📲 مدیریتِ خط‌ها و نسل‌های گوشی", callback_data="admin_phone_lines")],
    ]
    if pending_revenue > 0:
        rows.append([InlineKeyboardButton(f"💰 برداشتِ درآمدِ اپراتور ({pending_revenue:,.0f} 🪙)", callback_data="admin_myawy_withdraw_revenue")])
    rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
    return InlineKeyboardMarkup(rows)


@owner_only
async def cb_admin_myawy_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        revenue = db.cfg_get_float(session, "myawy_total_internet_revenue")
        pending_revenue = db.cfg_get_float(session, "myawy_pending_internet_revenue")
        pending_requests = session.query(db.PlatformRequest).filter_by(status="pending").count()
        pending_debts = session.query(db.UserDebt).filter_by(is_paid=False).count()
        text = (
            "📱 مدیریتِ گوشی هاپویی\n\n"
            f"💰 مجموعِ کلِ درآمدِ فروشِ اینترنت: {fmt(revenue)} 🪙\n"
            f"💵 در صفِ برداشت: {fmt(pending_revenue)} 🪙\n"
            f"📨 درخواستِ پلتفرمِ در انتظار: {pending_requests}\n"
            f"💳 بدهیِ پرداخت‌نشده: {pending_debts}"
        )
        await send_response(update, text, myawy_admin_menu_keyboard(pending_revenue))
    finally:
        session.close()


@owner_only
async def cb_admin_myawy_withdraw_revenue(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        pending = db.cfg_get_float(session, "myawy_pending_internet_revenue")
        if pending <= 0:
            await send_response(update, "❌ الان چیزی تو صفِ برداشت نیست.", myawy_admin_menu_keyboard())
            return
        owner_user = db.get_or_create_user(session, update.effective_user)
        owner_user.hop_points += pending
        db.cfg_set(session, "myawy_pending_internet_revenue", 0)
        session.commit()
        await send_response(update, f"✅ {fmt(pending)} 🪙 به موجودیت واریز شد.", myawy_admin_menu_keyboard(0))
    finally:
        session.close()


# --- اپراتورها ---

@owner_only
async def cb_admin_myawy_operators(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        operators = session.query(db.Operator).all()
        rows = []
        for op in operators:
            status = "✅" if op.is_active else "⛔️"
            rows.append([InlineKeyboardButton(
                f"{status} {op.name} | {fmt(op.price_per_gb)}🪙/GB | فعال:{fmt(op.active_speed_mbps)}/سقف:{fmt(op.speed_mbps)}Mbps",
                callback_data=f"admin_myawy_operator_view:{op.id}")])
        rows.append([InlineKeyboardButton("➕ افزودنِ اپراتورِ جدید", callback_data="admin_myawy_operator_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_myawy_menu")])
        text = "📶 اپراتورهای اینترنت:" if operators else "📶 هنوز هیچ اپراتوری نساختی."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_myawy_operator_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "📝 اسمِ اپراتورِ جدید رو بفرست:", {"type": "myawy_operator_add_name"}, "admin_state")


@owner_only
async def cb_admin_myawy_operator_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    op_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        op = session.get(db.Operator, op_id)
        if not op:
            await send_response(update, "این اپراتور پیدا نشد.", myawy_admin_menu_keyboard())
            return
        rows = [
            [InlineKeyboardButton("🚀 افزایشِ پهنای باند (سقفِ نهایی)", callback_data=f"admin_myawy_operator_boost_ask:{op.id}")],
            [InlineKeyboardButton("🔌 تنظیمِ پهنای باندِ فعال", callback_data=f"admin_myawy_operator_setactive_ask:{op.id}")],
            [InlineKeyboardButton("✏️ تغییرِ قیمتِ هر گیگ", callback_data=f"admin_myawy_operator_editprice:{op.id}")],
            [InlineKeyboardButton("⛔️ غیرفعال کردن" if op.is_active else "✅ فعال کردن", callback_data=f"admin_myawy_operator_toggle:{op.id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_myawy_operators")],
        ]
        text = (
            f"{op.name}\n"
            f"💵 قیمتِ هر گیگ: {fmt(op.price_per_gb)} 🪙\n"
            f"🚀 سقفِ نهایی (حداکثرِ ارتقا داده‌شده): {fmt(op.speed_mbps)} Mbps\n"
            f"🔌 پهنای باندِ فعال (همینه که تو محاسبه اثر داره): {fmt(op.active_speed_mbps)} Mbps"
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_myawy_operator_boost_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    op_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        cost = db.cfg_get_float(session, "myawy_speed_boost_cost")
        mbps = db.cfg_get_float(session, "myawy_speed_boost_mbps")
    finally:
        session.close()
    await ask_for_input(
        update, context,
        f"🚀 چند مگابیت می‌خوای به سقفِ نهایی اضافه کنی؟ (نرخ: هر {fmt(mbps)} مگابیت = {fmt(cost)} 🪙 از موجودیِ خودت)",
        {"type": "myawy_operator_boost_amount", "id": op_id}, "admin_state",
    )


@owner_only
async def cb_admin_myawy_operator_boost_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _, op_id, amount = update.callback_query.data.split(":")
    op_id, amount = int(op_id), float(amount)
    session = db.get_session()
    try:
        op = session.get(db.Operator, op_id)
        if not op:
            await send_response(update, "این اپراتور پیدا نشد.", myawy_admin_menu_keyboard())
            return
        cost_per_unit = db.cfg_get_float(session, "myawy_speed_boost_cost")
        mbps_per_unit = db.cfg_get_float(session, "myawy_speed_boost_mbps")
        cost = (amount / mbps_per_unit) * cost_per_unit if mbps_per_unit else 0
        owner_user = db.get_or_create_user(session, update.effective_user)
        if owner_user.hop_points < cost:
            await send_response(update, f"❌ ناموفق - موجودی کافی نیست! {fmt(cost)} 🪙 لازم بود.", myawy_admin_menu_keyboard())
            return
        owner_user.hop_points -= cost
        op.speed_mbps += amount
        op.active_speed_mbps = op.speed_mbps  # پیش‌فرض بعد از هر ارتقا، فعال هم با سقفِ جدید برابر می‌شه
        session.commit()
        await send_response(
            update,
            f"✅ سقفِ نهاییِ {op.name} به {fmt(op.speed_mbps)} Mbps رسید و پهنای باندِ فعالش هم همون شد!",
            myawy_admin_menu_keyboard(),
        )
    finally:
        session.close()


@owner_only
async def cb_admin_myawy_operator_boost_cancel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    op_id = int(update.callback_query.data.split(":")[1])
    await send_response(update, "❌ لغو شد؛ سرعت تغییر نکرد.", myawy_admin_menu_keyboard())


@owner_only
async def cb_admin_myawy_operator_setactive_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    op_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        op = session.get(db.Operator, op_id)
        if not op:
            await send_response(update, "این اپراتور پیدا نشد.", myawy_admin_menu_keyboard())
            return
        max_speed = op.speed_mbps
    finally:
        session.close()
    await ask_for_input(
        update, context,
        f"🔌 پهنای باندِ فعال رو چند مگابیت بذارم؟ (بینِ ۰ تا {fmt(max_speed)}، چون سقفِ نهایی همینه):",
        {"type": "myawy_operator_setactive", "id": op_id}, "admin_state",
    )


@owner_only
async def cb_admin_myawy_operator_editprice(update: Update, context: ContextTypes.DEFAULT_TYPE):
    op_id = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "💵 قیمتِ جدیدِ هر گیگ رو بفرست:", {"type": "myawy_operator_editprice", "id": op_id}, "admin_state")


@owner_only
async def cb_admin_myawy_operator_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    op_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        op = session.get(db.Operator, op_id)
        if op:
            op.is_active = not op.is_active
            session.commit()
    finally:
        session.close()
    await cb_admin_myawy_operator_view(update, context)


# --- پلتفرم‌ها ---

@owner_only
async def cb_admin_myawy_platforms(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        platforms = session.query(db.Platform).all()
        rows = []
        for p in platforms:
            status = "✅" if p.is_active else "⛔️"
            funded = "🤖" if p.is_bot_funded else "👤"
            rows.append([InlineKeyboardButton(
                f"{status}{funded} {p.name} ({fmt(p.reward_amount)}🪙/{p.likes_threshold}لایک)",
                callback_data=f"admin_myawy_platform_view:{p.id}")])
        rows.append([InlineKeyboardButton("➕ افزودنِ پلتفرمِ جدید", callback_data="admin_myawy_platform_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_myawy_menu")])
        text = "📱 پلتفرم‌ها (🤖=پرداختِ خودکارِ بات، 👤=بدهیِ مالک):" if platforms else "📱 هنوز هیچ پلتفرمی نساختی."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_myawy_platform_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "📝 اسمِ پلتفرمِ جدید رو بفرست (مثلا: 📸 میواستاگرام):", {"type": "myawy_platform_add_name"}, "admin_state")


@owner_only
async def cb_admin_myawy_platform_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        p = session.get(db.Platform, pid)
        if not p:
            await send_response(update, "این پلتفرم پیدا نشد.", myawy_admin_menu_keyboard())
            return
        rows = [
            [InlineKeyboardButton("✏️ تغییرِ نرخِ پاداش", callback_data=f"admin_myawy_platform_editreward:{p.id}")],
            [InlineKeyboardButton("✏️ تغییرِ آستانه‌ی لایک", callback_data=f"admin_myawy_platform_editlikes:{p.id}")],
            [InlineKeyboardButton("🤖 پرداختِ خودکارِ بات" if not p.is_bot_funded else "👤 بدهیِ مالک", callback_data=f"admin_myawy_platform_togglefund:{p.id}")],
            [InlineKeyboardButton("⛔️ غیرفعال کردن" if p.is_active else "✅ فعال کردن", callback_data=f"admin_myawy_platform_toggle:{p.id}")],
        ]
        universal_txt = ""
        if p.owner_user_id is None:
            rows.append([InlineKeyboardButton(
                "🌍 روی گوشیِ ممنوع‌شده هم اجرا شه" if not p.works_on_all_phones else "🌍 فقط روی گوشیِ مجاز اجرا شه",
                callback_data=f"admin_myawy_platform_toggleuniversal:{p.id}",
            )])
            universal_txt = (
                "\n🌍 روی هر گوشی‌ای (حتی نسلِ ممنوع‌شده) لود می‌شه"
                if p.works_on_all_phones else
                "\n🚫 روی گوشیِ نسلِ ممنوع‌شده لود نمی‌شه"
            )
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_myawy_platforms")])
        rows.insert(-1, [InlineKeyboardButton("🗑 حذفِ کاملِ پلتفرم", callback_data=f"admin_myawy_platform_delete_ask:{p.id}")])
        if p.is_bot_funded:
            funded_txt = "خودِ بات مستقیم پرداخت می‌کنه 🤖"
        elif p.owner_user_id:
            creator = session.get(db.User, p.owner_user_id)
            creator_name = creator.display_name() if creator else str(p.owner_user_id)
            commission = db.cfg_get_float(session, "myawy_creator_commission_pct")
            funded_txt = f"سازنده‌ش ({creator_name}) خودکار پرداخت می‌کنه و {fmt(commission)}٪ کمیسیون هم می‌گیره ✨"
        else:
            funded_txt = "به‌صورتِ بدهیِ مالک ثبت می‌شه (باید دستی از پنل پرداخت کنی) 👤"
        text = (
            f"{p.name}\n"
            f"🎁 پاداش: {fmt(p.reward_amount)} 🪙 به‌ازای هر {p.likes_threshold} لایک\n"
            f"💳 نحوه‌ی پرداخت: {funded_txt}{universal_txt}"
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_myawy_platform_editreward(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "💰 نرخِ جدیدِ پاداش رو بفرست (هاپ پوینت به‌ازای همون تعداد لایکِ فعلی):", {"type": "myawy_platform_editreward", "id": pid}, "admin_state")


@owner_only
async def cb_admin_myawy_platform_editlikes(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "🔢 به‌ازای هر چند لایک پاداش بده؟ یه عدد صحیح بفرست (مثلا 2):", {"type": "myawy_platform_editlikes", "id": pid}, "admin_state")


@owner_only
async def cb_admin_myawy_platform_togglefund(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        p = session.get(db.Platform, pid)
        if p:
            p.is_bot_funded = not p.is_bot_funded
            session.commit()
    finally:
        session.close()
    await cb_admin_myawy_platform_view(update, context)


@owner_only
async def cb_admin_myawy_platform_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        p = session.get(db.Platform, pid)
        if p:
            p.is_active = not p.is_active
            session.commit()
    finally:
        session.close()
    await cb_admin_myawy_platform_view(update, context)


@owner_only
async def cb_admin_myawy_platform_delete_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        p = session.get(db.Platform, pid)
        if not p:
            await send_response(update, "این پلتفرم پیدا نشد.", myawy_admin_menu_keyboard())
            return
        name = p.name
        post_count = session.query(db.MyawyPost).filter_by(platform_id=pid).count()
        session.commit()
    finally:
        session.close()
    await send_response(
        update,
        f"🗑 مطمئنی می‌خوای پلتفرمِ «{name}» رو کاملا حذف کنی؟\n"
        f"{post_count} پستِ ثبت‌شده تو این پلتفرم (با همه‌ی لایک‌هاشون) هم به‌طور کامل پاک می‌شن، "
        "انگار این پلتفرم اصلا وجود نداشته.\nاین کار برگشت‌ناپذیره!",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله، کلا حذفش کن", callback_data=f"admin_myawy_platform_delete_confirm:{pid}"),
            InlineKeyboardButton("❌ انصراف", callback_data=f"admin_myawy_platform_view:{pid}"),
        ]]),
    )


@owner_only
async def cb_admin_myawy_platform_delete_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    pid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        p = session.get(db.Platform, pid)
        if not p:
            await send_response(update, "این پلتفرم پیدا نشد.", myawy_admin_menu_keyboard())
            return
        post_ids = [row[0] for row in session.query(db.MyawyPost.id).filter_by(platform_id=pid).all()]
        if post_ids:
            session.query(db.MyawyPostLike).filter(db.MyawyPostLike.post_id.in_(post_ids)).delete(synchronize_session=False)
            session.query(db.MyawyPost).filter(db.MyawyPost.id.in_(post_ids)).delete(synchronize_session=False)
        session.delete(p)
        session.commit()
    finally:
        session.close()
    await cb_admin_myawy_platforms(update, context)


@owner_only
async def cb_admin_myawy_platform_toggleuniversal(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """فقط برای پلتفرم‌هایی که خودِ مالک مستقیم ساخته (owner_user_id خالیه)."""
    pid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        p = session.get(db.Platform, pid)
        if p and p.owner_user_id is None:
            p.works_on_all_phones = not p.works_on_all_phones
            session.commit()
    finally:
        session.close()
    await cb_admin_myawy_platform_view(update, context)


# --- درخواست‌های پلتفرمِ جدید ---

@owner_only
async def cb_admin_myawy_requests(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        pending = session.query(db.PlatformRequest).filter_by(status="pending").all()
        rows = []
        for r in pending:
            user = session.get(db.User, r.user_id)
            name = user.display_name() if user else str(r.user_id)
            rows.append([InlineKeyboardButton(
                f"📨 {r.platform_name} - {name}",
                callback_data=f"admin_myawy_request_view:{r.id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_myawy_menu")])
        text = "📨 درخواست‌های در انتظار:" if pending else "📨 الان هیچ درخواستِ در انتظاری وجود نداره."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_myawy_request_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.PlatformRequest, rid)
        if not r or r.status != "pending":
            await send_response(update, "این درخواست دیگه در انتظار نیست.", myawy_admin_menu_keyboard())
            return
        user = session.get(db.User, r.user_id)
        name = user.display_name() if user else str(r.user_id)
        rows = [
            [InlineKeyboardButton("✅ قبول (با تعیینِ فی)", callback_data=f"admin_myawy_request_accept:{r.id}")],
            [InlineKeyboardButton("❌ رد کردن", callback_data=f"admin_myawy_request_reject:{r.id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_myawy_requests")],
        ]
        text = (
            f"📨 درخواستِ پلتفرمِ جدید از {name}\n\n"
            f"📱 اسمِ پیشنهادی: {r.platform_name}\n"
            f"💰 نرخِ پیشنهادی: {fmt(r.requested_reward_amount)} 🪙 به‌ازای هر {r.requested_likes_threshold} لایک"
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_myawy_request_accept(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "💵 چقدر فی برای تاییدِ نهایی می‌خوای؟ یه عدد بفرست:", {"type": "myawy_request_fee", "id": rid}, "admin_state")


@owner_only
async def cb_admin_myawy_request_reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.PlatformRequest, rid)
        if r and r.status == "pending":
            r.status = "rejected"
            session.commit()
        await send_response(update, "✅ درخواست رد شد.", myawy_admin_menu_keyboard())
    finally:
        session.close()


# --- بدهی‌ها ---

@owner_only
async def cb_admin_myawy_debts(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        debts = session.query(db.UserDebt).filter_by(is_paid=False).all()
        rows = []
        for d in debts[:30]:
            user = session.get(db.User, d.user_id)
            name = user.display_name() if user else str(d.user_id)
            rows.append([InlineKeyboardButton(
                f"💳 {name}: {fmt(d.amount)} 🪙",
                callback_data=f"admin_myawy_debt_pay:{d.id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_myawy_menu")])
        total = sum(d.amount for d in debts)
        text = f"💳 بدهی‌های پرداخت‌نشده (مجموع: {fmt(total)} 🪙):" if debts else "💳 هیچ بدهیِ پرداخت‌نشده‌ای نیست."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_myawy_debt_pay(update: Update, context: ContextTypes.DEFAULT_TYPE):
    did = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        d = session.get(db.UserDebt, did)
        if not d or d.is_paid:
            await send_response(update, "این بدهی دیگه وجود نداره یا قبلا پرداخت شده.", myawy_admin_menu_keyboard())
            return
        user = session.get(db.User, d.user_id)
        if user:
            user.hop_points += d.amount
        d.is_paid = True
        d.paid_at = db.now()
        session.commit()
        await send_response(update, f"✅ {fmt(d.amount)} 🪙 به {user.display_name() if user else d.user_id} پرداخت شد.", myawy_admin_menu_keyboard())
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مدیریتِ خط‌ها و نسل‌های گوشیِ هاپویی
# ---------------------------------------------------------------------------

@owner_only
async def cb_admin_phone_lines(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = session.query(db.PhoneLine).all()
        rows = []
        for line in lines:
            status = "✅" if line.is_active else "⛔️"
            tag = "🃏 فیک" if line.is_fake else "📱 اصل"
            n = session.query(db.PhoneGeneration).filter_by(line_id=line.id).count()
            rows.append([InlineKeyboardButton(
                f"{status} {tag} - {line.name} ({n} نسل)", callback_data=f"admin_phone_line_view:{line.id}")])
        rows.append([InlineKeyboardButton("➕ افزودنِ خطِ جدید", callback_data="admin_phone_line_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_myawy_menu")])
        text = "📲 خط‌های گوشیِ هاپویی:" if lines else "📲 هنوز هیچ خط/برندی نساختی."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_phone_line_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "📝 اسمِ خط/برندِ جدید رو بفرست (مثلا: سامسونگ، آیفون، یا هاپ):", {"type": "phone_line_add_name"}, "admin_state")


@owner_only
async def cb_admin_phone_line_create(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """دکمه‌ی «📱 اصل» / «🃏 فیک» بعد از فرستادنِ اسمِ خط."""
    _, is_fake = update.callback_query.data.split(":")
    name = context.user_data.pop("_pending_phone_line_name", None)
    if not name:
        await update.callback_query.answer("اسم گم شد؛ دوباره از اول شروع کن.", show_alert=True)
        await cb_admin_phone_lines(update, context)
        return
    session = db.get_session()
    try:
        session.add(db.PhoneLine(name=name, is_fake=(is_fake == "1"), is_active=True))
        session.commit()
    finally:
        session.close()
    await send_response(update, f"✅ خطِ «{name}» ساخته شد.", myawy_admin_menu_keyboard())
    await cb_admin_phone_lines(update, context)


@owner_only
async def cb_admin_phone_line_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    line_id = int(update.callback_query.data.split(":")[1])
    await _render_phone_line_view(update, context, line_id)


async def _render_phone_line_view(update, context, line_id: int):
    session = db.get_session()
    try:
        line = session.get(db.PhoneLine, line_id)
        if not line:
            await send_response(update, "این خط دیگه وجود نداره.", myawy_admin_menu_keyboard())
            return
        gens = session.query(db.PhoneGeneration).filter_by(line_id=line.id).order_by(db.PhoneGeneration.gen_index).all()
        rows = []
        for g in gens:
            status = "✅" if g.is_active else "⛔️"
            market = "🛒موجود" if g.is_market_available else "🚫ناموجود"
            banned = " 🔒ممنوعِ دستی" if g.manual_ban else (" 🔒ممنوع" if g.banned_from_platforms else "")
            rows.append([InlineKeyboardButton(
                f"{status} {g.name} | {market}{banned}", callback_data=f"admin_phone_gen_view:{g.id}")])
        rows.append([InlineKeyboardButton("➕ افزودنِ نسلِ جدید", callback_data=f"admin_phone_line_add_gen:{line.id}")])
        rows.append([InlineKeyboardButton(
            "⛔️ غیرفعال کردنِ خط" if line.is_active else "✅ فعال کردنِ خط",
            callback_data=f"admin_phone_line_toggle:{line.id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_phone_lines")])
        tag = "🃏 فیک" if line.is_fake else "📱 اصل"
        text = f"{tag} - {line.name}\n\nنسل‌ها (هر ۳ نسلِ جدیدتر، نسلِ ۳-قدیمی‌تر خودکار از پلتفرم‌های عادی ممنوع می‌شه):"
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_phone_line_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    line_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        line = session.get(db.PhoneLine, line_id)
        if line:
            line.is_active = not line.is_active
            session.commit()
    finally:
        session.close()
    await cb_admin_phone_line_view(update, context)


@owner_only
async def cb_admin_phone_line_add_gen(update: Update, context: ContextTypes.DEFAULT_TYPE):
    line_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        line = session.get(db.PhoneLine, line_id)
        is_fake = bool(line and line.is_fake)
    finally:
        session.close()
    hint = (
        "برای گوشیِ فیک معمولاً: قیمتِ ارزون، اعتبار/مهلتِ کوتاه، تعمیرِ ارزون (LCD ۹۰۰,۰۰۰ / سی‌پی‌یو ۱,۰۰۰,۰۰۰ / باتری ۵,۰۰۰,۰۰۰) و احتمالِ خرابیِ روزانه‌ی بالا (۹۰٪)."
        if is_fake else
        "برای گوشیِ اصل معمولاً: تعمیر LCD ۵,۰۰۰,۰۰۰ / باتری ۱۲,۰۰۰,۰۰۰ / سی‌پی‌یو ۱۸,۰۰۰,۰۰۰ و احتمالِ خرابیِ روزانه‌ی ۳۰٪."
    )
    await ask_for_input(
        update, context, f"📝 اسمِ نسلِ جدید رو بفرست (مثلا S1 یا هاپ۱).\n\nℹ️ {hint}",
        {"type": "phone_gen_add_name", "line_id": line_id}, "admin_state",
    )


@owner_only
async def cb_admin_phone_gen_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    gen_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.PhoneGeneration, gen_id)
        if not g:
            await send_response(update, "این نسل دیگه وجود نداره.", myawy_admin_menu_keyboard())
            return
        line = session.get(db.PhoneLine, g.line_id)
        rows = [
            [InlineKeyboardButton("✏️ قیمت", callback_data=f"admin_phone_gen_editprice:{g.id}"),
             InlineKeyboardButton("✏️ روزِ اعتبار", callback_data=f"admin_phone_gen_editvalidity:{g.id}")],
            [InlineKeyboardButton("✏️ مهلتِ شروعِ خرابی", callback_data=f"admin_phone_gen_editgrace:{g.id}"),
             InlineKeyboardButton("✏️ % خرابیِ روزانه", callback_data=f"admin_phone_gen_editbreakchance:{g.id}")],
            [InlineKeyboardButton("✏️ تعمیرِ LCD", callback_data=f"admin_phone_gen_editrepairlcd:{g.id}"),
             InlineKeyboardButton("✏️ تعمیرِ باتری", callback_data=f"admin_phone_gen_editrepairbattery:{g.id}")],
            [InlineKeyboardButton("✏️ تعمیرِ سی‌پی‌یو", callback_data=f"admin_phone_gen_editrepaircpu:{g.id}")],
            [InlineKeyboardButton(
                "🚫 همین الان ناموجودش کن" if g.is_market_available else "🛒 موجودش کن تو بازار",
                callback_data=f"admin_phone_gen_togglemarket:{g.id}")],
            [InlineKeyboardButton(
                "🔓 لغوِ ممنوعیتِ دستی (برگرد به خودکار)" if g.manual_ban else "🔒 ممنوعِ فوری از پلتفرم‌های عادی",
                callback_data=f"admin_phone_gen_toggleban:{g.id}")],
            [InlineKeyboardButton("⛔️ غیرفعال کردن" if g.is_active else "✅ فعال کردن", callback_data=f"admin_phone_gen_toggle:{g.id}")],
            [InlineKeyboardButton("🗑 حذفِ کاملِ این مدل", callback_data=f"admin_phone_gen_delete_ask:{g.id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_phone_line_view:{g.line_id}")],
        ]
        ban_txt = "بله (دستی 🔒)" if g.manual_ban else ("بله" if g.banned_from_platforms else "خیر")
        text = (
            f"{line.name if line else '?'} {g.name}\n\n"
            f"💵 قیمت: {fmt(g.price)} 🪙\n"
            f"📆 اعتبار: {g.validity_days} روز\n"
            f"⏳ مهلتِ شروعِ خرابی: {g.breakdown_grace_days} روز\n"
            f"🎲 احتمالِ خرابیِ روزانه: {fmt(g.daily_break_chance_pct)}٪\n"
            f"🛠 تعمیر: 📺{fmt(g.repair_lcd_price)} | 🔋{fmt(g.repair_battery_price)} | 💽{fmt(g.repair_cpu_price)}\n"
            f"🛒 تو بازار: {'موجود' if g.is_market_available else 'ناموجود'}\n"
            f"🔒 ممنوع از پلتفرم‌های عادی: {ban_txt}"
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_phone_gen_togglemarket(update: Update, context: ContextTypes.DEFAULT_TYPE):
    gen_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.PhoneGeneration, gen_id)
        if g:
            g.is_market_available = not g.is_market_available
            session.commit()
    finally:
        session.close()
    await cb_admin_phone_gen_view(update, context)


@owner_only
async def cb_admin_phone_gen_toggleban(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """ممنوعِ فوری از پلتفرم‌های عادی، بدونِ نیاز به ساختنِ ۳ نسلِ جدیدتر - هم
    برای خط‌های اصل هم فیک کار می‌کنه (برخلافِ قانونِ خودکار که فقط اصلاست)."""
    gen_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.PhoneGeneration, gen_id)
        if g:
            if g.manual_ban:
                g.manual_ban = False
                import myawy
                myawy._recompute_generation_bans(session, g.line_id)
            else:
                g.manual_ban = True
                g.banned_from_platforms = True
            session.commit()
    finally:
        session.close()
    await cb_admin_phone_gen_view(update, context)


@owner_only
async def cb_admin_phone_gen_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    gen_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.PhoneGeneration, gen_id)
        if g:
            g.is_active = not g.is_active
            session.commit()
    finally:
        session.close()
    await cb_admin_phone_gen_view(update, context)


@owner_only
async def cb_admin_phone_gen_delete_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    gen_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.PhoneGeneration, gen_id)
        if not g:
            await send_response(update, "این نسل دیگه وجود نداره.", myawy_admin_menu_keyboard())
            return
        owned_count = session.query(db.UserPhone).filter_by(generation_id=gen_id).count()
        name = g.name
        session.commit()
    finally:
        session.close()
    await send_response(
        update,
        f"🗑 مطمئنی می‌خوای مدلِ «{name}» رو کلا از بازی حذف کنی؟\n"
        f"{owned_count} گوشیِ خریداری‌شده از این مدل (چه تو کشو، چه تو آگهیِ بازارِ سیاه) هم به‌طور کامل حذف می‌شن.\n"
        "این کار برگشت‌ناپذیره!",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله، کلا حذفش کن", callback_data=f"admin_phone_gen_delete_confirm:{gen_id}"),
            InlineKeyboardButton("❌ انصراف", callback_data=f"admin_phone_gen_view:{gen_id}"),
        ]]),
    )


@owner_only
async def cb_admin_phone_gen_delete_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    gen_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.PhoneGeneration, gen_id)
        if not g:
            await send_response(update, "این نسل دیگه وجود نداره.", myawy_admin_menu_keyboard())
            return
        line_id = g.line_id
        name = g.name
        phone_ids = [row[0] for row in session.query(db.UserPhone.id).filter_by(generation_id=gen_id).all()]
        if phone_ids:
            session.query(db.BlackMarketListing).filter(db.BlackMarketListing.phone_id.in_(phone_ids)).delete(synchronize_session=False)
            session.query(db.UserPhone).filter(db.UserPhone.id.in_(phone_ids)).delete(synchronize_session=False)
        session.delete(g)
        session.commit()
    finally:
        session.close()
    await _render_phone_line_view(update, context, line_id)


_PHONE_GEN_EDIT_PROMPTS = {
    "admin_phone_gen_editprice": ("phone_gen_editprice", "💵 قیمتِ جدید رو بفرست:"),
    "admin_phone_gen_editvalidity": ("phone_gen_editvalidity", "📆 روزهای اعتبارِ جدید رو بفرست (عددِ صحیح):"),
    "admin_phone_gen_editgrace": ("phone_gen_editgrace", "⏳ چند روز بعد از خرید شروع به خراب‌شدن کنه؟ (عددِ صحیح):"),
    "admin_phone_gen_editbreakchance": ("phone_gen_editbreakchance", "🎲 احتمالِ خرابیِ روزانه‌ی هر قطعه رو بفرست (۰ تا ۱۰۰):"),
    "admin_phone_gen_editrepairlcd": ("phone_gen_editrepairlcd", "💵 هزینه‌ی تعمیرِ LCD رو بفرست:"),
    "admin_phone_gen_editrepairbattery": ("phone_gen_editrepairbattery", "💵 هزینه‌ی تعمیرِ باتری رو بفرست:"),
    "admin_phone_gen_editrepaircpu": ("phone_gen_editrepaircpu", "💵 هزینه‌ی تعمیرِ سی‌پی‌یو رو بفرست:"),
}


async def _cb_admin_phone_gen_edit_generic(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = update.callback_query.data
    prefix, gid = data.split(":")
    stype, prompt = _PHONE_GEN_EDIT_PROMPTS[prefix]
    await ask_for_input(update, context, prompt, {"type": stype, "id": int(gid)}, "admin_state")


@owner_only
async def cb_admin_phone_gen_editprice(update, context):
    await _cb_admin_phone_gen_edit_generic(update, context)


@owner_only
async def cb_admin_phone_gen_editvalidity(update, context):
    await _cb_admin_phone_gen_edit_generic(update, context)


@owner_only
async def cb_admin_phone_gen_editgrace(update, context):
    await _cb_admin_phone_gen_edit_generic(update, context)


@owner_only
async def cb_admin_phone_gen_editbreakchance(update, context):
    await _cb_admin_phone_gen_edit_generic(update, context)


@owner_only
async def cb_admin_phone_gen_editrepairlcd(update, context):
    await _cb_admin_phone_gen_edit_generic(update, context)


@owner_only
async def cb_admin_phone_gen_editrepairbattery(update, context):
    await _cb_admin_phone_gen_edit_generic(update, context)


@owner_only
async def cb_admin_phone_gen_editrepaircpu(update, context):
    await _cb_admin_phone_gen_edit_generic(update, context)


# ---------------------------------------------------------------------------
# مدیریتِ تاکسیِ هاپویی
# ---------------------------------------------------------------------------

CFG_TAXI_KEYS = [
    ("taxi_drive_hours_per_day", "⏳ سقفِ ساعتِ هر شیفت"),
    ("taxi_rest_hours_after", "😴 ساعتِ استراحتِ اجباری بعدِ هر شیفت"),
    ("taxi_station_return_minutes", "↩️ دقیقه‌ی برگشت به ایستگاه"),
    ("taxi_min_passengers_per_trip", "👥 حداقلِ مسافر در هر سفر"),
    ("taxi_max_passengers_per_trip", "👥 حداکثرِ مسافر در هر سفر"),
    ("taxi_gas_price_min_per_liter", "⛽️ حداقلِ قیمتِ هر لیتر بنزین"),
    ("taxi_gas_price_max_per_liter", "⛽️ حداکثرِ قیمتِ هر لیتر بنزین"),
    ("taxi_dirty_after_hours", "🧼 بعدِ چند ساعت از آخرین کارواش کثیف می‌شه"),
    ("taxi_carwash_cost", "🧼 هزینه‌ی کارواش"),
    ("taxi_dirty_fare_multiplier", "🧼 ضریبِ کرایه با ماشینِ کثیف (۰ تا ۱)"),
    ("taxi_dirty_extra_wait_minutes", "🧼 دقیقه‌ی اضافه‌ی انتظار با ماشینِ کثیف"),
    ("taxi_engine_base_trip_min", "🏎 سطح۱ موتور: حداقلِ دقیقه‌ی مسیر"),
    ("taxi_engine_base_trip_max", "🏎 سطح۱ موتور: حداکثرِ دقیقه‌ی مسیر"),
    ("taxi_engine_floor_trip_min", "🏎 سطحِ آخرِ موتور: حداقلِ دقیقه‌ی مسیر"),
    ("taxi_engine_floor_trip_max", "🏎 سطحِ آخرِ موتور: حداکثرِ دقیقه‌ی مسیر"),
    ("taxi_engine_upgrade_base_cost", "🏎 هزینه‌ی ارتقای سطح۱->۲ موتور"),
    ("taxi_engine_upgrade_growth", "🏎 ضریبِ رشدِ هزینه‌ی موتور به‌ازای هر سطح"),
    ("taxi_appeal_base_fare_per_min", "⭐️ سطح۱ محبوبیت: کرایه به‌ازای هر دقیقه‌ی هر مسافر"),
    ("taxi_appeal_fare_increment", "⭐️ افزایشِ کرایه به‌ازای هر سطحِ محبوبیت"),
    ("taxi_appeal_base_wait_min", "⭐️ سطح۱ محبوبیت: حداقلِ دقیقه‌ی انتظار"),
    ("taxi_appeal_base_wait_max", "⭐️ سطح۱ محبوبیت: حداکثرِ دقیقه‌ی انتظار"),
    ("taxi_appeal_floor_wait_min", "⭐️ سطحِ مرجعِ محبوبیت: حداقلِ دقیقه‌ی انتظار"),
    ("taxi_appeal_floor_wait_max", "⭐️ سطحِ مرجعِ محبوبیت: حداکثرِ دقیقه‌ی انتظار"),
    ("taxi_appeal_reference_max_level", "⭐️ سطحِ مرجع (که انتظار به کفش می‌رسه)"),
    ("taxi_appeal_upgrade_base_cost", "⭐️ هزینه‌ی ارتقای سطح۱->۲ محبوبیت"),
    ("taxi_appeal_upgrade_growth", "⭐️ ضریبِ رشدِ هزینه‌ی محبوبیت به‌ازای هر سطح"),
]


@owner_only
async def cb_admin_taxi_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rows = [
        [InlineKeyboardButton("🚗 مدیریتِ مدل‌های ماشین", callback_data="admin_taxi_cars_menu")],
        [InlineKeyboardButton("🎖 مدیریتِ مقام‌های محبوبیت", callback_data="admin_taxi_ranks_menu")],
        [InlineKeyboardButton("⚙️ تنظیماتِ سراسریِ تاکسی", callback_data="admin_taxi_cfg")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")],
    ]
    await send_response(
        update,
        "🚕 مدیریتِ تاکسیِ هاپویی\n\n"
        "اول یه مدلِ ماشین بساز تا پلیرها بتونن بخرن، بعد (اختیاری) مقام‌های "
        "محبوبیت رو بچین. نرخِ کرایه/انتظار/هزینه‌ها همه از «تنظیماتِ سراسری» میان.",
        InlineKeyboardMarkup(rows),
    )


@owner_only
async def cb_admin_taxi_cfg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = ["⚙️ تنظیماتِ سراسریِ تاکسی:\n"]
        rows = []
        for key, label in CFG_TAXI_KEYS:
            val = db.cfg_get(session, key)
            lines.append(f"• {label}: {val}")
            rows.append([InlineKeyboardButton(f"✏️ {label}", callback_data=f"admin_cfg_edit:{key}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_taxi_menu")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


# --- مدل‌های ماشینِ تاکسی --------------------------------------------------

@owner_only
async def cb_admin_taxi_cars_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        cars = session.query(db.TaxiCarModel).order_by(db.TaxiCarModel.price).all()
        rows = []
        for c in cars:
            status = "✅" if c.is_active else "⛔️"
            rows.append([InlineKeyboardButton(f"{status} {c.name} | {fmt(c.price)}🪙", callback_data=f"admin_taxi_car_view:{c.id}")])
        rows.append([InlineKeyboardButton("➕ افزودنِ مدلِ جدید", callback_data="admin_taxi_car_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_taxi_menu")])
        text = "🚗 مدل‌های ماشینِ تاکسی:" if cars else "🚗 هنوز هیچ مدلی نساختی."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_taxi_car_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(
        update, context, "📝 اسمِ مدلِ جدید رو بفرست (مثلا: پراید هاپویی):",
        {"type": "taxi_car_add_name"}, "admin_state",
    )


@owner_only
async def cb_admin_taxi_car_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    car_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        c = session.get(db.TaxiCarModel, car_id)
        if not c:
            await send_response(update, "این مدل پیدا نشد.", None)
            return
        rows = [
            [InlineKeyboardButton("✏️ قیمت", callback_data=f"admin_taxi_car_editprice:{c.id}"),
             InlineKeyboardButton("✏️ ظرفیتِ باک", callback_data=f"admin_taxi_car_edittank:{c.id}")],
            [InlineKeyboardButton("✏️ مصرف/ساعت", callback_data=f"admin_taxi_car_editusage:{c.id}"),
             InlineKeyboardButton("✏️ سقفِ سطحِ موتور", callback_data=f"admin_taxi_car_editenginemax:{c.id}")],
            [InlineKeyboardButton("⛔️ غیرفعال کردن" if c.is_active else "✅ فعال کردن", callback_data=f"admin_taxi_car_toggle:{c.id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_taxi_cars_menu")],
        ]
        text = (
            f"🚗 {c.name}\n\n"
            f"💵 قیمت: {fmt(c.price)} 🪙\n"
            f"⛽️ ظرفیتِ باک: {fmt(c.gas_tank_liters)} لیتر\n"
            f"⛽️ مصرف: {fmt(c.gas_use_per_hour)} لیتر/ساعت\n"
            f"🏎 سقفِ سطحِ موتور: {c.engine_max_level}\n"
            f"وضعیت: {'فعال (تو بازار)' if c.is_active else 'غیرفعال'}"
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_taxi_car_toggle(update: Update, context: ContextTypes.DEFAULT_TYPE):
    car_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        c = session.get(db.TaxiCarModel, car_id)
        if c:
            c.is_active = not c.is_active
            session.commit()
    finally:
        session.close()
    await cb_admin_taxi_car_view(update, context)


_TAXI_CAR_EDIT_PROMPTS = {
    "admin_taxi_car_editprice": ("taxi_car_editprice", "💵 قیمتِ جدید رو بفرست:"),
    "admin_taxi_car_edittank": ("taxi_car_edittank", "⛽️ ظرفیتِ جدیدِ باک رو بفرست (لیتر):"),
    "admin_taxi_car_editusage": ("taxi_car_editusage", "⛽️ مصرفِ جدید رو بفرست (لیتر در ساعتِ کار):"),
    "admin_taxi_car_editenginemax": ("taxi_car_editenginemax", "🏎 سقفِ جدیدِ سطحِ موتور رو بفرست (عددِ صحیح):"),
}


async def _cb_admin_taxi_car_edit_generic(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = update.callback_query.data
    prefix, cid = data.split(":")
    stype, prompt = _TAXI_CAR_EDIT_PROMPTS[prefix]
    await ask_for_input(update, context, prompt, {"type": stype, "id": int(cid)}, "admin_state")


@owner_only
async def cb_admin_taxi_car_editprice(update, context):
    await _cb_admin_taxi_car_edit_generic(update, context)


@owner_only
async def cb_admin_taxi_car_edittank(update, context):
    await _cb_admin_taxi_car_edit_generic(update, context)


@owner_only
async def cb_admin_taxi_car_editusage(update, context):
    await _cb_admin_taxi_car_edit_generic(update, context)


@owner_only
async def cb_admin_taxi_car_editenginemax(update, context):
    await _cb_admin_taxi_car_edit_generic(update, context)


# --- مقام‌های محبوبیتِ تاکسی (کلونِ دقیقِ مقام‌های کارخونه) -----------------

@owner_only
async def cb_admin_taxi_ranks_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import taxi
    session = db.get_session()
    try:
        ranks = taxi.taxi_ranks_ordered(session)
        rows = []
        for r in ranks:
            rows.append([InlineKeyboardButton(f"{r.order}. {r.name} ({r.num_levels} سطح)", callback_data=f"admin_taxi_rank_view:{r.id}")])
        rows.append([InlineKeyboardButton("➕ افزودنِ مقامِ جدید", callback_data="admin_taxi_rank_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_taxi_menu")])
        text = (
            "🎖 مدیریتِ مقام‌های محبوبیتِ تاکسی\n\n"
            "سطح‌ها بینِ مقام‌ها مشترکن (سطح ۵ مقامِ اول == سطح ۵ مقامِ دوم، از "
            "«تنظیماتِ سراسری» می‌سازیمشون)؛ فقط فرقِ مقام‌ها تعداد سطح‌هاشونه. "
            "پیشِ‌فرض هنوز هیچ مقامی نساختی - تا نسازی، پلیرها اصلا نمی‌تونن "
            "محبوبیتشون رو ارتقا بدن."
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_taxi_rank_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "📝 اسمِ مقامِ جدید رو بفرست (مثلا: 🚕 راننده‌ی تازه‌کار):", {"type": "taxi_rank_add_name"}, "admin_state")


@owner_only
async def cb_admin_taxi_rank_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import taxi
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        rank = session.get(db.TaxiRank, rid)
        if not rank:
            await send_response(update, "این مقام پیدا نشد.", None)
            return
        ranks = taxi.taxi_ranks_ordered(session)
        rows = [
            [InlineKeyboardButton("✏️ تغییرِ اسم", callback_data=f"admin_taxi_rank_rename:{rid}")],
            [InlineKeyboardButton("➕ افزودنِ یک سطح", callback_data=f"admin_taxi_rank_addlevel:{rid}")],
        ]
        if rank.num_levels > 1:
            rows.append([InlineKeyboardButton("➖ کم‌کردنِ یک سطح", callback_data=f"admin_taxi_rank_removelevel:{rid}")])
        if len(ranks) > 1:
            rows.append([InlineKeyboardButton("🗑 حذفِ این مقام", callback_data=f"admin_taxi_rank_delete:{rid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_taxi_ranks_menu")])
        text = (
            f"{rank.name}\nترتیبِ مقام: {rank.order}\n"
            f"تعدادِ سطح: {rank.num_levels} (از سطح ۱ تا {rank.num_levels})\n\n"
            "مقدارِ هر سطح (کرایه/انتظار/هزینه) از «تنظیماتِ سراسری» محاسبه می‌شه، "
            "چون بینِ همه‌ی مقام‌ها یکیه."
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_taxi_rank_rename(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "✏️ اسمِ جدیدِ مقام رو بفرست:", {"type": "taxi_rank_rename", "id": rid}, "admin_state")


@owner_only
async def cb_admin_taxi_rank_addlevel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        rank = session.get(db.TaxiRank, rid)
        if rank:
            rank.num_levels += 1
            session.commit()
    finally:
        session.close()
    await cb_admin_taxi_rank_view(update, context)


@owner_only
async def cb_admin_taxi_rank_removelevel(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        rank = session.get(db.TaxiRank, rid)
        if rank and rank.num_levels > 1:
            rank.num_levels -= 1
            stuck = session.query(db.User).filter(
                db.User.taxi_rank_order == rank.order,
                db.User.taxi_level > rank.num_levels,
            ).all()
            for u in stuck:
                u.taxi_level = rank.num_levels
            session.commit()
    finally:
        session.close()
    await cb_admin_taxi_rank_view(update, context)


@owner_only
async def cb_admin_taxi_rank_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import taxi
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        ranks = taxi.taxi_ranks_ordered(session)
        rank = session.get(db.TaxiRank, rid)
        if rank and len(ranks) > 1:
            deleted_order = rank.order
            session.delete(rank)
            session.flush()
            remaining = session.query(db.TaxiRank).filter(db.TaxiRank.order > deleted_order).order_by(db.TaxiRank.order).all()
            for r in remaining:
                r.order -= 1
            new_max_order = len(ranks) - 1
            fallback_order = max(1, min(deleted_order - 1, new_max_order)) if new_max_order else 1
            stuck_users = session.query(db.User).filter(db.User.taxi_rank_order == deleted_order).all()
            fallback_rank = session.query(db.TaxiRank).filter_by(order=fallback_order).first()
            for u in stuck_users:
                u.taxi_rank_order = fallback_order
                u.taxi_level = fallback_rank.num_levels if fallback_rank else 1
            shifted_users = session.query(db.User).filter(db.User.taxi_rank_order > deleted_order).all()
            for u in shifted_users:
                u.taxi_rank_order -= 1
            session.commit()
    finally:
        session.close()
    await cb_admin_taxi_ranks_menu(update, context)


# ---------------------------------------------------------------------------
# گزارش‌های هاپویی (گزارشِ پلیرها از همدیگه)
# ---------------------------------------------------------------------------

@owner_only
async def cb_admin_reports_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        reports = (
            session.query(db.Report)
            .filter_by(status="pending")
            .order_by(db.Report.created_at.desc())
            .limit(30)
            .all()
        )
        rows = []
        for r in reports:
            reporter = session.get(db.User, r.reporter_id)
            reported = session.get(db.User, r.reported_user_id)
            label = f"👤 {reported.display_name() if reported else r.reported_user_id} (از {reporter.display_name() if reporter else r.reporter_id})"
            rows.append([InlineKeyboardButton(label, callback_data=f"admin_report_view:{r.id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        text = "📋 گزارش‌های در انتظارِ بررسی:" if reports else "📋 فعلاً گزارشِ درانتظاری وجود نداره."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_report_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.Report, rid)
        if not r:
            await send_response(update, "این گزارش پیدا نشد.", None)
            return
        reporter = session.get(db.User, r.reporter_id)
        reported = session.get(db.User, r.reported_user_id)
        lines = [
            f"👤 گزارش‌شده: {reported.display_name() if reported else r.reported_user_id} (آیدی: {r.reported_user_id})",
            f"🗣 گزارش‌دهنده: {reporter.display_name() if reporter else r.reporter_id}",
        ]
        if r.reason:
            lines.append(f"📝 دلیل: {r.reason}")
        if r.message_link:
            lines.append(f"🔗 لینکِ پیام: {r.message_link}")
        lines.append(f"وضعیت: {r.status}")
        rows = []
        if r.status == "pending":
            rows.append([
                InlineKeyboardButton("🔒 ۲۰ دقیقه", callback_data=f"admin_report_accept:{rid}:20"),
                InlineKeyboardButton("🔒 ۵۰ دقیقه", callback_data=f"admin_report_accept:{rid}:50"),
            ])
            rows.append([
                InlineKeyboardButton("🔒 مدتِ دلخواه", callback_data=f"admin_report_accept_custom:{rid}"),
                InlineKeyboardButton("🔒 لایف‌تایم", callback_data=f"admin_report_accept:{rid}:l"),
            ])
            rows.append([InlineKeyboardButton("❌ ردِ گزارش", callback_data=f"admin_report_reject:{rid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_reports_menu")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_report_reject(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.Report, rid)
        if r and r.status == "pending":
            r.status = "rejected"
            r.resolved_at = db.now()
            session.commit()
    finally:
        session.close()
    await cb_admin_reports_menu(update, context)


@owner_only
async def cb_admin_report_accept(update: Update, context: ContextTypes.DEFAULT_TYPE):
    _, rid, duration_arg = update.callback_query.data.split(":")
    rid = int(rid)
    session = db.get_session()
    try:
        r = session.get(db.Report, rid)
        if not r or r.status != "pending":
            await update.callback_query.answer("این گزارش دیگه در انتظار نیست.", show_alert=True)
            return
        if not is_owner(update.effective_user.id) and db.is_any_admin(session, r.reported_user_id):
            session.commit()
            await update.callback_query.answer("❌ فقط مالکِ اصلی می‌تونه گزارشِ رو مالک/ادمین رو قبول کنه.", show_alert=True)
            return
        u = session.get(db.User, r.reported_user_id)
        if not u:
            u = db.User(telegram_id=r.reported_user_id)
            session.add(u)
        if duration_arg == "l":
            u.jailed_until = db.JAIL_FOREVER
        else:
            u.jailed_until = db.now() + datetime.timedelta(minutes=int(duration_arg))
        r.status = "accepted"
        r.resolved_at = db.now()
        session.commit()
    finally:
        session.close()
    await cb_admin_reports_menu(update, context)


@owner_only
async def cb_admin_report_accept_custom(update: Update, context: ContextTypes.DEFAULT_TYPE):
    rid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, "چند دقیقه بره زندان؟ یه عددِ صحیحِ مثبت بفرست:", {"type": "report_accept_custom", "id": rid}, "admin_state")


# ---------------------------------------------------------------------------
# مدیریتِ کارتِ هاپویی
# ---------------------------------------------------------------------------

CFG_CARDS_KEYS = [
    ("card_default_event_days", "🎴 مهلتِ پیش‌فرضِ ایونت (روز)"),
    ("card_daily_free_rare", "🔹 تعدادِ توکنِ رایگانِ روزانه‌ی کمیاب"),
    ("card_daily_free_wild", "🔸 تعدادِ توکنِ رایگانِ روزانه‌ی جنگلی"),
    ("card_daily_free_legend", "👑 تعدادِ توکنِ رایگانِ روزانه‌ی لجند"),
    ("card_daily_paid_max", "💳 سقفِ توکنِ خریدنیِ روزانه (جمعِ هر سه لیست)"),
    ("card_paid_price_rare", "💵 قیمتِ توکنِ خریدنیِ کمیاب"),
    ("card_paid_price_wild", "💵 قیمتِ توکنِ خریدنیِ جنگلی"),
    ("card_paid_price_legend", "💵 قیمتِ توکنِ خریدنیِ لجند"),
    ("card_duplicate_cap_pct", "🎲 سقفِ درصدِ گرفتنِ کارتِ تکراری"),
    ("card_duplicate_max_extra_copies", "🔢 سقفِ تعدادِ کارتِ تکراری (با توکنِ رایگان)"),
    ("card_list1_reward_crypto_units", "🎁 پاداشِ لیستِ کمیاب - واحدِ ارزِ دیجیتال"),
    ("card_list2_reward_food_units", "🎁 پاداشِ لیستِ جنگلی - واحدِ غذای سگ"),
    ("card_list3_reward_bank_points", "🎁 پاداشِ لیستِ لجند - هاپ پوینتِ بانک"),
    ("card_duplicate_sell_price", "💰 قیمتِ فروشِ هر کارتِ تکراری (بعدِ اتمامِ ایونت)"),
]


@owner_only
async def cb_admin_cards_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import cards
    session = db.get_session()
    try:
        event = cards.get_active_event(session)
        rows = []
        if event:
            nowt = datetime.datetime.utcnow()
            remain = (event.ends_at - nowt).days
            status_txt = f"🟢 ایونت فعاله - {remain} روزِ دیگه تموم می‌شه (یا دستی تمومش کن)"
            rows.append([InlineKeyboardButton("📜 مدیریتِ لیست‌های کارت", callback_data="admin_cards_lists_menu")])
            rows.append([InlineKeyboardButton("⏹ پایانِ دستیِ ایونت", callback_data="admin_cards_end_ask")])
        else:
            status_txt = "🔴 الان هیچ ایونتی فعال نیست."
            rows.append([InlineKeyboardButton("▶️ شروعِ ایونتِ جدید", callback_data="admin_cards_start_ask")])
        rows.append([InlineKeyboardButton("⚙️ تنظیماتِ سراسریِ کارت", callback_data="admin_cards_cfg")])
        rows.append([InlineKeyboardButton("🗑 حذفِ کاملِ دیتابیسِ آخرین ایونت", callback_data="admin_cards_delete_ask")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        session.commit()
        await send_response(update, f"🎴 مدیریتِ کارتِ هاپویی\n\n{status_txt}", InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_cards_cfg(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        lines = ["⚙️ تنظیماتِ سراسریِ کارتِ هاپویی:\n"]
        rows = []
        for key, label in CFG_CARDS_KEYS:
            val = db.cfg_get(session, key)
            lines.append(f"• {label}: {val}")
            rows.append([InlineKeyboardButton(f"✏️ {label}", callback_data=f"admin_cfg_edit:{key}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_cards_menu")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_cards_start_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        default_days = db.cfg_get_int(session, "card_default_event_days")
        session.commit()
    finally:
        session.close()
    await ask_for_input(
        update, context, f"📅 این ایونت چند روز مهلت داشته باشه؟ (پیشنهاد: {default_days})",
        {"type": "cards_event_start_days"}, "admin_state",
    )


@owner_only
async def cb_admin_cards_end_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await send_response(
        update,
        "⏹ مطمئنی می‌خوای همین الان دستی ایونت رو تموم کنی؟ کارت‌های تکراریِ همه‌کس بعدش قابل‌فروش (به بازی) می‌شه.",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله، تمومش کن", callback_data="admin_cards_end_confirm"),
            InlineKeyboardButton("❌ انصراف", callback_data="admin_cards_menu"),
        ]]),
    )


@owner_only
async def cb_admin_cards_end_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import cards
    session = db.get_session()
    try:
        event = cards.get_active_event(session)
        if event:
            event.is_active = False
            event.ended_manually = True
            session.commit()
    finally:
        session.close()
    await cb_admin_cards_menu(update, context)


@owner_only
async def cb_admin_cards_delete_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        event = session.query(db.CardEvent).order_by(db.CardEvent.id.desc()).first()
        if not event:
            session.commit()
            await send_response(update, "هیچ ایونتی وجود نداره که حذف بشه.", None)
            return
        session.commit()
    finally:
        session.close()
    await send_response(
        update,
        "🗑 مطمئنی می‌خوای دیتابیسِ آخرین ایونتِ کارت رو کاملاً حذف کنی؟ همه‌ی کارت‌ها، توکن‌ها و آگهی‌های همه‌ی پلیرها "
        "برای این ایونت از بین می‌ره. این کار برگشت‌ناپذیره!",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله، کلا حذفش کن", callback_data="admin_cards_delete_confirm"),
            InlineKeyboardButton("❌ انصراف", callback_data="admin_cards_menu"),
        ]]),
    )


@owner_only
async def cb_admin_cards_delete_confirm(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        event = session.query(db.CardEvent).order_by(db.CardEvent.id.desc()).first()
        if event:
            eid = event.id
            session.query(db.CardListing).filter_by(event_id=eid).delete(synchronize_session=False)
            session.query(db.UserCard).filter_by(event_id=eid).delete(synchronize_session=False)
            session.query(db.UserCardTokens).filter_by(event_id=eid).delete(synchronize_session=False)
            session.query(db.UserCardProgress).filter_by(event_id=eid).delete(synchronize_session=False)
            session.query(db.CardSlot).filter_by(event_id=eid).delete(synchronize_session=False)
            session.delete(event)
            session.commit()
    finally:
        session.close()
    await send_response(update, "🗑 دیتابیسِ اون ایونت کاملاً حذف شد.", myawy_admin_menu_keyboard())
    await cb_admin_cards_menu(update, context)


# --- مدیریتِ لیست‌ها -------------------------------------------------------

@owner_only
async def cb_admin_cards_lists_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import cards
    session = db.get_session()
    try:
        event = cards.get_active_event(session)
        if not event:
            await send_response(update, "الان هیچ ایونتی فعال نیست.", None)
            return
        rows = []
        for list_no, name in cards.LIST_NAMES.items():
            n = session.query(db.CardSlot).filter_by(event_id=event.id, list_no=list_no).count()
            rows.append([InlineKeyboardButton(f"{name} ({n} کارت)", callback_data=f"admin_cards_list_detail:{list_no}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_cards_menu")])
        session.commit()
        await send_response(update, "📜 کدوم لیست رو می‌خوای مدیریت کنی؟", InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_cards_list_detail(update: Update, context: ContextTypes.DEFAULT_TYPE):
    import cards
    list_no = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        event = cards.get_active_event(session)
        if not event:
            await send_response(update, "الان هیچ ایونتی فعال نیست.", None)
            return
        slots = cards._slots_for_list(session, event, list_no)
        preview = "\n".join(f"{s.slot_index}. {s.emoji} - {fmt(s.base_percent)}٪" + (f" ⭐️{fmt(s.special_reward_points)}🪙" if s.is_special else "") for s in slots)
        rows = [
            [InlineKeyboardButton("📋 پیست‌کردنِ کلِ ایموجی‌ها (متن)", callback_data=f"admin_cards_paste_emoji:{list_no}")],
            [InlineKeyboardButton("📊 پیست‌کردنِ کلِ درصدها (متن)", callback_data=f"admin_cards_paste_percent:{list_no}")],
            [InlineKeyboardButton("✏️ ویرایشِ یه خونه‌ی خاص", callback_data=f"admin_cards_edit_slot_ask:{list_no}")],
            [InlineKeyboardButton("⭐️ تنظیمِ کارتِ ویژه", callback_data=f"admin_cards_special_ask:{list_no}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_cards_lists_menu")],
        ]
        text = f"{cards.LIST_NAMES[list_no]}\n\n" + (preview if preview else "هنوز کارتی تعریف نشده - از «پیست‌کردنِ ایموجی‌ها» شروع کن.")
        session.commit()
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_cards_paste_emoji(update: Update, context: ContextTypes.DEFAULT_TYPE):
    list_no = int(update.callback_query.data.split(":")[1])
    await ask_for_input(
        update, context,
        "📋 کلِ ایموجی‌ها رو با فرمتِ «1:😀2:😁3:😂...» بفرست (دقیقا مثلِ چیزی که تو گروه می‌نویسی؛ فاصله/خطِ جدید مهم نیست):",
        {"type": "cards_paste_emoji", "list_no": list_no}, "admin_state",
    )


@owner_only
async def cb_admin_cards_paste_percent(update: Update, context: ContextTypes.DEFAULT_TYPE):
    list_no = int(update.callback_query.data.split(":")[1])
    await ask_for_input(
        update, context,
        "📊 کلِ درصدها رو با فرمتِ «1—2٪ 2—17٪ 3—5٪...» بفرست (امکانِ گذاشتنِ ایموجی وسطش هم هست، مهم نیست):",
        {"type": "cards_paste_percent", "list_no": list_no}, "admin_state",
    )


@owner_only
async def cb_admin_cards_edit_slot_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    list_no = int(update.callback_query.data.split(":")[1])
    await ask_for_input(
        update, context, "شماره‌ی کدوم خونه رو می‌خوای ویرایش کنی؟ (عددِ صحیح):",
        {"type": "cards_edit_slot_number", "list_no": list_no}, "admin_state",
    )


@owner_only
async def cb_admin_cards_special_ask(update: Update, context: ContextTypes.DEFAULT_TYPE):
    list_no = int(update.callback_query.data.split(":")[1])
    await ask_for_input(
        update, context, "شماره‌ی کدوم خونه رو می‌خوای «ویژه» کنی (یا از حالتِ ویژه دربیاری)؟ (عددِ صحیح):",
        {"type": "cards_special_number", "list_no": list_no}, "admin_state",
    )


# ---------------------------------------------------------------------------
# مدیریتِ کدهای جایزه‌ی هاپویی
# ---------------------------------------------------------------------------

@owner_only
async def cb_admin_redeem_menu(update: Update, context: ContextTypes.DEFAULT_TYPE):
    session = db.get_session()
    try:
        codes = session.query(db.RedeemCode).filter_by(is_active=True).order_by(db.RedeemCode.created_at.desc()).all()
        rows = []
        for c in codes:
            uses = session.query(db.RedeemCodeUse).filter_by(code_id=c.id).count()
            exp_txt = c.expires_at.strftime("%Y-%m-%d") if c.expires_at else "بدونِ انقضا"
            rows.append([InlineKeyboardButton(
                f"{c.code} | {fmt(c.reward_points)}🪙 | {uses} استفاده | تا {exp_txt}",
                callback_data=f"admin_redeem_view:{c.id}")])
        rows.append([InlineKeyboardButton("➕ ساختنِ کدِ جدید", callback_data="admin_redeem_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")])
        text = "🎁 کدهای جایزه‌ی فعال:" if codes else "🎁 هنوز هیچ کدی نساختی."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_redeem_view(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        c = session.get(db.RedeemCode, cid)
        if not c:
            await send_response(update, "این کد پیدا نشد.", None)
            return
        uses = session.query(db.RedeemCodeUse).filter_by(code_id=c.id).count()
        exp_txt = c.expires_at.strftime("%Y-%m-%d %H:%M") if c.expires_at else "بدونِ انقضا"
        text = (
            f"🎁 کد: {c.code}\n"
            f"💵 پاداش: {fmt(c.reward_points)} 🪙\n"
            f"📅 انقضا: {exp_txt}\n"
            f"👥 تعدادِ استفاده: {uses}"
        )
        rows = [[InlineKeyboardButton("🗑 حذفِ این کد", callback_data=f"admin_redeem_delete:{c.id}")],
                [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_redeem_menu")]]
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@owner_only
async def cb_admin_redeem_delete(update: Update, context: ContextTypes.DEFAULT_TYPE):
    cid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        c = session.get(db.RedeemCode, cid)
        if c:
            session.query(db.RedeemCodeUse).filter_by(code_id=c.id).delete(synchronize_session=False)
            session.delete(c)
            session.commit()
    finally:
        session.close()
    await cb_admin_redeem_menu(update, context)


@owner_only
async def cb_admin_redeem_add(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await ask_for_input(update, context, "📝 متنِ کد رو بفرست (مثلا HOP2026):", {"type": "redeem_add_code"}, "admin_state")


# ---------------------------------------------------------------------------
# ورودی متنیِ منتظرِ مقدار (فقط برای مالک)
# ---------------------------------------------------------------------------


async def admin_awaiting_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    # قبلاً اینجا `is_owner` چک می‌شد که یعنی هیچ ادمینِ فرعی‌ای (even با
    # دسترسیِ کامل) نمی‌تونست جوابِ متنیِ هیچ پرامپتی رو کامل کنه (چون همون
    # لحظه که جواب می‌داد، رد می‌شد) - در حالی که خودِ دکمه‌ای که این پرامپت رو
    # باز کرده بود ممکن بود بر اساسِ دسترسیِ اون ادمین مجاز بوده باشه. الان هر
    # ادمینی (فرعی یا اصلی) می‌تونه جواب بده - چون دکمه‌ای که اول این state رو
    # ساخته، خودش قبلاً از رویِ دسته‌بندیِ مجوز چک شده (نگاه کن به
    # _admin_permission_category)؛ فلوهای مخصوصِ مالک (مثلِ افزودن/حذفِ ادمین)
    # هم چون دکمه‌شون OWNER_EXCLUSIVE-ه، اصلاً به ادمینِ فرعی نشون داده نمی‌شه.
    session_check = db.get_session()
    try:
        allowed = db.is_any_admin(session_check, update.effective_user.id)
    finally:
        session_check.close()
    if not allowed:
        return
    state = context.user_data.get("admin_state")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return  # این پیام ریپلای به پرامپتِ ما نیست - نادیده بگیر

    text = (update.message.text or "").strip()
    session = db.get_session()
    try:
        stype = state["type"]

        if stype in ("help_title_new", "help_title_edit", "help_desc_edit"):
            session.close()
            context.user_data.pop("admin_state", None)
            await guide.help_awaiting_handler(update, context, state)
            raise ApplicationHandlerStop

        if stype.startswith("referral_"):
            session.close()
            context.user_data.pop("admin_state", None)
            import referral_ui
            await referral_ui.ref_admin_awaiting_handler(update, context, state)
            raise ApplicationHandlerStop

        if stype.startswith("mission_"):
            session.close()
            context.user_data.pop("admin_state", None)
            import mission_admin
            await mission_admin.mission_admin_awaiting_handler(update, context, state)
            raise ApplicationHandlerStop

        if stype.startswith("bp_"):
            session.close()
            context.user_data.pop("admin_state", None)
            import battlepass_admin
            await battlepass_admin.bp_admin_awaiting_handler(update, context, state)
            raise ApplicationHandlerStop

        if stype.startswith("heist_"):
            session.close()
            context.user_data.pop("admin_state", None)
            import heist_admin
            await heist_admin.heist_admin_awaiting_handler(update, context, state)
            raise ApplicationHandlerStop

        if stype.startswith("war_"):
            session.close()
            context.user_data.pop("admin_state", None)
            import war_admin
            await war_admin.war_admin_awaiting_handler(update, context, state)
            raise ApplicationHandlerStop

        if stype.startswith("smg_"):
            session.close()
            context.user_data.pop("admin_state", None)
            await smuggling.smuggling_awaiting_handler(update, context, state)
            raise ApplicationHandlerStop

        if stype == "cfg":
            try:
                float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if state["key"].startswith("casino_rr_") or state["key"].startswith("casino_mafia_"):
                mod = __import__("roulette") if state["key"].startswith("casino_rr_") else __import__("mafia")
                err = mod.validate_cfg(state["key"], text)
                if err:
                    context.user_data.pop("admin_state", None)
                    await update.message.reply_text(f"{err}\nدوباره از دکمه‌ی مربوطه شروع کن.")
                    raise ApplicationHandlerStop
                text = str(int(float(text)))
            db.cfg_set(session, state["key"], text)
            await update.message.reply_text(f"✅ مقدار «{state['key']}» به {text} تغییر کرد.")

        elif stype == "player_search":
            if not text.isdigit():
                await update.message.reply_text("آیدی باید عدد باشه.")
                raise ApplicationHandlerStop
            uid = int(text)
            user = session.get(db.User, uid)
            if not user:
                await update.message.reply_text("❌ این کاربر هنوز با ربات کار نکرده (رکوردی نداره).")
            else:
                await show_player_card(None, context, uid, update=update)

        elif stype == "player_field":
            import economy
            try:
                value = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            user = session.get(db.User, state["uid"])
            if not user:
                await update.message.reply_text("❌ کاربر پیدا نشد.")
            else:
                field = state["field"]
                if field == "level":
                    user.level = int(value)
                elif field == "lvl":
                    user.lvl = max(1, min(db.MAX_LVL, int(value)))
                elif field == "factory_rank_order":
                    rank = economy.get_rank_by_order(session, int(value))
                    if not rank:
                        await update.message.reply_text("❌ مقامی با این ترتیب پیدا نشد.")
                        raise ApplicationHandlerStop
                    user.factory_rank_order = int(value)
                    user.factory_level = min(user.factory_level or 1, rank.num_levels)
                    economy.sync_user_production(session, user)
                elif field == "factory_level":
                    rank = economy.current_rank(session, user)
                    lvl = int(value)
                    if rank and lvl > rank.num_levels:
                        lvl = rank.num_levels
                    if lvl < 1:
                        lvl = 1
                    user.factory_level = lvl
                    economy.sync_user_production(session, user)
                else:
                    setattr(user, field, value)
                session.commit()
                await update.message.reply_text(f"✅ فیلد «{field}» برای کاربر {state['uid']} به {value} تغییر کرد.")

        elif stype == "add_points_self":
            try:
                value = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            owner_user = db.get_or_create_user(session, update.effective_user)
            owner_user.hop_points += value
            session.commit()
            await update.message.reply_text(f"✅ {fmt(value)} 🪙 به موجودیت اضافه شد. موجودی جدید: {fmt(owner_user.hop_points)} 🪙")

        elif stype == "lottery_prize":
            try:
                prize = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if prize <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(update, context, "🏆 چند نفر قراره برنده بشن؟ یه عدد صحیح بفرست (مثلا 3):", {"type": "lottery_winner_count", "prize": prize}, "admin_state")
            raise ApplicationHandlerStop

        elif stype == "lottery_winner_count":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            winner_count = int(text)
            prize = state["prize"]
            event = db.LotteryEvent(prize_amount=prize, winner_count=winner_count, is_active=True)
            event.set_participants([])
            event.set_winners([])
            session.add(event)
            session.commit()
            sent_count = await _broadcast_lottery_start(context, session, event)
            context.user_data.pop("admin_state", None)
            if sent_count == 0:
                await update.message.reply_text(
                    "⚠️ قرعه‌کشی با موفقیت ساخته شد ولی هیچ گروهی برای اعلام پیدا نشد "
                    "(هنوز پیامی از گروه‌ها ندیدم). به‌محض اینکه کسی تو یه گروه پیام بده، "
                    "می‌تونی دوباره از اونجا با «قرعه کشی هاپ» وضعیتش رو ببینه."
                )
            else:
                await update.message.reply_text(
                    f"✅ قرعه‌کشی با جایزه‌ی {fmt(prize)} 🪙 برای هرکدوم از {winner_count} برنده، "
                    f"تو {sent_count} گروه اعلام شد!"
                )

        elif stype == "currency_add_name":
            await ask_for_input_reply(update, context, "حالا یک ایموجی برای این ارز بفرست (مثلا 🚀):", {"type": "currency_add_emoji", "name": text}, "admin_state")
            raise ApplicationHandlerStop

        elif stype == "currency_add_emoji":
            await ask_for_input_reply(
                update, context, "قیمت خرید هر واحد (به هاپ پوینت) رو بفرست:",
                {"type": "currency_add_buy", "name": state["name"], "emoji": text}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "currency_add_buy":
            try:
                buy_price = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "قیمت فروش هر واحد رو بفرست:",
                {"type": "currency_add_sell", "name": state["name"], "emoji": state["emoji"], "buy": buy_price}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "currency_add_sell":
            try:
                sell_price = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            c = db.Currency(name=state["name"], emoji=state["emoji"], buy_price=state["buy"], sell_price=sell_price)
            session.add(c)
            session.commit()
            await update.message.reply_text(f"✅ ارز «{state['emoji']} {state['name']}» ساخته شد!")

        elif stype == "product_add_name":
            await ask_for_input_reply(update, context, "حالا یک ایموجی برای این محصول بفرست (مثلا ⚽):", {"type": "product_add_emoji", "name": text}, "admin_state")
            raise ApplicationHandlerStop

        elif stype == "product_add_emoji":
            await ask_for_input_reply(
                update, context, "از چه سطح محصولاتی باز بشه؟ (عدد صحیح، مثلا 2):",
                {"type": "product_add_level", "name": state["name"], "emoji": text}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "product_add_level":
            if not text.isdigit():
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "قیمت روز هر واحد این محصول (به هاپ پوینت) رو بفرست:",
                {"type": "product_add_price", "name": state["name"], "emoji": state["emoji"], "level": int(text)},
                "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "product_add_price":
            try:
                price = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            p = db.Product(name=state["name"], emoji=state["emoji"],
                            unlock_level=state["level"], daily_price=price, is_active=True)
            session.add(p)
            session.commit()
            await update.message.reply_text(
                f"✅ محصول «{state['emoji']} {state['name']}» ساخته شد! "
                f"از سطح محصولاتِ {state['level']} به بعد برای پلیرها فعال می‌شه."
            )

        elif stype == "product_edit":
            try:
                value = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            p = session.get(db.Product, state["id"])
            if p:
                if state["field"] == "price":
                    p.daily_price = value
                else:
                    p.unlock_level = int(value)
                session.commit()
                await update.message.reply_text("✅ محصول به‌روزرسانی شد.")

        elif stype == "currency_price":
            try:
                value = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            c = session.get(db.Currency, state["id"])
            if c:
                if state["side"] == "buy":
                    c.buy_price = value
                else:
                    c.sell_price = value
                session.commit()
                await update.message.reply_text("✅ قیمت به‌روزرسانی شد.")

        elif stype == "crypto_auto_interval":
            try:
                value = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if value <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            db.cfg_set(session, "crypto_auto_interval_hours", value)
            await update.message.reply_text(f"✅ فاصله‌ی زمانی روی هر {text} ساعت ست شد.")

        elif stype == "crypto_auto_maxpct":
            try:
                value = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if value <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            db.cfg_set(session, "crypto_auto_max_change_pct", value)
            await update.message.reply_text(f"✅ حداکثر درصد نوسان روی ±{text}٪ ست شد.")

        elif stype == "factory_rank_add_name":
            await ask_for_input_reply(update, context, "چند تا سطح داشته باشه این مقام؟ یه عدد صحیح بفرست (مثلا 10):", {"type": "factory_rank_add_levelcount", "name": text}, "admin_state")
            raise ApplicationHandlerStop

        elif stype == "factory_rank_add_levelcount":
            try:
                level_count = int(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if level_count < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            existing_orders = [r.order for r in session.query(db.FactoryRank).all()]
            new_order = (max(existing_orders) + 1) if existing_orders else 1
            r = db.FactoryRank(order=new_order, name=state["name"], num_levels=level_count)
            session.add(r)
            session.commit()
            await update.message.reply_text(f"✅ مقام «{state['name']}» با {level_count} سطح ساخته شد!")

        elif stype == "factory_rank_rename":
            rank = session.get(db.FactoryRank, state["id"])
            if rank:
                rank.name = text
                session.commit()
                await update.message.reply_text(f"✅ اسم مقام به «{text}» تغییر کرد.")
            else:
                await update.message.reply_text("❌ این مقام پیدا نشد.")

        elif stype == "factory_level_edit":
            lvl = state["level"]
            field = state["field"]
            ov = session.get(db.FactoryLevelDef, lvl)
            if not ov:
                ov = db.FactoryLevelDef(level_number=lvl)
                session.add(ov)

            try:
                value = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if field == "production":
                ov.production_per_min = value
            elif field == "capacity":
                ov.capacity = value
            elif field == "cost":
                ov.upgrade_cost = value
            session.commit()
            await update.message.reply_text(f"✅ سطح {lvl} به‌روزرسانی شد.")

        elif stype == "myawy_operator_add_name":
            await ask_for_input_reply(update, context, "💵 قیمتِ هر گیگ (به هاپ پوینت) رو بفرست:", {"type": "myawy_operator_add_price", "name": text}, "admin_state")
            raise ApplicationHandlerStop

        elif stype == "myawy_operator_add_price":
            try:
                price = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if price <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            default_speed = db.cfg_get_float(session, "myawy_operator_default_speed_mbps")
            op = db.Operator(name=state["name"], price_per_gb=price, speed_mbps=default_speed, active_speed_mbps=default_speed, is_active=True)
            session.add(op)
            session.commit()
            await update.message.reply_text(f"✅ اپراتورِ «{state['name']}» با قیمتِ {fmt(price)} 🪙/گیگ ساخته شد!")

        elif stype == "myawy_operator_editprice":
            try:
                price = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if price <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            op = session.get(db.Operator, state["id"])
            if op:
                op.price_per_gb = price
                session.commit()
                await update.message.reply_text(f"✅ قیمتِ هر گیگِ «{op.name}» به {fmt(price)} 🪙 تغییر کرد.")
            else:
                await update.message.reply_text("❌ این اپراتور دیگه پیدا نشد.")

        elif stype == "myawy_operator_boost_amount":
            try:
                amount = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if amount <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            op = session.get(db.Operator, state["id"])
            if not op:
                await update.message.reply_text("❌ این اپراتور دیگه پیدا نشد.")
                context.user_data.pop("admin_state", None)
                raise ApplicationHandlerStop
            cost_per_unit = db.cfg_get_float(session, "myawy_speed_boost_cost")
            mbps_per_unit = db.cfg_get_float(session, "myawy_speed_boost_mbps")
            cost = (amount / mbps_per_unit) * cost_per_unit if mbps_per_unit else 0
            context.user_data.pop("admin_state", None)
            confirm_kb = InlineKeyboardMarkup([
                [InlineKeyboardButton("✅ بله، مطمئنم", callback_data=f"admin_myawy_operator_boost_confirm:{op.id}:{amount}"),
                 InlineKeyboardButton("❌ انصراف", callback_data=f"admin_myawy_operator_boost_cancel:{op.id}")],
            ])
            await update.message.reply_text(
                f"⚠️ می‌خوای سقفِ نهاییِ «{op.name}» رو {fmt(amount)} مگابیت اضافه کنی؟\n"
                f"💵 هزینه: {fmt(cost)} 🪙 از موجودیِ خودت\n\nمطمئنی؟",
                reply_markup=confirm_kb,
            )

        elif stype == "myawy_operator_setactive":
            try:
                value = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            op = session.get(db.Operator, state["id"])
            if not op:
                await update.message.reply_text("❌ این اپراتور دیگه پیدا نشد.")
            elif value < 0 or value > op.speed_mbps:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text(
                    f"❌ مقدار اشتباه است (باید بینِ ۰ تا {fmt(op.speed_mbps)} باشه)؛ عملیات لغو شد."
                )
                raise ApplicationHandlerStop
            else:
                op.active_speed_mbps = value
                session.commit()
                await update.message.reply_text(f"✅ پهنای باندِ فعالِ «{op.name}» روی {fmt(value)} Mbps تنظیم شد.")

        elif stype == "myawy_platform_add_name":
            await ask_for_input_reply(update, context, "🔢 به‌ازای هر چند لایک پاداش بده؟ یه عدد صحیح بفرست (مثلا 2):", {"type": "myawy_platform_add_likes", "name": text}, "admin_state")
            raise ApplicationHandlerStop

        elif stype == "myawy_platform_add_likes":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, f"💰 به‌ازای هر {text} لایک چقدر هاپ پوینت پاداش بده؟ یه عدد بفرست:",
                {"type": "myawy_platform_add_reward", "name": state["name"], "likes_threshold": int(text)},
                "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "myawy_platform_add_reward":
            try:
                reward = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if reward < 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            platform = db.Platform(
                name=state["name"], reward_amount=reward, likes_threshold=state["likes_threshold"],
                is_bot_funded=False, owner_user_id=None, is_active=True,
            )
            session.add(platform)
            session.commit()
            await update.message.reply_text(
                f"✅ پلتفرمِ «{state['name']}» ساخته شد! هر {state['likes_threshold']} لایک = {fmt(reward)} 🪙 "
                "(پیش‌فرض: بدهیِ مالک - از صفحه‌ی خودِ پلتفرم می‌تونی به «پرداختِ خودکارِ بات» تغییرش بدی.)"
            )

        elif stype == "myawy_platform_editreward":
            try:
                reward = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if reward < 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            platform = session.get(db.Platform, state["id"])
            if platform:
                platform.reward_amount = reward
                session.commit()
                await update.message.reply_text(f"✅ نرخِ پاداشِ «{platform.name}» به {fmt(reward)} 🪙 تغییر کرد.")
            else:
                await update.message.reply_text("❌ این پلتفرم دیگه پیدا نشد.")

        elif stype == "myawy_platform_editlikes":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            platform = session.get(db.Platform, state["id"])
            if platform:
                platform.likes_threshold = int(text)
                session.commit()
                await update.message.reply_text(f"✅ آستانه‌ی لایکِ «{platform.name}» به هر {text} لایک تغییر کرد.")
            else:
                await update.message.reply_text("❌ این پلتفرم دیگه پیدا نشد.")

        elif stype == "myawy_request_fee":
            try:
                fee = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if fee <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            req = session.get(db.PlatformRequest, state["id"])
            if not req or req.status != "pending":
                await update.message.reply_text("❌ این درخواست دیگه در انتظار نیست.")
            else:
                days = db.cfg_get_int(session, "myawy_platform_fee_days")
                req.status = "awaiting_payment"
                req.fee_amount = fee
                req.fee_paid_amount = 0
                req.fee_deadline = db.now() + datetime.timedelta(days=days)
                session.commit()
                await update.message.reply_text(
                    f"✅ درخواستِ «{req.platform_name}» قبول شد؛ فی: {fmt(fee)} 🪙، مهلت: {days} روز."
                )
                try:
                    await context.bot.send_message(
                        req.user_id,
                        f"🎉 درخواستِ پلتفرمِ «{req.platform_name}» قبول شد!\n"
                        f"💵 فی: {fmt(fee)} 🪙 - باید ظرفِ {days} روز از «گوشی هاپویی» پرداختش کنی، "
                        "وگرنه درخواست خودکار لغو می‌شه.",
                    )
                except Exception:
                    pass

        elif stype == "dogfood_add_name":
            await ask_for_input_reply(update, context, "💵 قیمتِ هر واحد رو بفرست (هاپ پوینت):", {"type": "dogfood_add_price", "name": text}, "admin_state")
            raise ApplicationHandlerStop

        elif stype == "dogfood_add_price":
            try:
                price = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if price <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(update, context, "⏳ آماده‌سازیِ هر واحد چند دقیقه طول بکشه؟ یه عدد بفرست (مثلا 3.5):", {"type": "dogfood_add_prep", "name": state["name"], "price": price}, "admin_state")
            raise ApplicationHandlerStop

        elif stype == "dogfood_add_prep":
            try:
                prep = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if prep <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context,
                "🍖 هر واحدِ این غذا چند واحد از ظرفیتِ غذای سگ رو پر کنه؟ یه عدد صحیح بفرست (مثلا 1 یا 2):",
                {"type": "dogfood_add_feed", "name": state["name"], "price": state["price"], "prep": prep},
                "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "dogfood_add_feed":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            feed_value = int(text)
            food = db.DogFood(
                name=state["name"], price=state["price"], prep_minutes=state["prep"],
                feed_value=feed_value, is_active=True,
            )
            session.add(food)
            session.commit()
            await update.message.reply_text(
                f"✅ غذای «{state['name']}» ساخته شد! قیمت: {fmt(state['price'])} 🪙 | "
                f"زمانِ آماده‌سازی: {fmt(state['prep'])} دقیقه/واحد | ارزشِ سیری: {feed_value} واحد/واحد"
            )

        elif stype == "dogfood_editprice":
            try:
                price = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if price <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            food = session.get(db.DogFood, state["id"])
            if food:
                food.price = price
                session.commit()
                await update.message.reply_text(f"✅ قیمتِ «{food.name}» به {fmt(price)} 🪙 تغییر کرد.")
            else:
                await update.message.reply_text("❌ این غذا دیگه پیدا نشد.")

        elif stype == "dogfood_editprep":
            try:
                prep = float(text)
            except ValueError:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if prep <= 0:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            food = session.get(db.DogFood, state["id"])
            if food:
                food.prep_minutes = prep
                session.commit()
                await update.message.reply_text(f"✅ زمانِ آماده‌سازیِ «{food.name}» به {fmt(prep)} دقیقه/واحد تغییر کرد.")
            else:
                await update.message.reply_text("❌ این غذا دیگه پیدا نشد.")

        elif stype == "dogfood_editfeed":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            food = session.get(db.DogFood, state["id"])
            if food:
                food.feed_value = int(text)
                session.commit()
                await update.message.reply_text(f"✅ ارزشِ سیریِ «{food.name}» به {text} واحد تغییر کرد.")
            else:
                await update.message.reply_text("❌ این غذا دیگه پیدا نشد.")

        # -------------------------------------------------------------
        # خط‌ها و نسل‌های گوشیِ هاپویی
        # -------------------------------------------------------------
        elif stype == "phone_line_add_name":
            context.user_data["_pending_phone_line_name"] = text
            await update.message.reply_text(
                f"«{text}» رو تو کدوم دسته بسازم؟",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("📱 اصل", callback_data="admin_phone_line_create:0"),
                    InlineKeyboardButton("🃏 فیک", callback_data="admin_phone_line_create:1"),
                ]]),
            )

        elif stype == "phone_gen_add_name":
            await ask_for_input_reply(
                update, context, "💵 قیمتِ این نسل چند هاپ پوینت باشه؟",
                {"type": "phone_gen_add_price", "line_id": state["line_id"], "name": text}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "phone_gen_add_price":
            try:
                price = float(text)
                assert price >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "📆 این گوشی چند روز تو بازار موجود بمونه و چند روز برای هر خریدار معتبر باشه؟ (عددِ صحیح، پیشنهاد: 14)",
                {**state, "type": "phone_gen_add_validity", "price": price}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "phone_gen_add_validity":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "⏳ چند روز بعد از خرید شروع به خراب‌شدن کنه؟ (عددِ صحیح، پیشنهاد: 14 برای اصل، 0 برای فیک)",
                {**state, "type": "phone_gen_add_grace", "validity_days": int(text)}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "phone_gen_add_grace":
            if not text.isdigit():
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "🎲 احتمالِ خرابیِ روزانه‌ی هر قطعه چند درصد باشه؟ (0 تا 100، پیشنهاد: 30 برای اصل، 90 برای فیک)",
                {**state, "type": "phone_gen_add_breakchance", "breakdown_grace_days": int(text)}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "phone_gen_add_breakchance":
            try:
                pct = float(text)
                assert 0 <= pct <= 100
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار باید بینِ 0 و 100 باشه؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "🛠 هزینه‌ی تعمیرِ LCD چند هاپ پوینت باشه؟ (پیشنهاد: 5,000,000 اصل / 900,000 فیک)",
                {**state, "type": "phone_gen_add_repairlcd", "daily_break_chance_pct": pct}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "phone_gen_add_repairlcd":
            try:
                lcd_price = float(text)
                assert lcd_price >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "🛠 هزینه‌ی تعمیرِ باتری چند هاپ پوینت باشه؟ (پیشنهاد: 12,000,000 اصل / 5,000,000 فیک)",
                {**state, "type": "phone_gen_add_repairbattery", "repair_lcd_price": lcd_price}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "phone_gen_add_repairbattery":
            try:
                battery_price = float(text)
                assert battery_price >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "🛠 هزینه‌ی تعمیرِ سی‌پی‌یو چند هاپ پوینت باشه؟ (پیشنهاد: 18,000,000 اصل / 1,000,000 فیک)",
                {**state, "type": "phone_gen_add_repaircpu", "repair_battery_price": battery_price}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "phone_gen_add_repaircpu":
            try:
                cpu_price = float(text)
                assert cpu_price >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            line_id = state["line_id"]
            max_index = (
                session.query(db.PhoneGeneration.gen_index)
                .filter_by(line_id=line_id)
                .order_by(db.PhoneGeneration.gen_index.desc())
                .first()
            )
            gen_index = (max_index[0] if max_index else 0) + 1
            gen = db.PhoneGeneration(
                line_id=line_id, name=state["name"], gen_index=gen_index,
                price=state["price"], validity_days=state["validity_days"],
                breakdown_grace_days=state["breakdown_grace_days"],
                daily_break_chance_pct=state["daily_break_chance_pct"],
                repair_lcd_price=state["repair_lcd_price"],
                repair_battery_price=state["repair_battery_price"],
                repair_cpu_price=cpu_price,
                is_market_available=True, is_active=True,
            )
            session.add(gen)
            session.flush()
            import myawy
            myawy._recompute_generation_bans(session, line_id)
            session.commit()
            await update.message.reply_text(f"✅ نسلِ «{state['name']}» ساخته شد و تو بازار موجود شد.")

        elif stype == "phone_gen_editprice":
            try:
                value = float(text)
                assert value >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            g = session.get(db.PhoneGeneration, state["id"])
            if g:
                g.price = value
                session.commit()
                await update.message.reply_text(f"✅ قیمتِ «{g.name}» به {fmt(value)} 🪙 تغییر کرد.")
            else:
                await update.message.reply_text("❌ این نسل دیگه پیدا نشد.")

        elif stype == "phone_gen_editvalidity":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            g = session.get(db.PhoneGeneration, state["id"])
            if g:
                g.validity_days = int(text)
                session.commit()
                await update.message.reply_text(f"✅ روزهای اعتبارِ «{g.name}» به {text} روز تغییر کرد.")
            else:
                await update.message.reply_text("❌ این نسل دیگه پیدا نشد.")

        elif stype == "phone_gen_editgrace":
            if not text.isdigit():
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            g = session.get(db.PhoneGeneration, state["id"])
            if g:
                g.breakdown_grace_days = int(text)
                session.commit()
                await update.message.reply_text(f"✅ مهلتِ شروعِ خرابیِ «{g.name}» به {text} روز تغییر کرد.")
            else:
                await update.message.reply_text("❌ این نسل دیگه پیدا نشد.")

        elif stype == "phone_gen_editbreakchance":
            try:
                pct = float(text)
                assert 0 <= pct <= 100
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار باید بینِ 0 و 100 باشه؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            g = session.get(db.PhoneGeneration, state["id"])
            if g:
                g.daily_break_chance_pct = pct
                session.commit()
                await update.message.reply_text(f"✅ احتمالِ خرابیِ روزانه‌ی «{g.name}» به {fmt(pct)}٪ تغییر کرد.")
            else:
                await update.message.reply_text("❌ این نسل دیگه پیدا نشد.")

        elif stype == "phone_gen_editrepairlcd":
            try:
                value = float(text)
                assert value >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            g = session.get(db.PhoneGeneration, state["id"])
            if g:
                g.repair_lcd_price = value
                session.commit()
                await update.message.reply_text(f"✅ هزینه‌ی تعمیرِ LCDِ «{g.name}» به {fmt(value)} 🪙 تغییر کرد.")
            else:
                await update.message.reply_text("❌ این نسل دیگه پیدا نشد.")

        elif stype == "phone_gen_editrepairbattery":
            try:
                value = float(text)
                assert value >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            g = session.get(db.PhoneGeneration, state["id"])
            if g:
                g.repair_battery_price = value
                session.commit()
                await update.message.reply_text(f"✅ هزینه‌ی تعمیرِ باتریِ «{g.name}» به {fmt(value)} 🪙 تغییر کرد.")
            else:
                await update.message.reply_text("❌ این نسل دیگه پیدا نشد.")

        elif stype == "phone_gen_editrepaircpu":
            try:
                value = float(text)
                assert value >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            g = session.get(db.PhoneGeneration, state["id"])
            if g:
                g.repair_cpu_price = value
                session.commit()
                await update.message.reply_text(f"✅ هزینه‌ی تعمیرِ سی‌پی‌یوِ «{g.name}» به {fmt(value)} 🪙 تغییر کرد.")
            else:
                await update.message.reply_text("❌ این نسل دیگه پیدا نشد.")

        # -------------------------------------------------------------
        # مدل‌های ماشینِ تاکسی
        # -------------------------------------------------------------
        elif stype == "taxi_car_add_name":
            await ask_for_input_reply(
                update, context, "💵 قیمتِ این ماشین چند هاپ پوینت باشه؟ (پیشنهاد: 80,000,000)",
                {"type": "taxi_car_add_price", "name": text}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "taxi_car_add_price":
            try:
                price = float(text)
                assert price >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "⛽️ ظرفیتِ باک چند لیتر باشه؟ (پیشنهاد: 40)",
                {**state, "type": "taxi_car_add_tank", "price": price}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "taxi_car_add_tank":
            try:
                tank = float(text)
                assert tank > 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "⛽️ مصرف چند لیتر در ساعتِ کار باشه؟ (پیشنهاد: 4 - یعنی باکِ ۴۰لیتری تقریبا ۱۰ساعته خالی می‌شه)",
                {**state, "type": "taxi_car_add_usage", "tank": tank}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "taxi_car_add_usage":
            try:
                usage = float(text)
                assert usage > 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "🏎 سقفِ سطحِ موتورِ این ماشین چند باشه؟ (پیشنهاد: 20)",
                {**state, "type": "taxi_car_add_enginemax", "usage": usage}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "taxi_car_add_enginemax":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            car = db.TaxiCarModel(
                name=state["name"], price=state["price"], gas_tank_liters=state["tank"],
                gas_use_per_hour=state["usage"], engine_max_level=int(text), is_active=True,
            )
            session.add(car)
            session.commit()
            await update.message.reply_text(f"✅ ماشینِ «{state['name']}» ساخته شد و تو بازار موجود شد.")

        elif stype == "taxi_car_editprice":
            try:
                value = float(text)
                assert value >= 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            c = session.get(db.TaxiCarModel, state["id"])
            if c:
                c.price = value
                session.commit()
                await update.message.reply_text(f"✅ قیمتِ «{c.name}» به {fmt(value)} 🪙 تغییر کرد.")
            else:
                await update.message.reply_text("❌ این مدل دیگه پیدا نشد.")

        elif stype == "taxi_car_edittank":
            try:
                value = float(text)
                assert value > 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            c = session.get(db.TaxiCarModel, state["id"])
            if c:
                c.gas_tank_liters = value
                session.commit()
                await update.message.reply_text(f"✅ ظرفیتِ باکِ «{c.name}» به {fmt(value)} لیتر تغییر کرد.")
            else:
                await update.message.reply_text("❌ این مدل دیگه پیدا نشد.")

        elif stype == "taxi_car_editusage":
            try:
                value = float(text)
                assert value > 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            c = session.get(db.TaxiCarModel, state["id"])
            if c:
                c.gas_use_per_hour = value
                session.commit()
                await update.message.reply_text(f"✅ مصرفِ «{c.name}» به {fmt(value)} لیتر/ساعت تغییر کرد.")
            else:
                await update.message.reply_text("❌ این مدل دیگه پیدا نشد.")

        elif stype == "taxi_car_editenginemax":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            c = session.get(db.TaxiCarModel, state["id"])
            if c:
                c.engine_max_level = int(text)
                session.commit()
                await update.message.reply_text(f"✅ سقفِ سطحِ موتورِ «{c.name}» به {text} تغییر کرد.")
            else:
                await update.message.reply_text("❌ این مدل دیگه پیدا نشد.")

        # -------------------------------------------------------------
        # مقام‌های محبوبیتِ تاکسی
        # -------------------------------------------------------------
        elif stype == "taxi_rank_add_name":
            await ask_for_input_reply(
                update, context, "چند تا سطح داشته باشه این مقام؟ یه عدد صحیح بفرست (مثلا 5):",
                {"type": "taxi_rank_add_levelcount", "name": text}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "taxi_rank_add_levelcount":
            try:
                level_count = int(text)
                assert level_count >= 1
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            existing_orders = [r.order for r in session.query(db.TaxiRank).all()]
            new_order = (max(existing_orders) + 1) if existing_orders else 1
            r = db.TaxiRank(order=new_order, name=state["name"], num_levels=level_count)
            session.add(r)
            session.commit()
            await update.message.reply_text(f"✅ مقامِ «{state['name']}» با {level_count} سطح ساخته شد!")

        elif stype == "taxi_rank_rename":
            rank = session.get(db.TaxiRank, state["id"])
            if rank:
                rank.name = text
                session.commit()
                await update.message.reply_text(f"✅ اسمِ مقام به «{text}» تغییر کرد.")
            else:
                await update.message.reply_text("❌ این مقام دیگه پیدا نشد.")

        # -------------------------------------------------------------
        # گزارش‌های هاپویی
        # -------------------------------------------------------------
        elif stype == "report_accept_custom":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            r = session.get(db.Report, state["id"])
            if not r or r.status != "pending":
                await update.message.reply_text("❌ این گزارش دیگه در انتظار نیست.")
                raise ApplicationHandlerStop
            if not is_owner(update.effective_user.id) and db.is_any_admin(session, r.reported_user_id):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ فقط مالکِ اصلی می‌تونه گزارشِ رو مالک/ادمین رو قبول کنه.")
                raise ApplicationHandlerStop
            u = session.get(db.User, r.reported_user_id)
            if not u:
                u = db.User(telegram_id=r.reported_user_id)
                session.add(u)
            u.jailed_until = db.now() + datetime.timedelta(minutes=int(text))
            r.status = "accepted"
            r.resolved_at = db.now()
            session.commit()
            await update.message.reply_text(f"🔒 {u.display_name()} به مدتِ {text} دقیقه به زندان هاپویی فرستاده شد.")

        # -------------------------------------------------------------
        # کارتِ هاپویی
        # -------------------------------------------------------------
        elif stype == "cards_event_start_days":
            import cards
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            if cards.get_active_event(session):
                await update.message.reply_text("❌ یه ایونت از قبل فعاله؛ اول تمومش کن.")
                raise ApplicationHandlerStop
            ends_at = db.now() + datetime.timedelta(days=int(text))
            session.add(db.CardEvent(ends_at=ends_at, is_active=True))
            session.commit()
            await update.message.reply_text(
                f"✅ ایونتِ کارتِ هاپویی شروع شد! تا {text} روزِ دیگه فعاله.\n"
                "حالا از «📜 مدیریتِ لیست‌های کارت» ایموجی/درصدهای هر لیست رو تنظیم کن."
            )

        elif stype == "cards_paste_emoji":
            import cards
            event = cards.get_active_event(session)
            if not event:
                await update.message.reply_text("❌ ایونتی فعال نیست.")
                raise ApplicationHandlerStop
            parsed = cards.parse_emoji_list(text)
            if not parsed:
                await update.message.reply_text("❌ چیزی ازش دستگیرم نشد؛ فرمت رو چک کن (مثلا «1:😀2:😁3:😂»).")
                raise ApplicationHandlerStop
            list_no = state["list_no"]
            for idx, emoji in parsed.items():
                slot = session.query(db.CardSlot).filter_by(event_id=event.id, list_no=list_no, slot_index=idx).first()
                if slot:
                    slot.emoji = emoji
                else:
                    session.add(db.CardSlot(event_id=event.id, list_no=list_no, slot_index=idx, emoji=emoji, base_percent=1.0))
            session.commit()
            await update.message.reply_text(f"✅ {len(parsed)} خونه‌ی ایموجی ثبت/به‌روز شد.")

        elif stype == "cards_paste_percent":
            import cards
            event = cards.get_active_event(session)
            if not event:
                await update.message.reply_text("❌ ایونتی فعال نیست.")
                raise ApplicationHandlerStop
            parsed = cards.parse_percent_list(text)
            if not parsed:
                await update.message.reply_text("❌ چیزی ازش دستگیرم نشد؛ فرمت رو چک کن (مثلا «1—2٪ 2—17٪»).")
                raise ApplicationHandlerStop
            list_no = state["list_no"]
            updated = 0
            for idx, pct in parsed.items():
                slot = session.query(db.CardSlot).filter_by(event_id=event.id, list_no=list_no, slot_index=idx).first()
                if slot:
                    slot.base_percent = pct
                    updated += 1
            session.commit()
            extra = "" if updated == len(parsed) else f" ({len(parsed) - updated} تاش خونه‌ی متناظر نداشت - اول ایموجی‌هاشو پیست کن.)"
            await update.message.reply_text(f"✅ {updated} درصد به‌روز شد.{extra}")

        elif stype == "cards_edit_slot_number":
            import cards
            if not text.isdigit():
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            event = cards.get_active_event(session)
            if not event:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ ایونتی فعال نیست.")
                raise ApplicationHandlerStop
            slot = session.query(db.CardSlot).filter_by(event_id=event.id, list_no=state["list_no"], slot_index=int(text)).first()
            if not slot:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ همچین خونه‌ای وجود نداره (اول باید با پیست‌کردنِ ایموجی بسازیش).")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, f"ایموجیِ جدید برای خونه‌ی {text} (الان: {slot.emoji}) رو بفرست، یا «-» برای بدون‌تغییر:",
                {"type": "cards_edit_slot_emoji", "slot_id": slot.id}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "cards_edit_slot_emoji":
            slot = session.get(db.CardSlot, state["slot_id"])
            if not slot:
                await update.message.reply_text("❌ این خونه دیگه وجود نداره.")
                raise ApplicationHandlerStop
            if text.strip() != "-":
                slot.emoji = text.strip()
            await ask_for_input_reply(
                update, context, f"درصدِ جدید برای این خونه (الان: {fmt(slot.base_percent)}٪) رو بفرست، یا «-» برای بدون‌تغییر:",
                {"type": "cards_edit_slot_percent", "slot_id": slot.id}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "cards_edit_slot_percent":
            import cards
            slot = session.get(db.CardSlot, state["slot_id"])
            if not slot:
                await update.message.reply_text("❌ این خونه دیگه وجود نداره.")
            else:
                raw = text.strip()
                if raw != "-":
                    raw = cards._normalize_digits(raw).replace("٪", "").replace("%", "")
                    try:
                        slot.base_percent = float(raw)
                    except ValueError:
                        pass
                session.commit()
                await update.message.reply_text(f"✅ خونه‌ی {slot.slot_index} به‌روز شد: {slot.emoji} - {fmt(slot.base_percent)}٪")

        elif stype == "cards_special_number":
            import cards
            if not text.isdigit():
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            event = cards.get_active_event(session)
            if not event:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ ایونتی فعال نیست.")
                raise ApplicationHandlerStop
            slot = session.query(db.CardSlot).filter_by(event_id=event.id, list_no=state["list_no"], slot_index=int(text)).first()
            if not slot:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ همچین خونه‌ای وجود نداره.")
                raise ApplicationHandlerStop
            if slot.is_special:
                slot.is_special = False
                slot.special_reward_points = None
                session.commit()
                await update.message.reply_text(f"✅ خونه‌ی {text} دیگه ویژه نیست.")
            else:
                await ask_for_input_reply(
                    update, context, f"چقدر هاپ پوینت پاداشِ ویژه‌ی خونه‌ی {text} باشه؟",
                    {"type": "cards_special_points", "slot_id": slot.id}, "admin_state",
                )
                raise ApplicationHandlerStop

        elif stype == "cards_special_points":
            try:
                points = float(text)
                assert points > 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            slot = session.get(db.CardSlot, state["slot_id"])
            if slot:
                slot.is_special = True
                slot.special_reward_points = points
                session.commit()
                await update.message.reply_text(f"✅ خونه‌ی {slot.slot_index} ویژه شد - پاداش: {fmt(points)} 🪙")
            else:
                await update.message.reply_text("❌ این خونه دیگه وجود نداره.")

        # -------------------------------------------------------------
        # کدهای جایزه‌ی هاپویی
        # -------------------------------------------------------------
        elif stype == "redeem_add_code":
            code_text = text.strip()
            if not code_text:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ کد نمی‌تونه خالی باشه؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            existing = session.query(db.RedeemCode).filter_by(is_active=True).all()
            if any(c.code.strip().lower() == code_text.lower() for c in existing):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ این کد از قبل وجود داره؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, f"💵 کدِ «{code_text}» چند هاپ پوینت پاداش بده؟",
                {"type": "redeem_add_reward", "code": code_text}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "redeem_add_reward":
            try:
                reward = float(text)
                assert reward > 0
            except (ValueError, AssertionError):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            await ask_for_input_reply(
                update, context, "📅 این کد چند روز معتبر باشه؟ (عددِ صحیح، یا «-» برای بدونِ‌انقضا):",
                {**state, "type": "redeem_add_expiry", "reward": reward}, "admin_state",
            )
            raise ApplicationHandlerStop

        elif stype == "redeem_add_expiry":
            expires_at = None
            if text.strip() != "-":
                if not text.isdigit() or int(text) < 1:
                    context.user_data.pop("admin_state", None)
                    await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد.")
                    raise ApplicationHandlerStop
                expires_at = db.now() + datetime.timedelta(days=int(text))
            session.add(db.RedeemCode(code=state["code"], reward_points=state["reward"], expires_at=expires_at, is_active=True))
            session.commit()
            exp_txt = expires_at.strftime("%Y-%m-%d") if expires_at else "بدونِ انقضا"
            await update.message.reply_text(f"✅ کدِ «{state['code']}» ساخته شد! پاداش: {fmt(state['reward'])} 🪙 | انقضا: {exp_txt}")

        # -------------------------------------------------------------
        # فروشگاه و حمله: ساخت/ویرایشِ آیتم‌ها (نگاه کن به attack.py برای منطقِ
        # خودِ بازی؛ اینجا فقط CRUDِ آیتم‌های ShopItem هست)
        # -------------------------------------------------------------
        elif stype == "attack_add_fields":
            cat = state["category"]
            parts = [p.strip() for p in text.split("|")]
            spec = _ATTACK_FIELD_SPECS[cat]
            if len(parts) != len(spec):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text(
                    f"❌ تعدادِ فیلدها اشتباهه؛ عملیات لغو شد. فرمتِ درست:\n{_ATTACK_FIELD_HINT[cat]}"
                )
                raise ApplicationHandlerStop
            try:
                parsed = _parse_attack_fields(cat, parts)
            except ValueError as e:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            item = db.ShopItem(category=cat, booster_type=state.get("booster_type"), active=True, **parsed)
            session.add(item)
            session.commit()
            await update.message.reply_text(f"✅ «{item.name}» به دسته‌ی {attack.CATEGORY_LABELS[cat]} اضافه شد.")

        elif stype == "attack_edit_field":
            field = state["field"]
            item = session.get(db.ShopItem, state["id"])
            if not item:
                await update.message.reply_text("❌ این آیتم دیگه پیدا نشد.")
                raise ApplicationHandlerStop
            try:
                value = _parse_attack_single_field(field, text)
            except ValueError as e:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            setattr(item, field, value)
            session.commit()
            await update.message.reply_text(f"✅ «{item.name}» به‌روزرسانی شد.")

        # -------------------------------------------------------------
        # افزودنِ ادمینِ فرعی (فقط مالکِ اصلی به این می‌رسه - strict_owner_only
        # از پیش تو دکمه‌ی cb_admin_admin_add چک شده)
        # -------------------------------------------------------------
        elif stype == "admin_add_target":
            if not is_owner(update.effective_user.id):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("⛔️ این بخش فقط برای مالکِ اصلیِ رباته.")
                raise ApplicationHandlerStop
            raw = text.strip().lstrip("@")
            target = None
            if raw.isdigit():
                target_id = int(raw)
                target = session.get(db.User, target_id)
            else:
                target = session.query(db.User).filter(db.User.username == raw).first()
                target_id = target.telegram_id if target else None
            if target_id is None:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text(
                    "❌ کاربر پیدا نشد. اگه با یوزرنیم امتحان کردی، باید حداقل یه‌بار قبلاً با بات تعامل داشته باشه؛ "
                    "وگرنه آیدیِ عددیش رو بفرست."
                )
                raise ApplicationHandlerStop
            if target_id == config.OWNER_ID:
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ این کاربر همینطوریش مالکِ اصلیه.")
                raise ApplicationHandlerStop
            if session.get(db.AdminUser, target_id):
                context.user_data.pop("admin_state", None)
                await update.message.reply_text("❌ این کاربر از قبل ادمینه.")
                raise ApplicationHandlerStop
            name = target.display_name() if target else str(target_id)
            await update.message.reply_text(
                f"آیا می‌خواهید {name} را ادمین کنید؟",
                reply_markup=InlineKeyboardMarkup([[
                    InlineKeyboardButton("✅ بله", callback_data=f"admin_admin_add_confirm:{target_id}"),
                    InlineKeyboardButton("❌ خیر", callback_data="admin_admins_menu"),
                ]]),
            )
    except ApplicationHandlerStop:
        raise
    except Exception as e:
        logger.exception("خطا تو پردازش ورودیِ پنل مدیریت (admin_state=%s)", state.get("type"))
        session.rollback()
        await update.message.reply_text(
            f"❌ یه خطا پیش اومد و این مرحله انجام نشد: {e}\n"
            "دوباره امتحان کن یا از «/cancel» برای شروعِ دوباره استفاده کن."
        )
    finally:
        session.close()

    context.user_data.pop("admin_state", None)
    raise ApplicationHandlerStop


ADMIN_CALLBACK_MAP = {
    "admin_panel": cb_admin_panel,
    "admin_admins_menu": cb_admin_admins_menu,
    "admin_admin_add": cb_admin_admin_add,
    "admin_cfg": cb_admin_cfg,
    "admin_market_prices": cb_admin_market_prices,
    "admin_bank_cfg": cb_admin_bank_cfg,
    "admin_player_search": cb_admin_player_search,
    "admin_add_points_self": cb_admin_add_points_self,
    "admin_toggle_private": cb_admin_toggle_private,
    "admin_currency_menu": cb_admin_currency_menu,
    "admin_currency_add": cb_admin_currency_add,
    "admin_currency_auto_menu": cb_admin_currency_auto_menu,
    "admin_currency_auto_toggle": cb_admin_currency_auto_toggle,
    "admin_currency_auto_interval": cb_admin_currency_auto_interval,
    "admin_currency_auto_maxpct": cb_admin_currency_auto_maxpct,
    "admin_lottery_menu": cb_admin_lottery_menu,
    "admin_lottery_start": cb_admin_lottery_start,
    "admin_products_menu": cb_admin_products_menu,
    "admin_product_add": cb_admin_product_add,
    "admin_factory_ranks_menu": cb_admin_factory_ranks_menu,
    "admin_factory_levels_menu": cb_admin_factory_levels_menu,
    "admin_factory_rank_add": cb_admin_factory_rank_add,
    "admin_myawy_menu": cb_admin_myawy_menu,
    "admin_myawy_withdraw_revenue": cb_admin_myawy_withdraw_revenue,
    "admin_myawy_operators": cb_admin_myawy_operators,
    "admin_myawy_operator_add": cb_admin_myawy_operator_add,
    "admin_myawy_platforms": cb_admin_myawy_platforms,
    "admin_myawy_platform_add": cb_admin_myawy_platform_add,
    "admin_myawy_requests": cb_admin_myawy_requests,
    "admin_myawy_debts": cb_admin_myawy_debts,
    "admin_chef_cfg": cb_admin_chef_cfg,
    "admin_casino_cfg": cb_admin_casino_cfg,
    "admin_dogfoods_menu": cb_admin_dogfoods_menu,
    "admin_dogfood_add": cb_admin_dogfood_add,
    "admin_phone_lines": cb_admin_phone_lines,
    "admin_phone_line_add": cb_admin_phone_line_add,
    "admin_taxi_menu": cb_admin_taxi_menu,
    "admin_taxi_cfg": cb_admin_taxi_cfg,
    "admin_taxi_cars_menu": cb_admin_taxi_cars_menu,
    "admin_taxi_car_add": cb_admin_taxi_car_add,
    "admin_taxi_ranks_menu": cb_admin_taxi_ranks_menu,
    "admin_taxi_rank_add": cb_admin_taxi_rank_add,
    "admin_reports_menu": cb_admin_reports_menu,
    "admin_cards_menu": cb_admin_cards_menu,
    "admin_cards_cfg": cb_admin_cards_cfg,
    "admin_cards_start_ask": cb_admin_cards_start_ask,
    "admin_cards_end_ask": cb_admin_cards_end_ask,
    "admin_cards_end_confirm": cb_admin_cards_end_confirm,
    "admin_cards_delete_ask": cb_admin_cards_delete_ask,
    "admin_cards_delete_confirm": cb_admin_cards_delete_confirm,
    "admin_cards_lists_menu": cb_admin_cards_lists_menu,
    "admin_redeem_menu": cb_admin_redeem_menu,
    "admin_redeem_add": cb_admin_redeem_add,
    "admin_attack_menu": cb_admin_attack_menu,
    "admin_access_levels_menu": cb_admin_access_levels_menu,
    "admin_lvl_recalc_ask": cb_admin_lvl_recalc_ask,
    "admin_lvl_recalc_do": cb_admin_lvl_recalc_do,
}

ADMIN_PREFIX_CALLBACK_MAP = {
    "admin_admin_view": cb_admin_admin_view,
    "admin_admin_add_confirm": cb_admin_admin_add_confirm,
    "admin_admin_toggle": cb_admin_admin_toggle,
    "admin_admin_remove_ask": cb_admin_admin_remove_ask,
    "admin_admin_remove_confirm": cb_admin_admin_remove_confirm,
    "admin_cfg_edit": cb_admin_cfg_edit,
    "admin_player_edit": cb_admin_player_edit,
    "admin_currency_view": cb_admin_currency_view,
    "admin_currency_edit": cb_admin_currency_edit,
    "admin_currency_delete": cb_admin_currency_delete,
    "admin_lottery_random": cb_admin_lottery_random,
    "admin_lottery_manual_start": cb_admin_lottery_manual_start,
    "admin_lottery_toggle": cb_admin_lottery_toggle,
    "admin_lottery_manual_confirm": cb_admin_lottery_manual_confirm,
    "admin_lottery_cancel": cb_admin_lottery_cancel,
    "admin_product_view": cb_admin_product_view,
    "admin_product_edit": cb_admin_product_edit,
    "admin_product_toggle": cb_admin_product_toggle,
    "admin_product_delete": cb_admin_product_delete,
    "admin_factory_rank_view": cb_admin_factory_rank_view,
    "admin_factory_rank_rename": cb_admin_factory_rank_rename,
    "admin_factory_rank_addlevel": cb_admin_factory_rank_addlevel,
    "admin_factory_rank_removelevel": cb_admin_factory_rank_removelevel,
    "admin_factory_rank_delete": cb_admin_factory_rank_delete,
    "admin_factory_level_view": cb_admin_factory_level_view,
    "admin_factory_level_edit": cb_admin_factory_level_edit,
    "admin_factory_level_reset": cb_admin_factory_level_reset,
    "admin_dogfood_view": cb_admin_dogfood_view,
    "admin_dogfood_editprice": cb_admin_dogfood_editprice,
    "admin_dogfood_editprep": cb_admin_dogfood_editprep,
    "admin_dogfood_editfeed": cb_admin_dogfood_editfeed,
    "admin_dogfood_toggle": cb_admin_dogfood_toggle,
    "admin_myawy_operator_view": cb_admin_myawy_operator_view,
    "admin_myawy_operator_boost_ask": cb_admin_myawy_operator_boost_ask,
    "admin_myawy_operator_boost_confirm": cb_admin_myawy_operator_boost_confirm,
    "admin_myawy_operator_boost_cancel": cb_admin_myawy_operator_boost_cancel,
    "admin_myawy_operator_setactive_ask": cb_admin_myawy_operator_setactive_ask,
    "admin_myawy_operator_editprice": cb_admin_myawy_operator_editprice,
    "admin_myawy_operator_toggle": cb_admin_myawy_operator_toggle,
    "admin_myawy_platform_view": cb_admin_myawy_platform_view,
    "admin_myawy_platform_editreward": cb_admin_myawy_platform_editreward,
    "admin_myawy_platform_editlikes": cb_admin_myawy_platform_editlikes,
    "admin_myawy_platform_togglefund": cb_admin_myawy_platform_togglefund,
    "admin_myawy_platform_toggle": cb_admin_myawy_platform_toggle,
    "admin_myawy_request_view": cb_admin_myawy_request_view,
    "admin_myawy_request_accept": cb_admin_myawy_request_accept,
    "admin_myawy_request_reject": cb_admin_myawy_request_reject,
    "admin_myawy_debt_pay": cb_admin_myawy_debt_pay,
    "admin_myawy_platform_toggleuniversal": cb_admin_myawy_platform_toggleuniversal,
    "admin_myawy_platform_delete_ask": cb_admin_myawy_platform_delete_ask,
    "admin_myawy_platform_delete_confirm": cb_admin_myawy_platform_delete_confirm,
    "admin_phone_line_view": cb_admin_phone_line_view,
    "admin_phone_line_toggle": cb_admin_phone_line_toggle,
    "admin_phone_line_add_gen": cb_admin_phone_line_add_gen,
    "admin_phone_line_create": cb_admin_phone_line_create,
    "admin_phone_gen_view": cb_admin_phone_gen_view,
    "admin_phone_gen_togglemarket": cb_admin_phone_gen_togglemarket,
    "admin_phone_gen_toggleban": cb_admin_phone_gen_toggleban,
    "admin_phone_gen_toggle": cb_admin_phone_gen_toggle,
    "admin_phone_gen_delete_ask": cb_admin_phone_gen_delete_ask,
    "admin_phone_gen_delete_confirm": cb_admin_phone_gen_delete_confirm,
    "admin_phone_gen_editprice": cb_admin_phone_gen_editprice,
    "admin_phone_gen_editvalidity": cb_admin_phone_gen_editvalidity,
    "admin_phone_gen_editgrace": cb_admin_phone_gen_editgrace,
    "admin_phone_gen_editbreakchance": cb_admin_phone_gen_editbreakchance,
    "admin_phone_gen_editrepairlcd": cb_admin_phone_gen_editrepairlcd,
    "admin_phone_gen_editrepairbattery": cb_admin_phone_gen_editrepairbattery,
    "admin_phone_gen_editrepaircpu": cb_admin_phone_gen_editrepaircpu,
    "admin_taxi_car_view": cb_admin_taxi_car_view,
    "admin_taxi_car_toggle": cb_admin_taxi_car_toggle,
    "admin_taxi_car_editprice": cb_admin_taxi_car_editprice,
    "admin_taxi_car_edittank": cb_admin_taxi_car_edittank,
    "admin_taxi_car_editusage": cb_admin_taxi_car_editusage,
    "admin_taxi_car_editenginemax": cb_admin_taxi_car_editenginemax,
    "admin_taxi_rank_view": cb_admin_taxi_rank_view,
    "admin_taxi_rank_rename": cb_admin_taxi_rank_rename,
    "admin_taxi_rank_addlevel": cb_admin_taxi_rank_addlevel,
    "admin_taxi_rank_removelevel": cb_admin_taxi_rank_removelevel,
    "admin_taxi_rank_delete": cb_admin_taxi_rank_delete,
    "admin_report_view": cb_admin_report_view,
    "admin_report_reject": cb_admin_report_reject,
    "admin_report_accept": cb_admin_report_accept,
    "admin_report_accept_custom": cb_admin_report_accept_custom,
    "admin_cards_list_detail": cb_admin_cards_list_detail,
    "admin_cards_paste_emoji": cb_admin_cards_paste_emoji,
    "admin_cards_paste_percent": cb_admin_cards_paste_percent,
    "admin_cards_edit_slot_ask": cb_admin_cards_edit_slot_ask,
    "admin_cards_special_ask": cb_admin_cards_special_ask,
    "admin_redeem_view": cb_admin_redeem_view,
    "admin_redeem_delete": cb_admin_redeem_delete,
    "admin_attack_cat": cb_admin_attack_cat,
    "admin_attack_add": cb_admin_attack_add,
    "admin_attack_add_booster_type": cb_admin_attack_add_booster_type,
    "admin_attack_view": cb_admin_attack_view,
    "admin_attack_edit_ask": cb_admin_attack_edit_ask,
    "admin_attack_toggle": cb_admin_attack_toggle,
    "admin_attack_delete_ask": cb_admin_attack_delete_ask,
    "admin_attack_delete_confirm": cb_admin_attack_delete_confirm,
    "admin_attack_cfg": cb_admin_attack_cfg,
}
ADMIN_PREFIX_CALLBACK_MAP.update(guide.ADMIN_HELP_CALLBACKS)
ADMIN_PREFIX_CALLBACK_MAP.update(smuggling.ADMIN_SMG_CALLBACKS)
import war_admin  # noqa: E402
ADMIN_PREFIX_CALLBACK_MAP.update(war_admin.ADMIN_WAR_CALLBACKS)
import heist_admin  # noqa: E402
ADMIN_PREFIX_CALLBACK_MAP.update(heist_admin.ADMIN_HEIST_CALLBACKS)
import mission_admin  # noqa: E402
ADMIN_PREFIX_CALLBACK_MAP.update(mission_admin.ADMIN_MISSION_CALLBACKS)
import battlepass_admin  # noqa: E402
ADMIN_PREFIX_CALLBACK_MAP.update(battlepass_admin.ADMIN_BP_CALLBACKS)
import referral_ui  # noqa: E402
ADMIN_PREFIX_CALLBACK_MAP.update(referral_ui.ADMIN_REF_CALLBACKS)


async def admin_callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = update.callback_query.data
    prefix = data.split(":")[0]
    handler = ADMIN_CALLBACK_MAP.get(data) or ADMIN_PREFIX_CALLBACK_MAP.get(prefix)
    if not handler:
        return False
    uid = update.effective_user.id
    if not is_owner(uid):
        category = _admin_permission_category(data)
        if category == "OWNER_EXCLUSIVE":
            await update.callback_query.answer("⛔️ این بخش فقط برای مالکِ اصلیِ رباته.", show_alert=True)
            return True
        session = db.get_session()
        try:
            allowed = db.has_admin_permission(session, uid, category)
        finally:
            session.close()
        if not allowed:
            await update.callback_query.answer("⛔️ شما دسترسیِ این بخش رو ندارید.", show_alert=True)
            return True
    await handler(update, context)
    return True
