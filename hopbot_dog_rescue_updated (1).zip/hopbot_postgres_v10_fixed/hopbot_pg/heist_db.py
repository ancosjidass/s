# -*- coding: utf-8 -*-
"""
مدل‌های دیتابیس «سرقت تیمی هاپویی» + کانفیگ پیش‌فرض + برچسب‌های فارسیِ پنل ادمین.

اصول:
- هیچ ارز/XP/زندانِ موازی نداریم: پول = User.hop_points (با لجرِ HopTransaction از طریق war_svc.hop_apply)،
  زندان = User.jailed_until / jail_bail_amount / jail_reason (همون «وثیقه»ی هاپویی).
- هیچ مکانِ سرقتی به‌صورت پیش‌فرض ساخته نمی‌شه (init_heist فقط جدول و کانفیگ می‌سازه). مکان‌ها فقط از پنلِ ادمین.
- هر عددِ بالانس یا ستونِ مکانه (LOC_FIELDS) یا کلیدِ db.Config با پیشوندِ heist_ (GLOBAL_CFG)؛ پس بدونِ
  دست‌زدن به کد از پنل قابل‌تغییره. (مقدارهای پیش‌فرضِ زیر فقط «مقدارِ اولیه‌ی» کانفیگن، نه ثابتِ کد.)
- هر عملیات هنگامِ شروع، تنظیماتِ مکان رو Snapshot می‌کنه (cfg_json)؛ تغییرِ ادمین وسطِ عملیات اثر نداره.
"""
import json

from sqlalchemy import (
    Column, Integer, BigInteger, Float, String, Boolean, DateTime, Text, Index, UniqueConstraint,
)

import db
from db import Base, now

# ---------------------------------------------------------------------------
# کلید/برچسبِ فیلدهای مکان (هم برای ساخت ستون‌ها، هم برای پنلِ فارسیِ ادمین، هم برای پیش‌فرضِ مکانِ جدید)
# (کلید، برچسبِ فارسی، نوع، مقدارِ اولیه‌ی پیش‌فرض، گروه، توضیح)
# نوع: int / float / str / text / bool / enum:<a|b|c>
# ---------------------------------------------------------------------------
LOC_GROUPS = [
    ("main", "📋 مشخصات"),
    ("xp", "⭐ XP و پاداش"),
    ("time", "⏱ زمان و کول‌داون"),
    ("jail", "🔒 زندان"),
    ("safe", "🔓 صندوق و آیتم‌ها"),
    ("spy", "🕵️ مهارتِ جاسوس"),
    ("safeskill", "🔓 مهارتِ صندوق‌دار"),
    ("carrier", "📦 مهارتِ جابه‌جا‌کننده"),
    ("driver", "🚗 مهارتِ راننده"),
    ("rules", "📜 قوانین"),
]

LOC_FIELDS = [
    ("name", "📛 نام مکان", "str", "", "main", ""),
    ("description", "📝 توضیحات", "text", "", "main", ""),
    ("tier", "🏷 درجه/سطحِ نمایشی", "str", "1", "main", "فقط برای نمایش (مثلا ۱ یا «آسان»)"),
    ("req_xp", "⭐ XP موردنیاز برای باز شدنِ مکان", "int", "1000", "xp", "کمتر از این = قفل 🔒"),
    ("success_xp", "🎁 XP پاداشِ سرقتِ موفق (برای هر نفر)", "int", "250", "xp", "در شکست XP نمیدن"),
    ("cooldown_minutes", "⏳ کول‌داونِ مکان (دقیقه)", "int", "480", "time", "هر مکان کول‌داونِ مستقلِ خودش رو داره"),
    ("cooldown_trigger", "🚦 کول‌داون از کِی شروع بشه؟", "enum:on_lobby_start|on_start|on_finish|on_success|on_failure", "on_finish", "time",
     "on_lobby_start=ساختِ لابی | on_start=شروعِ عملیات | on_finish=پایانِ عملیات | on_success=فقط بعدِ موفقیت | on_failure=فقط بعدِ شکست"),
    ("police_seconds", "🚨 زمانِ رسیدنِ پلیس (ثانیه، از شروعِ عملیات)", "int", "300", "time", "تایمرِ کلِ عملیات؛ تو همه‌ی مرحله‌ها فعاله"),
    ("jail_minutes", "🔒 مدتِ زندانِ شکست (دقیقه)", "int", "180", "jail", "کلِ تیم می‌رن زندانِ هاپویی"),
    ("bail_amount", "💸 وثیقه (هاپ پوینت؛ ‎-۱ یعنی وثیقه قبول نمی‌شه)", "float", "300000000", "jail", ""),
    ("items_count", "🎁 تعدادِ آیتمِ واقعیِ داخلِ صندوق", "int", "5", "safe", "از بینِ خونه‌ها؛ بقیه خالی‌ان"),
    ("grid_cells", "🔢 تعدادِ خونه‌های صندوق", "int", "20", "safe", "پیش‌فرض ۲۰ (۴×۵)، حداکثر ۴۰"),
    ("item_fail_pct", "⚠️ احتمالِ پایه‌ی از دست رفتنِ هر آیتم (٪)", "float", "12", "safe",
     "اگه خودِ آیتم عدد نداشته باشه این استفاده می‌شه؛ آخرِ سرقت محاسبه می‌شه"),
    ("value_variance", "🎲 نوسانِ ارزشِ آیتم (± هاپ)", "float", "1000000", "safe", "ارزشِ هر آیتم = پایه ± این مقدار (مستقل)"),
    ("early_finish", "✅ دکمه‌ی «کافیه» فعال باشه؟", "bool", "1", "safe", "فقط تو مرحله‌ی صندوق"),
    ("min_found_items", "🔢 حداقل آیتمِ لازم برای زدنِ «کافیه»", "int", "1", "safe", ""),
    ("auto_finish_all", "⚡ با پیدا شدنِ همه‌ی آیتم‌ها مرحله خودکار تموم شه؟", "bool", "1", "safe", ""),
    ("no_item_policy", "📭 اگه هیچ آیتمی پیدا نشد", "enum:blocked|skip", "blocked", "safe",
     "blocked=نمیشه از مرحله‌ی صندوق رد شد | skip=مستقیم بره مرحله‌ی راننده"),
    ("failed_item_policy", "💥 آیتمِ شکست‌خورده در نهایت", "enum:remove|half", "remove", "safe",
     "remove=کامل حذف | half=نصفِ ارزش می‌مونه"),
    ("spy_base_colors", "🎨 تعدادِ رنگِ پایه در پازلِ جاسوسی", "int", "8", "spy", ""),
    ("spy_per_skill_colors", "➖ کاهشِ رنگ به‌ازای هر امتیازِ مهارت", "int", "1", "spy", ""),
    ("spy_min_colors", "🔻 حداقلِ تعدادِ رنگ", "int", "3", "spy", "هیچ‌وقت کمتر از این نمی‌شه"),
    ("spy_max_skill", "🧠 سقفِ مهارتِ مؤثرِ جاسوس (۰ = بدونِ سقف)", "int", "0", "spy", ""),
    ("safe_per_skill_pct", "➖ کاهشِ ریسکِ آیتم به‌ازای هر امتیاز (درصدواحد)", "float", "1", "safeskill", ""),
    ("safe_min_pct", "🔻 کفِ ریسکِ آیتم (٪)", "float", "0", "safeskill", ""),
    ("safe_max_pct", "🔺 سقفِ ریسکِ آیتم (٪)", "float", "100", "safeskill", ""),
    ("safe_max_skill", "🧠 سقفِ مهارتِ مؤثرِ صندوق‌دار (۰ = بدونِ سقف)", "int", "5", "safeskill", ""),
    ("carrier_base_sec", "⏱ زمانِ پایه‌ی جابه‌جاییِ هر آیتم (ثانیه)", "int", "15", "carrier", ""),
    ("carrier_per_skill_sec", "➖ کاهشِ زمان به‌ازای هر امتیاز (ثانیه)", "int", "1", "carrier", ""),
    ("carrier_min_sec", "🔻 حداقلِ زمانِ جابه‌جاییِ هر آیتم (ثانیه)", "int", "3", "carrier", ""),
    ("carrier_max_skill", "🧠 سقفِ مهارتِ مؤثرِ جابه‌جا‌کننده (۰ = بدونِ سقف)", "int", "0", "carrier", ""),
    ("driver_base_sec", "⏱ زمانِ پایه‌ی رانندگی (ثانیه)", "int", "165", "driver", "۱۶۵ = ۲ دقیقه و ۴۵ ثانیه"),
    ("driver_per_skill_sec", "➖ کاهشِ زمان به‌ازای هر امتیاز (ثانیه)", "int", "14", "driver", ""),
    ("driver_min_sec", "🔻 حداقلِ زمانِ رانندگی (ثانیه)", "int", "30", "driver", ""),
    ("driver_max_skill", "🧠 سقفِ مهارتِ مؤثرِ راننده (۰ = بدونِ سقف)", "int", "0", "driver", ""),
    ("split_remainder", "➗ باقی‌مانده‌ی تقسیمِ غنیمت", "enum:normalize|creator|random", "normalize", "rules",
     "normalize=مجموع به مضربِ ۴ گرد می‌شه | creator=به سازنده | random=به یه عضوِ شانسی"),
    ("auto_start", "🚀 با کامل شدنِ ۴ نفر عملیات خودکار شروع بشه؟", "bool", "1", "rules", "خاموش = سازنده باید «شروع عملیات» رو بزنه"),
    ("leave_after_start", "🚪 خروج بعد از شروعِ عملیات", "enum:blocked|fail", "blocked", "rules",
     "blocked=ممنوع | fail=خروجِ هر عضو = شکستِ کلِ عملیات"),
    ("rules_text", "📜 توضیح/قوانینِ اضافه (نمایشی)", "text", "", "rules", ""),
]
LOC_KEYS = [f[0] for f in LOC_FIELDS]
LOC_BY_KEY = {f[0]: f for f in LOC_FIELDS}
LOC_LABEL = {f[0]: f[1] for f in LOC_FIELDS}
# فیلدهایی که لازمه موقعِ ساختِ مکان از پیش‌فرض کپی نشن (نامِ مکان رو خودِ ادمین می‌گه)
LOC_NO_DEFAULT = {"name"}

# ---------------------------------------------------------------------------
# تنظیماتِ کلی (db.Config) با برچسبِ فارسی
# ---------------------------------------------------------------------------
GLOBAL_CFG = [
    # key, label, default, help
    ("heist_enabled", "🟢 سرقت تیمی روشن باشه؟ (۱=بله ۰=خیر)", "1", ""),
    ("heist_xp_per_skill_point", "🔁 هر چند XP = ۱ امتیازِ مهارت", "5", "مثلا ۵ یعنی ۵ XP = ۱ امتیاز"),
    ("heist_unlock_lifetime_xp", "⭐ بازشدنِ مکان‌ها بر اساسِ کلِ XPِ کسب‌شده باشه؟ (۱=بله ۰=XPِ باقی‌مانده)", "1",
     "۱: خرجِ XP برای مهارت، مکان‌های باز شده رو دوباره قفل نمی‌کنه"),
    ("heist_skill_max_spy", "🕵️ سقفِ امتیازِ مهارتِ جاسوس (۰ = بدونِ سقف)", "0", ""),
    ("heist_skill_max_safe", "🔓 سقفِ امتیازِ مهارتِ صندوق‌دار (۰ = بدونِ سقف)", "5", ""),
    ("heist_skill_max_carrier", "📦 سقفِ امتیازِ مهارتِ جابه‌جا‌کننده (۰ = بدونِ سقف)", "0", ""),
    ("heist_skill_max_driver", "🚗 سقفِ امتیازِ مهارتِ راننده (۰ = بدونِ سقف)", "0", ""),
    ("heist_skill_min_spy", "🕵️ کفِ امتیازِ مهارتِ جاسوس", "0", ""),
    ("heist_skill_min_safe", "🔓 کفِ امتیازِ مهارتِ صندوق‌دار", "0", ""),
    ("heist_skill_min_carrier", "📦 کفِ امتیازِ مهارتِ جابه‌جا‌کننده", "0", ""),
    ("heist_skill_min_driver", "🚗 کفِ امتیازِ مهارتِ راننده", "0", ""),
    ("heist_color_pool", "🎨 رنگ‌های پازلِ جاسوسی (با کاما جدا کن)", "🟨,🟥,🟦,🟩,🟪,🟧,⬜,🟫", "حداقل ۲ رنگ"),
    ("heist_spy_allow_repeat", "🔁 تکرارِ رنگ در پازل مجاز باشه؟ (۱/۰)", "0", ""),
    ("heist_lobby_ttl_minutes", "⌛ مهلتِ لابی تا کامل شدن (دقیقه)", "30", "بعدش لابی خودکار لغو می‌شه"),
    ("heist_panel_refresh_seconds", "🔄 هر چند ثانیه پنلِ عملیات به‌روز بشه", "15", "کمتر از ۱۰ پیشنهاد نمی‌شه (محدودیتِ تلگرام)"),
    ("heist_history_size", "📜 تعدادِ رکوردهای تاریخچه", "10", ""),
    ("heist_dashboard_hours", "📊 بازه‌ی آمارِ پنل (ساعت)", "24", ""),
]
GLOBAL_CFG_DEFAULT = {k: v for k, _l, v, _h in GLOBAL_CFG}
GLOBAL_CFG_LABEL = {k: l for k, l, _v, _h in GLOBAL_CFG}
GLOBAL_CFG_HELP = {k: h for k, _l, _v, h in GLOBAL_CFG}

# پیش‌فرضِ مکانِ جدید (هر فیلدِ مکان یه کلیدِ heist_def_<key> داره که ادمین می‌تونه عوضش کنه)
DEF_PREFIX = "heist_def_"
DEF_CFG_DEFAULT = {DEF_PREFIX + f[0]: f[3] for f in LOC_FIELDS if f[0] not in LOC_NO_DEFAULT and f[0] not in ("description", "rules_text")}
DEF_CFG_LABEL = {DEF_PREFIX + f[0]: "(پیش‌فرضِ مکانِ جدید) " + f[1] for f in LOC_FIELDS if DEF_PREFIX + f[0] in DEF_CFG_DEFAULT}

HEIST_CFG_DEFAULTS = dict(GLOBAL_CFG_DEFAULT)
HEIST_CFG_DEFAULTS.update(DEF_CFG_DEFAULT)
ALL_CFG_LABEL = dict(GLOBAL_CFG_LABEL)
ALL_CFG_LABEL.update(DEF_CFG_LABEL)

# ---------------------------------------------------------------------------
# متن‌های قابل‌ویرایش از پنل (قالب‌ها؛ جاهای {خالی} با مقدار پر می‌شن)
# ---------------------------------------------------------------------------
MESSAGES = {
    "not_your_panel": ("🚫 پیامِ «این پنل برای شما نیست»", "این پنل برای شما نیست.", ""),
    "locked_join": ("🔒 پیامِ ورودِ مکانِ قفل", "این مکان هنوز برای شما باز نشده است.", ""),
    "cooldown_join": ("⏳ پیامِ ورود/ساختِ مکانِ در کول‌داون", "این سرقت هنوز برای شما در Cooldown است.\n⏳ زمانِ باقی‌مانده: {remain}", "{remain}"),
    "not_member": ("🙅 پیامِ «عضو نیستی»", "شما عضو این سرقت نیستید.", ""),
    "turn_spy": ("🕵️ پیامِ نوبتِ جاسوس", "الان نوبت جاسوس است.", ""),
    "turn_safe": ("🔓 پیامِ نوبتِ صندوق‌دار", "الان نوبت صندوق‌دار است.", ""),
    "turn_carrier": ("📦 پیامِ نوبتِ جابه‌جا‌کننده", "الان نوبت جابه‌جا‌کننده است.", ""),
    "turn_driver": ("🚗 پیامِ نوبتِ راننده", "الان نوبت راننده است.", ""),
    "nothing_found": ("❌ پیامِ «کافیه» بدونِ آیتم", "هنوز چیزی پیدا نکردی!", ""),
    "reverse_hint": ("💡 نکته‌ی نمایشِ برعکس", "💡 نکته: رنگ‌ها بعد از انتخاب برعکس نمایش داده می‌شوند، اما شما باید رنگ‌ها را همیشه از چپ به راست وارد کنید.", ""),
    "success_title": ("🥷 تیترِ گزارشِ موفقیت", "🥷 سرقت با موفقیت انجام شد!", ""),
    "fail_title": ("🚨 تیترِ گزارشِ شکست", "🚨 سرقت ناموفق شد", ""),
    "reason_police": ("🚔 دلیلِ شکست: پلیس", "پلیس رسید", ""),
    "reason_failed": ("💥 دلیلِ شکست: عملیات", "شکست عملیات", ""),
    "reason_leave": ("🚪 دلیلِ شکست: خروج", "یکی از اعضا از عملیات خارج شد", ""),
    "jail_line": ("🚔 جمله‌ی زندان", "🚔 کل تیم به زندان هاپویی منتقل شد.", ""),
}
MSG_PREFIX = "heist_msg_"
MESSAGE_DEFAULTS = {MSG_PREFIX + k: v[1] for k, v in MESSAGES.items()}
HEIST_CFG_DEFAULTS.update(MESSAGE_DEFAULTS)
for _k, _v in MESSAGES.items():
    ALL_CFG_LABEL[MSG_PREFIX + _k] = _v[0]

db.DEFAULT_CONFIG.update(HEIST_CFG_DEFAULTS)
db.MODULE_LEVEL_GATES.setdefault("heist", "🥷 سرقت هاپویی (کل بخش‌ها)")
db.DEFAULT_CONFIG.setdefault("minlvl_heist", "0")


# ---------------------------------------------------------------------------
# مدل‌ها
# ---------------------------------------------------------------------------
_TYPE_MAP = {"int": Integer, "float": Float, "str": String, "text": Text, "bool": Boolean}


class HeistLocation(Base):
    __tablename__ = "heist_locations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    code = Column(String, unique=True, nullable=False)          # Internal ID
    name = Column(String, nullable=False)
    description = Column(Text, default="")
    tier = Column(String, default="1")
    req_xp = Column(Integer, default=0)
    success_xp = Column(Integer, default=0)
    cooldown_minutes = Column(Integer, default=0)
    cooldown_trigger = Column(String, default="on_finish")
    police_seconds = Column(Integer, default=300)
    jail_minutes = Column(Integer, default=0)
    bail_amount = Column(Float, default=0)
    items_count = Column(Integer, default=1)
    grid_cells = Column(Integer, default=20)
    item_fail_pct = Column(Float, default=0)
    value_variance = Column(Float, default=0)
    early_finish = Column(Boolean, default=True)
    min_found_items = Column(Integer, default=1)
    auto_finish_all = Column(Boolean, default=True)
    no_item_policy = Column(String, default="blocked")
    failed_item_policy = Column(String, default="remove")
    spy_base_colors = Column(Integer, default=8)
    spy_per_skill_colors = Column(Integer, default=1)
    spy_min_colors = Column(Integer, default=3)
    spy_max_skill = Column(Integer, default=0)
    safe_per_skill_pct = Column(Float, default=1)
    safe_min_pct = Column(Float, default=0)
    safe_max_pct = Column(Float, default=100)
    safe_max_skill = Column(Integer, default=5)
    carrier_base_sec = Column(Integer, default=15)
    carrier_per_skill_sec = Column(Integer, default=1)
    carrier_min_sec = Column(Integer, default=3)
    carrier_max_skill = Column(Integer, default=0)
    driver_base_sec = Column(Integer, default=165)
    driver_per_skill_sec = Column(Integer, default=14)
    driver_min_sec = Column(Integer, default=30)
    driver_max_skill = Column(Integer, default=0)
    split_remainder = Column(String, default="normalize")
    auto_start = Column(Boolean, default=True)
    leave_after_start = Column(String, default="blocked")
    rules_text = Column(Text, default="")
    enabled = Column(Boolean, default=True)
    deleted = Column(Boolean, default=False, index=True)        # Soft Delete
    sort = Column(Integer, default=0)
    created_at = Column(DateTime, default=now)


class HeistLocationItem(Base):
    __tablename__ = "heist_location_items"
    id = Column(Integer, primary_key=True, autoincrement=True)
    location_id = Column(Integer, index=True, nullable=False)
    name = Column(String, nullable=False)
    base_value = Column(Integer, default=0)
    weight = Column(Float, default=1)                           # شانسِ نسبیِ انتخاب شدن در Pool
    fail_pct = Column(Float, nullable=True)                     # خالی = از پیش‌فرضِ مکان
    variance = Column(Float, nullable=True)                     # خالی = از پیش‌فرضِ مکان
    enabled = Column(Boolean, default=True)


class HeistPlayer(Base):
    """XP و مهارت‌های سرقت. (XPِ سرقت جداست چون User.xp «پیشرفتِ داخلِ سطحه» و با لول‌آپ صفر می‌شه؛
    الگوی دقیقاً مثلِ WarPlayer.xp در جنگ هاپویی.)"""
    __tablename__ = "heist_players"
    user_id = Column(BigInteger, primary_key=True)
    xp_total = Column(Float, default=0)          # کلِ XPِ کسب‌شده (برای باز شدنِ مکان‌ها)
    xp = Column(Float, default=0)                # XPِ باقی‌مانده (قابلِ تبدیل به امتیازِ مهارت)
    skill_spy = Column(Integer, default=0)
    skill_safe = Column(Integer, default=0)
    skill_carrier = Column(Integer, default=0)
    skill_driver = Column(Integer, default=0)
    free_points = Column(Integer, default=0)     # امتیازِ آزاد (بعد از ➖)
    heists = Column(Integer, default=0)
    wins = Column(Integer, default=0)
    created_at = Column(DateTime, default=now)


class HeistPanel(Base):
    """هر پیامِ پنل (سمتِ سرور مالک/گروه/نوعش مشخصه؛ به callback_data اعتماد نمی‌کنیم)."""
    __tablename__ = "heist_panels"
    id = Column(Integer, primary_key=True, autoincrement=True)
    chat_id = Column(BigInteger, nullable=False)
    message_id = Column(BigInteger, nullable=True)
    owner_id = Column(BigInteger, nullable=False)
    op_id = Column(Integer, nullable=True, index=True)          # خالی = هنوز لابی ساخته نشده (پنلِ شخصیِ سازنده)
    created_at = Column(DateTime, default=now)


class HeistOperation(Base):
    __tablename__ = "heist_operations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    location_id = Column(Integer, index=True, nullable=False)
    chat_id = Column(BigInteger, index=True, nullable=False)
    creator_id = Column(BigInteger, nullable=False)
    panel_id = Column(Integer, nullable=True)
    status = Column(String, default="RECRUITING", index=True)
    result = Column(String, nullable=True)                      # success / failed
    fail_reason = Column(String, nullable=True)                 # police / failed / leave
    seed = Column(BigInteger, nullable=False)                   # فقط سمتِ سرور تولید و نگهداری می‌شه
    cfg_json = Column(Text, nullable=True)                      # Snapshotِ تنظیماتِ مکان+آیتم‌ها (موقعِ شروعِ واقعی)
    phase_data = Column(Text, default="{}")                     # اطلاعاتِ مرحله‌ی جاری (رنگ‌ها، ورودی، تایمر آیتم و ...)
    created_at = Column(DateTime, default=now)
    expires_at = Column(DateTime, nullable=True)                # مهلتِ لابی
    started_at = Column(DateTime, nullable=True)
    police_deadline = Column(DateTime, nullable=True)
    phase_started_at = Column(DateTime, nullable=True)
    phase_ready_at = Column(DateTime, nullable=True)            # تایمرِ مرحله‌ی جاری (آیتم/رانندگی)
    last_refresh_at = Column(DateTime, nullable=True)
    finished_at = Column(DateTime, nullable=True)
    settled_at = Column(DateTime, nullable=True)
    total_loot = Column(Float, default=0)
    per_member = Column(Float, default=0)
    resolution_id = Column(String, nullable=True, unique=True)  # یکتا؛ ضدِ پرداختِ تکراری
    __table_args__ = (Index("ix_heist_op_active", "status", "police_deadline"),)


class HeistOpMember(Base):
    __tablename__ = "heist_operation_members"
    id = Column(Integer, primary_key=True, autoincrement=True)
    op_id = Column(Integer, index=True, nullable=False)
    user_id = Column(BigInteger, index=True, nullable=False)
    slot = Column(Integer, nullable=False)
    role = Column(String, nullable=False)
    name = Column(String, default="")
    skill = Column(Integer, default=0)                          # Snapshotِ مهارتِ همین نقش
    skills_json = Column(Text, default="{}")                    # Snapshotِ هر ۴ مهارت (برای لاگ)
    joined_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("op_id", "slot", name="uq_heist_member_slot"),
                      UniqueConstraint("op_id", "user_id", name="uq_heist_member_user"))


class HeistOpItem(Base):
    __tablename__ = "heist_operation_items"
    id = Column(Integer, primary_key=True, autoincrement=True)
    op_id = Column(Integer, index=True, nullable=False)
    cell = Column(Integer, nullable=False)
    item_id = Column(Integer, nullable=True)
    name = Column(String, nullable=False)
    base_value = Column(Integer, default=0)
    value = Column(Integer, default=0)
    fail_pct_base = Column(Float, nullable=True)
    found = Column(Boolean, default=False)
    loaded = Column(Boolean, default=False)
    lost = Column(Boolean, nullable=True)                       # نتیجه‌ی Rollِ نهایی
    fail_pct_eff = Column(Float, nullable=True)
    __table_args__ = (UniqueConstraint("op_id", "cell", name="uq_heist_item_cell"),)


class HeistCooldown(Base):
    __tablename__ = "heist_cooldowns"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    location_id = Column(Integer, nullable=False)
    op_id = Column(Integer, nullable=False)
    until = Column(DateTime, nullable=False)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("user_id", "location_id", "op_id", name="uq_heist_cd"),
                      Index("ix_heist_cd_lookup", "user_id", "location_id"))


class HeistReward(Base):
    __tablename__ = "heist_rewards"
    id = Column(Integer, primary_key=True, autoincrement=True)
    op_id = Column(Integer, nullable=False)
    user_id = Column(BigInteger, nullable=False)
    hop = Column(Float, default=0)
    xp = Column(Float, default=0)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("op_id", "user_id", name="uq_heist_reward"),)


class HeistEvent(Base):
    """لاگِ کاملِ هر عملیات (و تغییراتِ ادمین با op_id=0) برای Audit/Replay."""
    __tablename__ = "heist_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    op_id = Column(Integer, index=True, nullable=False)
    kind = Column(String, index=True, nullable=False)
    detail = Column(Text, default="{}")
    created_at = Column(DateTime, default=now)


# ---------------------------------------------------------------------------
# ساختِ جدول‌ها + کانفیگ (بدونِ هیچ مکانِ پیش‌فرض!)
# ---------------------------------------------------------------------------
def init_heist():
    """بعد از db.init_db() صدا زده می‌شه. فقط جدولِ جدید می‌سازه و کلیدِ کانفیگِ جدید اضافه می‌کنه؛
    به هیچ جدولِ قدیمی دست نمی‌زنه (بدونِ ALTER/DROP/DELETE) و هیچ مکانی نمی‌سازه."""
    Base.metadata.create_all(db.engine)
    s = db.get_session()
    try:
        existing = {c.key for c in s.query(db.Config).all()}
        for k, v in HEIST_CFG_DEFAULTS.items():
            if k not in existing:
                s.add(db.Config(key=k, value=v))
        if "minlvl_heist" not in existing:
            s.add(db.Config(key="minlvl_heist", value="0"))
        s.commit()
        db.cfg_cache_clear()   # کلیدهایِ تازه‌سیدشده فوراً دیده بشن
    finally:
        s.close()


def loc_default_values(session) -> dict:
    """مقدارِ اولیه‌ی یه مکانِ جدید = پیش‌فرض‌های ادمین (heist_def_*)."""
    out = {}
    for key, _l, kind, default, _g, _h in LOC_FIELDS:
        if key in LOC_NO_DEFAULT or key in ("description", "rules_text"):
            continue
        raw = db.cfg_get(session, DEF_PREFIX + key)
        out[key] = coerce(kind, raw if raw is not None else default)
    return out


def coerce(kind: str, raw):
    """تبدیلِ ورودیِ متنی به مقدارِ درست؛ ValueError با پیامِ فارسی در صورتِ نامعتبر."""
    raw = str(raw).strip()
    if kind == "int":
        try:
            v = float(raw)
        except ValueError:
            raise ValueError("یه عدد بفرست.")
        if v != v or v in (float("inf"), float("-inf")) or v != int(v):
            raise ValueError("یه عددِ صحیح بفرست.")
        return int(v)
    if kind == "float":
        try:
            v = float(raw)
        except ValueError:
            raise ValueError("یه عدد بفرست.")
        if v != v or v in (float("inf"), float("-inf")):
            raise ValueError("عددِ نامعتبر.")
        return v
    if kind == "bool":
        if raw.lower() in ("1", "true", "yes", "on", "بله", "آره", "روشن", "فعال"):
            return True
        if raw.lower() in ("0", "false", "no", "off", "خیر", "نه", "خاموش", "غیرفعال"):
            return False
        raise ValueError("۱ (بله) یا ۰ (خیر) بفرست.")
    if kind.startswith("enum:"):
        opts = kind[5:].split("|")
        if raw not in opts:
            raise ValueError("فقط یکی از اینا: " + " | ".join(opts))
        return raw
    return raw


def validate_loc_value(key: str, value):
    """قوانینِ منطقیِ مقدار (جلوی مقدارهای مخربِ بالانس رو می‌گیره). متنِ خطا یا ''."""
    if key in ("req_xp", "success_xp", "cooldown_minutes", "jail_minutes", "min_found_items", "spy_per_skill_colors",
               "carrier_per_skill_sec", "driver_per_skill_sec", "spy_max_skill", "safe_max_skill", "carrier_max_skill",
               "driver_max_skill", "items_count", "value_variance", "safe_per_skill_pct", "safe_min_pct"):
        if value < 0:
            return "منفی مجاز نیست."
    if key == "bail_amount" and value < -1:
        return "فقط ‎-۱ یا عددِ ۰ و بالاتر."
    if key == "police_seconds" and value < 5:
        return "زمانِ پلیس حداقل ۵ ثانیه."
    if key == "grid_cells" and not 1 <= value <= 40:
        return "تعدادِ خونه‌ها بینِ ۱ تا ۴۰."
    if key in ("item_fail_pct", "safe_max_pct", "safe_min_pct") and not 0 <= value <= 100:
        return "درصد باید بینِ ۰ تا ۱۰۰ باشه."
    if key in ("spy_base_colors", "spy_min_colors", "carrier_base_sec", "carrier_min_sec", "driver_base_sec", "driver_min_sec") and value < 1:
        return "حداقل ۱."
    if key == "name" and not str(value).strip():
        return "نام نمی‌تونه خالی باشه."
    return ""


def validate_loc_cross(vals: dict) -> str:
    """چکِ رابطه‌ی بینِ فیلدها (مثلا تعدادِ آیتم از تعدادِ خونه بیشتر نباشه). vals = مقدارهای نهاییِ مکان."""
    if vals.get("items_count", 0) > vals.get("grid_cells", 20):
        return "تعدادِ آیتم‌ها نمی‌تونه از تعدادِ خونه‌ها بیشتر باشه."
    if vals.get("spy_min_colors", 1) > vals.get("spy_base_colors", 8):
        return "حداقلِ رنگ نمی‌تونه از رنگِ پایه بیشتر باشه."
    if vals.get("safe_min_pct", 0) > vals.get("safe_max_pct", 100):
        return "کفِ ریسک نمی‌تونه از سقفش بیشتر باشه."
    if vals.get("carrier_min_sec", 1) > vals.get("carrier_base_sec", 1):
        return "حداقلِ زمانِ جابه‌جایی نمی‌تونه از زمانِ پایه بیشتر باشه."
    if vals.get("driver_min_sec", 1) > vals.get("driver_base_sec", 1):
        return "حداقلِ زمانِ رانندگی نمی‌تونه از زمانِ پایه بیشتر باشه."
    return ""


def dumps(obj) -> str:
    return json.dumps(obj, ensure_ascii=False, default=str)
