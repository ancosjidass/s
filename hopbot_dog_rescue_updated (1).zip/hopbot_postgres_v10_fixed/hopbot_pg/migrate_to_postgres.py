# -*- coding: utf-8 -*-
"""
انتقالِ کاملِ دیتابیسِ ربات از SQLite به PostgreSQL (Supabase) — بدونِ تغییرِ هیچ دیتایی.

مراحل (همه خودکار):
  ۱) از فایلِ SQLite یه نسخه‌ی سازگار (با backup API؛ حتی اگه ربات هنوز روشن/WAL باشه) می‌گیره
  ۲) جدول‌ها رو تو PostgreSQL می‌سازه (دقیقاً از رویِ مدل‌هایِ ربات + جدول‌هایِ بی‌مدلِ قدیمی)
  ۳) دیتا رو با حفظِ تمامِ idها (telegram_id، round id، ...) کپی می‌کنه
  ۴) شمارنده‌هایِ خودکارِ id (sequence) رو روی بعد از بزرگ‌ترین id می‌ذاره
  ۵) صحت رو چک می‌کنه: تعدادِ ردیفِ هر جدول + جمعِ هر ستونِ عددی (مثلاً مجموعِ همه‌ی hop_points)
     بینِ SQLite و PostgreSQL باید «دقیقاً» برابر باشه، وگرنه خطا می‌ده
  ۶) (اختیاری) RLS رو روی همه‌ی جدول‌ها روشن می‌کنه تا از طریقِ API عمومیِ Supabase قابلِ خوندن نباشن

استفاده:
  export DATABASE_URL='postgresql://postgres.xxxx:PASSWORD@aws-0-eu-central-1.pooler.supabase.com:5432/postgres'
  python migrate_to_postgres.py --sqlite hop_bot.db --dry-run     # فقط تست؛ هیچی ثبت نمی‌شه
  python migrate_to_postgres.py --sqlite hop_bot.db               # انتقالِ واقعی
  (اگه جدولِ مقصد از قبل دیتا داره: --wipe  تا اول خالی بشه)
"""
import argparse
import datetime
import os
import sqlite3
import sys
import tempfile
import time


def _norm_url(url: str) -> str:
    url = url.strip()
    if url.startswith("postgres://"):
        url = "postgresql://" + url[len("postgres://"):]
    if url.startswith("postgresql://"):
        url = "postgresql+psycopg2://" + url[len("postgresql://"):]
    return url


def main():
    ap = argparse.ArgumentParser(description="SQLite -> PostgreSQL migration for the bot")
    ap.add_argument("--sqlite", required=True, help="مسیرِ فایلِ دیتابیسِ SQLite (مثلاً hop_bot.db)")
    ap.add_argument("--pg", default=os.environ.get("DATABASE_URL", ""), help="آدرسِ اتصالِ PostgreSQL (یا متغیرِ DATABASE_URL)")
    ap.add_argument("--dry-run", action="store_true", help="همه‌چیز رو تست می‌کنه ولی دیتا ثبت (commit) نمی‌شه")
    ap.add_argument("--wipe", action="store_true", help="اگه جدول‌هایِ مقصد دیتا دارن، اول خالی‌شون کن")
    ap.add_argument("--no-rls", action="store_true", help="RLS روشن نشه (پیش‌فرض: روشن)")
    ap.add_argument("--purge", action="store_true", help="بعد از انتقال، دیتایِ عملیات‌هایِ تمام‌شده هم پاک‌سازی بشه")
    a = ap.parse_args()

    if not a.pg:
        sys.exit("❌ آدرسِ PostgreSQL داده نشده (--pg یا متغیرِ DATABASE_URL).")
    if not os.path.exists(a.sqlite):
        sys.exit(f"❌ فایلِ SQLite پیدا نشد: {a.sqlite}")

    os.environ["DATABASE_URL"] = _norm_url(a.pg)
    sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

    from sqlalchemy import create_engine, text, select, MetaData, Table, inspect, Integer, BigInteger, Float, Numeric
    import db  # noqa  (با DATABASE_URL بالا، engineِ PostgreSQL ساخته می‌شه)
    import war_db, heist_db, mission_db, account_backup, chat_prefs, referral  # noqa  (ثبتِ همه‌ی مدل‌ها)

    if not db.IS_PG:
        sys.exit("❌ DATABASE_URL یه آدرسِ PostgreSQL نیست.")
    pg = db.engine

    # ۱) نسخه‌ی سازگار از SQLite (بدونِ دست‌زدن به فایلِ اصلی)
    tmpdir = tempfile.mkdtemp(prefix="hopmig_")
    snap = os.path.join(tmpdir, "snapshot.db")
    src_c = sqlite3.connect(f"file:{os.path.abspath(a.sqlite)}?mode=ro", uri=True)
    dst_c = sqlite3.connect(snap)
    src_c.backup(dst_c)
    dst_c.close()
    src_c.close()
    sl = create_engine(f"sqlite:///{snap}")
    print(f"✅ نسخه‌ی سازگار از SQLite گرفته شد ({os.path.getsize(snap) / 1e6:.1f} MB)")

    # ۲) ساختِ جدول‌ها
    md = db.Base.metadata
    db.no_autoincrement_for_natural_keys()
    md.create_all(pg)
    sl_tables = set(inspect(sl).get_table_names()) - {"sqlite_sequence"}
    model_tables = {t.name: t for t in md.sorted_tables}

    # جدول‌هایِ قدیمیِ بی‌مدل (مثلاً rebalance_backup): از رویِ ساختارِ خودِ SQLite ساخته و کپی می‌شن
    extra_md = MetaData()
    extra = {}
    for name in sorted(sl_tables - set(model_tables)):
        t = Table(name, extra_md, autoload_with=sl)
        for col in t.columns:          # نوع‌هایِ مخصوصِ SQLite (مثلاً DATETIME) → نوعِ عمومی
            try:
                col.type = col.type.as_generic()
            except Exception:
                from sqlalchemy import Text
                col.type = Text()
        if len(list(t.primary_key.columns)) == 1 and list(t.primary_key.columns)[0].name != 'id':
            list(t.primary_key.columns)[0].autoincrement = False
        extra[name] = t
    if extra:
        extra_md.create_all(pg)
        print("ℹ️ جدول‌هایِ بی‌مدل (کپی می‌شن):", ", ".join(extra))

    all_tables = [t for t in md.sorted_tables if t.name in sl_tables] + list(extra.values())

    # ردیف‌هایِ «یتیم» (به ردیفی اشاره می‌کنن که تو SQLite دیگه نیست؛ مثلاً آیتمِ پاک‌شده‌ی فروشگاه).
    # SQLite این‌ها رو تحمل می‌کرد ولی PostgreSQL نه. برایِ اینکه هیچ دیتایِ بازیکنی حذف/عوض نشه،
    # فقط همون کلیدِ خارجیِ مشکل‌دار تو PostgreSQL برداشته می‌شه و ردیف‌ها عیناً کپی می‌شن.
    with sl.connect() as sc:
        orphans = sc.execute(text("PRAGMA foreign_key_check")).fetchall()
    if orphans:
        pairs = {}
        for child, rowid, parent, fkid in orphans:
            pairs[(child, parent)] = pairs.get((child, parent), 0) + 1
        insp_pg = inspect(pg)
        with pg.begin() as c:
            for (child, parent), n in pairs.items():
                for fk in insp_pg.get_foreign_keys(child):
                    if fk["referred_table"] == parent and fk.get("name"):
                        c.execute(text(f'ALTER TABLE "{child}" DROP CONSTRAINT "{fk["name"]}"'))
                print(f"⚠️ {n} ردیفِ یتیم تو {child} (اشاره به {parent}ی که دیگه نیست) — ردیف‌ها حفظ شدن، فقط این یه قید برداشته شد.")

    # ۳) خالی‌بودنِ مقصد
    with pg.connect() as c:
        nonempty = [t.name for t in all_tables if c.execute(select(text("1")).select_from(t).limit(1)).first()]
    if nonempty:
        if not a.wipe:
            sys.exit("❌ این جدول‌ها تو PostgreSQL از قبل دیتا دارن: " + ", ".join(nonempty[:8]) +
                     "\n   اگه مطمئنی، با --wipe دوباره اجرا کن.")
        with pg.begin() as c:
            c.execute(text("TRUNCATE " + ", ".join(f'"{t.name}"' for t in all_tables) + " RESTART IDENTITY CASCADE"))
        print("🧹 جدول‌هایِ مقصد خالی شدن.")

    # ۴) کپی
    problems = []
    t0 = time.time()
    conn = pg.connect()
    trans = conn.begin()
    try:
        # بدونِ چکِ لحظه‌ایِ کلیدِ خارجی تا ترتیبِ جدول‌ها مهم نباشه (چک تو COMMIT انجام می‌شه)
        conn.execute(text("SET CONSTRAINTS ALL DEFERRED"))
        for t in all_tables:
            with sl.connect() as sc:
                have = {c["name"] for c in inspect(sl).get_columns(t.name)}
                cols = [c for c in t.columns if c.name in have]
                rows = [dict(r._mapping) for r in sc.execute(select(*cols))]
            if not rows:
                continue
            # کاراکترِ NUL تو رشته‌ها تو PostgreSQL ممنوعه
            for r in rows:
                for k, v in r.items():
                    if isinstance(v, str) and "\x00" in v:
                        r[k] = v.replace("\x00", "")
            for i in range(0, len(rows), 2000):
                part = rows[i:i + 2000]
                sp = conn.begin_nested()
                try:
                    conn.execute(t.insert(), part)
                    sp.commit()
                except Exception as e:  # ردیف‌به‌ردیف تا ردیفِ مشکل‌دار مشخص بشه
                    sp.rollback()
                    for r in part:
                        sp2 = conn.begin_nested()
                        try:
                            conn.execute(t.insert(), [r])
                            sp2.commit()
                        except Exception as e2:
                            sp2.rollback()
                            pk = {c.name: r.get(c.name) for c in t.primary_key.columns}
                            problems.append((t.name, pk, str(e2).splitlines()[0][:160]))
            print(f"  ↳ {t.name:34s}{len(rows):8d} ردیف")
        if problems:
            raise RuntimeError("ردیف‌هایِ نامعتبر پیدا شد")

        # ۵) sequence ها
        for t in all_tables:
            pk = list(t.primary_key.columns)
            if len(pk) == 1 and isinstance(pk[0].type, (Integer, BigInteger)):
                col = pk[0].name
                conn.execute(text(
                    f"SELECT setval(pg_get_serial_sequence('\"{t.name}\"', '{col}'), "
                    f"COALESCE((SELECT MAX(\"{col}\") FROM \"{t.name}\"), 0) + 1, false) "
                    f"WHERE pg_get_serial_sequence('\"{t.name}\"', '{col}') IS NOT NULL"))

        # ۶) صحت‌سنجی: تعداد + جمعِ ستون‌هایِ عددی
        conn.execute(text("SET CONSTRAINTS ALL IMMEDIATE"))
        bad = []
        for t in all_tables:
            with sl.connect() as sc:
                n_sl = sc.execute(text(f'SELECT COUNT(*) FROM "{t.name}"')).scalar()
            n_pg = conn.execute(text(f'SELECT COUNT(*) FROM "{t.name}"')).scalar()
            if n_sl != n_pg:
                bad.append(f"{t.name}: تعداد SQLite={n_sl} PostgreSQL={n_pg}")
                continue
            have = {c["name"] for c in inspect(sl).get_columns(t.name)}
            for c in t.columns:
                if c.name not in have or not isinstance(c.type, (Integer, BigInteger, Float, Numeric)):
                    continue
                # SQLite: TOTAL() (بدونِ overflow)؛ PostgreSQL: SUM رویِ numeric (بدونِ overflowِ bigint)
                q1 = f'SELECT TOTAL("{c.name}") FROM "{t.name}"'
                q2 = f'SELECT COALESCE(SUM("{c.name}"::numeric), 0) FROM "{t.name}"'
                with sl.connect() as sc:
                    s1 = float(sc.execute(text(q1)).scalar() or 0)
                s2 = float(conn.execute(text(q2)).scalar() or 0)
                if abs(s1 - s2) > max(1e-6, abs(s1) * 1e-9):
                    bad.append(f"{t.name}.{c.name}: جمع SQLite={s1} PostgreSQL={s2}")
        if bad:
            for b in bad:
                print("  ❌", b)
            raise RuntimeError("صحت‌سنجی ناموفق")

        if a.dry_run:
            trans.rollback()
            print(f"\n🧪 تستِ خشک موفق بود ({time.time() - t0:.0f}s): همه‌ی دیتا بدونِ خطا کپی و صحت‌سنجی شد، ولی چیزی ثبت نشد.")
        else:
            trans.commit()
            print(f"\n✅ انتقال کامل شد و صحت‌سنجی (تعداد + جمعِ ستون‌هایِ عددی) برایِ {len(all_tables)} جدول برابر بود ({time.time() - t0:.0f}s).")
    except Exception as e:
        trans.rollback()
        conn.close()
        print(f"\n❌ انتقال متوقف شد و هیچ تغییری ثبت نشد: {e}")
        for name, pk, msg in problems[:25]:
            print(f"   - {name} {pk}: {msg}")
        if len(problems) > 25:
            print(f"   ... و {len(problems) - 25} مورد دیگه")
        sys.exit(1)
    conn.close()

    if a.dry_run:
        return

    # ۷) RLS (Supabase: جلوگیریِ دسترسیِ عمومی از طریقِ REST API)
    if not a.no_rls:
        with pg.begin() as c:
            names = [r[0] for r in c.execute(text("SELECT tablename FROM pg_tables WHERE schemaname='public'"))]
            for n in names:
                c.execute(text(f'ALTER TABLE public."{n}" ENABLE ROW LEVEL SECURITY'))
        print(f"🔒 RLS روی {len(names)} جدول روشن شد (فقط خودِ ربات با رمزِ دیتابیس دسترسی داره).")

    # ۸) پاک‌سازیِ اختیاریِ عملیات‌هایِ تمام‌شده
    if a.purge:
        import db_purge
        rep = db_purge.run_purge_all()
        print("🧹 پاک‌سازیِ عملیات‌هایِ تمام‌شده:", rep or "چیزی برایِ پاک‌کردن نبود")

    print("\nحالا ربات رو با همین DATABASE_URL اجرا کن (فایلِ SQLite دست‌نخورده مونده و به‌عنوانِ بک‌آپ نگهش دار).")


if __name__ == "__main__":
    main()
