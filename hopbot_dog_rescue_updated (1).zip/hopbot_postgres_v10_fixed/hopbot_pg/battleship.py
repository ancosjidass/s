# -*- coding: utf-8 -*-
"""
نبردِ دریایی 🚢 - بازیِ جدیدِ کازینو هاپویی، دقیقاً ۲نفره.

قوانین:
- صفحه‌ی ۵×۵. هر بازیکن ۴تا نقطه (کشتی) رو مخفیانه انتخاب می‌کنه.
- چون باید مخفی بمونه (بازیکن‌ها نباید جای کشتیِ همدیگه رو ببینن)، جای‌گذاری و
  حدس‌زدن از طریقِ پیویِ خودِ بات با هرکدوم از بازیکن‌ها انجام می‌شه - نه با
  دکمه‌های تو پیامِ گروه (که همه می‌بینن). تو گروه فقط وضعیتِ کلی/برد‌وباخت
  اعلام می‌شه.
- بعدِ اینکه هر دو نفر ۴ نقطه‌شون رو نهایی کردن، شانسی مشخص می‌شه کی اول حدس
  می‌زنه. نوبتی، هر پلیر هر نوبت ۱ نقطه از صفحه‌ی حریف رو حدس می‌زنه (نه بیشتر -
  با قفلِ round + چک‌کردنِ نوبت/تکراری‌نبودنِ خونه، جلوی دوبار حساب‌شدنِ یه کلیک
  گرفته شده).
- حداکثر ۱۲ نوبت برای هر پلیر. اگه یکی زودتر هر ۴ نقطه‌ی حریف رو پیدا کنه،
  همون‌جا برنده‌ست. اگه به ۱۲ نوبت رسیدن و کسی همه رو پیدا نکرده بود، هرکی
  اصابتِ بیشتری داشته برنده‌ست؛ مساوی بشه، مبلغِ ورودیِ هر دو برمی‌گرده.
- تاییدِ جای‌گذاری/حدس منتظرِ ۸۰ ثانیه‌ست (چه تو جای‌گذاری چه تو نوبتِ بعدی)؛
  اگه بگذره، بازی لغو می‌شه و پول‌ها برمی‌گرده (چک‌شونده تو jobs.tick_job).
"""
import asyncio
import datetime
import json
import logging
import random

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import Forbidden, BadRequest
from telegram.ext import ApplicationHandlerStop

import db
import mentions
from handlers import fmt, send_response, is_reply_to_prompt, parse_amount, ask_for_input
import casino

logger = logging.getLogger(__name__)

GRID_SIZE = 5
DEFAULT_SHIPS_PER_PLAYER = 4
DEFAULT_MAX_TURNS_PER_PLAYER = 12
ACTION_TIMEOUT_SECONDS = 80
SETUP_ABANDON_TIMEOUT_SECONDS = 60  # اگه کاربر بازی رو بسازه ولی هیچ‌وقت «شروع» رو نزنه (یا پیامش رو پاک کنه)، بعدِ این‌همه ثانیه رها می‌شه

# قفلِ اختصاصیِ هر دورِ نبردِ دریایی - همون منطقِ with_round_lock تو casino.py،
# برای جلوگیری از پردازشِ هم‌زمانِ دو تا اکشنِ یه دور (که می‌تونست باعثِ
# ثبتِ چندتایی/اضافیِ یه حدس بشه).
_round_locks = {}


def _get_round_lock(round_id: int) -> asyncio.Lock:
    lock = _round_locks.get(round_id)
    if lock is None:
        lock = asyncio.Lock()
        _round_locks[round_id] = lock
    return lock


def with_round_lock(func):
    async def wrapper(update, context):
        try:
            rid = int(update.callback_query.data.split(":")[1])
        except (ValueError, IndexError, AttributeError):
            await func(update, context)
            return
        async with _get_round_lock(rid):
            await func(update, context)
        session = db.get_session()
        try:
            r = session.get(db.BattleshipRound, rid)
            if not r or r.status in ("resolved", "cancelled"):
                _round_locks.pop(rid, None)
        finally:
            session.close()
    return wrapper


def _preset_amounts(session):
    raw = db.cfg_get(session, "casino_preset_amounts")
    out = []
    for part in raw.split(","):
        part = part.strip()
        if part.isdigit():
            out.append(int(part))
    return out or [100, 500, 1000, 5000, 10000]


def _load(text):
    try:
        return json.loads(text) if text else []
    except (TypeError, ValueError):
        return []


def _dump(obj):
    return json.dumps(obj)


def _touch(r):
    r.last_action_at = datetime.datetime.utcnow()


def _end_round(r, status):
    r.status = status
    r.ended_at = datetime.datetime.utcnow()


async def _refund(session, r, reason: str):
    """پولِ ورودیِ هر دو بازیکن (هرکدوم که واقعاً پرداخت کرده) رو برمی‌گردونه."""
    for uid in (r.player1_id, r.player2_id):
        if not uid:
            continue
        u = session.get(db.User, uid)
        if u and r.entry_amount:
            u.hop_points += r.entry_amount


# ---------------------------------------------------------------------------
# شروع/تنظیمِ مبلغ (تو گروه)
# ---------------------------------------------------------------------------

async def cb_bship_new(update, context):
    parts = update.callback_query.data.split(":")
    owner_id = int(parts[1]) if len(parts) > 1 else None
    if owner_id is not None and update.effective_user.id != owner_id:
        await update.callback_query.answer(
            "⛔️ این منو مالِ تو نیست! برای بازکردنِ کازینوی خودت، بنویس «کازینو هاپویی».",
            show_alert=True)
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, update.effective_user.id):
            await update.callback_query.answer(
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, update.effective_user.id)
        if remaining > 0:
            await update.callback_query.answer(
                f"⏳ کازینوی قبلیِ این گروه تازه تموم شده. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        r = db.BattleshipRound(
            chat_id=update.effective_chat.id,
            group_message_id=update.callback_query.message.message_id,
            initiator_id=update.effective_user.id,
            status="setup",
            ships_per_player=max(1, min(GRID_SIZE * GRID_SIZE, db.cfg_get_int(session, "bship_ships_per_player") or DEFAULT_SHIPS_PER_PLAYER)),
            max_turns=max(1, db.cfg_get_int(session, "bship_max_turns") or DEFAULT_MAX_TURNS_PER_PLAYER),
        )
        session.add(r)
        session.commit()
        text, kb = _render_setup(session, r)
        await send_response(update, text, kb)
    finally:
        session.close()


def _render_setup(session, r):
    amount_txt = fmt(r.entry_amount) + " 🪙" if r.entry_amount else "— تنظیم نشده —"
    text = (
        f"🚢 نبردِ دریایی (۲نفره)\n\n"
        f"💰 مبلغ ورودی: {amount_txt}\n\n"
        "بعدِ انتخابِ مبلغ، بازی تو گروه لابی می‌شه؛ یه نفرِ دیگه باید بپیونده. "
        "بعدش هر دو تو پیویِ بات، جدا از هم، جای کشتی‌هاشون رو انتخاب می‌کنن."
    )
    rows = [[InlineKeyboardButton("💰 انتخاب مبلغ ورودی", callback_data=f"bship_amt_menu:{r.id}")]]
    if r.entry_amount:
        rows.append([InlineKeyboardButton("▶️ شروع بازی", callback_data=f"bship_start:{r.id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت (تغییرِ نوعِ بازی)", callback_data=f"bship_back_to_types:{r.id}"),
                 InlineKeyboardButton("❌ لغو", callback_data=f"bship_cancel:{r.id}")])
    return text, InlineKeyboardMarkup(rows)


async def _check_initiator(update, r):
    if not r or update.effective_user.id != r.initiator_id:
        await update.callback_query.answer("⛔️ این بازی مال تو نیست! برای ساختن بازی خودت رو دکمه‌ی «نبرد دریایی» بزن.", show_alert=True)
        return False
    return True


async def cb_bship_amt_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        rows = [[InlineKeyboardButton(f"{a:,}", callback_data=f"bship_amt_pick:{rid}:{a}")] for a in _preset_amounts(session)]
        rows.append([InlineKeyboardButton("✏️ مبلغِ دلخواه", callback_data=f"bship_amt_custom:{rid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"bship_back:{rid}")])
        await send_response(update, "💰 مبلغِ ورودی رو انتخاب کن:", InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_bship_amt_pick(update, context):
    _, rid, amount = update.callback_query.data.split(":")
    rid, amount = int(rid), float(amount)
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if casino.max_bet_exceeded(session, amount):
            await update.callback_query.answer(
                f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست.", show_alert=True)
            return
        r.entry_amount = amount
        session.commit()
        text, kb = _render_setup(session, r)
        await send_response(update, text, kb)
    finally:
        session.close()


async def cb_bship_amt_custom(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
    finally:
        session.close()
    await ask_for_input(update, context, "✏️ مبلغ ورودیِ دلخواه رو به عدد بفرست:", {"type": "amount", "round_id": rid}, "bship_awaiting")


async def bship_awaiting_handler(update, context):
    state = context.user_data.get("bship_awaiting")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return
    context.user_data.pop("bship_awaiting", None)
    rid = state["round_id"]
    amount = parse_amount(update.message.text or "")
    if amount is None or amount <= 0:
        await update.message.reply_text("❌ مقدار نامعتبره؛ عملیات لغو شد.")
        raise ApplicationHandlerStop
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not r or r.status != "setup" or update.effective_user.id != r.initiator_id:
            await update.message.reply_text("این بازی دیگه فعال نیست.")
            raise ApplicationHandlerStop
        if casino.max_bet_exceeded(session, amount):
            await update.message.reply_text(f"❌ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست؛ عملیات لغو شد.")
            raise ApplicationHandlerStop
        r.entry_amount = amount
        session.commit()
        # نکته‌ی مهم: اینجا باید همون پیامِ اصلیِ بازی (group_message_id) رو
        # ادیت کنیم، نه یه پیامِ جدید بفرستیم - وگرنه از این به بعد دو تا پیامِ
        # جدا از هم داریم (یکی قدیمی و رهاشده، یکی جدید) و همه‌ی مراحلِ بعدیِ
        # بازی (لابی/نتیجه/...) که رو group_message_id ادیت می‌شن، رو پیامِ
        # اشتباهی می‌رن و پیامِ جدید هیچ‌وقت به‌روز نمی‌شه - دقیقاً همون باگی که
        # باعث می‌شد صفحه‌ی «عضوگیری» قدیمی برای همیشه باز/رهاشده بمونه.
        text, kb = _render_setup(session, r)
        try:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text, reply_markup=kb)
        except Exception:
            msg = await update.message.reply_text(text, reply_markup=kb)
            r.group_message_id = msg.message_id
            session.commit()
    finally:
        session.close()
    raise ApplicationHandlerStop


async def cb_bship_back(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not await _check_initiator(update, r):
            return
        text, kb = _render_setup(session, r)
        await send_response(update, text, kb)
    finally:
        session.close()


async def cb_bship_cancel(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status not in ("setup", "lobby"):
            await update.callback_query.answer("⛔️ این بازی دیگه قابلِ لغو نیست.", show_alert=True)
            return
        await _refund(session, r, "لغو توسطِ سازنده")
        _end_round(r, "cancelled")
        session.commit()
        await send_response(update, "❌ بازی لغو شد.", None)
    finally:
        session.close()


async def cb_bship_back_to_types(update, context):
    """مشابهِ casino.cb_casino_back_to_types - برگشت به منوی انتخابِ نوعِ بازیِ
    کازینو، برای وقتی که کاربر اشتباهی «نبردِ دریایی» رو انتخاب کرده بود."""
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _end_round(r, "cancelled")
        session.commit()
        text, kb = casino.menu_text_and_kb(r.initiator_id)
        await send_response(update, text, kb)
    finally:
        session.close()


@with_round_lock
async def cb_bship_start(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if not r.entry_amount:
            await update.callback_query.answer("اول باید مبلغِ ورودی رو انتخاب کنی.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await update.callback_query.answer(f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        r.player1_id = update.effective_user.id
        r.status = "lobby"
        r.lobby_opened_at = datetime.datetime.utcnow()
        _touch(r)
        session.commit()
        text = (
            f"🚢 نبردِ دریایی\n\n"
            f"💰 مبلغِ ورودی: {fmt(r.entry_amount)} 🪙\n"
            f"👤 بازیکنِ اول: {mentions.of(update.effective_user)}\n\n"
            f"⏳ منتظرِ پیوستنِ نفرِ دوم (تا {_timeout_min(session)} دقیقه)..."
        )
        rows = [
            [InlineKeyboardButton("🚢 پیوستن به بازی", callback_data=f"bship_join:{rid}")],
            [InlineKeyboardButton("❌ لغو", callback_data=f"bship_cancel:{rid}")],
        ]
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


def _timeout_min(session):
    return max(1, round(casino._timeout_seconds(session) / 60))


@with_round_lock
async def cb_bship_join(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not r or r.status != "lobby":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if update.effective_user.id == r.player1_id:
            await update.callback_query.answer("⛔️ نمی‌تونی با خودت بازی کنی!", show_alert=True)
            return
        if casino._user_has_active_round(session, update.effective_user.id):
            await update.callback_query.answer(
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, update.effective_user.id)
        if remaining > 0:
            await update.callback_query.answer(
                f"⏳ خودت تازه یه کازینو تموم کردی. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await update.callback_query.answer(f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        r.player2_id = update.effective_user.id
        r.status = "placing"
        _touch(r)
        session.commit()
        await update.callback_query.answer("✅ پیوستی!")
        await _start_placement_phase(context, session, r)
    finally:
        session.close()


async def _start_placement_phase(context, session, r):
    text = (
        f"🚢 نبردِ دریایی شروع شد!\n\n"
        f"💰 مبلغِ ورودی: {fmt(r.entry_amount)} 🪙\n\n"
        "هر دو بازیکن الان تو پیویِ بات دارن جای ۴تا کشتیِ خودشون رو مخفیانه انتخاب می‌کنن. "
        f"⏳ اگه تا {ACTION_TIMEOUT_SECONDS} ثانیه دیگه هر دو کارشون تموم نشه، بازی لغو و پول‌ها برمی‌گرده."
    )
    try:
        await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
    except Exception:
        pass

    ok1 = await _send_placement_dm(context, session, r, r.player1_id, is_p1=True)
    ok2 = await _send_placement_dm(context, session, r, r.player2_id, is_p1=False)
    if not ok1 or not ok2:
        missing = []
        if not ok1:
            missing.append(r.player1_id)
        if not ok2:
            missing.append(r.player2_id)
        await _refund(session, r, "پیویِ بسته")
        _end_round(r, "cancelled")
        session.commit()
        names = "، ".join(str(uid) for uid in missing)
        try:
            await context.bot.edit_message_text(
                chat_id=r.chat_id, message_id=r.group_message_id,
                text=(f"❌ نبردِ دریایی لغو شد چون نمی‌تونم به پیویِ این آیدی(ها) پیام بدم: {names}\n"
                      "(باید اول یه‌بار تو پیویِ بات «استارت» بزنن.) پول‌ها برگشت داده شد."))
        except Exception:
            pass
        return
    session.commit()


def _placement_keyboard(ships, rid, ships_per_player):
    rows = []
    for row in range(GRID_SIZE):
        line = []
        for col in range(GRID_SIZE):
            mark = "🚢" if [row, col] in ships else "⬜"
            line.append(InlineKeyboardButton(mark, callback_data=f"bship_place:{rid}:{row}:{col}"))
        rows.append(line)
    if len(ships) == ships_per_player:
        rows.append([InlineKeyboardButton("✅ تایید نهایی", callback_data=f"bship_place_confirm:{rid}")])
    rows.append([InlineKeyboardButton(f"🚢 انتخاب‌شده: {len(ships)}/{ships_per_player}", callback_data="noop")])
    return InlineKeyboardMarkup(rows)


async def _send_placement_dm(context, session, r, user_id, is_p1: bool) -> bool:
    ships = _load(r.player1_ships if is_p1 else r.player2_ships)
    text = (
        "🚢 نبردِ دریایی - جای‌گذاریِ کشتی‌ها\n\n"
        f"روی صفحه بزن و {r.ships_per_player} تا خونه رو به‌عنوانِ کشتی انتخاب کن "
        "(دوباره زدن روی یه خونه‌ی انتخاب‌شده، انتخابش رو برمی‌داره).\n"
        "این صفحه رو کسِ دیگه‌ای نمی‌بینه."
    )
    try:
        msg = await context.bot.send_message(user_id, text, reply_markup=_placement_keyboard(ships, r.id, r.ships_per_player))
    except (Forbidden, BadRequest):
        return False
    except Exception:
        logger.exception("خطا در ارسالِ پیامِ جای‌گذاریِ نبردِ دریایی")
        return False
    if is_p1:
        r.player1_dm_message_id = msg.message_id
    else:
        r.player2_dm_message_id = msg.message_id
    return True


@with_round_lock
async def cb_bship_place(update, context):
    _, rid, row, col = update.callback_query.data.split(":")
    rid, row, col = int(rid), int(row), int(col)
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not r or r.status != "placing":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        is_p1 = uid == r.player1_id
        is_p2 = uid == r.player2_id
        if not is_p1 and not is_p2:
            await update.callback_query.answer("⛔️ این بازی مالِ تو نیست.", show_alert=True)
            return
        ships = _load(r.player1_ships if is_p1 else r.player2_ships)
        cell = [row, col]
        if cell in ships:
            ships.remove(cell)
        elif len(ships) < r.ships_per_player:
            ships.append(cell)
        else:
            await update.callback_query.answer(f"همینا کافیه ({r.ships_per_player}تا)! اول یکیشونو بردار یا تایید کن.", show_alert=True)
            return
        if is_p1:
            r.player1_ships = _dump(ships)
        else:
            r.player2_ships = _dump(ships)
        _touch(r)
        session.commit()
        await update.callback_query.answer()
        try:
            await update.callback_query.edit_message_reply_markup(_placement_keyboard(ships, rid, r.ships_per_player))
        except Exception:
            pass
    finally:
        session.close()


@with_round_lock
async def cb_bship_place_confirm(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not r or r.status != "placing":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        is_p1 = uid == r.player1_id
        is_p2 = uid == r.player2_id
        if not is_p1 and not is_p2:
            await update.callback_query.answer("⛔️ این بازی مالِ تو نیست.", show_alert=True)
            return
        ships = _load(r.player1_ships if is_p1 else r.player2_ships)
        if len(ships) != r.ships_per_player:
            await update.callback_query.answer(f"باید دقیقاً {r.ships_per_player} تا کشتی انتخاب کنی.", show_alert=True)
            return
        await update.callback_query.answer("✅ تاییدشد! منتظرِ حریف...")
        try:
            await update.callback_query.edit_message_text("✅ جای کشتی‌هات ثبت شد. منتظرِ آماده‌شدنِ حریف...")
        except Exception:
            pass

        if is_p1:
            r.player1_confirmed_at = datetime.datetime.utcnow()
        else:
            r.player2_confirmed_at = datetime.datetime.utcnow()
        _touch(r)
        session.commit()

        if r.player1_confirmed_at and r.player2_confirmed_at:
            await _start_playing_phase(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# فازِ بازی: نوبتی حدس‌زدن
# ---------------------------------------------------------------------------

def _guess_keyboard(guesses, rid, my_turn: bool):
    rows = []
    guessed_map = {(g[0], g[1]): g[2] for g in guesses}
    for row in range(GRID_SIZE):
        line = []
        for col in range(GRID_SIZE):
            if (row, col) in guessed_map:
                mark = "✅" if guessed_map[(row, col)] else "❌"
            else:
                mark = "🔷" if my_turn else "⬜"
            cb_data = f"bship_guess:{rid}:{row}:{col}" if my_turn else "noop"
            line.append(InlineKeyboardButton(mark, callback_data=cb_data))
        rows.append(line)
    return InlineKeyboardMarkup(rows)


def _guess_status_line(guesses, opponent_hits_found: int, max_turns: int, ships_per_player: int) -> str:
    turns_used = len(guesses)
    return f"🎯 نوبت‌های استفاده‌شده: {turns_used}/{max_turns} | 🎯 اصابت: {opponent_hits_found}/{ships_per_player}"


async def _send_guess_dm(context, r, user_id, is_p1: bool, my_turn: bool):
    my_guesses = _load(r.player1_guesses if is_p1 else r.player2_guesses)
    hits = sum(1 for g in my_guesses if g[2])
    header = "🎯 نوبتِ توئه! یه خونه از صفحه‌ی حریف رو انتخاب کن:" if my_turn else "⏳ منتظرِ نوبتِ حریف..."
    text = (
        f"🚢 نبردِ دریایی - فازِ حدس‌زدن\n\n{header}\n\n"
        f"{_guess_status_line(my_guesses, hits, r.max_turns, r.ships_per_player)}\n"
        "✅ = اصابت (کشتیِ حریف اونجا بود) | ❌ = خطا"
    )
    kb = _guess_keyboard(my_guesses, r.id, my_turn)
    dm_message_id = r.player1_dm_message_id if is_p1 else r.player2_dm_message_id
    try:
        if dm_message_id:
            await context.bot.edit_message_text(chat_id=user_id, message_id=dm_message_id, text=text, reply_markup=kb)
            return
    except Exception:
        pass
    try:
        msg = await context.bot.send_message(user_id, text, reply_markup=kb)
        if is_p1:
            r.player1_dm_message_id = msg.message_id
        else:
            r.player2_dm_message_id = msg.message_id
    except Exception:
        logger.exception("خطا در ارسالِ پیامِ حدس‌زدنِ نبردِ دریایی")


async def _start_playing_phase(context, session, r):
    r.status = "playing"
    r.turn_user_id = random.choice([r.player1_id, r.player2_id])
    _touch(r)
    session.commit()
    try:
        await context.bot.edit_message_text(
            chat_id=r.chat_id, message_id=r.group_message_id,
            text=(
                f"🚢 نبردِ دریایی - جای‌گذاری‌ها تموم شد!\n\n"
                f"🎲 شانسی مشخص شد که بازی رو کی شروع می‌کنه.\n"
                f"⏳ نتیجه‌ی نهایی همینجا اعلام می‌شه."
            ))
    except Exception:
        pass
    await _send_guess_dm(context, r, r.player1_id, True, r.turn_user_id == r.player1_id)
    await _send_guess_dm(context, r, r.player2_id, False, r.turn_user_id == r.player2_id)
    session.commit()


@with_round_lock
async def cb_bship_guess(update, context):
    _, rid, row, col = update.callback_query.data.split(":")
    rid, row, col = int(rid), int(row), int(col)
    session = db.get_session()
    try:
        r = session.get(db.BattleshipRound, rid)
        if not r or r.status != "playing":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        is_p1 = uid == r.player1_id
        is_p2 = uid == r.player2_id
        if not is_p1 and not is_p2:
            await update.callback_query.answer("⛔️ این بازی مالِ تو نیست.", show_alert=True)
            return
        if r.turn_user_id != uid:
            await update.callback_query.answer("⌛️ نوبتِ تو نیست، صبر کن.", show_alert=True)
            return
        my_guesses = _load(r.player1_guesses if is_p1 else r.player2_guesses)
        if any(g[0] == row and g[1] == col for g in my_guesses):
            await update.callback_query.answer("قبلاً همین خونه رو زده بودی.", show_alert=True)
            return
        if len(my_guesses) >= r.max_turns:
            await update.callback_query.answer("نوبت‌هات تموم شده.", show_alert=True)
            return

        opp_ships = _load(r.player2_ships if is_p1 else r.player1_ships)
        hit = [row, col] in opp_ships
        my_guesses.append([row, col, hit])
        if is_p1:
            r.player1_guesses = _dump(my_guesses)
        else:
            r.player2_guesses = _dump(my_guesses)

        my_hits = sum(1 for g in my_guesses if g[2])
        await update.callback_query.answer("✅ اصابت کردی!" if hit else "❌ خطا رفت.")

        if my_hits >= r.ships_per_player:
            await _finish_round(context, session, r, winner_id=uid, reason="found_all")
            session.commit()
            return

        other_id = r.player2_id if is_p1 else r.player1_id
        other_guesses = _load(r.player2_guesses if is_p1 else r.player1_guesses)
        if len(my_guesses) >= r.max_turns and len(other_guesses) >= r.max_turns:
            await _finish_round_by_score(context, session, r)
            session.commit()
            return

        # نوبت رو بلافاصله عوض می‌کنیم - همین باعث می‌شه اگه همین کلیک دوباره
        # (تکراری/کند بودنِ نت) برسه، چکِ «r.turn_user_id != uid» بالاتر جلوشو
        # بگیره، نه اینکه دوباره حساب بشه.
        r.turn_user_id = other_id
        _touch(r)
        session.commit()

        await _send_guess_dm(context, r, uid, is_p1, my_turn=False)
        await _send_guess_dm(context, r, other_id, not is_p1, my_turn=True)
        session.commit()
    finally:
        session.close()


def _reveal_keyboard(my_ships, enemy_guesses):
    """پنلِ پایانِ بازی - نشون می‌ده حریف کجاهای صفحه‌ی من رو زده:
    💥 = اونجا کشتی داشتم و حریف پیدا کرد | ❌ = اونجا کشتی نداشتم و حریف اشتباه زد
    🚢 = اونجا کشتی داشتم ولی حریف هیچ‌وقت نزد (زنده موند) | ⬜ = نه کشتی بود نه زده شد.
    دکمه‌ها همه noop هستن (غیرقابل‌کلیک) چون این فقط یه نمایشِ نتیجه‌ست."""
    guessed_map = {(g[0], g[1]): g[2] for g in enemy_guesses}
    rows = []
    for row in range(GRID_SIZE):
        line = []
        for col in range(GRID_SIZE):
            has_ship = [row, col] in my_ships
            if (row, col) in guessed_map:
                mark = "💥" if has_ship else "❌"
            else:
                mark = "🚢" if has_ship else "⬜"
            line.append(InlineKeyboardButton(mark, callback_data="noop"))
        rows.append(line)
    return InlineKeyboardMarkup(rows)


async def _send_final_reveal_dm(context, r, uid, result_line: str):
    """به هر دو بازیکن (چه برده چه باخته) «پنلِ دشمن» رو نشون می‌ده: یعنی
    صفحه‌ی خودشون با حمله‌های حریف روش مشخص‌شده - کجاها رو درست زده، کجاها رو
    اشتباه، و کدوم کشتی‌هاش اصلاً پیدا نشدن."""
    is_p1 = uid == r.player1_id
    my_ships = _load(r.player1_ships if is_p1 else r.player2_ships)
    enemy_guesses = _load(r.player2_guesses if is_p1 else r.player1_guesses)
    text = f"{result_line}\n\n🗺 پنلِ دشمن (حمله‌های حریف به صفحه‌ی تو):\n💥 اصابت | ❌ خطا | 🚢 پیدانشده"
    kb = _reveal_keyboard(my_ships, enemy_guesses)
    dm_id = r.player1_dm_message_id if is_p1 else r.player2_dm_message_id
    try:
        if dm_id:
            await context.bot.edit_message_text(chat_id=uid, message_id=dm_id, text=text, reply_markup=kb)
            return
    except Exception:
        pass
    try:
        await context.bot.send_message(uid, text, reply_markup=kb)
    except Exception:
        pass


def _player_label(session, uid):
    u = session.get(db.User, uid)
    return u.display_name() if u else str(uid)


async def _resolve_timeout_forfeit(context, session, r):
    """اگه تو فازِ playing، کسی که نوبتش بود بیش‌ازحد صبر نکنه (حدس نزنه)،
    می‌بازه - حریف برنده‌ی کاملِ pot می‌شه (نه فقط لغو/برگشتِ پول)."""
    loser_id = r.turn_user_id
    winner_id = r.player2_id if loser_id == r.player1_id else r.player1_id
    pot = (r.entry_amount or 0) * 2
    winner = session.get(db.User, winner_id)
    if winner:
        winner.hop_points += pot
    _end_round(r, "resolved")
    session.commit()
    winner_label = _player_label(session, winner_id)
    loser_label = _player_label(session, loser_id)
    text = (
        f"⏳ نبردِ دریایی بینِ {winner_label} و {loser_label} به‌خاطرِ تاخیر تموم شد!\n\n"
        f"😴 {loser_label} تو نوبتِ خودش دیر کرد و حدس نزد.\n"
        f"🏆 برنده: {winner_label}\n"
        f"🎁 جایزه‌ی برنده: {fmt(pot)} 🪙"
    )
    try:
        await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
    except Exception:
        pass
    for uid in (r.player1_id, r.player2_id):
        won = uid == winner_id
        result_line = (f"🎉 بردی! حریف به‌خاطرِ تاخیر نتونست حدس بزنه و {fmt(pot)} 🪙 به حسابت اضافه شد."
                        if won else "⏳ به‌خاطرِ تاخیر (دیر کردی و حدس نزدی) باختی!")
        await _send_final_reveal_dm(context, r, uid, result_line)


async def _finish_round(context, session, r, winner_id, reason: str):
    loser_id = r.player2_id if winner_id == r.player1_id else r.player1_id
    pot = (r.entry_amount or 0) * 2
    winner = session.get(db.User, winner_id)
    if winner:
        winner.hop_points += pot
    _end_round(r, "resolved")

    winner_hits = sum(1 for g in _load(r.player1_guesses if winner_id == r.player1_id else r.player2_guesses) if g[2])
    loser_hits = sum(1 for g in _load(r.player1_guesses if loser_id == r.player1_id else r.player2_guesses) if g[2])
    winner_label = _player_label(session, winner_id)
    loser_label = _player_label(session, loser_id)
    # تو گروه هم برنده هم بازنده رو می‌نویسیم - اینطوری کسی که تازه آنلاین
    # می‌شه هم می‌فهمه بازی بینِ کیا بوده، هم نتیجه رو.
    text = (
        f"🏆 نبردِ دریایی بینِ {winner_label} و {loser_label} تموم شد!\n\n"
        f"🥇 برنده: {winner_label} ({winner_hits} اصابت)\n"
        f"😔 بازنده: {loser_label} ({loser_hits} اصابت)\n"
        f"🎁 جایزه‌ی برنده: {fmt(pot)} 🪙"
    )
    try:
        await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
    except Exception:
        pass
    for uid in (r.player1_id, r.player2_id):
        won = uid == winner_id
        result_line = f"🎉 بردی! {fmt(pot)} 🪙 به حسابت اضافه شد." if won else "😔 باختی."
        await _send_final_reveal_dm(context, r, uid, result_line)


async def _finish_round_by_score(context, session, r):
    p1_hits = sum(1 for g in _load(r.player1_guesses) if g[2])
    p2_hits = sum(1 for g in _load(r.player2_guesses) if g[2])
    if p1_hits == p2_hits:
        await _refund(session, r, "مساوی")
        _end_round(r, "resolved")
        p1_label = _player_label(session, r.player1_id)
        p2_label = _player_label(session, r.player2_id)
        text = (
            f"🤝 نبردِ دریایی بینِ {p1_label} و {p2_label} مساوی شد!\n\n"
            f"هر دو نفر {p1_hits} اصابت داشتن. مبلغِ ورودیِ هر دو برگشت داده شد."
        )
        try:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
        except Exception:
            pass
        for uid in (r.player1_id, r.player2_id):
            await _send_final_reveal_dm(context, r, uid, "🤝 مساوی شد! مبلغِ ورودیت برگشت داده شد.")
        return
    winner_id = r.player1_id if p1_hits > p2_hits else r.player2_id
    await _finish_round(context, session, r, winner_id, reason="more_hits")


# ---------------------------------------------------------------------------
# جاروبِ تایم‌اوت - از jobs.tick_job صدا زده می‌شه
# ---------------------------------------------------------------------------

async def sweep_timeouts(context):
    """دورهایی که تو فازِ لابی/جای‌گذاری بیشتر از ACTION_TIMEOUT_SECONDS بدونِ
    حرکت مونده‌ن، یا خودِ مرحله‌ی setup (نه شروع شده نه لغو، مثلاً کاربر
    پیامش رو پاک کرده و رفته) بیش‌ازحد رها شدن رو لغو می‌کنه و پول‌ها رو
    برمی‌گردونه - چون تا اینجا بازیِ واقعی هنوز شروع نشده، برگشتِ پول به هر دو
    منصفانه‌ست.

    اما اگه بازی وارد فازِ playing شده باشه (هر دو کشتی‌هاشون رو چیدن، دارن
    نوبتی حدس می‌زنن) و کسی که نوبتشه بیش‌ازحد صبر نکنه، دیگه لغو/برگشت نمی‌کنیم
    - همون‌طور که انگار حریف برده، حریف کاملِ pot رو می‌بره (نگاه کن به
    _resolve_timeout_forfeit).

    چون این تابع از داخلِ tick_job (هر ۶۰ ثانیه) صدا زده می‌شه، دقتش حدودِ
    ۶۰-۱۴۰ ثانیه‌ست، نه دقیقاً لحظه‌ای - برای این بازیِ غیرِ حیاتی کافیه.

    بدونِ این جاروب، چون از این به بعد تا وقتی یه بازیِ نیمه‌کاره داشته باشی
    نمی‌تونی بازیِ جدید بسازی/بپیوندی، اگه یه نفر بازی رو رها می‌کرد (یا پیامش
    رو پاک می‌کرد) برای همیشه قفل می‌موند."""
    session = db.get_session()
    try:
        now = datetime.datetime.utcnow()
        action_cutoff = now - datetime.timedelta(seconds=ACTION_TIMEOUT_SECONDS)
        setup_cutoff = now - datetime.timedelta(seconds=SETUP_ABANDON_TIMEOUT_SECONDS)
        stale = (
            session.query(db.BattleshipRound)
            .filter(
                ((db.BattleshipRound.status.in_(("lobby", "placing"))) & (db.BattleshipRound.last_action_at < action_cutoff))
                | ((db.BattleshipRound.status == "setup") & (db.BattleshipRound.created_at < setup_cutoff))
            )
            .all()
        )
        for r in stale:
            await _refund(session, r, "تایم‌اوت")
            _end_round(r, "cancelled")
            text = "⏳ نبردِ دریایی به‌خاطرِ عدمِ فعالیت لغو شد. مبلغِ ورودی (برای هرکی پرداخت کرده بود) برگشت داده شد."
            try:
                if r.group_message_id:
                    await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.group_message_id, text=text)
            except Exception:
                pass
            for uid in (r.player1_id, r.player2_id):
                if not uid:
                    continue
                try:
                    await context.bot.send_message(uid, text)
                except Exception:
                    pass
        if stale:
            session.commit()

        # فازِ playing: بازیِ واقعی شروع شده -> تایم‌اوتِ نوبت = باختِ همون
        # کسی که نوبتش بود، نه لغوِ کلِ بازی
        playing_stale = (
            session.query(db.BattleshipRound)
            .filter(db.BattleshipRound.status == "playing", db.BattleshipRound.last_action_at < action_cutoff)
            .all()
        )
        for r in playing_stale:
            async with _get_round_lock(r.id):
                session.refresh(r)
                if r.status != "playing":
                    continue
                await _resolve_timeout_forfeit(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مسیریابی
# ---------------------------------------------------------------------------

BSHIP_PREFIX_MAP = {
    "bship_new": cb_bship_new,
    "bship_amt_menu": cb_bship_amt_menu,
    "bship_amt_pick": cb_bship_amt_pick,
    "bship_amt_custom": cb_bship_amt_custom,
    "bship_back": cb_bship_back,
    "bship_cancel": cb_bship_cancel,
    "bship_back_to_types": cb_bship_back_to_types,
    "bship_start": cb_bship_start,
    "bship_join": cb_bship_join,
    "bship_place": cb_bship_place,
    "bship_place_confirm": cb_bship_place_confirm,
    "bship_guess": cb_bship_guess,
}


async def bship_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = BSHIP_PREFIX_MAP.get(prefix)
    if handler:
        await handler(update, context)
        return True
    return False
