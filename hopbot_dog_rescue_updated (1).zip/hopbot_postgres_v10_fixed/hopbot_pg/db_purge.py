# -*- coding: utf-8 -*-
"""
پاک‌سازیِ خودکارِ دیتایِ عملیات‌هایِ تمام‌شده.

ایده: وقتی یه عملیات (کازینو، رولت، مافیا، اونو، رأی‌گیریِ شف، سرقت، جنگ، قاچاق،
گروگان‌گیری، قرعه‌کشی، ...) تموم شد، «نتیجه‌ی نهایی» همین الان تو موجودیِ بازیکن
(users.hop_points و بقیه‌ی فیلدهایِ خودِ کاربر) اعمال شده؛ ردیف‌هایِ ریزِ خودِ
عملیات (لابی، بازیکن‌ها، رأی‌ها، وضعیت، لاگِ مرحله‌ها) دیگه به درد نمی‌خورن و فقط
دیتابیس رو بزرگ و کند می‌کنن. این ماژول اون‌ها رو پاک می‌کنه.

چیزی که ممکنه به ردیف‌هایِ تمام‌شده وابسته باشه و باید خراب نشه:
  • ماموریت‌ها (mission_metrics) «تعدادِ بازیِ امروز/این هفته» رو از شمردنِ همین ردیف‌ها
    درمی‌آوردن  ➜ قبل از پاک‌کردن، شمارش تو جدولِ activity_counters خلاصه می‌شه.
  • کول‌داونِ کازینو (آخرین بازیِ تمام‌شده)         ➜ مهلتِ نگه‌داری ≥ کول‌داون + حاشیه.
  • سقفِ روزانه‌ی گروگان‌گیری (Hostage.started_at ≥ شروعِ روز) ➜ ۴۸ ساعت نگه داشته می‌شه.
  • انتقام/ضدِ فارمِ جنگ (war_revenge_hours / war_antifarm_window_hours) ➜ طبقِ تنظیماتِ
    خودِ جنگ + حاشیه نگه داشته می‌شه.
  • دکمه‌هایِ دیرکلیک‌شده روی پنل‌هایِ قدیمی ➜ مهلتِ purge_grace_minutes (پیش‌فرض ۳۰ دقیقه).

اجرا: هر چند دقیقه یه بار از main.py (purge_job)، یا دستی:  python db_purge.py  (فقط گزارش) /
python db_purge.py --run
هیچ‌وقت ردیفِ «در جریان» (lobby / active / marching / pending / open / ...) پاک نمی‌شه؛ فقط
وضعیت‌هایِ پایانی.
"""
import datetime
import json
import logging

from sqlalchemy import and_, or_, func

import db
import heist_db as H
import war_db as W
import account_backup as AB

logger = logging.getLogger(__name__)

BATCH = 400  # حداکثر تعدادِ عملیاتِ تمام‌شده در هر دور برای هر بخش (تراکنشِ کوچیک = قفلِ کوتاه)


# ---------------------------------------------------------------------------
# شمارنده‌هایِ خلاصه (جایگزینِ شمردنِ ردیف‌ها برایِ ماموریت‌ها)
# ---------------------------------------------------------------------------
def bucket_of(ts):
    """بازه‌ی ۱۵دقیقه‌ای (UTC). ۱۵ دقیقه چون همه‌ی منطقه‌هایِ زمانیِ واقعی (حتی +۳:۳۰ و +۵:۴۵)
    مضربِ ۱۵ دقیقه‌ان، پس مرزِ «شروعِ امروزِ» هر کاربر دقیقاً روی مرزِ یه بازه می‌افته."""
    ts = ts or datetime.datetime(1970, 1, 1)
    return ts.replace(minute=(ts.minute // 15) * 15, second=0, microsecond=0)


def counter_sum(session, metric: str, uid: int, since) -> int:
    """جمعِ شمارنده‌هایِ خلاصه‌شده برایِ یه کاربر/معیار از زمانِ since (None = از ابتدا)."""
    q = session.query(func.coalesce(func.sum(db.ActivityCounter.n), 0)).filter(
        db.ActivityCounter.user_id == uid, db.ActivityCounter.metric == metric)
    if since is not None:
        q = q.filter(db.ActivityCounter.bucket >= bucket_of(since))
    return int(q.scalar() or 0)


class _Acc:
    """(user, metric, bucket) -> n   ؛ آخرِ کار یکجا تو activity_counters جمع می‌شه."""

    def __init__(self):
        self.d = {}

    def add(self, metric, uid, ts, n=1):
        if uid is None:
            return
        k = (int(uid), metric, bucket_of(ts))
        self.d[k] = self.d.get(k, 0) + n

    def flush(self, session):
        for (uid, metric, bkt), n in self.d.items():
            row = session.query(db.ActivityCounter).filter_by(user_id=uid, metric=metric, bucket=bkt).first()
            if row is None:
                session.add(db.ActivityCounter(user_id=uid, metric=metric, bucket=bkt, n=n))
            else:
                row.n = (row.n or 0) + n
        session.flush()


# ---------------------------------------------------------------------------
# ابزارهایِ حذف
# ---------------------------------------------------------------------------
def _chunks(seq, n=500):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def _delete_in(session, model, col, ids):
    total = 0
    for part in _chunks(list(ids)):
        total += session.query(model).filter(col.in_(part)).delete(synchronize_session=False)
    return total


def _fetch_in(session, model, col, ids):
    out = []
    for part in _chunks(list(ids)):
        out.extend(session.query(model).filter(col.in_(part)).all())
    return out


def _cfg_f(session, key, default):
    try:
        v = db.cfg_get(session, key)
        return float(v) if v not in (None, "") else default
    except Exception:
        return default


# ---------------------------------------------------------------------------
# تعریفِ هر بخش
# ---------------------------------------------------------------------------
# هر بخش: (اسم، مدلِ اصلی، شرطِ «تمام‌شده و قدیمی» تابعِ cutoff، [(مدلِ فرزند، ستونِ کلید)],
#          تابعِ خلاصه‌ساز(acc, parent, children_by_model))
def _older(model, ts, cutoff, fallback="created_at", extra=datetime.timedelta(minutes=30)):
    """«قدیمی‌تر از cutoff»: اگه ستونِ زمانِ پایان خالیه (ردیف‌هایِ قدیمی/مسیرهایی که ثبتش نکردن)
    از زمانِ ساخت + حاشیه‌ی امن استفاده می‌شه تا این ردیف‌ها تا ابد نمونن."""
    tcol = getattr(model, ts)
    fcol = getattr(model, fallback)
    return or_(and_(tcol.isnot(None), tcol < cutoff),
               and_(tcol.is_(None), fcol < cutoff - extra))


def _terminal(model, cutoff, statuses=("resolved", "cancelled"), ts="ended_at"):
    return and_(model.status.in_(statuses), _older(model, ts, cutoff))


def _roll_players(metric):
    def f(acc, r, ch):
        for pl in ch.get("players", []):
            acc.add(metric, pl.user_id, pl.joined_at)
    return f


def _roll_guess(acc, r, ch):
    if r.status != "cancelled":
        for u in {r.initiator_id, r.setter_id, r.guesser_id}:
            acc.add("guess_played", u, r.created_at)


def _roll_pair(metric, a, b):
    def f(acc, r, ch):
        if r.status == "resolved":
            for u in {getattr(r, a), getattr(r, b)}:
                acc.add(metric, u, r.ended_at)
    return f


def _roll_duel(acc, r, ch):
    if r.winner_id is not None:
        for u in {r.host_id, r.guest_id}:
            acc.add("duel_played", u, r.ended_at)


def _roll_attack(acc, r, ch):
    acc.add("rob_attempts", r.attacker_id, r.created_at)


def _roll_smuggle(acc, r, ch):
    acc.add("smuggle_started", r.user_id, r.started_at)
    if r.status == "success":
        acc.add("smuggle_success", r.user_id, r.ended_at)


def _roll_heist(acc, r, ch):
    for rw in ch.get("rewards", []):
        acc.add("heist_played", rw.user_id, rw.created_at)
        if (rw.hop or 0) > 0:
            acc.add("heist_success", rw.user_id, rw.created_at)


def _roll_war(acc, r, ch):
    acc.add("war_attacks", r.attacker_id, r.created_at)
    if r.outcome == "attacker":
        acc.add("war_wins", r.attacker_id, r.created_at)


def _roll_frontier(acc, r, ch):
    acc.add("frontier_runs", r.user_id, r.created_at)
    if r.outcome == "win":
        acc.add("frontier_wins", r.user_id, r.created_at)
    if r.boss_state_id and r.outcome in ("win",):
        acc.add("frontier_boss_hits", r.user_id, r.created_at)


def _roll_lottery(acc, r, ch):
    seen = set()
    try:
        for p in json.loads(r.participants_json or "[]"):
            pid = p.get("id") if isinstance(p, dict) else p
            if pid is not None and str(pid) not in seen:
                seen.add(str(pid))
                acc.add("lottery_joined", int(pid), r.created_at)
    except (ValueError, TypeError, AttributeError):
        pass


def _sections(session, now):
    grace = datetime.timedelta(minutes=max(1.0, _cfg_f(session, "purge_grace_minutes", 30)))
    cd_min = _cfg_f(session, "casino_cooldown_minutes", 0)
    # کازینو/نبردِ دریایی/رولت: کول‌داونِ بینِ بازی‌ها از ended_at آخرین بازیِ resolved خونده می‌شه
    casino_grace = max(grace, datetime.timedelta(minutes=cd_min + 10))
    c_cut = now - casino_grace
    g_cut = now - grace
    war_hours = max(_cfg_f(session, "war_revenge_hours", 24), _cfg_f(session, "war_antifarm_window_hours", 24), 24)
    war_cut = now - datetime.timedelta(hours=war_hours + 2)
    hostage_cut = now - datetime.timedelta(hours=48)  # سقفِ روزانه از شروعِ روز (با اختلافِ منطقه‌ی زمانی) می‌خونه

    S = []
    # ---- بازی‌هایِ کازینو ----
    S.append(("casino", db.CasinoRound, _terminal(db.CasinoRound, c_cut),
              [("players", db.CasinoPlayer, db.CasinoPlayer.round_id)], _roll_players("casino_played")))
    S.append(("roulette", db.RouletteRound, _terminal(db.RouletteRound, c_cut),
              [("players", db.RoulettePlayer, db.RoulettePlayer.round_id)], _roll_players("roulette_played")))
    S.append(("battleship", db.BattleshipRound, _terminal(db.BattleshipRound, c_cut), [],
              _roll_pair("ship_played", "player1_id", "player2_id")))
    S.append(("uno", db.UnoRound, _terminal(db.UnoRound, g_cut),
              [("players", db.UnoPlayer, db.UnoPlayer.round_id)], _roll_players("uno_played")))
    S.append(("mafia", db.MafiaRound, _terminal(db.MafiaRound, g_cut),
              [("players", db.MafiaPlayer, db.MafiaPlayer.round_id)], _roll_players("mafia_played")))
    S.append(("guessnum", db.GuessNumberRound, _terminal(db.GuessNumberRound, g_cut), [], _roll_guess))
    S.append(("mastermind", db.MastermindRound, _terminal(db.MastermindRound, g_cut), [],
              _roll_pair("mind_played", "player1_id", "player2_id")))
    S.append(("duel", db.DuelLobby, _terminal(db.DuelLobby, g_cut, ("finished", "cancelled")), [], _roll_duel))
    # ---- رأی‌گیریِ شف (حداکثر ۱ ساعت باز می‌مونه؛ شفِ منتخب تو group_chefs می‌مونه) ----
    S.append(("chef_election", db.ChefElection,
              and_(db.ChefElection.status == "closed", db.ChefElection.closes_at < g_cut),
              [("votes", db.ChefVote, db.ChefVote.election_id),
               ("cands", db.ChefCandidate, db.ChefCandidate.election_id)], None))
    # ---- دزدی/گروگان/قاچاق/سرقتِ تیمی/جنگ/قرعه‌کشی ----
    S.append(("attack", db.AttackSession,
              and_(db.AttackSession.status.in_(("attacker_failed", "attacker_killed", "hostage_success", "cancelled")),
                   db.AttackSession.created_at < g_cut),
              [], _roll_attack))
    S.append(("hostage", db.Hostage,
              and_(db.Hostage.status.in_(("escaped", "freed_paid", "released")), db.Hostage.started_at < hostage_cut),
              [], None))
    S.append(("smuggling", db.SmugglingOperation,
              and_(db.SmugglingOperation.status.in_(("success", "failed", "cancelled")),
                   _older(db.SmugglingOperation, "ended_at", g_cut, "started_at")),
              [("stages", db.SmugglingOperationStage, db.SmugglingOperationStage.operation_id)], _roll_smuggle))
    S.append(("heist", H.HeistOperation,
              and_(H.HeistOperation.status.in_(("SETTLED", "CANCELLED")),
                   or_(and_(H.HeistOperation.settled_at.isnot(None), H.HeistOperation.settled_at < g_cut),
                       and_(H.HeistOperation.settled_at.is_(None), H.HeistOperation.created_at < now - datetime.timedelta(hours=6)))),
              [("items", H.HeistOpItem, H.HeistOpItem.op_id), ("members", H.HeistOpMember, H.HeistOpMember.op_id),
               ("events", H.HeistEvent, H.HeistEvent.op_id), ("rewards", H.HeistReward, H.HeistReward.op_id),
               ("panels", H.HeistPanel, H.HeistPanel.op_id)], _roll_heist))
    S.append(("war_battle", W.WarBattle,
              and_(W.WarBattle.status == "resolved", W.WarBattle.clan_war_id.is_(None),
                   _older(W.WarBattle, "resolved_at", war_cut)),
              [], _roll_war))
    try:
        import frontier_db as FR
        # نتیجه‌ی عملیات‌های تمام‌شده‌ی Frontier بعد از ۳۶ ساعت به شمارنده‌ی خلاصه تبدیل و پاک می‌شه (سقف‌ها/فصل از جدول‌های دیگه می‌خونن)
        fr_cut = now - datetime.timedelta(hours=36)
        S.append(("frontier_run", FR.FrontierRun,
                  and_(FR.FrontierRun.status.in_(("resolved", "cancelled")), _older(FR.FrontierRun, "resolved_at", fr_cut)),
                  [], _roll_frontier))
    except Exception:
        pass
    S.append(("lottery", db.LotteryEvent,
              and_(db.LotteryEvent.is_active == False,  # noqa: E712
                   _older(db.LotteryEvent, "finished_at", g_cut)),
              [("msgs", db.LotteryBroadcastMessage, db.LotteryBroadcastMessage.event_id)], _roll_lottery))
    return S


def _purge_section(session, spec, limit, dry):
    name, P, where, children, roller = spec
    parents = session.query(P).filter(where).order_by(P.id).limit(limit).all()
    if not parents:
        return 0, 0
    ids = [p.id for p in parents]
    kids = {}
    for key, M, col in children:
        kids[key] = _fetch_in(session, M, col, ids)
    child_n = sum(len(v) for v in kids.values())
    if dry:
        return len(parents), child_n
    if roller is not None:
        acc = _Acc()
        for p in parents:
            ch = {k: [x for x in v if getattr(x, [c for kk, M, c in children if kk == k][0].key) == p.id]
                  for k, v in kids.items()}
            roller(acc, p, ch)
        acc.flush(session)
    # فرزندها (به ترتیبِ وابستگی: رأی قبل از کاندیدا) بعد خودِ عملیات
    for key, M, col in children:
        _delete_in(session, M, col, ids)
    _delete_in(session, P, P.id, ids)
    session.commit()
    return len(parents), child_n


def _purge_misc(session, now, dry):
    """جدول‌هایِ کمکیِ منقضی‌شده (بدونِ نیاز به خلاصه‌سازی)."""
    out = {}
    g_cut = now - datetime.timedelta(minutes=max(1.0, _cfg_f(session, "purge_grace_minutes", 30)))
    log_cut = now - datetime.timedelta(days=max(1.0, _cfg_f(session, "purge_log_days", 14)))
    today = now.date()
    jobs = [
        ("war_confirms", W.WarConfirm,
         or_(W.WarConfirm.used == True, W.WarConfirm.expires_at < now - datetime.timedelta(hours=1))),  # noqa: E712
        ("email_codes", AB.EmailCode,
         and_(AB.EmailCode.status != "pending", AB.EmailCode.created_at < now - datetime.timedelta(days=1))),
        ("email_codes_expired", AB.EmailCode, AB.EmailCode.expires_at < now - datetime.timedelta(days=1)),
        ("pending_hostage_confirms", db.PendingHostageConfirm,
         db.PendingHostageConfirm.created_at < now - datetime.timedelta(hours=1)),
        ("heist_cooldowns", H.HeistCooldown, H.HeistCooldown.until < now - datetime.timedelta(hours=1)),
        ("heist_panels_orphan", H.HeistPanel,
         and_(H.HeistPanel.op_id.is_(None), H.HeistPanel.created_at < now - datetime.timedelta(days=3))),
        ("smuggling_daily_usage", db.SmugglingDailyUsage,
         db.SmugglingDailyUsage.usage_date < (today - datetime.timedelta(days=3)).strftime("%Y-%m-%d")),
        ("war_audit_logs", W.WarAudit, W.WarAudit.created_at < log_cut),
        ("war_reward_counters", W.WarRewardCounter,
         W.WarRewardCounter.day < (today - datetime.timedelta(days=3)).strftime("%Y-%m-%d")),
        ("account_migration_snapshots", AB.AccountMigrationSnapshot,
         AB.AccountMigrationSnapshot.created_at < now - datetime.timedelta(days=AB.SNAPSHOT_KEEP_DAYS)),
    ]
    for name, M, where in jobs:
        try:
            q = session.query(M).filter(where)
            if dry:
                n = q.count()
            else:
                n = q.delete(synchronize_session=False)
                session.commit()
            if n:
                out[name] = n
        except Exception:
            session.rollback()
            logger.exception("purge misc %s", name)
    return out


# ---------------------------------------------------------------------------
# ماموریت‌هایِ هاپویی: شمارنده‌هایِ activity_counters
# ---------------------------------------------------------------------------
EPOCH = datetime.datetime(1970, 1, 1)


def purge_mission_counters(session, now, dry=False) -> dict:
    """
    قانون (فقط وقتی «تموم شد/پاداشش گرفته شد» پاک می‌شه):
      • روزانه/هفتگی: شمارنده‌هایِ بازه‌هایِ تموم‌شده (قدیمی‌تر از شروعِ هفته‌ی جاری − ۱ روز حاشیه) پاک می‌شن.
        تا وقتی روز/هفته تموم نشده می‌مونن، چون چند ماموریتِ هم‌معیار ممکنه هم‌زمان وجود داشته باشه.
      • «یک‌بار» (مسیرِ تازه‌کار): این ماموریت‌ها کلِ تاریخچه رو می‌شمرن (since=None). برایِ همین قبل از
        پاک‌شدنِ جزئیات، مجموعِ کل تو یه ردیفِ واحد (bucket=1970) نگه داشته می‌شه؛ و به محضِ اینکه کاربر
        پاداشِ همه‌ی ماموریت‌هایِ «یک‌بار»ِ اون معیار رو گرفت، همون ردیفِ مجموع هم پاک می‌شه.
    """
    import mission_engine as ME
    import mission_db as MD
    tz = int(_cfg_f(session, "ct_tz_minutes", 210))
    wk = ME.period_start_utc("weekly", now, tz)
    cutoff = bucket_of(wk - datetime.timedelta(days=1))

    by_metric = {}
    for d in session.query(MD.MissionDef).filter(MD.MissionDef.period == "once",
                                                 MD.MissionDef.deleted == False).all():  # noqa: E712
        by_metric.setdefault(d.metric, []).append(d.id)

    claimed_cache = {}

    def all_once_claimed(uid, metric):
        ids = by_metric.get(metric)
        if not ids:
            return True
        if uid not in claimed_cache:
            claimed_cache[uid] = {c.mission_id for c in session.query(MD.MissionClaim).filter_by(
                user_id=uid, period_key="once")}
        return all(i in claimed_cache[uid] for i in ids)

    old = (session.query(db.ActivityCounter)
           .filter(db.ActivityCounter.bucket < cutoff, db.ActivityCounter.bucket > EPOCH)
           .order_by(db.ActivityCounter.id).limit(3000).all())
    stale_totals = [r for r in session.query(db.ActivityCounter).filter(db.ActivityCounter.bucket == EPOCH).all()
                    if all_once_claimed(r.user_id, r.metric)]
    out = {"detail_rows": len(old), "released_totals": len(stale_totals)}
    if dry:
        return out
    collapsed = {}
    for r in old:
        if not all_once_claimed(r.user_id, r.metric):
            collapsed[(r.user_id, r.metric)] = collapsed.get((r.user_id, r.metric), 0) + (r.n or 0)
        session.delete(r)
    session.flush()
    for (uid, metric), n in collapsed.items():
        row = session.query(db.ActivityCounter).filter_by(user_id=uid, metric=metric, bucket=EPOCH).first()
        if row is None:
            session.add(db.ActivityCounter(user_id=uid, metric=metric, bucket=EPOCH, n=n))
        else:
            row.n = (row.n or 0) + n
    for r in stale_totals:
        session.delete(r)
    session.commit()
    return out


# ---------------------------------------------------------------------------
# ماموریت‌هایِ جنگ: war_quest_progress / war_metrics
# ---------------------------------------------------------------------------
def purge_war_quests(session, now, dry=False) -> dict:
    """
    • فقط ردیف‌هایِ «بازه‌ی تموم‌شده»ی روزانه/هفتگی (period ≠ بازه‌ی جاری) بررسی می‌شن.
    • ردیفِ نگرفته (claimed=False) از بازه‌ی تموم‌شده دیگه قابلِ دریافت نیست ➜ پاک.
    • ردیفِ گرفته‌شده ➜ پاک، مگر اینکه کلیدِ اون ماموریت تو یه قانونِ بازشدن (req_quest) استفاده بشه؛
      چون quest_done() فقط با وجودِ یه ردیفِ claimed=True می‌فهمه ماموریت انجام شده.
    • ماموریتِ ویژه (special / once) و ردیف‌هایِ بازه‌ی جاری هیچ‌وقت دست‌ نمی‌خورن.
    • متریک‌هایِ هفتگیِ wk_attacks_<هفته> قدیمی‌تر از ۲ هفته پاک می‌شن (جایی خونده نمی‌شن).
    """
    import war_svc
    gating = {r[0] for r in session.query(W.WarUnlockRule.req_quest).filter(
        W.WarUnlockRule.req_quest.isnot(None), W.WarUnlockRule.req_quest != "").all()}
    defs = {d.key: d.kind for d in session.query(W.WarQuestDef).all()}
    cur = {"daily": war_svc.period_key("daily"), "weekly": war_svc.period_key("weekly")}
    ids = []
    for pr in session.query(W.WarQuestProgress).filter(W.WarQuestProgress.period != "once").all():
        kind = defs.get(pr.quest_key)
        if kind not in ("daily", "weekly") or pr.period == cur[kind]:
            continue
        if pr.claimed and pr.quest_key in gating:
            continue
        ids.append(pr.id)
    y, w, _ = now.isocalendar()
    keep = {f"wk_attacks_{y}-W{w:02d}"}
    prev = now - datetime.timedelta(days=7)
    y2, w2, _ = prev.isocalendar()
    keep.add(f"wk_attacks_{y2}-W{w2:02d}")
    mq = session.query(W.WarMetric).filter(W.WarMetric.metric.like("wk_attacks_%"),
                                           W.WarMetric.metric.notin_(keep))
    out = {"quest_rows": len(ids), "weekly_metrics": mq.count()}
    if dry:
        return out
    _delete_in(session, W.WarQuestProgress, W.WarQuestProgress.id, ids)
    mq.delete(synchronize_session=False)
    session.commit()
    return out


def run_purge(session=None, dry_run=False, now=None, limit=BATCH) -> dict:
    """یک دورِ پاک‌سازی. خروجی: {بخش: (تعدادِ عملیاتِ پاک‌شده, تعدادِ ردیفِ فرزندِ پاک‌شده)}.
    اگه purge_enabled=0 باشه هیچ کاری نمی‌کنه (به‌جز dry_run)."""
    own = session is None
    session = session or db.get_session()
    try:
        if not dry_run and _cfg_f(session, "purge_enabled", 1) <= 0:
            return {}
        now = now or datetime.datetime.utcnow()
        report = {}
        for spec in _sections(session, now):
            try:
                n, kids = _purge_section(session, spec, limit, dry_run)
            except Exception:
                session.rollback()
                logger.exception("purge section %s failed", spec[0])
                continue
            if n:
                report[spec[0]] = (n, kids)
        misc = _purge_misc(session, now, dry_run)
        for fn in (purge_mission_counters, purge_war_quests):
            try:
                r = fn(session, now, dry_run)
                misc.update({f"{fn.__name__}.{k}": v for k, v in r.items() if v})
            except Exception:
                session.rollback()
                logger.exception("purge %s failed", fn.__name__)
        if misc:
            report["misc"] = misc
        return report
    finally:
        if own:
            session.close()


def run_purge_all(dry_run=False, now=None, max_rounds=200) -> dict:
    """تا وقتی چیزی برایِ پاک‌کردن مونده تکرار می‌کنه (برایِ بارِ اولِ پاک‌سازیِ دیتای قدیمی)."""
    total = {}
    for _ in range(max_rounds):
        rep = run_purge(dry_run=dry_run, now=now)
        if not rep:
            break
        for k, v in rep.items():
            if k == "misc":
                m = total.setdefault("misc", {})
                for kk, vv in v.items():
                    m[kk] = m.get(kk, 0) + vv
            else:
                a, b = total.get(k, (0, 0))
                total[k] = (a + v[0], b + v[1])
        if dry_run:  # dry-run چیزی پاک نمی‌کنه؛ تکرارش بی‌معنیه
            break
    return total


# ---------------------------------------------------------------------------
# job برایِ main.py (python-telegram-bot JobQueue)
# ---------------------------------------------------------------------------
async def purge_job(context):
    import asyncio
    try:
        rep = await asyncio.to_thread(run_purge)
        if rep:
            logger.info("purge: %s", rep)
    except Exception:
        logger.exception("purge_job")


if __name__ == "__main__":
    import sys
    logging.basicConfig(level=logging.INFO)
    run = "--run" in sys.argv
    rep = run_purge_all(dry_run=not run)
    print(("پاک شد:" if run else "گزارشِ آزمایشی (چیزی پاک نشد):"))
    for k, v in sorted(rep.items()):
        print(" ", k, v)
    if not rep:
        print("  چیزی برایِ پاک‌کردن نبود.")
