# -*- coding: utf-8 -*-
"""
سرآشپز و غذای سگ 🍖 - سیستمِ انتخاباتِ سرآشپزِ هر گروه («رای گیری هاپویی») و
مارکتِ غذای سگ («مارکت هاپویی»).

نکته‌ی مهم دربابِ قفلِ مالکیت: مثلِ همه‌ی پنل‌های دیگه‌ی بات (هاپ‌منیج، گوشی
هاپویی، کازینو هاپویی و...)، هر پیامی که اینجا فرستاده می‌شه فقط مالِ همون
کسیه که دستورِ مربوطه رو تایپ کرده (owner_id که تو callback_data قفل شده) و
قفلِ مالکیت داره (_verify_panel_owner):
- صفحه‌ی انتخابات (کاندیدشدن/رای‌دادن/درخواستِ برکناری): هر کسی «رای گیری
  هاپویی» رو بزنه، نسخه‌ی خودش از این پیام رو می‌گیره و فقط خودش می‌تونه رو
  دکمه‌های همون پیام کلیک کنه؛ بقیه باید خودشون همون دستور رو بفرستن تا نسخه‌ی
  خودشون رو داشته باشن. (رای‌ای که ثبت می‌شه طبیعتاً بازم مالِ همون owner_idه،
  چون کسِ دیگه‌ای اصلاً نمی‌تونه رو این دکمه‌ها کلیک کنه.)
- صفحه‌ی «شخصیِ» سرآشپز (تهیه‌ی غذا/تنظیمِ مالیات) و «شخصیِ» خریدِ غذا: از قبل
  همین‌طور قفل‌شده بودن.
"""
import datetime

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationHandlerStop

import db
import economy
from handlers import fmt, send_response, _verify_panel_owner, ask_for_input, ask_for_input_reply, is_reply_to_prompt

CHEF_MAX_COOK_QTY = 20  # حداکثرِ تعدادِ غذا در یک درخواستِ پخت‌وپزِ سرآشپز


# ---------------------------------------------------------------------------
# کمکی‌ها
# ---------------------------------------------------------------------------

def _active_chef(session, chat_id):
    chef = session.query(db.GroupChef).filter_by(chat_id=chat_id).first()
    if chef and chef.term_ends_at > datetime.datetime.utcnow():
        return chef
    return None


def _format_remaining(delta: datetime.timedelta) -> str:
    total_seconds = max(0, int(delta.total_seconds()))
    days, rem = divmod(total_seconds, 86400)
    hours, rem = divmod(rem, 3600)
    minutes = rem // 60
    parts = []
    if days:
        parts.append(f"{days} روز")
    if hours:
        parts.append(f"{hours} ساعت")
    if minutes or not parts:
        parts.append(f"{minutes} دقیقه")
    return " و ".join(parts)


# ---------------------------------------------------------------------------
# انتخاباتِ سرآشپز («رای گیری هاپویی»)
# ---------------------------------------------------------------------------

async def handle_election_trigger(update, context):
    chat_id = update.effective_chat.id
    session = db.get_session()
    try:
        chef = _active_chef(session, chat_id)
        if chef:
            await _show_active_chef_status(update, context, session, chef)
            return

        election = session.query(db.ChefElection).filter_by(chat_id=chat_id, status="open").first()
        if not election:
            hours = db.cfg_get_float(session, "chef_election_hours")
            election = db.ChefElection(
                chat_id=chat_id, status="open",
                closes_at=datetime.datetime.utcnow() + datetime.timedelta(hours=hours),
            )
            session.add(election)
            session.commit()
        await _show_election(update, context, session, election)
    finally:
        session.close()


async def _show_active_chef_status(update, context, session, chef):
    owner_id = update.effective_user.id
    user = session.get(db.User, chef.user_id)
    name = user.display_name() if user else str(chef.user_id)
    remain = chef.term_ends_at - datetime.datetime.utcnow()
    already_voted = session.query(db.ChefRecallVote).filter_by(
        chat_id=chef.chat_id, chef_user_id=chef.user_id, voter_user_id=update.effective_user.id
    ).first()
    recall_count = session.query(db.ChefRecallVote).filter_by(chat_id=chef.chat_id, chef_user_id=chef.user_id).count()
    needed = db.cfg_get_int(session, "chef_recall_votes_needed")
    rows = []
    if not already_voted:
        rows.append([InlineKeyboardButton("🚫 درخواستِ برکناری", callback_data=f"chef_recall:{chef.chat_id}:{chef.user_id}:{owner_id}")])
    text = (
        f"👨‍🍳 سرآشپزِ فعلیِ این گروه: {name}\n"
        f"💰 مالیات: {fmt(chef.tax_pct)}٪\n"
        f"⏳ زمانِ باقی‌مونده تا پایانِ دوره: {_format_remaining(remain)}\n\n"
        f"🚫 رای‌هایِ درخواستِ برکناری: {recall_count}/{needed}"
    )
    if already_voted:
        text += "\n\n✅ قبلا برای برکناریِ همین سرآشپز رای دادی."
    await send_response(update, text, InlineKeyboardMarkup(rows) if rows else None)


async def cb_chef_recall(update, context):
    q = update.callback_query
    _, chat_id, chef_user_id, owner_id = q.data.split(":")
    chat_id, chef_user_id, owner_id = int(chat_id), int(chef_user_id), int(owner_id)
    # این پیام مثلِ بقیه‌ی پنل‌های شخصی، مالِ همون کسیه که «رای گیری هاپویی» رو
    # تایپ کرده (owner_id) - بقیه باید خودشون همون دستور رو بزنن تا نسخه‌ی
    # خودشون رو داشته باشن.
    if not await _verify_panel_owner(update, owner_id):
        return
    if update.effective_chat.id != chat_id:
        await q.answer("این دکمه مالِ این گروه نیست.", show_alert=True)
        return
    session = db.get_session()
    try:
        chef = _active_chef(session, chat_id)
        if not chef or chef.user_id != chef_user_id:
            await q.answer("این سرآشپز دیگه فعال نیست.", show_alert=True)
            return
        exists = session.query(db.ChefRecallVote).filter_by(
            chat_id=chat_id, chef_user_id=chef_user_id, voter_user_id=update.effective_user.id
        ).first()
        if exists:
            await q.answer("قبلا رای دادی ✅", show_alert=True)
            return
        session.add(db.ChefRecallVote(chat_id=chat_id, chef_user_id=chef_user_id, voter_user_id=update.effective_user.id))
        session.commit()
        recall_count = session.query(db.ChefRecallVote).filter_by(chat_id=chat_id, chef_user_id=chef_user_id).count()
        needed = db.cfg_get_int(session, "chef_recall_votes_needed")
        if recall_count >= needed:
            chef_name_user = session.get(db.User, chef_user_id)
            chef_name = chef_name_user.display_name() if chef_name_user else str(chef_user_id)
            _clear_market_and_refund(session, chef)
            session.delete(chef)
            session.query(db.ChefRecallVote).filter_by(chat_id=chat_id, chef_user_id=chef_user_id).delete()
            session.commit()
            await q.answer("🚫 برکنار شد!")
            await context.bot.send_message(
                chat_id,
                f"🚫 سرآشپز {chef_name} با رای‌گیریِ اعضای گروه برکنار شد!\n"
                "برای شروعِ انتخاباتِ جدید، «رای گیری هاپویی» رو بنویس.",
            )
        else:
            await q.answer(f"✅ رایت ثبت شد ({recall_count}/{needed})")
            await _show_active_chef_status(update, context, session, chef)
    finally:
        session.close()


async def _show_election(update, context, session, election):
    if election.closes_at and election.closes_at <= datetime.datetime.utcnow():
        await _close_election(context, session, election)
        session.commit()
        await send_response(update, "⌛️ این دوره‌ی انتخابات تموم شد؛ نتیجه اعلام شد.", None)
        return

    owner_id = update.effective_user.id
    candidates = session.query(db.ChefCandidate).filter_by(election_id=election.id).all()
    max_candidates = db.cfg_get_int(session, "chef_max_candidates")
    already_candidate = any(c.user_id == update.effective_user.id for c in candidates)
    already_voted = session.query(db.ChefVote).filter_by(
        election_id=election.id, user_id=update.effective_user.id
    ).first()

    rows = []
    if not already_candidate and len(candidates) < max_candidates:
        rows.append([InlineKeyboardButton("🙋 کاندید شدن", callback_data=f"chef_candidate_ask:{election.id}:{owner_id}")])
    if not already_voted:
        for c in candidates:
            user = session.get(db.User, c.user_id)
            name = user.display_name() if user else str(c.user_id)
            rows.append([InlineKeyboardButton(f"🗳 رای به {name}", callback_data=f"chef_vote:{c.id}:{election.id}:{owner_id}")])

    remain = election.closes_at - datetime.datetime.utcnow()
    lines = [
        "🗳 انتخاباتِ سرآشپزِ این گروه\n",
        f"👥 تعدادِ کاندیدها: {len(candidates)}/{max_candidates}",
        f"⏳ تا پایانِ رای‌گیری: {_format_remaining(remain)}\n",
    ]
    if candidates:
        for c in candidates:
            user = session.get(db.User, c.user_id)
            name = user.display_name() if user else str(c.user_id)
            lines.append(f"• {name} — {c.votes} رای" + (f"\n  «{c.slogan}»" if c.slogan else ""))
    else:
        lines.append("هنوز کسی کاندید نشده.")
    if already_voted:
        lines.append("\n✅ قبلا رای دادی.")

    await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows) if rows else None)


async def cb_chef_candidate_ask(update, context):
    _, election_id, owner_id = update.callback_query.data.split(":")
    election_id, owner_id = int(election_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        election = session.get(db.ChefElection, election_id)
        if not election or election.status != "open":
            await update.callback_query.answer("این انتخابات دیگه فعال نیست.", show_alert=True)
            return
        max_candidates = db.cfg_get_int(session, "chef_max_candidates")
        count = session.query(db.ChefCandidate).filter_by(election_id=election_id).count()
        if count >= max_candidates:
            await update.callback_query.answer("ظرفیتِ کاندیدها پر شده.", show_alert=True)
            return
        exists = session.query(db.ChefCandidate).filter_by(
            election_id=election_id, user_id=update.effective_user.id
        ).first()
        if exists:
            await update.callback_query.answer("قبلا کاندید شدی ✅", show_alert=True)
            return
    finally:
        session.close()
    await ask_for_input(update, context, "📝 شعار/سخنرانیِ انتخاباتیت رو بفرست (یا فقط یه پیامِ کوتاه، حتی خالی با یه نقطه):", {"type": "candidate_slogan", "election_id": election_id}, "chef_awaiting")


async def cb_chef_vote(update, context):
    q = update.callback_query
    _, candidate_id, election_id, owner_id = q.data.split(":")
    candidate_id, election_id, owner_id = int(candidate_id), int(election_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        election = session.get(db.ChefElection, election_id)
        candidate = session.get(db.ChefCandidate, candidate_id)
        if not election or election.status != "open" or not candidate:
            await q.answer("این انتخابات دیگه فعال نیست.", show_alert=True)
            return
        exists = session.query(db.ChefVote).filter_by(election_id=election_id, user_id=update.effective_user.id).first()
        if exists:
            await q.answer("قبلا رای دادی ✅", show_alert=True)
            return
        if candidate.user_id == update.effective_user.id:
            await q.answer("نمی‌تونی به خودت رای بدی!", show_alert=True)
            return
        session.add(db.ChefVote(election_id=election_id, candidate_id=candidate_id, user_id=update.effective_user.id))
        candidate.votes += 1
        session.commit()
        await q.answer("✅ رایت ثبت شد!")
        await _show_election(update, context, session, election)
    finally:
        session.close()


async def _close_election(context, session, election):
    election.status = "closed"
    candidates = session.query(db.ChefCandidate).filter_by(election_id=election.id).order_by(db.ChefCandidate.votes.desc()).all()
    if not candidates or candidates[0].votes == 0:
        try:
            await context.bot.send_message(election.chat_id, "🗳 انتخاباتِ سرآشپز بدونِ برنده تموم شد (رایی ثبت نشد).")
        except Exception:
            pass
        return
    winner = candidates[0]
    term_days = db.cfg_get_float(session, "chef_term_days")
    chef = db.GroupChef(
        chat_id=election.chat_id, user_id=winner.user_id, tax_pct=0,
        term_started_at=datetime.datetime.utcnow(),
        term_ends_at=datetime.datetime.utcnow() + datetime.timedelta(days=term_days),
    )
    session.add(chef)
    user = session.get(db.User, winner.user_id)
    name = user.display_name() if user else str(winner.user_id)
    try:
        await context.bot.send_message(
            election.chat_id,
            f"🎉👨‍🍳 {name} با {winner.votes} رای، سرآشپزِ جدیدِ این گروه شد! "
            f"برای {int(term_days)} روز مسئولِ تامینِ غذای سگ‌های گروهه.",
        )
    except Exception:
        pass


# ---------------------------------------------------------------------------
# مارکتِ غذای سگ («مارکت هاپویی»)
# ---------------------------------------------------------------------------

def _clear_market_and_refund(session, chef):
    """پایانِ دورهٔ سرآشپز (چه با تمومِ‌شدنِ زمان، چه با برکناری): برای تمامِ
    غذاهایی که فروش نرفته و تو مارکتِ هاپویی باقی مونده (چه آماده چه هنوز درحالِ
    آماده‌سازی)، ۹۵٪ از قیمتِ اصلیِ همون غذا (بدونِ مالیاتِ سرآشپز) × تعدادِ
    باقی‌مونده به سرآشپزِ قبلی برگردونده می‌شه؛ بعدش مارکتِ هاپویی کاملاً و
    بدونِ هیچ موجودی‌ای خالی می‌شه تا سرآشپزِ بعدی خودش از صفر تأمینش کنه."""
    stocks = session.query(db.GroupFoodStock).filter_by(chat_id=chef.chat_id).all()
    refund_total = 0.0
    for s in stocks:
        if s.quantity and s.quantity > 0:
            food = session.get(db.DogFood, s.food_id)
            if food:
                refund_total += food.price * s.quantity * 0.95
        session.delete(s)
    if refund_total > 0:
        chef_user = session.get(db.User, chef.user_id)
        if chef_user:
            chef_user.hop_points += refund_total
    return refund_total


async def handle_market_trigger(update, context):
    chat_id = update.effective_chat.id
    session = db.get_session()
    try:
        chef = _active_chef(session, chat_id)
        if chef and chef.user_id == update.effective_user.id:
            await _show_chef_panel(update, context, session, chef)
        else:
            await _show_food_market(update, context, session, chat_id)
    finally:
        session.close()


async def cb_chef_panel(update, context):
    _, chat_id, owner_id = update.callback_query.data.split(":")
    chat_id, owner_id = int(chat_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        chef = _active_chef(session, chat_id)
        if not chef or chef.user_id != owner_id:
            await send_response(update, "❌ الان سرآشپزِ این گروه نیستی.", None)
            return
        await _show_chef_panel(update, context, session, chef)
    finally:
        session.close()


async def cb_chef_buy_menu(update, context):
    """سرآشپز هم باید بتونه غذا برای سگِ خودش بخره، نه فقط تهیه‌ش کنه برای بقیه -
    این دکمه از پنلِ سرآشپز، همون صفحه‌ی خریدی که بقیه‌ی اعضا می‌بینن رو باز می‌کنه."""
    _, chat_id, owner_id = update.callback_query.data.split(":")
    chat_id, owner_id = int(chat_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        await _show_food_market(update, context, session, chat_id)
    finally:
        session.close()


async def _show_chef_panel(update, context, session, chef):
    foods = session.query(db.DogFood).filter_by(is_active=True).all()
    rows = []
    for f in foods:
        rows.append([InlineKeyboardButton(f"🍖 تهیه‌ی {f.name} ({fmt(f.price)}🪙/واحد)", callback_data=f"chef_prepare_ask:{chef.chat_id}:{f.id}:{chef.user_id}")])
    rows.append([InlineKeyboardButton(f"💰 تنظیمِ مالیات (فعلا {fmt(chef.tax_pct)}٪)", callback_data=f"chef_settax_ask:{chef.chat_id}:{chef.user_id}")])
    rows.append([InlineKeyboardButton("🛒 خریدِ غذا برای خودم", callback_data=f"chef_buy_menu:{chef.chat_id}:{chef.user_id}")])

    stock = session.query(db.GroupFoodStock).filter_by(chat_id=chef.chat_id).all()
    lines = ["👨‍🍳 پنلِ سرآشپز\n"]
    if not foods:
        lines.append("هنوز مالک هیچ نوع غذایی تعریف نکرده.")
    if stock:
        lines.append("📦 موجودیِ فعلی:")
        nowt = datetime.datetime.utcnow()
        for s in stock:
            if s.quantity <= 0:
                continue
            food = session.get(db.DogFood, s.food_id)
            fname = food.name if food else "?"
            status = "" if (s.ready_at and s.ready_at <= nowt) else f" (آماده تا {s.ready_at.strftime('%H:%M')})"
            lines.append(f"• {fname}: {s.quantity} واحد{status}")
    await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def cb_chef_prepare_ask(update, context):
    _, chat_id, food_id, owner_id = update.callback_query.data.split(":")
    chat_id, food_id, owner_id = int(chat_id), int(food_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        chef = _active_chef(session, chat_id)
        if not chef or chef.user_id != owner_id:
            await send_response(update, "❌ الان سرآشپزِ این گروه نیستی.", None)
            return
    finally:
        session.close()
    await ask_for_input(update, context, "🔢 چند واحد می‌خوای تهیه کنی؟ عدد رو بفرست.", {"type": "prepare_qty", "chat_id": chat_id, "food_id": food_id}, "chef_awaiting")


async def cb_chef_settax_ask(update, context):
    _, chat_id, owner_id = update.callback_query.data.split(":")
    chat_id, owner_id = int(chat_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        max_tax = db.cfg_get_int(session, "chef_max_tax_pct")
    finally:
        session.close()
    await ask_for_input(update, context, f"💰 مالیات رو چند درصد بذارم؟ (بینِ ۰ تا {max_tax}):", {"type": "settax", "chat_id": chat_id}, "chef_awaiting")


async def _show_food_market(update, context, session, chat_id):
    nowt = datetime.datetime.utcnow()
    stock = (
        session.query(db.GroupFoodStock)
        .filter(db.GroupFoodStock.chat_id == chat_id, db.GroupFoodStock.quantity > 0, db.GroupFoodStock.ready_at <= nowt)
        .all()
    )
    chef = _active_chef(session, chat_id)
    tax_pct = chef.tax_pct if chef else 0
    owner_id = update.effective_user.id

    if not stock:
        text = "🛒 مارکتِ هاپویی\n\nفعلا هیچ غذایی موجود نیست؛ منتظر بمون تا سرآشپزِ گروه تهیه کنه."
        await send_response(update, text, None)
        return

    # جلوگیری از دکمه‌ی تکراری: اگه یه غذا چند ردیفِ موجودیِ جدا داشته باشه
    # (مثلاً چندبار تهیه شده)، باید فقط یه دکمه‌ی واحد براش نشون داده بشه، نه
    # به‌ازای هر ردیف یه دکمه.
    totals_by_food = {}
    for s in stock:
        totals_by_food[s.food_id] = totals_by_food.get(s.food_id, 0) + s.quantity

    rows = []
    lines = ["🛒 مارکتِ هاپویی - غذای سگ\n"]
    for food_id, qty in totals_by_food.items():
        if qty <= 0:
            continue
        food = session.get(db.DogFood, food_id)
        if not food:
            continue
        unit_price = food.price * (1 + tax_pct / 100.0)
        lines.append(f"{food.name}: {qty} واحد موجود - {fmt(unit_price)} 🪙/واحد (هر واحد = {food.feed_value} واحدِ سیری)")
        rows.append([InlineKeyboardButton(f"🛒 خریدِ {food.name}", callback_data=f"chef_buy_ask:{chat_id}:{food_id}:{owner_id}")])
    await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))


async def cb_chef_buy_ask(update, context):
    _, chat_id, food_id, owner_id = update.callback_query.data.split(":")
    chat_id, food_id, owner_id = int(chat_id), int(food_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    await ask_for_input(update, context, "🔢 چند واحد می‌خوای بخری؟ عدد رو بفرست.", {"type": "buy_qty", "chat_id": chat_id, "food_id": food_id}, "chef_awaiting")


# ---------------------------------------------------------------------------
# پردازشِ ورودی‌های متنی
# ---------------------------------------------------------------------------

async def chef_awaiting_handler(update, context):
    awaiting = context.user_data.get("chef_awaiting")
    if not awaiting:
        return
    if not is_reply_to_prompt(update, awaiting):
        return  # این پیام ریپلای به پرامپتِ ما نیست - نادیده بگیر
    text = (update.message.text or "").strip()
    kind = awaiting["type"]
    session = db.get_session()
    try:
        import economy
        user = db.get_or_create_user(session, update.effective_user)

        if kind == "candidate_slogan":
            election_id = awaiting["election_id"]
            election = session.get(db.ChefElection, election_id)
            if not election or election.status != "open":
                await update.message.reply_text("❌ این انتخابات دیگه فعال نیست.")
                context.user_data.pop("chef_awaiting", None)
                raise ApplicationHandlerStop
            max_candidates = db.cfg_get_int(session, "chef_max_candidates")
            count = session.query(db.ChefCandidate).filter_by(election_id=election_id).count()
            if count >= max_candidates:
                await update.message.reply_text("❌ ظرفیتِ کاندیدها پر شده.")
                context.user_data.pop("chef_awaiting", None)
                raise ApplicationHandlerStop
            session.add(db.ChefCandidate(election_id=election_id, user_id=user.telegram_id, slogan=text[:300]))
            session.commit()
            context.user_data.pop("chef_awaiting", None)
            await update.message.reply_text("✅ کاندید شدی! موفق باشی 🍀")
            raise ApplicationHandlerStop

        if kind == "prepare_qty":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("chef_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            qty = int(text)
            if qty > CHEF_MAX_COOK_QTY:
                context.user_data.pop("chef_awaiting", None)
                await update.message.reply_text(
                    f"❌ حداکثرِ تعدادِ مجاز در یک درخواستِ پخت‌وپز {CHEF_MAX_COOK_QTY} غذا است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن."
                )
                raise ApplicationHandlerStop
            chat_id, food_id = awaiting["chat_id"], awaiting["food_id"]
            chef = session.query(db.GroupChef).filter_by(chat_id=chat_id).first()
            food = session.get(db.DogFood, food_id)
            if not chef or chef.user_id != user.telegram_id or not food:
                await update.message.reply_text("❌ الان سرآشپزِ این گروه نیستی یا این غذا دیگه وجود نداره.")
                context.user_data.pop("chef_awaiting", None)
                raise ApplicationHandlerStop
            cost = food.price * qty
            if user.hop_points < cost - 0.5:
                await update.message.reply_text(f"❌ موجودی کافی نیست! {fmt(cost)} 🪙 لازمه.")
                raise ApplicationHandlerStop
            user.hop_points -= cost
            ready_at = datetime.datetime.utcnow() + datetime.timedelta(minutes=food.prep_minutes * qty)
            stock = db.GroupFoodStock(chat_id=chat_id, food_id=food_id, quantity=qty, ready_at=ready_at)
            session.add(stock)
            session.commit()
            context.user_data.pop("chef_awaiting", None)
            await update.message.reply_text(
                f"✅ {qty} واحد {food.name} سفارش داده شد! هزینه: {fmt(cost)} 🪙\n"
                f"⏳ آماده می‌شه: {ready_at.strftime('%Y-%m-%d %H:%M')}"
            )
            raise ApplicationHandlerStop

        if kind == "settax":
            try:
                pct = float(text)
            except ValueError:
                context.user_data.pop("chef_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            max_tax = db.cfg_get_float(session, "chef_max_tax_pct")
            if pct < 0 or pct > max_tax:
                context.user_data.pop("chef_awaiting", None)
                await update.message.reply_text(f"❌ مقدار اشتباه است (باید بینِ ۰ تا {fmt(max_tax)} باشه)؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            chat_id = awaiting["chat_id"]
            chef = session.query(db.GroupChef).filter_by(chat_id=chat_id).first()
            if not chef or chef.user_id != user.telegram_id:
                await update.message.reply_text("❌ الان سرآشپزِ این گروه نیستی.")
                context.user_data.pop("chef_awaiting", None)
                raise ApplicationHandlerStop
            chef.tax_pct = pct
            session.commit()
            context.user_data.pop("chef_awaiting", None)
            await update.message.reply_text(f"✅ مالیات روی {fmt(pct)}٪ تنظیم شد.")
            raise ApplicationHandlerStop

        if kind == "buy_qty":
            if not text.isdigit() or int(text) < 1:
                context.user_data.pop("chef_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            qty = int(text)
            chat_id, food_id = awaiting["chat_id"], awaiting["food_id"]
            nowt = datetime.datetime.utcnow()
            # چون یه غذا ممکنه چند ردیفِ موجودیِ جدا داشته باشه (چندبار تهیه
            # شده)، خریدِ کاربر از رویِ همه‌شون (قدیمی‌ترین اول) کسر می‌شه.
            stocks = (
                session.query(db.GroupFoodStock)
                .filter(
                    db.GroupFoodStock.chat_id == chat_id,
                    db.GroupFoodStock.food_id == food_id,
                    db.GroupFoodStock.quantity > 0,
                    db.GroupFoodStock.ready_at <= nowt,
                )
                .order_by(db.GroupFoodStock.ready_at.asc(), db.GroupFoodStock.id.asc())
                .all()
            )
            total_available = sum(s.quantity for s in stocks)
            food = session.get(db.DogFood, food_id)
            if not stocks or not food or total_available <= 0:
                await update.message.reply_text("❌ این غذا دیگه موجود نیست.")
                context.user_data.pop("chef_awaiting", None)
                raise ApplicationHandlerStop
            if qty > total_available:
                await update.message.reply_text(f"❌ فقط {total_available} واحد موجوده.")
                raise ApplicationHandlerStop
            chef = session.query(db.GroupChef).filter_by(chat_id=chat_id).first()
            tax_pct = chef.tax_pct if chef else 0
            unit_price = food.price * (1 + tax_pct / 100.0)
            total_cost = unit_price * qty
            if user.hop_points < total_cost:
                await update.message.reply_text(f"❌ موجودی کافی نیست! {fmt(total_cost)} 🪙 لازمه.")
                raise ApplicationHandlerStop
            feed_units = (food.feed_value or 1) * qty
            economy.sync_dog_food(session, user)  # اول هرچی زمانی کم شده حساب شه، بعد اضافه کنیم
            minutes_per_unit = db.cfg_get_float(session, "chef_dog_food_minutes_per_unit")
            feed_minutes = feed_units * minutes_per_unit
            cap_minutes = economy.dog_food_capacity_minutes(session, user)
            if (user.dog_food or 0) + feed_minutes > cap_minutes:
                room_minutes = cap_minutes - (user.dog_food or 0)
                await update.message.reply_text(
                    f"❌ ظرفیتِ غذای سگت پر می‌شه! فقط {economy.format_minutes(room_minutes)} ظرفیت جا داری."
                )
                raise ApplicationHandlerStop
            user.hop_points -= total_cost
            user.dog_food = (user.dog_food or 0) + feed_minutes
            remaining = qty
            for s in stocks:
                if remaining <= 0:
                    break
                take = min(s.quantity, remaining)
                s.quantity -= take
                remaining -= take
            if chef:
                chef_user = session.get(db.User, chef.user_id)
                if chef_user:
                    chef_user.hop_points += total_cost * economy.money_income_multiplier(session, chef_user)
            session.commit()
            context.user_data.pop("chef_awaiting", None)
            await update.message.reply_text(
                f"✅ {qty} واحد {food.name} خریدی (+{feed_units} واحدِ سیری)! هزینه: {fmt(total_cost)} 🪙"
            )
            raise ApplicationHandlerStop
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مسیریاب دکمه‌های شیشه‌ای
# ---------------------------------------------------------------------------

CHEF_PREFIX_MAP = {
    "chef_recall": cb_chef_recall,
    "chef_candidate_ask": cb_chef_candidate_ask,
    "chef_vote": cb_chef_vote,
    "chef_panel": cb_chef_panel,
    "chef_buy_menu": cb_chef_buy_menu,
    "chef_prepare_ask": cb_chef_prepare_ask,
    "chef_settax_ask": cb_chef_settax_ask,
    "chef_buy_ask": cb_chef_buy_ask,
}


async def chef_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = CHEF_PREFIX_MAP.get(prefix)
    if handler:
        await handler(update, context)
        return True
    return False
