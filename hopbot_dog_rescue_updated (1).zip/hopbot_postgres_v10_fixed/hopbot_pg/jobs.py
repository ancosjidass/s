# -*- coding: utf-8 -*-
"""
جاب پس‌زمینه که هر چند دقیقه یک‌بار تولید کارخونه/سوپرمارکت و سود بانکی همه‌ی
کاربرها رو به‌روز می‌کنه؛ این‌طوری موجودی همیشه تازه‌ست حتی اگر کاربر منو رو باز نکنه
(مثلا وقتی می‌خواد هاپ پوینت انتقال بده یا از تراز واقعی مطلع بشه).
"""
import asyncio
import logging
import datetime

from sqlalchemy import and_, or_
from sqlalchemy.orm.attributes import flag_modified

import db
import economy

logger = logging.getLogger(__name__)


_MARKET_COLS = ("cat_meat", "cinnamon_cucumber", "banana", "dog_egg", "market_produce_progress",
                "market_product_level", "last_market_collect_at")
_BANK_COLS = ("bank_balance", "bank_last_interest_at", "bank_last_interest_amount")


def _tick_bank_and_market(session):
    """سودِ بانک + جمع‌شدنِ سوپرمارکتِ همه‌ی کاربرها (قدمِ اولِ tick_job).

    سرعت: قبلاً *همه‌ی* کاربرها (با همه‌ی ستون‌ها) لود می‌شدن و به‌ازایِ هر کاربر چند کوئریِ جدا
    (محصولاتِ دینامیک، محصولِ هر کاربر، تنظیمات) به دیتابیسِ ریموت زده می‌شد؛ هر دقیقه، رویِ
    event-loop - یعنی با زیاد‌شدنِ کاربرها کلِ ربات هر دقیقه چند ثانیه می‌ایستاد. حالا:
      • فقط کاربرهایی که اصلاً سوپرمارکت دارن یا بانکِ دارایی‌دار (بقیه تو هر دو تابع همون اولِ
        کار return می‌کردن، پس نتیجه عیناً یکیه)؛
      • محصولاتِ فعال و ردیف‌هایِ UserProduct یک‌جا خونده می‌شن، نه به‌ازایِ هر کاربر؛
      • تنظیمات از کشِ درون‌حافظه می‌آن (db.cfg_get).
    خودِ فرمول‌ها (economy.collect_supermarket_production / apply_bank_interest_if_due) دست‌نخورده‌ان."""
    users = (
        session.query(db.User)
        .filter(or_(
            db.User.has_supermarket == True,  # noqa: E712
            and_(db.User.has_bank == True, db.User.bank_balance > 0),  # noqa: E712
        ))
        .all()
    )
    if not users:
        return
    products = session.query(db.Product).filter(db.Product.is_active == True).all()  # noqa: E712
    user_products = {}
    if products:
        market_ids = [u.telegram_id for u in users if u.has_supermarket]
        for i in range(0, len(market_ids), 1000):
            chunk = market_ids[i:i + 1000]
            for up in session.query(db.UserProduct).filter(db.UserProduct.user_id.in_(chunk)).all():
                user_products.setdefault((up.user_id, up.product_id), up)
    # ORM فقط ردیف‌هایِ «هم‌شکل» (با دقیقاً همون ستون‌هایِ تغییرکرده) رو یکجا و دسته‌ای می‌فرسته؛
    # اگه هر کاربر یه مجموعه‌ستونِ متفاوت عوض کنه (مثلاً یکی سطحِ محصول بالا رفته و یکی نه) هر کدوم
    # یه UPDATEِ جدا = یه رفت‌وبرگشتِ جدا می‌شن. برایِ همین کاربرها رو به سه گروه (فقط سوپرمارکت /
    # فقط بانک / هر دو) تقسیم می‌کنیم و برایِ کاربرِ تغییرکرده ستون‌هایِ همون گروه رو یکدست «تغییرکرده»
    # علامت می‌زنیم (مقدارِ جدیدشون همون مقدارِ الانشونه؛ این حلقه هیچ await ای نداره، پس بینِ
    # خوندن و نوشتن هیچ هندلرِ دیگه‌ای وسط نمی‌پره).
    groups = {"m": [], "b": [], "mb": []}
    for user in users:
        is_m = bool(user.has_supermarket)
        is_b = bool(user.has_bank and (user.bank_balance or 0) > 0)
        groups["mb" if (is_m and is_b) else ("m" if is_m else "b")].append(user)
    for key, grp in groups.items():
        cols = (_MARKET_COLS if key != "b" else ()) + (_BANK_COLS if key != "m" else ())
        for user in grp:
            economy.collect_supermarket_production(session, user, products, user_products)
            economy.apply_bank_interest_if_due(session, user)
            if cols and session.is_modified(user):
                for c in cols:
                    flag_modified(user, c)
        session.flush()


async def tick_job(context):
    """
    این جاب هر ۶۰ ثانیه اجرا می‌شه (یا با fallback داخل main.py، بدون نیاز به
    job_queue). فقط کارهایی که «باید خودکار» باشن اینجان:
    - سود بانکی روزانه، دقیقاً ساعتِ ۹ صبح به وقتِ ایران (چک‌پوینتِ مطلق و
      مشترکِ بینِ همه، نه از لحظه‌ی واریزِ خودِ کاربر - نگاه کن به
      economy.apply_bank_interest_if_due). چون این تیک روی همه‌ی کاربرها
      اجرا می‌شه (نه فقط وقتی کسی بانک رو باز می‌کنه)، حتی کسی که چند
      ثانیه قبل از ۹ صبح واریز کرده هم دقیقاً سرِ ۹ سود می‌گیره.
    - جمع‌شدنِ محصولاتِ سوپرمارکت (کالا، نه پول - برداشتِ نهایی/فروش هنوز با کاربره)
    - بروزرسانی خودکار قیمت ارزها (فقط اگه مالک از پنل روشنش کرده باشه)
    - انقضای درخواست‌های پلتفرمِ گوشی هاپویی که تا مهلتِ فی رو کامل پرداخت نکردن
      (با ۱ ساعت مونده هشدار می‌گیرن، و اگه سرِ وقت پرداخت نکنن هم درخواست کنسل
      می‌شه هم می‌رن زندانِ هاپویی)
    - بستنِ انتخاباتِ سرآشپزی که مهلتشون تموم شده و اعلامِ برنده
    - پایانِ دوره‌ی سرآشپزهایی که ۷ روزشون تموم شده
    - جاروبِ تایم‌اوتِ بازی‌های کازینو (نبردِ دریایی/حدسِ عدد/رمزیاب/کلاسیک)

    عمداً «کارخونه» اینجا نیست: تولیدِ کارخونه فقط با فشردنِ دکمه‌ی برداشت باید
    به هاپ پوینت واریز بشه (باگ قبلی همین بود که خودکار واریز می‌شد).

    نکته‌ی مهمِ ساختاری: هر کدوم از قدم‌های زیر تویِ try/except جداگونه‌ی خودش
    اجراش می‌شه. قبلاً همه‌شون تو یه try/except مشترک بودن - یعنی اگه فقط یکی
    از قدم‌های اولیه (مثلاً بروزرسانیِ قیمتِ ارزها) خطا می‌داد، کلِ تابع همون‌جا
    متوقف می‌شد و قدم‌های بعدی (از جمله جاروبِ تایم‌اوتِ بازی‌های کازینو، که
    کاملاً بی‌ربط به ارزهاست) اصلاً اجرا نمی‌شدن - دقیقاً همین بود که باعث
    می‌شد بازیِ کسی که تایم‌اوت شده، even بعدِ ساعت‌ها، هیچ‌وقت لغو/تمام نشه.
    الان هر قدم مستقل از بقیه‌ست؛ خطای یکی جلوی بقیه رو نمی‌گیره.
    """
    session = db.get_session()
    try:
        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            _tick_bank_and_market(session)
            session.commit()
        except Exception:
            logger.exception("خطا در سود بانکی/تولیدِ سوپرمارکت")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            await economy.tick_crypto_prices(session, context)
            session.commit()
        except Exception:
            logger.exception("خطا در بروزرسانیِ قیمتِ ارزها")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            await _warn_soon_expiring_fees(session, context)
            session.commit()
        except Exception:
            logger.exception("خطا در هشدارِ انقضای فیِ پلتفرم")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            await _expire_unpaid_platform_requests(session, context)
            session.commit()
        except Exception:
            logger.exception("خطا در انقضای درخواست‌های پلتفرم")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            await _close_overdue_elections(session, context)
            session.commit()
        except Exception:
            logger.exception("خطا در بستنِ انتخاباتِ سرآشپزی")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            await _expire_chef_terms(session, context)
            session.commit()
        except Exception:
            logger.exception("خطا در پایانِ دوره‌ی سرآشپز")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            _tick_myawy_phones(session)
            session.commit()
        except Exception:
            logger.exception("خطا در تیکِ گوشیِ هاپویی")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            import attack
            await attack.tick_hostage_escapes(session, context)
        except Exception:
            logger.exception("خطا در بررسیِ فرارِ گروگان")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            import attack
            await attack.tick_pending_hostage_confirms(session, context)
        except Exception:
            logger.exception("خطا در لغوِ خودکارِ تأییدِ گروگان‌گیریِ بی‌جواب‌مونده")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            import attack
            await attack.tick_attack_session_timeouts(session, context)
        except Exception:
            logger.exception("خطا در لغوِ خودکارِ نبردِ بی‌حرکت‌مونده")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            import smuggling
            await smuggling.tick_smuggling_operation_timeouts(session, context)
        except Exception:
            logger.exception("خطا در لغوِ خودکارِ عملیاتِ قاچاقِ بی‌حرکت‌مونده")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            import uno
            await uno.tick_uno(session, context)
        except Exception:
            logger.exception("خطا در جمع‌کردنِ نوبت/لابیِ رهاشده‌ی اونو")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            import roulette
            await roulette.tick_roulette(session, context)
        except Exception:
            logger.exception("خطا در جمع‌کردنِ لابی/نوبتِ رهاشده‌ی رولت روسی")
            session.rollback()

        await asyncio.sleep(0)   # بینِ قدم‌هایِ جاب، حلقه رو برایِ پردازشِ پیام‌هایِ کاربرها آزاد می‌کنه
        try:
            import mafia
            await mafia.tick_mafia(session, context)
        except Exception:
            logger.exception("خطا در جمع‌کردنِ لابی/فازِ رهاشده‌ی مافیا/گرگینه")
            session.rollback()

        await _sweep_battleship_timeouts(context)
        await _sweep_casino_stale_rounds(context)
        await _sweep_guessnum_timeouts(context)
        await _sweep_mastermind_timeouts(context)
    except Exception:
        logger.exception("خطا در اجرای jobِ پس‌زمینه")
        session.rollback()
    finally:
        session.close()


async def game_tick_job(context):
    """جاروبِ *سریعِ* بازی‌هایِ کازینو (هر ~۱۰ ثانیه)، جدا از tick_job ـیِ سنگین.
    tick_job رویِ همه‌ی کاربرها حلقه می‌زنه (سودِ بانک، سوپرمارکت، قیمتِ ارز ...) و
    وقتی سرور شلوغه ممکنه طول بکشه؛ چون جاروبِ لابی‌ها آخرِ اون بود، لغوِ لابیِ
    منقضی (و برداشتنِ دکمه‌هایِ مرده) دیر می‌رسید. الان لابی‌ها مستقل و سریع جمع
    می‌شن. همه‌ی این کارها idempotent ان، پس اجرایِ همزمان/تکراری با tick_job بی‌ضرره."""
    await _sweep_casino_stale_rounds(context)
    session = db.get_session()
    try:
        try:
            import roulette
            await roulette.tick_roulette(session, context)
        except Exception:
            logger.exception("خطا در جاروبِ سریعِ رولت روسی")
            session.rollback()
        try:
            import mafia
            await mafia.tick_mafia(session, context)
        except Exception:
            logger.exception("خطا در جاروبِ سریعِ مافیا/گرگینه")
            session.rollback()
    finally:
        session.close()


async def _sweep_battleship_timeouts(context):
    """دورهای «نبردِ دریایی» که بیشتر از حدِ مجاز بدونِ حرکت موندن رو لغو
    می‌کنه (نگاه کن به battleship.sweep_timeouts)."""
    import battleship  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
    try:
        await battleship.sweep_timeouts(context)
    except Exception:
        logger.exception("خطا در جاروبِ تایم‌اوتِ نبردِ دریایی")


async def _sweep_casino_stale_rounds(context):
    """کازینوهای کلاسیکِ رهاشده (setup/lobby) رو لغو و پول‌ها رو برمی‌گردونه
    (نگاه کن به casino.sweep_stale_rounds)."""
    import casino  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
    try:
        await casino.sweep_stale_rounds(context)
    except Exception:
        logger.exception("خطا در جاروبِ کازینوهای رهاشده")


async def _sweep_guessnum_timeouts(context):
    """لابی/سازنده‌ی رهاشده‌ی «حدسِ عدد» رو لغو و پول‌ها رو برمی‌گردونه
    (نگاه کن به guessnum.sweep_timeouts)."""
    import guessnum  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
    try:
        await guessnum.sweep_timeouts(context)
    except Exception:
        logger.exception("خطا در جاروبِ تایم‌اوتِ حدسِ عدد")


async def _sweep_mastermind_timeouts(context):
    """دورهای «رمزیاب» رهاشده رو لغو و پول‌ها رو برمی‌گردونه (نگاه کن به
    mastermind.sweep_timeouts)."""
    import mastermind  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
    try:
        await mastermind.sweep_timeouts(context)
    except Exception:
        logger.exception("خطا در جاروبِ تایم‌اوتِ رمزیاب")


async def _warn_soon_expiring_fees(session, context):
    """۱ ساعت مونده به مهلتِ فیِ پلتفرم، یه اخطارِ یک‌باره تو پیویِ کاربر می‌فرسته."""
    nowt = datetime.datetime.utcnow()
    soon = (
        session.query(db.PlatformRequest)
        .filter(
            db.PlatformRequest.status == "awaiting_payment",
            db.PlatformRequest.warned_1h == False,  # noqa: E712
            db.PlatformRequest.fee_deadline > nowt,
            db.PlatformRequest.fee_deadline <= nowt + datetime.timedelta(hours=1),
        )
        .all()
    )
    jail_days = db.cfg_get_int(session, "myawy_fee_jail_days")
    for req in soon:
        remain = req.fee_amount - req.fee_paid_amount
        req.warned_1h = True
        try:
            await context.bot.send_message(
                req.user_id,
                f"⚠️ فقط ۱ ساعت مونده تا مهلتِ پرداختِ فیِ پلتفرمِ «{req.platform_name}»!\n"
                f"💵 مقدارِ باقی‌مونده: {req.fee_amount - req.fee_paid_amount:,.0f} 🪙\n"
                f"اگه ندی، درخواست کنسل می‌شه و {jail_days} روز می‌ری زندانِ هاپویی.",
            )
        except Exception:
            pass


async def _expire_unpaid_platform_requests(session, context):
    nowt = datetime.datetime.utcnow()
    expired = (
        session.query(db.PlatformRequest)
        .filter(db.PlatformRequest.status == "awaiting_payment", db.PlatformRequest.fee_deadline < nowt)
        .all()
    )
    jail_days = db.cfg_get_int(session, "myawy_fee_jail_days")
    for req in expired:
        req.status = "expired"
        user = session.get(db.User, req.user_id)
        if user:
            user.jailed_until = nowt + datetime.timedelta(days=jail_days)
        try:
            await context.bot.send_message(
                req.user_id,
                f"⌛️ مهلتِ پرداختِ فیِ پلتفرمِ «{req.platform_name}» تموم شد و درخواست لغو شد.\n"
                f"🔒 به‌خاطرِ پرداخت‌نکردن، {jail_days} روز رفتی زندانِ هاپویی.",
            )
        except Exception:
            pass


async def _close_overdue_elections(session, context):
    """اگه کسی تو گروه دیگه سراغِ «رای گیری هاپویی» نره، انتخاباتی که مهلتش تموم
    شده تا ابد باز نمونه - این تابع خودش می‌بندتش و برنده رو اعلام می‌کنه."""
    import chef  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای

    nowt = datetime.datetime.utcnow()
    overdue = (
        session.query(db.ChefElection)
        .filter(db.ChefElection.status == "open", db.ChefElection.closes_at <= nowt)
        .all()
    )
    for election in overdue:
        await chef._close_election(context, session, election)


def _tick_myawy_phones(session):
    """گوشی‌های هاپویی: نسل‌هایی که مهلتِ بازارشون تموم شده رو خودکار «ناموجود»
    می‌کنه، و برای هر گوشیِ خریداری‌شده (بعد از گذشتِ روزهای مهلت) یه‌بار در روز
    شانسِ خراب‌شدنِ هر قطعه رو چک می‌کنه."""
    import myawy  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
    myawy.expire_stale_markets(session)
    myawy.roll_daily_breakdowns(session)


async def _expire_chef_terms(session, context):
    import chef  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای

    nowt = datetime.datetime.utcnow()
    expired = session.query(db.GroupChef).filter(db.GroupChef.term_ends_at <= nowt).all()
    for c in expired:
        user = session.get(db.User, c.user_id)
        name = user.display_name() if user else str(c.user_id)
        chef._clear_market_and_refund(session, c)
        session.query(db.ChefRecallVote).filter_by(chat_id=c.chat_id, chef_user_id=c.user_id).delete()
        session.delete(c)
        try:
            await context.bot.send_message(
                c.chat_id,
                f"⌛️ دوره‌ی سرآشپزیِ {name} تموم شد!\n"
                "برای شروعِ انتخاباتِ جدید، «رای گیری هاپویی» رو بنویس.",
            )
        except Exception:
            pass
