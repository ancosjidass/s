# -*- coding: utf-8 -*-
"""
پنل ادمینِ «سرقت تیمی هاپویی» - دقیقاً به سبکِ «هاپ منیج»: هر تنظیم یه برچسبِ فارسیِ قابل‌فهم داره
(نه اسمِ انگلیسیِ متغیر)، مقدارِ فعلی کنارش نوشته شده و با یه دکمه ویرایش می‌شه.
هیچ مکانی پیش‌فرض نیست؛ اولین مکان رو خودت از «➕ مکانِ جدید» می‌سازی.
"""
import math

from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb

import db
import heist_db as H
import heist_engine as E
import heist_svc as S
from heist_svc import HeistError

PAGE = 8


async def _send(update, text, rows):
    from handlers import send_response
    return await send_response(update, text[:3900], Kb(rows))


async def _ask(update, context, text, state):
    from handlers import ask_for_input
    await ask_for_input(update, context, text, state, "admin_state", "admin_heist_menu")


def _val_text(kind, v):
    if kind == "bool":
        return "✅ روشن" if v else "⛔️ خاموش"
    if v is None or v == "":
        return "—"
    if kind in ("int", "float") and isinstance(v, (int, float)):
        return E.fmt_int(v) if float(v) == int(v) else str(v)
    return str(v)


# ---------------------------------------------------------------------------
# منوی اصلی
# ---------------------------------------------------------------------------
async def cb_heist_menu(update, context):
    session = db.get_session()
    try:
        on = S.gi(session, "heist_enabled", 1)
        locs = len(S.list_locations(session, include_hidden=True))
        lvl = db.cfg_get(session, "minlvl_heist")
    finally:
        session.close()
    rows = [
        [Btn(f"{'🟢' if on else '🔴'} سرقت تیمی: {'روشن' if on else 'خاموش'}", callback_data="admin_heist_toggle")],
        [Btn(f"🗺 مکان‌های سرقت ({locs})", callback_data="admin_heist_locs:0")],
        [Btn("⚙️ تنظیمات کلی (مهارت، رنگ‌ها، لابی)", callback_data="admin_heist_cfg:g:0")],
        [Btn("🆕 پیش‌فرضِ مکان‌های جدید", callback_data="admin_heist_cfg:d:0")],
        [Btn("💬 متن پیام‌ها", callback_data="admin_heist_cfg:m:0")],
        [Btn(f"🔐 حداقل لولِ ورود به سرقت ({lvl})", callback_data=f"admin_cfg_edit:minlvl_heist")],
        [Btn("👤 ابزارِ بازیکن (XP / مهارت / کول‌داون)", callback_data="admin_heist_player")],
        [Btn("🛑 لغوِ عملیاتِ باز", callback_data="admin_heist_cancelop"), Btn("📊 آمار", callback_data="admin_heist_dash")],
        [Btn("🔙 پنل مدیریت", callback_data="admin_panel")],
    ]
    await _send(update, "🥷 مدیریت سرقت هاپویی\n(همه‌ی اعداد، مکان‌ها، آیتم‌ها و متن‌ها از همین‌جا؛ بدونِ تغییرِ کد)\n\n"
                        "ℹ️ تا وقتی خودت مکان نسازی، هیچ سرقتی وجود نداره.", rows)


async def cb_heist_toggle(update, context):
    session = db.get_session()
    try:
        S.admin_set_global_cfg(session, update.effective_user.id, "heist_enabled", "0" if S.gi(session, "heist_enabled", 1) else "1")
    finally:
        session.close()
    await cb_heist_menu(update, context)


async def cb_heist_noop(update, context):
    await update.callback_query.answer()


# ---------------------------------------------------------------------------
# تنظیمات کلی / پیش‌فرض‌ها / متن‌ها (لیستِ برچسب‌دار مثلِ هاپ منیج)
# ---------------------------------------------------------------------------
def _cfg_keys(group):
    if group == "g":
        return [k for k, _l, _v, _h in H.GLOBAL_CFG], "⚙️ تنظیمات کلیِ سرقت"
    if group == "d":
        return list(H.DEF_CFG_DEFAULT), "🆕 پیش‌فرضِ مکان‌های جدید\n(فقط روی مکان‌هایی که از این به بعد می‌سازی اثر داره)"
    return [H.MSG_PREFIX + k for k in H.MESSAGES], "💬 متن پیام‌ها"


async def cb_heist_cfg(update, context):
    _, group, page = update.callback_query.data.split(":")
    keys, title = _cfg_keys(group)
    pages = max(1, math.ceil(len(keys) / PAGE))
    page = max(0, min(int(page), pages - 1))
    session = db.get_session()
    try:
        lines, rows = [f"{title} ({page + 1}/{pages})", ""], []
        for k in keys[page * PAGE:(page + 1) * PAGE]:
            label = H.ALL_CFG_LABEL[k]
            val = str(db.cfg_get(session, k))
            shown = val if len(val) <= 40 else val[:40] + "…"
            lines.append(f"• {label}: {shown}")
            help_ = H.GLOBAL_CFG_HELP.get(k)
            if help_:
                lines.append(f"   ({help_})")
            rows.append([Btn(f"✏️ {label[:45]}", callback_data=f"admin_heist_cfgk:{k}")])
    finally:
        session.close()
    rows.append([Btn("◀️", callback_data=f"admin_heist_cfg:{group}:{max(0, page - 1)}"), Btn(f"{page + 1}/{pages}", callback_data="admin_heist_noop"),
                 Btn("▶️", callback_data=f"admin_heist_cfg:{group}:{min(pages - 1, page + 1)}")])
    rows.append([Btn("🔙 بازگشت", callback_data="admin_heist_menu")])
    await _send(update, "\n".join(lines), rows)


async def cb_heist_cfgk(update, context):
    key = update.callback_query.data.split(":", 1)[1]
    if key not in H.ALL_CFG_LABEL:
        await update.callback_query.answer("کلید ناشناخته", show_alert=True)
        return
    session = db.get_session()
    try:
        cur = db.cfg_get(session, key)
    finally:
        session.close()
    extra = ""
    if key.startswith(H.MSG_PREFIX):
        extra = "\n(می‌تونی از {remain} و مشابهش استفاده کنی اگه تو متنِ فعلی هست)"
    await _ask(update, context, f"✏️ {H.ALL_CFG_LABEL[key]}\nمقدارِ فعلی: {cur}{extra}\n\nمقدارِ جدید رو بفرست:",
               {"type": "heist_cfg", "key": key})


# ---------------------------------------------------------------------------
# مکان‌ها
# ---------------------------------------------------------------------------
async def cb_heist_locs(update, context):
    page = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        locs = S.list_locations(session, include_hidden=True)
        pages = max(1, math.ceil(len(locs) / PAGE))
        page = max(0, min(page, pages - 1))
        rows = [[Btn(("✅ " if l.enabled else "⛔️ ") + f"{l.name} — {E.fmt_int(l.req_xp)} XP", callback_data=f"admin_heist_loc:{l.id}")]
                for l in locs[page * PAGE:(page + 1) * PAGE]]
        text = f"🗺 مکان‌های سرقت ({len(locs)})" + ("" if locs else "\n\nهنوز هیچ مکانی نساختی. با «➕ مکانِ جدید» اولین مکان رو بساز.")
    finally:
        session.close()
    rows.append([Btn("➕ مکانِ جدید", callback_data="admin_heist_locnew")])
    if pages > 1:
        rows.append([Btn("◀️", callback_data=f"admin_heist_locs:{max(0, page - 1)}"), Btn(f"{page + 1}/{pages}", callback_data="admin_heist_noop"),
                     Btn("▶️", callback_data=f"admin_heist_locs:{min(pages - 1, page + 1)}")])
    rows.append([Btn("🔙 بازگشت", callback_data="admin_heist_menu")])
    await _send(update, text, rows)


async def cb_heist_locnew(update, context):
    await _ask(update, context, "➕ نامِ مکانِ جدید رو بفرست (مثلا: سوپرمارکت).\nبقیه‌ی مقدارها از «پیش‌فرضِ مکان‌های جدید» پر می‌شن و بعدش خودت دونه‌دونه تغییرشون می‌دی.",
               {"type": "heist_locnew"})


async def cb_heist_loc(update, context):
    """صفحه‌ی یه مکان: همه‌ی تنظیماتش با برچسبِ فارسی + دکمه‌ی ویرایشِ هرکدوم."""
    loc_id = int(update.callback_query.data.split(":")[1])
    await _show_location(update, loc_id)


async def _show_location(update, loc_id):
    session = db.get_session()
    try:
        loc = session.get(H.HeistLocation, loc_id)
        if loc is None or loc.deleted:
            await update.callback_query.answer("مکان پیدا نشد", show_alert=True)
            return
        n_items = len(S.location_pool(session, loc_id))
        lines = [f"{'✅' if loc.enabled else '⛔️'} {loc.name}", f"🆔 {loc.code} | 🎁 آیتم‌های فعال: {n_items}", ""]
        for gkey, gname in H.LOC_GROUPS:
            lines.append(gname)
            for key, label, kind, _d, g, _h in H.LOC_FIELDS:
                if g == gkey:
                    lines.append(f"• {label}: {_val_text(kind.split(':')[0], getattr(loc, key))}")
            lines.append("")
        text = "\n".join(lines)
    finally:
        session.close()
    rows = [[Btn("🎁 آیتم‌های این مکان", callback_data=f"admin_heist_items:{loc_id}")],
            [Btn("🔁 فعال/غیرفعال", callback_data=f"admin_heist_loctgl:{loc_id}"), Btn("🗑 حذف", callback_data=f"admin_heist_locdel:{loc_id}")]]
    for gkey, gname in H.LOC_GROUPS:
        rows.append([Btn(f"✏️ ویرایشِ {gname}", callback_data=f"admin_heist_locg:{loc_id}:{gkey}")])
    rows.append([Btn("🔙 مکان‌ها", callback_data="admin_heist_locs:0")])
    await _send(update, text, rows)


async def cb_heist_locg(update, context):
    _, loc_id, gkey = update.callback_query.data.split(":")
    session = db.get_session()
    try:
        loc = session.get(H.HeistLocation, int(loc_id))
        if loc is None:
            await update.callback_query.answer("مکان پیدا نشد", show_alert=True)
            return
        gname = dict(H.LOC_GROUPS)[gkey]
        rows = []
        for key, label, kind, _d, g, _h in H.LOC_FIELDS:
            if g == gkey:
                rows.append([Btn(f"✏️ {label[:40]} ({_val_text(kind.split(':')[0], getattr(loc, key))[:12]})", callback_data=f"admin_heist_locf:{loc_id}:{key}")])
        title = f"{loc.name} — {gname}"
    finally:
        session.close()
    rows.append([Btn("🔙 بازگشت", callback_data=f"admin_heist_loc:{loc_id}")])
    await _send(update, f"{title}\nروی هر مورد بزن تا مقدارِ جدیدش رو بفرستی:", rows)


async def cb_heist_locf(update, context):
    _, loc_id, key = update.callback_query.data.split(":")
    spec = H.LOC_BY_KEY.get(key)
    session = db.get_session()
    try:
        loc = session.get(H.HeistLocation, int(loc_id))
        cur = getattr(loc, key) if loc else None
    finally:
        session.close()
    if spec is None or loc is None:
        await update.callback_query.answer("پیدا نشد", show_alert=True)
        return
    hint = spec[5]
    kind = spec[2]
    ex = ""
    if kind == "bool":
        ex = "\n(۱ = روشن، ۰ = خاموش)"
    elif kind.startswith("enum:"):
        ex = "\n(یکی از: " + " | ".join(kind[5:].split("|")) + ")"
    await _ask(update, context, f"✏️ {spec[1]}\nمقدارِ فعلی: {cur}\n{hint}{ex}\n\nمقدارِ جدید رو بفرست:",
               {"type": "heist_locf", "loc": int(loc_id), "key": key})


async def cb_heist_loctgl(update, context):
    loc_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        S.admin_toggle_location(session, update.effective_user.id, loc_id)
    except HeistError as e:
        await update.callback_query.answer(str(e), show_alert=True)
        return
    finally:
        session.close()
    await _show_location(update, loc_id)


async def cb_heist_locdel(update, context):
    parts = update.callback_query.data.split(":")
    loc_id = int(parts[1])
    if len(parts) == 2:
        await _send(update, "⚠️ این مکان حذف بشه؟ (حذفِ منطقی: از لیست‌ها و بازی می‌ره، تاریخچه‌ی قبلی می‌مونه.\nعملیات‌های در حال اجرا تحت‌تأثیر قرار نمی‌گیرن.)",
                    [[Btn("✅ بله، حذف کن", callback_data=f"admin_heist_locdel:{loc_id}:y")], [Btn("❌ انصراف", callback_data=f"admin_heist_loc:{loc_id}")]])
        return
    session = db.get_session()
    try:
        S.admin_delete_location(session, update.effective_user.id, loc_id)
    except HeistError as e:
        await update.callback_query.answer(str(e), show_alert=True)
        return
    finally:
        session.close()
    await update.callback_query.answer("🗑 حذف شد")
    update.callback_query.data = "admin_heist_locs:0"
    await cb_heist_locs(update, context)


# ---------------------------------------------------------------------------
# آیتم‌های مکان
# ---------------------------------------------------------------------------
async def cb_heist_items(update, context):
    loc_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        loc = session.get(H.HeistLocation, loc_id)
        if loc is None:
            await update.callback_query.answer("مکان پیدا نشد", show_alert=True)
            return
        items = session.query(H.HeistLocationItem).filter_by(location_id=loc_id).order_by(H.HeistLocationItem.id).all()
        lines = [f"🎁 آیتم‌های «{loc.name}»", ""]
        rows = []
        for it in items:
            lines.append(f"{'✅' if it.enabled else '⛔️'} {it.name} — {E.fmt_int(it.base_value)}")
            rows.append([Btn(f"{'✅' if it.enabled else '⛔️'} {it.name} — {E.fmt_int(it.base_value)}", callback_data=f"admin_heist_item:{it.id}")])
        if not items:
            lines.append("هنوز آیتمی ندارد؛ بدونِ آیتم این مکان برای بازیکن‌ها قابلِ سرقت نیست.")
    finally:
        session.close()
    rows.append([Btn("➕ آیتمِ جدید", callback_data=f"admin_heist_itemnew:{loc_id}")])
    rows.append([Btn("🔙 بازگشت", callback_data=f"admin_heist_loc:{loc_id}")])
    await _send(update, "\n".join(lines), rows)


async def cb_heist_itemnew(update, context):
    loc_id = int(update.callback_query.data.split(":")[1])
    await _ask(update, context, "➕ آیتمِ جدید: «نام | ارزشِ پایه»\nمثال: تلویزیون | 50000000", {"type": "heist_itemnew", "loc": loc_id})


async def cb_heist_item(update, context):
    item_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        it = session.get(H.HeistLocationItem, item_id)
        if it is None:
            await update.callback_query.answer("آیتم پیدا نشد", show_alert=True)
            return
        loc_id = it.location_id
        lines = [f"🎁 {it.name}", ""]
        for key, label, kind in S.ITEM_FIELDS:
            v = getattr(it, key)
            lines.append(f"• {label}: {'پیش‌فرضِ مکان' if v is None else v}")
        lines.append(f"• وضعیت: {'✅ فعال' if it.enabled else '⛔️ غیرفعال'}")
    finally:
        session.close()
    rows = [[Btn(f"✏️ {label[:45]}", callback_data=f"admin_heist_itemf:{item_id}:{key}")] for key, label, _k in S.ITEM_FIELDS]
    rows.append([Btn("🔁 فعال/غیرفعال", callback_data=f"admin_heist_itemtgl:{item_id}"), Btn("🗑 حذف", callback_data=f"admin_heist_itemdel:{item_id}")])
    rows.append([Btn("🔙 بازگشت", callback_data=f"admin_heist_items:{loc_id}")])
    await _send(update, "\n".join(lines), rows)


async def cb_heist_itemf(update, context):
    _, item_id, key = update.callback_query.data.split(":")
    await _ask(update, context, f"✏️ {S.ITEM_LABEL.get(key, key)}\nمقدارِ جدید رو بفرست:", {"type": "heist_itemf", "item": int(item_id), "key": key})


async def cb_heist_itemtgl(update, context):
    item_id = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        S.admin_toggle_item(session, update.effective_user.id, item_id)
    finally:
        session.close()
    await cb_heist_item(update, context)


async def cb_heist_itemdel(update, context):
    parts = update.callback_query.data.split(":")
    item_id = int(parts[1])
    if len(parts) == 2:
        await _send(update, "⚠️ این آیتم برای همیشه حذف بشه؟ (غیرفعال‌کردنش امن‌تره)",
                    [[Btn("✅ بله، حذف کن", callback_data=f"admin_heist_itemdel:{item_id}:y")], [Btn("❌ انصراف", callback_data=f"admin_heist_item:{item_id}")]])
        return
    session = db.get_session()
    try:
        it = session.get(H.HeistLocationItem, item_id)
        loc_id = it.location_id if it else 0
        S.admin_delete_item(session, update.effective_user.id, item_id)
    except HeistError as e:
        await update.callback_query.answer(str(e), show_alert=True)
        return
    finally:
        session.close()
    await update.callback_query.answer("🗑 حذف شد")
    update.callback_query.data = f"admin_heist_items:{loc_id}"
    await cb_heist_items(update, context)


# ---------------------------------------------------------------------------
# ابزارها
# ---------------------------------------------------------------------------
async def cb_heist_player(update, context):
    await _ask(update, context, "👤 ابزارِ بازیکن:\nآیدیِ عددی + عملیات\n\n"
                                "مثال‌ها:\n12345 xp 500   ← ۵۰۰ XP اضافه\n12345 xp -200   ← ۲۰۰ XP کم\n"
                                "12345 cooldown   ← پاک‌کردنِ همه‌ی کول‌داون‌ها\n12345 reset   ← صفر کردنِ مهارت‌ها",
               {"type": "heist_player"})


async def cb_heist_cancelop(update, context):
    await _ask(update, context, "🛑 شماره‌ی عملیاتِ بازی که می‌خوای لغو کنی رو بفرست (بدونِ زندان و پاداش؛ کول‌داونِ ثبت‌شده‌ی لابی هم برمی‌گرده):",
               {"type": "heist_cancelop"})


async def cb_heist_dash(update, context):
    session = db.get_session()
    try:
        d = S.dashboard(session)
    finally:
        session.close()
    txt = (f"📊 آمارِ سرقت ({d['hours']} ساعتِ اخیر)\n\n🗺 مکان‌ها: {d['locations']}\n👥 بازیکن‌ها: {d['players']}\n"
           f"🟡 عملیاتِ باز: {d['open']}\n✅ موفق: {d['success']} | ❌ ناموفق: {d['failed']}\n💰 هاپِ پرداخت‌شده: {E.fmt_int(d['hop_paid'])}")
    await _send(update, txt, [[Btn("🔙 بازگشت", callback_data="admin_heist_menu")]])


# ---------------------------------------------------------------------------
# جوابِ متنیِ پرامپت‌ها (از admin.admin_awaiting_handler صدا زده می‌شه)
# ---------------------------------------------------------------------------
async def heist_admin_awaiting_handler(update, context, state):
    text = (update.message.text or "").strip()
    stype = state["type"]
    uid = update.effective_user.id
    session = db.get_session()
    reply, rows = None, [[Btn("🔙 منوی سرقت", callback_data="admin_heist_menu")]]
    try:
        if stype == "heist_cfg":
            val = S.admin_set_global_cfg(session, uid, state["key"], text)
            reply = f"✅ {H.ALL_CFG_LABEL[state['key']]} ← {val}"
        elif stype == "heist_locnew":
            loc = S.admin_create_location(session, uid, text)
            reply = f"✅ مکانِ «{loc.name}» ساخته شد.\nحالا مقدارهاش رو تنظیم کن و حتماً حداقل یه آیتم براش بساز."
            rows = [[Btn("⚙️ تنظیمِ این مکان", callback_data=f"admin_heist_loc:{loc.id}")], rows[0]]
        elif stype == "heist_locf":
            loc = S.admin_set_location_field(session, uid, state["loc"], state["key"], text)
            reply = f"✅ {H.LOC_LABEL[state['key']]} ← {getattr(loc, state['key'])}"
            rows = [[Btn("🔙 برگشت به مکان", callback_data=f"admin_heist_loc:{loc.id}")]]
        elif stype == "heist_itemnew":
            if "|" not in text:
                raise HeistError("فرمت: نام | ارزشِ پایه")
            name, _, val = text.partition("|")
            try:
                value = H.coerce("int", val)
            except ValueError as e:
                raise HeistError(str(e))
            S.admin_add_item(session, uid, state["loc"], name, value)
            reply = f"✅ آیتمِ «{name.strip()}» اضافه شد."
            rows = [[Btn("🎁 آیتم‌ها", callback_data=f"admin_heist_items:{state['loc']}")]]
        elif stype == "heist_itemf":
            it = S.admin_set_item_field(session, uid, state["item"], state["key"], text)
            reply = f"✅ {S.ITEM_LABEL[state['key']]} ← {getattr(it, state['key'])}"
            rows = [[Btn("🔙 برگشت به آیتم", callback_data=f"admin_heist_item:{it.id}")]]
        elif stype == "heist_player":
            parts = text.split()
            if len(parts) < 2 or not parts[0].lstrip("-").isdigit():
                raise HeistError("فرمت: آیدی xp 500 | آیدی cooldown | آیدی reset")
            target, op = int(parts[0]), parts[1].lower()
            if op == "xp" and len(parts) == 3:
                S.admin_adjust_player(session, uid, target, xp_delta=float(parts[2]))
                reply = f"✅ {parts[2]} XP برای {target} تغییر کرد."
            elif op == "cooldown":
                S.admin_adjust_player(session, uid, target, clear_cooldowns=True)
                reply = f"✅ کول‌داون‌های {target} پاک شد."
            elif op == "reset":
                S.admin_adjust_player(session, uid, target, reset_skills=True)
                reply = f"✅ مهارت‌های {target} صفر شد."
            else:
                raise HeistError("فرمت: آیدی xp 500 | آیدی cooldown | آیدی reset")
        elif stype == "heist_cancelop":
            if not text.isdigit():
                raise HeistError("یه شماره بفرست.")
            S.admin_cancel_op(session, int(text), uid)
            reply = f"✅ عملیات {text} لغو شد."
    except (HeistError, ValueError) as e:
        session.rollback()
        reply = f"❌ {e}"
    finally:
        session.close()
    await update.message.reply_text(reply or "—", reply_markup=Kb(rows))


ADMIN_HEIST_CALLBACKS = {
    "admin_heist_menu": cb_heist_menu, "admin_heist_toggle": cb_heist_toggle, "admin_heist_noop": cb_heist_noop,
    "admin_heist_cfg": cb_heist_cfg, "admin_heist_cfgk": cb_heist_cfgk,
    "admin_heist_locs": cb_heist_locs, "admin_heist_locnew": cb_heist_locnew, "admin_heist_loc": cb_heist_loc,
    "admin_heist_locg": cb_heist_locg, "admin_heist_locf": cb_heist_locf, "admin_heist_loctgl": cb_heist_loctgl, "admin_heist_locdel": cb_heist_locdel,
    "admin_heist_items": cb_heist_items, "admin_heist_itemnew": cb_heist_itemnew, "admin_heist_item": cb_heist_item,
    "admin_heist_itemf": cb_heist_itemf, "admin_heist_itemtgl": cb_heist_itemtgl, "admin_heist_itemdel": cb_heist_itemdel,
    "admin_heist_player": cb_heist_player, "admin_heist_cancelop": cb_heist_cancelop, "admin_heist_dash": cb_heist_dash,
}
