# -*- coding: utf-8 -*-
"""
پردازشِ هم‌زمانِ آپدیت‌ها + ابزارِ تشخیصِ کندی.

مشکلِ قبلی: PTB به‌صورتِ پیش‌فرض آپدیت‌ها رو *یکی‌یکی* (برای کلِ بات) پردازش می‌کنه.
تو کدِ بازی‌ها (کازینو/مافیا/رولت/...) هندلرها `await asyncio.sleep(...)` دارن
(مثلاً ۳.۵ ثانیه بینِ هر پرتابِ تاس، یا تا ۲۰ ثانیه صبر برایِ flood-wait تلگرام)؛ تا اون‌ها تموم
نشن، هیچ آپدیتِ دیگه‌ای - مثلاً «هاپ منیج» یه نفرِ دیگه - اصلاً شروع نمی‌شه.

راه‌حل: آپدیت‌هایِ آدم‌هایِ مختلف هم‌زمان پردازش می‌شن، ولی آپدیت‌هایِ *یه نفر* هنوز
به ترتیب (صف) اجرا می‌شن - یعنی همون تضمینِ ترتیبِ قبلی برایِ هر کاربر حفظ می‌شه.
متن و دکمه‌ها از هم جدا صف می‌شن (دکمه‌ها قبلاً هم با قفلِ per-user تو main.py صف می‌شدن).

ابزارِ تشخیص (فقط وقتی کند باشه لاگ می‌ده، پس بی‌سر‌و‌صدا و سبکه):
  • «UPDATE slow»      : یه آپدیت چقدر تو صف موند و چقدر اجرا شد
  • «TG-API slow»      : یه درخواست به تلگرام (sendMessage/editMessage/...) چقدر طول کشید
  • «EVENT-LOOP blocked»: حلقه‌یِ اصلی چند ثانیه گیر کرده (مثلاً کوئریِ sync به دیتابیس)
"""
import asyncio
import logging
import time

from telegram.ext import SimpleUpdateProcessor

logger = logging.getLogger("perf")

SLOW_UPDATE_SECONDS = 1.0
SLOW_API_SECONDS = 1.0
LOOP_LAG_SECONDS = 0.5


class PerUserUpdateProcessor(SimpleUpdateProcessor):
    """هم‌زمانیِ بینِ کاربرها، ترتیبِ کاملِ برایِ هر کاربر."""

    def __init__(self, max_concurrent_updates: int = 64):
        super().__init__(max_concurrent_updates)
        self._locks = {}          # key -> [Lock, تعدادِ منتظر/در حالِ اجرا]

    @staticmethod
    def _key(update):
        user = getattr(update, "effective_user", None)
        if user is None:
            return None
        kind = "cb" if getattr(update, "callback_query", None) is not None else "msg"
        return (kind, user.id)

    async def do_process_update(self, update, coroutine):
        t0 = time.monotonic()
        key = self._key(update)
        if key is None:
            await coroutine
            return
        entry = self._locks.get(key)
        if entry is None:
            entry = self._locks[key] = [asyncio.Lock(), 0]
        entry[1] += 1
        try:
            async with entry[0]:
                t1 = time.monotonic()
                try:
                    await coroutine
                finally:
                    t2 = time.monotonic()
                    if (t2 - t0) >= SLOW_UPDATE_SECONDS:
                        logger.warning("UPDATE slow: user=%s kind=%s queue=%.2fs run=%.2fs",
                                       key[1], key[0], t1 - t0, t2 - t1)
        finally:
            entry[1] -= 1
            if entry[1] <= 0 and self._locks.get(key) is entry:
                del self._locks[key]


def install_api_timer():
    """هر درخواست به تلگرام که از SLOW_API_SECONDS بیشتر طول بکشه رو لاگ می‌کنه."""
    from telegram import Bot
    orig = Bot.__dict__.get("_post")
    if orig is None or getattr(orig, "_hop_timer", False):
        return

    async def _post(self, endpoint, *args, **kwargs):
        t = time.monotonic()
        try:
            return await orig(self, endpoint, *args, **kwargs)
        finally:
            dt = time.monotonic() - t
            if dt >= SLOW_API_SECONDS and endpoint != "getUpdates":
                logger.warning("TG-API slow: %s took %.2fs", endpoint, dt)

    _post._hop_timer = True
    Bot._post = _post


async def loop_lag_monitor():
    """اگه event-loop بیشتر از LOOP_LAG_SECONDS گیر کنه (کدِ sync مثلِ کوئریِ دیتابیس) لاگ می‌ده."""
    interval = 0.25
    while True:
        t = time.monotonic()
        await asyncio.sleep(interval)
        lag = time.monotonic() - t - interval
        if lag >= LOOP_LAG_SECONDS:
            logger.warning("EVENT-LOOP blocked for %.2fs (کدِ sync مثلِ دیتابیس حلقه رو گرفته)", lag)
