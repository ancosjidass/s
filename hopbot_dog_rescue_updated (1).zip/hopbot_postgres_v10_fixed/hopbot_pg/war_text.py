# -*- coding: utf-8 -*-
"""نرمال‌سازی متن (تریگرها) و فرمت‌دهیِ اعداد/زمان برای جنگ هاپویی."""
import re

_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹٠١٢٣٤٥٦٧٨٩", "01234567890123456789")
_INVISIBLE = re.compile("[\u200b\u200d\u200e\u200f\u202a-\u202e\u2066-\u2069\ufeff\u0640\u064b-\u065f\u0670]")
_EDGE_JUNK = re.compile(r"^[^\w]+|[^\w]+$", re.UNICODE)


def normalize(text: str) -> str:
    """ي/ی، ك/ک، نیم‌فاصله، فاصله‌ی اضافه، کاراکترهای اضافیِ ابتدا/انتها رو یکدست می‌کنه."""
    if not text:
        return ""
    t = text.replace("\u200c", " ")
    t = _INVISIBLE.sub("", t)
    t = t.replace("ي", "ی").replace("ك", "ک").replace("ى", "ی").replace("ۀ", "ه").replace("ة", "ه")
    t = t.translate(_FA_DIGITS)
    t = t.lower()
    t = _EDGE_JUNK.sub("", t)
    t = re.sub(r"\s+", " ", t).strip()
    return t


def fmt(n) -> str:
    try:
        n = float(n)
    except (TypeError, ValueError):
        return str(n)
    return f"{n:,.0f}"


def short(n) -> str:
    """عددِ کوتاه (۱٫۲M / ۳۴۵K) برای نمایشِ عمومی."""
    try:
        n = float(n)
    except (TypeError, ValueError):
        return str(n)
    a = abs(n)
    for div, suf in ((1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "K")):
        if a >= div:
            v = n / div
            return f"{v:.1f}{suf}".replace(".0", "")
    return f"{n:.0f}"


def dur(seconds) -> str:
    s = max(0, int(seconds))
    d, s = divmod(s, 86400)
    h, s = divmod(s, 3600)
    m, s = divmod(s, 60)
    parts = []
    if d:
        parts.append(f"{d}d")
    if h:
        parts.append(f"{h}h")
    if m and not d:
        parts.append(f"{m}m")
    if s and not d and not h and not m:
        parts.append(f"{s}s")
    return " ".join(parts) or "0s"


def bar(pct, width=10) -> str:
    pct = max(0.0, min(100.0, float(pct)))
    filled = int(round(width * pct / 100.0))
    return "█" * filled + "░" * (width - filled)


def stars(n) -> str:
    n = max(0, min(3, int(n)))
    return "⭐" * n + "☆" * (3 - n)
