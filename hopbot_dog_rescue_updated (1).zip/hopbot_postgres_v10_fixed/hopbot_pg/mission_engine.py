# -*- coding: utf-8 -*-
"""
موتورِ خالصِ «مأموریت‌های هاپویی» (بدونِ دیتابیس/تلگرام): دوره‌ها، استریک، مقیاسِ پاداش، انتخابِ روزانه.
همه‌ی اعداد از ورودی میاد (تنظیماتِ ادمین)؛ هیچ عددِ بالانسی اینجا ثابت نیست.
"""
import datetime
import random


# ---------------------------------------------------------------------------
# دوره‌ها (روز/هفته) با ساعتِ محلیِ قابل‌تنظیم (پیش‌فرضِ ایران = ‎+۲۱۰ دقیقه از UTC)
# ---------------------------------------------------------------------------
def local(now_utc: datetime.datetime, tz_minutes: int) -> datetime.datetime:
    return now_utc + datetime.timedelta(minutes=tz_minutes)


def day_key(now_utc, tz_minutes) -> str:
    return local(now_utc, tz_minutes).strftime("%Y-%m-%d")


def week_key(now_utc, tz_minutes) -> str:
    l = local(now_utc, tz_minutes)
    start = (l - datetime.timedelta(days=(l.weekday() + 2) % 7)).date()      # هفته از شنبه
    return "W" + start.strftime("%Y-%m-%d")


def period_key(period: str, now_utc, tz_minutes) -> str:
    if period == "daily":
        return day_key(now_utc, tz_minutes)
    if period == "weekly":
        return week_key(now_utc, tz_minutes)
    return "once"


def period_start_utc(period: str, now_utc, tz_minutes):
    """شروعِ دوره‌ی جاری به UTC (یا None برای once = از ابتدا)."""
    l = local(now_utc, tz_minutes)
    if period == "daily":
        s = l.replace(hour=0, minute=0, second=0, microsecond=0)
    elif period == "weekly":
        s = (l - datetime.timedelta(days=(l.weekday() + 2) % 7)).replace(hour=0, minute=0, second=0, microsecond=0)
    else:
        return None
    return s - datetime.timedelta(minutes=tz_minutes)


def period_end_utc(period: str, now_utc, tz_minutes):
    s = period_start_utc(period, now_utc, tz_minutes)
    if s is None:
        return None
    return s + datetime.timedelta(days=1 if period == "daily" else 7)


# ---------------------------------------------------------------------------
# استریک
# ---------------------------------------------------------------------------
def next_streak(prev_streak: int, last_day: str, today: str, grace_days: int = 0) -> int:
    """last_day/today: 'YYYY-MM-DD'. روزِ بعد = +۱، همون روز = بدونِ تغییر، فاصله‌ی بیشتر از (۱+مهلت) = ریست به ۱."""
    if not last_day:
        return 1
    d = (datetime.date.fromisoformat(today) - datetime.date.fromisoformat(last_day)).days
    if d <= 0:
        return max(1, prev_streak)
    if d <= 1 + max(0, grace_days):
        return prev_streak + 1
    return 1


def parse_steps(text: str) -> list:
    """'3:1.1,7:1.25,30:1.5' -> [(3,1.1),(7,1.25),(30,1.5)] مرتب. ورودیِ خراب نادیده گرفته می‌شه."""
    out = []
    for part in str(text or "").split(","):
        a, _, b = part.strip().partition(":")
        try:
            out.append((int(a), float(b)))
        except ValueError:
            continue
    return sorted(out)


def streak_multiplier(streak: int, steps) -> float:
    m = 1.0
    for need, mult in steps:
        if streak >= need:
            m = mult
    return m


# ---------------------------------------------------------------------------
# پاداش: «ساعتِ درآمدِ خودِ بازیکن» با کف/سقف  ->  برای هر ثروتی معنی‌دار، بدونِ تورمِ بی‌حد
# ---------------------------------------------------------------------------
def reward_hop(ref_hours: float, abs_hop: float, hourly_income: float, floor_hourly: float,
               min_hop: float, max_hop: float, multiplier: float = 1.0) -> int:
    hourly = max(float(hourly_income or 0), float(floor_hourly or 0))
    raw = (abs_hop + ref_hours * hourly) * multiplier
    if max_hop and max_hop > 0:
        raw = min(raw, max_hop)
    raw = max(raw, min_hop or 0)
    return int(max(0, raw))


# ---------------------------------------------------------------------------
# انتخابِ مأموریت‌های امروز (قطعی برای هر کاربر/روز؛ همه‌ی دکمه‌ها از همین لیست)
# ---------------------------------------------------------------------------
def pick_daily(defs: list, user_id: int, key: str, count: int, user_level: int = 0) -> list:
    """defs: [{'id','tier','min_level','sort'}]. از هر «رده» (tier) به ترتیب یکی انتخاب می‌کنه تا به count برسه.
    رده‌ها: 1=آسان، 2=متوسط، 3=سخت (اگه رده‌ای خالی بود، از بقیه پر می‌شه)."""
    elig = [d for d in defs if (d.get("min_level") or 0) <= user_level]
    if not elig or count <= 0:
        return []
    r = random.Random(f"mission|{user_id}|{key}")
    tiers = {}
    for d in sorted(elig, key=lambda x: (x.get("sort", 0), x["id"])):
        tiers.setdefault(d.get("tier", 1), []).append(d)
    chosen = []
    order = sorted(tiers)
    i = 0
    while len(chosen) < min(count, len(elig)):
        t = order[i % len(order)]
        pool = [d for d in tiers[t] if d not in chosen]
        if pool:
            chosen.append(r.choice(pool))
        i += 1
        if i > 10 * (count + len(order)):
            break
    return chosen


def progress_bar(cur: int, target: int, width: int = 10) -> str:
    target = max(1, int(target))
    f = int(width * min(cur, target) / target)
    return "▰" * f + "▱" * (width - f)
