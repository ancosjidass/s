# -*- coding: utf-8 -*-
"""
قبیله (بخش ۳): رتبه‌ها (۵ سطح مثل CoC)، درخواستِ عضویت، اخراج/ارتقا/انتقالِ مالکیت، خزانه،
تسویه، تحقیقات، جنگ قبیله، کودتا، دیپلماسی، اهدای نیرو، لیگِ هفتگی و tick.

رتبه‌ها (نام‌ها از کانفیگ war_clan_rank_names): ۱ عضو، ۲ ارشد، ۳ افسر، ۴ معاون، ۵ سازنده.
حداقل رتبه‌ی هر اقدام از war_clan_perms (پنلِ ادمین) - هیچ‌چیزِ مهمی هاردکد نیست.
"""
import datetime
import json
import logging
import math
import random

from sqlalchemy import func

import db
import war_db as W
import war_svc as S
from war_svc import WarError, cf, ci, cs, utcnow

logger = logging.getLogger(__name__)

# ---------------------------------------------------------------------------
# رتبه/دسترسی
# ---------------------------------------------------------------------------

DEFAULT_RANKS = ["عضو", "ارشد", "افسر", "معاون", "سازنده"]
LEADER_RANK = 5
RANK_EMOJI = {1: "👤", 2: "🎖", 3: "⭐", 4: "🛡", 5: "👑"}


def rank_names(session):
    names = [x.strip() for x in cs(session, "war_clan_rank_names", "").split(",") if x.strip()]
    return names if len(names) == 5 else DEFAULT_RANKS


def rank_label(session, r) -> str:
    r = max(1, min(5, int(r)))
    return f"{RANK_EMOJI[r]} {rank_names(session)[r - 1]}"


def perms(session) -> dict:
    try:
        return json.loads(cs(session, "war_clan_perms", "{}"))
    except ValueError:
        return {}


def can(session, member, action) -> bool:
    if member is None:
        return False
    need = int(perms(session).get(action, LEADER_RANK))
    return member.rank >= need


def need(session, member, action, msg=None):
    if not can(session, member, action):
        need_r = int(perms(session).get(action, LEADER_RANK))
        raise WarError(msg or f"⛔️ این کار حداقل رتبه‌ی «{rank_names(session)[need_r - 1]}» می‌خواد.")


def member_of(session, uid):
    return session.get(W.WarClanMember, uid)


def clan_of(session, uid):
    m = member_of(session, uid)
    return (session.get(W.WarClan, m.clan_id), m) if m else (None, None)


def member_count(session, clan_id) -> int:
    return session.query(W.WarClanMember).filter_by(clan_id=clan_id).count()


def capacity(session, clan) -> int:
    cap = ci(session, "war_clan_capacity_base", 10) + ci(session, "war_clan_capacity_per_level", 3) * (clan.level - 1)
    return min(ci(session, "war_clan_max_members", 25), cap)


def clan_log(session, clan_id, text):
    session.add(W.WarClanLog(clan_id=clan_id, text=text))


def clan_xp_required(session, level) -> float:
    return cf(session, "war_clan_xp_base", 1500) * (cf(session, "war_clan_xp_growth", 1.55) ** (level - 1))


def clan_add_xp(session, clan_id, amount):
    c = session.get(W.WarClan, clan_id)
    if not c or amount <= 0:
        return 0
    c.xp += amount
    c.last_active_at = utcnow()
    ups = 0
    mx = ci(session, "war_clan_max_level", 10)
    while c.level < mx and c.xp >= clan_xp_required(session, c.level):
        c.xp -= clan_xp_required(session, c.level)
        c.level += 1
        ups += 1
        clan_log(session, c.id, f"🎉 قبیله به سطح {c.level} رسید")
    return ups


def add_contribution(session, uid, amount):
    m = member_of(session, uid)
    if m and amount > 0:
        m.contribution += amount
        m.week_contribution += amount


def treasury_cap(session, clan) -> float:
    return cf(session, "war_treasury_cap_hours", 300) * S.ref_hourly(session, 10 * 3 - 2) * (0.5 + 0.1 * clan.level)


def treasury_tx(session, clan, amount, ttype, reason, uid=None, ref=None):
    clan.treasury += amount
    if clan.treasury < -1e-6:
        raise WarError("خزانه‌ی قبیله کافی نیست.")
    session.add(W.WarClanTx(clan_id=clan.id, user_id=uid, amount=amount, type=ttype, reason=reason,
                            reference_id=None if ref is None else str(ref), balance_after=clan.treasury))


# ---------------------------------------------------------------------------
# ساخت / عضویت
# ---------------------------------------------------------------------------

def _valid_name(name):
    name = (name or "").strip()
    if not 3 <= len(name) <= 20 or "\n" in name:
        raise WarError("نامِ قبیله باید ۳ تا ۲۰ نویسه باشه.")
    return name


def _valid_tag(tag):
    tag = (tag or "").strip().upper()
    if not 2 <= len(tag) <= 5 or not tag.replace("_", "").isalnum():
        raise WarError("تگ باید ۲ تا ۵ حرف/عدد (بدونِ فاصله) باشه.")
    return tag


def leave_cooldown_left(session, uid, now=None) -> float:
    now = now or utcnow()
    last = S.metric_get(session, uid, "clan_leave_ts")
    return max(0.0, last + cf(session, "war_leave_cooldown_hours", 12) * 3600 - now.timestamp()) if last else 0.0


def _set_metric(session, uid, metric, value):
    row = session.query(W.WarMetric).filter_by(user_id=uid, metric=metric).first()
    if row is None:
        session.add(W.WarMetric(user_id=uid, metric=metric, value=value))
    else:
        row.value = value


def create_clan(session, p, name, tag):
    S.sync_player(session, p)
    S.require_feature(session, p, "clan")
    if p.clan_id:
        raise WarError("تو الان عضوِ یه قبیله‌ای.")
    if p.th_level < ci(session, "war_clan_create_min_th", 2):
        raise WarError(f"برای ساختِ قبیله مقر باید حداقل سطح {ci(session, 'war_clan_create_min_th', 2)} باشه.")
    left = leave_cooldown_left(session, p.user_id)
    if left > 0:
        raise WarError(f"⏳ بعد از ترکِ قبیله باید {int(left // 60)} دقیقه صبر کنی.")
    name, tag = _valid_name(name), _valid_tag(tag)
    if session.query(W.WarClan).filter(func.lower(W.WarClan.name) == name.lower(), W.WarClan.disbanded == False).first():  # noqa: E712
        raise WarError("این نام قبلاً گرفته شده.")
    if session.query(W.WarClan).filter(W.WarClan.tag == tag, W.WarClan.disbanded == False).first():  # noqa: E712
        raise WarError("این تگ قبلاً گرفته شده.")
    cost = round(cf(session, "war_clan_create_ref_hours", 5) * S.player_ref(session, p), -1)
    S.hop_apply(session, session.get(db.User, p.user_id), -cost, "SPEND", "war:clan_create")
    c = W.WarClan(name=name, tag=tag, leader_id=p.user_id)
    session.add(c)
    session.flush()
    session.add(W.WarClanMember(user_id=p.user_id, clan_id=c.id, rank=LEADER_RANK))
    p.clan_id = c.id
    for pending in session.query(W.WarClanRequest).filter_by(user_id=p.user_id, status="pending").all():
        pending.status = "cancelled"
    clan_log(session, c.id, f"🏰 قبیله توسط {_nm(session, p.user_id)} ساخته شد")
    S.metric_bump(session, p.user_id, "joined_clan", 1)
    S.audit(session, p.user_id, "clan_create", clan=c.id, cost=cost)
    return c, cost


def _nm(session, uid):
    u = session.get(db.User, uid)
    return u.display_name() if u else str(uid)


def suggest_clans(session, p, limit=None):
    """قبیله‌های پیشنهادی: ظرفیت‌دار، شرط‌هاش با تو جور، فعال‌تر و بزرگ‌تر اول."""
    limit = limit or ci(session, "war_clan_suggest_count", 6)
    lvl = S.player_level(session, p)
    out = []
    for c in session.query(W.WarClan).filter(W.WarClan.disbanded == False, W.WarClan.join_mode == "request").all():  # noqa: E712
        cnt = member_count(session, c.id)
        if cnt >= capacity(session, c) or p.trophies < c.min_trophies or lvl < c.min_level:
            continue
        active = 1.0 if (utcnow() - (c.last_active_at or c.created_at)).total_seconds() < 3 * 86400 else 0.4
        fit = 1.0 / (1.0 + abs(c.min_trophies - p.trophies) / 500.0)
        out.append((active * (1 + c.level * 0.15) * (0.6 + fit) + random.random() * 0.2, c, cnt))
    out.sort(key=lambda t: -t[0])
    return [(c, cnt) for _, c, cnt in out[:limit]]


def search_clans(session, query, limit=8):
    from war_text import normalize
    q = normalize(query)
    if len(q) < 2:
        raise WarError("حداقل ۲ حرف بنویس.")
    res = []
    for c in session.query(W.WarClan).filter(W.WarClan.disbanded == False).all():  # noqa: E712
        if q in normalize(c.name) or q == normalize(c.tag):
            res.append((c, member_count(session, c.id)))
    return res[:limit]


def applicant_card(session, uid) -> dict:
    """مشخصاتی که سازنده/معاون موقعِ تصمیم می‌بینه (مثل CoC)."""
    p = session.get(W.WarPlayer, uid)
    if not p:
        return {"name": _nm(session, uid), "level": 1, "th": 1, "trophies": 0, "wins": 0, "stars": 0, "ach": 0}
    ach = session.query(W.WarAchievement).filter_by(user_id=uid).count()
    return {"name": _nm(session, uid), "level": S.player_level(session, p), "th": p.th_level, "trophies": p.trophies,
            "wins": p.wins, "stars": p.stars_total, "ach": ach,
            "attacks": p.attacks, "days": max(0, (utcnow() - p.created_at).days)}


def send_request(session, p, clan_id, message=""):
    S.require_feature(session, p, "clan")
    if p.clan_id:
        raise WarError("تو الان عضوِ یه قبیله‌ای.")
    c = session.get(W.WarClan, clan_id)
    if not c or c.disbanded:
        raise WarError("قبیله پیدا نشد.")
    if c.join_mode != "request":
        raise WarError("این قبیله الان عضو نمی‌گیره.")
    lvl = S.player_level(session, p)
    if p.trophies < c.min_trophies or lvl < c.min_level:
        raise WarError(f"شرطِ ورود: {c.min_trophies} کاپ و سطح {c.min_level}.")
    if member_count(session, c.id) >= capacity(session, c):
        raise WarError("ظرفیتِ این قبیله پره.")
    left = leave_cooldown_left(session, p.user_id)
    if left > 0:
        raise WarError(f"⏳ {int(left // 60)} دقیقه‌ی دیگه می‌تونی درخواست بدی.")
    pend = session.query(W.WarClanRequest).filter_by(user_id=p.user_id, status="pending").count()
    if pend >= ci(session, "war_clan_max_pending_requests", 3):
        raise WarError("درخواست‌های بازت به سقف رسیده؛ یکی رو لغو کن.")
    if session.query(W.WarClanRequest).filter_by(user_id=p.user_id, clan_id=clan_id, status="pending").first():
        raise WarError("قبلاً به این قبیله درخواست دادی.")
    r = W.WarClanRequest(clan_id=clan_id, user_id=p.user_id, message=(message or "")[:80])
    session.add(r)
    session.flush()
    S.audit(session, p.user_id, "clan_request", clan=clan_id)
    return r


def pending_requests(session, clan_id):
    return session.query(W.WarClanRequest).filter_by(clan_id=clan_id, status="pending").order_by(W.WarClanRequest.created_at).all()


def my_requests(session, uid):
    return session.query(W.WarClanRequest).filter_by(user_id=uid, status="pending").all()


def cancel_request(session, uid, req_id):
    n = session.query(W.WarClanRequest).filter(W.WarClanRequest.id == req_id, W.WarClanRequest.user_id == uid,
                                               W.WarClanRequest.status == "pending").update({"status": "cancelled", "decided_at": utcnow()}, synchronize_session=False)
    if n != 1:
        raise WarError("درخواست پیدا نشد.")


def decide_request(session, actor_id, req_id, accept: bool):
    """فقط رتبه‌ی accept_requests به بالا. برمی‌گردونه (applicant_id, clan)."""
    am = member_of(session, actor_id)
    need(session, am, "accept_requests")
    n = session.query(W.WarClanRequest).filter(W.WarClanRequest.id == req_id, W.WarClanRequest.clan_id == am.clan_id,
                                               W.WarClanRequest.status == "pending").update(
        {"status": "accepted" if accept else "rejected", "decided_by": actor_id, "decided_at": utcnow()}, synchronize_session=False)
    if n != 1:
        raise WarError("این درخواست دیگه معتبر نیست.")
    r = session.get(W.WarClanRequest, req_id)
    c = session.get(W.WarClan, am.clan_id)
    if not accept:
        return r.user_id, c
    ap = S.get_player(session, r.user_id)
    if ap.clan_id:
        r.status = "cancelled"
        raise WarError("متقاضی الان عضوِ قبیله‌ی دیگه‌ایه.")
    if member_count(session, c.id) >= capacity(session, c):
        r.status = "pending"
        raise WarError("ظرفیتِ قبیله پره.")
    session.add(W.WarClanMember(user_id=r.user_id, clan_id=c.id, rank=1))
    ap.clan_id = c.id
    for other in session.query(W.WarClanRequest).filter(W.WarClanRequest.user_id == r.user_id, W.WarClanRequest.status == "pending").all():
        other.status = "cancelled"
    clan_log(session, c.id, f"➕ {_nm(session, r.user_id)} به قبیله پیوست (تأییدِ {_nm(session, actor_id)})")
    S.metric_bump(session, r.user_id, "joined_clan", 1)
    S.audit(session, actor_id, "clan_accept", clan=c.id, user=r.user_id)
    return r.user_id, c


def expire_requests(session, now=None):
    now = now or utcnow()
    ttl = cf(session, "war_clan_request_ttl_hours", 48)
    return session.query(W.WarClanRequest).filter(W.WarClanRequest.status == "pending",
                                                  W.WarClanRequest.created_at < now - datetime.timedelta(hours=ttl)).update(
        {"status": "expired", "decided_at": now}, synchronize_session=False)


def members_list(session, clan_id):
    rows = session.query(W.WarClanMember).filter_by(clan_id=clan_id).order_by(W.WarClanMember.rank.desc(), W.WarClanMember.contribution.desc()).all()
    return rows


def set_join_rules(session, actor_id, mode=None, min_trophies=None, min_level=None, desc=None):
    m = member_of(session, actor_id)
    need(session, m, "edit")
    c = session.get(W.WarClan, m.clan_id)
    if mode in ("request", "closed"):
        c.join_mode = mode
    if min_trophies is not None:
        c.min_trophies = max(0, int(min_trophies))
    if min_level is not None:
        c.min_level = max(0, int(min_level))
    if desc is not None:
        c.description = desc[:120]
    return c


# ---------------------------------------------------------------------------
# مدیریتِ اعضا: ارتقا/تنزل/اخراج/انتقالِ مالکیت/ترک
# ---------------------------------------------------------------------------

def set_rank(session, actor_id, target_id, new_rank):
    """ارتقا/تنزل - فقط سازنده (perm promote). سازنده شدن فقط از راهِ transfer."""
    am, tm = member_of(session, actor_id), member_of(session, target_id)
    need(session, am, "promote")
    if not tm or tm.clan_id != am.clan_id:
        raise WarError("این نفر عضوِ قبیله‌ی تو نیست.")
    if target_id == actor_id:
        raise WarError("رتبه‌ی خودت رو نمی‌تونی عوض کنی.")
    new_rank = int(new_rank)
    if not 1 <= new_rank <= LEADER_RANK - 1:
        raise WarError("رتبه‌ی نامعتبر (برای سازنده‌شدن از «انتقالِ مالکیت» استفاده کن).")
    if tm.rank == new_rank:
        raise WarError("هم‌اکنون همین رتبه رو داره.")
    old = tm.rank
    tm.rank = new_rank
    tm.last_promoted_at = utcnow()
    verb = "ارتقا" if new_rank > old else "تنزل"
    clan_log(session, am.clan_id, f"{'⬆️' if new_rank > old else '⬇️'} {_nm(session, target_id)} {verb} یافت: {rank_names(session)[old - 1]} ← {rank_names(session)[new_rank - 1]}")
    S.audit(session, actor_id, "clan_rank", target=target_id, old=old, new=new_rank)
    return old, new_rank


def can_kick(session, actor_m, target_m) -> bool:
    if not can(session, actor_m, "kick") or target_m.rank >= actor_m.rank:
        return False
    if actor_m.rank >= LEADER_RANK:
        return True
    return target_m.rank <= ci(session, "war_clan_coleader_kick_max_rank", 1)


def kick(session, actor_id, target_id):
    am, tm = member_of(session, actor_id), member_of(session, target_id)
    if not am or not tm or am.clan_id != tm.clan_id:
        raise WarError("این نفر عضوِ قبیله‌ی تو نیست.")
    if target_id == actor_id:
        raise WarError("خودت رو نمی‌تونی اخراج کنی؛ «ترکِ قبیله» رو بزن.")
    if not can(session, am, "kick"):
        need(session, am, "kick")
    if not can_kick(session, am, tm):
        raise WarError("⛔️ با رتبه‌ی فعلی فقط عضوهای رتبه‌ی پایین رو می‌تونی اخراج کنی.")
    _remove_member(session, tm, f"🚪 {_nm(session, target_id)} توسط {_nm(session, actor_id)} اخراج شد", kicked=True)
    S.audit(session, actor_id, "clan_kick", target=target_id)


def _in_active_war(session, clan_id, uid) -> bool:
    q = session.query(W.WarClanWarMember).join(W.WarClanWar, W.WarClanWar.id == W.WarClanWarMember.war_id).filter(
        W.WarClanWarMember.user_id == uid, W.WarClanWar.status.in_(("prep", "active")))
    return q.first() is not None


def _remove_member(session, m, log_text, kicked=False):
    uid, cid = m.user_id, m.clan_id
    if session.query(W.WarBattle).filter(W.WarBattle.attacker_id == uid, W.WarBattle.status == "marching",
                                         W.WarBattle.clan_war_id.isnot(None)).first():
        raise WarError("عضو الان وسطِ یه نبردِ جنگ قبیله‌ست؛ بعد از پایانش.")
    clan_log(session, cid, f"{log_text} (مشارکتِ ثبت‌شده: {m.contribution:.0f})")
    session.query(W.WarDonation).filter(W.WarDonation.requester_id == uid, W.WarDonation.status == "open").update({"status": "cancelled"}, synchronize_session=False)
    session.delete(m)
    p = session.get(W.WarPlayer, uid)
    if p:
        p.clan_id = None
    if not kicked:
        _set_metric(session, uid, "clan_leave_ts", utcnow().timestamp())


def leave_clan(session, uid):
    m = member_of(session, uid)
    if not m:
        raise WarError("عضوِ قبیله‌ای نیستی.")
    if m.rank >= LEADER_RANK:
        if member_count(session, m.clan_id) > 1:
            raise WarError("سازنده تا وقتی قبیله عضو داره نمی‌تونه بره؛ اول مالکیت رو منتقل کن.")
        return disband(session, uid)
    if _in_active_war(session, m.clan_id, uid):
        raise WarError("تا پایانِ جنگِ قبیله نمی‌تونی ترک کنی.")
    _remove_member(session, m, f"🚪 {_nm(session, uid)} قبیله رو ترک کرد")
    S.audit(session, uid, "clan_leave")
    return None


def transfer_leadership(session, actor_id, target_id):
    am, tm = member_of(session, actor_id), member_of(session, target_id)
    need(session, am, "transfer")
    if not tm or tm.clan_id != am.clan_id or target_id == actor_id:
        raise WarError("نفرِ انتخابی معتبر نیست.")
    c = session.get(W.WarClan, am.clan_id)
    tm.rank, am.rank = LEADER_RANK, LEADER_RANK - 1
    c.leader_id = target_id
    clan_log(session, c.id, f"👑 مالکیت از {_nm(session, actor_id)} به {_nm(session, target_id)} منتقل شد")
    S.audit(session, actor_id, "clan_transfer", target=target_id)


def disband(session, actor_id):
    m = member_of(session, actor_id)
    need(session, m, "disband")
    c = session.get(W.WarClan, m.clan_id)
    if member_count(session, c.id) > 1:
        raise WarError("قبیله هنوز عضو داره.")
    if session.query(W.WarClanWar).filter(W.WarClanWar.status.in_(("prep", "active")), (W.WarClanWar.clan_a == c.id) | (W.WarClanWar.clan_b == c.id)).first():
        raise WarError("قبیله در جنگه.")
    if c.treasury > 0:
        S.hop_apply(session, session.get(db.User, actor_id), math.floor(c.treasury), "REFUND", "war:clan_disband_treasury", ref=f"clan:{c.id}")
        treasury_tx(session, c, -c.treasury, "expense", "disband_refund", actor_id)
    session.delete(m)
    p = session.get(W.WarPlayer, actor_id)
    if p:
        p.clan_id = None
    c.disbanded = True
    c.name = f"{c.name}#{c.id}x"
    c.tag = f"{c.tag[:3]}{c.id}x"[:8]
    S.audit(session, actor_id, "clan_disband", clan=c.id)
    return True


# ---------------------------------------------------------------------------
# خزانه / تسویه
# ---------------------------------------------------------------------------

def deposit(session, p, amount):
    S.sync_player(session, p)
    m = member_of(session, p.user_id)
    if not m:
        raise WarError("عضوِ قبیله‌ای نیستی.")
    need(session, m, "donate_request" if False else "donate_request")
    c = session.get(W.WarClan, m.clan_id)
    amount = math.floor(float(amount))
    ref1 = S.player_ref(session, p)
    if amount < cf(session, "war_deposit_min_ref_hours", 0.05) * ref1:
        raise WarError(f"حداقلِ کمک {int(cf(session, 'war_deposit_min_ref_hours', 0.05) * ref1):,} هاپ ـه.")
    room = treasury_cap(session, c) - c.treasury
    if room <= 0:
        raise WarError("خزانه پره؛ سطحِ قبیله رو بالا ببرید.")
    amount = min(amount, math.floor(room))
    S.hop_apply(session, session.get(db.User, p.user_id), -amount, "SPEND", "war:clan_deposit", ref=f"clan:{c.id}")
    treasury_tx(session, c, amount, "deposit", "member_deposit", p.user_id, ref=f"u{p.user_id}")
    m.deposits_total += amount
    # مشارکت از پول خریدنی نیست: سقفِ روزانه
    day = utcnow().strftime("%Y-%m-%d")
    key = f"dep_contrib_{day}"
    got = S.metric_get(session, p.user_id, key)
    ref_h = S.ref_hourly(session, 1)
    gain = min(amount / max(1.0, ref_h) * cf(session, "war_deposit_contrib_per_ref_hour", 10), max(0.0, cf(session, "war_deposit_contrib_daily_cap", 60) - got))
    _set_metric(session, p.user_id, key, got + gain)
    add_contribution(session, p.user_id, gain)
    cnt_key = f"dep_reward_{day}"
    if S.metric_get(session, p.user_id, cnt_key) < 3:
        _set_metric(session, p.user_id, cnt_key, S.metric_get(session, p.user_id, cnt_key) + 1)
        S.give_reward(session, p.user_id, "deposit", ref=f"dep:{c.id}", _player=p)
    S.metric_bump(session, p.user_id, "deposits", 1)
    c.last_active_at = utcnow()
    S.audit(session, p.user_id, "clan_deposit", clan=c.id, amount=amount)
    return amount, gain


def run_settlement(session, clan, now=None, force=False):
    """تسویه‌ی دوره‌ای: فقط درصدِ مشخصی از خزانه (Pool) بین اعضا به‌نسبتِ مشارکت. هیچ‌کس کلِ خزانه رو نمی‌بره."""
    now = now or utcnow()
    days = cf(session, "war_settle_days", 7)
    if not force and (now - clan.last_settlement_at).total_seconds() < days * 86400:
        return None
    pool = math.floor(clan.treasury * cf(session, "war_settle_pool_pct", 20) / 100)
    members = [m for m in members_list(session, clan.id) if m.week_contribution >= cf(session, "war_settle_min_contribution", 20)]
    total_w = sum(m.week_contribution for m in members)
    paid = 0
    payouts = []
    if pool > 0 and total_w > 0:
        cap_each = pool * cf(session, "war_settle_member_cap_pct", 25) / 100
        for m in members:
            share = min(pool * m.week_contribution / total_w, cap_each)
            mp = session.get(W.WarPlayer, m.user_id)
            share = min(share, cf(session, "war_settle_max_ref_hours", 30) * S.player_ref(session, mp))
            share = math.floor(share)
            if share <= 0:
                continue
            S.hop_apply(session, session.get(db.User, m.user_id), share, "CLAN_REWARD", "war:clan_settlement", ref=f"clan:{clan.id}:{now.date()}")
            m.settled_total += share
            paid += share
            payouts.append((m.user_id, share))
        if paid:
            treasury_tx(session, clan, -paid, "settlement", f"weekly_settlement:{now.date()}")
    for m in members_list(session, clan.id):
        m.week_contribution = 0
    clan.last_settlement_at = now
    clan_log(session, clan.id, f"💸 تسویه‌ی دوره‌ای: {paid:,} هاپ بینِ {len(payouts)} عضو پخش شد")
    S.audit(session, None, "clan_settlement", clan=clan.id, paid=paid, pool=pool)
    return {"paid": paid, "payouts": payouts, "pool": pool}


# ---------------------------------------------------------------------------
# تحقیقات
# ---------------------------------------------------------------------------

def research_state(session, clan_id):
    return {r.key: r for r in session.query(W.WarClanResearch).filter_by(clan_id=clan_id).all()}


def research_cost(session, clan, d, cur_level):
    hop = d.cost_ref_hours * S.ref_hourly(session, clan.level * 3) * (1 + 0.6 * cur_level)
    return round(hop, -1), int(d.time_minutes * (1 + 0.5 * cur_level))


def start_research(session, actor_id, key):
    am = member_of(session, actor_id)
    need(session, am, "research")
    p = S.get_player(session, actor_id)
    S.require_feature(session, p, "clan_research")
    c = session.get(W.WarClan, am.clan_id)
    d = session.get(W.WarResearchDef, key)
    if not d or not d.enabled:
        raise WarError("تحقیق پیدا نشد.")
    if c.level < d.req_clan_level:
        raise WarError(f"سطحِ قبیله باید {d.req_clan_level} باشه.")
    st = research_state(session, c.id)
    if any(r.upgrade_finish_at for r in st.values()):
        raise WarError("یه تحقیقِ دیگه در جریانه.")
    cur = st[key].level if key in st else 0
    if cur >= d.max_level:
        raise WarError("این تحقیق کامل شده.")
    cost, mins = research_cost(session, c, d, cur)
    treasury_tx(session, c, -cost, "expense", f"research:{key}:{cur + 1}", actor_id)
    row = st.get(key)
    if row is None:
        row = W.WarClanResearch(clan_id=c.id, key=key, level=0)
        session.add(row)
    row.upgrade_finish_at = utcnow() + datetime.timedelta(minutes=mins)
    clan_log(session, c.id, f"🔬 تحقیقِ «{d.name}» شروع شد (سطح {cur + 1})")
    S.audit(session, actor_id, "research_start", key=key, cost=cost)
    return cost, mins


def finish_research(session, now=None):
    now = now or utcnow()
    n = 0
    for r in session.query(W.WarClanResearch).filter(W.WarClanResearch.upgrade_finish_at.isnot(None), W.WarClanResearch.upgrade_finish_at <= now).all():
        r.level += 1
        r.upgrade_finish_at = None
        d = session.get(W.WarResearchDef, r.key)
        clan_log(session, r.clan_id, f"✅ تحقیقِ «{d.name if d else r.key}» به سطح {r.level} رسید")
        n += 1
    return n


# ---------------------------------------------------------------------------
# دیپلماسی
# ---------------------------------------------------------------------------

def _rel(session, a, b, create=True):
    x, y = (a, b) if a < b else (b, a)
    r = session.query(W.WarRelation).filter_by(clan_a=x, clan_b=y).first()
    if r is None and create:
        r = W.WarRelation(clan_a=x, clan_b=y, kind="neutral", score=0)
        session.add(r)
        session.flush()
    return r


def relations_of(session, clan_id):
    out = []
    for r in session.query(W.WarRelation).filter((W.WarRelation.clan_a == clan_id) | (W.WarRelation.clan_b == clan_id)).all():
        if r.kind == "neutral":
            continue
        other = r.clan_b if r.clan_a == clan_id else r.clan_a
        oc = session.get(W.WarClan, other)
        if oc and not oc.disbanded:
            out.append((r, oc))
    return out


def propose_relation(session, actor_id, other_id, kind):
    am = member_of(session, actor_id)
    need(session, am, "diplomacy")
    p = S.get_player(session, actor_id)
    S.require_feature(session, p, "diplomacy")
    me, other = session.get(W.WarClan, am.clan_id), session.get(W.WarClan, other_id)
    if not other or other.disbanded or other.id == me.id:
        raise WarError("قبیله‌ی مقصد معتبر نیست.")
    r = _rel(session, me.id, other.id)
    now = utcnow()
    if kind == "enemy":
        if r.kind in ("ally",):
            raise WarError("اول پیمان رو بشکن.")
        r.kind, r.score, r.until = "enemy", -100, None
        clan_log(session, me.id, f"⚔️ {other.name} دشمن اعلام شد")
        return r, False
    if kind == "ally":
        if min(me.level, other.level) < ci(session, "war_dip_ally_min_clan_level", 3):
            raise WarError(f"هر دو قبیله باید حداقل سطح {ci(session, 'war_dip_ally_min_clan_level', 3)} باشن.")
        mx = ci(session, "war_dip_max_allies", 2)
        for cid in (me.id, other.id):
            if sum(1 for rr, _ in relations_of(session, cid) if rr.kind == "ally") >= mx:
                raise WarError("سقفِ هم‌پیمان‌ها پر شده.")
    elif kind != "truce":
        raise WarError("نوعِ رابطه نامعتبره.")
    if r.kind == f"pending_{kind}" and r.proposer == other.id:
        return respond_relation(session, actor_id, r.id, True)
    if r.kind in ("ally",) or (r.kind == "truce" and r.until and r.until > now):
        raise WarError("رابطه‌ی فعال از قبل وجود داره.")
    r.kind, r.proposer = f"pending_{kind}", me.id
    return r, True


def respond_relation(session, actor_id, rel_id, accept: bool):
    am = member_of(session, actor_id)
    need(session, am, "diplomacy")
    r = session.get(W.WarRelation, rel_id)
    if not r or not r.kind.startswith("pending_") or am.clan_id not in (r.clan_a, r.clan_b) or r.proposer == am.clan_id:
        raise WarError("درخواست معتبر نیست.")
    kind = r.kind.replace("pending_", "")
    if not accept:
        r.kind, r.proposer = "neutral", None
        return r, False
    now = utcnow()
    if kind == "truce":
        r.kind, r.until, r.score = "truce", now + datetime.timedelta(hours=cf(session, "war_dip_truce_hours", 12)), 30
    else:
        r.kind, r.until, r.score = "ally", None, 100
    a, b = session.get(W.WarClan, r.clan_a), session.get(W.WarClan, r.clan_b)
    for x, y in ((a, b), (b, a)):
        clan_log(session, x.id, f"🤝 {'پیمانِ هم‌پیمانی' if kind == 'ally' else 'آتش‌بس'} با {y.name} برقرار شد")
    return r, True


def break_relation(session, actor_id, other_id):
    am = member_of(session, actor_id)
    need(session, am, "diplomacy")
    r = _rel(session, am.clan_id, other_id, create=False)
    if not r or r.kind == "neutral":
        raise WarError("رابطه‌ای وجود نداره.")
    r.kind, r.until, r.proposer, r.score = "neutral", None, None, 0
    return r


# ---------------------------------------------------------------------------
# اهدای نیرو (Clan Castle)
# ---------------------------------------------------------------------------

def request_units(session, p, unit_key, qty):
    m = member_of(session, p.user_id)
    need(session, m, "donate_request")
    d = session.get(W.WarUnitDef, unit_key)
    if not d or not d.enabled:
        raise WarError("تجهیز نامعتبر.")
    qty = int(qty)
    if not 1 <= qty <= ci(session, "war_donate_max_request", 10):
        raise WarError(f"تعداد باید بین ۱ و {ci(session, 'war_donate_max_request', 10)} باشه.")
    if session.query(W.WarDonation).filter_by(requester_id=p.user_id, status="open").first():
        raise WarError("یه درخواستِ بازِ دیگه داری.")
    if S.housing_used(session, p.user_id) + qty * d.housing > S.camp_capacity(session, p):
        raise WarError("🏕 ظرفیتِ پادگانت کافی نیست.")
    r = W.WarDonation(clan_id=m.clan_id, requester_id=p.user_id, unit_key=unit_key, qty=qty)
    session.add(r)
    session.flush()
    return r


def open_requests(session, clan_id, exclude_uid=None):
    q = session.query(W.WarDonation).filter_by(clan_id=clan_id, status="open")
    if exclude_uid:
        q = q.filter(W.WarDonation.requester_id != exclude_uid)
    return q.order_by(W.WarDonation.created_at).limit(20).all()


def donate(session, donor, req_id, qty):
    """انتقالِ واقعیِ واحد (بدونِ تولیدِ چیزِ جدید): دهنده کم، گیرنده اضافه؛ دهنده مشارکت می‌گیره."""
    dm = member_of(session, donor.user_id)
    r = session.get(W.WarDonation, req_id)
    if not dm or not r or r.status != "open" or r.clan_id != dm.clan_id or r.requester_id == donor.user_id:
        raise WarError("این درخواست معتبر نیست.")
    day = utcnow().strftime("%Y-%m-%d")
    key = f"donated_{day}"
    done = S.metric_get(session, donor.user_id, key)
    qty = min(int(qty), r.qty - r.filled, int(ci(session, "war_donate_daily_cap", 40) - done))
    if qty <= 0:
        raise WarError("سقفِ اهدای امروزت پر شده یا درخواست کامل شده.")
    du = session.query(W.WarUnit).filter_by(user_id=donor.user_id, unit_key=r.unit_key).first()
    if not du or du.healthy < qty:
        raise WarError("واحدِ سالمِ کافی نداری.")
    n = session.query(W.WarDonation).filter(W.WarDonation.id == r.id, W.WarDonation.status == "open", W.WarDonation.filled + qty <= W.WarDonation.qty).update(
        {"filled": W.WarDonation.filled + qty}, synchronize_session=False)
    if n != 1:
        raise WarError("درخواست همین حالا تغییر کرد؛ دوباره امتحان کن.")
    du.healthy -= qty
    ru = session.query(W.WarUnit).filter_by(user_id=r.requester_id, unit_key=r.unit_key).first()
    if ru is None:
        ru = W.WarUnit(user_id=r.requester_id, unit_key=r.unit_key, healthy=0, damaged=0, level=1)
        session.add(ru)
    ru.healthy += qty
    session.refresh(r)
    if r.filled >= r.qty:
        r.status = "done"
    _set_metric(session, donor.user_id, key, done + qty)
    add_contribution(session, donor.user_id, qty * cf(session, "war_donate_contrib", 1))
    S.audit(session, donor.user_id, "donate", to=r.requester_id, unit=r.unit_key, qty=qty)
    return qty, r


# ---------------------------------------------------------------------------
# کودتا (ریسک/ریوارد واقعی؛ پاداش از خزانه، نه پولِ بی‌منشأ)
# ---------------------------------------------------------------------------

def coup_preview(session, p, now=None):
    now = now or utcnow()
    m = member_of(session, p.user_id)
    if not m:
        raise WarError("عضوِ قبیله‌ای نیستی.")
    S.require_feature(session, p, "coup")
    c = session.get(W.WarClan, m.clan_id)
    if m.rank >= LEADER_RANK:
        raise WarError("تو خودت سازنده‌ای.")
    days = (now - m.joined_at).total_seconds() / 86400
    if days < cf(session, "war_coup_min_membership_days", 3):
        raise WarError(f"حداقل {cf(session, 'war_coup_min_membership_days', 3):g} روز باید عضو باشی.")
    if m.contribution < cf(session, "war_coup_min_contribution", 50):
        raise WarError(f"مشارکتت باید حداقل {cf(session, 'war_coup_min_contribution', 50):g} باشه.")
    if p.xp < cf(session, "war_coup_min_xp", 1500):
        raise WarError(f"XP شخصی‌ت باید حداقل {cf(session, 'war_coup_min_xp', 1500):,.0f} باشه.")
    if p.coup_cooldown_until and p.coup_cooldown_until > now:
        raise WarError("⏳ کول‌دان کودتات تموم نشده.")
    if c.coup_cooldown_until and c.coup_cooldown_until > now:
        raise WarError("⏳ این قبیله به‌تازگی کودتا دیده؛ صبر کن.")
    leader = member_of(session, c.leader_id)
    lp = session.get(W.WarPlayer, c.leader_id)
    chance = cf(session, "war_coup_base_chance_pct", 20)
    ratio = m.contribution / max(1.0, leader.contribution if leader else 1.0)
    chance += min(25.0, 25.0 * ratio)
    chance += (m.rank - 1) * 5
    if lp and (now - (lp.last_seen_at or now)).total_seconds() > cf(session, "war_coup_leader_inactive_days", 3) * 86400:
        chance += 15
    chance = min(cf(session, "war_coup_max_chance_pct", 70), chance)
    cost = cf(session, "war_coup_xp_cost", 600)
    reward = min(c.treasury * cf(session, "war_coup_reward_treasury_pct", 4) / 100, cf(session, "war_coup_reward_cap_hours", 20) * S.player_ref(session, p))
    return {"chance": chance, "xp_cost": cost, "reward": math.floor(reward), "leader": c.leader_id, "clan": c}


def attempt_coup(session, p, now=None, rng=None):
    now = now or utcnow()
    rng = rng or random
    pv = coup_preview(session, p, now)
    c = pv["clan"]
    p.xp = max(0.0, p.xp - pv["xp_cost"])                # هزینه‌ی XP همیشه کم می‌شه
    success = rng.random() * 100 < pv["chance"]
    p.coup_cooldown_until = now + datetime.timedelta(days=cf(session, "war_coup_user_cooldown_days", 7))
    reward = 0
    m = member_of(session, p.user_id)
    if success:
        old = member_of(session, c.leader_id)
        old.rank = 3
        m.rank = LEADER_RANK
        c.leader_id = p.user_id
        c.coup_cooldown_until = now + datetime.timedelta(days=cf(session, "war_coup_clan_cooldown_days", 3))
        reward = min(pv["reward"], math.floor(c.treasury))
        if reward > 0:
            treasury_tx(session, c, -reward, "coup", "coup_reward", p.user_id)
            S.hop_apply(session, session.get(db.User, p.user_id), reward, "BONUS", "war:coup_reward", ref=f"coup:{c.id}")
        S.metric_bump(session, p.user_id, "coups_won", 1)
        clan_log(session, c.id, f"🚨 کودتا! {_nm(session, p.user_id)} رهبری رو گرفت")
    else:
        p.xp = max(0.0, p.xp - cf(session, "war_coup_fail_xp_extra", 300))
        m.contribution *= 1 - cf(session, "war_coup_fail_contrib_pct", 30) / 100
        clan_log(session, c.id, f"🕵️ تلاشِ کودتای {_nm(session, p.user_id)} ناموفق بود")
    session.add(W.WarCoup(clan_id=c.id, initiator_id=p.user_id, old_leader_id=pv["leader"], success=success,
                          chance=pv["chance"], xp_cost=pv["xp_cost"], reward=reward))
    S.audit(session, p.user_id, "coup", success=success, chance=pv["chance"], reward=reward, xp=pv["xp_cost"])
    return success, pv, reward


# ---------------------------------------------------------------------------
# جنگ قبیله
# ---------------------------------------------------------------------------

def active_war_of(session, clan_id):
    return session.query(W.WarClanWar).filter(W.WarClanWar.status.in_(("prep", "active")),
                                              (W.WarClanWar.clan_a == clan_id) | (W.WarClanWar.clan_b == clan_id)).first()


def search_war(session, actor_id, size):
    am = member_of(session, actor_id)
    need(session, am, "start_war")
    p = S.get_player(session, actor_id)
    S.require_feature(session, p, "clan_war")
    c = session.get(W.WarClan, am.clan_id)
    if active_war_of(session, c.id):
        raise WarError("قبیله الان تو جنگه.")
    size = max(ci(session, "war_cw_min_size", 2), min(int(size), ci(session, "war_cw_max_size", 10), member_count(session, c.id)))
    if size < ci(session, "war_cw_min_size", 2):
        raise WarError("اعضای قبیله برای این جنگ کافی نیست.")
    c.war_search_until = utcnow() + datetime.timedelta(minutes=cf(session, "war_cw_search_timeout_minutes", 120))
    c.war_search_size = size
    clan_log(session, c.id, f"🔎 جستجوی جنگ {size} نفره شروع شد")
    return size


def cancel_search(session, actor_id):
    am = member_of(session, actor_id)
    need(session, am, "start_war")
    c = session.get(W.WarClan, am.clan_id)
    c.war_search_until, c.war_search_size = None, 0


def match_wars(session, now=None):
    now = now or utcnow()
    for c in session.query(W.WarClan).filter(W.WarClan.war_search_until.isnot(None), W.WarClan.war_search_until <= now).all():
        c.war_search_until, c.war_search_size = None, 0
    searching = session.query(W.WarClan).filter(W.WarClan.war_search_until > now, W.WarClan.disbanded == False).order_by(W.WarClan.war_search_until).all()  # noqa: E712
    gap = ci(session, "war_cw_match_level_gap", 2)
    created, used = [], set()
    import war_battle as B
    for a in searching:
        if a.id in used or active_war_of(session, a.id):
            continue
        best = None
        for b in searching:
            if b.id == a.id or b.id in used or active_war_of(session, b.id) or abs(a.level - b.level) > gap:
                continue
            if B.relation_blocks_attack(session, a.id, b.id, now):
                continue
            r = B.relation_between(session, a.id, b.id)
            score = (0 if (r and r.kind == "enemy") else 1, abs(a.level - b.level))
            if best is None or score < best[0]:
                best = (score, b)
        if best:
            b = best[1]
            size = min(a.war_search_size, b.war_search_size)
            prep_end = now + datetime.timedelta(minutes=cf(session, "war_cw_prep_minutes", 60))
            war = W.WarClanWar(clan_a=a.id, clan_b=b.id, status="prep", prep_end_at=prep_end,
                               end_at=prep_end + datetime.timedelta(minutes=cf(session, "war_cw_duration_minutes", 360)),
                               formula_version=ci(session, "war_formula_version", 1))
            session.add(war)
            session.flush()
            _set_metric(session, war.id, "cw_size_" + str(war.id), size)
            for c in (a, b):
                c.war_search_until, c.war_search_size = None, 0
                clan_log(session, c.id, f"⚔️ جنگ قبیله #{war.id} پیدا شد ({a.name} vs {b.name})")
            used.update({a.id, b.id})
            created.append(war.id)
    return created


def war_size(session, war_id) -> int:
    return int(S.metric_get(session, war_id, "cw_size_" + str(war_id))) or ci(session, "war_cw_max_size", 10)


def join_war(session, p, war_id):
    m = member_of(session, p.user_id)
    war = session.get(W.WarClanWar, war_id)
    if not m or not war or m.clan_id not in (war.clan_a, war.clan_b) or war.status == "ended":
        raise WarError("جنگ معتبر نیست.")
    if session.query(W.WarClanWarMember).filter_by(war_id=war_id, user_id=p.user_id).first():
        raise WarError("قبلاً ثبت‌نام کردی.")
    if session.query(W.WarClanWarMember).filter_by(war_id=war_id, clan_id=m.clan_id).count() >= war_size(session, war_id):
        raise WarError("لیستِ جنگِ قبیله پره.")
    import war_battle as B
    _, _, mil = B.power_of(session, p.user_id)
    session.add(W.WarClanWarMember(war_id=war_id, clan_id=m.clan_id, user_id=p.user_id, power=mil))
    return war


def war_roster(session, war_id, clan_id):
    return session.query(W.WarClanWarMember).filter_by(war_id=war_id, clan_id=clan_id).order_by(W.WarClanWarMember.power.desc()).all()


def cw_launch(session, p, war_id, target_id, comp, healthy_only=False, chat_id=None, now=None):
    now = now or utcnow()
    import war_battle as B
    war = session.get(W.WarClanWar, war_id)
    me = session.query(W.WarClanWarMember).filter_by(war_id=war_id, user_id=p.user_id).first()
    tgt = session.query(W.WarClanWarMember).filter_by(war_id=war_id, user_id=target_id).first()
    if not war or not me or not tgt or me.clan_id == tgt.clan_id:
        raise WarError("هدفِ جنگ معتبر نیست.")
    if war.status != "active" or war.end_at <= now:
        raise WarError("جنگ هنوز شروع نشده یا تموم شده.")
    if me.attacks_used >= ci(session, "war_cw_attacks_per_member", 2):
        raise WarError("حمله‌های این جنگ رو مصرف کردی.")
    b, cost = B.launch_attack(session, p, target_id, "clanwar", comp, healthy_only, chat_id, mode="clanwar", war_id=war_id, now=now)
    me.attacks_used += 1
    return b, cost


def record_cw_attack(session, battle, res):
    me = session.query(W.WarClanWarMember).filter_by(war_id=battle.clan_war_id, user_id=battle.attacker_id).first()
    tgt = session.query(W.WarClanWarMember).filter_by(war_id=battle.clan_war_id, user_id=battle.defender_id).first()
    if me:
        me.stars_scored += res["stars"]
    if tgt:
        tgt.best_stars_taken = max(tgt.best_stars_taken, res["stars"])
        tgt.best_dest_taken = max(tgt.best_dest_taken, res["destruction"])
    S.give_reward(session, battle.attacker_id, "cw_attack", scale=1.0, ref=f"battle:{battle.id}", clan_xp_scale=1.0)


def war_scores(session, war):
    sa = sum(m.best_stars_taken for m in war_roster(session, war.id, war.clan_b))
    sb = sum(m.best_stars_taken for m in war_roster(session, war.id, war.clan_a))
    da = sum(m.best_dest_taken for m in war_roster(session, war.id, war.clan_b))
    db_ = sum(m.best_dest_taken for m in war_roster(session, war.id, war.clan_a))
    return sa, sb, da, db_


def war_kills(session, war_id):
    """تعدادِ واحدِ نابودشده‌ی هر طرف (برای گزارش/دلداریِ بازنده: «۲ اف-۳۵ دشمن رو نابود کرد»)."""
    a_kills = d_kills = 0
    war = session.get(W.WarClanWar, war_id)
    for b in session.query(W.WarBattle).filter_by(clan_war_id=war_id, status="resolved").all():
        res = json.loads(b.result_json or "{}")
        killed_def = sum(v["x"] for v in res.get("def_units", {}).values())
        killed_atk = sum(v["x"] for v in res.get("atk_units", {}).values())
        am = session.query(W.WarClanWarMember).filter_by(war_id=war_id, user_id=b.attacker_id).first()
        if am and am.clan_id == war.clan_a:
            a_kills += killed_def
            d_kills += killed_atk
        else:
            d_kills += killed_def
            a_kills += killed_atk
    return a_kills, d_kills


def advance_wars(session, now=None):
    """prep→active، و پایانِ جنگ‌ها. برمی‌گردونه رویدادها برای اعلان."""
    now = now or utcnow()
    events = []
    for war in session.query(W.WarClanWar).filter(W.WarClanWar.status == "prep", W.WarClanWar.prep_end_at <= now).all():
        n_a = len(war_roster(session, war.id, war.clan_a))
        n_b = len(war_roster(session, war.id, war.clan_b))
        if min(n_a, n_b) < ci(session, "war_cw_min_size", 2):
            war.status, war.winner = "ended", "cancelled"
            for cid in (war.clan_a, war.clan_b):
                clan_log(session, cid, f"⚠️ جنگ #{war.id} به‌خاطرِ کمبودِ شرکت‌کننده لغو شد")
            events.append({"type": "cw_cancel", "war_id": war.id})
        else:
            war.status = "active"
            events.append({"type": "cw_start", "war_id": war.id})
    for war in session.query(W.WarClanWar).filter(W.WarClanWar.status == "active", W.WarClanWar.end_at <= now).all():
        live = session.query(W.WarBattle).filter_by(clan_war_id=war.id, status="marching").count()
        if live and now < war.end_at + datetime.timedelta(minutes=30):
            continue
        for b in session.query(W.WarBattle).filter_by(clan_war_id=war.id, status="marching").all():
            import war_battle as B
            B.cancel_battle(session, b.id, "cw_timeout", 50)
        end_war(session, war, now)
        events.append({"type": "cw_end", "war_id": war.id})
    return events


def end_war(session, war, now):
    sa, sb, da, dbb = war_scores(session, war)
    war.stars_a, war.stars_b, war.dest_a, war.dest_b = sa, sb, da, dbb
    if sa != sb:
        war.winner = "a" if sa > sb else "b"
    elif abs(da - dbb) > 1e-6:
        war.winner = "a" if da > dbb else "b"
    else:
        war.winner = "draw"
    war.status = "ended"
    for clan_id, side in ((war.clan_a, "a"), (war.clan_b, "b")):
        trig = "cw_draw" if war.winner == "draw" else ("cw_win" if war.winner == side else "cw_loss")
        rule = session.get(W.WarRewardRule, trig)
        if rule and rule.clan_xp:
            clan_add_xp(session, clan_id, rule.clan_xp)
        for m in war_roster(session, war.id, clan_id):
            if m.attacks_used <= 0:
                continue
            S.give_reward(session, m.user_id, trig, ref=f"cw:{war.id}", clan_xp_scale=0)
            if m.stars_scored:
                S.give_reward(session, m.user_id, "cw_star", scale=m.stars_scored, ref=f"cw:{war.id}", clan_xp_scale=0)
        clan_log(session, clan_id, f"🏁 جنگ #{war.id} تموم شد: {'برد' if war.winner == side else ('مساوی' if war.winner == 'draw' else 'باخت')} ({sa if side == 'a' else sb}⭐ در برابر {sb if side == 'a' else sa}⭐)")
    S.audit(session, None, "cw_end", war=war.id, winner=war.winner, stars=[sa, sb])


# ---------------------------------------------------------------------------
# لیگ
# ---------------------------------------------------------------------------

def leagues(session):
    out = []
    for tok in cs(session, "war_leagues", "برنز:0").split(","):
        if ":" in tok:
            n, t = tok.rsplit(":", 1)
            try:
                out.append((n.strip(), int(t)))
            except ValueError:
                pass
    return sorted(out, key=lambda x: x[1]) or [("برنز", 0)]


def league_of(session, trophies):
    ls = leagues(session)
    idx = 0
    for i, (_, t) in enumerate(ls):
        if trophies >= t:
            idx = i
    return idx, ls[idx][0]


def run_league_weekly(session, now=None, limit=200):
    now = now or utcnow()
    y, w, _ = now.isocalendar()
    wk = f"{y}-W{w:02d}"
    hrs = S.csv_floats(session, "war_league_weekly_ref_hours", "0.5,1,2,4,7,10,15")
    active_since = now - datetime.timedelta(days=7)
    n = 0
    for p in session.query(W.WarPlayer).filter(W.WarPlayer.last_league_week != wk, W.WarPlayer.last_seen_at >= active_since,
                                               W.WarPlayer.attacks > 0).limit(limit).all():
        idx, _ = league_of(session, p.trophies)
        p.last_league_week = wk
        if idx <= 0 and p.trophies <= 0:
            continue
        amt = math.floor((hrs[min(idx, len(hrs) - 1)] if hrs else 0) * S.player_ref(session, p))
        if amt > 0:
            S.hop_apply(session, session.get(db.User, p.user_id), amt, "BONUS", "war:league_weekly", ref=f"league:{wk}")
            n += 1
    return n


# ---------------------------------------------------------------------------
# Tick (Scheduler): Persistent + Retryable + Idempotent
# ---------------------------------------------------------------------------

def run_tick(now=None):
    """هر ۱۰-۳۰ ثانیه صدا زده می‌شه. هر مرحله در Session/تراکنشِ جدا؛ خطای یکی جلوی بقیه رو نمی‌گیره.
    برمی‌گردونه لیستِ رویدادها برای اعلان (بعد از commit)."""
    import war_battle as B
    now = now or utcnow()
    events = []
    s = db.get_session()
    try:
        ids = [r[0] for r in s.query(W.WarBattle.id).filter(W.WarBattle.status == "marching", W.WarBattle.resolve_at <= now).order_by(W.WarBattle.resolve_at).limit(40).all()]
    finally:
        s.close()
    for bid in ids:
        s = db.get_session()
        try:
            ev = B.resolve_battle(s, bid, now)
            s.commit()
            if ev:
                ev["type"] = "battle"
                events.append(ev)
        except Exception:
            s.rollback()
            logger.exception("resolve battle %s failed (retry next tick)", bid)
        finally:
            s.close()
    steps = [
        ("expire_battles", lambda s: _expire_stuck(s, now)),
        ("wars_match", lambda s: [{"type": "cw_found", "war_id": w} for w in match_wars(s, now)]),
        ("wars_advance", lambda s: advance_wars(s, now)),
        ("research", lambda s: finish_research(s, now) and None),
        ("requests", lambda s: expire_requests(s, now) and None),
        ("settlement", lambda s: _settle_all(s, now)),
        ("league", lambda s: run_league_weekly(s, now) and None),
    ]
    for name, fn in steps:
        s = db.get_session()
        try:
            out = fn(s)
            s.commit()
            if out:
                events.extend(out)
        except Exception:
            s.rollback()
            logger.exception("war tick step %s failed", name)
        finally:
            s.close()
    return events


def _expire_stuck(session, now):
    hrs = cf(session, "war_battle_expire_hours", 24)
    n = 0
    for b in session.query(W.WarBattle).filter(W.WarBattle.status == "marching", W.WarBattle.resolve_at < now - datetime.timedelta(hours=hrs)).all():
        import war_battle as B
        if B.cancel_battle(session, b.id, "expired", cf(session, "war_expire_refund_pct", 50)):
            n += 1
    return None


def _settle_all(session, now):
    ev = []
    for c in session.query(W.WarClan).filter_by(disbanded=False).all():
        r = run_settlement(session, c, now)
        if r and r["payouts"]:
            ev.append({"type": "settlement", "clan_id": c.id, "payouts": r["payouts"]})
    return ev
