# -*- coding: utf-8 -*-
"""
ضدِ اسپمِ دستورات ربات - سراسری (فارغ از گروه).

قانون: اگه یه کاربر ۵ بار (یا بیشتر) در ۳۰ ثانیه یا کمتر یکی از دستورات متنیِ
ربات رو (تو هر گروهی، حتی اگه بینِ چند گروه پخش کنه) بفرسته، به مدت ۲۰ دقیقه
به «زندان هاپویی» می‌ره و در این مدت رو کل ربات (همه‌ی گروه‌ها + پیوی) اجازه‌ی
اجرای هیچ دستوری رو نداره؛ هر بار که تو این ۲۰ دقیقه دوباره تلاش کنه، بهش
یادآوری می‌شه که اجازه‌ی این کار رو نداره.

نکته: قبلاً این زندان بر اساسِ (chat_id, user_id) بود که یه باگ بود - یعنی
کسی که تو یه گروه اسپم می‌کرد فقط تو همون گروه بن می‌شد و تو بقیه‌ی گروه‌ها/پیوی
آزادانه به کارش ادامه می‌داد. حالا فقط بر اساسِ user_id سراسریه.

پیاده‌سازی ساده و در حافظه (in-memory) است؛ چون فقط برای جلوگیری از اسپمِ
لحظه‌ایه، نیازی به ذخیره‌ی دائمی توی دیتابیس نیست — با ری‌استارت ربات هم
مشکلی پیش نمیاد (کاربرهای زندانی صرفا آزاد می‌شن).
"""
import collections
import datetime

SPAM_WINDOW_SECONDS = 30   # اگه ۵ دستور توی این بازه بیاد => اسپم
SPAM_THRESHOLD = 5
JAIL_DURATION_SECONDS = 20 * 60  # ۲۰ دقیقه

JAIL_ENTER_TEXT = (
    "🚨🔒 شما در زندان هاپویی هستید!\n\n"
    "به‌خاطر اسپم کردن دستورات ربات، به مدت ۲۰ دقیقه از استفاده از دستورات "
    "ربات (در همه‌ی گروه‌ها) محروم شدید. ⏳🐾\n\n"
    "💸 برای آزادیِ زودهنگام بنویس «وثیقه»."
)
JAIL_BLOCKED_TEXT = "⛔️ شما اجازه‌ی این کار را ندارید."

# {user_id: deque[datetime, ...]}  — زمان دستورات اخیر (سراسری، فارغ از گروه)
_command_log = collections.defaultdict(collections.deque)
# {user_id: datetime}  — تا چه زمانی زندانیه (سراسری)
_jailed_until = {}


def register_and_check(chat_id: int, user_id: int):
    """هر بار که کاربر یکی از دستورات متنیِ ربات رو (تو هر گروهی) می‌فرسته صدا
    زده می‌شه. chat_id فقط برای سازگاریِ امضای تابع نگه داشته شده و دیگه تو
    کلیدِ زندان استفاده نمی‌شه (زندان سراسریه).

    خروجی: (blocked: bool, message: str یا None)
    اگه blocked=True باشه نباید اجازه‌ی اجرای دستور داده بشه و باید همون
    message به کاربر نمایش داده بشه.
    """
    now = datetime.datetime.utcnow()
    key = user_id

    until = _jailed_until.get(key)
    if until:
        if now < until:
            return True, JAIL_BLOCKED_TEXT
        # مدت حبس تموم شده -> آزادش کن و از نو شروع کن
        _jailed_until.pop(key, None)
        _command_log.pop(key, None)

    log = _command_log[key]
    log.append(now)
    cutoff = now - datetime.timedelta(seconds=SPAM_WINDOW_SECONDS)
    while log and log[0] < cutoff:
        log.popleft()

    if len(log) >= SPAM_THRESHOLD:
        _jailed_until[key] = now + datetime.timedelta(seconds=JAIL_DURATION_SECONDS)
        _command_log.pop(key, None)
        return True, JAIL_ENTER_TEXT

    return False, None


def release(user_id: int):
    """آزادکردنِ دستیِ کسی که با اسپم زندانی شده بود - باید هر جا که زندانِ
    دیتابیسی (User.jailed_until) دستی آزاد می‌شه (مثلاً دستورِ «زندان هاپویی»
    برای آزادکردن)، این هم صدا زده بشه؛ وگرنه چون این زندان جداگونه و
    درون‌حافظه‌ست، آزادکردنِ دیتابیسی اثری روش نداره و کاربر همچنان تا آخرِ
    ۲۰دقیقه بلاک می‌مونه."""
    _jailed_until.pop(user_id, None)
    _command_log.pop(user_id, None)
