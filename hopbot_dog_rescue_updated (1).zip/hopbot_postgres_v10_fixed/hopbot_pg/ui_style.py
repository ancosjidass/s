# -*- coding: utf-8 -*-
"""سیستمِ طراحیِ یکدستِ پیام‌های ربات (فقط متن/ایموجی؛ به parse_mode نیاز نداره). هر صفحه از همین ابزارها بسازه تا ظاهرِ بات یکدست بمونه."""
RULE = "━━━━━━━━━━━━━━"
THIN = "┈┈┈┈┈┈┈┈┈┈┈┈┈┈"


def title(emoji: str, text: str) -> str:
    return f"{emoji} {text}\n{RULE}"


def section(name: str) -> str:
    return f"\n▸ {name}"


def kv(icon: str, label: str, value) -> str:
    return f"{icon} {label}: {value}"


def bar(cur, total, width: int = 10) -> str:
    total = max(1e-9, float(total))
    f = int(width * max(0.0, min(float(cur), total)) / total)
    return "▰" * f + "▱" * (width - f)


def money(n) -> str:
    try:
        return f"{int(round(float(n))):,} 🪙"
    except (TypeError, ValueError):
        return str(n)
