# -*- coding: utf-8 -*-
"""
زیرساختِ چندزبانه. دو لایه:

۱) کلیدی (قدیمی، برایِ مأموریت‌ها): locales/<کد>.json  →  i18n.t("کلید", lang, **kw)

۲) ترجمه‌ی خودکارِ همه‌ی متن‌هایِ بات (جدید): همه‌ی کدِ بات فارسی می‌نویسه؛ موقعِ ارسال، اگه چتِ مقصد
   انگلیسی باشه، متنِ پیام و متنِ دکمه‌ها با «قالب‌ها» (locales/<کد>_tpl/*.json) ترجمه می‌شه:
        { "💰 موجودی: {0} هاپ": "💰 Balance: {0} hops", ... }
   {0}،{1}،... جایِ مقدارهایِ متغیر (اسم، عدد، ...) هستن و می‌تونن جابه‌جا بشن. قالبِ ترجمه‌نشده = همون فارسی.
   زبانِ هر چت: پیوی = انتخابِ خودِ کاربر، گروه = انتخابِ ادمینِ گروه (chat_prefs.py).
   ورودی: وقتی چتی انگلیسیه، دستورهایِ انگلیسی (hapoyiwar، deposit 500، ...) قبل از رسیدن به هندلرها
   به معادلِ فارسی تبدیل می‌شن (locales/<کد>_alias.json) تا منطقِ بات دست‌نخورده بمونه.

اضافه‌کردنِ زبانِ جدید: locales/xx.json (با _meta) + locales/xx_tpl/*.json (+ اختیاری xx_alias.json).
لیستِ ترجمه‌نشده‌ها:  python3 i18n.py en
"""
import contextvars
import glob
import json
import os
import re
import sys

LOCALE_DIR = os.path.join(os.path.dirname(os.path.abspath(__file__)), "locales")
DEFAULT = "fa"
_cache = {}          # code -> (mtime, dict)


class _Safe(dict):
    def __missing__(self, k):
        return "{" + k + "}"


def _load(code):
    path = os.path.join(LOCALE_DIR, f"{code}.json")
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return {}
    hit = _cache.get(code)
    if hit and hit[0] == mt:
        return hit[1]
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return hit[1] if hit else {}
    _cache[code] = (mt, data)
    return data


def available() -> dict:
    """{code: نامِ نمایشی}"""
    out = {}
    try:
        names = sorted(f[:-5] for f in os.listdir(LOCALE_DIR) if f.endswith(".json"))
    except OSError:
        return {DEFAULT: "فارسی"}
    for code in names:
        out[code] = (_load(code).get("_meta") or {}).get("name", code)
    return out or {DEFAULT: "فارسی"}


def t(key: str, lang: str = "", **kw) -> str:
    for code in (lang, DEFAULT):
        if code:
            v = _load(code).get(key)
            if isinstance(v, str):
                try:
                    return v.format_map(_Safe(kw))
                except (ValueError, IndexError, KeyError):
                    return v
    return key


def missing(code: str) -> list:
    base = {k for k, v in _load(DEFAULT).items() if k != "_meta" and isinstance(v, str)}
    have = {k for k, v in _load(code).items() if k != "_meta" and isinstance(v, str) and v.strip()}
    return sorted(base - have)


# ===========================================================================
# ترجمه‌ی خودکارِ متنِ خروجی (قالب‌محور)
# ===========================================================================
_FA_RE = re.compile(r"[\u0600-\u06FF]")
_FA_L = "\u0600-\u06FF\u200c"
_HOLE = re.compile(r"\{(\d+)\}")

# چتی که الان داره پردازش می‌شه (برایِ answer_callback_query و ویرایش با inline_message_id که chat_id ندارن)
CURRENT_CHAT = contextvars.ContextVar("hop_current_chat", default=None)
CURRENT_USER = contextvars.ContextVar("hop_current_user", default=None)   # کاربری که آپدیتِ جاری رو فرستاده

_tpl_cache = {}      # code -> (signature, [Tpl...])
_alias_cache = {}    # code -> (mtime, dict)
_tr_memo = {}        # (lang, text) -> translated  (فقط برایِ متن‌هایِ کوتاه)
_MEMO_MAX = 6000


class Tpl:
    __slots__ = ("fa", "en", "anchor", "rx", "static_len", "en_parts", "_order")

    def __init__(self, fa, en):
        self.fa, self.en = fa, en
        parts = _HOLE.split(fa)            # [static, idx, static, idx, ..., static]
        statics = parts[0::2]
        self._order = [int(x) for x in parts[1::2]]
        self.static_len = sum(len(s) for s in statics)
        fa_statics = [s for s in statics if _FA_RE.search(s)]
        if not fa_statics:
            raise re.error("no persian static text")
        self.anchor = max(fa_statics, key=len).strip()
        rx = []
        last_i = len(statics) - 1
        for n, s in enumerate(statics):
            if n:
                if n == last_i and s == "":
                    rx.append("([^\\n]*)")                        # ته‌ِ قالب: تا آخرِ خط
                elif n == 1 and statics[0] == "":
                    rx.append("(?<![^\\n])([^\\n]*?)")             # اولِ قالب: از اولِ خط
                else:
                    rx.append("(.*?)")
            if s:
                rx.append(re.escape(s))
        body = "".join(rx)
        if statics[0] and _FA_RE.match(statics[0][0]):
            body = "(?<![" + _FA_L + "])" + body
        if statics[-1] and _FA_RE.match(statics[-1][-1]):
            body = body + "(?![" + _FA_L + "])"
        self.rx = re.compile(body, re.S)
        self.en_parts = _HOLE.split(en)

    def apply(self, text):
        def sub(m):
            groups = m.groups()
            # شماره‌یِ هر گروه = ترتیبِ ظاهرشدن در قالبِ فارسی؛ idx همون شماره‌ایه که تو قالب نوشته شده
            val = {}
            for pos, idx in enumerate(self._order):
                if pos < len(groups):
                    val[idx] = groups[pos]
            p = self.en_parts
            out = [p[0]]
            for k in range(1, len(p), 2):
                out.append(val.get(int(p[k]), ""))
                out.append(p[k + 1])
            return "".join(out)
        return self.rx.sub(sub, text)


def _tpl_files(code):
    d = os.path.join(LOCALE_DIR, f"{code}_tpl")
    return sorted(glob.glob(os.path.join(d, "*.json")))


def _templates(code):
    files = _tpl_files(code)
    try:
        sig = tuple((f, os.path.getmtime(f)) for f in files)
    except OSError:
        sig = ()
    hit = _tpl_cache.get(code)
    if hit and hit[0] == sig:
        return hit[1]
    data = {}
    for f in files:
        try:
            with open(f, encoding="utf-8") as fh:
                d = json.load(fh)
            data.update({k: v for k, v in d.items() if isinstance(k, str) and isinstance(v, str) and v.strip()})
        except (OSError, ValueError):
            continue
    tpls = []
    for fa, en in data.items():
        try:
            tpls.append(Tpl(fa, en))
        except re.error:
            continue
    tpls.sort(key=lambda t: -t.static_len)
    _tpl_cache[code] = (sig, tpls)
    _tr_memo.clear()
    return tpls


def tr(text, lang):
    """متنِ فارسیِ بات → زبانِ lang (اگه فارسی باشه/قالبی نباشه همون متن). نشانه‌هایِ منشن دست‌نخورده می‌مونن."""
    if not isinstance(text, str) or not text or not lang or lang == DEFAULT:
        return text
    if not _FA_RE.search(text):
        return text
    key = (lang, text) if len(text) <= 400 else None
    if key is not None:
        hit = _tr_memo.get(key)
        if hit is not None:
            return hit
    out = text
    for t in _templates(lang):
        if t.anchor and t.anchor in out:
            out = t.apply(out)
        if not _FA_RE.search(out):
            break
    if key is not None:
        if len(_tr_memo) > _MEMO_MAX:
            _tr_memo.clear()
        _tr_memo[key] = out
    return out


def tr_markup(rm, lang):
    """متنِ دکمه‌هایِ اینلاین را ترجمه می‌کند (callback_data/آدرس‌ها دست‌نخورده)."""
    if rm is None or not lang or lang == DEFAULT:
        return rm
    rows = getattr(rm, "inline_keyboard", None)
    if not rows:
        return rm
    if not any(_FA_RE.search(getattr(b, "text", "") or "") for r in rows for b in r):
        return rm
    from telegram import InlineKeyboardButton, InlineKeyboardMarkup
    new = []
    for r in rows:
        nr = []
        for b in r:
            if _FA_RE.search(b.text or ""):
                d = b.to_dict()
                d["text"] = tr(b.text, lang)[:64] if len(tr(b.text, lang)) > 64 else tr(b.text, lang)
                b = InlineKeyboardButton.de_json(d, None)
            nr.append(b)
        new.append(nr)
    return InlineKeyboardMarkup(new)


def lang_of_chat(chat_id=None):
    """زبانِ پیامِ خروجی. زبان همیشه «شخصیِ کاربر»ه (گروه/ادمین کنترلی روش ندارن):
       • مقصد پیوی (chat_id>0)             → زبانِ همون کاربر
       • مقصد گروه، تو پاسخ به آپدیتِ جاری → زبانِ کسی که دستور داده/دکمه زده
       • پیامِ بدونِ کاربرِ مشخص (جاب‌ها)   → فارسی"""
    import chat_prefs
    cur_chat = CURRENT_CHAT.get()
    if chat_id is None:
        chat_id = cur_chat
    try:
        cid = int(chat_id)
    except (TypeError, ValueError):
        return DEFAULT
    if cid > 0:
        return chat_prefs.get_lang(cid)
    if cid == cur_chat:
        uid = CURRENT_USER.get()
        if uid:
            return chat_prefs.get_lang(uid)
    return DEFAULT


# ---------------------------------------------------------------------------
# ورودی: دستورهایِ انگلیسی → معادلِ فارسی (فقط وقتی چت انگلیسی/غیرفارسیه)
# ---------------------------------------------------------------------------
def _alias(code):
    path = os.path.join(LOCALE_DIR, f"{code}_alias.json")
    try:
        mt = os.path.getmtime(path)
    except OSError:
        return {}
    hit = _alias_cache.get(code)
    if hit and hit[0] == mt:
        return hit[1]
    try:
        with open(path, encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, ValueError):
        return hit[1] if hit else {}
    # کلیدها نرمال می‌شن: حروفِ کوچک، بدونِ فاصله/خط‌تیره/آندرلاین
    norm = {}
    for k, v in (data.get("exact") or {}).items():
        norm[_squash(k)] = v
    data = {"exact": norm,
            "words": {_squash(k): v for k, v in (data.get("words") or {}).items()},
            "all_words": {k.lower(): v for k, v in (data.get("all_words") or {}).items()}}
    _alias_cache[code] = (mt, data)
    return data


def _squash(s):
    return re.sub(r"[\s_\-]+", "", (s or "").lower())


def to_fa(text, lang):
    """اگه text (انگلیسی) یه دستورِ بات باشه، معادلِ فارسیش؛ وگرنه همون text.
    «exact»: کلِ پیام = دستور. «words»: دستورِ کلمه‌ایِ دارایِ آرگومان (مثلاً deposit 500 → «واریز 500»)."""
    if not text or not lang or lang == DEFAULT or len(text) > 120 or _FA_RE.search(text):
        return text
    a = _alias(lang)
    if not a:
        return text
    raw = text.strip()
    hit = a["exact"].get(_squash(raw))
    if hit:
        return hit
    parts = raw.split(None, 1)
    head = _squash(parts[0])
    fa_head = a["words"].get(head)
    if fa_head and len(parts) == 2:
        rest = parts[1].strip()
        rest_fa = (a.get("all_words") or {}).get(rest.lower())
        return f"{fa_head} {rest_fa or rest}"
    return text


def missing_tpl(code):
    """قالب‌هایِ فارسی که هنوز ترجمه ندارن (نیازمندِ tools/extract_strings.py)."""
    path = os.path.join(os.path.dirname(os.path.abspath(__file__)), "locales", "_all_templates.json")
    try:
        with open(path, encoding="utf-8") as f:
            allk = json.load(f)
    except (OSError, ValueError):
        return []
    have = {t.fa for t in _templates(code)}
    return [k for k in allk if k not in have]


if __name__ == "__main__":
    code = sys.argv[1] if len(sys.argv) > 1 else ""
    if not code:
        print("زبان‌های موجود:", available())
    else:
        m = missing(code)
        print(f"{len(m)} کلید ترجمه‌نشده برای {code}:")
        print("\n".join(m))
        mt = missing_tpl(code)
        total = len(_templates(code)) + len(mt)
        print(f"\nقالب‌های متنِ بات: {len(_templates(code))} ترجمه‌شده، {len(mt)} ترجمه‌نشده (از {total})")
