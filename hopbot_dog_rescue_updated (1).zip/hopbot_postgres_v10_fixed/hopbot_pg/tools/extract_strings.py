# -*- coding: utf-8 -*-
"""
متن‌هایِ فارسیِ کدِ بات رو (با AST) به «قالب» تبدیل می‌کنه:
    f"💰 موجودی: {user.hop_points:,} هاپ"   →   "💰 موجودی: {0} هاپ"
خروجی:
    locales/_all_templates.json      همه‌ی قالب‌ها (کلید) + فایل‌هایی که توشون هستن
    tools/work/todo_<ماژول>.json     قالب‌هایِ هر ماژول به ترتیبِ ظاهرشدن (برایِ ترجمه)
اجرا:  python3 tools/extract_strings.py
بعد از ترجمه: python3 tools/merge_translations.py <ماژول> <فایلِ ترجمه>
"""
import ast
import glob
import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
FA = re.compile(r"[\u0600-\u06FF]")
FMT_HOLE = re.compile(r"\{[A-Za-z_0-9\.\[\]'\"]*(?::[^{}]*)?\}")
PCT_HOLE = re.compile(r"%(?:\.\d+)?[sdif]|%,d")
ADMIN_FILES = {"admin.py", "heist_admin.py", "war_admin.py", "mission_admin.py"}
SKIP_FILES = {"i18n.py", "lang_ui.py", "chat_prefs.py", "mentions.py"}


def norm_const(s):
    """Constant با {name}/%s → {0},{1},..."""
    n = [0]

    def rep(m):
        i = n[0]
        n[0] += 1
        return "{%d}" % i
    s2 = FMT_HOLE.sub(rep, s)
    s2 = PCT_HOLE.sub(rep, s2)
    return s2


def joined_template(node):
    parts, hints, n = [], [], 0
    for v in node.values:
        if isinstance(v, ast.Constant) and isinstance(v.value, str):
            if "{" in v.value or "}" in v.value:
                return None, None
            parts.append(v.value)
        elif isinstance(v, ast.FormattedValue):
            parts.append("{%d}" % n)
            try:
                hints.append(ast.unparse(v.value)[:18])
            except Exception:
                hints.append("?")
            n += 1
        else:
            return None, None
    return "".join(parts), hints


def collect(path):
    src = open(path, encoding="utf-8").read()
    tree = ast.parse(src)
    parents = {}
    for p in ast.walk(tree):
        for c in ast.iter_child_nodes(p):
            parents[c] = p
    doc_ids = set()
    for node in ast.walk(tree):
        if isinstance(node, (ast.Module, ast.ClassDef, ast.FunctionDef, ast.AsyncFunctionDef)):
            b = getattr(node, "body", [])
            if b and isinstance(b[0], ast.Expr) and isinstance(getattr(b[0], "value", None), ast.Constant):
                doc_ids.add(id(b[0].value))
    inside_join = set()
    for node in ast.walk(tree):
        if isinstance(node, ast.JoinedStr):
            for v in node.values:
                inside_join.add(id(v))

    def skip(node):
        p = parents.get(node)
        # لاگ/print/assert/مقایسه/regex
        while p is not None and not isinstance(p, (ast.stmt,)):
            if isinstance(p, ast.Call):
                f = p.func
                name = f.attr if isinstance(f, ast.Attribute) else getattr(f, "id", "")
                base = ast.unparse(f.value)[:20] if isinstance(f, ast.Attribute) else ""
                if name in ("print", "compile", "match", "search", "fullmatch", "sub", "findall") or base in ("logger", "logging", "log"):
                    return True
            if isinstance(p, ast.Compare):
                return True
            p = parents.get(p)
        if isinstance(p, ast.Assert):
            return True
        return False

    out = []
    for node in ast.walk(tree):
        if isinstance(node, ast.JoinedStr):
            if id(node) in inside_join or skip(node):
                continue
            t, hints = joined_template(node)
            if t and FA.search(t):
                out.append((node.lineno, t, hints))
        elif isinstance(node, ast.Constant) and isinstance(node.value, str):
            if id(node) in doc_ids or id(node) in inside_join:
                continue
            if not FA.search(node.value) or skip(node):
                continue
            v = node.value
            if re.search(r"[{}]", v):
                v2 = norm_const(v)
                if re.search(r"[{}]", re.sub(r"\{\d+\}", "", v2)):
                    continue         # آکولادِ واقعی (JSON و ...) - بی‌خیال
                v = v2
            out.append((node.lineno, v, []))
    out.sort(key=lambda x: x[0])
    return out


def main():
    os.makedirs(os.path.join(ROOT, "tools", "work"), exist_ok=True)
    allk = {}
    for f in sorted(glob.glob(os.path.join(ROOT, "*.py"))):
        base = os.path.basename(f)
        if base.startswith("test_") or base in SKIP_FILES:
            continue
        items = collect(f)
        seen, todo = set(), []
        for ln, t, hints in items:
            if t in seen or not t.strip():
                continue
            seen.add(t)
            todo.append({"t": t, "h": hints})
            allk.setdefault(t, []).append(base)
        mod = base[:-3]
        with open(os.path.join(ROOT, "tools", "work", f"todo_{mod}.json"), "w", encoding="utf-8") as fh:
            json.dump({"admin": base in ADMIN_FILES, "items": todo}, fh, ensure_ascii=False, indent=0)
    with open(os.path.join(ROOT, "locales", "_all_templates.json"), "w", encoding="utf-8") as fh:
        json.dump(allk, fh, ensure_ascii=False, indent=0)
    print(f"{len(allk)} قالبِ یکتا از {len(set(sum(allk.values(), [])))} فایل")


if __name__ == "__main__":
    main()
