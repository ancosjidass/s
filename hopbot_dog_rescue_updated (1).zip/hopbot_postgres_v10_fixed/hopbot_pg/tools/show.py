# -*- coding: utf-8 -*-
"""python3 tools/show.py <ماژول> [شروع] [پایان]  → قالب‌هایِ شماره‌دار برایِ ترجمه (ترجمه‌نشده‌ها)"""
import json, os, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
mod = sys.argv[1]
a = int(sys.argv[2]) if len(sys.argv) > 2 else 0
b = int(sys.argv[3]) if len(sys.argv) > 3 else 10**9
d = json.load(open(f"{ROOT}/tools/work/todo_{mod}.json", encoding="utf-8"))
tp = f"{ROOT}/locales/en_tpl/{mod}.json"
have = json.load(open(tp, encoding="utf-8")) if os.path.exists(tp) else {}
for i, it in enumerate(d["items"]):
    if i < a or i >= b or it["t"] in have:
        continue
    h = ("  ⟨" + ", ".join(f"{k}={x}" for k, x in enumerate(it["h"])) + "⟩") if it["h"] else ""
    print(f"{i}|{it['t'].replace(chr(10), '↵')}{h}")
