# -*- coding: utf-8 -*-
"""
python3 tools/merge_translations.py <ماژول> < ترجمه.txt
هر خط:  <شماره>|<ترجمه‌یِ انگلیسی>     («↵» = خطِ جدید). شماره‌ها از tools/show.py می‌آد.
خروجی: locales/en_tpl/<ماژول>.json  (ادغام با قبلی‌ها). placeholderهایِ {n} چک می‌شن.
"""
import json, os, re, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
mod = sys.argv[1]
d = json.load(open(f"{ROOT}/tools/work/todo_{mod}.json", encoding="utf-8"))["items"]
tp = f"{ROOT}/locales/en_tpl/{mod}.json"
have = json.load(open(tp, encoding="utf-8")) if os.path.exists(tp) else {}
ok = bad = 0
for line in sys.stdin.read().splitlines():
    if "|" not in line:
        continue
    n, en = line.split("|", 1)
    if not n.strip().isdigit() or int(n) >= len(d):
        continue
    fa = d[int(n)]["t"]
    en = en.replace("↵", "\n")
    holes_fa = set(re.findall(r"\{(\d+)\}", fa))
    holes_en = set(re.findall(r"\{(\d+)\}", en))
    if not holes_en <= holes_fa or (holes_fa - holes_en and len(holes_fa) > 0 and not holes_en):
        print("⚠ placeholder mismatch:", n, fa[:50], "→", en[:50]); bad += 1
        continue
    have[fa] = en
    ok += 1
os.makedirs(os.path.dirname(tp), exist_ok=True)
json.dump(have, open(tp, "w", encoding="utf-8"), ensure_ascii=False, indent=0)
print(f"{mod}: +{ok} ({bad} رد شد) → جمعاً {len(have)}")
