# -*- coding: utf-8 -*-
"""پنل ادمینِ «مأموریت‌های هاپویی» — برچسبِ فارسی، مقدارِ فعلی کنارش، ویرایش با دکمه."""
import math

from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb

import db
import mission_db as MD
import mission_metrics as MM
import mission_svc as S
from mission_svc import MissionError

PAGE = 8


async def _send(update, text, rows):
    from handlers import send_response
    return await send_response(update, text[:3900], Kb(rows))


async def _ask(update, context, text, state):
    from handlers import ask_for_input
    await ask_for_input(update, context, text, state, "admin_state", "admin_mission_menu")


async def cb_menu(update, context):
    session = db.get_session()
    try:
        on = S.gi(session, "ct_enabled", 1)
        n = session.query(MD.MissionDef).filter_by(deleted=False).count()
        lvl = db.cfg_get(session, "minlvl_mission")
        season = S.current_season(session)
        session.commit()
        ends = season.ends_at.strftime("%Y-%m-%d")
    finally:
        session.close()
    rows = [
        [Btn(f"{'🟢' if on else '🔴'} مأموریت‌ها: {'روشن' if on else 'خاموش'}", callback_data="admin_mission_toggle")],
        [Btn(f"📋 مأموریت‌ها ({n})", callback_data="admin_mission_list:0")],
        [Btn("📦 نصبِ بسته‌ی شروع (۱۳ مأموریتِ آماده)", callback_data="admin_mission_pack")],
        [Btn("⚙️ تنظیماتِ پاداش، استریک و فصل", callback_data="admin_mission_cfg:0")],
        [Btn(f"🔐 حداقل لولِ ورود ({lvl})", callback_data="admin_cfg_edit:minlvl_mission")],
        [Btn("🔙 پنل مدیریت", callback_data="admin_panel")],
    ]
    await _send(update, f"🎯 مدیریتِ مأموریت‌های هاپویی\n🏆 پایانِ فصلِ جاری: {ends}\n\n"
                        "ℹ️ پاداشِ هر مأموریت «ساعتِ درآمدِ خودِ بازیکن» حساب می‌شه؛ پس برای کم‌درآمد و پولدار هر دو معنی‌دار می‌مونه و با سقفِ پاداش تورم کنترل می‌شه.", rows)


async def cb_toggle(update, context):
    session = db.get_session()
    try:
        S.admin_set_cfg(session, "ct_enabled", "0" if S.gi(session, "ct_enabled", 1) else "1")
    finally:
        session.close()
    await cb_menu(update, context)


async def cb_pack(update, context):
    session = db.get_session()
    try:
        n = S.admin_install_starter_pack(session)
    finally:
        session.close()
    await update.callback_query.answer(f"✅ {n} مأموریت اضافه شد" if n else "همه‌ی مأموریت‌های بسته از قبل هستن", show_alert=True)
    await cb_menu(update, context)


async def cb_list(update, context):
    page = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        defs = session.query(MD.MissionDef).filter_by(deleted=False).order_by(MD.MissionDef.period, MD.MissionDef.tier, MD.MissionDef.id).all()
        pages = max(1, math.ceil(len(defs) / PAGE))
        page = max(0, min(page, pages - 1))
        rows = [[Btn(f"{'✅' if d.enabled else '⛔️'} {MD.PERIODS[d.period][:2]}{MD.TIERS[d.tier][:2]} {d.title}"[:60], callback_data=f"admin_mission_def:{d.id}")]
                for d in defs[page * PAGE:(page + 1) * PAGE]]
    finally:
        session.close()
    rows.append([Btn("➕ مأموریتِ جدید", callback_data="admin_mission_new")])
    rows.append([Btn("◀️", callback_data=f"admin_mission_list:{max(0, page - 1)}"), Btn(f"{page + 1}/{pages}", callback_data="admin_mission_noop"),
                 Btn("▶️", callback_data=f"admin_mission_list:{min(pages - 1, page + 1)}")])
    rows.append([Btn("🔙 بازگشت", callback_data="admin_mission_menu")])
    await _send(update, f"📋 مأموریت‌ها ({len(defs)})", rows)


async def cb_noop(update, context):
    await update.callback_query.answer()


async def cb_new(update, context):
    await _ask(update, context,
               "➕ مأموریتِ جدید: «عنوان | معیار | تعداد | دوره | رده | ساعتِ درآمد»\n"
               "مثال:\n🎲 ۳ دور کازینو | casino_played | 3 | daily | 1 | 1\n\n"
               "معیارها:\n" + "\n".join(f"• {k} = {v}" for k, v in MM.METRIC_LABEL.items()) +
               "\n\nدوره: daily / weekly / once   |   رده: 1 آسان، 2 متوسط، 3 سخت",
               {"type": "mission_new"})


async def cb_def(update, context):
    did = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        d = session.get(MD.MissionDef, did)
        if d is None or d.deleted:
            await update.callback_query.answer("پیدا نشد", show_alert=True)
            return
        lines = [f"{'✅' if d.enabled else '⛔️'} {d.title}", ""]
        for k, lab, kind in MD.DEF_FIELDS:
            v = getattr(d, k)
            if k == "metric":
                v = f"{v} ({MM.METRIC_LABEL.get(v, '؟')})"
            elif k == "tier":
                v = MD.TIERS.get(v, v)
            elif k == "period":
                v = MD.PERIODS.get(v, v)
            lines.append(f"• {lab}: {v}")
    finally:
        session.close()
    rows = [[Btn(f"✏️ {lab[:45]}", callback_data=f"admin_mission_df:{did}:{k}")] for k, lab, _t in MD.DEF_FIELDS]
    rows.append([Btn("🔁 فعال/غیرفعال", callback_data=f"admin_mission_dtgl:{did}"), Btn("🗑 حذف", callback_data=f"admin_mission_ddel:{did}")])
    rows.append([Btn("🔙 لیست", callback_data="admin_mission_list:0")])
    await _send(update, "\n".join(lines), rows)


async def cb_df(update, context):
    _, did, key = update.callback_query.data.split(":")
    extra = ("\nمعیارها: " + ", ".join(MM.METRICS)) if key == "metric" else ""
    await _ask(update, context, f"✏️ {MD.DEF_LABEL[key]}{extra}\nمقدارِ جدید رو بفرست:", {"type": "mission_df", "id": int(did), "key": key})


async def cb_dtgl(update, context):
    session = db.get_session()
    try:
        S.admin_toggle_def(session, int(update.callback_query.data.split(":")[1]))
    finally:
        session.close()
    await cb_def(update, context)


async def cb_ddel(update, context):
    parts = update.callback_query.data.split(":")
    did = int(parts[1])
    if len(parts) == 2:
        await _send(update, "⚠️ این مأموریت حذف بشه؟ (پاداش‌های قبلاً گرفته‌شده سر جاشون می‌مونن)",
                    [[Btn("✅ بله", callback_data=f"admin_mission_ddel:{did}:y")], [Btn("❌ انصراف", callback_data=f"admin_mission_def:{did}")]])
        return
    session = db.get_session()
    try:
        S.admin_delete_def(session, did)
    finally:
        session.close()
    update.callback_query.data = "admin_mission_list:0"
    await cb_list(update, context)


async def cb_cfg(update, context):
    page = int(update.callback_query.data.split(":")[1])
    keys = [k for k, _l, _v, _h in MD.CFG] + list(MD.MSG)
    pages = max(1, math.ceil(len(keys) / PAGE))
    page = max(0, min(page, pages - 1))
    session = db.get_session()
    try:
        lines, rows = [f"⚙️ تنظیماتِ مأموریت‌ها ({page + 1}/{pages})", ""], []
        for k in keys[page * PAGE:(page + 1) * PAGE]:
            lines.append(f"• {MD.CFG_LABEL[k]}: {str(db.cfg_get(session, k))[:40]}")
            if MD.CFG_HELP.get(k):
                lines.append(f"   ({MD.CFG_HELP[k]})")
            rows.append([Btn(f"✏️ {MD.CFG_LABEL[k][:45]}", callback_data=f"admin_mission_cfgk:{k}")])
    finally:
        session.close()
    rows.append([Btn("◀️", callback_data=f"admin_mission_cfg:{max(0, page - 1)}"), Btn(f"{page + 1}/{pages}", callback_data="admin_mission_noop"),
                 Btn("▶️", callback_data=f"admin_mission_cfg:{min(pages - 1, page + 1)}")])
    rows.append([Btn("🔙 بازگشت", callback_data="admin_mission_menu")])
    await _send(update, "\n".join(lines), rows)


async def cb_cfgk(update, context):
    key = update.callback_query.data.split(":", 1)[1]
    if key not in MD.CFG_LABEL:
        await update.callback_query.answer("؟", show_alert=True)
        return
    session = db.get_session()
    try:
        cur = db.cfg_get(session, key)
    finally:
        session.close()
    await _ask(update, context, f"✏️ {MD.CFG_LABEL[key]}\nمقدارِ فعلی: {cur}\n\nمقدارِ جدید رو بفرست:", {"type": "mission_cfg", "key": key})


async def mission_admin_awaiting_handler(update, context, state):
    text = (update.message.text or "").strip()
    stype = state["type"]
    session = db.get_session()
    rows = [[Btn("🔙 منوی مأموریت‌ها", callback_data="admin_mission_menu")]]
    try:
        if stype == "mission_cfg":
            v = S.admin_set_cfg(session, state["key"], text)
            reply = f"✅ {MD.CFG_LABEL[state['key']]} ← {v}"
        elif stype == "mission_df":
            d = S.admin_set_def(session, state["id"], state["key"], text)
            reply = f"✅ {MD.DEF_LABEL[state['key']]} ← {getattr(d, state['key'])}"
            rows = [[Btn("🔙 برگشت", callback_data=f"admin_mission_def:{d.id}")]]
        elif stype == "mission_new":
            parts = [p.strip() for p in text.split("|")]
            if len(parts) != 6:
                raise MissionError("فرمت: عنوان | معیار | تعداد | دوره | رده | ساعتِ درآمد")
            try:
                hours = float(parts[5])
            except ValueError:
                raise MissionError("ساعتِ درآمد باید عدد باشه.")
            d = S.admin_create_def(session, parts[0], parts[1], parts[2], parts[3], parts[4], hours)
            reply = f"✅ مأموریتِ «{d.title}» ساخته شد."
            rows = [[Btn("⚙️ تنظیمش", callback_data=f"admin_mission_def:{d.id}")], rows[0]]
        else:
            reply = "؟"
    except MissionError as e:
        session.rollback()
        reply = f"❌ {e}"
    finally:
        session.close()
    await update.message.reply_text(reply, reply_markup=Kb(rows))


ADMIN_MISSION_CALLBACKS = {
    "admin_mission_menu": cb_menu, "admin_mission_toggle": cb_toggle, "admin_mission_pack": cb_pack, "admin_mission_list": cb_list,
    "admin_mission_noop": cb_noop, "admin_mission_new": cb_new, "admin_mission_def": cb_def, "admin_mission_df": cb_df,
    "admin_mission_dtgl": cb_dtgl, "admin_mission_ddel": cb_ddel, "admin_mission_cfg": cb_cfg, "admin_mission_cfgk": cb_cfgk,
}
