# -*- coding: utf-8 -*-
"""اجرا:  python3 -m unittest test_mission_engine -v"""
import datetime
import unittest

import mission_engine as M

TZ = 210                                   # ایران
D = datetime.datetime


class Periods(unittest.TestCase):
    def test_day_rolls_at_local_midnight(self):
        # ۲۰:۲۹ UTC = ۲۳:۵۹ ایران، ۲۰:۳۰ UTC = ۰۰:۰۰ روزِ بعد
        self.assertEqual(M.day_key(D(2026, 10, 7, 20, 29), TZ), "2026-10-07")
        self.assertEqual(M.day_key(D(2026, 10, 7, 20, 30), TZ), "2026-10-08")

    def test_period_start_is_utc_of_local_midnight(self):
        s = M.period_start_utc("daily", D(2026, 10, 7, 12, 0), TZ)
        self.assertEqual(s, D(2026, 10, 6, 20, 30))
        self.assertEqual(M.period_end_utc("daily", D(2026, 10, 7, 12, 0), TZ), D(2026, 10, 7, 20, 30))

    def test_week_starts_saturday(self):
        # ۲۰۲۶-۱۰-۱۰ شنبه است
        self.assertEqual(M.week_key(D(2026, 10, 10, 12), TZ), "W2026-10-10")
        self.assertEqual(M.week_key(D(2026, 10, 16, 12), TZ), "W2026-10-10")     # جمعه
        self.assertEqual(M.week_key(D(2026, 10, 17, 12), TZ), "W2026-10-17")

    def test_once_has_no_window(self):
        self.assertIsNone(M.period_start_utc("once", D(2026, 1, 1), TZ))
        self.assertEqual(M.period_key("once", D(2026, 1, 1), TZ), "once")


class Streak(unittest.TestCase):
    def test_first_and_next_day(self):
        self.assertEqual(M.next_streak(0, "", "2026-10-07"), 1)
        self.assertEqual(M.next_streak(4, "2026-10-06", "2026-10-07"), 5)

    def test_same_day_unchanged(self):
        self.assertEqual(M.next_streak(4, "2026-10-07", "2026-10-07"), 4)

    def test_gap_resets_unless_grace(self):
        self.assertEqual(M.next_streak(9, "2026-10-04", "2026-10-07"), 1)
        self.assertEqual(M.next_streak(9, "2026-10-05", "2026-10-07", grace_days=1), 10)

    def test_multiplier_steps(self):
        steps = M.parse_steps("30:1.5, 3:1.1,7:1.25,bad,x:y")
        self.assertEqual(steps, [(3, 1.1), (7, 1.25), (30, 1.5)])
        self.assertEqual([M.streak_multiplier(s, steps) for s in (1, 3, 6, 7, 29, 30, 99)], [1.0, 1.1, 1.1, 1.25, 1.25, 1.5, 1.5])
        self.assertEqual(M.streak_multiplier(5, []), 1.0)


class Reward(unittest.TestCase):
    def test_scales_with_own_income(self):
        poor = M.reward_hop(2, 0, 72_000, 50_000, 10_000, 0)
        rich = M.reward_hop(2, 0, 7_200_000, 50_000, 10_000, 0)
        self.assertEqual((poor, rich), (144_000, 14_400_000))

    def test_floor_income_protects_idle_players(self):
        self.assertEqual(M.reward_hop(1, 0, 0, 60_000, 0, 0), 60_000)

    def test_cap_and_min(self):
        self.assertEqual(M.reward_hop(5, 0, 77_000_000, 0, 0, 100_000_000), 100_000_000)      # سقفِ ضدِ تورم
        self.assertEqual(M.reward_hop(0.0001, 0, 10, 0, 5_000, 0), 5_000)

    def test_absolute_and_multiplier(self):
        self.assertEqual(M.reward_hop(1, 1000, 1000, 0, 0, 0, multiplier=2), 4000)

    def test_never_negative(self):
        self.assertEqual(M.reward_hop(-5, 0, 1000, 0, 0, 0), 0)


class Pick(unittest.TestCase):
    DEFS = [{"id": i, "tier": 1 + (i % 3), "min_level": 0, "sort": i} for i in range(1, 10)]

    def test_deterministic_per_user_day(self):
        a = M.pick_daily(self.DEFS, 5, "2026-10-07", 3)
        self.assertEqual([d["id"] for d in a], [d["id"] for d in M.pick_daily(self.DEFS, 5, "2026-10-07", 3)])

    def test_varies_between_days_and_users(self):
        seen = {tuple(d["id"] for d in M.pick_daily(self.DEFS, u, f"2026-10-{day:02d}", 3)) for u in (1, 2, 3) for day in range(1, 8)}
        self.assertGreater(len(seen), 5)

    def test_one_per_tier_first(self):
        picked = M.pick_daily(self.DEFS, 1, "k", 3)
        self.assertEqual(sorted(d["tier"] for d in picked), [1, 2, 3])
        self.assertEqual(len({d["id"] for d in picked}), 3)

    def test_count_capped_by_pool_and_level_gate(self):
        defs = [{"id": 1, "tier": 1, "min_level": 0}, {"id": 2, "tier": 1, "min_level": 10}]
        self.assertEqual([d["id"] for d in M.pick_daily(defs, 1, "k", 5, user_level=1)], [1])
        self.assertEqual(M.pick_daily([], 1, "k", 3), [])
        self.assertEqual(M.pick_daily(self.DEFS, 1, "k", 0), [])

    def test_missing_tier_filled_from_others(self):
        defs = [{"id": i, "tier": 1, "min_level": 0} for i in range(1, 6)]
        self.assertEqual(len(M.pick_daily(defs, 1, "k", 3)), 3)


class Bar(unittest.TestCase):
    def test_bar(self):
        self.assertEqual(M.progress_bar(0, 4), "▱" * 10)
        self.assertEqual(M.progress_bar(2, 4), "▰" * 5 + "▱" * 5)
        self.assertEqual(M.progress_bar(9, 4), "▰" * 10)
        self.assertEqual(M.progress_bar(1, 0), "▰" * 10)


if __name__ == "__main__":
    unittest.main()
