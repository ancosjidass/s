# -*- coding: utf-8 -*-
"""پنل ادمینِ «بتل‌پسِ هاپویی» — برچسبِ فارسی، مقدارِ فعلی کنارش، ویرایش با دکمه."""
import math

from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb

import battlepass_db as BD
import battlepass_engine as E
import db
from battlepass_engine import BpError, fmt

PAGE = 8
HOP_KEYS = ("bp_hop_bonus_global_pct", "bp_hop_bonus_premium_pct", "bp_hop_bonus_cap_pct")


async def _send(update, text, rows):
    from handlers import send_response
    return await send_response(update, text[:3900], Kb(rows))


async def _ask(update, context, text, state, back="admin_bp_menu"):
    from handlers import ask_for_input
    await ask_for_input(update, context, text, state, "admin_state", back)


async def cb_menu(update, context):
    session = db.get_session()
    try:
        on = E.enabled(session)
        season = E.current_season(session)
        session.commit()
        st = E.stats(session, season)
        lvl = db.cfg_get(session, "minlvl_battlepass")
        ghop = E.gf(session, "bp_hop_bonus_global_pct", 0)
        left = E.left_text(season.ends_at - E.utcnow()) if E.is_open(season) else "تمام‌شده"
        info = (f"🎖 مدیریتِ بتل‌پس هاپویی\n📅 {season.name} — پایان: {left}\n"
                f"👥 بازیکنِ این فصل: {st['players']} | 👑 پریمیوم: {st['premium']} | میانگینِ تیر: {st['avg_tier']:.1f}\n"
                f"🦘 هاپِ بیشترِ همگانی (ایونت): {ghop:g}٪")
    finally:
        session.close()
    rows = [
        [Btn(f"{'🟢' if on else '🔴'} بتل‌پس: {'روشن' if on else 'خاموش'}", callback_data="admin_bp_toggle")],
        [Btn("🦘 درصدِ هاپِ بیشتر (همگانی/پریمیوم/سقف)", callback_data="admin_bp_hop")],
        [Btn("📅 فصل (جدید/تمدید/پایان)", callback_data="admin_bp_season")],
        [Btn("🎁 جایزه‌هایِ تیرها", callback_data="admin_bp_rewards")],
        [Btn("🎯 چلنج‌ها", callback_data="admin_bp_list:0")],
        [Btn("⚙️ تنظیماتِ XP، سختی و قیمت‌ها", callback_data="admin_bp_cfg:0")],
        [Btn("🧰 اعطا به بازیکن (XP/پریمیوم/بوستر)", callback_data="admin_bp_grant")],
        [Btn(f"🔐 حداقل لولِ ورود ({lvl})", callback_data="admin_cfg_edit:minlvl_battlepass")],
        [Btn("🔙 پنل مدیریت", callback_data="admin_panel")],
    ]
    await _send(update, info, rows)


async def cb_toggle(update, context):
    session = db.get_session()
    try:
        E.admin_set_cfg(session, "bp_enabled", "0" if E.enabled(session) else "1")
    finally:
        session.close()
    await cb_menu(update, context)


async def cb_noop(update, context):
    await update.callback_query.answer()


# --- درصدِ هاپ ---
async def cb_hop(update, context):
    session = db.get_session()
    try:
        lines = ["🦘 درصدِ هاپِ بیشتر", "",
                 "این درصد روی هر «هاپ هاپ» اعمال می‌شه (جمعِ: همگانی + پریمیوم + تیرهایِ دائمی + بوستر، تا سقف).", ""]
        rows = []
        for k in HOP_KEYS:
            lines.append(f"• {BD.CFG_LABEL[k]}: {db.cfg_get(session, k)}" + (f"\n   ({BD.CFG_HELP[k]})" if BD.CFG_HELP.get(k) else ""))
            rows.append([Btn(f"✏️ {BD.CFG_LABEL[k][:45]}", callback_data=f"admin_bp_cfgk:{k}")])
    finally:
        session.close()
    rows.append([Btn("🔙 بازگشت", callback_data="admin_bp_menu")])
    await _send(update, "\n".join(lines), rows)


# --- تنظیمات ---
async def cb_cfg(update, context):
    page = int(update.callback_query.data.split(":")[1])
    keys = [k for k, _l, _v, _h in BD.CFG]
    pages = max(1, math.ceil(len(keys) / PAGE))
    page = max(0, min(page, pages - 1))
    session = db.get_session()
    try:
        lines, rows = [f"⚙️ تنظیماتِ بتل‌پس ({page + 1}/{pages})", ""], []
        for k in keys[page * PAGE:(page + 1) * PAGE]:
            lines.append(f"• {BD.CFG_LABEL[k]}: {str(db.cfg_get(session, k))[:40]}")
            if BD.CFG_HELP.get(k):
                lines.append(f"   ({BD.CFG_HELP[k]})")
            rows.append([Btn(f"✏️ {BD.CFG_LABEL[k][:45]}", callback_data=f"admin_bp_cfgk:{k}")])
    finally:
        session.close()
    rows.append([Btn("◀️", callback_data=f"admin_bp_cfg:{max(0, page - 1)}"), Btn(f"{page + 1}/{pages}", callback_data="admin_bp_noop"),
                 Btn("▶️", callback_data=f"admin_bp_cfg:{min(pages - 1, page + 1)}")])
    rows.append([Btn("🔙 بازگشت", callback_data="admin_bp_menu")])
    await _send(update, "\n".join(lines), rows)


async def cb_cfgk(update, context):
    key = update.callback_query.data.split(":", 1)[1]
    if key not in BD.CFG_LABEL:
        await update.callback_query.answer("؟", show_alert=True)
        return
    session = db.get_session()
    try:
        cur = db.cfg_get(session, key)
    finally:
        session.close()
    hint = ""
    if key == "bp_stage_costs":
        hint = "\n(۵ عدد با کاما: XPِ هر تیر در مرحله‌هایِ تازه‌کار…افسانه)"
    elif key == "bp_activity_weights":
        hint = "\n(مثال: hops:4,casino_played:15 — معیارها: " + ", ".join(E.METRIC_LABEL) + ")"
    await _ask(update, context, f"✏️ {BD.CFG_LABEL[key]}\nمقدارِ فعلی: {cur}{hint}\n\nمقدارِ جدید رو بفرست:", {"type": "bp_cfg", "key": key})


# --- فصل ---
async def cb_season(update, context):
    session = db.get_session()
    try:
        s = E.current_season(session)
        session.commit()
        left = E.left_text(s.ends_at - E.utcnow()) if E.is_open(s) else "تمام‌شده"
        txt = (f"📅 {s.name}\nوضعیت: {s.status} | شروع: {s.started_at:%Y-%m-%d} | پایان: {s.ends_at:%Y-%m-%d} ({left})\n"
               f"🎚 تیرها: {s.tiers}\n\nℹ️ «فصلِ جدید» فصلِ فعلی رو تموم می‌کنه و جایزه‌هایِ همین فصل رو کپی می‌کنه؛ "
               "بعد می‌تونی جایزه‌هایِ فصلِ جدید رو جدا تغییر بدی. بازیکن‌ها تا مهلتِ مجاز جایزه‌هایِ فصلِ قبل رو می‌گیرن.")
    finally:
        session.close()
    rows = [[Btn("🆕 فصلِ جدید", callback_data="admin_bp_snew")],
            [Btn("➕ تمدید (روز)", callback_data="admin_bp_sext"), Btn("🏁 پایانِ همین الان", callback_data="admin_bp_send")],
            [Btn("🔙 بازگشت", callback_data="admin_bp_menu")]]
    await _send(update, txt, rows)


async def cb_snew(update, context):
    await _ask(update, context, "🆕 فصلِ جدید: «اسم | تعدادِ روز» (هر دو اختیاری؛ فقط - بفرست برای پیش‌فرض)\nمثال: فصلِ زمستان | 45",
               {"type": "bp_snew"}, "admin_bp_season")


async def cb_sext(update, context):
    await _ask(update, context, "➕ چند روز تمدید بشه؟ (عدد)", {"type": "bp_sext"}, "admin_bp_season")


async def cb_send(update, context):
    parts = update.callback_query.data.split(":")
    if len(parts) == 1:
        await _send(update, "⚠️ فصل همین الان تموم بشه؟ (اگه «فصلِ بعد خودکار» روشن باشه، فصلِ بعدی شروع می‌شه)",
                    [[Btn("✅ بله", callback_data="admin_bp_send:y")], [Btn("❌ انصراف", callback_data="admin_bp_season")]])
        return
    session = db.get_session()
    try:
        E.admin_end_now(session)
    finally:
        session.close()
    await cb_season(update, context)


# --- جایزه‌ها ---
async def cb_rewards(update, context):
    session = db.get_session()
    try:
        s = E.current_season(session)
        session.commit()
        txt = (f"🎁 جایزه‌هایِ {s.name}\n\nیه تیر رو انتخاب کن تا جایزه‌ی مسیرِ رایگان/پریمیومش رو عوض کنی.\n"
               "جایزه‌هایِ پیش‌فرض از «واحدِ پاداشِ نقدی» (تنظیمات) ساخته شدن؛ با «بازسازیِ پیش‌فرض» دوباره ساخته می‌شن.")
        n = s.tiers
    finally:
        session.close()
    step = max(1, n // 5)
    rows = [[Btn(f"{BD.STAGES[i]}: تیر {i * step + 1}-{min(n, (i + 1) * step)}", callback_data=f"admin_bp_rp:{i * step // 10}")] for i in range(5)]
    rows.append([Btn("🔢 رفتن به یه تیرِ مشخص", callback_data="admin_bp_tpick")])
    rows.append([Btn("♻️ بازسازیِ پیش‌فرضِ جایزه‌هایِ این فصل", callback_data="admin_bp_rreset")])
    rows.append([Btn("🔙 بازگشت", callback_data="admin_bp_menu")])
    await _send(update, txt, rows)


async def cb_rp(update, context):
    page = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        s = E.current_season(session)
        session.commit()
        defs = E.defs_map(session, s.id)
        lo, hi = page * 10 + 1, min(s.tiers, page * 10 + 10)
        lines = [f"🎁 تیر {lo} تا {hi}", ""]
        rows = []
        for t in range(lo, hi + 1):
            lines.append(f"{t}: 🆓 {E.reward_text(defs.get((t, 'free')))} | 👑 {E.reward_text(defs.get((t, 'premium')))}")
            rows.append([Btn(f"✏️ تیر {t}", callback_data=f"admin_bp_tier:{t}")])
        pages = max(1, math.ceil(s.tiers / 10))
    finally:
        session.close()
    rows.append([Btn("◀️", callback_data=f"admin_bp_rp:{max(0, page - 1)}"), Btn(f"{page + 1}/{pages}", callback_data="admin_bp_noop"),
                 Btn("▶️", callback_data=f"admin_bp_rp:{min(pages - 1, page + 1)}")])
    rows.append([Btn("🔙 بازگشت", callback_data="admin_bp_rewards")])
    await _send(update, "\n".join(lines), rows)


async def cb_tpick(update, context):
    await _ask(update, context, "🔢 شماره‌ی تیر رو بفرست:", {"type": "bp_tpick"}, "admin_bp_rewards")


async def cb_tier(update, context):
    tier = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        s = E.current_season(session)
        session.commit()
        defs = E.defs_map(session, s.id)
        txt = (f"🎁 تیر {tier} — {s.name}\n\n🆓 رایگان: {E.reward_text(defs.get((tier, 'free')))}\n"
               f"👑 پریمیوم: {E.reward_text(defs.get((tier, 'premium')))}")
    finally:
        session.close()
    rows = [[Btn("✏️ جایزه‌ی رایگان", callback_data=f"admin_bp_te:{tier}:free"), Btn("✏️ جایزه‌ی پریمیوم", callback_data=f"admin_bp_te:{tier}:premium")],
            [Btn("🔙 بازگشت", callback_data=f"admin_bp_rp:{(tier - 1) // 10}")]]
    await _send(update, txt, rows)


async def cb_te(update, context):
    _, tier, track = update.callback_query.data.split(":")
    kinds = "\n".join(f"• {k} = {v}" for k, v in BD.KINDS.items())
    await _ask(update, context,
               f"✏️ جایزه‌ی تیر {tier} ({'پریمیوم' if track == 'premium' else 'رایگان'})\n"
               "فرمت: نوع | مقدار | درصد | تعدادِ‌استفاده | مدت(دقیقه) | برچسب\n"
               "مثال‌ها:\n• hop | 2500000\n• hop_boost |  | 30 |  | 90 | بوسترِ هاپ ۳۰٪\n• heist_loot |  | 25 | 3 |  | غنیمتِ سرقت +۲۵٪\n"
               "• prod_boost |  | 40 |  | 120\n• jail_free | 1\n• shop_money | 2\n• title |  |  |  |  | 🏷 لقبِ دلخواه\n• none (خالی)\n\n"
               f"نوع‌ها:\n{kinds}",
               {"type": "bp_te", "tier": int(tier), "track": track}, f"admin_bp_tier:{tier}")


async def cb_rreset(update, context):
    parts = update.callback_query.data.split(":")
    if len(parts) == 1:
        await _send(update, "⚠️ همه‌ی جایزه‌هایِ این فصل به پیش‌فرض برگرده؟ (جایزه‌هایِ دست‌کاری‌شده از بین می‌رن؛ چیزایی که بازیکن‌ها قبلاً گرفتن سر جاشونه)",
                    [[Btn("✅ بله", callback_data="admin_bp_rreset:y")], [Btn("❌ انصراف", callback_data="admin_bp_rewards")]])
        return
    session = db.get_session()
    try:
        s = E.current_season(session)
        E.admin_reset_rewards(session, s.id)
    finally:
        session.close()
    await cb_rewards(update, context)


# --- چلنج‌ها ---
async def cb_list(update, context):
    page = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        defs = (session.query(BD.BpChallengeDef).filter_by(deleted=False)
                .order_by(BD.BpChallengeDef.period, BD.BpChallengeDef.diff, BD.BpChallengeDef.id).all())
        pages = max(1, math.ceil(len(defs) / PAGE))
        page = max(0, min(page, pages - 1))
        rows = [[Btn(f"{'✅' if d.enabled else '⛔️'} {BD.PERIODS[d.period][:2]}{['', '⭐', '⭐⭐', '⭐⭐⭐', '💀'][d.diff]} {d.title}"[:60],
                     callback_data=f"admin_bp_def:{d.id}")] for d in defs[page * PAGE:(page + 1) * PAGE]]
    finally:
        session.close()
    rows.append([Btn("➕ چلنجِ جدید", callback_data="admin_bp_new")])
    rows.append([Btn("◀️", callback_data=f"admin_bp_list:{max(0, page - 1)}"), Btn(f"{page + 1}/{pages}", callback_data="admin_bp_noop"),
                 Btn("▶️", callback_data=f"admin_bp_list:{min(pages - 1, page + 1)}")])
    rows.append([Btn("🔙 بازگشت", callback_data="admin_bp_menu")])
    await _send(update, f"🎯 چلنج‌ها ({len(defs)})\n\nروزانه/هفتگی: هر بازیکن از هر درجه یکی (تصادفیِ ثابت) می‌گیره؛ فصلی: همه‌شون.", rows)


async def cb_new(update, context):
    await _ask(update, context,
               "➕ چلنجِ جدید: «عنوان | معیار | تعداد | XP | درجه | دوره»\nمثال:\n🎲 ۵ دور کازینو | casino_played | 5 | 400 | 2 | daily\n\n"
               "معیارها:\n" + "\n".join(f"• {k} = {v}" for k, v in E.METRIC_LABEL.items()) +
               "\n\nدرجه: 1 آسان، 2 متوسط، 3 سخت، 4 الیت   |   دوره: daily / weekly / season",
               {"type": "bp_chnew"}, "admin_bp_list:0")


async def cb_def(update, context):
    did = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        d = session.get(BD.BpChallengeDef, did)
        if d is None or d.deleted:
            await update.callback_query.answer("پیدا نشد", show_alert=True)
            return
        lines = [f"{'✅' if d.enabled else '⛔️'} {d.title}", ""]
        for k, lab, _t in BD.CH_FIELDS:
            v = getattr(d, k)
            if k == "metric":
                v = f"{v} ({E.METRIC_LABEL.get(v, '؟')})"
            elif k == "diff":
                v = BD.DIFF.get(v, v)
            elif k == "period":
                v = BD.PERIODS.get(v, v)
            lines.append(f"• {lab}: {v}")
    finally:
        session.close()
    rows = [[Btn(f"✏️ {lab[:45]}", callback_data=f"admin_bp_df:{did}:{k}")] for k, lab, _t in BD.CH_FIELDS]
    rows.append([Btn("🔁 فعال/غیرفعال", callback_data=f"admin_bp_dtgl:{did}"), Btn("🗑 حذف", callback_data=f"admin_bp_ddel:{did}")])
    rows.append([Btn("🔙 لیست", callback_data="admin_bp_list:0")])
    await _send(update, "\n".join(lines), rows)


async def cb_df(update, context):
    _, did, key = update.callback_query.data.split(":")
    extra = ("\nمعیارها: " + ", ".join(E.METRIC_LABEL)) if key == "metric" else ""
    await _ask(update, context, f"✏️ {BD.CH_LABEL[key]}{extra}\nمقدارِ جدید رو بفرست:", {"type": "bp_chdf", "id": int(did), "key": key}, f"admin_bp_def:{did}")


async def cb_dtgl(update, context):
    did = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        d = session.get(BD.BpChallengeDef, did)
        if d is not None:
            d.enabled = not d.enabled
            session.commit()
    finally:
        session.close()
    await cb_def(update, context)


async def cb_ddel(update, context):
    parts = update.callback_query.data.split(":")
    did = int(parts[1])
    if len(parts) == 2:
        await _send(update, "⚠️ این چلنج حذف بشه؟ (XPِ قبلاً گرفته‌شده سر جاشه)",
                    [[Btn("✅ بله", callback_data=f"admin_bp_ddel:{did}:y")], [Btn("❌ انصراف", callback_data=f"admin_bp_def:{did}")]])
        return
    session = db.get_session()
    try:
        d = session.get(BD.BpChallengeDef, did)
        if d is not None:
            d.deleted = True
            session.commit()
    finally:
        session.close()
    update.callback_query.data = "admin_bp_list:0"
    await cb_list(update, context)


# --- اعطا ---
async def cb_grant(update, context):
    await _ask(update, context,
               "🧰 اعطا به بازیکن (آیدیِ عددیِ تلگرام):\n"
               "• XP: «آیدی | xp | مقدار»\n• پریمیوم: «آیدی | premium»\n"
               "• بوستر: «آیدی | booster | نوع | درصد | تعدادِ‌استفاده | مدت(دقیقه)»\n\n"
               "مثال‌ها:\n123456 | xp | 5000\n123456 | premium\n123456 | booster | heist_loot | 30 | 3 | 0\n"
               "123456 | booster | hop_boost | 25 | 0 | 120\n\nنوعِ بوستر: " + ", ".join(BD.BOOSTER_KINDS),
               {"type": "bp_grant"})


async def bp_admin_awaiting_handler(update, context, state):
    text = (update.message.text or "").strip()
    stype = state["type"]
    session = db.get_session()
    rows = [[Btn("🔙 منوی بتل‌پس", callback_data="admin_bp_menu")]]
    try:
        if stype == "bp_cfg":
            v = E.admin_set_cfg(session, state["key"], text)
            reply = f"✅ {BD.CFG_LABEL[state['key']]} ← {v}"
            if state["key"] in HOP_KEYS:
                rows = [[Btn("🦘 برگشت به درصدِ هاپ", callback_data="admin_bp_hop")]] + rows
        elif stype == "bp_snew":
            name, days = None, None
            if text and text != "-":
                parts = [x.strip() for x in text.split("|")]
                name = parts[0] or None
                if len(parts) > 1 and parts[1]:
                    try:
                        days = int(float(parts[1].translate(E._FA)))
                    except ValueError:
                        raise BpError("تعدادِ روز باید عدد باشه.")
            s = E.admin_new_season(session, name, days)
            reply = f"✅ فصلِ «{s.name}» شروع شد (تا {s.ends_at:%Y-%m-%d})."
        elif stype == "bp_sext":
            try:
                days = int(float(text.translate(E._FA)))
            except ValueError:
                raise BpError("عدد بفرست.")
            s = E.admin_extend(session, days)
            reply = f"✅ فصل تا {s.ends_at:%Y-%m-%d} تمدید شد."
        elif stype == "bp_tpick":
            try:
                t = int(text.translate(E._FA))
            except ValueError:
                raise BpError("عدد بفرست.")
            s = E.current_season(session)
            if not (1 <= t <= s.tiers):
                raise BpError(f"تیر بین ۱ تا {s.tiers} باشه.")
            reply = f"✅ تیر {t}"
            rows = [[Btn(f"✏️ ویرایشِ تیر {t}", callback_data=f"admin_bp_tier:{t}")]] + rows
        elif stype == "bp_te":
            s = E.current_season(session)
            E.admin_set_tier(session, s.id, state["tier"], state["track"], text)
            reply = f"✅ جایزه‌ی تیر {state['tier']} ({state['track']}) ذخیره شد."
            rows = [[Btn("🔙 برگشت", callback_data=f"admin_bp_tier:{state['tier']}")]] + rows
        elif stype == "bp_chnew":
            parts = [x.strip() for x in text.split("|")]
            if len(parts) != 6:
                raise BpError("فرمت: عنوان | معیار | تعداد | XP | درجه | دوره")
            d = E.admin_create_challenge(session, *parts)
            reply = f"✅ چلنجِ «{d.title}» ساخته شد."
            rows = [[Btn("⚙️ تنظیمش", callback_data=f"admin_bp_def:{d.id}")]] + rows
        elif stype == "bp_chdf":
            d = E.admin_set_challenge(session, state["id"], state["key"], text)
            reply = f"✅ {BD.CH_LABEL[state['key']]} ← {getattr(d, state['key'])}"
            rows = [[Btn("🔙 برگشت", callback_data=f"admin_bp_def:{d.id}")]] + rows
        elif stype == "bp_grant":
            parts = [x.strip() for x in text.split("|")]
            if len(parts) < 2 or not parts[0].lstrip("-").isdigit():
                raise BpError("فرمت نامعتبر.")
            uid, what = int(parts[0]), parts[1]
            if what == "xp":
                if len(parts) < 3:
                    raise BpError("مقدارِ XP رو بده.")
                u = E.admin_grant(session, uid, "xp", float(parts[2].translate(E._FA)))
            elif what == "premium":
                u = E.admin_grant(session, uid, "premium")
            elif what == "booster":
                if len(parts) < 3:
                    raise BpError("نوعِ بوستر رو بده.")
                num = lambda i: float(parts[i].translate(E._FA)) if len(parts) > i and parts[i] else 0
                u = E.admin_grant(session, uid, "booster", parts[2], num(3), int(num(4)), int(num(5)))
            else:
                raise BpError("نوع: xp / premium / booster")
            reply = f"✅ برایِ {u.first_name or u.telegram_id} اعمال شد."
        else:
            reply = "؟"
    except BpError as e:
        session.rollback()
        reply = f"❌ {e}"
    except ValueError:
        session.rollback()
        reply = "❌ مقدارها باید عدد باشن."
    finally:
        session.close()
    await update.message.reply_text(reply, reply_markup=Kb(rows))


ADMIN_BP_CALLBACKS = {
    "admin_bp_menu": cb_menu, "admin_bp_toggle": cb_toggle, "admin_bp_noop": cb_noop, "admin_bp_hop": cb_hop,
    "admin_bp_cfg": cb_cfg, "admin_bp_cfgk": cb_cfgk,
    "admin_bp_season": cb_season, "admin_bp_snew": cb_snew, "admin_bp_sext": cb_sext, "admin_bp_send": cb_send,
    "admin_bp_rewards": cb_rewards, "admin_bp_rp": cb_rp, "admin_bp_tpick": cb_tpick, "admin_bp_tier": cb_tier,
    "admin_bp_te": cb_te, "admin_bp_rreset": cb_rreset,
    "admin_bp_list": cb_list, "admin_bp_new": cb_new, "admin_bp_def": cb_def, "admin_bp_df": cb_df,
    "admin_bp_dtgl": cb_dtgl, "admin_bp_ddel": cb_ddel, "admin_bp_grant": cb_grant,
}
