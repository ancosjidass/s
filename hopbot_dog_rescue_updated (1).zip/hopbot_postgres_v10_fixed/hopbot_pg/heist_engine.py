# -*- coding: utf-8 -*-
"""
موتورِ «سرقت تیمی هاپویی» - فقط منطقِ خالص (بدونِ دیتابیس، بدونِ تلگرام، بدونِ هیچ پکیجِ خارجی).

هرچی اینجاست قطعی (Deterministic) و با Seed قابل بازتولیده: با همون Seed همیشه همون
ترتیبِ رنگ‌ها، همون جاي آیتم‌ها، همون ارزش‌ها و همون نتیجه‌ی ریسکِ آیتم‌ها درمیاد.
هیچ عددِ بالانسی اینجا Hard-code نشده؛ همه‌چیز از دیکشنریِ تنظیماتِ مکان (cfg) خونده می‌شه
که از پنلِ ادمین میاد و موقع شروعِ واقعیِ عملیات Snapshot می‌شه.
"""
import random
import secrets

# ---------------------------------------------------------------------------
# نقش‌ها
# ---------------------------------------------------------------------------
ROLES = ("spy", "safe", "carrier", "driver")           # ترتیبِ اسلات‌ها: ۱..۴
ROLE_FA = {"spy": "جاسوس", "safe": "صندوق‌دار", "carrier": "جابه‌جا‌کننده", "driver": "راننده"}
ROLE_EMOJI = {"spy": "🕵️", "safe": "🔓", "carrier": "📦", "driver": "🚗"}
TEAM_SIZE = 4


def role_of_slot(slot: int) -> str:
    if not 1 <= slot <= TEAM_SIZE:
        raise ValueError("اسلاتِ نامعتبر")
    return ROLES[slot - 1]


def role_label(role: str) -> str:
    return f"{ROLE_EMOJI[role]} {ROLE_FA[role]}"


# ---------------------------------------------------------------------------
# State Machine
# ---------------------------------------------------------------------------
RECRUITING, FULL, SPY, SAFE, CARRIER, DRIVER, SETTLED, CANCELLED = (
    "RECRUITING", "FULL", "SPY", "SAFECRACKER", "CARRIER", "DRIVER", "SETTLED", "CANCELLED")

PHASE_ORDER = (SPY, SAFE, CARRIER, DRIVER)
PHASE_ROLE = {SPY: "spy", SAFE: "safe", CARRIER: "carrier", DRIVER: "driver"}
ACTIVE_PHASES = set(PHASE_ORDER)
OPEN_STATUSES = {RECRUITING, FULL} | ACTIVE_PHASES        # یعنی کاربر هنوز درگیرِ این عملیاته

TRANSITIONS = {
    RECRUITING: {FULL, SPY, CANCELLED},
    FULL: {SPY, CANCELLED},
    SPY: {SAFE, SETTLED},
    SAFE: {CARRIER, SETTLED},
    CARRIER: {DRIVER, SETTLED},
    DRIVER: {SETTLED},
    SETTLED: set(),
    CANCELLED: set(),
}


def can_transition(a: str, b: str) -> bool:
    return b in TRANSITIONS.get(a, set())


def next_phase(phase: str):
    i = PHASE_ORDER.index(phase)
    return PHASE_ORDER[i + 1] if i + 1 < len(PHASE_ORDER) else None


# ---------------------------------------------------------------------------
# Random (Seed سمتِ سرور؛ کاربر هیچ‌وقت نمی‌بینه/نمی‌تونه تعیینش کنه)
# ---------------------------------------------------------------------------
def new_seed() -> int:
    return secrets.randbits(62)


def rng(seed: int, *parts) -> random.Random:
    """هر «هدف» (رنگ‌ها، جای آیتم‌ها، ...) استریمِ مستقلِ خودش رو داره؛ پس اضافه‌شدنِ یه
    Random تو یه بخش، نتیجه‌ی بخش‌های دیگه رو عوض نمی‌کنه (برای Replay/Audit مهمه)."""
    return random.Random("heist|%s|%s" % (seed, "|".join(str(p) for p in parts)))


# ---------------------------------------------------------------------------
# اثرِ مهارت (Generic، قابل تنظیم)
# ---------------------------------------------------------------------------
def effective_level(level: int, max_skill: int) -> int:
    """سطحِ مؤثر: منفی نمی‌شه و از سقفِ مؤثر (اگه > 0 باشه) بالاتر نمی‌ره. سقفِ 0 = بدونِ سقف."""
    lv = max(0, int(level))
    if max_skill and max_skill > 0:
        lv = min(lv, int(max_skill))
    return lv


def clamp(v, lo=None, hi=None):
    if lo is not None and v < lo:
        v = lo
    if hi is not None and v > hi:
        v = hi
    return v


def skill_value(base, per_level, level, max_skill=0, lo=None, hi=None):
    """base + per_level × سطحِ مؤثر، با کفِ/سقفِ مقدار. (per_level برای کاهش‌ها منفیه.)"""
    return clamp(base + per_level * effective_level(level, max_skill), lo, hi)


def spy_length(cfg: dict, skill: int, pool_size: int = 0) -> int:
    n = skill_value(cfg["spy_base_colors"], -cfg["spy_per_skill_colors"], skill, cfg.get("spy_max_skill", 0))
    n = int(round(n))
    n = max(int(cfg.get("spy_min_colors", 1)), 1, n)      # هیچ‌وقت صفر/منفی نمی‌شه
    return n


def carrier_seconds(cfg: dict, skill: int) -> int:
    v = skill_value(cfg["carrier_base_sec"], -cfg["carrier_per_skill_sec"], skill, cfg.get("carrier_max_skill", 0))
    return int(max(int(cfg.get("carrier_min_sec", 1)), 1, round(v)))


def driver_seconds(cfg: dict, skill: int) -> int:
    v = skill_value(cfg["driver_base_sec"], -cfg["driver_per_skill_sec"], skill, cfg.get("driver_max_skill", 0))
    return int(max(int(cfg.get("driver_min_sec", 1)), 1, round(v)))


def item_fail_pct(item_base_pct: float, cfg: dict, skill: int) -> float:
    """درصدِ ریسکِ از دست رفتنِ یه آیتم بعد از اثرِ مهارتِ صندوق‌دار (درصدی، بینِ min و max)."""
    v = skill_value(item_base_pct, -cfg["safe_per_skill_pct"], skill, cfg.get("safe_max_skill", 0))
    return float(clamp(v, cfg.get("safe_min_pct", 0), cfg.get("safe_max_pct", 100)))


# ---------------------------------------------------------------------------
# جاسوس: پازلِ رنگ
# ---------------------------------------------------------------------------
def gen_sequence(seed: int, attempt: int, length: int, pool_size: int, allow_repeat: bool = False) -> list:
    """لیستی از ایندکسِ رنگ‌ها (۰..pool_size-1). هر تلاشِ جدید یه استریمِ جدید داره."""
    if pool_size < 1:
        raise ValueError("Color Pool خالیه")
    r = rng(seed, "spy", attempt)
    if allow_repeat or length > pool_size:
        return [r.randrange(pool_size) for _ in range(length)]
    return r.sample(range(pool_size), length)


def render_colors(idx_list, palette) -> str:
    return " ".join(palette[i] for i in idx_list)


def reverse_display(idx_input, palette) -> str:
    """نمایشِ برعکس (راست→چپ) فقط برای نمایشه؛ خودِ ورودی همچنان چپ→راست ذخیره/مقایسه می‌شه."""
    return " ".join(palette[i] for i in reversed(idx_input))


def sequence_ok(target, given) -> bool:
    return list(target) == list(given)


# ---------------------------------------------------------------------------
# صندوق‌دار: چیدنِ آیتم‌ها روی گرید
# ---------------------------------------------------------------------------
GRID_COLS = 4


def place_items(seed: int, cells: int, pool: list, count: int, variance: float) -> list:
    """
    pool: لیستِ دیکشنری {id,name,base_value,weight,fail_pct(None=پیش‌فرضِ مکان),variance(None=پیش‌فرضِ مکان)}.
    خروجی: لیستی از آیتم‌های واقعی با cell، ارزشِ نهایی (Base ± Variance، مستقل برای هر آیتم).
    تعدادِ آیتم هیچ‌وقت از تعدادِ خونه‌ها بیشتر نمی‌شه.
    """
    count = max(0, min(int(count), int(cells)))
    if count == 0 or not pool:
        return []
    cells_pick = sorted(rng(seed, "place").sample(range(cells), count))
    pr = rng(seed, "pick")
    weights = [max(0.0, float(p.get("weight", 1) or 0)) for p in pool]
    if sum(weights) <= 0:
        weights = [1.0] * len(pool)
    out = []
    for n, cell in enumerate(cells_pick):
        it = pr.choices(pool, weights=weights, k=1)[0]
        var = it.get("variance")
        var = float(variance if var is None else var)
        vr = rng(seed, "val", n)
        val = int(it["base_value"]) + (vr.randint(-int(var), int(var)) if var >= 1 else 0)
        out.append({"cell": cell, "item_id": it.get("id"), "name": it["name"],
                    "base_value": int(it["base_value"]), "value": max(0, val),
                    "fail_pct": it.get("fail_pct")})
    return out


def roll_failures(seed: int, items: list, pcts: list) -> list:
    """هر آیتم Roll مستقلِ خودش رو داره (استریمِ جدا با شماره‌ی خونه). True یعنی آیتم از دست رفت."""
    res = []
    for it, pct in zip(items, pcts):
        r = rng(seed, "fail", it["cell"]).random() * 100.0
        res.append(r < pct)
    return res


# ---------------------------------------------------------------------------
# تقسیمِ غنیمت (Integer-safe)
# ---------------------------------------------------------------------------
def split_loot(total: int, members: int, mode: str, seed: int = 0, creator_idx: int = 0):
    """
    خروجی: (مجموعِ نهایی پرداختی, لیستِ سهمِ هر عضو)
      normalize: مجموع به نزدیک‌ترین مضربِ ۴ (به پایین) گرد می‌شه تا تقسیم دقیق باشه (باقی‌مانده‌ی ریز حذف می‌شه)
      creator  : باقی‌مانده به سازنده می‌رسه
      random   : باقی‌مانده به یه عضوِ تصادفی (با Seed) می‌رسه
    """
    total = max(0, int(total))
    members = max(1, int(members))
    base, rem = divmod(total, members)
    shares = [base] * members
    if mode == "creator":
        shares[creator_idx] += rem
    elif mode == "random":
        shares[rng(seed, "remainder").randrange(members)] += rem
    else:
        total -= rem
    return sum(shares), shares


# ---------------------------------------------------------------------------
# متن‌کمکی
# ---------------------------------------------------------------------------
def fmt_int(n) -> str:
    return f"{int(round(n)):,}"


def fmt_clock(seconds) -> str:
    s = max(0, int(seconds))
    return f"{s // 60:02d}:{s % 60:02d}"


def fmt_long(seconds) -> str:
    s = max(0, int(seconds))
    return f"{s // 3600:02d}:{(s % 3600) // 60:02d}:{s % 60:02d}"


def fmt_duration_fa(minutes) -> str:
    m = int(minutes)
    if m % 60 == 0 and m >= 60:
        return f"{m // 60} ساعت"
    if m >= 60:
        return f"{m // 60} ساعت و {m % 60} دقیقه"
    return f"{m} دقیقه"
