# -*- coding: utf-8 -*-
"""
فرمول‌های اقتصادی بازی.
همه‌ی این فرمول‌ها از روی مقادیر جدول game_config می‌خونن، پس مالک می‌تونه
از پنل مدیریت (بدون دست‌زدن به کد) پارامترهاشون رو تغییر بده.
"""
import datetime
import random
from db import cfg_get, cfg_get_float, cfg_get_int, cfg_set


def xp_required_for_level(session, level: int) -> float:
    """
    XP لازم برای رفتن از `level` به `level+1`.
    سطح ۱->۲ کمترین فاصله رو داره (پیش‌فرض ۴۰۰) و هرچی سطح بالاتر بره
    فاصله‌ها بزرگ‌تر می‌شن (رشد خطی + یک جزء درجه‌دوم برای شتاب‌گرفتن در سطوح آخر).
    """
    base = cfg_get_float(session, "level_base_xp")
    growth = cfg_get_float(session, "level_growth")
    quad = cfg_get_float(session, "level_quad")
    n = level - 1
    return base + n * growth + quad * (n ** 2)


def apply_xp_gain(session, user, amount: float):
    """XP اضافه می‌کنه و اگر لازم بود چند سطح پشت‌سرهم بالا می‌بره."""
    total_levels = cfg_get_int(session, "total_levels")
    user.xp += amount
    leveled_up = 0
    while user.level < total_levels:
        need = xp_required_for_level(session, user.level)
        if user.xp >= need:
            user.xp -= need
            user.level += 1
            leveled_up += 1
        else:
            break
    return leveled_up


def factory_ranks_ordered(session):
    import db
    return session.query(db.FactoryRank).order_by(db.FactoryRank.order).all()


# --- کشِ «مقام‌ها» و «سطح‌هایِ کارخونه» -------------------------------------------------
# این دو جدول تقریباً هیچ‌وقت عوض نمی‌شن (فقط مالک از پنل) ولی هر «هاپ منیج» ۶ کوئری بهشون
# می‌زد - رویِ دیتابیسِ ریموت هر کوئری یه رفت‌وبرگشتِ شبکه‌ست. حالا یه‌بار خونده می‌شه و تا
# وقتی کسی (مالک) ردیفی رو عوض نکرده تو حافظه می‌مونه. هر insert/update/delete رویِ این دو
# مدل کش رو خالی می‌کنه (و بعد از commit هم دوباره، تا خوندنِ وسطِ تراکنش چیزِ کهنه نمونه)؛
# TTL هم به‌عنوانِ کمربندِ ایمنی هست.
import threading as _threading
import time as _time_mod
from types import SimpleNamespace as _NS

_FX = {"at": 0.0, "ranks": None, "levels": None, "dirty": False}
_FX_LOCK = _threading.Lock()
_FX_TTL = 60.0


def fx_cache_clear():
    with _FX_LOCK:
        _FX["ranks"] = None
        _FX["levels"] = None
        _FX["at"] = 0.0


def _fx_load():
    import db
    s = db.SessionLocal()
    try:
        ranks = {r.order: _NS(id=r.id, order=r.order, name=r.name, num_levels=r.num_levels)
                 for r in s.query(db.FactoryRank).all()}
        levels = {d.level_number: _NS(level_number=d.level_number, production_per_min=d.production_per_min,
                                      capacity=d.capacity, upgrade_cost=d.upgrade_cost)
                  for d in s.query(db.FactoryLevelDef).all()}
    finally:
        s.close()
    with _FX_LOCK:
        _FX["ranks"], _FX["levels"], _FX["at"] = ranks, levels, _time_mod.monotonic()
    return ranks, levels


def _fx_get():
    import os
    if os.environ.get("FACTORY_CACHE", "1") == "0":
        raise RuntimeError("factory cache disabled")   # → هر دو تابع به کوئریِ مستقیمِ قبلی برمی‌گردن
    if _FX["ranks"] is None or (_time_mod.monotonic() - _FX["at"]) > _FX_TTL:
        return _fx_load()
    return _FX["ranks"], _FX["levels"]


def _fx_install_events():
    import db
    from sqlalchemy import event
    from sqlalchemy.orm import Session

    def _mark(mapper, connection, target):
        _FX["dirty"] = True
        fx_cache_clear()

    for model in (db.FactoryRank, db.FactoryLevelDef):
        for ev in ("after_insert", "after_update", "after_delete"):
            event.listen(model, ev, _mark)

    @event.listens_for(Session, "after_commit")
    def _after_commit(session):
        if _FX["dirty"]:
            _FX["dirty"] = False
            fx_cache_clear()


_fx_events_ready = False


def get_rank_by_order(session, order):
    global _fx_events_ready
    import db
    try:
        if not _fx_events_ready:
            _fx_install_events()
            _fx_events_ready = True
        ranks, _ = _fx_get()
        return ranks.get(order)
    except Exception:
        return session.query(db.FactoryRank).filter_by(order=order).first()


def current_rank(session, user):
    return get_rank_by_order(session, user.factory_rank_order)


def factory_level_values(session, level_number: int):
    """
    مقدارِ سطحِ «نسبیِ مشترک» شماره‌ی level_number: این سطح فارغ از اینکه کاربر
    تو کدوم مقامیه همیشه همین تولید/ظرفیت/هزینه رو داره (سطح ۵ مقامِ اول دقیقا
    مثل سطح ۵ مقامِ دومه؛ فرقِ مقام‌ها فقط تعداد سطح‌هاشونه). اگه مالک برای این
    سطح دستی چیزی ست نکرده باشه، از فرمولِ پیش‌فرضِ پنل محاسبه می‌شه.
    برمی‌گردونه: (تولید در دقیقه، ظرفیت، هزینه‌ی ارتقا به این سطح).
    """
    import db
    try:
        get_rank_by_order  # noqa  (مطمئن می‌شه هوکِ بی‌اعتبارسازیِ کش نصب شده)
        if not _fx_events_ready:
            get_rank_by_order(session, 1)
        row = _fx_get()[1].get(level_number)
    except Exception:
        row = session.get(db.FactoryLevelDef, level_number)
    n = level_number - 1
    base = cfg_get_float(session, "production_base")
    inc = cfg_get_float(session, "production_increment")
    cap_base = cfg_get_float(session, "factory_capacity_base")
    cap_inc = cfg_get_float(session, "factory_capacity_increment")
    cost_base = cfg_get_float(session, "production_upgrade_base_cost")
    growth = cfg_get_float(session, "production_upgrade_growth")

    production = row.production_per_min if (row and row.production_per_min is not None) else base + inc * n
    capacity = row.capacity if (row and row.capacity is not None) else cap_base + cap_inc * n
    cost = row.upgrade_cost if (row and row.upgrade_cost is not None) else round(cost_base * (growth ** n), 0)
    return production, capacity, cost


def sync_user_production(session, user):
    """production_per_min رو با سطحِ نسبیِ فعلیِ کاربر هماهنگ می‌کنه (کش)."""
    production, _, _ = factory_level_values(session, user.factory_level)
    user.production_per_min = production
    return production


def factory_capacity(session, user):
    _, capacity, _ = factory_level_values(session, user.factory_level)
    return capacity


def factory_next_upgrade_cost(session, user):
    """هزینه‌ی ارتقای عادیِ سطح (داخلِ همون مقام). اگه به آخرِ سطوحِ مقامِ فعلی
    رسیده باشه، None برمی‌گردونه (باید بره مقامِ بعد، نه ارتقای سطحِ عادی)."""
    rank = current_rank(session, user)
    if not rank or user.factory_level >= rank.num_levels:
        return None
    _, _, cost = factory_level_values(session, user.factory_level + 1)
    return cost


def factory_can_advance_rank(session, user):
    """کاربر به آخرِ سطوحِ مقامِ فعلی رسیده و مقامِ بعدی هم وجود داره؟"""
    rank = current_rank(session, user)
    if not rank or user.factory_level < rank.num_levels:
        return False
    return get_rank_by_order(session, user.factory_rank_order + 1) is not None


def factory_is_maxed(session, user):
    """کاربر به بالاترین سطحِ بالاترین مقامِ موجود رسیده (دیگه هیچ ارتقایی نیست)."""
    rank = current_rank(session, user)
    if not rank:
        return True
    if user.factory_level < rank.num_levels:
        return False
    return get_rank_by_order(session, user.factory_rank_order + 1) is None


def factory_upgrade_level(session, user):
    """ارتقای عادیِ سطح، داخلِ همون مقام (بدونِ تغییرِ مقام و بدونِ ریست)."""
    user.factory_level += 1
    sync_user_production(session, user)


def factory_advance_rank(session, user):
    """رفتن به مقامِ بعد: سطح به ۱ برمی‌گرده و تولید/ظرفیت ریست می‌شه."""
    user.factory_rank_order += 1
    user.factory_level = 1
    sync_user_production(session, user)


def supermarket_upgrade_cost(session, current_supermarket_level: int) -> float:
    base = cfg_get_float(session, "supermarket_upgrade_base_cost")
    growth = cfg_get_float(session, "supermarket_upgrade_growth")
    return round(base * (growth ** current_supermarket_level), 0)


def sync_dog_food(session, user):
    """غذای سگ رو بر اساسِ زمانِ واقعیِ سپری‌شده کم می‌کنه (نه با کلیکِ دکمه‌ی
    برداشت - اون روش قبلی باگ داشت چون کسی که کمتر کلیک می‌کرد عملاً غذای
    بیشتری داشت). باید همیشه قبل از هر خوندن/تصمیمی (تولید/برداشت/نمایش/تغذیه)
    صدا زده بشه تا user.dog_food همیشه به‌روز باشه."""
    nowt = datetime.datetime.utcnow()
    last = user.dog_food_last_check_at or nowt
    if isinstance(last, str):   # دیتابیسی که ستونش TEXT مونده (db._pg_fix_datetime_column_types درستش می‌کنه)
        try:
            last = datetime.datetime.fromisoformat(last.strip())
        except Exception:
            last = nowt
    minutes = max(0.0, (nowt - last).total_seconds() / 60.0)
    if minutes > 0:
        user.dog_food = max(0.0, (user.dog_food or 0) - minutes)
    user.dog_food_last_check_at = nowt
    return user.dog_food


def format_minutes(total_minutes) -> str:
    total_minutes = max(0, int(round(total_minutes or 0)))
    days, rem = divmod(total_minutes, 1440)
    hours, minutes = divmod(rem, 60)
    parts = []
    if days:
        parts.append(f"{days} روز")
    if hours:
        parts.append(f"{hours} ساعت")
    if minutes or not parts:
        parts.append(f"{minutes} دقیقه")
    return " و ".join(parts)


def sync_factory_pending(session, user):
    """
    از آخرین باری که چک شده تا الان، تولیدِ جدید رو حساب می‌کنه و به «تولیدِ
    منتظرِ برداشت» (factory_pending) اضافه می‌کنه - ولی به هاپ پوینت واریزش
    نمی‌کنه (فقط با فشردنِ دکمه‌ی «برداشت» واریز می‌شه). اگه تولیدِ منتظر به
    سقفِ ظرفیتِ سطح فعلی برسه، دیگه بیشتر نمی‌شه تا کاربر برداشت کنه.

    اگه سگِ کاربر گشنه باشه (dog_food صفر یا کمتر - که حالا زمانی و مستقل از
    کلیک‌کردن کم می‌شه، نگاه کن به sync_dog_food)، کارخونه اصلاً تو این مدت
    تولید نمی‌کنه (نه فقط قابل‌برداشت نیست) - یعنی اگه از امروز تا فردا غذا
    نده، تولیدِ اون بازه‌ی زمانی کاملاً از دست می‌ره، نه اینکه بعداً جبران بشه.
    """
    sync_dog_food(session, user)
    nowt = datetime.datetime.utcnow()
    last = user.last_collect_at or nowt
    minutes = max(0.0, (nowt - last).total_seconds() / 60.0)
    cap = factory_capacity(session, user)
    is_hungry = (user.dog_food or 0) <= 0
    if not is_hungry and user.factory_pending < cap and minutes > 0:
        mult = factory_production_multiplier(session, user)
        gained = minutes * user.production_per_min * mult
        try:
            import battlepass_engine as _bp
            gained *= _bp.production_mult(session, user.telegram_id)   # بوسترِ تولیدِ بتل‌پس
        except Exception:
            pass
        user.factory_pending = min(cap, (user.factory_pending or 0) + gained)
    user.last_collect_at = nowt
    return user.factory_pending, cap


def collect_factory_production(session, user):
    """تولیدِ منتظرِ برداشت رو به هاپ پوینت کاربر واریز می‌کنه. این تابع فقط باید
    وقتی صدا زده بشه که کاربر خودش دکمه‌ی «برداشت» رو زده باشه - نه خودکار و نه
    فقط با بازکردنِ منو، چون قبلا این باعث می‌شد کارخونه «خودکار» برداشت بشه."""
    sync_factory_pending(session, user)
    gained = user.factory_pending
    user.hop_points += gained
    user.factory_pending = 0
    return gained


# ---------------------------------------------------------------------------
# بوستر/گروگان/جریمه - فقط برای «سیستمِ حمله» (نگاه کن به attack.py). این
# توابع اینجان (نه تو attack.py) که economy.py بتونه بدونِ importِ attack ازشون
# استفاده کنه (جلوگیری از importِ چرخه‌ای: attack.py از economy استفاده می‌کنه،
# نه برعکس).
# ---------------------------------------------------------------------------

def active_booster_pct(session, user, booster_type: str) -> float:
    """درصدِ بوسترِ فعالِ این کاربر از این نوع (money/power)، یا ۰ اگه فعال
    نباشه. با مقایسه‌ی ends_at > الان چک می‌شه (نیازی به پاکسازیِ دستی نیست)."""
    import db
    nowt = datetime.datetime.utcnow()
    b = (
        session.query(db.ActiveBooster)
        .filter(db.ActiveBooster.user_id == user.telegram_id,
                db.ActiveBooster.booster_type == booster_type,
                db.ActiveBooster.ends_at > nowt)
        .order_by(db.ActiveBooster.ends_at.desc())
        .first()
    )
    return b.pct if b else 0.0


def money_income_multiplier(session, user) -> float:
    """ضریبِ افزایشِ درآمد از بوسترِ پولِ فعال (تاکسی/Hop Manager/فروشِ غذا/
    پلتفرم/لایک) - هرگز رو قیمت/نوسانِ ارزِ دیجیتال اعمال نمی‌شه."""
    return 1.0 + active_booster_pct(session, user, "money") / 100.0


def power_boost_multiplier(session, user) -> float:
    """ضریبِ افزایشِ قدرتِ حمله از بوسترِ قدرتِ فعال."""
    return 1.0 + active_booster_pct(session, user, "power") / 100.0


def factory_production_multiplier(session, user) -> float:
    """ضریبِ کلیِ تولیدِ Hop Manager (کارخونه) - شاملِ بوسترِ پول + اثرِ
    گروگان‌گیری (قربانی=۱/۴، مهاجم=۴برابر) + جریمه‌های موقتِ سیستمِ حمله
    (شکستِ تلاش/کشته‌شدنِ مهاجم). این ضریب فقط رو Hop Manager اثر داره - نه
    رو تاکسی/پلتفرم/فروشِ غذا/لایک (اونا فقط بوسترِ پول رو مستقیم می‌گیرن) و
    نه رو ارزِ دیجیتال."""
    import db
    nowt = datetime.datetime.utcnow()
    mult = money_income_multiplier(session, user)

    victim_row = (
        session.query(db.Hostage)
        .filter(db.Hostage.victim_id == user.telegram_id, db.Hostage.status == "active", db.Hostage.ends_at > nowt)
        .first()
    )
    if victim_row:
        mult *= cfg_get_float(session, "attack_hostage_victim_production_mult") / 100.0

    attacker_row = (
        session.query(db.Hostage)
        .filter(db.Hostage.attacker_id == user.telegram_id, db.Hostage.status == "active", db.Hostage.ends_at > nowt)
        .first()
    )
    if attacker_row:
        mult *= cfg_get_float(session, "attack_hostage_attacker_production_mult") / 100.0

    penalties = (
        session.query(db.ProductionPenalty)
        .filter(db.ProductionPenalty.user_id == user.telegram_id, db.ProductionPenalty.ends_at > nowt)
        .all()
    )
    for p in penalties:
        mult *= p.multiplier

    return mult


DOG_FOOD_DRAWER_MAX_UNITS = 10  # سقفِ ثابتِ ظرفیتِ کشویی هاپویی - هیچ سیستم ارتقا/افزایشی نداره


def dog_food_capacity(session, user):
    """ظرفیتِ کشویی هاپویی (به «واحد» - فقط برای فروش/تغذیه‌کردن استفاده می‌شه):
    ثابت و حداکثر DOG_FOOD_DRAWER_MAX_UNITS واحده و مستقل از مقام/سطحِ کارخونه؛
    هیچ سیستمِ ارتقا یا افزایشِ ظرفیتی براش وجود نداره."""
    return DOG_FOOD_DRAWER_MAX_UNITS


def dog_food_capacity_minutes(session, user):
    """ظرفیتِ غذا به دقیقه (سقفِ user.dog_food) - واحدهای بالا رو به دقیقه
    تبدیل می‌کنه (نگاه کن به sync_dog_food برای کم‌شدنِ زمانیش)."""
    minutes_per_unit = cfg_get_float(session, "chef_dog_food_minutes_per_unit")
    return dog_food_capacity(session, user) * minutes_per_unit


def unlocked_dynamic_products(session, user):
    """محصولاتی که مالک از پنل ساخته و به سطحِ محصولاتِ فعلیِ این کاربر رسیدن."""
    import db  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
    return (
        session.query(db.Product)
        .filter(db.Product.is_active == True)  # noqa: E712
        .filter(db.Product.unlock_level <= user.market_product_level)
        .all()
    )


def collect_supermarket_production(session, user, _dynamic_products=None, _user_products=None):
    """
    تولید محصولات سوپرمارکت رو جمع می‌زنه: ۴ محصول ثابت (گوشت گربه/دارچین خیار/
    موز/تخم سگ) + هر محصول دینامیکی که مالک از پنل تعریف کرده و باز شده باشه.
    سرعت تولید در ساعت (supermarket_prod_per_hour) به‌طور مساوی بین همه‌ی
    محصولاتِ فعالِ کاربر تقسیم می‌شه.
    هر چند واحد محصول (پیش‌فرض ۳۰، در پنل قابل تغییر) که جمع بشه، «سطح محصولات»
    کاربر (جدا از سطح ارتقای پولیِ سرعت تولید) یک پله بالا می‌ره و محصولات جدیدی
    که مالک برای اون سطح تعریف کرده باز می‌شن.
    """
    import db

    if not user.has_supermarket:
        return 0
    nowt = datetime.datetime.utcnow()
    last = user.last_market_collect_at or nowt
    hours = max(0.0, (nowt - last).total_seconds() / 3600.0)

    if _dynamic_products is None:
        dynamic_products = unlocked_dynamic_products(session, user)
    else:
        # تیکِ دوره‌ای (jobs.tick_job): لیستِ محصولاتِ فعال یک‌بار برایِ همه‌ی کاربرها خونده شده؛
        # همون فیلترِ unlock_level <= سطحِ محصولاتِ کاربر رو این‌جا تو پایتون اعمال می‌کنیم
        # (همون نتیجه‌ی کوئری، بدونِ یه رفت‌وبرگشتِ جداگونه به دیتابیس برایِ هر کاربر).
        lvl = user.market_product_level
        dynamic_products = [
            p for p in _dynamic_products
            if lvl is not None and p.unlock_level is not None and p.unlock_level <= lvl
        ]
    total_item_types = 4 + len(dynamic_products)
    per_item = (user.supermarket_prod_per_hour / total_item_types) * hours if total_item_types else 0

    user.cat_meat += per_item
    user.cinnamon_cucumber += per_item
    user.banana += per_item
    user.dog_egg += per_item

    for p in dynamic_products:
        if _user_products is not None:
            up = _user_products.get((user.telegram_id, p.id))
        else:
            up = session.query(db.UserProduct).filter_by(user_id=user.telegram_id, product_id=p.id).first()
        if not up:
            up = db.UserProduct(user_id=user.telegram_id, product_id=p.id, amount=0)
            session.add(up)
            if _user_products is not None:
                _user_products[(user.telegram_id, p.id)] = up
        up.amount += per_item

    user.last_market_collect_at = nowt

    total_gained = per_item * total_item_types
    if total_gained > 0:
        user.market_produce_progress += total_gained
        threshold = cfg_get_float(session, "market_produce_per_level")
        if threshold > 0:
            while user.market_produce_progress >= threshold:
                user.market_produce_progress -= threshold
                user.market_product_level += 1

    return total_gained


# ایران دیگه از ۱۴۰۱ ساعتِ تابستونی نداره، پس آفستِ ثابتِ +۰۳:۳۰ همیشه درسته -
# نیازی به zoneinfo/tzdata (که ممکنه رو هاستِ اشتراکی نصب نباشه) نیست.
IRAN_UTC_OFFSET = datetime.timedelta(hours=3, minutes=30)
BANK_INTEREST_HOUR = 9  # ساعتِ سودِ روزانه‌ی بانک، به وقتِ ایران


def _last_bank_checkpoint_utc(nowt_utc: datetime.datetime) -> datetime.datetime:
    """آخرین لحظه‌ای که چک‌پوینتِ «ساعتِ ۹ صبح به وقتِ ایران» رد شده، برگردونده‌شده
    بر حسبِ UTC (که بقیه‌ی کدِ بات هم باهاش کار می‌کنه)."""
    tehran_now = nowt_utc + IRAN_UTC_OFFSET
    boundary_tehran = tehran_now.replace(hour=BANK_INTEREST_HOUR, minute=0, second=0, microsecond=0)
    if tehran_now < boundary_tehran:
        boundary_tehran -= datetime.timedelta(days=1)
    return boundary_tehran - IRAN_UTC_OFFSET


def apply_bank_interest_if_due(session, user):
    """هر روز ساعتِ ۹ صبح (به وقتِ ایران) سود اعمال می‌شه - این یه چک‌پوینتِ
    مطلق و مشترکِ بینِ همه‌ست، نه تایمری که از لحظه‌ی واریزِ خودِ کاربر شروع
    بشه. برای همین حتی کسی که ۷:۵۹:۵۹ (چند ثانیه قبل از ۹) پول رو گذاشته باشه
    هم سرِ همون ۹ صبح سود می‌گیره، چون سود رویِ *بالانسِ فعلی*ِ لحظه‌ی چک‌پوینت
    حساب می‌شه، نه رویِ اینکه از کِی توشه.

    سود فقط تا سقفِ `bank_interest_cap` حساب می‌شه (پیش‌فرض ۱۰ میلیارد)؛
    مازادِ بالانس روی اون سقف، سود نمی‌گیره - حتی اگه درصدِ سود ۱۰۰٪ باشه."""
    if not user.has_bank or user.bank_balance <= 0:
        return 0
    nowt = datetime.datetime.utcnow()
    last_checkpoint = _last_bank_checkpoint_utc(nowt)
    baseline = user.bank_last_interest_at or (last_checkpoint - datetime.timedelta(days=1))
    if baseline >= last_checkpoint:
        return 0  # این چک‌پوینت رو قبلاً گرفته

    # اگه بات چند روز خاموش بوده، همه‌ی چک‌پوینت‌هایِ ردشده رو یکی‌یکی (با
    # ترکیب، درست مثلِ سودِ مرکب) جبران می‌کنیم؛ عددشون طبیعتاً کم و محدوده.
    n_days = int((last_checkpoint - baseline).total_seconds() // 86400)
    n_days = max(1, n_days)

    pct = cfg_get_float(session, "bank_daily_interest_pct") / 100.0
    cap = cfg_get_float(session, "bank_interest_cap")
    gained_total = 0
    for _ in range(n_days):
        eligible = min(user.bank_balance, cap) if cap and cap > 0 else user.bank_balance
        gain = eligible * pct
        user.bank_balance += gain
        gained_total += gain
    user.bank_last_interest_at = last_checkpoint
    if gained_total > 0:
        # برای نمایشِ «آخرین بار چه تاریخی و چقدر سود داده» تو پنلِ بانک،
        # حتی بعدِ اینکه این ویویِ خاص بسته شد، ذخیره‌ش می‌کنیم.
        user.bank_last_interest_amount = gained_total
    return gained_total


def _round_price(p):
    return max(1.0, round(p, 2))


def step_crypto_prices(session):
    """موتورِ جدیدِ نوسانِ قیمت: به‌جای یه جهشِ بزرگ هر چند ساعت یک‌بار (که باعث
    می‌شد قیمت از رویِ خیلی نقطه‌ها «بپره» و سفارش‌های Limit رو غیرمنصفانه رد
    کنه)، هر بار این تابع صدا زده بشه (حداکثر هر ~۶۰ ثانیه، نگاه کن به
    crypto_auto_last_tick_at) یه قدمِ کوچیکِ تصادفی برمی‌داره - دقیقاً مثلِ
    نوسانِ لحظه‌ایِ یه صرافیِ واقعی. قدم‌ها همیشه داخلِ یه «سقفِ حداکثریِ تغییر»
    (crypto_auto_max_change_pct، دقیقاً همون خطِ قرمزی که تو پنل تنظیم می‌شه)
    نسبت‌به قیمتِ لنگرِ شروعِ دوره (period_anchor_price) می‌مونن؛ با تمومِ هر
    دوره (crypto_auto_interval_hours)، یه لنگرِ تازه از قیمتِ فعلی گرفته می‌شه.

    خروجی: لیستی از (currency, old_price, new_price) فقط برای ارزهایی که واقعاً
    قیمتشون عوض شده - این لیست برای چک‌کردنِ آلارم/سفارش (که باید مسیرِ
    old->new رو بررسی کنن، نه فقط مقصد) لازمه."""
    if cfg_get(session, "crypto_auto_enabled") != "1":
        return []

    interval_hours = cfg_get_float(session, "crypto_auto_interval_hours")
    if interval_hours <= 0:
        return []

    nowt = datetime.datetime.utcnow()
    last_tick_raw = cfg_get(session, "crypto_auto_last_tick_at")
    if last_tick_raw:
        try:
            last_tick = datetime.datetime.fromisoformat(last_tick_raw)
            if (nowt - last_tick).total_seconds() < 50:
                return []  # کمتر از ~۱ دقیقه از آخرین قدم گذشته - هنوز زوده
        except ValueError:
            pass

    max_change_pct = cfg_get_float(session, "crypto_auto_max_change_pct") / 100.0
    if max_change_pct <= 0:
        max_change_pct = 0.08

    import db  # وارد کردن دیرهنگام برای جلوگیری از import چرخه‌ای
    changed = []
    for c in session.query(db.Currency).all():
        if (
            not c.period_anchor_price or not c.period_started_at
            or (nowt - c.period_started_at).total_seconds() >= interval_hours * 3600
        ):
            c.period_anchor_price = c.buy_price
            c.period_started_at = nowt

        anchor = c.period_anchor_price or c.buy_price
        lo = anchor * (1 - max_change_pct)
        hi = anchor * (1 + max_change_pct)
        # هر قدم حداکثر ~۱۵٪ از کلِ بازه‌ی مجازِ این دوره - یعنی رسیدن به مرز
        # چند تیک طول می‌کشه، نه یک‌دفعه.
        step_range = max(0.01, (hi - lo) * 0.15)
        old_price = c.buy_price
        new_price = old_price + random.uniform(-step_range, step_range)
        new_price = min(hi, max(lo, new_price))
        new_price = _round_price(new_price)
        if new_price == old_price:
            continue
        c.buy_price = new_price
        spread_ratio = (c.sell_price / old_price) if old_price > 0 else 0.9
        c.sell_price = _round_price(c.buy_price * spread_ratio)
        changed.append((c, old_price, new_price))

    cfg_set(session, "crypto_auto_last_tick_at", nowt.isoformat())
    return changed


async def check_alarms_and_orders(session, context, changed):
    """برای هر ارزی که قیمتش تغییر کرده، چک می‌کنه آیا آلارم یا سفارشی رو
    مسیرِ بینِ قیمتِ قبلی و جدید عبور کرده - نه فقط چک‌کردنِ مقصدِ نهایی، تا
    سفارش‌ها فقط وقتی واقعاً «قیمت از اونجا رد شد» اجرا بشن."""
    import db
    for c, old_price, new_price in changed:
        lo, hi = min(old_price, new_price), max(old_price, new_price)

        alarms = session.query(db.CurrencyAlarm).filter(
            db.CurrencyAlarm.currency_id == c.id,
            db.CurrencyAlarm.target_price >= lo,
            db.CurrencyAlarm.target_price <= hi,
        ).all()
        for a in alarms:
            crossed_up = a.direction == "up" and old_price <= a.target_price <= new_price
            crossed_down = a.direction == "down" and new_price <= a.target_price <= old_price
            if not (crossed_up or crossed_down):
                continue
            if context:
                try:
                    await context.bot.send_message(
                        a.user_id,
                        f"🔔 آلارم! {c.emoji} {c.name} به قیمتِ {a.target_price:,.0f} 🪙 رسید.\n"
                        f"قیمتِ الان: {new_price:,.0f} 🪙"
                    )
                except Exception:
                    pass
            session.delete(a)

        orders = session.query(db.CurrencyOrder).filter(
            db.CurrencyOrder.currency_id == c.id,
            db.CurrencyOrder.status == "pending",
            db.CurrencyOrder.target_price >= lo,
            db.CurrencyOrder.target_price <= hi,
        ).all()
        for o in orders:
            # سفارشِ خرید: با کاهشِ قیمت تا هدف پر می‌شه (منتظرِ ارزون‌شدن).
            # سفارشِ فروش: با افزایشِ قیمت تا هدف پر می‌شه (منتظرِ گرون‌شدن).
            fillable = (
                (o.kind == "buy" and new_price <= o.target_price <= old_price)
                or (o.kind == "sell" and old_price <= o.target_price <= new_price)
            )
            if not fillable:
                continue
            o.status = "filled"
            o.filled_at = datetime.datetime.utcnow()
            u = session.get(db.User, o.user_id)
            if o.kind == "buy":
                # پولش موقعِ ثبتِ سفارش از قبل کم شده بود؛ الان فقط خودِ ارز رو تحویل می‌دیم
                uc = session.query(db.UserCurrency).filter_by(user_id=o.user_id, currency_id=c.id).first()
                if not uc:
                    uc = db.UserCurrency(user_id=o.user_id, currency_id=c.id, amount=0)
                    session.add(uc)
                uc.amount += o.quantity
                if context:
                    try:
                        await context.bot.send_message(
                            o.user_id,
                            f"✅ سفارشِ خریدِ {o.quantity:,.0f} {c.name} با قیمتِ {o.target_price:,.0f} 🪙 پر شد!"
                        )
                    except Exception:
                        pass
            else:
                # خودِ ارز موقعِ ثبتِ سفارش از قبل کم شده بود؛ الان فقط پولش رو می‌دیم
                revenue = o.target_price * o.quantity
                if u:
                    u.hop_points = round(u.hop_points + revenue)
                if context:
                    try:
                        await context.bot.send_message(
                            o.user_id,
                            f"✅ سفارشِ فروشِ {o.quantity:,.0f} {c.name} با قیمتِ {o.target_price:,.0f} 🪙 پر شد! "
                            f"{revenue:,.0f} 🪙 به حسابت اضافه شد."
                        )
                    except Exception:
                        pass


async def tick_crypto_prices(session, context=None):
    """نقطه‌ی ورودیِ مشترک: هم از jobs.py (هر تیکِ پس‌زمینه) هم از خودِ صفحه‌ی
    ارزها (وقتی کاربر بازش می‌کنه، به‌عنوانِ عقب‌نیفتادنِ قیمت اگه جاب دیر
    اجرا شده باشه) صدا زده می‌شه."""
    changed = step_crypto_prices(session)
    if changed:
        await check_alarms_and_orders(session, context, changed)
    return changed


def maybe_auto_update_crypto_prices(session):
    """نسخه‌ی قدیمی، فقط برای سازگاری با کدهایی که هنوز این اسم رو صدا
    می‌زنن - دیگه استفاده نکن، به‌جاش از tick_crypto_prices استفاده کن."""
    step_crypto_prices(session)
