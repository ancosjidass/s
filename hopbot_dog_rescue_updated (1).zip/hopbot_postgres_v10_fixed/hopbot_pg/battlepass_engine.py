# -*- coding: utf-8 -*-
"""
موتورِ «بتل‌پسِ هاپویی» - بدونِ هیچ وابستگی به تلگرام (قابلِ تست).

  • XP از چلنج‌ها + فعالیتِ روزانه (سقف‌دار) + استریک.  تیرها ۵ مرحله‌ی سختی دارن (هرچی بالاتر، XPِ بیشتر).
  • پیشرفتِ فعالیت از جدول‌هایِ خودِ بازی‌ها خونده می‌شه (مثلِ مأموریت‌ها؛ تو یه کوئریِ واحد، یه رفت‌وبرگشت).
  • دریافتِ جایزه Idempotent: UniqueConstraint + لجرِ war_svc.hop_apply.
  • بوسترها: زمانی یا تعدادی؛ از هر نوع یکی هم‌زمان فعاله.
"""
import datetime
import functools
import hashlib
import logging
import math
import threading
from types import SimpleNamespace

from sqlalchemy import text

import battlepass_db as BD
import db
import mission_metrics as MM

logger = logging.getLogger(__name__)
LOCK = threading.RLock()


class BpError(Exception):
    """پیامِ فارسیِ قابل‌نمایش به کاربر."""


def utcnow():
    return datetime.datetime.utcnow()


def _txn(fn):
    @functools.wraps(fn)
    def w(session, *a, **kw):
        with LOCK:
            try:
                out = fn(session, *a, **kw)
                session.commit()
                return out
            except Exception:
                session.rollback()
                raise
    return w


_FA = str.maketrans("۰۱۲۳۴۵۶۷۸۹٫٬،", "0123456789.,,")


def gs(session, k, d=""):
    v = db.cfg_get(session, k)
    return d if v is None else str(v)


def gf(session, k, d=0.0):
    try:
        return float(str(db.cfg_get(session, k)).translate(_FA))
    except (TypeError, ValueError):
        return d


def gi(session, k, d=0):
    return int(gf(session, k, d))


def enabled(session):
    return gi(session, "bp_enabled", 1) == 1


def fmt(n):
    return f"{int(round(n)):,}"


# ---------------------------------------------------------------------------
# زمان (روزِ محلی)
# ---------------------------------------------------------------------------
def _tz(session):
    return datetime.timedelta(minutes=gi(session, "bp_tz_minutes", 210))


def day_key(session, dt):
    return (dt + _tz(session)).strftime("%Y-%m-%d")


def day_bounds(session, dk):
    start_local = datetime.datetime.strptime(dk, "%Y-%m-%d")
    start = start_local - _tz(session)
    return start, start + datetime.timedelta(days=1)


# ---------------------------------------------------------------------------
# تیرها و XP (درجه‌بندیِ سختی)
# ---------------------------------------------------------------------------
def stage_costs(session):
    out = []
    for p in gs(session, "bp_stage_costs", "500,750,1100,1500,2000").translate(_FA).split(","):
        try:
            out.append(max(1.0, float(p)))
        except ValueError:
            pass
    out = out or [1000.0]
    while len(out) < 5:
        out.append(out[-1])
    return out[:5]


def stage_of(tier, n):
    return min(4, max(0, (tier - 1) * 5 // max(1, n)))


def tier_cost(costs, tier, n):
    return costs[stage_of(tier, n)]


def thresholds(session, n):
    """cum[i] = XPِ لازم برای رسیدن به تیرِ i (cum[0]=0)."""
    costs = stage_costs(session)
    cum = [0.0]
    for t in range(1, n + 1):
        cum.append(cum[-1] + tier_cost(costs, t, n))
    return cum


def progress(session, xp, n):
    """-> dict(tier, into, need, maxed, mastery, stage)"""
    cum = thresholds(session, n)
    xp = max(0.0, float(xp or 0))
    tier = 0
    while tier < n and xp >= cum[tier + 1]:
        tier += 1
    if tier >= n:
        mc = max(1.0, gf(session, "bp_mastery_cost", 3000))
        extra = xp - cum[n]
        mastery = int(extra // mc)
        return {"tier": n, "into": extra - mastery * mc, "need": mc, "maxed": True, "mastery": mastery, "stage": 4}
    need = cum[tier + 1] - cum[tier]
    return {"tier": tier, "into": xp - cum[tier], "need": need, "maxed": False, "mastery": 0,
            "stage": stage_of(tier + 1, n)}


def bar(into, need, width=10):
    f = 0 if need <= 0 else max(0, min(width, int(round(width * into / need))))
    return "▰" * f + "▱" * (width - f)


# ---------------------------------------------------------------------------
# جایزه‌هایِ پیش‌فرض (از اقتصادِ ربات: واحدِ نقدی bp_cash_unit)
# ---------------------------------------------------------------------------
_FREE_MILESTONES = {
    1: ("hop_boost", 0, 20, 0, 120, "بوسترِ هاپ ۲۰٪ (۲ ساعت)"),
    2: ("shop_money", 1, 0, 0, 0, "بوسترِ پولِ فروشگاه"),
    3: ("heist_cd", 0, 30, 2, 0, "کول‌دانِ سرقت ۳۰٪ - ۲ بار"),
    4: ("fr_fuel", 6, 0, 0, 0, "⛽ سوختِ Frontier +۶"),
    5: ("hop_perm", 0, 3, 0, 0, "هاپِ +۳٪ تا آخرِ فصل"),
    6: ("shop_power", 1, 0, 0, 0, "بوسترِ قدرتِ فروشگاه"),
    7: ("fr_atk", 0, 15, 3, 0, "💥 قدرتِ حمله‌ی Frontier +۱۵٪ (۳ عملیات)"),
    8: ("xp_boost", 0, 25, 0, 360, "بوسترِ XP ۲۵٪ (۶ ساعت)"),
    9: ("prod_boost", 0, 40, 0, 180, "بوسترِ تولید ۴۰٪ (۳ ساعت)"),
    10: ("jail_free", 1, 0, 1, 0, "کارتِ آزادی از زندان"),
}
_PREM_CYCLE = [
    ("heist_loot", 0, 25, 3, 0, "غنیمتِ سرقت +۲۵٪ - ۳ بار"),
    ("hop_boost", 0, 30, 0, 90, "بوسترِ هاپ ۳۰٪ (۹۰ دقیقه)"),
    ("prod_boost", 0, 35, 0, 120, "بوسترِ تولید ۳۵٪ (۲ ساعت)"),
    ("heist_cd", 0, 50, 3, 0, "کول‌دانِ سرقت ۵۰٪ - ۳ بار"),
    ("xp_boost", 0, 30, 0, 240, "بوسترِ XP ۳۰٪ (۴ ساعت)"),
    ("fr_loot", 0, 25, 3, 0, "🎁 پاداشِ Frontier +۲۵٪ (۳ عملیات)"),
    ("fr_clue", 1, 0, 0, 0, "🔎 سرنخِ اتاقِ مخفی"),
]


def _cash(unit, mult):
    return max(1000, int(round(unit * mult / 1000.0)) * 1000)


def default_rewards(n, unit):
    out = []
    step = max(1, n // 10)

    def add(t, track, kind, amount=0, pct=0, uses=0, minutes=0, label=""):
        out.append(dict(tier=t, track=track, kind=kind, amount=float(amount), pct=float(pct),
                        uses=int(uses), minutes=int(minutes), label=label))

    for t in range(1, n + 1):
        base = 0.6 + 0.04 * t
        idx = t // step if t % step == 0 else 0
        # --- مسیرِ رایگان ---
        if idx and idx in _FREE_MILESTONES:
            k, a, p, u, m, lab = _FREE_MILESTONES[idx]
            add(t, "free", k, a, p, u, m, lab)
        elif t % 5 == 0:
            add(t, "free", "hop", _cash(unit, base * 2.5))
        else:
            add(t, "free", "hop", _cash(unit, base))
        # --- مسیرِ پریمیوم ---
        if t == n:
            add(t, "premium", "title", 0, 0, 0, 0, "👑 فرمانده‌ی افسانه‌ایِ فصل")
        elif t in (n // 4, (3 * n) // 4):
            add(t, "premium", "jail_free", 1, 0, 1, 0, "کارتِ آزادی از زندان")
        elif idx:
            if idx == 5:
                add(t, "premium", "hop_perm", 0, 5, 0, 0, "هاپِ +۵٪ تا آخرِ فصل")
            else:
                add(t, "premium", "shop_money" if idx % 2 else "shop_power", 2, 0, 0, 0, "۲ بوسترِ فروشگاه")
        elif t % 20 == 0:
            add(t, "premium", "title", 0, 0, 0, 0, f"🏷 لقبِ مرحله‌ی {t}")
        elif t % 5 == 0:
            k, a, p, u, m, lab = _PREM_CYCLE[(t // 5) % len(_PREM_CYCLE)]
            add(t, "premium", k, a, p, u, m, lab)
        else:
            add(t, "premium", "hop", _cash(unit, base * 3))
    return out


def mastery_reward(session, k):
    unit = gf(session, "bp_cash_unit", 100000)
    if k % 5 == 0:
        return SimpleNamespace(kind="hop_boost", amount=0, pct=20, uses=0, minutes=60, label="بوسترِ هاپ ۲۰٪ (۱ ساعت)")
    return SimpleNamespace(kind="hop", amount=_cash(unit, 8), pct=0, uses=0, minutes=0, label="")


# ---------------------------------------------------------------------------
# چلنج‌هایِ پیش‌فرض (عنوان، معیار، تعدادِ پایه، XP، درجه، دوره، هفته‌ی بازشدن، ترتیب)
# ---------------------------------------------------------------------------
DEFAULT_CHALLENGES = [
    # روزانه — اعداد از رفتارِ واقعیِ بازیکن‌هایِ فعالِ دیتابیس (هاپ ۵ دقیقه یه‌بار، کازینو/اونو/رولت چندبار در هفته)
    ("🦘 ۳ بار هاپ بزن", "hops", 3, 150, 1, "daily", 0, 1),
    ("🎲 ۱ دور کازینو بازی کن", "casino_played", 1, 150, 1, "daily", 0, 2),
    ("🔢 ۱ دور حدسِ عدد", "guess_played", 1, 150, 1, "daily", 0, 3),
    ("❤️ ۳ پستِ میاوی رو لایک کن", "myawy_likes", 3, 150, 1, "daily", 0, 4),
    ("🦘 ۶ بار هاپ بزن", "hops", 6, 350, 2, "daily", 0, 5),
    ("🎲 ۲ دور کازینو بازی کن", "casino_played", 2, 350, 2, "daily", 0, 6),
    ("🔫 ۱ دور رولت بازی کن", "roulette_played", 1, 350, 2, "daily", 0, 7),
    ("🃏 ۱ دور اونو بازی کن", "uno_played", 1, 350, 2, "daily", 0, 8),
    ("🚢 ۱ نبردِ دریایی تمام کن", "ship_played", 1, 350, 2, "daily", 0, 9),
    ("🦘 ۱۲ بار هاپ بزن", "hops", 12, 700, 3, "daily", 0, 10),
    ("🔫 ۲ بار به بازیکنی حمله کن", "rob_attempts", 2, 700, 3, "daily", 0, 11),
    ("🎲 ۴ دور کازینو بازی کن", "casino_played", 4, 700, 3, "daily", 0, 12),
    ("🕴 ۱ دور مافیا بازی کن", "mafia_played", 1, 700, 3, "daily", 0, 13),
    ("📦 ۱ قاچاقِ موفق", "smuggle_success", 1, 700, 3, "daily", 0, 14),
    # هفتگی
    ("🦘 ۲۰ بار هاپ بزن", "hops", 20, 800, 1, "weekly", 0, 20),
    ("🎲 ۴ دور کازینو", "casino_played", 4, 800, 1, "weekly", 0, 21),
    ("📝 ۲ پستِ میاوی بذار", "myawy_posts", 2, 800, 1, "weekly", 0, 22),
    ("🦘 ۵۰ بار هاپ بزن", "hops", 50, 2000, 2, "weekly", 0, 23),
    ("🔫 ۶ حمله به بازیکن‌ها", "rob_attempts", 6, 2000, 2, "weekly", 0, 24),
    ("📦 ۲ قاچاق شروع کن", "smuggle_started", 2, 2000, 2, "weekly", 0, 25),
    ("⚔️ ۴ حمله در جنگ هاپویی", "war_attacks", 4, 2000, 2, "weekly", 0, 26),
    ("🥷 ۱ سرقتِ تیمی شرکت کن", "heist_played", 1, 4000, 3, "weekly", 0, 27),
    ("📦 ۲ قاچاقِ موفق", "smuggle_success", 2, 4000, 3, "weekly", 0, 28),
    ("🏆 ۳ بردِ حمله در جنگ", "war_wins", 3, 4000, 3, "weekly", 0, 29),
    ("🎲 ۱۰ دور کازینو", "casino_played", 10, 4000, 3, "weekly", 0, 30),
    ("🥷 ۲ سرقتِ تیمیِ موفق", "heist_success", 2, 7000, 4, "weekly", 2, 31),
    ("📦 ۴ قاچاقِ موفق", "smuggle_success", 4, 7000, 4, "weekly", 2, 32),
    ("🏆 ۶ بردِ حمله در جنگ", "war_wins", 6, 7000, 4, "weekly", 2, 33),
    ("🦘 ۹۰ بار هاپ بزن", "hops", 90, 7000, 4, "weekly", 2, 34),
    # فصلی (مسترى)
    ("🦘 ۴۰۰ بار هاپ بزن", "hops", 400, 3000, 1, "season", 0, 40),
    ("🎲 ۴۰ دور کازینو", "casino_played", 40, 5000, 2, "season", 0, 41),
    ("🔫 ۳۰ حمله به بازیکن‌ها", "rob_attempts", 30, 6000, 2, "season", 0, 42),
    ("📦 ۱۰ قاچاقِ موفق", "smuggle_success", 10, 8000, 3, "season", 0, 43),
    ("🥷 ۴ سرقتِ تیمیِ موفق", "heist_success", 4, 8000, 3, "season", 0, 44),
    ("🏆 ۱۵ بردِ حمله در جنگ", "war_wins", 15, 8000, 4, "season", 0, 45),
]


def seed_challenges_once(session):
    if session.get(db.Config, "_bp_challenges_seeded_v1") is not None:
        return 0
    n = 0
    if session.query(BD.BpChallengeDef).count() == 0:
        for title, metric, target, xp, diff, period, unlock, sort in DEFAULT_CHALLENGES:
            session.add(BD.BpChallengeDef(title=title, metric=metric, target=target, xp=xp, diff=diff,
                                          period=period, unlock_week=unlock, sort=sort))
            n += 1
    session.add(db.Config(key="_bp_challenges_seeded_v1", value="1"))
    session.flush()
    return n


# ---------------------------------------------------------------------------
# معیارها: از جدول‌هایِ خودِ بازی‌ها (+ شمارنده‌هایِ خلاصه‌ی db_purge) - همه با یه کوئری
# ---------------------------------------------------------------------------
_WIN = "{a}"  # جایگزین می‌شه
SOURCES = {
    "casino_played": ("🎲 بازیِ کازینو", "SELECT COUNT(*) FROM casino_players WHERE user_id=:u AND joined_at>=:{a} AND joined_at<:{b}"),
    "roulette_played": ("🔫 بازیِ رولت", "SELECT COUNT(*) FROM roulette_players WHERE user_id=:u AND joined_at>=:{a} AND joined_at<:{b}"),
    "uno_played": ("🃏 بازیِ اونو", "SELECT COUNT(*) FROM uno_players WHERE user_id=:u AND joined_at>=:{a} AND joined_at<:{b}"),
    "mafia_played": ("🕴 بازیِ مافیا", "SELECT COUNT(*) FROM mafia_players WHERE user_id=:u AND joined_at>=:{a} AND joined_at<:{b}"),
    "guess_played": ("🔢 حدسِ عدد", "SELECT COUNT(*) FROM guessnum_rounds WHERE (initiator_id=:u OR setter_id=:u OR guesser_id=:u) AND created_at>=:{a} AND created_at<:{b} AND status!='cancelled'"),
    "mind_played": ("🧠 ماستر‌مایند", "SELECT COUNT(*) FROM mastermind_rounds WHERE (player1_id=:u OR player2_id=:u) AND ended_at>=:{a} AND ended_at<:{b} AND status='resolved'"),
    "ship_played": ("🚢 نبردِ دریایی", "SELECT COUNT(*) FROM battleship_rounds WHERE (player1_id=:u OR player2_id=:u) AND ended_at>=:{a} AND ended_at<:{b} AND status='resolved'"),
    "duel_played": ("⚔️ دوئل", "SELECT COUNT(*) FROM duel_lobbies WHERE (host_id=:u OR guest_id=:u) AND winner_id IS NOT NULL AND ended_at>=:{a} AND ended_at<:{b}"),
    "rob_attempts": ("🔫 حمله به بازیکن", "SELECT COUNT(*) FROM attack_sessions WHERE attacker_id=:u AND created_at>=:{a} AND created_at<:{b}"),
    "smuggle_started": ("📦 شروعِ قاچاق", "SELECT COUNT(*) FROM smuggling_operations WHERE user_id=:u AND started_at>=:{a} AND started_at<:{b}"),
    "smuggle_success": ("📦 قاچاقِ موفق", "SELECT COUNT(*) FROM smuggling_operations WHERE user_id=:u AND status='success' AND ended_at>=:{a} AND ended_at<:{b}"),
    "heist_played": ("🥷 شرکت در سرقتِ تیمی", "SELECT COUNT(*) FROM heist_rewards WHERE user_id=:u AND created_at>=:{a} AND created_at<:{b}"),
    "heist_success": ("🥷 سرقتِ تیمیِ موفق", "SELECT COUNT(*) FROM heist_rewards WHERE user_id=:u AND hop>0 AND created_at>=:{a} AND created_at<:{b}"),
    "war_attacks": ("⚔️ حمله در جنگ هاپویی", "SELECT COUNT(*) FROM war_battles WHERE attacker_id=:u AND created_at>=:{a} AND created_at<:{b}"),
    "war_wins": ("🏆 بردِ حمله در جنگ", "SELECT COUNT(*) FROM war_battles WHERE attacker_id=:u AND outcome='attacker' AND created_at>=:{a} AND created_at<:{b}"),
    "frontier_runs": ("🌌 عملیاتِ Frontier", "SELECT COUNT(*) FROM frontier_runs WHERE user_id=:u AND created_at>=:{a} AND created_at<:{b}"),
    "frontier_wins": ("🌌 کلیرِ موفقِ Frontier", "SELECT COUNT(*) FROM frontier_runs WHERE user_id=:u AND outcome='win' AND created_at>=:{a} AND created_at<:{b}"),
    "frontier_boss_hits": ("🐉 حمله به باسِ Frontier", "SELECT COUNT(*) FROM frontier_runs WHERE user_id=:u AND boss_state_id IS NOT NULL AND outcome='win' AND created_at>=:{a} AND created_at<:{b}"),
    "myawy_posts": ("📝 پستِ میاوی", "SELECT COUNT(*) FROM myawy_posts WHERE user_id=:u AND created_at>=:{a} AND created_at<:{b}"),
    "myawy_likes": ("❤️ لایکِ میاوی", "SELECT COUNT(*) FROM myawy_post_likes WHERE user_id=:u AND created_at>=:{a} AND created_at<:{b}"),
}
METRIC_LABEL = {"hops": "🦘 هاپ زدن"}
METRIC_LABEL.update({k: v[0] for k, v in SOURCES.items()})


def _bucket(session_unused, dt):
    import db_purge
    return MM._ts(db_purge.bucket_of(dt))


def window_counts(uid, season_id, windows, metrics, dk_of):
    """windows: {name: (start_utc, end_utc)} ؛ metrics: iterable ؛ -> {(metric, name): n}
    یه Session جدا و کوتاه می‌گیره (خطایِ جدولِ نبود، تراکنشِ صدازننده رو خراب نمی‌کنه)."""
    metrics = [m for m in dict.fromkeys(metrics) if m in SOURCES or m == "hops"]
    out = {}
    if not metrics or not windows:
        return out
    params = {"u": int(uid), "sid": int(season_id)}
    cells = []
    for wi, (wn, (a, b)) in enumerate(windows.items()):
        params[f"a{wi}"], params[f"b{wi}"] = MM._ts(a), MM._ts(b)
        params[f"ba{wi}"], params[f"bb{wi}"] = _bucket(None, a), _bucket(None, b)
        params[f"da{wi}"], params[f"db{wi}"] = dk_of(a), dk_of(b - datetime.timedelta(seconds=1))
        for m in metrics:
            if m == "hops":
                sql = (f"SELECT COALESCE(SUM(hops),0) FROM bp_days WHERE user_id=:u AND season_id=:sid "
                       f"AND day_key>=:da{wi} AND day_key<=:db{wi}")
            else:
                sql = SOURCES[m][1].format(a=f"a{wi}", b=f"b{wi}")
                sql = (f"({sql}) + (SELECT COALESCE(SUM(n),0) FROM activity_counters WHERE user_id=:u AND metric='{m}' "
                       f"AND bucket>=:ba{wi} AND bucket<:bb{wi})")
            cells.append(((m, wn), f"({sql})"))
    s = db.get_session()
    try:
        try:
            row = s.execute(text("SELECT " + ",".join(c for _k, c in cells)), params).one()
            for (k, _c), v in zip(cells, row):
                out[k] = int(v or 0)
            return out
        except Exception as e:                       # جدولی (مثلاً تو نصبِ قدیمی) نبود → تک‌به‌تک
            s.rollback()
            logger.warning("bp batched counts failed (%s); falling back", e)
        for k, c in cells:
            try:
                out[k] = int(s.execute(text("SELECT " + c), params).scalar() or 0)
            except Exception:
                s.rollback()
                out[k] = 0
        return out
    finally:
        s.close()


def parse_weights(session):
    w = {}
    for part in gs(session, "bp_activity_weights").translate(_FA).split(","):
        if ":" in part:
            k, v = part.split(":", 1)
            try:
                w[k.strip()] = float(v)
            except ValueError:
                pass
    return {k: v for k, v in w.items() if v > 0 and (k in SOURCES or k == "hops")}


# ---------------------------------------------------------------------------
# فصل‌ها
# ---------------------------------------------------------------------------
_SEASON_MEMO = {"t": 0.0, "id": None, "ends": None}


def _season_memo_clear():
    _SEASON_MEMO["t"] = 0.0


def create_season(session, name=None, days=None, clone_from=None):
    last = session.query(BD.BpSeason).order_by(BD.BpSeason.number.desc()).first()
    number = (last.number if last else 0) + 1
    if not name:
        names = [x.strip() for x in gs(session, "bp_season_names").split("|") if x.strip()] or ["فصل"]
        name = f"{names[(number - 1) % len(names)]} #{number}"
    days = days or max(1, gi(session, "bp_season_days", 30))
    start = utcnow()
    n = max(5, gi(session, "bp_tiers", 100))
    s = BD.BpSeason(number=number, name=name, started_at=start, ends_at=start + datetime.timedelta(days=days),
                    status="active", tiers=n)
    session.add(s)
    session.flush()
    src = clone_from if clone_from is not None else last
    rows = []
    if src is not None and src.tiers == n:
        rows = [dict(tier=d.tier, track=d.track, kind=d.kind, amount=d.amount, pct=d.pct, uses=d.uses,
                     minutes=d.minutes, label=d.label)
                for d in session.query(BD.BpTierDef).filter_by(season_id=src.id).all()]
    if not rows:
        rows = default_rewards(n, gf(session, "bp_cash_unit", 100000))
    for r in rows:
        session.add(BD.BpTierDef(season_id=s.id, **r))
    session.flush()
    _season_memo_clear()
    return s


def current_season(session):
    """آخرین فصل (فعال یا تمام‌شده). اگه تموم شده و ادامه‌دار روشنه، فصلِ بعدی ساخته می‌شه."""
    s = session.query(BD.BpSeason).order_by(BD.BpSeason.id.desc()).first()
    if s is None:
        return create_season(session)
    if s.status == "active" and utcnow() >= s.ends_at:
        s.status = "ended"
    if s.status == "ended" and gi(session, "bp_auto_next_season", 1):
        return create_season(session, clone_from=s)
    return s


def is_open(season):
    return season is not None and season.status == "active" and utcnow() < season.ends_at


def previous_season(session, season):
    return (session.query(BD.BpSeason).filter(BD.BpSeason.id < season.id)
            .order_by(BD.BpSeason.id.desc()).first())


def in_grace(session, season):
    if season is None or season.status != "ended":
        return False
    return utcnow() < season.ends_at + datetime.timedelta(days=gi(session, "bp_grace_days", 3))


def left_text(delta):
    s = max(0, int(delta.total_seconds()))
    d, h, m = s // 86400, (s % 86400) // 3600, (s % 3600) // 60
    return f"{d} روز و {h} ساعت" if d else (f"{h} ساعت و {m} دقیقه" if h else f"{m} دقیقه")


# ---------------------------------------------------------------------------
# بازیکن
# ---------------------------------------------------------------------------
def get_player(session, user, season, create=True):
    uid = user.telegram_id if hasattr(user, "telegram_id") else int(user)
    p = session.get(BD.BpPlayer, (uid, season.id))
    if p is None and create:
        p = BD.BpPlayer(user_id=uid, season_id=season.id, xp=0, premium=False, hop_perm_pct=0,
                        last_hop_count=(getattr(user, "hop_count", None) or 0) if hasattr(user, "hop_count") else None)
        session.add(p)
        session.flush()
    return p


_HOP_LOG = {}        # uid -> {day_key: n}   (فقط حافظه؛ برایِ نسبت‌دادنِ دقیقِ هاپ‌ها به روزِ درست)
_HOP_LOCK = threading.Lock()


def _log_hop(session, uid):
    dk = day_key(session, utcnow())
    with _HOP_LOCK:
        d = _HOP_LOG.setdefault(int(uid), {})
        d[dk] = d.get(dk, 0) + 1


def _pop_hops(uid):
    with _HOP_LOCK:
        return _HOP_LOG.pop(int(uid), {})


def xp_mult(session, p, uid, extra_pct=0.0):
    pct = gf(session, "bp_xp_global_pct", 0) + extra_pct
    if p is not None and p.premium:
        pct += gf(session, "bp_xp_premium_pct", 10)
    pct += booster_pct(session, uid, "xp_boost")
    return 1.0 + pct / 100.0


def add_xp(session, p, amount):
    p.xp = (p.xp or 0) + float(amount)


def _sync(session, user, season, force=False):
    p = get_player(session, user, season)
    now = utcnow()
    if not is_open(season):
        return p
    if not force and p.last_sync_at and (now - p.last_sync_at).total_seconds() < 25:
        return p
    uid = user.telegram_id
    today = day_key(session, now)
    # --- هاپ‌ها ---
    attributed = _pop_hops(uid)
    hc = user.hop_count or 0
    if p.last_hop_count is None:
        p.last_hop_count = hc
        attributed = {}
    delta = max(0, hc - (p.last_hop_count or 0))
    left = max(0, delta - sum(attributed.values()))
    if left:
        attributed[today] = attributed.get(today, 0) + left
    p.last_hop_count = hc
    rows = {}

    def day_row(dk):
        r = rows.get(dk)
        if r is None:
            r = session.get(BD.BpDay, (uid, season.id, dk))
            if r is None:
                r = BD.BpDay(user_id=uid, season_id=season.id, day_key=dk, xp=0, hops=0)
                session.add(r)
            rows[dk] = r
        return r

    for dk, n in attributed.items():
        r = day_row(dk)
        r.hops = (r.hops or 0) + n
    # --- روزهایی که باید بازحساب بشن ---
    back = max(1, gi(session, "bp_backfill_days", 10))
    first_day = p.last_sync_day or today
    earliest = day_key(session, now - datetime.timedelta(days=back))
    first_day = max(first_day, earliest, day_key(session, season.started_at))
    days = []
    d = datetime.datetime.strptime(first_day, "%Y-%m-%d")
    end = datetime.datetime.strptime(today, "%Y-%m-%d")
    while d <= end:
        days.append(d.strftime("%Y-%m-%d"))
        d += datetime.timedelta(days=1)
    for dk in attributed:
        if dk not in days:
            days.append(dk)
    windows = {}
    for dk in days:
        a, b = day_bounds(session, dk)
        a, b = max(a, season.started_at), min(b, season.ends_at, now + datetime.timedelta(seconds=1))
        if b > a:
            windows[dk] = (a, b)
    weights = parse_weights(session)
    counts = window_counts(uid, season.id, windows, [m for m in weights if m != "hops"],
                           lambda t: day_key(session, t)) if windows else {}
    cap = gf(session, "bp_activity_cap_day", 1500)
    mult = xp_mult(session, p, uid)
    for dk in windows:
        raw = sum(counts.get((m, dk), 0) * w for m, w in weights.items() if m != "hops")
        r = day_row(dk)
        raw += (r.hops or 0) * weights.get("hops", 0)
        target = min(raw, cap) if cap > 0 else raw
        inc = target - (r.xp or 0)
        if inc > 0.01:
            r.xp = target
            add_xp(session, p, inc * mult)
    p.last_sync_day = today
    p.last_sync_at = now
    session.flush()
    return p


@_txn
def sync(session, user, force=False):
    season = current_season(session)
    p = _sync(session, user, season, force)
    return season, p


def tier_status(session, season, p):
    return progress(session, p.xp if p else 0, season.tiers)


# ---------------------------------------------------------------------------
# چلنج‌ها
# ---------------------------------------------------------------------------
def week_index(season, now=None):
    now = now or utcnow()
    return max(0, (now - season.started_at).days // 7)


def _pick(uid, key, diff, cands):
    if not cands:
        return None
    h = int(hashlib.sha1(f"{uid}:{key}:{diff}".encode()).hexdigest()[:8], 16)
    return cands[h % len(cands)]


def _parse_diffs(session, key, default):
    out = []
    for p in gs(session, key, default).translate(_FA).split(","):
        try:
            v = int(p)
            if 1 <= v <= 4:
                out.append(v)
        except ValueError:
            pass
    return out


def scale_for(session, user, wk, period):
    wg = gf(session, "bp_week_difficulty", 0.12) if period != "season" else 0.0
    cap = max(1.0, gf(session, "bp_level_cap", 100))
    lvl = min(float(db.user_lvl(user)), cap)
    return (1.0 + wg * wk) * (1.0 + gf(session, "bp_level_scale", 0.5) * lvl / cap)


def challenge_list(session, user, season, p):
    """چلنج‌هایِ امروزِ بازیکن با پیشرفت. -> list[dict]"""
    now = utcnow()
    uid = user.telegram_id
    wk = week_index(season, now)
    lvl = db.user_lvl(user)
    today = day_key(session, now)
    wkey, skey = f"w{season.id}-{wk}", f"s{season.id}"
    defs = (session.query(BD.BpChallengeDef)
            .filter(BD.BpChallengeDef.deleted == False, BD.BpChallengeDef.enabled == True)  # noqa: E712
            .order_by(BD.BpChallengeDef.id).all())

    def ok(d):
        return d.metric in METRIC_LABEL and (d.unlock_week or 0) <= wk and (d.min_level or 0) <= lvl

    chosen = []
    for period, key, diffs in (("daily", today, _parse_diffs(session, "bp_daily_diffs", "1,2,3")),
                               ("weekly", wkey, _parse_diffs(session, "bp_weekly_diffs", "1,2,3,4"))):
        for df in diffs:
            c = _pick(uid, key, df, [d for d in defs if d.period == period and d.diff == df and ok(d)])
            if c:
                chosen.append((c, key))
    season_defs = sorted([d for d in defs if d.period == "season" and ok(d)], key=lambda d: (d.diff, d.sort, d.id))
    for d in season_defs[:max(0, gi(session, "bp_season_challenges", 6))]:
        chosen.append((d, skey))
    # پنجره‌هایِ زمانی
    a_day, b_day = day_bounds(session, today)
    w_a = season.started_at + datetime.timedelta(days=7 * wk)
    w_b = min(w_a + datetime.timedelta(days=7), season.ends_at)
    windows = {
        "daily": (max(a_day, season.started_at), min(b_day, season.ends_at)),
        "weekly": (w_a, w_b),
        "season": (season.started_at, season.ends_at),
    }
    counts = window_counts(uid, season.id, windows, [d.metric for d, _k in chosen], lambda t: day_key(session, t))
    claimed = {(c.ch_id, c.period_key) for c in session.query(BD.BpChClaim).filter_by(user_id=uid, season_id=season.id).all()}
    out = []
    for d, key in chosen:
        sc = scale_for(session, user, wk, d.period)
        target = max(1, int(round(d.target * sc)))
        xp = int(round(d.xp * (1.0 + 0.5 * (sc - 1.0))))
        prog = counts.get((d.metric, d.period), 0)
        out.append(dict(id=d.id, key=key, title=d.title, metric=d.metric, period=d.period, diff=d.diff,
                        target=target, xp=xp, progress=prog, done=prog >= target,
                        claimed=(d.id, key) in claimed))
    out.sort(key=lambda x: ({"daily": 0, "weekly": 1, "season": 2}[x["period"]], x["diff"], x["id"]))
    return out


@_txn
def claim_challenge(session, user, ch_id):
    season = current_season(session)
    if not is_open(season):
        raise BpError("فصل تموم شده؛ منتظرِ فصلِ بعد باش.")
    p = _sync(session, user, season, force=True)
    session.commit()                      # هاپ‌هایِ امروز برایِ شمارشِ پنجره‌ها قابل‌دیدن باشن
    item = next((c for c in challenge_list(session, user, season, p) if c["id"] == int(ch_id)), None)
    if item is None:
        raise BpError("این چلنج دیگه فعال نیست.")
    if item["claimed"]:
        raise BpError("قبلاً گرفتی.")
    if not item["done"]:
        raise BpError(f"هنوز تموم نشده ({item['progress']}/{item['target']}).")
    today = day_key(session, utcnow())
    streak_pct = 0.0
    if item["period"] == "daily":
        last = p.last_streak_day or ""
        if last != today:
            yesterday = day_key(session, utcnow() - datetime.timedelta(days=1))
            p.streak = (p.streak or 0) + 1 if last == yesterday else 1
            p.last_streak_day = today
            p.best_streak = max(p.best_streak or 0, p.streak)
    streak_pct = gf(session, "bp_streak_xp_pct_per_day", 3) * min(p.streak or 0, gi(session, "bp_streak_max_days", 10))
    mult = xp_mult(session, p, user.telegram_id, extra_pct=streak_pct)
    gained = item["xp"] * mult
    session.add(BD.BpChClaim(user_id=user.telegram_id, season_id=season.id, ch_id=item["id"],
                             period_key=item["key"], xp=gained))
    try:
        session.flush()
    except Exception:
        session.rollback()
        raise BpError("قبلاً گرفتی.")
    before = progress(session, p.xp, season.tiers)["tier"]
    add_xp(session, p, gained)
    after = progress(session, p.xp, season.tiers)
    invalidate(user.telegram_id)
    return {"xp": gained, "streak": p.streak or 0, "streak_pct": streak_pct, "tier": after["tier"],
            "tier_up": after["tier"] > before}


# ---------------------------------------------------------------------------
# بوسترها
# ---------------------------------------------------------------------------
def _expire(session, uid):
    now = utcnow()
    for b in session.query(BD.BpBooster).filter(BD.BpBooster.user_id == uid, BD.BpBooster.state == "active").all():
        if (b.ends_at and b.ends_at <= now) or (b.uses_left is not None and b.uses_left <= 0):
            b.state = "used"


def active_boosters(session, uid):
    _expire(session, uid)
    return session.query(BD.BpBooster).filter_by(user_id=uid, state="active").all()


def best_booster(session, uid, kind):
    bs = [b for b in active_boosters(session, uid) if b.kind == kind]
    return max(bs, key=lambda b: b.pct) if bs else None


def booster_pct(session, uid, kind):
    b = best_booster(session, uid, kind)
    return b.pct if b else 0.0


def grant_booster(session, uid, kind, pct=0, uses=0, minutes=0, season_id=0, source=""):
    if kind not in BD.BOOSTER_KINDS:
        raise BpError("نوعِ بوستر نامعتبره.")
    uses, minutes = int(uses or 0), int(minutes or 0)
    if kind == "jail_free":
        uses, minutes = max(1, uses), 0
    elif uses <= 0 and minutes <= 0:
        minutes = 60
    b = BD.BpBooster(user_id=uid, season_id=season_id, kind=kind, pct=float(pct or 0),
                     uses_left=(uses if uses > 0 else None), duration_min=minutes, state="stored", source=source)
    session.add(b)
    session.flush()
    return b


def consume(b, n=1):
    if b.uses_left is not None:
        b.uses_left -= n
        if b.uses_left <= 0:
            b.state = "used"


@_txn
def activate_booster(session, user, booster_id):
    b = session.get(BD.BpBooster, int(booster_id))
    if b is None or b.user_id != user.telegram_id or b.state != "stored":
        raise BpError("این بوستر پیدا نشد یا قبلاً فعال شده.")
    if b.kind == "jail_free":
        raise BpError("کارتِ آزادی وقتی تو زندانی از «بوستر‌ها» یا صفحه‌ی وثیقه مصرف می‌شه.")
    if best_booster(session, user.telegram_id, b.kind) is not None:
        raise BpError("از این نوع یه بوستر الان فعاله؛ بعد از تموم‌شدنش فعالِ بعدی رو بزن.")
    now = utcnow()
    b.state = "active"
    b.activated_at = now
    b.ends_at = now + datetime.timedelta(minutes=b.duration_min) if b.duration_min else None
    invalidate(user.telegram_id)
    return b


@_txn
def use_jail_card(session, user):
    now = utcnow()
    if not (user.jailed_until and user.jailed_until > now):
        raise BpError("الان تو زندان نیستی.")
    b = (session.query(BD.BpBooster).filter(BD.BpBooster.user_id == user.telegram_id, BD.BpBooster.kind == "jail_free",
                                            BD.BpBooster.state.in_(["stored", "active"]))
         .order_by(BD.BpBooster.id).first())
    if b is None:
        raise BpError("کارتِ آزادی نداری.")
    user.jailed_until = None
    user.jail_bail_amount = None
    user.jail_reason = None
    if b.uses_left is None:
        b.uses_left = 1
    b.state = "active"
    consume(b)
    try:
        import antispam
        antispam.release(user.telegram_id)
    except Exception:
        pass
    invalidate(user.telegram_id)
    return b


def has_jail_card(uid):
    """آیا کاربر کارتِ آزادیِ مصرف‌نشده داره؟ (Session کوتاهِ خودش - برایِ صفحه‌ی وثیقه)."""
    s = db.get_session()
    try:
        return s.query(BD.BpBooster.id).filter(BD.BpBooster.user_id == int(uid), BD.BpBooster.kind == "jail_free",
                                               BD.BpBooster.state.in_(["stored", "active"])).first() is not None
    finally:
        s.close()


def my_boosters(session, uid):
    _expire(session, uid)
    return (session.query(BD.BpBooster).filter(BD.BpBooster.user_id == uid, BD.BpBooster.state.in_(["stored", "active"]))
            .order_by(BD.BpBooster.state, BD.BpBooster.id).all())


# ---------------------------------------------------------------------------
# جایزه‌ها
# ---------------------------------------------------------------------------
def defs_map(session, season_id):
    return {(d.tier, d.track): d for d in session.query(BD.BpTierDef).filter_by(season_id=season_id).all()}


def claimed_set(session, uid, season_id):
    return {(c.tier, c.track) for c in session.query(BD.BpClaim).filter_by(user_id=uid, season_id=season_id).all()}


def reward_text(d):
    """متنِ کوتاهِ یه جایزه (برایِ نمایش)."""
    if d is None or d.kind == "none":
        return "—"
    if d.label:
        base = d.label
    elif d.kind == "hop":
        return f"💰 {fmt(d.amount)}"
    elif d.kind == "xp":
        return f"⭐ {fmt(d.amount)} XP"
    elif d.kind in ("shop_money", "shop_power"):
        base = f"{BD.KINDS[d.kind].split(' (')[0]} ×{int(d.amount or 1)}"
    else:
        base = BD.KINDS.get(d.kind, d.kind)
    icon = {"hop": "💰", "hop_perm": "🦘", "hop_boost": "🦘", "prod_boost": "🏭", "xp_boost": "⚡️", "heist_loot": "🥷",
            "heist_cd": "⏱", "jail_free": "🗝", "shop_money": "💵", "shop_power": "💪", "title": "🏷"}.get(d.kind, "🎁")
    return base if base[:1] in "💰🦘🏭⚡🥷⏱🗝💵💪🏷🎁⭐👑" else f"{icon} {base}"


def _cheapest_shop_booster(session, btype):
    return (session.query(db.ShopItem)
            .filter(db.ShopItem.category == "booster", db.ShopItem.booster_type == btype, db.ShopItem.active == True)  # noqa: E712
            .order_by(db.ShopItem.price).first())


def _deliver(session, user, season, p, d, tag):
    """جایزه رو تحویل می‌ده. -> متنِ نتیجه"""
    import war_svc
    k = d.kind
    uid = user.telegram_id
    if k == "hop":
        war_svc.hop_apply(session, user, float(d.amount), "EVENT_REWARD", f"bp:{tag}", ref=f"bp:{season.id}:{tag}")
        return f"💰 +{fmt(d.amount)} هاپ"
    if k == "xp":
        add_xp(session, p, d.amount)
        return f"⭐ +{fmt(d.amount)} XP"
    if k == "hop_perm":
        p.hop_perm_pct = (p.hop_perm_pct or 0) + float(d.pct)
        invalidate(uid)
        return f"🦘 هاپِ +{d.pct:g}٪ تا آخرِ فصل"
    if k in BD.BOOSTER_KINDS:
        grant_booster(session, uid, k, d.pct, d.uses, d.minutes, season.id, f"bp:{tag}")
        return reward_text(d)
    if k in ("shop_money", "shop_power"):
        item = _cheapest_shop_booster(session, "money" if k == "shop_money" else "power")
        if item is None:
            war_svc.hop_apply(session, user, 5 * gf(session, "bp_cash_unit", 100000), "EVENT_REWARD", f"bp:{tag}:nostock")
            return "💰 (بوسترِ فروشگاه موجود نبود؛ جایگزینِ نقدی)"
        qty = max(1, int(d.amount or 1))
        inv = (session.query(db.InventoryItem).filter_by(user_id=uid, shop_item_id=item.id, equipped=False).first())
        if inv is None:
            session.add(db.InventoryItem(user_id=uid, shop_item_id=item.id, quantity=qty, uses_remaining=item.uses))
        else:
            inv.quantity = (inv.quantity or 0) + qty
        return f"{BD.KINDS[k].split(' (')[0]} «{item.name}» ×{qty} (تو کوله‌پشتی)"
    if k.startswith("fr_"):
        import frontier_svc
        return frontier_svc.bp_deliver(session, user, d, tag)
    if k == "title":
        cur = [t for t in (p.titles or "").split("|") if t]
        if d.label and d.label not in cur:
            cur.append(d.label)
        p.titles = "|".join(cur)
        return f"🏷 لقب: {d.label}"
    return "🎁"


def _claim_one(session, user, season, p, tier, track, defs):
    n = season.tiers
    if tier > n:                                   # مسترى
        d = mastery_reward(session, tier - n)
    else:
        d = defs.get((tier, track))
    if d is None or d.kind == "none":
        return None
    session.add(BD.BpClaim(user_id=user.telegram_id, season_id=season.id, tier=tier, track=track))
    session.flush()                                # UniqueConstraint = جلوگیری از دریافتِ دوباره
    return _deliver(session, user, season, p, d, f"{tier}{track[0]}")


def claimable(session, season, p, defs=None, claimed=None):
    """-> list[(tier, track)] جایزه‌هایِ قابل‌دریافت (شاملِ مسترى)."""
    defs = defs if defs is not None else defs_map(session, season.id)
    claimed = claimed if claimed is not None else claimed_set(session, p.user_id, season.id)
    st = progress(session, p.xp, season.tiers)
    out = []
    for t in range(1, st["tier"] + 1):
        for track in ("free", "premium"):
            if track == "premium" and not p.premium:
                continue
            d = defs.get((t, track))
            if d is not None and d.kind != "none" and (t, track) not in claimed:
                out.append((t, track))
    for k in range(1, st["mastery"] + 1):
        if (season.tiers + k, "free") not in claimed:
            out.append((season.tiers + k, "free"))
    return out


def _can_claim_window(session, season):
    return is_open(season) or in_grace(session, season)


@_txn
def claim_tier(session, user, season_id, tier, track):
    season = session.get(BD.BpSeason, int(season_id))
    if season is None or not _can_claim_window(session, season):
        raise BpError("مهلتِ دریافتِ این فصل تموم شده.")
    p = get_player(session, user, season, create=False)
    if p is None:
        raise BpError("تو این فصل شرکت نکردی.")
    if (tier, track) not in claimable(session, season, p):
        raise BpError("این جایزه هنوز قابل‌دریافت نیست یا قبلاً گرفتیش.")
    text_ = _claim_one(session, user, season, p, tier, track, defs_map(session, season.id))
    invalidate(user.telegram_id)
    return text_


@_txn
def claim_all(session, user, season_id):
    season = session.get(BD.BpSeason, int(season_id))
    if season is None or not _can_claim_window(session, season):
        raise BpError("مهلتِ دریافتِ این فصل تموم شده.")
    p = get_player(session, user, season, create=False)
    if p is None:
        raise BpError("تو این فصل شرکت نکردی.")
    defs = defs_map(session, season.id)
    lines = []
    for tier, track in claimable(session, season, p, defs):
        try:
            r = _claim_one(session, user, season, p, tier, track, defs)
        except Exception:
            session.rollback()
            raise
        if r:
            lines.append(f"{'👑' if track == 'premium' else '🆓'} تیر {tier}: {r}")
    if not lines:
        raise BpError("جایزه‌ی قابل‌دریافتی نداری.")
    invalidate(user.telegram_id)
    return lines


@_txn
def buy_premium(session, user):
    import war_svc
    season = current_season(session)
    if not is_open(season):
        raise BpError("فصل تموم شده.")
    p = _sync(session, user, season)
    if p.premium:
        raise BpError("پریمیومِ این فصل رو از قبل داری.")
    price = gf(session, "bp_premium_price", 30000000)
    try:
        war_svc.hop_apply(session, user, -price, "SPEND", "bp:premium", ref=f"bp:{season.id}")
    except Exception:
        raise BpError(f"💸 موجودیِ هاپ پوینتت کافی نیست ({fmt(price)} 🪙 لازمه).")
    p.premium = True
    p.premium_at = utcnow()
    invalidate(user.telegram_id)
    return price


def skip_price(session, season, p):
    st = progress(session, p.xp, season.tiers)
    base = gf(session, "bp_skip_price", 1500000)
    return base * (1.0 + 0.25 * stage_of(st["tier"] + 1, season.tiers)), st


@_txn
def buy_skip(session, user):
    import war_svc
    season = current_season(session)
    if not is_open(season):
        raise BpError("فصل تموم شده.")
    p = _sync(session, user, season)
    price, st = skip_price(session, season, p)
    if st["maxed"]:
        raise BpError("به آخرین تیر رسیدی؛ مسترى فقط با XP بالا می‌ره.")
    try:
        war_svc.hop_apply(session, user, -price, "SPEND", "bp:skip", ref=f"bp:{season.id}")
    except Exception:
        raise BpError(f"💸 موجودیِ هاپ پوینتت کافی نیست ({fmt(price)} 🪙 لازمه).")
    p.xp = thresholds(session, season.tiers)[st["tier"] + 1]
    p.skips = (p.skips or 0) + 1
    return price, st["tier"] + 1


def leaderboard(session, season, limit=None):
    limit = limit or gi(session, "bp_leaderboard_size", 10)
    rows = (session.query(BD.BpPlayer, db.User).join(db.User, db.User.telegram_id == BD.BpPlayer.user_id)
            .filter(BD.BpPlayer.season_id == season.id, BD.BpPlayer.xp > 0)
            .order_by(BD.BpPlayer.xp.desc()).limit(limit).all())
    return [((u.first_name or u.username or str(u.telegram_id)), progress(session, p.xp, season.tiers), p.premium)
            for p, u in rows]


def rank_of(session, season, p):
    return 1 + session.query(BD.BpPlayer).filter(BD.BpPlayer.season_id == season.id, BD.BpPlayer.xp > (p.xp or 0)).count()


# ---------------------------------------------------------------------------
# هوک‌ها (کشِ حافظه؛ بدونِ کوئری رویِ مسیرِ داغِ «هاپ»)
# ---------------------------------------------------------------------------
_CACHE = {}
_CACHE_TTL = 20.0


def invalidate(uid=None):
    if uid is None:
        _CACHE.clear()
    else:
        _CACHE.pop(int(uid), None)
    _season_memo_clear()


def _season_light(session):
    import time as _t
    if _SEASON_MEMO["id"] is not None and _t.monotonic() - _SEASON_MEMO["t"] < 30 and utcnow() < _SEASON_MEMO["ends"]:
        return _SEASON_MEMO["id"]
    s = current_season(session)
    _SEASON_MEMO.update(t=_t.monotonic(), id=s.id if is_open(s) else 0, ends=s.ends_at if is_open(s) else utcnow() + datetime.timedelta(seconds=30))
    return _SEASON_MEMO["id"]


def _bonus_state(session, uid):
    import time as _t
    c = _CACHE.get(uid)
    now = utcnow()
    if c and _t.monotonic() - c["t"] < _CACHE_TTL and (c["hop_ends"] is None or c["hop_ends"] > now) \
            and (c["prod_ends"] is None or c["prod_ends"] > now):
        return c
    sid = _season_light(session)
    perm, prem = 0.0, False
    if sid:
        p = session.get(BD.BpPlayer, (uid, sid))
        if p is not None:
            perm, prem = float(p.hop_perm_pct or 0), bool(p.premium)
    hb = best_booster(session, uid, "hop_boost")
    pb = best_booster(session, uid, "prod_boost")
    c = {"t": _t.monotonic(), "perm": perm, "prem": prem,
         "hop_pct": hb.pct if hb else 0.0, "hop_ends": hb.ends_at if hb else None,
         "prod_pct": pb.pct if pb else 0.0, "prod_ends": pb.ends_at if pb else None}
    _CACHE[uid] = c
    return c


def hop_bonus_pct(session, uid):
    if not enabled(session):
        return 0.0
    c = _bonus_state(session, uid)
    pct = gf(session, "bp_hop_bonus_global_pct", 0) + c["perm"] + c["hop_pct"]
    if c["prem"]:
        pct += gf(session, "bp_hop_bonus_premium_pct", 10)
    return max(0.0, min(pct, gf(session, "bp_hop_bonus_cap_pct", 150)))


def production_mult(session, uid):
    if not enabled(session):
        return 1.0
    return 1.0 + _bonus_state(session, uid)["prod_pct"] / 100.0


def on_hop(session, user, reward):
    """بعد از انتخابِ مبلغِ هاپ صدا زده می‌شه. -> (مبلغِ جدید, درصدِ بونوس)"""
    if not enabled(session):
        return reward, 0.0
    _log_hop(session, user.telegram_id)
    pct = hop_bonus_pct(session, user.telegram_id)
    if pct > 0:
        reward = int(round(reward * (1.0 + pct / 100.0)))
    return reward, pct


def heist_bonus(session, user, share, op_id):
    """غنیمتِ اضافه از بوسترِ سرقت (از «خانه»؛ از سهمِ بقیه کم نمی‌شه)."""
    import war_svc
    b = best_booster(session, user.telegram_id, "heist_loot")
    if b is None or share <= 0:
        return 0.0
    extra = share * b.pct / 100.0
    war_svc.hop_apply(session, user, extra, "BONUS", f"bp:heist_loot:{op_id}", ref=op_id)
    consume(b)
    invalidate(user.telegram_id)
    return extra


def heist_cooldown(session, user_id, minutes):
    b = best_booster(session, int(user_id), "heist_cd")
    if b is None or minutes <= 0:
        return minutes
    consume(b)
    invalidate(user_id)
    return max(1, int(round(minutes * (1.0 - min(b.pct, 95.0) / 100.0))))


# ---------------------------------------------------------------------------
# ادمین
# ---------------------------------------------------------------------------
_TEXT_KEYS = {"bp_season_names", "bp_stage_costs", "bp_activity_weights", "bp_daily_diffs", "bp_weekly_diffs"}


def admin_set_cfg(session, key, value):
    if key not in BD.CFG_DEFAULT:
        raise BpError("کلیدِ نامعتبر.")
    v = str(value).strip()
    if key not in _TEXT_KEYS:
        try:
            f = float(v.translate(_FA))
        except ValueError:
            raise BpError("باید عدد باشه.")
        if f < 0:
            raise BpError("عددِ منفی مجاز نیست.")
        v = str(int(f)) if f == int(f) else str(f)
    elif key == "bp_stage_costs":
        if len([x for x in v.translate(_FA).split(",") if x.strip()]) != 5:
            raise BpError("دقیقاً ۵ عدد با کاما بده (۵ مرحله‌ی سختی).")
    db.cfg_set(session, key, v)
    db.cfg_cache_clear()
    invalidate()
    return v


def admin_new_season(session, name=None, days=None):
    with LOCK:
        cur = session.query(BD.BpSeason).order_by(BD.BpSeason.id.desc()).first()
        if cur is not None and cur.status == "active":
            cur.status = "ended"
            cur.ends_at = min(cur.ends_at, utcnow())
        s = create_season(session, name=name, days=days, clone_from=cur)
        session.commit()
        return s


def admin_extend(session, days):
    with LOCK:
        s = current_season(session)
        if s.status != "active":
            raise BpError("فصلِ فعالی نیست.")
        s.ends_at = s.ends_at + datetime.timedelta(days=int(days))
        session.commit()
        _season_memo_clear()
        return s


def admin_end_now(session):
    with LOCK:
        s = current_season(session)
        s.status = "ended"
        s.ends_at = min(s.ends_at, utcnow())
        session.commit()
        _season_memo_clear()
        return s


def admin_parse_reward(text_):
    """kind|amount|pct|uses|minutes|label"""
    parts = [x.strip() for x in text_.split("|")]
    if not parts or parts[0] not in BD.KINDS:
        raise BpError("نوعِ جایزه نامعتبره. یکی از: " + ", ".join(BD.KINDS))
    parts += [""] * (6 - len(parts))
    try:
        amount = float(parts[1].translate(_FA) or 0)
        pct = float(parts[2].translate(_FA) or 0)
        uses = int(float(parts[3].translate(_FA) or 0))
        minutes = int(float(parts[4].translate(_FA) or 0))
    except ValueError:
        raise BpError("مقدارها باید عدد باشن.")
    return dict(kind=parts[0], amount=amount, pct=pct, uses=uses, minutes=minutes, label=parts[5][:80])


def admin_set_tier(session, season_id, tier, track, text_):
    if track not in ("free", "premium"):
        raise BpError("مسیر باید free یا premium باشه.")
    r = admin_parse_reward(text_)
    with LOCK:
        d = session.query(BD.BpTierDef).filter_by(season_id=season_id, tier=tier, track=track).first()
        if d is None:
            d = BD.BpTierDef(season_id=season_id, tier=tier, track=track)
            session.add(d)
        for k, v in r.items():
            setattr(d, k, v)
        session.commit()
        return d


def admin_reset_rewards(session, season_id):
    with LOCK:
        s = session.get(BD.BpSeason, season_id)
        session.query(BD.BpTierDef).filter_by(season_id=season_id).delete()
        for r in default_rewards(s.tiers, gf(session, "bp_cash_unit", 100000)):
            session.add(BD.BpTierDef(season_id=season_id, **r))
        session.commit()


def admin_create_challenge(session, title, metric, target, xp, diff, period):
    if metric not in METRIC_LABEL:
        raise BpError("معیارِ نامعتبر. یکی از: " + ", ".join(METRIC_LABEL))
    if period not in BD.PERIODS:
        raise BpError("دوره باید daily/weekly/season باشه.")
    try:
        target, xp, diff = int(float(str(target).translate(_FA))), int(float(str(xp).translate(_FA))), int(str(diff).translate(_FA))
    except ValueError:
        raise BpError("تعداد/XP/درجه باید عدد باشن.")
    if not (1 <= diff <= 4) or target < 1 or xp < 0:
        raise BpError("درجه ۱ تا ۴ و تعداد ≥ ۱ باشه.")
    d = BD.BpChallengeDef(title=title[:80], metric=metric, target=target, xp=xp, diff=diff, period=period)
    session.add(d)
    session.commit()
    return d


def admin_set_challenge(session, ch_id, key, value):
    d = session.get(BD.BpChallengeDef, int(ch_id))
    if d is None or d.deleted:
        raise BpError("پیدا نشد.")
    kind = BD.CH_KIND.get(key)
    if kind is None:
        raise BpError("فیلدِ نامعتبر.")
    v = str(value).strip()
    if kind == "int":
        try:
            v = int(float(v.translate(_FA)))
        except ValueError:
            raise BpError("باید عدد باشه.")
        if key == "diff" and not (1 <= v <= 4):
            raise BpError("درجه ۱ تا ۴.")
        if key == "target" and v < 1:
            raise BpError("حداقل ۱.")
    elif kind == "metric":
        if v not in METRIC_LABEL:
            raise BpError("معیارِ نامعتبر.")
    elif kind.startswith("enum:"):
        if v not in kind[5:].split("|"):
            raise BpError("فقط یکی از: " + kind[5:])
    setattr(d, key, v)
    session.commit()
    return d


def admin_grant(session, uid, what, a=0, b=0, c=0, d_=0):
    """what: xp | premium | booster"""
    with LOCK:
        u = session.get(db.User, int(uid))
        if u is None:
            raise BpError("کاربری با این آیدی نیست.")
        season = current_season(session)
        p = get_player(session, u, season)
        if what == "xp":
            add_xp(session, p, float(a))
        elif what == "premium":
            p.premium, p.premium_at = True, utcnow()
        elif what == "booster":
            grant_booster(session, u.telegram_id, a, b, c, d_, season.id, "admin")
        else:
            raise BpError("؟")
        session.commit()
        invalidate(u.telegram_id)
        return u


def stats(session, season):
    xs = [(float(x or 0), bool(pr)) for x, pr in session.query(BD.BpPlayer.xp, BD.BpPlayer.premium).filter_by(season_id=season.id).all()]
    n = len(xs)
    cum = thresholds(session, season.tiers)
    tiers = []
    for x, _p in xs:
        t = 0
        while t < season.tiers and x >= cum[t + 1]:
            t += 1
        tiers.append(t)
    return {"players": n, "premium": sum(1 for _x, pr in xs if pr),
            "avg_tier": (sum(tiers) / n) if n else 0, "maxed": sum(1 for t in tiers if t >= season.tiers),
            "revenue": sum(1 for _x, pr in xs if pr) * gf(session, "bp_premium_price", 0)}
