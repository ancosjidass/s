# -*- coding: utf-8 -*-
"""
برچسب‌های فارسیِ تنظیمات و فیلدهای «جنگ هاپویی» برای پنل ادمین (مثلِ «تولید پایه در دقیقه» تو هاپ منیج).
اسمِ انگلیسیِ متغیر فقط ریز و داخلِ پرانتز کنارش میاد؛ اگه برای کلیدی برچسب نباشه همون اسمِ خامش نشون داده می‌شه.
"""

CFG = {
    "war_enabled": "🟢 سیستمِ جنگ روشن باشه؟ (۱=بله ۰=خیر)",
    "minlvl_war": "🔐 حداقل لولِ ورود به جنگ (۰ = بدونِ محدودیت)",
    # --- اقتصاد
    "war_income_multiplier": "💰 ضریبِ درآمدِ جنگ نسبت به کارخونه (۳ تا ۴ برابر)",
    "war_level_step": "🏗 سقفِ سطحِ هر ساختمان = سطحِ مقر × این عدد",
    "war_vault_cap_hours": "🏦 ظرفیتِ گاوصندوق (چند ساعت درآمد)",
    "war_mat_cap_hours": "🧱 ظرفیتِ انبارِ مواد (چند ساعت تولید)",
    "war_upgrade_h0": "⬆️ هزینه‌ی ارتقا: ساعتِ درآمدِ پایه",
    "war_upgrade_h1": "⬆️ هزینه‌ی ارتقا: افزایش به‌ازای هر سطح (ساعت)",
    "war_mat_base_per_hour": "🧱 تولیدِ پایه‌ی مواد در ساعت",
    "war_mat_growth": "📈 ضریبِ رشدِ تولیدِ مواد در هر سطح",
    "war_mat_upgrade_hours": "🧱 هزینه‌ی ارتقای مواد (ساعتِ درآمد)",
    "war_start_mat_hours": "🎁 موادِ اولیه‌ی بازیکنِ جدید (ساعتِ تولید)",
    "war_build_time_base_min": "⏱ زمانِ پایه‌ی ساخت/ارتقا (دقیقه)",
    "war_build_time_growth": "📈 ضریبِ رشدِ زمانِ ساخت در هر سطح",
    "war_build_time_max_hours": "⏱ سقفِ زمانِ ساخت (ساعت)",
    "war_builders_base": "👷 تعدادِ پایه‌ی سازنده‌ها",
    "war_builders_per_th": "👷 هر چند سطحِ مقر، یه سازنده‌ی اضافه",
    "war_hop_max_balance": "🔒 سقفِ موجودیِ هاپ پوینت (ضدِ سرریز)",
    # --- XP
    "war_level_base_xp": "⭐ فاصله‌ی سطحِ ۱ به ۲ در جنگ (XP)",
    "war_level_growth": "📈 رشدِ خطیِ فاصله‌ی سطح‌ها (XP)",
    "war_level_quad": "📊 رشدِ درجه‌دومِ فاصله‌ی سطح‌ها",
    "war_max_level": "🔢 سقفِ سطحِ بازیکن در جنگ",
    # --- سوخت و آمادگی
    "war_fuel_max": "⛽ حداکثرِ سوخت",
    "war_fuel_regen_minutes": "⛽ هر چند دقیقه ۱ سوخت پر می‌شه",
    "war_start_fuel": "⛽ سوختِ اولیه‌ی بازیکنِ جدید",
    "war_start_infantry": "🪖 پیاده‌نظامِ اولیه‌ی بازیکنِ جدید",
    "war_readiness_recovery_per_hour": "🔋 بازیابیِ آمادگی در ساعت (درصد)",
    "war_prepare_cost_ref_hours": "🔧 هزینه‌ی آماده‌سازی (ساعتِ درآمد)",
    "war_prepare_fuel": "⛽ سوختِ لازم برای آماده‌سازی",
    "war_prepare_gain": "🔋 افزایشِ آمادگی با هر آماده‌سازی (درصد)",
    "war_prepare_seconds": "⏱ مدتِ آماده‌سازی (ثانیه)",
    "war_defense_readiness_loss": "🛡 افتِ آمادگی بعد از هر دفاع (درصد)",
    # --- شیلد / انتقام
    "war_shield_rules": "🛡 قانونِ شیلد (حداقل تخریب:ساعت، با کاما)",
    "war_shield_buy_hours": "🛡 مدتِ شیلدِ خریدنی (ساعت)",
    "war_shield_buy_ref_hours": "🛡 قیمتِ شیلدِ خریدنی (ساعتِ درآمد)",
    "war_attack_breaks_shield": "💥 حمله‌ی خودت شیلدت رو بشکنه؟ (۱/۰)",
    "war_revenge_hours": "⚔️ مهلتِ انتقام (ساعت)",
    "war_revenge_loot_bonus_pct": "⚔️ بونوسِ غنیمتِ انتقام (درصد)",
    "war_revenge_xp_mult": "⚔️ ضریبِ XPِ انتقام",
    # --- غنیمت / ضدفارم
    "war_antifarm_steps": "🚫 ضدِ فارم: ضریبِ غنیمت برای حمله‌های پشتِ‌سرهم به یه نفر (با کاما)",
    "war_antifarm_window_hours": "🚫 ضدِ فارم: بازه‌ی شمارش (ساعت)",
    "war_loot_max_frac_pct": "💰 سقفِ سهمِ غنیمت از گاوصندوقِ هدف (درصد)",
    "war_loot_exp": "💰 توانِ منحنیِ غنیمت نسبت به تخریب",
    "war_vault_protect_pct": "🔐 درصدِ محافظت‌شده‌ی گاوصندوق",
    "war_loot_cap_hours": "💰 سقفِ غنیمتِ هر نبرد (ساعتِ درآمدِ مهاجم)",
    "war_pair_daily_loot_cap_hours": "💰 سقفِ روزانه‌ی غنیمت بینِ دو نفر (ساعتِ درآمد)",
    "war_crushing_threshold": "💥 حدِ «پیروزی کوبنده» (درصدِ تخریب)",
    "war_crushing_bonus_pct": "💥 بونوسِ پیروزیِ کوبنده (درصد)",
    "war_weak_target_trophy_gap": "🏅 اختلافِ کاپ برای «هدفِ خیلی ضعیف»",
    "war_weak_target_loot_pct": "🏅 درصدِ غنیمت از هدفِ خیلی ضعیف",
    "war_matchmaking_trophy_range": "🎯 بازه‌ی کاپ برای پیدا کردنِ حریف",
    "war_target_max_inactive_days": "😴 هدف‌هایی که بیشتر از این روز غیرفعالن نمایش داده نشن",
    "war_scout_cost_ref_hours": "🔭 هزینه‌ی دیدنِ حریف (ساعتِ درآمد)",
    "war_spy_cost_ref_hours": "🕵️ هزینه‌ی جاسوسی (ساعتِ درآمد)",
    "war_spy_base_error_pct": "🕵️ خطای پایه‌ی گزارشِ جاسوسی (درصد)",
    "war_spy_error_per_radar_pct": "📡 کاهشِ خطا به‌ازای هر سطحِ رادار (درصد)",
    "war_spy_cooldown_minutes": "🕵️ کول‌داونِ جاسوسی (دقیقه)",
    # --- کاپ / لیگ
    "war_trophy_base": "🏅 کاپِ پایه‌ی هر نبرد",
    "war_trophy_loss_ratio": "🏅 نسبتِ کاپِ از دست رفته در باخت",
    "war_leagues": "🏆 لیگ‌ها (نام:کاپِ لازم، با کاما)",
    "war_league_weekly_ref_hours": "🏆 پاداشِ هفتگیِ هر لیگ (ساعتِ درآمد، با کاما)",
    # --- آموزش / تعمیر
    "war_queue_per_barracks_levels": "🪖 هر چند سطحِ پادگان، ۱ صفِ آموزشِ اضافه",
    "war_repair_workshop_disc_pct": "🔧 تخفیفِ تعمیر به‌ازای هر سطحِ کارگاه (درصد)",
    "war_repair_workshop_max_pct": "🔧 سقفِ تخفیفِ تعمیر (درصد)",
    "war_sell_enabled": "💱 فروشِ تجهیزات فعال باشه؟ (۱/۰)",
    # --- قبیله
    "war_clan_create_ref_hours": "🏰 هزینه‌ی ساختِ قبیله (ساعتِ درآمد)",
    "war_clan_create_min_th": "🏰 حداقل سطحِ مقر برای ساختِ قبیله",
    "war_clan_max_members": "👥 سقفِ مطلقِ اعضای قبیله",
    "war_clan_capacity_base": "👥 ظرفیتِ قبیله در سطحِ ۱",
    "war_clan_capacity_per_level": "👥 افزایشِ ظرفیت به‌ازای هر سطحِ قبیله",
    "war_clan_rank_names": "🎖 نامِ رتبه‌های قبیله (۵ نام، با کاما)",
    "war_clan_perms": "🔑 حداقل رتبه‌ی لازم برای هر اقدامِ قبیله (JSON)",
    "war_clan_coleader_kick_max_rank": "🚪 معاون تا کدوم رتبه رو می‌تونه اخراج کنه",
    "war_clan_request_ttl_hours": "📨 اعتبارِ درخواستِ عضویت (ساعت)",
    "war_clan_max_pending_requests": "📨 سقفِ درخواستِ عضویتِ هم‌زمان",
    "war_clan_suggest_count": "💡 تعدادِ قبیله‌های پیشنهادی",
    "war_donate_daily_cap": "🎁 سقفِ روزانه‌ی اهدای واحد",
    "war_donate_max_request": "🎁 سقفِ درخواستِ اهدا",
    "war_donate_contrib": "⭐ امتیازِ مشارکت به‌ازای هر واحدِ اهدایی",
    "war_clan_max_level": "🏰 سقفِ سطحِ قبیله",
    "war_clan_xp_base": "⭐ XPِ لازم برای سطحِ ۲ قبیله",
    "war_clan_xp_growth": "📈 ضریبِ رشدِ XPِ قبیله",
    "war_treasury_cap_hours": "🏦 ظرفیتِ خزانه‌ی قبیله (ساعتِ درآمد)",
    "war_deposit_min_ref_hours": "💵 حداقلِ واریز به خزانه (ساعتِ درآمد)",
    "war_deposit_contrib_per_ref_hour": "⭐ امتیازِ مشارکتِ هر ساعتِ واریزی",
    "war_deposit_contrib_daily_cap": "⭐ سقفِ روزانه‌ی امتیازِ مشارکتِ واریز",
    "war_settle_days": "📆 هر چند روز تسویه‌ی خزانه",
    "war_settle_pool_pct": "💰 درصدِ خزانه که تسویه می‌شه",
    "war_settle_member_cap_pct": "💰 سقفِ سهمِ هر عضو از تسویه (درصد)",
    "war_settle_min_contribution": "⭐ حداقلِ مشارکت برای گرفتنِ سهمِ تسویه",
    "war_settle_max_ref_hours": "💰 سقفِ برداشتِ هر عضو در هر تسویه (ساعتِ درآمد)",
    "war_leave_cooldown_hours": "🚪 کول‌داونِ عضویت بعد از خروج (ساعت)",
    # --- جنگِ قبیله
    "war_cw_prep_minutes": "⚔️ مدتِ آماده‌سازیِ جنگِ قبیله (دقیقه)",
    "war_cw_duration_minutes": "⚔️ مدتِ خودِ جنگِ قبیله (دقیقه)",
    "war_cw_attacks_per_member": "⚔️ تعدادِ حمله‌ی هر عضو در جنگِ قبیله",
    "war_cw_min_size": "👥 حداقلِ تعدادِ نفراتِ هر طرف",
    "war_cw_max_size": "👥 حداکثرِ تعدادِ نفراتِ هر طرف",
    "war_cw_search_timeout_minutes": "🔎 مهلتِ جست‌وجوی حریف (دقیقه)",
    "war_cw_match_level_gap": "🎯 حداکثر اختلافِ سطحِ قبیله‌ها",
    "war_cw_loot_mult": "💰 ضریبِ غنیمتِ جنگِ قبیله",
    # --- کودتا
    "war_coup_min_membership_days": "🚨 کودتا: حداقلِ روزِ عضویت",
    "war_coup_min_contribution": "🚨 کودتا: حداقلِ مشارکت",
    "war_coup_min_xp": "🚨 کودتا: حداقلِ XP",
    "war_coup_xp_cost": "🚨 کودتا: هزینه‌ی XP",
    "war_coup_base_chance_pct": "🚨 کودتا: شانسِ پایه (درصد)",
    "war_coup_max_chance_pct": "🚨 کودتا: سقفِ شانس (درصد)",
    "war_coup_reward_treasury_pct": "🚨 کودتا: پاداش از خزانه (درصد)",
    "war_coup_reward_cap_hours": "🚨 کودتا: سقفِ پاداش (ساعتِ درآمد)",
    "war_coup_user_cooldown_days": "🚨 کودتا: کول‌داونِ هر فرد (روز)",
    "war_coup_clan_cooldown_days": "🚨 کودتا: کول‌داونِ هر قبیله (روز)",
    "war_coup_fail_xp_extra": "🚨 کودتا: جریمه‌ی XP در شکست",
    "war_coup_fail_contrib_pct": "🚨 کودتا: جریمه‌ی مشارکت در شکست (درصد)",
    "war_coup_leader_inactive_days": "😴 کودتا: روزهای غیرفعالیِ رهبر برای مجاز شدن",
    # --- دیپلماسی
    "war_dip_truce_hours": "🕊 مدتِ آتش‌بس (ساعت)",
    "war_dip_ally_min_clan_level": "🤝 حداقلِ سطحِ قبیله برای اتحاد",
    "war_dip_max_allies": "🤝 حداکثرِ تعدادِ متحدها",
    # --- ارتقای تجهیز
    "war_unit_upgrade_ref_hours": "🚀 هزینه‌ی ارتقای تجهیز (ضریبِ ساعتِ درآمد)",
    "war_unit_upgrade_cost_mult": "🚀 ضریبِ هزینه‌ی ارتقای تجهیز",
    # --- UI
    "war_panel_cooldown_seconds": "⏱ فاصله‌ی ضدِ اسپمِ دکمه‌های پنل (ثانیه)",
    "war_page_size": "📄 تعدادِ ردیف در هر صفحه",
    "war_confirm_ttl_seconds": "⏳ اعتبارِ دکمه‌ی تأیید (ثانیه)",
    "war_notify_group_max_chars": "💬 حداکثرِ طولِ پیامِ اعلانِ گروه",
    "war_formula_version": "🧮 نسخه‌ی فعالِ فرمولِ نبرد (فقط‌خواندنی؛ با «انتشار» عوض می‌شه)",
    "war_ref_calibration": "♻️ مبنای کالیبراسیونِ قیمت‌ها (خودکار)",
    # --- فرمولِ نبرد
    "war_f_k": "🧮 شیبِ منحنیِ تخریب",
    "war_f_h": "🧮 نسبتِ قدرت برای رسیدن به ۵۰٪ تخریب",
    "war_f_random": "🎲 نوسانِ تصادفیِ نبرد (±، حداکثر ۰٫۵)",
    "war_f_damaged_mult": "🔧 قدرتِ تجهیزِ آسیب‌دیده نسبت به سالم (۰٫۰۵ تا ۱)",
    "war_f_support_cap": "🛠 سقفِ بونوسِ پشتیبانی",
    "war_f_def_army_share": "🛡 سهمِ قدرتِ ارتشِ مستقر در دفاع",
    "war_f_readiness_floor": "🔋 حداقلِ قدرت وقتی آمادگی صفره",
    "war_f_star_thresholds": "⭐ حدِ ستاره‌ها (درصدِ تخریب برای ۱/۲/۳ ستاره، با کاما)",
    "war_f_draw_threshold": "🤝 حدِ مساوی (تخریبِ بدونِ ستاره، درصد)",
    "war_f_atk_destroy": "💥 نرخِ پایه‌ی نابودیِ نیروی مهاجم",
    "war_f_atk_damage": "💔 نرخِ پایه‌ی آسیب‌دیدنِ نیروی مهاجم",
    "war_f_def_destroy": "💥 نرخِ پایه‌ی نابودیِ نیروی مدافع",
    "war_f_def_damage": "💔 نرخِ پایه‌ی آسیب‌دیدنِ نیروی مدافع",
    "war_f_counter_matrix": "🎯 جدولِ برتریِ نوعِ تجهیزات (JSON)",
}

# فیلدهای جدول‌ها (ستون -> برچسبِ فارسی). فیلدهای مشترک بینِ جدول‌ها یه‌بار تعریف شدن.
COL = {
    "key": "🔑 شناسه (غیرقابل‌تغییر)", "name": "📛 نام", "emoji": "😀 ایموجی", "enabled": "✅ فعال (۱/۰)", "sort": "↕️ ترتیبِ نمایش",
    "id": "🔢 شماره", "description": "📝 توضیحات",
    # تجهیزات
    "category": "🗂 دسته (ground/armor/air/naval/missile/defense/support/special)", "tier": "🏷 رده", "rarity": "💎 کمیابی",
    "atk": "⚔️ قدرتِ حمله", "defn": "🛡 قدرتِ دفاع", "durability": "🧱 استحکام (بالاتر = کمتر آسیب می‌بینه)",
    "accuracy": "🎯 ضریبِ حمله (دقت)", "special_power": "✨ قدرتِ ویژه (درصدِ بونوسِ حمله به‌ازای هر واحدِ پشتیبان)",
    "housing": "🏠 فضای اشغالی در پادگان", "train_seconds": "⏱ زمانِ آموزش (ثانیه)", "cost": "💰 قیمتِ ساخت (هاپ پوینت)",
    "cost_mat": "🧱 هزینه‌ی مواد", "repair_pct": "🔧 هزینه‌ی تعمیر (درصدِ قیمت)", "repair_seconds": "⏱ زمانِ تعمیر (ثانیه)",
    "sell_pct": "💱 درصدِ برگشتِ پول در فروش", "maint_per_hour": "🛠 نگهداری در ساعت (از تولید کم می‌شه)",
    "upgradeable": "⬆️ قابلِ ارتقا (۱/۰)", "repairable": "🔧 قابلِ تعمیر (۱/۰)", "max_level": "🔝 سقفِ سطح",
    "upg_stat_pct": "📈 درصدِ رشدِ قدرت به‌ازای هر سطح", "req_th": "🏰 حداقل سطحِ مقر", "req_level": "⭐ حداقل سطح",
    "req_clan_level": "🏰 حداقل سطحِ قبیله", "req_research": "🔬 تحقیقِ لازم", "req_achievement": "🏆 دستاوردِ لازم",
    "visible_before": "👁 قبل از باز شدن هم نمایش داده بشه (۱/۰)",
    # ساختمان
    "kind": "🏗 نوع (th/mine/depot/vault/camp/barracks/def_ground/def_air/wall/workshop/radar)", "unlock_th": "🔓 باز شدن در سطحِ مقر",
    "value_base": "📐 مقدارِ پایه", "value_growth": "📈 ضریبِ رشدِ مقدار", "value_add": "➕ افزایشِ مقدار در هر سطح",
    "cost_weight": "💰 وزنِ هزینه نسبت به درآمدِ مرجع", "time_weight": "⏱ وزنِ زمان", "free_start": "🎁 از ابتدا رایگان سطح ۱ (۱/۰)",
    # نوع نبرد
    "min_seconds": "⏱ حداقلِ مدتِ نبرد (ثانیه)", "max_seconds": "⏱ حداکثرِ مدتِ نبرد (ثانیه)", "fuel": "⛽ سوختِ لازم",
    "cost_ref_hours": "💰 هزینه‌ی عملیات (ساعتِ درآمد)", "atk_mult": "⚔️ ضریبِ حمله", "loot_mult": "💰 ضریبِ غنیمت",
    "casualty_mult": "💔 ضریبِ تلفات", "readiness_loss": "🔋 افتِ آمادگی", "xp_mult": "⭐ ضریبِ XP", "reward_mult": "🎁 ضریبِ پاداش",
    "min_army_housing": "🪖 حداقلِ حجمِ ارتش", "unlock_feature": "🔓 قابلیتِ بازکننده",
    # پاداش
    "trigger": "⚡ رویدادِ فعال‌کننده", "label": "📛 عنوان", "xp": "⭐ XP", "xp_min": "⭐ حداقلِ XP", "xp_max": "⭐ سقفِ XP (۰=بدونِ سقف)",
    "clan_xp": "🏰 XPِ قبیله", "contribution": "⭐ مشارکت", "hop_abs": "💰 هاپِ ثابت", "hop_ref_hours": "💰 هاپ (ساعتِ درآمدِ مرجعِ بازیکن)",
    "materials": "🧱 مواد", "hop_min": "💰 حداقلِ هاپ", "hop_max": "💰 سقفِ هاپ (۰=بدونِ سقف)", "ledger_type": "📒 نوعِ تراکنش در لجر",
    "daily_cap_hop": "📆 سقفِ روزانه‌ی هاپ (۰=بدونِ سقف)", "daily_cap_xp": "📆 سقفِ روزانه‌ی XP", "antifarm": "🚫 ضدِ فارم", "multiplier": "✖️ ضریب",
    # آنلاک
    "feature": "🔓 قابلیت", "req_wins": "🏆 حداقلِ برد", "req_quest": "🎯 مأموریتِ لازم", "hint": "💡 راهنما (قبل از باز شدن)",
    # مأموریت
    "metric": "📏 معیار", "target": "🎯 هدف (عدد)",
    # دستاورد
    "threshold": "🎯 حدِ لازم", "badge": "🏅 نشان",
    # تحقیق
    "branch": "🌿 شاخه", "effect": "✨ اثر", "effect_per_level": "📈 اثر به‌ازای هر سطح", "time_minutes": "⏱ زمان (دقیقه)",
    # ایونت
    "start_at": "🕐 شروع (YYYY-MM-DD HH:MM)", "end_at": "🕐 پایان (YYYY-MM-DD HH:MM)", "hop_mult": "💰 ضریبِ هاپ",
    "income_mult": "💵 ضریبِ درآمد", "min_level": "⭐ حداقل سطح", "battle_type": "⚔️ نوعِ نبرد (خالی=همه)",
    # alias
    "panel": "🪟 پنل", "text": "💬 متنِ تریگر", "builtin": "🧰 پیش‌ساخته",
}


def cfg_label(key: str) -> str:
    return CFG.get(key, key)


def col_label(name: str) -> str:
    return COL.get(name, name)


def find_col(model_cols, typed: str):
    """نامِ ستون رو از ورودیِ ادمین پیدا می‌کنه: اسمِ انگلیسی یا عینِ برچسبِ فارسی."""
    t = typed.strip()
    names = list(model_cols)
    if t in names:
        return t
    for n in names:
        if COL.get(n) == t:
            return n
    return None
