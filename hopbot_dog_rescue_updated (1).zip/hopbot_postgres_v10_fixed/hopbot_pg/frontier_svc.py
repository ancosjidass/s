# -*- coding: utf-8 -*-
"""
🌌 FRONTIER — لایه‌ی سرویس. فقط با Session کار می‌کنه و commit رو به فراخوان (UI/Tick) می‌سپره
تا هر «عملِ کاربر» یک تراکنشِ اتمیک باشه. هیچ Handler تلگرامی اینجا نیست.

اتصال به جنگِ موجود (بدونِ سیستمِ موازی):
- بازیکن/سوخت/ریدینس/نیرو/گاوصندوق: war_svc.get_player / sync_player / WarUnit (همون ارتش، همون تعمیر/ارتقا)
- نبرد: war_engine (E.resolve / attack_side / apply_casualties) با دشمنِ ساختگیِ PvE
- پاداش: war_svc.give_reward (قوانینِ WarRewardRule، لجر، ایونت) + hop_apply برای هزینه‌ها
- قبیله: war_clan.member_of / clan_of / clan_add_xp / add_contribution
- مأموریت/متریک: war_svc.metric_bump (WarQuestDef)
"""
import datetime
import json
import math
import random

from sqlalchemy import func, and_

import db
import war_db as W
import war_svc as S
import war_battle as B
import war_clan as C
import war_engine as E
import frontier_db as F
import frontier_engine as FE
from war_svc import WarError, cf, ci, cs


def utcnow():
    return S.utcnow()


# ---------------------------------------------------------------------------
# ابزارهای پایه
# ---------------------------------------------------------------------------

def _insert(model):
    if db.IS_PG:
        from sqlalchemy.dialects.postgresql import insert
    else:
        from sqlalchemy.dialects.sqlite import insert
    return insert(model)


def insert_once(session, model, index_elements, **vals) -> bool:
    """INSERT ... ON CONFLICT DO NOTHING (SQLite + PostgreSQL). True فقط اگه واقعاً ردیف ساخته شد (Race-safe)."""
    r = session.execute(_insert(model).values(**vals).on_conflict_do_nothing(index_elements=list(index_elements)))
    return (r.rowcount or 0) == 1


def claim_once(session, uid, key, trigger="") -> bool:
    return insert_once(session, F.FrontierRewardClaim, ["user_id", "claim_key"], user_id=uid, claim_key=key,
                       trigger=trigger, hop=0.0, xp=0.0, created_at=utcnow())


def enabled(session) -> bool:
    return bool(ci(session, "frontier_enabled", 1)) and bool(ci(session, "war_enabled", 1))


def require_open(session, p):
    if not enabled(session):
        raise WarError("🌌 Frontier فعلاً خاموشه.")
    S.require_feature(session, p, "frontier")


def routes_cfg(session):
    return FE.parse_routes(cs(session, "frontier_routes", ""), F.ROUTES_DEFAULT)


def stealth_cats(session):
    return {x.strip() for x in cs(session, "frontier_stealth_cats", "air,special,missile").split(",") if x.strip()}


def region_of(session, key):
    return session.get(F.FrontierRegion, key)


def regions(session, enabled_only=True):
    q = session.query(F.FrontierRegion)
    if enabled_only:
        q = q.filter_by(enabled=True)
    return q.order_by(F.FrontierRegion.sort, F.FrontierRegion.key).all()


def nodes_in(session, region_key, enabled_only=True):
    q = session.query(F.FrontierNode).filter_by(region_key=region_key)
    if enabled_only:
        q = q.filter_by(enabled=True)
    return q.order_by(F.FrontierNode.sort, F.FrontierNode.key).all()


def boss_def_for_node(session, node_key):
    return session.query(F.FrontierBossDef).filter_by(node_key=node_key, enabled=True).first()


# ---------------------------------------------------------------------------
# ایونت‌ها (همه از دیتابیس؛ بدونِ State در RAM → ری‌استارت امنه)
# ---------------------------------------------------------------------------

def active_events(session, now=None):
    now = now or utcnow()
    return session.query(F.FrontierEvent).filter(F.FrontierEvent.enabled == True, F.FrontierEvent.start_at <= now,  # noqa: E712
                                                 F.FrontierEvent.end_at > now).order_by(F.FrontierEvent.id).all()


def event_mods(session, region_key="", now=None) -> dict:
    out = {"power": 1.0, "reward": 1.0, "xp": 1.0, "points": 1.0, "names": []}
    for e in active_events(session, now):
        if e.region_key and region_key and e.region_key != region_key:
            continue
        if e.kind in ("awakening", "treasure") and (e.power_mult, e.reward_mult, e.xp_mult, e.points_mult) == (1.0, 1.0, 1.0, 1.0):
            out["names"].append(e.name)
            continue
        out["power"] *= e.power_mult
        out["reward"] *= e.reward_mult
        out["xp"] *= e.xp_mult
        out["points"] *= e.points_mult
        out["names"].append(e.name)
    return out


def treasure_open_nodes(session, now=None) -> set:
    return {e.node_key for e in active_events(session, now) if e.kind == "treasure" and e.node_key}


def awakened_bosses(session, now=None):
    """[(event, bossdef)] برای ایونت‌های «بیداری»."""
    out = []
    for e in active_events(session, now):
        if e.kind == "awakening" and e.boss_key:
            b = session.get(F.FrontierBossDef, e.boss_key)
            if b and b.enabled:
                out.append((e, b))
    return out


# ---------------------------------------------------------------------------
# فصل
# ---------------------------------------------------------------------------

def current_season(session, now=None, create=True):
    now = now or utcnow()
    s = session.query(F.FrontierSeason).filter(F.FrontierSeason.status == "active",
                                               F.FrontierSeason.end_at > now).order_by(F.FrontierSeason.id.desc()).first()
    if s is None and create and enabled(session):
        s = start_season(session, None, now=now, name=None, settle_old=False)
    return s


def start_season(session, actor, now=None, name=None, days=None, settle_old=True, reason=""):
    now = now or utcnow()
    events = []
    if settle_old:
        for old in session.query(F.FrontierSeason).filter_by(status="active").all():
            events += settle_season(session, old, now, force=True)
    n = session.query(F.FrontierSeason).count() + 1
    days = days if days else cf(session, "frontier_season_days", 28)
    s = F.FrontierSeason(name=name or f"فصل {n}", start_at=now, end_at=now + datetime.timedelta(days=days),
                         status="active", settled=False, created_by=actor)
    session.add(s)
    session.flush()
    S.audit(session, actor, "frontier_season_start", season=s.id, days=days, reason=reason)
    return s


def extend_season(session, actor, season_id, days, reason=""):
    s = session.get(F.FrontierSeason, season_id)
    if not s or s.status != "active":
        raise WarError("فصلِ فعالی پیدا نشد.")
    s.end_at = s.end_at + datetime.timedelta(days=days)
    S.audit(session, actor, "frontier_season_extend", season=s.id, days=days, reason=reason)
    return s


def end_season(session, actor, season_id, reason=""):
    s = session.get(F.FrontierSeason, season_id)
    if not s or s.status != "active":
        raise WarError("فصلِ فعالی پیدا نشد.")
    S.audit(session, actor, "frontier_season_end", season=s.id, reason=reason)
    return settle_season(session, s, utcnow(), force=True)


# ---------------------------------------------------------------------------
# پرداخت (Reward Engine + سقفِ روزانه + کلیمِ یکتا)
# ---------------------------------------------------------------------------

def _day():
    return S._today()


def daily_row(session, uid):
    d = _day()
    r = session.query(F.FrontierDaily).filter_by(user_id=uid, day=d).first()
    if r is None:
        insert_once(session, F.FrontierDaily, ["user_id", "day"], user_id=uid, day=d, points=0.0, ref_hours=0.0, runs=0, boss_attacks=0)
        r = session.query(F.FrontierDaily).filter_by(user_id=uid, day=d).first()
    return r


def daily_cap_hours(session, p):
    return FE.daily_cap_hours(cf(session, "frontier_daily_cap_ref_hours", 5), cf(session, "frontier_daily_cap_th_bonus", 0.5), p.th_level)


def pay(session, p, trigger, scale=1.0, claim_key=None, capped=False, xp_mult=1.0, hop_mult=1.0, region_scale=1.0,
        mods=None, ref=None, battle_type=""):
    """
    تنها مسیرِ پاداشِ Frontier. claim_key → فقط یک‌بار (UniqueConstraint)؛ None = بدونِ کلیم (تکرارِ مجاز).
    capped → از سقفِ روزانه‌ی ساعتِ مرجع کم می‌شه؛ بعدش فقط XP کم‌رنگ می‌ده (فارمِ بی‌نهایت ممکن نیست).
    """
    uid = p.user_id
    if claim_key and not claim_once(session, uid, claim_key, trigger):
        return None
    mods = mods or {"reward": 1.0, "xp": 1.0}
    ref_h = S.player_ref(session, p)
    rule = session.get(W.WarRewardRule, trigger)
    base_h = (rule.hop_ref_hours if rule else 0.0) * scale * region_scale * mods.get("reward", 1.0) * hop_mult
    day = None
    if capped and ref_h > 0:
        day = daily_row(session, uid)
        remaining = max(0.0, daily_cap_hours(session, p) - day.ref_hours)
        if base_h > remaining:
            hop_mult = hop_mult * (remaining / base_h if base_h > 0 else 0.0)
            xp_mult *= 0.4 if remaining <= 0 else 1.0
    out = S.give_reward(session, uid, trigger, scale=scale * region_scale * 1.0, ref=ref or claim_key, farm_mult=1.0,
                        xp_mult=xp_mult * mods.get("xp", 1.0), hop_mult=hop_mult * mods.get("reward", 1.0), _player=p,
                        battle_type=battle_type)
    if capped and day is not None and ref_h > 0:
        day.ref_hours = (day.ref_hours or 0.0) + out["hop"] / ref_h
    if claim_key:
        c = session.query(F.FrontierRewardClaim).filter_by(user_id=uid, claim_key=claim_key).first()
        if c:
            c.hop, c.xp = out["hop"], out["xp"]
    return out


# ---------------------------------------------------------------------------
# پیشرفت / کشف / سرنخ
# ---------------------------------------------------------------------------

def progress_map(session, uid) -> dict:
    return {r.node_key: r for r in session.query(F.FrontierProgress).filter_by(user_id=uid).all()}


def _prog(session, uid, node_key):
    r = session.query(F.FrontierProgress).filter_by(user_id=uid, node_key=node_key).first()
    if r is None:
        insert_once(session, F.FrontierProgress, ["user_id", "node_key"], user_id=uid, node_key=node_key,
                    clears=0, fails=0, best_stars=0)
        r = session.query(F.FrontierProgress).filter_by(user_id=uid, node_key=node_key).first()
    return r


def personal_points(session, uid, region_key) -> int:
    r = session.query(F.FrontierProgress).filter_by(user_id=uid, node_key=f"_pts:{region_key}").first()
    return int(r.clears) if r else 0


def _add_personal_points(session, uid, region_key, pts):
    r = _prog(session, uid, f"_pts:{region_key}")
    r.clears = (r.clears or 0) + int(round(pts))


def discovered(session, uid, kind, region_key=None) -> list:
    q = session.query(F.FrontierDiscovery).filter_by(user_id=uid, kind=kind)
    if region_key:
        q = q.filter_by(region_key=region_key)
    return q.all()


def has_room(session, uid, node_key) -> bool:
    return session.query(F.FrontierDiscovery.id).filter_by(user_id=uid, key=f"room:{node_key}").first() is not None


def clue_count(session, uid, region_key) -> int:
    return session.query(func.count(F.FrontierDiscovery.id)).filter_by(user_id=uid, kind="clue", region_key=region_key).scalar() or 0


def add_clue(session, uid, region_key) -> bool:
    n = clue_count(session, uid, region_key)
    for i in range(1, 4):
        if insert_once(session, F.FrontierDiscovery, ["user_id", "key"], user_id=uid, key=f"clue:{region_key}:{n + i}",
                       kind="clue", region_key=region_key, at=utcnow()):
            return True
    return False


def _bump_discovery_score(session, p, season):
    if season is None:
        return
    row = _contrib(session, season.id, p.user_id, p.clan_id or 0)
    row.discoveries = (row.discoveries or 0) + 1


def _contrib(session, season_id, uid, clan_id):
    r = session.query(F.FrontierContribution).filter_by(season_id=season_id, user_id=uid, clan_id=clan_id).first()
    if r is None:
        insert_once(session, F.FrontierContribution, ["season_id", "user_id", "clan_id"], season_id=season_id, user_id=uid,
                    clan_id=clan_id, points=0.0, runs=0, boss_damage=0.0, discoveries=0)
        r = session.query(F.FrontierContribution).filter_by(season_id=season_id, user_id=uid, clan_id=clan_id).first()
    return r


# ---------------------------------------------------------------------------
# بازشدنِ مناطق / مراحل
# ---------------------------------------------------------------------------

def _boss_node_of_region(session, region_key):
    return session.query(F.FrontierNode).filter_by(region_key=region_key, kind="boss", enabled=True).first()


def clan_region_row(session, clan_id, region_key, create=False):
    r = session.query(F.FrontierClanRegion).filter_by(clan_id=clan_id, region_key=region_key).first()
    if r is None and create:
        insert_once(session, F.FrontierClanRegion, ["clan_id", "region_key"], clan_id=clan_id, region_key=region_key, points=0.0, boss_down=False)
        r = session.query(F.FrontierClanRegion).filter_by(clan_id=clan_id, region_key=region_key).first()
    return r


def clan_participants(session, clan_id, region_key) -> int:
    """تعدادِ اعضای فعلیِ قبیله که حداقل یک مرحله از این منطقه رو کلیر کردن."""
    keys = [n.key for n in nodes_in(session, region_key, enabled_only=False)]
    if not keys:
        return 0
    uids = [m.user_id for m in session.query(W.WarClanMember).filter_by(clan_id=clan_id).all()]
    if not uids:
        return 0
    return session.query(func.count(func.distinct(F.FrontierProgress.user_id))).filter(
        F.FrontierProgress.user_id.in_(uids), F.FrontierProgress.node_key.in_(keys), F.FrontierProgress.clears >= 1).scalar() or 0


def region_requirements(session, p, region) -> dict:
    """
    شرطِ بازشدنِ منطقه (نمایش + اجرا). دو مسیر: شخصی (برای بازیکنِ بدونِ قبیله) یا گروهی (قبیله).
    برمی‌گردونه: {'open': bool, 'base': [(متن, ok)], 'personal': [...], 'clan': [...], 'via': 'personal'|'clan'|None}
    """
    lvl = S.player_level(session, p)
    base = []
    if region.req_level:
        base.append((f"سطحِ جنگ {region.req_level}", lvl >= region.req_level))
    if region.req_th:
        base.append((f"مقرِ سطح {region.req_th}", p.th_level >= region.req_th))
    base_ok = all(ok for _t, ok in base)
    personal, clan_l = [], []
    pers_ok = clan_ok = True
    prev = session.get(F.FrontierRegion, region.prev_region) if region.prev_region else None
    if prev is not None:
        pn = _boss_node_of_region(session, prev.key)
        if region.req_prev_boss and pn:
            done = (session.query(F.FrontierProgress).filter(F.FrontierProgress.user_id == p.user_id,
                                                             F.FrontierProgress.node_key == pn.key,
                                                             F.FrontierProgress.clears >= 1).first() is not None)
            personal.append((f"شکستِ «{pn.name}»", done))
            pers_ok = pers_ok and done
        if region.req_personal_points:
            pp = personal_points(session, p.user_id, prev.key)
            ok = pp >= region.req_personal_points
            personal.append((f"{region.req_personal_points} امتیازِ فتحِ شخصی در {prev.name} ({pp})", ok))
            pers_ok = pers_ok and ok
        if p.clan_id:
            cr = clan_region_row(session, p.clan_id, prev.key)
            if region.req_prev_boss and pn:
                ok = bool(cr and cr.boss_down)
                clan_l.append((f"قبیله «{pn.name}» رو شکست داده باشه", ok))
                clan_ok = clan_ok and ok
            if region.req_clan_points:
                cp = int(cr.points) if cr else 0
                ok = cp >= region.req_clan_points
                clan_l.append((f"{region.req_clan_points} امتیازِ پیشرویِ گروهی ({cp})", ok))
                clan_ok = clan_ok and ok
            if region.req_clan_participants:
                n = clan_participants(session, p.clan_id, prev.key)
                ok = n >= region.req_clan_participants
                clan_l.append((f"{region.req_clan_participants} عضوِ فعالِ قبیله در اکتشاف ({n})", ok))
                clan_ok = clan_ok and ok
        else:
            clan_ok = False
    via = None
    if base_ok and (prev is None or pers_ok or (p.clan_id and clan_ok)):
        via = "base" if prev is None else ("personal" if pers_ok else "clan")
    return {"open": via is not None, "base": base, "personal": personal, "clan": clan_l, "via": via,
            "personal_ok": pers_ok, "clan_ok": bool(p.clan_id and clan_ok)}


def node_state(session, p, node, prog, rooms: set, region_open: bool, treasure: set, lvl=None) -> tuple:
    """(state, missing_text). state: hidden / locked / open / cleared"""
    lvl = lvl if lvl is not None else S.player_level(session, p)
    pr = prog.get(node.key)
    cleared = bool(pr and pr.clears >= 1)
    if node.hidden and node.key not in rooms and node.key not in treasure and not cleared:
        return "hidden", ""
    if cleared:
        return "cleared", ""
    miss = []
    if not region_open:
        miss.append("منطقه هنوز قفله")
    if lvl < node.req_level:
        miss.append(f"سطحِ جنگ {node.req_level}")
    if p.th_level < node.req_th:
        miss.append(f"مقرِ سطح {node.req_th}")
    for rk in [x for x in (node.requires or "").split(",") if x]:
        if not (prog.get(rk) and prog[rk].clears >= 1):
            rn = session.get(F.FrontierNode, rk)
            miss.append(f"کلیرِ «{rn.name if rn else rk}»")
    if node.hidden and node.key in treasure and node.key not in rooms:
        miss = [m for m in miss if m != "منطقه هنوز قفله"] if region_open else miss
    return ("open" if not miss else "locked"), "، ".join(miss)


def region_view(session, p, region):
    """همه‌ی اطلاعاتِ یک منطقه برای UI در یک بسته (Query سبک: یک‌بار progress/rooms)."""
    prog = progress_map(session, p.user_id)
    rooms = {d.key[5:] for d in discovered(session, p.user_id, "room")}
    req = region_requirements(session, p, region)
    treasure = treasure_open_nodes(session)
    lvl = S.player_level(session, p)
    out = []
    for n in nodes_in(session, region.key):
        st, miss = node_state(session, p, n, prog, rooms, req["open"], treasure, lvl)
        out.append({"node": n, "state": st, "missing": miss, "prog": prog.get(n.key)})
    visible = [x for x in out if x["state"] != "hidden"]
    done = sum(1 for x in out if x["state"] == "cleared")
    total = len(out)
    return {"region": region, "req": req, "nodes": visible, "all": out, "done": done, "total": total,
            "pct": int(100 * done / total) if total else 0}


def region_main_complete(session, uid, region_key) -> bool:
    prog = progress_map(session, uid)
    mains = [n for n in nodes_in(session, region_key) if n.kind in ("scout", "operation", "elite", "boss")]
    return bool(mains) and all(prog.get(n.key) and prog[n.key].clears >= 1 for n in mains)


def map_view(session, p):
    rows = []
    for r in regions(session):
        req = region_requirements(session, p, r)
        rv = region_view(session, p, r) if req["open"] else None
        rows.append({"region": r, "req": req, "view": rv, "complete": region_main_complete(session, p.user_id, r.key) if req["open"] else False})
    return rows


# ---------------------------------------------------------------------------
# ارتش / پیش‌نمایش
# ---------------------------------------------------------------------------

MODE_CATS = {"all": None, "air": {"air", "missile"}, "ground": {"ground", "armor", "naval", "special", "support"}}


def preset_comp(session, uid, pct=100, include_damaged=False, mode="all") -> dict:
    """ترکیبِ پیش‌فرضِ اعزام: pct٪ از نیروهای سالم؛ mode = all / air (هوایی+موشکی) / ground (زمینی/زره/دریایی)."""
    base = B.default_composition(session, uid, "all" if not include_damaged else "wounded")
    cats = MODE_CATS.get(mode)
    if cats is not None:
        defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
        base = {k: n for k, n in base.items() if k in defs and defs[k].category in cats}
    out = {}
    for k, n in base.items():
        m = int(math.floor(n * pct / 100.0))
        if m > 0:
            out[k] = m
    return out


def _fx_for(session, route, army, defs):
    rc = routes_cfg(session)[route]
    st = FE.stealth_factor(army, defs, stealth_cats(session))
    return FE.route_effects(rc, st, cf(session, "frontier_clue_stealth_bonus_pct", 25)), st


def estimate(session, p, comp, node, route, mods=None, extra_atk=1.0):
    """نسبتِ قدرتِ مهاجم/دشمن (بدونِ نویز) — فقط برای برچسبِ ریسک؛ عددِ دشمن لو نمی‌ره."""
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    army = B.materialize(session, p.user_id, comp)
    if not army:
        return 0.0
    fx, _st = _fx_for(session, route, army, defs)
    params, _v = S.formula_params(session)
    units = B.engine_units(session, p.user_id, army)
    mods = mods or event_mods(session, node.region_key)
    structs = FE.enemy_structures(node.power, node.ground_pct, node.air_pct, mods["power"], fx["def_mult"])
    A, by_cat, _sup = E.attack_side(units, params, p.readiness, fx["atk"] * extra_atk, 1.0)
    D, P = E.defense_side(structs, [], params, 100.0, node.wall, 1.0)
    M = E.counter_multiplier(by_cat, P, params)
    return (A * M / D) if D > 0 else 9.9


# ---------------------------------------------------------------------------
# باف‌ها (لجستیک)
# ---------------------------------------------------------------------------

def add_buff(session, scope, scope_id, kind, pct, charges, hours, source=None):
    now = utcnow()
    mx = cf(session, "frontier_logi_buff_max_pct", 30)
    row = session.query(F.FrontierBuff).filter(F.FrontierBuff.scope == scope, F.FrontierBuff.scope_id == scope_id,
                                               F.FrontierBuff.kind == kind, F.FrontierBuff.expires_at > now,
                                               F.FrontierBuff.charges > 0).first()
    if row:
        row.pct = min(mx, row.pct + pct)
        row.charges = min(10, row.charges + charges)
        row.expires_at = now + datetime.timedelta(hours=hours)
    else:
        row = F.FrontierBuff(scope=scope, scope_id=scope_id, kind=kind, pct=min(mx, pct), charges=charges,
                             expires_at=now + datetime.timedelta(hours=hours), source_user=source)
        session.add(row)
    return row


def active_buffs(session, uid, clan_id, now=None):
    now = now or utcnow()
    q = session.query(F.FrontierBuff).filter(F.FrontierBuff.expires_at > now, F.FrontierBuff.charges > 0)
    conds = [and_(F.FrontierBuff.scope == "user", F.FrontierBuff.scope_id == uid)]
    if clan_id:
        conds.append(and_(F.FrontierBuff.scope == "clan", F.FrontierBuff.scope_id == clan_id))
    from sqlalchemy import or_
    return q.filter(or_(*conds)).all()


def consume_buffs(session, uid, clan_id, now=None):
    """باف‌های فعال رو (حداکثر ۱ شارژ از هر ردیف) مصرف می‌کنه و {'atk':pct,'loot':pct} برمی‌گردونه."""
    mx = cf(session, "frontier_logi_buff_max_pct", 30)
    tot = {"atk": 0.0, "loot": 0.0}
    for b in active_buffs(session, uid, clan_id, now):
        tot[b.kind] = tot.get(b.kind, 0.0) + b.pct
        b.charges -= 1
    return {k: min(mx, v) for k, v in tot.items()}


# ---------------------------------------------------------------------------
# اعزام
# ---------------------------------------------------------------------------

def max_runs(session, p) -> int:
    return ci(session, "frontier_max_runs", 2) + max(0, p.th_level - 1) // 4


def active_runs(session, uid):
    return session.query(F.FrontierRun).filter(F.FrontierRun.user_id == uid, F.FrontierRun.status.in_(("marching", "resolving"))) \
        .order_by(F.FrontierRun.resolve_at).all()


def _take_units(session, uid, army):
    have = S.units_of(session, uid)
    for k, v in army.items():
        have[k].healthy -= v["h"]
        have[k].damaged -= v["d"]
        v["lv"] = have[k].level


def _return_units(session, uid, army, results=None):
    """نیروها رو برمی‌گردونه. results = خروجیِ تلفات (h/d/x) یا None = بدونِ تلفات."""
    have = S.units_of(session, uid)
    for k, v in army.items():
        if k.startswith("_"):
            continue
        u = have.get(k)
        if u is None:
            u = W.WarUnit(user_id=uid, unit_key=k, healthy=0, damaged=0, level=v.get("lv", 1))
            session.add(u)
            have[k] = u
        if results is not None and k in results:
            r = results[k]
            u.healthy += r["h"]
            u.damaged += r["d"]
            u.destroyed_total += r["x"]
        else:
            u.healthy += v["h"]
            u.damaged += v["d"]


def _check_run_common(session, p, node_key_for_limit=None):
    if len(active_runs(session, p.user_id)) >= max_runs(session, p):
        raise WarError(f"عملیاتِ هم‌زمانت پره ({max_runs(session, p)} تا). صبر کن تا یکی تموم شه.")


def _pay_costs(session, p, node, route_fx, route):
    S.sync_player(session, p)
    if p.fuel < node.fuel - 1e-9:
        raise WarError(f"⛽ سوخت کافی نیست (نیاز: {node.fuel:g}).")
    mat_cost = node.cost_mat
    if route == "logistics":
        mat_cost = max(node.cost_mat, 10.0) * max(1.0, route_fx["mat"])
    if mat_cost > p.vault_mat + 1e-9:
        raise WarError(f"🔩 مواد کافی نیست (نیاز: {mat_cost:,.0f}).")
    cost = round(node.cost_ref_hours * S.player_ref(session, p), -1)
    if cost > 0:
        S.hop_apply(session, session.get(db.User, p.user_id), -cost, "SPEND", f"war:fr:{node.key}", ref=f"fr:{p.user_id}:{node.key}")
    p.fuel -= node.fuel
    p.vault_mat -= mat_cost
    return cost, mat_cost


def _army_for(session, p, comp, route):
    army = B.materialize(session, p.user_id, comp)
    if not army:
        raise WarError("هیچ نیرویی برای اعزام انتخاب نشده.")
    attackers = [k for k in army if any(u.atk > 0 for u in B.engine_units(session, p.user_id, {k: army[k]}))]
    if route != "logistics" and not attackers:
        raise WarError("حداقل یک واحدِ تهاجمی لازمه.")
    return army


def launch_run(session, p, node_key, route, comp, chat_id=None, now=None):
    """اعزامِ عادی (scout/operation/elite/secret). برای باس launch_boss."""
    now = now or utcnow()
    require_open(session, p)
    node = session.get(F.FrontierNode, node_key)
    if not node or not node.enabled:
        raise WarError("این مرحله وجود نداره.")
    if node.kind == "boss":
        raise WarError("برای نگهبان از پنلِ باس حمله کن.")
    if route not in FE.ROUTE_KEYS or route not in (node.routes or "").split(","):
        raise WarError("این مسیر برای این مرحله مجاز نیست.")
    region = session.get(F.FrontierRegion, node.region_key)
    if not region or not region.enabled:
        raise WarError("این منطقه غیرفعاله.")
    _check_run_common(session, p)
    S.sync_player(session, p, now)
    view_prog = progress_map(session, p.user_id)
    rooms = {d.key[5:] for d in discovered(session, p.user_id, "room")}
    req = region_requirements(session, p, region)
    st, miss = node_state(session, p, node, view_prog, rooms, req["open"], treasure_open_nodes(session, now))
    if st == "hidden":
        raise WarError("🔒 این مرحله هنوز کشف نشده.")
    if st == "locked":
        raise WarError(f"🔒 شرط‌ها کامل نیست: {miss}")
    if session.query(F.FrontierRun).filter(F.FrontierRun.user_id == p.user_id, F.FrontierRun.node_key == node_key,
                                           F.FrontierRun.status == "marching").first():
        raise WarError("یه عملیاتِ در حالِ انجام روی این مرحله داری.")
    army = _army_for(session, p, comp, route)
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    fx, stealth = _fx_for(session, route, army, defs)
    cost, mat = _pay_costs(session, p, node, fx, route)
    _take_units(session, p.user_id, army)
    buffs = consume_buffs(session, p.user_id, p.clan_id, now)
    mods = event_mods(session, node.region_key, now)
    army["_ready"] = round(p.readiness, 2)
    dur = random.randint(int(node.min_seconds), int(max(node.min_seconds, node.max_seconds))) * fx["dur"]
    season = current_season(session, now)
    modifiers = {"stealth": stealth, "atk_extra": 1.0 + buffs["atk"] / 100.0, "loot_extra": 1.0 + buffs["loot"] / 100.0,
                 "event": {"power": mods["power"], "reward": mods["reward"], "xp": mods["xp"], "points": mods["points"]},
                 "cost": cost, "mat": mat, "fuel": node.fuel, "kind": node.kind}
    run = F.FrontierRun(user_id=p.user_id, node_key=node_key, route=route, clan_id=p.clan_id, season_id=season.id if season else 0,
                        seed=random.randrange(1, 2 ** 62), created_at=now, resolve_at=now + datetime.timedelta(seconds=dur),
                        army_json=json.dumps(army), modifiers_json=json.dumps(modifiers), chat_id=chat_id,
                        formula_version=ci(session, "war_formula_version", 1))
    session.add(run)
    session.flush()
    S.audit(session, p.user_id, "frontier_launch", run=run.id, node=node_key, route=route, cost=cost, mat=mat)
    return run, cost


# ---------------------------------------------------------------------------
# باس
# ---------------------------------------------------------------------------

def boss_scope(p):
    return ("clan", p.clan_id) if p.clan_id else ("user", p.user_id)


def boss_hp_for(session, bdef, scope):
    hp = bdef.hp * (bdef.solo_hp_mult if scope == "user" else 1.0)
    return max(1.0, float(hp))


def get_boss_state(session, bdef, p, event_id=0, create=True):
    scope, sid = boss_scope(p)
    st = session.query(F.FrontierBossState).filter_by(boss_key=bdef.key, scope=scope, scope_id=sid, event_id=event_id).first()
    if st is None and create:
        hp = boss_hp_for(session, bdef, scope)
        insert_once(session, F.FrontierBossState, ["boss_key", "scope", "scope_id", "event_id"], boss_key=bdef.key, scope=scope,
                    scope_id=sid, event_id=event_id, hp_max=hp, hp=hp, status="active", created_at=utcnow(), paid=False)
        st = session.query(F.FrontierBossState).filter_by(boss_key=bdef.key, scope=scope, scope_id=sid, event_id=event_id).first()
    return st


def boss_phases(bdef):
    try:
        return json.loads(bdef.phases_json or "[]")
    except ValueError:
        return []


def boss_resist(bdef):
    try:
        return json.loads(bdef.resist_json or "{}")
    except ValueError:
        return {}


def boss_top(session, state_id, limit=5):
    rows = session.query(F.FrontierBossAttack.user_id, func.sum(F.FrontierBossAttack.damage), func.count(F.FrontierBossAttack.id)) \
        .filter(F.FrontierBossAttack.state_id == state_id).group_by(F.FrontierBossAttack.user_id) \
        .order_by(func.sum(F.FrontierBossAttack.damage).desc()).limit(limit).all()
    return [(u, float(d or 0), int(c or 0)) for u, d, c in rows]


def launch_boss(session, p, boss_key, route, comp, event_id=0, chat_id=None, now=None):
    now = now or utcnow()
    require_open(session, p)
    bdef = session.get(F.FrontierBossDef, boss_key)
    if not bdef or not bdef.enabled:
        raise WarError("این باس وجود نداره.")
    if route not in FE.ROUTE_KEYS:
        raise WarError("مسیرِ نامعتبر.")
    if bdef.is_event or event_id:
        ev = session.get(F.FrontierEvent, event_id) if event_id else None
        if not ev or ev.kind != "awakening" or ev.boss_key != boss_key or not (ev.enabled and ev.start_at <= now < ev.end_at):
            raise WarError("این رویداد تموم شده.")
        node_ref = f"event:{boss_key}"
        node_obj = F.FrontierNode(key=node_ref, region_key=bdef.region_key, kind="boss", name=bdef.name, power=bdef.defense,
                                  fuel=2.0, cost_ref_hours=0.12, cost_mat=25, readiness_loss=14, points=bdef.participation_points,
                                  min_seconds=600, max_seconds=900)
    else:
        node_obj = session.get(F.FrontierNode, bdef.node_key)
        if not node_obj or not node_obj.enabled:
            raise WarError("نگهبانِ این منطقه غیرفعاله.")
        region = session.get(F.FrontierRegion, node_obj.region_key)
        req = region_requirements(session, p, region)
        if not req["open"]:
            raise WarError("🔒 این منطقه هنوز برات باز نشده.")
        prog = progress_map(session, p.user_id)
        _, miss = node_state(session, p, node_obj, prog, set(), True, set())
        if miss:
            raise WarError(f"🔒 برای نبرد با نگهبان: {miss}")
        node_ref = node_obj.key
    _check_run_common(session, p)
    S.sync_player(session, p, now)
    state = get_boss_state(session, bdef, p, event_id=event_id if bdef.is_event or event_id else 0)
    if state.status != "active":
        raise WarError("🏁 این باس قبلاً شکست خورده.")
    day = daily_row(session, p.user_id)
    if (day.boss_attacks or 0) >= ci(session, "frontier_boss_attacks_daily", 8):
        raise WarError("سقفِ حمله‌ی روزانه به باس پر شده؛ فردا برگرد.")
    if session.query(F.FrontierRun).filter(F.FrontierRun.user_id == p.user_id, F.FrontierRun.node_key == node_ref,
                                           F.FrontierRun.status == "marching").first():
        raise WarError("یه حمله‌ی در حالِ انجام روی این باس داری.")
    army = _army_for(session, p, comp, route)
    defs = {d.key: d for d in S.udefs(session, enabled_only=False)}
    fx, stealth = _fx_for(session, route, army, defs)
    cost, mat = _pay_costs(session, p, node_obj, fx, route)
    _take_units(session, p.user_id, army)
    buffs = consume_buffs(session, p.user_id, p.clan_id, now)
    mods = event_mods(session, bdef.region_key, now)
    army["_ready"] = round(p.readiness, 2)
    dur = random.randint(int(node_obj.min_seconds), int(max(node_obj.min_seconds, node_obj.max_seconds))) * fx["dur"]
    season = current_season(session, now)
    modifiers = {"stealth": stealth, "atk_extra": 1.0 + buffs["atk"] / 100.0, "loot_extra": 1.0 + buffs["loot"] / 100.0,
                 "event": {"power": mods["power"], "reward": mods["reward"], "xp": mods["xp"], "points": mods["points"]},
                 "cost": cost, "mat": mat, "fuel": node_obj.fuel, "kind": "boss", "boss": boss_key, "event_id": event_id}
    run = F.FrontierRun(user_id=p.user_id, node_key=node_ref, route=route, boss_state_id=state.id, clan_id=p.clan_id,
                        season_id=season.id if season else 0, seed=random.randrange(1, 2 ** 62), created_at=now,
                        resolve_at=now + datetime.timedelta(seconds=dur), army_json=json.dumps(army),
                        modifiers_json=json.dumps(modifiers), chat_id=chat_id, formula_version=ci(session, "war_formula_version", 1))
    session.add(run)
    day.boss_attacks = (day.boss_attacks or 0) + 1
    session.flush()
    S.audit(session, p.user_id, "frontier_boss_launch", run=run.id, boss=boss_key, route=route, state=state.id)
    return run, cost


# ---------------------------------------------------------------------------
# لغو / انقضا
# ---------------------------------------------------------------------------

def cancel_run(session, run_id, reason="cancelled", refund_pct=100.0, actor=None):
    n = session.query(F.FrontierRun).filter(F.FrontierRun.id == run_id, F.FrontierRun.status == "marching").update(
        {"status": "cancelled", "resolved_at": utcnow(), "outcome": "void"}, synchronize_session=False)
    if n != 1:
        return False
    run = session.get(F.FrontierRun, run_id)
    session.refresh(run)
    army = json.loads(run.army_json or "{}")
    _return_units(session, run.user_id, army)
    mods = json.loads(run.modifiers_json or "{}")
    p = S.get_player(session, run.user_id)
    f = max(0.0, min(100.0, refund_pct)) / 100.0
    fuel_max = cf(session, "war_fuel_max", 10)
    p.fuel = min(fuel_max, p.fuel + mods.get("fuel", 0) * f)
    p.vault_mat += mods.get("mat", 0) * f
    cost = mods.get("cost", 0) * f
    if cost > 0:
        S.hop_apply(session, session.get(db.User, run.user_id), cost, "REFUND", f"war:fr:{reason}", ref=f"frrun:{run.id}")
    if run.boss_state_id:
        d = session.query(F.FrontierDaily).filter_by(user_id=run.user_id, day=run.created_at.strftime("%Y-%m-%d")).first()
        if d and d.boss_attacks:
            d.boss_attacks -= 1
    S.audit(session, actor, "frontier_run_cancel", run=run_id, reason=reason, refund=refund_pct)
    return True


def player_cancel(session, p, run_id):
    """لغوِ عملیات توسطِ بازیکن: نیروها ۱۰۰٪ برمی‌گردن؛ هزینه/سوخت/مواد فقط ٪ تنظیم‌شده (ضدِ سوءاستفاده از «شروعِ آزمایشی»)."""
    run = session.get(F.FrontierRun, run_id)
    if not run or run.user_id != p.user_id:
        raise WarError("عملیات پیدا نشد.")
    if run.status != "marching":
        raise WarError("این عملیات دیگه قابل‌لغو نیست.")
    if not cancel_run(session, run_id, "player", cf(session, "frontier_cancel_refund_pct", 50), actor=p.user_id):
        raise WarError("این عملیات دیگه قابل‌لغو نیست.")
    return True


def expire_stuck(session, now):
    hrs = cf(session, "frontier_run_expire_hours", 24)
    n = 0
    for r in session.query(F.FrontierRun).filter(F.FrontierRun.status == "marching",
                                                 F.FrontierRun.resolve_at < now - datetime.timedelta(hours=hrs)).all():
        if cancel_run(session, r.id, "expired", cf(session, "frontier_expire_refund_pct", 50)):
            n += 1
    return n


# ---------------------------------------------------------------------------
# امتیازِ فتح (غیرقابل‌انتقال، سقف‌دار، بازده‌ی نزولی)
# ---------------------------------------------------------------------------

def add_points(session, p, season, region_key, pts) -> float:
    day = daily_row(session, p.user_id)
    got = FE.capped_points(day.points or 0.0, pts, cf(session, "frontier_member_daily_point_cap", 600),
                           cf(session, "frontier_point_soft_ratio", 0.7), cf(session, "frontier_point_soft_mult", 0.5))
    if got <= 0:
        return 0.0
    day.points = (day.points or 0.0) + got
    if season is not None:
        c = _contrib(session, season.id, p.user_id, p.clan_id or 0)
        c.points = (c.points or 0.0) + got
    if p.clan_id:
        cr = clan_region_row(session, p.clan_id, region_key, create=True)
        cr.points = (cr.points or 0.0) + got
    _add_personal_points(session, p.user_id, region_key, got)
    return got


# ---------------------------------------------------------------------------
# افتخارات
# ---------------------------------------------------------------------------

def honor_values(session, uid) -> dict:
    prog = progress_map(session, uid)
    v = {"clears": sum(r.clears for k, r in prog.items() if not k.startswith("_") and r.clears),
         "runs": int(S.metric_get(session, uid, "fr_runs")),
         "flawless": int(S.metric_get(session, uid, "fr_flawless")),
         "pillar": int(S.metric_get(session, uid, "fr_h_pillar")),
         "season_win": int(S.metric_get(session, uid, "fr_h_season_win")),
         "season_top3": int(S.metric_get(session, uid, "fr_h_season_top3"))}
    v["regions"] = session.query(func.count(F.FrontierRewardClaim.id)).filter(
        F.FrontierRewardClaim.user_id == uid, F.FrontierRewardClaim.claim_key.like("region:%")).scalar() or 0
    v["pioneer"] = session.query(func.count(F.FrontierRewardClaim.id)).filter(
        F.FrontierRewardClaim.user_id == uid, F.FrontierRewardClaim.claim_key.like("pioneer:%")).scalar() or 0
    v["rooms"] = session.query(func.count(F.FrontierDiscovery.id)).filter_by(user_id=uid, kind="room").scalar() or 0
    for n in session.query(F.FrontierNode).filter_by(kind="boss", enabled=True).all():
        v[f"boss:{n.region_key}"] = 1 if (prog.get(n.key) and prog[n.key].clears >= 1) else 0
    return v


def honors_of(session, uid):
    return [(h, session.get(F.FrontierHonorDef, h.key)) for h in session.query(F.FrontierHonor).filter_by(user_id=uid)
            .order_by(F.FrontierHonor.earned_at).all()]


def grant_honor(session, uid, key, season_id=0):
    hd = session.get(F.FrontierHonorDef, key)
    if not hd or not hd.enabled:
        return None
    if not insert_once(session, F.FrontierHonor, ["user_id", "key"], user_id=uid, key=key, earned_at=utcnow(), season_id=season_id):
        return None                                   # دستاوردِ تکراری صادر نمی‌شه
    p = S.get_player(session, uid)
    if hd.xp:
        S.add_xp(session, p, hd.xp)
    if hd.hop_ref_hours:
        amt = math.floor(hd.hop_ref_hours * S.player_ref(session, p))
        if amt > 0:
            S.hop_apply(session, session.get(db.User, uid), amt, "EVENT_REWARD", f"war:fr_honor:{key}", ref=f"honor:{uid}:{key}")
    S.audit(session, uid, "frontier_honor", key=key)
    return hd


def check_honors(session, uid, season_id=0) -> list:
    owned = {h.key for h in session.query(F.FrontierHonor).filter_by(user_id=uid).all()}
    vals = None
    out = []
    for hd in session.query(F.FrontierHonorDef).filter_by(enabled=True).order_by(F.FrontierHonorDef.sort).all():
        if hd.key in owned:
            continue
        if vals is None:
            vals = honor_values(session, uid)
        if vals.get(hd.metric, 0) >= max(1, hd.threshold):
            g = grant_honor(session, uid, hd.key, season_id)
            if g:
                out.append(g)
    return out


# ---------------------------------------------------------------------------
# سیگنال / اتاقِ مخفی
# ---------------------------------------------------------------------------

def signal_info(session, p, node) -> dict:
    """وضعیتِ سیگنالِ یک اتاقِ مخفی برای این بازیکن (برای UI)."""
    opts = [o for o in (node.reveal_options or "").split("|") if o]
    clues = clue_count(session, p.user_id, node.region_key)
    now = utcnow()
    found = has_room(session, p.user_id, node.key)
    cool = session.query(F.FrontierDiscovery).filter_by(user_id=p.user_id, key=f"signaltry:{node.key}").first()
    cd_left = 0.0
    if cool:
        cd_left = max(0.0, cf(session, "frontier_signal_retry_minutes", 30) * 60 - (now - cool.at).total_seconds())
    hint = None
    clan_hint = False
    if p.clan_id and node.reveal_clues:
        uids = [m.user_id for m in session.query(W.WarClanMember).filter_by(clan_id=p.clan_id).all()]
        if uids:
            per = session.query(F.FrontierDiscovery.user_id, func.count(F.FrontierDiscovery.id)).filter(
                F.FrontierDiscovery.kind == "clue", F.FrontierDiscovery.region_key == node.region_key,
                F.FrontierDiscovery.user_id.in_(uids)).group_by(F.FrontierDiscovery.user_id).all()
            clan_hint = sum(1 for _u, c in per if c >= node.reveal_clues) >= ci(session, "frontier_clan_hint_members", 2)
    if opts and (clues >= node.hint_clues or clan_hint):
        hint = FE.signal_hint(p.user_id, node.key, len(opts))
    return {"opts": opts, "clues": clues, "need": node.reveal_clues, "found": found, "ready": (not found and clues >= node.reveal_clues and bool(opts)),
            "cooldown": cd_left, "hint": hint, "clan_hint": clan_hint}


def pending_signals(session, p, region_key):
    """اتاق‌های مخفیِ این منطقه که سیگنالشون آماده‌ست (منطقه باید برای بازیکن باز باشه)."""
    out = []
    for n in nodes_in(session, region_key):
        if not n.hidden or not n.reveal_options:
            continue
        info = signal_info(session, p, n)
        if info["ready"]:
            out.append((n, info))
    return out


def answer_signal(session, p, node_key, choice: int):
    require_open(session, p)
    node = session.get(F.FrontierNode, node_key)
    if not node or not node.hidden:
        raise WarError("سیگنالی وجود نداره.")
    region = session.get(F.FrontierRegion, node.region_key)
    if not region_requirements(session, p, region)["open"]:
        raise WarError("🔒 این منطقه هنوز برات باز نشده.")
    info = signal_info(session, p, node)
    if info["found"]:
        raise WarError("این اتاق رو قبلاً کشف کردی.")
    if not info["ready"]:
        raise WarError(f"هنوز سرنخِ کافی نداری ({info['clues']}/{info['need']}).")
    if info["cooldown"] > 0:
        raise WarError(f"⏳ تیمِ شناسایی هنوز برنگشته؛ {int(info['cooldown'] // 60) + 1} دقیقه‌ی دیگه.")
    if not (0 <= choice < len(info["opts"])):
        raise WarError("گزینه‌ی نامعتبر.")
    now = utcnow()
    key = f"signaltry:{node_key}"
    row = session.query(F.FrontierDiscovery).filter_by(user_id=p.user_id, key=key).first()
    if row is None:
        insert_once(session, F.FrontierDiscovery, ["user_id", "key"], user_id=p.user_id, key=key, kind="signal",
                    region_key=node.region_key, at=now)
    else:
        row.at = now
    if choice != FE.signal_answer(p.user_id, node_key, len(info["opts"])):
        # تصمیمِ غلط = هزینه: یک سرنخ می‌سوزه (ولی هرگز زیرِ صفر)
        last = session.query(F.FrontierDiscovery).filter_by(user_id=p.user_id, kind="clue", region_key=node.region_key) \
            .order_by(F.FrontierDiscovery.id.desc()).first()
        if last:
            session.delete(last)
        S.audit(session, p.user_id, "frontier_signal_wrong", node=node_key)
        return {"ok": False, "text": "❌ تیمِ شناسایی دست‌خالی برگشت؛ یه سرنخ از دست رفت. دقیق‌تر فکر کن!"}
    if not insert_once(session, F.FrontierDiscovery, ["user_id", "key"], user_id=p.user_id, key=f"room:{node_key}", kind="room",
                       region_key=node.region_key, at=now):
        raise WarError("این اتاق رو قبلاً کشف کردی.")
    season = current_season(session, now)
    _bump_discovery_score(session, p, season)
    mods = event_mods(session, node.region_key, now)
    out = pay(session, p, "fr_room_found", scale=1.0, claim_key=f"room:{node_key}", region_scale=region.reward_scale, mods=mods)
    S.metric_bump(session, p.user_id, "fr_rooms", 1)
    check_honors(session, p.user_id, season.id if season else 0)
    S.audit(session, p.user_id, "frontier_room_found", node=node_key)
    return {"ok": True, "text": f"✅ {node.name} کشف شد!", "reward": out, "node": node}


# ---------------------------------------------------------------------------
# حل عملیات (Idempotent + Atomic)
# ---------------------------------------------------------------------------

def claim_run(session, run_id) -> bool:
    """اولین statement؛ فقط یک تراکنش برنده می‌شه (اگه Job دو بار اجرا شه، پاداشِ دوم نمی‌ره)."""
    n = session.query(F.FrontierRun).filter(F.FrontierRun.id == run_id, F.FrontierRun.status == "marching").update(
        {"status": "resolving"}, synchronize_session=False)
    return n == 1


_KIND_W = {"scout": 0.5, "operation": 1.0, "elite": 1.9, "secret": 2.5}


def _today_node_clears(session, uid, node_key, now):
    start = now.replace(hour=0, minute=0, second=0, microsecond=0)
    return session.query(func.count(F.FrontierRun.id)).filter(
        F.FrontierRun.user_id == uid, F.FrontierRun.node_key == node_key, F.FrontierRun.status == "resolved",
        F.FrontierRun.outcome == "win", F.FrontierRun.resolved_at >= start).scalar() or 0


def _grant_clue(session, p, region_key, fx, seed, notes):
    pct = fx["clue_pct"]
    if pct <= 0:
        return False
    pity_row = _prog(session, p.user_id, f"_pity:{region_key}")
    got = FE.clue_roll(seed, pct) or (pity_row.fails or 0) + 1 >= ci(session, "frontier_clue_pity", 3)
    if got and add_clue(session, p.user_id, region_key):
        pity_row.fails = 0
        notes.append("🔎 یه سرنخ از اتاقِ مخفی پیدا کردی!")
        return True
    pity_row.fails = (pity_row.fails or 0) + 1
    return False


def _after_clear(session, p, region_key, season, events, now):
    """تکمیلِ منطقه / مسیرِ مخفی؛ یک‌بار برای هر بازیکن (کلیم)."""
    region = session.get(F.FrontierRegion, region_key)
    if not region_main_complete(session, p.user_id, region_key):
        return
    if claim_once(session, p.user_id, f"region:{region_key}", "fr_region_done"):
        out = pay(session, p, "fr_region_done", scale=1.0, region_scale=region.reward_scale, mods=event_mods(session, region_key, now))
        c = session.query(F.FrontierRewardClaim).filter_by(user_id=p.user_id, claim_key=f"region:{region_key}").first()
        if c and out:
            c.hop, c.xp = out["hop"], out["xp"]
        S.metric_bump(session, p.user_id, "fr_regions", 1)
        events.append({"type": "fr_region_done", "user": p.user_id, "region": region_key})
    prog = progress_map(session, p.user_id)
    secret_cleared = any(n.hidden and prog.get(n.key) is not None and prog[n.key].clears >= 1 for n in nodes_in(session, region_key))
    if secret_cleared and claim_once(session, p.user_id, f"regionsecret:{region_key}", "fr_secret_path"):
        S.metric_bump(session, p.user_id, "fr_secret_regions", 1)


def resolve_run(session, run_id, now=None):
    """برمی‌گردونه لیستِ رویدادهای اعلان یا None اگه قبلاً پردازش شده. commit با فراخوان."""
    now = now or utcnow()
    if not claim_run(session, run_id):
        return None
    run = session.get(F.FrontierRun, run_id)
    session.refresh(run)
    p = S.get_player(session, run.user_id)
    S.sync_player(session, p, now)
    params, _v = S.formula_params(session, run.formula_version)
    army = json.loads(run.army_json or "{}")
    ready = army.pop("_ready", p.readiness)
    mods = json.loads(run.modifiers_json or "{}")
    ev_mods = mods.get("event", {})
    rc = routes_cfg(session)[run.route]
    fx = FE.route_effects(rc, mods.get("stealth", 0.0), cf(session, "frontier_clue_stealth_bonus_pct", 25))
    research = 1 + S.clan_bonus_pct(session, p.clan_id, "atk_pct") / 100.0
    events = []
    units = B.engine_units(session, run.user_id, army)
    season = session.get(F.FrontierSeason, run.season_id) if run.season_id else None
    result = {"kind": "boss" if run.boss_state_id else "node", "route": run.route, "notes": []}
    if run.boss_state_id:
        result = _resolve_boss(session, run, p, army, units, params, ready, fx, mods, ev_mods, research, season, now, events)
    else:
        result = _resolve_node(session, run, p, army, units, params, ready, fx, mods, ev_mods, research, season, now, events)
    day = daily_row(session, run.user_id)
    if result.get("outcome") != "void":
        day.runs = (day.runs or 0) + 1
        if season is not None:
            c = _contrib(session, season.id, p.user_id, run.clan_id or 0)
            c.runs = (c.runs or 0) + 1
        S.metric_bump(session, p.user_id, "fr_runs", 1)
    ch = check_honors(session, p.user_id, run.season_id or 0)
    result["honors"] = [h.key for h in ch]
    run.status, run.outcome, run.resolved_at = "resolved", result.get("outcome", "lose"), now
    run.result_json = json.dumps(result, ensure_ascii=False, default=str)
    S.audit(session, None, "frontier_run_resolved", run=run.id, outcome=run.outcome, node=run.node_key, route=run.route)
    events.insert(0, {"type": "fr_run", "run_id": run.id, "user": run.user_id, "chat_id": run.chat_id, "outcome": run.outcome})
    return events


def _resolve_node(session, run, p, army, units, params, ready, fx, mods, ev_mods, research, season, now, events):
    node = session.get(F.FrontierNode, run.node_key)
    region = session.get(F.FrontierRegion, node.region_key)
    rscale = region.reward_scale
    nd = {"power": node.power, "ground_pct": node.ground_pct, "air_pct": node.air_pct, "wall": node.wall}
    res = FE.run_node(run.seed, units, nd, params, ready, fx, event_power=ev_mods.get("power", 1.0),
                      atk_extra=mods.get("atk_extra", 1.0), research_atk=research)
    _return_units(session, run.user_id, army, res["atk_units"])
    p.readiness = max(0.0, p.readiness - node.readiness_loss * max(0.6, min(1.6, res["pressure"])))
    lost = sum(v["x"] for v in res["atk_units"].values())
    out = {"kind": "node", "route": run.route, "node": node.key, "stars": res["stars"], "destruction": res["destruction"],
           "ratio": res["ratio"], "lost": lost, "atk_units": res["atk_units"], "notes": [], "rewards": {}, "points": 0.0}
    rm = {"reward": ev_mods.get("reward", 1.0), "xp": ev_mods.get("xp", 1.0)}
    loot = mods.get("loot_extra", 1.0) * fx["rew"]
    dmg = int(round(res["attack_power"] * res["destruction"] / 100.0 * 10))
    S.metric_bump(session, p.user_id, "fr_damage", max(0, dmg))
    out["damage"] = dmg
    if run.route == "logistics":
        out["outcome"] = "support"
        r = pay(session, p, "fr_support", scale=_KIND_W.get(node.kind, 1.0), capped=True, region_scale=rscale, mods=rm, hop_mult=loot, ref=f"frrun:{run.id}")
        out["rewards"] = r or {}
        pct = cf(session, "frontier_logi_buff_pct", 8) + 2.0 * node.difficulty
        scope, sid = ("clan", p.clan_id) if p.clan_id else ("user", p.user_id)
        add_buff(session, scope, sid, "atk", pct, ci(session, "frontier_logi_buff_charges", 3),
                 cf(session, "frontier_logi_buff_hours", 12), p.user_id)
        out["buff"] = {"pct": pct, "scope": scope}
        out["notes"].append(f"📦 انبارِ پشتیبانی آماده شد: +{pct:g}٪ قدرتِ حمله برای {'عملیات‌های بعدیِ قبیله' if scope == 'clan' else 'عملیات‌های بعدیِ خودت'}.")
        gp = add_points(session, p, season, node.region_key, node.points * fx["pts"] * ev_mods.get("points", 1.0))
        out["points"] = gp
        S.metric_bump(session, p.user_id, "fr_support", 1)
        _grant_clue(session, p, node.region_key, fx, run.seed, out["notes"])
        if p.clan_id:
            C.clan_log(session, p.clan_id, f"📦 {B.name_of(session, p.user_id)} انبارِ پشتیبانیِ Frontier رو آماده کرد.")
        return out
    if res["outcome"] == "attacker":
        out["outcome"] = "win"
        pr = _prog(session, p.user_id, node.key)
        first = (pr.clears or 0) == 0
        n_today = _today_node_clears(session, p.user_id, node.key, now)
        pr.clears = (pr.clears or 0) + 1
        pr.best_stars = max(pr.best_stars or 0, res["stars"])
        pr.last_clear_at = now
        if first:
            pr.first_clear_at = now
            r = pay(session, p, node.reward_trigger, scale=1.0, claim_key=f"first:{node.key}", region_scale=rscale, mods=rm, hop_mult=loot)
            out["first_clear"] = True
        else:
            steps = FE.csv_floats(cs(session, "frontier_repeat_steps", "1,0.7,0.45,0.25,0.1"), [1.0])
            sc = cf(session, "frontier_repeat_mult", 0.35) * FE.repeat_mult(steps, n_today) * _KIND_W.get(node.kind, 1.0)
            r = pay(session, p, "fr_repeat", scale=sc, capped=True, region_scale=rscale, mods=rm, hop_mult=loot, ref=f"frrun:{run.id}")
            out["repeat_mult"] = round(sc, 3)
        out["rewards"] = r or {}
        pts = node.points * fx["pts"] * ev_mods.get("points", 1.0) * (0.9 + 0.1 * res["stars"]) * (1.5 if first else 1.0)
        out["points"] = add_points(session, p, season, node.region_key, pts)
        if node.kind == "scout":
            S.metric_bump(session, p.user_id, "fr_scouts", 1)
        _grant_clue(session, p, node.region_key, fx, run.seed, out["notes"])
        if first:
            _after_clear(session, p, node.region_key, season, events, now)
    else:
        out["outcome"] = "lose"
        pr = _prog(session, p.user_id, node.key)
        pr.fails = (pr.fails or 0) + 1
        r = pay(session, p, "fr_fail", scale=cf(session, "frontier_fail_mult", 0.25) * 4, capped=True, region_scale=rscale, mods=rm,
                ref=f"frrun:{run.id}")
        out["rewards"] = r or {}
        out["notes"].append("💥 عملیات شکست خورد؛ با نیروی بیشتر یا مسیرِ دیگه برگرد.")
    return out


def _void_boss(session, run, p, army, mods, reason):
    _return_units(session, run.user_id, army)
    fuel_max = cf(session, "war_fuel_max", 10)
    p.fuel = min(fuel_max, p.fuel + mods.get("fuel", 0))
    p.vault_mat += mods.get("mat", 0)
    if mods.get("cost", 0) > 0:
        S.hop_apply(session, session.get(db.User, run.user_id), mods["cost"], "REFUND", "war:fr:void", ref=f"frrun:{run.id}")
    d = session.query(F.FrontierDaily).filter_by(user_id=run.user_id, day=run.created_at.strftime("%Y-%m-%d")).first()
    if d and d.boss_attacks:
        d.boss_attacks -= 1
    return {"kind": "boss", "outcome": "void", "route": run.route, "notes": [reason], "rewards": {}, "points": 0.0, "damage": 0}


def _resolve_boss(session, run, p, army, units, params, ready, fx, mods, ev_mods, research, season, now, events):
    state = session.query(F.FrontierBossState).filter_by(id=run.boss_state_id).with_for_update().first()
    bdef = session.get(F.FrontierBossDef, state.boss_key) if state else None
    valid = bool(state and bdef and state.status == "active")
    if valid and state.scope == "clan" and p.clan_id != state.scope_id:
        valid = False
    if valid and state.scope == "user" and state.scope_id != p.user_id:
        valid = False
    if not valid:
        return _void_boss(session, run, p, army, mods, "🏁 باس دیگه در دسترس نبود یا دیگه عضوِ اون قبیله نیستی؛ نیروها و هزینه‌ها برگشتن.")
    region = session.get(F.FrontierRegion, bdef.region_key)
    rscale = region.reward_scale
    rm = {"reward": ev_mods.get("reward", 1.0), "xp": ev_mods.get("xp", 1.0)}
    loot = mods.get("loot_extra", 1.0) * fx["rew"]
    out = {"kind": "boss", "route": run.route, "boss": bdef.key, "state": state.id, "notes": [], "rewards": {}, "points": 0.0}
    node_pts = bdef.participation_points
    if run.route == "logistics":
        _return_units(session, run.user_id, army)
        out["outcome"] = "support"
        out["damage"] = 0
        r = pay(session, p, "fr_support", scale=1.0, capped=True, region_scale=rscale, mods=rm, hop_mult=loot, ref=f"frrun:{run.id}")
        out["rewards"] = r or {}
        pct = cf(session, "frontier_logi_buff_pct", 8) + 2.0 * bdef.difficulty
        scope, sid = ("clan", p.clan_id) if p.clan_id else ("user", p.user_id)
        add_buff(session, scope, sid, "atk", pct, ci(session, "frontier_logi_buff_charges", 3),
                 cf(session, "frontier_logi_buff_hours", 12), p.user_id)
        out["buff"] = {"pct": pct, "scope": scope}
        out["notes"].append(f"📦 تدارکاتِ نبردِ باس آماده شد: +{pct:g}٪ قدرتِ حمله برای حمله‌های بعدی.")
        out["points"] = add_points(session, p, season, bdef.region_key, node_pts * fx["pts"] * ev_mods.get("points", 1.0))
        S.metric_bump(session, p.user_id, "fr_support", 1)
        return out
    phases = boss_phases(bdef)
    idx, ph = FE.phase_of(phases, state.hp, state.hp_max)
    boss = {"defense": bdef.defense, "resist": boss_resist(bdef)}
    res = FE.boss_attack(run.seed, units, boss, ph, params, ready, fx, dmg_scale=cf(session, "frontier_dmg_scale", 100),
                         ret_k=cf(session, "frontier_boss_ret_k", 1.0), atk_extra=mods.get("atk_extra", 1.0),
                         research_atk=research, event_power=ev_mods.get("power", 1.0))
    _return_units(session, run.user_id, army, res["atk_units"])
    p.readiness = max(0.0, p.readiness - 14 * max(0.6, min(1.6, res["pressure"])))
    dealt = min(float(res["damage"]), float(state.hp))
    state.hp = max(0.0, float(state.hp) - dealt)
    new_idx, new_ph = FE.phase_of(phases, state.hp, state.hp_max)
    session.add(F.FrontierBossAttack(state_id=state.id, user_id=p.user_id, run_id=run.id, damage=dealt, lost=res["lost"], phase=idx))
    c = _contrib(session, season.id, p.user_id, run.clan_id or 0) if season is not None else None
    if c is not None:
        c.boss_damage = (c.boss_damage or 0.0) + dealt
    out.update({"outcome": "win", "damage": dealt, "lost": res["lost"], "phase": idx, "phase_name": ph.get("name", ""),
                "phase_note": ph.get("note", ""), "atk_units": res["atk_units"], "hp_left": state.hp, "hp_max": state.hp_max,
                "weak": ph.get("weak", ""), "ratio": res["ratio"]})
    if new_idx != idx and state.hp > 0:
        out["phase_change"] = new_ph.get("name", "")
        out["notes"].append(f"⚠️ باس وارد فازِ «{new_ph.get('name', '')}» شد! {new_ph.get('note', '')}")
    out["points"] = add_points(session, p, season, bdef.region_key, node_pts * fx["pts"] * ev_mods.get("points", 1.0))
    r = pay(session, p, "fr_boss_hit", scale=1.0, capped=True, region_scale=rscale, mods=rm, hop_mult=loot, ref=f"frrun:{run.id}")
    out["rewards"] = r or {}
    S.metric_bump(session, p.user_id, "fr_boss_hits", 1)
    S.metric_bump(session, p.user_id, "fr_damage", int(dealt))
    if state.hp <= 1e-6 and state.status == "active":
        state.status = "defeated"
        state.defeated_at = now
        out["killed"] = True
        events.extend(_boss_defeated(session, state, bdef, region, season, now))
    return out


def _boss_defeated(session, state, bdef, region, season, now):
    rows = session.query(F.FrontierBossAttack.user_id, func.sum(F.FrontierBossAttack.damage), func.count(F.FrontierBossAttack.id),
                         func.sum(F.FrontierBossAttack.lost)).filter(F.FrontierBossAttack.state_id == state.id) \
        .group_by(F.FrontierBossAttack.user_id).all()
    total = sum(float(r[1] or 0) for r in rows) or 1.0
    min_att = ci(session, "frontier_boss_min_attacks", 2) if state.scope == "clan" else 1
    min_share = cf(session, "frontier_boss_min_share_pct", 1) / 100.0 if state.scope == "clan" else 0.0
    min_lvl = ci(session, "frontier_min_war_level_rewards", 2)
    cap = cf(session, "frontier_boss_share_cap_pct", 35) / 100.0
    valid = []
    for uid, dmg, cnt, lost in rows:
        pl = S.get_player(session, uid)
        if cnt >= min_att and (float(dmg or 0) / total) >= min_share and S.player_level(session, pl) >= min_lvl:
            valid.append((uid, float(dmg or 0), int(cnt), int(lost or 0), pl))
    apply_cap = state.scope == "clan" and len(valid) >= 3
    solo_f = 0.5 if state.scope == "user" else 1.0
    events = []
    paid = []
    ev_mods = event_mods(session, bdef.region_key, now)
    rm = {"reward": ev_mods["reward"], "xp": ev_mods["xp"]}
    for uid, dmg, cnt, lost, pl in valid:
        share = dmg / total
        sh = min(share, cap) if apply_cap else share
        sc = (0.5 + 1.5 * sh) * solo_f
        if bdef.is_event:
            r1 = pay(session, pl, bdef.reward_trigger, scale=0.8, claim_key=f"eventboss:{state.id}:{uid}", region_scale=region.reward_scale, mods=rm)
        else:
            pr = _prog(session, uid, bdef.node_key)
            if (pr.clears or 0) == 0:
                pr.first_clear_at = now
            pr.clears = (pr.clears or 0) + 1
            pr.last_clear_at = now
            r1 = pay(session, pl, bdef.reward_trigger, scale=1.0, claim_key=f"first:{bdef.node_key}", region_scale=region.reward_scale, mods=rm)
        r2 = pay(session, pl, "fr_boss_kill", scale=sc, claim_key=f"kill:{state.id}", region_scale=region.reward_scale, mods=rm)
        paid.append((uid, (r1 or {}).get("hop", 0) + (r2 or {}).get("hop", 0)))
        S.metric_bump(session, uid, "fr_boss_kills", 1)
        if lost == 0 and cnt >= (2 if state.scope == "clan" else 1) and bdef.difficulty >= 3:
            S.metric_bump(session, uid, "fr_flawless", 1)
        if not bdef.is_event:
            _after_clear(session, pl, bdef.region_key, season, events, now)
        check_honors(session, uid, season.id if season else 0)
    state.paid = True
    if state.scope == "clan":
        cr = clan_region_row(session, state.scope_id, bdef.region_key, create=True)
        if not bdef.is_event:
            cr.boss_down = True
            cr.first_boss_at = cr.first_boss_at or now
        C.clan_log(session, state.scope_id, f"🐉 باسِ «{bdef.name}» با همکاریِ قبیله شکست خورد!")
        if len(valid) >= 3 and not bdef.is_event:
            top = max(valid, key=lambda x: x[1])
            if grant_honor(session, top[0], "clan_pillar", season.id if season else 0):
                S.metric_bump(session, top[0], "fr_h_pillar", 1, _skip_ach=True)
    S.audit(session, None, "frontier_boss_defeated", state=state.id, boss=bdef.key, scope=state.scope, scope_id=state.scope_id,
            participants=len(valid))
    events.append({"type": "fr_boss_down", "state_id": state.id, "boss": bdef.key, "scope": state.scope, "scope_id": state.scope_id,
                   "participants": [u for u, _h in paid], "region": bdef.region_key, "event": bdef.is_event})
    return events


# ---------------------------------------------------------------------------
# خوش‌آمد / پیشگام / کشفِ منطقه
# ---------------------------------------------------------------------------

def welcome(session, p):
    """هدیه‌ی ورود (یک‌بار): پاداش + پرکردنِ سوخت. برمی‌گردونه dict یا None."""
    if not ci(session, "frontier_welcome_enabled", 1):
        return None
    if not claim_once(session, p.user_id, "welcome", "fr_welcome"):
        return None
    r = pay(session, p, "fr_welcome", scale=1.0, mods=event_mods(session))
    c = session.query(F.FrontierRewardClaim).filter_by(user_id=p.user_id, claim_key="welcome").first()
    if c and r:
        c.hop, c.xp = r["hop"], r["xp"]
    S.sync_player(session, p)
    p.fuel = max(p.fuel, cf(session, "war_fuel_max", 10))
    S.audit(session, p.user_id, "frontier_welcome")
    return r or {}


def pop_region_unlocks(session, p):
    """منطقه‌هایی که تازه برای بازیکن باز شدن (فقط یک‌بار اعلام می‌شن)."""
    new = []
    for r in regions(session):
        if region_requirements(session, p, r)["open"]:
            if insert_once(session, F.FrontierDiscovery, ["user_id", "key"], user_id=p.user_id, key=f"region:{r.key}", kind="region",
                           region_key=r.key, at=utcnow()):
                new.append(r)
    return new


def pioneer_state(session, p):
    """نردبانِ سه‌روزِ اول: [(n, state, date)] ؛ state: claimed / ready / today / missed / future"""
    w = session.query(F.FrontierRewardClaim).filter_by(user_id=p.user_id, claim_key="welcome").first()
    if not w:
        return []
    start = w.created_at.date()
    today = utcnow().date()
    out = []
    for n in (1, 2, 3):
        d = start + datetime.timedelta(days=n - 1)
        claimed = session.query(F.FrontierRewardClaim.id).filter_by(user_id=p.user_id, claim_key=f"pioneer:{n}").first() is not None
        row = session.query(F.FrontierDaily).filter_by(user_id=p.user_id, day=d.strftime("%Y-%m-%d")).first()
        ran = bool(row and (row.runs or 0) >= 1)
        if claimed:
            st = "claimed"
        elif today < d:
            st = "future"
        elif ran and today <= d + datetime.timedelta(days=1):
            st = "ready"
        elif today > d + datetime.timedelta(days=1):
            st = "missed"
        else:
            st = "today"
        out.append((n, st, d))
    return out


def claim_pioneer(session, p, n):
    if not ci(session, "frontier_pioneer_enabled", 1):
        raise WarError("این پاداش خاموشه.")
    st = {x[0]: x[1] for x in pioneer_state(session, p)}.get(n)
    if st != "ready":
        raise WarError("این پاداش الان قابل‌دریافت نیست.")
    r = pay(session, p, f"fr_pioneer_{n}", scale=1.0, claim_key=f"pioneer:{n}", mods=event_mods(session))
    if r is None:
        raise WarError("قبلاً دریافت کردی.")
    check_honors(session, p.user_id)
    return r


def recent_rewards(session, uid, limit=8):
    return session.query(F.FrontierRewardClaim).filter_by(user_id=uid).order_by(F.FrontierRewardClaim.id.desc()).limit(limit).all()


# ---------------------------------------------------------------------------
# فصل: امتیاز، جدول، تسویه
# ---------------------------------------------------------------------------

def refresh_scores(session, season, now=None):
    now = now or utcnow()
    min_runs = ci(session, "frontier_active_member_min_runs", 3)
    agg = session.query(F.FrontierContribution.clan_id, func.sum(F.FrontierContribution.points),
                        func.sum(F.FrontierContribution.discoveries), func.sum(F.FrontierContribution.runs)) \
        .filter(F.FrontierContribution.season_id == season.id, F.FrontierContribution.clan_id > 0) \
        .group_by(F.FrontierContribution.clan_id).all()
    actives = dict(session.query(F.FrontierContribution.clan_id, func.count(F.FrontierContribution.id)).filter(
        F.FrontierContribution.season_id == season.id, F.FrontierContribution.clan_id > 0,
        F.FrontierContribution.runs >= min_runs).group_by(F.FrontierContribution.clan_id).all())
    kills = dict(session.query(F.FrontierBossState.scope_id, func.count(F.FrontierBossState.id)).filter(
        F.FrontierBossState.scope == "clan", F.FrontierBossState.status == "defeated",
        F.FrontierBossState.defeated_at >= season.start_at, F.FrontierBossState.defeated_at <= season.end_at + datetime.timedelta(days=1))
        .group_by(F.FrontierBossState.scope_id).all())
    out = []
    expo = cf(session, "frontier_size_exponent", 0.6)
    for clan_id, pts, disc, runs in agg:
        clan = session.get(W.WarClan, clan_id)
        if not clan or clan.disbanded:
            continue
        n = max(1, C.member_count(session, clan_id))
        bracket = FE.bracket_of(n, ci(session, "frontier_bracket_small", 8), ci(session, "frontier_bracket_medium", 16))
        act = int(actives.get(clan_id, 0))
        total = FE.clan_rating(float(pts or 0), n, expo, int(kills.get(clan_id, 0)), int(disc or 0), act,
                               cf(session, "frontier_score_boss_kill", 500), cf(session, "frontier_score_discovery", 40),
                               cf(session, "frontier_score_participation", 1000))
        row = session.query(F.FrontierSeasonScore).filter_by(season_id=season.id, clan_id=clan_id).first()
        if row is None:
            row = F.FrontierSeasonScore(season_id=season.id, clan_id=clan_id)
            session.add(row)
        row.points, row.boss_kills, row.discoveries, row.ops = float(pts or 0), int(kills.get(clan_id, 0)), int(disc or 0), int(runs or 0)
        row.active_members, row.members_n, row.bracket, row.total, row.updated_at = act, n, bracket, total, now
        out.append(row)
    session.flush()
    return out


def leaderboard(session, season, bracket=None, limit=10, refresh=True):
    if season is None:
        return []
    if refresh:
        refresh_scores(session, season)
    q = session.query(F.FrontierSeasonScore).filter_by(season_id=season.id).filter(F.FrontierSeasonScore.total > 0)
    if bracket:
        q = q.filter_by(bracket=bracket)
    return q.order_by(F.FrontierSeasonScore.total.desc(), F.FrontierSeasonScore.clan_id).limit(limit).all()


def my_rank(session, season, clan_id, bracket=None):
    rows = leaderboard(session, season, bracket, limit=500, refresh=False)
    for i, r in enumerate(rows, 1):
        if r.clan_id == clan_id:
            return i, r
    return None, None


def settle_season(session, season, now=None, force=False):
    """تسویه‌ی فصل: Idempotent (یک UPDATE شرطی)؛ رتبه‌ها در تالارِ افتخارات ثبت و جایزه‌ها فقط یک‌بار پرداخت می‌شن."""
    now = now or utcnow()
    if season.status != "active" and season.settled:
        return []
    if not force and season.end_at > now:
        return []
    n = session.query(F.FrontierSeason).filter(F.FrontierSeason.id == season.id, F.FrontierSeason.settled == False).update(  # noqa: E712
        {"settled": True, "status": "ended"}, synchronize_session=False)
    if n != 1:
        return []
    session.refresh(season)
    refresh_scores(session, season, now)
    min_pts = cf(session, "frontier_season_min_points", 60)
    min_runs = ci(session, "frontier_season_min_runs", 5)
    min_lvl = ci(session, "frontier_min_war_level_rewards", 2)
    events, payouts, winners = [], [], []
    allrows = session.query(F.FrontierSeasonScore).filter_by(season_id=season.id).filter(
        F.FrontierSeasonScore.total > 0, F.FrontierSeasonScore.points >= min_pts).all()
    ranked_all = sorted(allrows, key=lambda r: (-r.total, r.clan_id))
    for i, r in enumerate(ranked_all[:3], 1):                       # رتبه‌بندیِ کلی (افتخار)
        clan = session.get(W.WarClan, r.clan_id)
        insert_once(session, F.FrontierHall, ["season_id", "bracket", "rank"], season_id=season.id, season_name=season.name, bracket="all",
                    rank=i, clan_id=r.clan_id, clan_name=clan.name if clan else "?", clan_tag=clan.tag if clan else "", score=r.total,
                    created_at=now)
    ranked_ids = set()
    for bracket in ("small", "medium", "large"):
        rows = sorted([r for r in allrows if r.bracket == bracket], key=lambda r: (-r.total, r.clan_id))
        for rank, r in enumerate(rows, 1):
            r.final_rank = rank
            ranked_ids.add(r.clan_id)
            clan = session.get(W.WarClan, r.clan_id)
            members = [m.user_id for m in session.query(W.WarClanMember).filter_by(clan_id=r.clan_id).all()]
            eligible = []
            for u in members:
                cr = session.query(F.FrontierContribution).filter_by(season_id=season.id, user_id=u, clan_id=r.clan_id).first()
                pl = S.get_player(session, u)
                if cr and cr.runs >= min_runs and cr.points > 0 and S.player_level(session, pl) >= min_lvl:
                    eligible.append((u, pl))
            if rank <= 3:
                insert_once(session, F.FrontierHall, ["season_id", "bracket", "rank"], season_id=season.id, season_name=season.name,
                            bracket=bracket, rank=rank, clan_id=r.clan_id, clan_name=clan.name if clan else "?",
                            clan_tag=clan.tag if clan else "", score=r.total, created_at=now)
                winners.append((bracket, rank, r.clan_id))
                for u, pl in eligible:
                    out = pay(session, pl, f"fr_season_{rank}", scale=1.0, claim_key=f"season:{season.id}:rank", mods={"reward": 1.0, "xp": 1.0})
                    if out is not None:
                        payouts.append((u, out["hop"], rank))
                    S.metric_bump(session, u, "fr_h_season_top3", 1, _skip_ach=True)
                    if rank == 1:
                        S.metric_bump(session, u, "fr_h_season_win", 1, _skip_ach=True)
                    check_honors(session, u, season.id)
            else:
                for u, pl in eligible:
                    out = pay(session, pl, "fr_season_part", scale=cf(session, "frontier_season_part_ref_hours", 2.5) / max(0.01, session.get(
                        W.WarRewardRule, "fr_season_part").hop_ref_hours or 2.5), claim_key=f"season:{season.id}:part")
                    if out is not None:
                        payouts.append((u, out["hop"], 0))
    S.audit(session, None, "frontier_season_settled", season=season.id, winners=winners, paid=len(payouts))
    events.append({"type": "fr_season_end", "season_id": season.id, "winners": winners, "payouts": payouts, "name": season.name})
    return events


def hall_of_fame(session, limit=9):
    return session.query(F.FrontierHall).filter_by(bracket="all").order_by(F.FrontierHall.season_id.desc(), F.FrontierHall.rank).limit(limit).all()


# ---------------------------------------------------------------------------
# Tick (هر ۱۵ ثانیه) — فقط رکوردهای موعدرسیده؛ Idempotent
# ---------------------------------------------------------------------------

def run_tick(now=None):
    now = now or utcnow()
    events = []
    s = db.get_session()
    try:
        ids = [r[0] for r in s.query(F.FrontierRun.id).filter(F.FrontierRun.status == "marching", F.FrontierRun.resolve_at <= now)
               .order_by(F.FrontierRun.resolve_at).limit(40).all()]
    finally:
        s.close()
    import logging
    log = logging.getLogger(__name__)
    for rid in ids:
        s = db.get_session()
        try:
            ev = resolve_run(s, rid, now)
            s.commit()
            if ev:
                events.extend(ev)
        except Exception:
            s.rollback()
            log.exception("frontier resolve %s failed (retry next tick)", rid)
        finally:
            s.close()

    def _season_roll(s):
        out = []
        if not enabled(s):
            return out
        for old in s.query(F.FrontierSeason).filter(F.FrontierSeason.status == "active", F.FrontierSeason.end_at <= now).all():
            out += settle_season(s, old, now)
        if ci(s, "frontier_season_auto_next", 1):
            current_season(s, now, create=True)
        return out

    def _cleanup(s):
        s.query(F.FrontierBuff).filter((F.FrontierBuff.expires_at <= now) | (F.FrontierBuff.charges <= 0)).delete(synchronize_session=False)
        for st in s.query(F.FrontierBossState).filter(F.FrontierBossState.status == "active", F.FrontierBossState.event_id > 0).all():
            ev = s.get(F.FrontierEvent, st.event_id)
            if not ev or ev.end_at <= now or not ev.enabled:
                st.status = "expired"
        return None

    for name, fn in (("expire", lambda s: expire_stuck(s, now) and None), ("season", _season_roll), ("cleanup", _cleanup)):
        s = db.get_session()
        try:
            out = fn(s)
            s.commit()
            if out:
                events.extend(out)
        except Exception:
            s.rollback()
            log.exception("frontier tick step %s failed", name)
        finally:
            s.close()
    return events


# ---------------------------------------------------------------------------
# بتل‌پس: آیتم‌های Frontier (kind هایی که با fr_ شروع می‌شن)
# ---------------------------------------------------------------------------

def bp_deliver(session, user, d, tag):
    """تحویلِ جایزه‌ی بتل‌پسِ Frontier. برمی‌گردونه متنِ نتیجه. (Idempotency با BpClaim خودِ بتل‌پسه)"""
    uid = user.telegram_id
    p = S.get_player(session, uid)
    S.sync_player(session, p)
    k = d.kind
    if k == "fr_fuel":
        fmax = cf(session, "war_fuel_max", 10)
        before = p.fuel
        p.fuel = min(fmax, p.fuel + max(1.0, float(d.amount or 6)))
        return f"⛽ سوختِ Frontier +{p.fuel - before:g}" + (" (پر شد)" if p.fuel >= fmax else "")
    if k in ("fr_atk", "fr_loot"):
        kind = "atk" if k == "fr_atk" else "loot"
        pct = float(d.pct or 15)
        charges = int(d.uses or 3)
        hours = max(24.0, (d.minutes or 0) / 60.0)
        add_buff(session, "user", uid, kind, pct, charges, hours, uid)
        return (f"💥 قدرتِ حمله‌ی Frontier +{pct:g}٪ برای {charges} عملیات" if kind == "atk"
                else f"🎁 پاداشِ Frontier +{pct:g}٪ برای {charges} عملیات")
    if k == "fr_mats":
        _, cap = S.vault_caps(session, p)
        add = max(0.0, min(float(d.amount or 150), cap - p.vault_mat))
        p.vault_mat += add
        return f"🔩 مواد +{add:,.0f}"
    if k == "fr_clue":
        n = max(1, int(d.amount or 1))
        got = 0
        for r in regions(session):
            if not region_requirements(session, p, r)["open"]:
                continue
            rooms = [x for x in nodes_in(session, r.key) if x.hidden and not has_room(session, uid, x.key)]
            while rooms and got < n:
                if add_clue(session, uid, r.key):
                    got += 1
                else:
                    break
            if got >= n:
                break
        if got:
            return f"🔎 {got} سرنخِ اتاقِ مخفی"
        add = min(100.0, S.vault_caps(session, p)[1] - p.vault_mat)
        p.vault_mat += max(0.0, add)
        return "🔩 مواد +100 (اتاقِ مخفیِ قابل‌کشفی نبود)"
    return "🎁"


# ---------------------------------------------------------------------------
# نصبِ یک‌باره روی دیتابیسِ موجود: چلنج‌ها و آیتم‌های Frontier در بتل‌پس (Idempotent، بدونِ دست‌زدن به جایزه‌های دریافت‌شده)
# ---------------------------------------------------------------------------
BP_CHALLENGES = [
    ("🌌 ۲ عملیاتِ Frontier انجام بده", "frontier_runs", 2, 350, 2, "daily", 0, 60),
    ("🐉 ۱ حمله به باسِ Frontier", "frontier_boss_hits", 1, 700, 3, "daily", 0, 61),
    ("🌌 ۶ عملیاتِ Frontier", "frontier_runs", 6, 2000, 2, "weekly", 0, 62),
    ("🏆 ۴ کلیرِ موفقِ Frontier", "frontier_wins", 4, 4000, 3, "weekly", 0, 63),
    ("🐉 ۴ حمله به باس", "frontier_boss_hits", 4, 7000, 4, "weekly", 2, 64),
    ("🌌 ۳۰ عملیاتِ Frontier", "frontier_runs", 30, 5000, 2, "season", 0, 65),
]
BP_FREE = [("fr_fuel", 6, 0, 0, 0, "⛽ سوختِ Frontier +۶"), ("fr_mats", 150, 0, 0, 0, "🔩 ۱۵۰ مواد جنگ")]
BP_PREM = [("fr_atk", 0, 15, 3, 0, "💥 قدرتِ حمله‌ی Frontier +۱۵٪ (۳ عملیات)"), ("fr_loot", 0, 25, 3, 0, "🎁 پاداشِ Frontier +۲۵٪ (۳ عملیات)"),
           ("fr_clue", 1, 0, 0, 0, "🔎 سرنخِ اتاقِ مخفی")]


def post_init(session):
    import battlepass_db as BD
    from sqlalchemy import inspect as _insp
    if not _insp(session.get_bind()).has_table("bp_challenge_defs"):
        return 0                                   # بتل‌پس نصب/ساخته نشده (مثلاً تست)
    changed = 0
    if session.get(db.Config, "_fr_bp_ch_v1") is None and session.query(BD.BpChallengeDef).count() > 0:
        have = {c.title for c in session.query(BD.BpChallengeDef).all()}
        for title, metric, target, xp, diff, period, unlock, sort in BP_CHALLENGES:
            if title not in have:
                session.add(BD.BpChallengeDef(title=title, metric=metric, target=target, xp=xp, diff=diff, period=period,
                                              unlock_week=unlock, sort=sort))
                changed += 1
        session.add(db.Config(key="_fr_bp_ch_v1", value="1"))
    if session.get(db.Config, "_fr_bp_inject_v1") is None:
        season = session.query(BD.BpSeason).filter_by(status="active").order_by(BD.BpSeason.id.desc()).first()
        if season is not None:
            claimed = {(c.tier, c.track) for c in session.query(BD.BpClaim).filter_by(season_id=season.id).all()}
            fi = pi = 0
            for d in session.query(BD.BpTierDef).filter_by(season_id=season.id).order_by(BD.BpTierDef.tier).all():
                if (d.tier, d.track) in claimed or d.kind != "hop":
                    continue
                if d.track == "free" and d.tier % 7 == 3:
                    k, a, pc, u, m, lab = BP_FREE[fi % len(BP_FREE)]
                    fi += 1
                elif d.track == "premium" and d.tier % 6 == 2:
                    k, a, pc, u, m, lab = BP_PREM[pi % len(BP_PREM)]
                    pi += 1
                else:
                    continue
                d.kind, d.amount, d.pct, d.uses, d.minutes, d.label = k, float(a), float(pc), int(u), int(m), lab
                changed += 1
        if season is not None:                      # اگه هنوز فصلی نیست، دفعه‌ی بعدِ استارت دوباره تلاش می‌شه
            session.add(db.Config(key="_fr_bp_inject_v1", value="1"))
    session.commit()
    return changed
