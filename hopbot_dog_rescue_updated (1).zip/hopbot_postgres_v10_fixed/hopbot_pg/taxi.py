# -*- coding: utf-8 -*-
"""
تاکسیِ هاپویی 🚕 - بازیِ مسافرکشیِ خودکار.

با تایپِ «تاکسی هاپویی» در گروه فعال می‌شه (پنلِ شخصی و قفل‌شده به همون کاربر،
دقیقا مثلِ باقیِ منوها - نگاه کن به _verify_panel_owner).

اجزا:
- 🚗 خریدِ ماشین: پیش‌فرض هیچ ماشینی وجود نداره؛ پلیر باید یکی از مدل‌هایی که
  مالک از پنل ساخته رو بخره.
- 🏎 موتور: سطح ۱ تا سقفِ همون مدل (پیش‌فرض ۲۰). فقط رو مدتِ مسیرِ رفتن به
  مقصد اثر داره (سریع‌تر = مسیرِ کوتاه‌تر، نه واژه‌ی «سرعت»).
- ⭐️ محبوبیت: یه سیستمِ مقام/سطحِ سراسری برای خودِ راننده (نه ماشین) - دقیقا
  مثلِ هاپ‌منیج (TaxiRank/TaxiLevelDef): سطح‌ها بینِ مقام‌ها مشترکن، فقط تعداد
  سطحِ هر مقام فرق داره. رو نرخِ کرایه (هاپ پوینت به‌ازای هر دقیقه هر مسافر) و
  مدتِ پرشدنِ ماشین تو ایستگاه اثر می‌ذاره.
- ⛽️ بنزین: هر مدل باکِ خودشو داره؛ با مسافرکشی مصرف می‌شه؛ قیمتِ هر لیتر تو
  یه بازه نوسان می‌کنه (رندوم در لحظه‌ی پرکردن).
- 🧼 کارواش: بعد از چند روز از آخرین شست‌وشو، ماشین کثیف می‌شه؛ باعثِ کاهشِ
  شدیدِ کرایه و افزایشِ مدتِ انتظار می‌شه تا دوباره شسته بشه.
- چرخه‌ی خودکار: شروعِ شیفت -> (تو ایستگاه منتظرِ مسافر -> در راه -> برگشت) ×N
  -> پایانِ شیفت -> برداشتِ درآمد -> استراحتِ اجباری -> دوباره. کل شبیه‌سازی
  «تنبل» (lazy) پیاده شده: هر بار که پنل باز می‌شه یا دکمه‌ای زده می‌شه، وضعیت
  بر اساسِ زمانِ واقعیِ سپری‌شده به‌روزرسانی می‌شه - نیازی به تیکِ پس‌زمینه یا
  پیام‌دادنِ خودکار برای هر مرحله نیست (که خودش هم اسپم می‌شد).
"""
import datetime
import random

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

import db
import economy
import keyboards as kb
from handlers import fmt, send_response, _verify_panel_owner
from myawy import _format_remaining


# ---------------------------------------------------------------------------
# فرمول‌ها (موتور/محبوبیت) - مثلِ economy.py برای کارخونه
# ---------------------------------------------------------------------------

def engine_trip_range(session, car, engine_level: int):
    """(حداقل، حداکثر) دقیقه‌ی مسیر برای این سطحِ موتور، بینِ رنجِ سطح۱ و رنجِ
    کفِ (سقفِ) همین مدلِ ماشین درون‌یابی می‌شه."""
    base_min = db.cfg_get_float(session, "taxi_engine_base_trip_min")
    base_max = db.cfg_get_float(session, "taxi_engine_base_trip_max")
    floor_min = db.cfg_get_float(session, "taxi_engine_floor_trip_min")
    floor_max = db.cfg_get_float(session, "taxi_engine_floor_trip_max")
    max_level = max(2, car.engine_max_level)
    frac = min(1.0, max(0.0, (engine_level - 1) / (max_level - 1)))
    trip_min = base_min + (floor_min - base_min) * frac
    trip_max = base_max + (floor_max - base_max) * frac
    if trip_max < trip_min:
        trip_max = trip_min
    return trip_min, trip_max


def engine_upgrade_cost(session, level: int) -> float:
    """هزینه‌ی ارتقای موتور از `level` به `level+1`."""
    base = db.cfg_get_float(session, "taxi_engine_upgrade_base_cost")
    growth = db.cfg_get_float(session, "taxi_engine_upgrade_growth")
    n = level - 1
    return round(base * (growth ** n), 0)


def taxi_ranks_ordered(session):
    return session.query(db.TaxiRank).order_by(db.TaxiRank.order).all()


def get_taxi_rank_by_order(session, order):
    return session.query(db.TaxiRank).filter_by(order=order).first()


def current_taxi_rank(session, user):
    return get_taxi_rank_by_order(session, user.taxi_rank_order)


def taxi_level_values(session, level_number: int):
    """مقدارِ سطحِ نسبیِ مشترکِ محبوبیت - برمی‌گردونه:
    (کرایه به‌ازای هر دقیقه‌ی هر مسافر، حداقلِ انتظار، حداکثرِ انتظار، هزینه‌ی ارتقا به این سطح)."""
    row = session.get(db.TaxiLevelDef, level_number)
    n = level_number - 1
    base_fare = db.cfg_get_float(session, "taxi_appeal_base_fare_per_min")
    inc_fare = db.cfg_get_float(session, "taxi_appeal_fare_increment")
    base_wait_min = db.cfg_get_float(session, "taxi_appeal_base_wait_min")
    base_wait_max = db.cfg_get_float(session, "taxi_appeal_base_wait_max")
    floor_wait_min = db.cfg_get_float(session, "taxi_appeal_floor_wait_min")
    floor_wait_max = db.cfg_get_float(session, "taxi_appeal_floor_wait_max")
    ref_max = max(2, db.cfg_get_int(session, "taxi_appeal_reference_max_level"))
    cost_base = db.cfg_get_float(session, "taxi_appeal_upgrade_base_cost")
    growth = db.cfg_get_float(session, "taxi_appeal_upgrade_growth")

    fare = row.fare_bonus_per_min if (row and row.fare_bonus_per_min is not None) else base_fare + inc_fare * n
    frac = min(1.0, max(0.0, n / (ref_max - 1)))
    wait_min = row.wait_min_minutes if (row and row.wait_min_minutes is not None) else base_wait_min + (floor_wait_min - base_wait_min) * frac
    wait_max = row.wait_max_minutes if (row and row.wait_max_minutes is not None) else base_wait_max + (floor_wait_max - base_wait_max) * frac
    cost = row.upgrade_cost if (row and row.upgrade_cost is not None) else round(cost_base * (growth ** n), 0)
    return fare, wait_min, wait_max, cost


def taxi_next_upgrade_cost(session, user):
    rank = current_taxi_rank(session, user)
    if not rank or user.taxi_level >= rank.num_levels:
        return None
    _, _, _, cost = taxi_level_values(session, user.taxi_level + 1)
    return cost


def taxi_can_advance_rank(session, user) -> bool:
    rank = current_taxi_rank(session, user)
    if not rank or user.taxi_level < rank.num_levels:
        return False
    return get_taxi_rank_by_order(session, user.taxi_rank_order + 1) is not None


def taxi_upgrade_level(session, user):
    user.taxi_level += 1


def taxi_advance_rank(session, user):
    user.taxi_rank_order += 1
    user.taxi_level = 1


def _recompute_taxi_ranks_noop(session):
    """جای‌نگه‌دار برای تقارن با myawy._recompute_generation_bans - محبوبیت
    قانونِ خودکارِ اضافه‌ای نداره که نیاز به بازمحاسبه داشته باشه."""
    return None


# ---------------------------------------------------------------------------
# بنزین/کثیفی
# ---------------------------------------------------------------------------

def _is_car_dirty(session, user) -> bool:
    if not user.taxi_last_wash_at:
        return True
    hours = db.cfg_get_float(session, "taxi_dirty_after_hours")
    return (datetime.datetime.utcnow() - user.taxi_last_wash_at).total_seconds() / 3600.0 >= hours


def _random_gas_price(session) -> float:
    lo = db.cfg_get_float(session, "taxi_gas_price_min_per_liter")
    hi = db.cfg_get_float(session, "taxi_gas_price_max_per_liter")
    if hi < lo:
        hi = lo
    return random.uniform(lo, hi)


def _consume_gas(user, car, duration_minutes: float) -> bool:
    """اگه بنزین کافی بود مصرف می‌کنه و True برمی‌گردونه؛ وگرنه بنزین رو صفر
    می‌کنه و False برمی‌گردونه (یعنی این مرحله نمی‌تونه طی بشه - باکِ خالی)."""
    use = car.gas_use_per_hour / 60.0 * duration_minutes
    if user.taxi_gas_liters < use:
        user.taxi_gas_liters = 0
        return False
    user.taxi_gas_liters -= use
    return True


def _end_shift(user, out_of_gas: bool = False):
    user.taxi_state = "shift_complete" if user.taxi_shift_earnings > 0 else "idle"
    user.taxi_state_until = None


# ---------------------------------------------------------------------------
# شبیه‌سازیِ «تنبل» - همیشه قبل از نمایش/هر اکشن صدا زده می‌شه
# ---------------------------------------------------------------------------

def sync_taxi_state(session, user):
    """وضعیتِ تاکسیِ کاربر رو با زمانِ واقعیِ سپری‌شده هماهنگ می‌کنه: هر مرحله‌ای
    که موعدش گذشته رو (با لنگرِ زمانِ منطقیِ خودش، نه لحظه‌ی چک‌کردن) پشتِ سرِ
    هم پردازش می‌کنه تا به الان برسه یا به یه مرحله‌ی بازِ جدید برسه."""
    nowt = datetime.datetime.utcnow()

    if user.taxi_state == "resting" and user.taxi_resting_until and nowt >= user.taxi_resting_until:
        user.taxi_state = "idle"
        user.taxi_resting_until = None

    car = session.get(db.TaxiCarModel, user.taxi_car_model_id) if user.taxi_car_model_id else None

    guard = 0
    while (
        user.taxi_state in ("at_station", "en_route", "returning")
        and user.taxi_state_until is not None
        and nowt >= user.taxi_state_until
        and guard < 500
    ):
        guard += 1
        anchor = user.taxi_state_until  # زمانِ منطقیِ اتمامِ این مرحله (نه الان)

        if not car:
            _end_shift(user)
            break

        if user.taxi_state == "at_station":
            min_p = db.cfg_get_int(session, "taxi_min_passengers_per_trip")
            max_p = db.cfg_get_int(session, "taxi_max_passengers_per_trip")
            if max_p < min_p:
                max_p = min_p
            passengers = random.randint(min_p, max_p)
            trip_min, trip_max = engine_trip_range(session, car, user.taxi_engine_level)
            duration = random.uniform(trip_min, trip_max)
            if not _consume_gas(user, car, duration):
                _end_shift(user, out_of_gas=True)
                break
            fare_per_min, _wmin, _wmax, _cost = taxi_level_values(session, user.taxi_level)
            dirty = _is_car_dirty(session, user)
            multiplier = db.cfg_get_float(session, "taxi_dirty_fare_multiplier") if dirty else 1.0
            earnings = fare_per_min * duration * passengers * multiplier * economy.money_income_multiplier(session, user)
            user.taxi_shift_earnings += earnings
            user.taxi_current_passengers = passengers
            user.taxi_state = "en_route"
            user.taxi_state_until = anchor + datetime.timedelta(minutes=duration)

        elif user.taxi_state == "en_route":
            return_minutes = db.cfg_get_float(session, "taxi_station_return_minutes")
            if not _consume_gas(user, car, return_minutes):
                _end_shift(user, out_of_gas=True)
                break
            user.taxi_state = "returning"
            user.taxi_state_until = anchor + datetime.timedelta(minutes=return_minutes)

        elif user.taxi_state == "returning":
            if user.taxi_shift_until and anchor >= user.taxi_shift_until:
                _end_shift(user)
                break
            fare_per_min, wait_min, wait_max, _cost = taxi_level_values(session, user.taxi_level)
            dirty = _is_car_dirty(session, user)
            if dirty:
                extra = db.cfg_get_float(session, "taxi_dirty_extra_wait_minutes")
                wait_min += extra
                wait_max += extra
            if wait_max < wait_min:
                wait_max = wait_min
            duration = random.uniform(wait_min, wait_max)
            if not _consume_gas(user, car, duration):
                _end_shift(user, out_of_gas=True)
                break
            user.taxi_state = "at_station"
            user.taxi_state_until = anchor + datetime.timedelta(minutes=duration)


# ---------------------------------------------------------------------------
# نمایشِ خانه‌ی تاکسی
# ---------------------------------------------------------------------------

_STATE_LABELS = {
    "idle": "🅿️ پارکه، آماده‌ی شروع",
    "at_station": "🚏 تو ایستگاه منتظرِ مسافره",
    "en_route": "🛣 در حالِ رسوندنِ مسافرا",
    "returning": "↩️ در حالِ برگشت به ایستگاه",
    "shift_complete": "🏁 شیفت تموم شد - آماده‌ی برداشت",
    "resting": "😴 داره استراحت می‌کنه",
}


async def handle_taxi_trigger(update, context):
    await show_taxi_home(update, context)


async def show_taxi_home(update, context):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        sync_taxi_state(session, user)
        session.commit()
        await _send_taxi_home(update, user.telegram_id, session)
    finally:
        session.close()


async def _render_taxi_home(update, context, owner_id: int):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        sync_taxi_state(session, user)
        session.commit()
        await _send_taxi_home(update, owner_id, session)
    finally:
        session.close()


async def _send_taxi_home(update, owner_id: int, session):
    """توجه: session باز نگه داشته می‌شه فقط برای خوندن (بدونِ commit/close تو
    این تابع - فراخوان مسئولِ بستنشه) چون خودِ user و car از همین session میان."""
    user = session.get(db.User, owner_id)
    car = session.get(db.TaxiCarModel, user.taxi_car_model_id) if user.taxi_car_model_id else None
    lines = ["🚕 تاکسیِ هاپویی\n"]
    if not car:
        lines.append("🚫 هنوز ماشین نخریدی - از «🏪 خریدِ ماشین» یکی بخر.")
    else:
        dirty = _is_car_dirty(session, user)
        lines.append(f"🚗 ماشین: {car.name}" + (" | 🧼 کثیفه!" if dirty else ""))
        lines.append(f"⛽️ بنزین: {fmt(user.taxi_gas_liters)} / {fmt(car.gas_tank_liters)} لیتر")
        lines.append(f"🏎 سطحِ موتور: {user.taxi_engine_level}/{car.engine_max_level}")
        rank = current_taxi_rank(session, user)
        rank_txt = f"{rank.name} - سطح {user.taxi_level}/{rank.num_levels}" if rank else f"سطح {user.taxi_level} (هنوز مقامی تعریف نشده)"
        lines.append(f"⭐️ محبوبیت: {rank_txt}")
        lines.append(f"📍 وضعیت: {_STATE_LABELS.get(user.taxi_state, user.taxi_state)}")
        nowt = datetime.datetime.utcnow()
        if user.taxi_state == "resting" and user.taxi_resting_until:
            remain = user.taxi_resting_until - nowt
            if remain.total_seconds() > 0:
                lines.append(f"⏳ تا آماده‌شدنِ دوباره: {_format_remaining(remain)}")
        if user.taxi_state in ("at_station", "en_route", "returning") and user.taxi_shift_until:
            remain_shift = user.taxi_shift_until - nowt
            if remain_shift.total_seconds() > 0:
                lines.append(f"⏳ تا پایانِ شیفت (تقریبی): {_format_remaining(remain_shift)}")
        lines.append(f"💰 درآمدِ برداشت‌نشده‌ی همین شیفت: {fmt(user.taxi_shift_earnings)} 🪙")
    await send_response(update, "\n".join(lines), kb.taxi_home_keyboard(owner_id, user, car))


# ---------------------------------------------------------------------------
# شروع/برداشت/کنسل
# ---------------------------------------------------------------------------

async def cb_taxi_home(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await _render_taxi_home(update, context, owner_id)


async def cb_taxi_start(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        sync_taxi_state(session, user)
        if not user.taxi_car_model_id:
            session.commit()
            await update.callback_query.answer("اول باید یه ماشینِ تاکسی بخری.", show_alert=True)
            return
        if user.taxi_state != "idle":
            session.commit()
            await update.callback_query.answer("الان تو حالتِ دیگه‌ای هستی؛ نمی‌تونی شیفتِ جدید شروع کنی.", show_alert=True)
            return
        car = session.get(db.TaxiCarModel, user.taxi_car_model_id)
        if not car or not car.is_active:
            session.commit()
            await update.callback_query.answer("ماشینِ فعلیت دیگه معتبر نیست.", show_alert=True)
            return
        if user.taxi_gas_liters <= 0:
            session.commit()
            await update.callback_query.answer("باکت خالیه! اول بنزین بزن.", show_alert=True)
            return
        nowt = datetime.datetime.utcnow()
        drive_hours = db.cfg_get_float(session, "taxi_drive_hours_per_day")
        user.taxi_shift_until = nowt + datetime.timedelta(hours=drive_hours)
        user.taxi_shift_earnings = 0
        user.taxi_state = "at_station"
        user.taxi_state_until = nowt
        sync_taxi_state(session, user)
        session.commit()
    finally:
        session.close()
    await _render_taxi_home(update, context, owner_id)


async def cb_taxi_withdraw(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        sync_taxi_state(session, user)
        if user.taxi_state != "shift_complete" or user.taxi_shift_earnings <= 0:
            session.commit()
            await update.callback_query.answer("چیزی برای برداشت نیست.", show_alert=True)
            return
        amount = user.taxi_shift_earnings
        user.hop_points += amount
        user.taxi_shift_earnings = 0
        rest_hours = db.cfg_get_float(session, "taxi_rest_hours_after")
        user.taxi_state = "resting"
        user.taxi_resting_until = datetime.datetime.utcnow() + datetime.timedelta(hours=rest_hours)
        session.commit()
        await update.callback_query.answer(f"🏧 {fmt(amount)} 🪙 واریز شد!")
    finally:
        session.close()
    await _render_taxi_home(update, context, owner_id)


async def cb_taxi_cancel_ask(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await send_response(
        update,
        "🛑 مطمئنی می‌خوای همینجا تاکسی‌رانی رو کنسل کنی؟ درآمدِ برداشت‌نشده‌ی همین شیفت از دست می‌ره.",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله، کنسلش کن", callback_data=f"taxi_cancel_confirm:{owner_id}"),
            InlineKeyboardButton("❌ انصراف", callback_data=f"taxi_home:{owner_id}"),
        ]]),
    )


async def cb_taxi_cancel_confirm(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        user.taxi_state = "idle"
        user.taxi_state_until = None
        user.taxi_shift_until = None
        user.taxi_shift_earnings = 0
        user.taxi_current_passengers = 0
        session.commit()
    finally:
        session.close()
    await _render_taxi_home(update, context, owner_id)


# ---------------------------------------------------------------------------
# خریدِ ماشین
# ---------------------------------------------------------------------------

async def cb_taxi_shop(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        cars = session.query(db.TaxiCarModel).filter_by(is_active=True).order_by(db.TaxiCarModel.price).all()
        items = [(c.id, f"{c.name} | {fmt(c.price)}🪙") for c in cars]
        session.commit()
        text = "🏪 ماشین‌های تاکسیِ موجود:" if items else "🏪 فعلاً هیچ ماشینی تو بازار نیست."
        await send_response(update, text, kb.taxi_shop_keyboard(items, owner_id))
    finally:
        session.close()


async def cb_taxi_shop_view(update, context):
    _, car_id, owner_id = update.callback_query.data.split(":")
    car_id, owner_id = int(car_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        car = session.get(db.TaxiCarModel, car_id)
        if not car or not car.is_active:
            await send_response(update, "این ماشین دیگه موجود نیست.", kb.taxi_shop_keyboard([], owner_id))
            return
        text = (
            f"🚗 {car.name}\n\n"
            f"💵 قیمت: {fmt(car.price)} 🪙\n"
            f"⛽️ ظرفیتِ باک: {fmt(car.gas_tank_liters)} لیتر\n"
            f"⛽️ مصرف: {fmt(car.gas_use_per_hour)} لیتر در ساعتِ کار\n"
            f"🏎 سقفِ سطحِ موتور: {car.engine_max_level}"
        )
        session.commit()
        await send_response(update, text, kb.taxi_shop_view_keyboard(car.id, owner_id))
    finally:
        session.close()


async def cb_taxi_shop_buy_ask(update, context):
    _, car_id, owner_id = update.callback_query.data.split(":")
    car_id, owner_id = int(car_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        has_car = bool(user.taxi_car_model_id)
        session.commit()
    finally:
        session.close()
    warn = "\n\n⚠️ ماشینِ فعلیت با این عوض می‌شه و از دست می‌ره (بدونِ بازپرداخت)!" if has_car else ""
    await send_response(
        update, f"مطمئنی می‌خوای این ماشین رو بخری؟{warn}",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله، بخر", callback_data=f"taxi_shop_buy_confirm:{car_id}:{owner_id}"),
            InlineKeyboardButton("❌ انصراف", callback_data=f"taxi_shop_view:{car_id}:{owner_id}"),
        ]]),
    )


async def cb_taxi_shop_buy_confirm(update, context):
    _, car_id, owner_id = update.callback_query.data.split(":")
    car_id, owner_id = int(car_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        sync_taxi_state(session, user)
        if user.taxi_state not in ("idle", "resting", "shift_complete"):
            session.commit()
            await update.callback_query.answer("اول باید تاکسی‌رانیِ فعلیت رو تموم یا کنسل کنی.", show_alert=True)
            return
        car = session.get(db.TaxiCarModel, car_id)
        if not car or not car.is_active:
            session.commit()
            await update.callback_query.answer("این ماشین دیگه موجود نیست.", show_alert=True)
            return
        if user.hop_points < car.price:
            session.commit()
            await update.callback_query.answer(f"موجودی کافی نیست! {fmt(car.price)} 🪙 لازمه.", show_alert=True)
            return
        user.hop_points -= car.price
        user.taxi_car_model_id = car.id
        user.taxi_engine_level = 1
        user.taxi_gas_liters = car.gas_tank_liters
        user.taxi_last_wash_at = datetime.datetime.utcnow()
        user.taxi_state = "idle"
        user.taxi_state_until = None
        user.taxi_shift_until = None
        user.taxi_shift_earnings = 0
        session.commit()
    finally:
        session.close()
    await _render_taxi_home(update, context, owner_id)


# ---------------------------------------------------------------------------
# ارتقای موتور/محبوبیت، کارواش، بنزین
# ---------------------------------------------------------------------------

async def cb_taxi_upgrade_engine(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        car = session.get(db.TaxiCarModel, user.taxi_car_model_id) if user.taxi_car_model_id else None
        if not car:
            session.commit()
            await update.callback_query.answer("اول باید ماشین بخری.", show_alert=True)
            return
        if user.taxi_engine_level >= car.engine_max_level:
            session.commit()
            await update.callback_query.answer("موتور در حداکثرِ سطحه.", show_alert=True)
            return
        cost = engine_upgrade_cost(session, user.taxi_engine_level)
        if user.hop_points < cost - 0.5:
            session.commit()
            await update.callback_query.answer(f"موجودی کافی نیست! {cost:,.0f} 🪙 لازمه.", show_alert=True)
            return
        user.hop_points -= cost
        user.taxi_engine_level += 1
        session.commit()
        await update.callback_query.answer("✅ موتور ارتقا یافت!")
    finally:
        session.close()
    await _render_taxi_home(update, context, owner_id)


async def cb_taxi_upgrade_appeal(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        cost = taxi_next_upgrade_cost(session, user)
        if cost is None:
            session.commit()
            if taxi_can_advance_rank(session, user):
                await update.callback_query.answer("به آخرِ این مقام رسیدی! باید بری مقامِ بعد.", show_alert=True)
            else:
                await update.callback_query.answer("محبوبیتت الان در حداکثره (یا هنوز مقامی تعریف نشده).", show_alert=True)
            return
        if user.hop_points < cost - 0.5:
            session.commit()
            await update.callback_query.answer(f"موجودی کافی نیست! {cost:,.0f} 🪙 لازمه.", show_alert=True)
            return
        user.hop_points -= cost
        taxi_upgrade_level(session, user)
        session.commit()
        await update.callback_query.answer("✅ محبوبیت ارتقا یافت!")
    finally:
        session.close()
    await _render_taxi_home(update, context, owner_id)


async def cb_taxi_advance_rank_ask(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        can = taxi_can_advance_rank(session, user)
        next_rank = get_taxi_rank_by_order(session, user.taxi_rank_order + 1) if can else None
        name = next_rank.name if next_rank else ""
        session.commit()
    finally:
        session.close()
    if not can:
        await update.callback_query.answer("هنوز نمی‌تونی بری مقامِ بعد.", show_alert=True)
        return
    await send_response(
        update, f"میری مقامِ «{name}»؛ سطحِ محبوبیتت به ۱ برمی‌گرده (کرایه‌ی اضافه‌ات ریست می‌شه). مطمئنی؟",
        InlineKeyboardMarkup([[
            InlineKeyboardButton("✅ بله، برو مقامِ بعد", callback_data=f"taxi_advance_rank_confirm:{owner_id}"),
            InlineKeyboardButton("❌ انصراف", callback_data=f"taxi_home:{owner_id}"),
        ]]),
    )


async def cb_taxi_advance_rank_confirm(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        if taxi_can_advance_rank(session, user):
            taxi_advance_rank(session, user)
            session.commit()
        else:
            session.commit()
            await update.callback_query.answer("هنوز نمی‌تونی بری مقامِ بعد.", show_alert=True)
            return
    finally:
        session.close()
    await _render_taxi_home(update, context, owner_id)


async def cb_taxi_carwash(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        sync_taxi_state(session, user)
        if not user.taxi_car_model_id:
            session.commit()
            await update.callback_query.answer("اول باید ماشین بخری.", show_alert=True)
            return
        if user.taxi_state not in ("idle", "resting", "shift_complete"):
            session.commit()
            await update.callback_query.answer("وسطِ تاکسی‌رانی نمی‌تونی بری کارواش.", show_alert=True)
            return
        cost = db.cfg_get_float(session, "taxi_carwash_cost")
        if not _is_car_dirty(session, user):
            session.commit()
            await update.callback_query.answer("ماشینت الان کثیف نیست.", show_alert=True)
            return
        if user.hop_points < cost - 0.5:
            session.commit()
            await update.callback_query.answer(f"موجودی کافی نیست! {cost:,.0f} 🪙 لازمه.", show_alert=True)
            return
        user.hop_points -= cost
        user.taxi_last_wash_at = datetime.datetime.utcnow()
        session.commit()
        await update.callback_query.answer("🧼 ماشین شسته شد!")
    finally:
        session.close()
    await _render_taxi_home(update, context, owner_id)


async def cb_taxi_refuel(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        sync_taxi_state(session, user)
        car = session.get(db.TaxiCarModel, user.taxi_car_model_id) if user.taxi_car_model_id else None
        if not car:
            session.commit()
            await update.callback_query.answer("اول باید ماشین بخری.", show_alert=True)
            return
        needed = car.gas_tank_liters - user.taxi_gas_liters
        if needed <= 0.001:
            session.commit()
            await update.callback_query.answer("باکت پره.", show_alert=True)
            return
        price_per_liter = _random_gas_price(session)
        total_cost = needed * price_per_liter
        if user.hop_points < total_cost:
            session.commit()
            await update.callback_query.answer(
                f"موجودی کافی نیست! برای پرکردنِ کامل {total_cost:,.0f} 🪙 لازمه (هر لیتر {price_per_liter:,.0f}).",
                show_alert=True,
            )
            return
        user.hop_points -= total_cost
        user.taxi_gas_liters = car.gas_tank_liters
        session.commit()
        await update.callback_query.answer(f"⛽️ باک پر شد! {total_cost:,.0f} 🪙 پرداخت شد.")
    finally:
        session.close()
    await _render_taxi_home(update, context, owner_id)


# ---------------------------------------------------------------------------
# مسیریاب دکمه‌های شیشه‌ای
# ---------------------------------------------------------------------------

TAXI_PREFIX_MAP = {
    "taxi_home": cb_taxi_home,
    "taxi_start": cb_taxi_start,
    "taxi_withdraw": cb_taxi_withdraw,
    "taxi_cancel_ask": cb_taxi_cancel_ask,
    "taxi_cancel_confirm": cb_taxi_cancel_confirm,
    "taxi_shop": cb_taxi_shop,
    "taxi_shop_view": cb_taxi_shop_view,
    "taxi_shop_buy_ask": cb_taxi_shop_buy_ask,
    "taxi_shop_buy_confirm": cb_taxi_shop_buy_confirm,
    "taxi_upgrade_engine": cb_taxi_upgrade_engine,
    "taxi_upgrade_appeal": cb_taxi_upgrade_appeal,
    "taxi_advance_rank_ask": cb_taxi_advance_rank_ask,
    "taxi_advance_rank_confirm": cb_taxi_advance_rank_confirm,
    "taxi_carwash": cb_taxi_carwash,
    "taxi_refuel": cb_taxi_refuel,
}


async def taxi_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = TAXI_PREFIX_MAP.get(prefix)
    if not handler:
        return False
    await handler(update, context)
    return True
