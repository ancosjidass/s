# -*- coding: utf-8 -*-
"""
انتخابِ زبان + پیش‌پردازشِ هر آپدیت.

• پیوی: هر کاربر زبانِ خودش رو انتخاب می‌کنه (دکمه‌ی «🌐 Language» تو منوی اصلی، یا /lang، یا نوشتنِ «زبان»/language).
• گروه: زبانِ گروه وجود نداره؛ زبان فقط شخصیه. هر کاربر (حتی تو گروهِ فارسی) به زبانِ انتخابیِ خودش جواب می‌گیره و
  ادمین‌ها هیچ کنترلی روش ندارن. /lang یا «زبان هاپویی»/hapoyilang تو گروه هم زبانِ شخصیِ همون کاربر رو عوض می‌کنه.
• این بخش حتی وقتی «پیویِ عمومی» خاموشه هم کار می‌کنه (main._private_chat_blocked استثنا می‌ده).

callback_data:
    lang:menu:<uid>               → باز کردنِ لیستِ زبان‌ها برایِ پیویِ همون کاربر
    lang:set:u:<code>:<uid>       → زبانِ پیویِ کاربر
    lang:set:g:<code>:<uid>       → زبانِ گروه (فقط ادمین)
"""
import logging
import re

from telegram import InlineKeyboardButton as B, InlineKeyboardMarkup as K, Update
from telegram.ext import ContextTypes

import chat_prefs
import config
import db
import i18n

logger = logging.getLogger(__name__)

CB_PREFIX = "lang:"
# تریگرهایِ متنی. «زبان»/language فقط تو پیوی؛ تو گروه فقط تریگرهایِ اختصاصی (تا کلمه‌یِ عادیِ «زبان» وسطِ چت اشتباهی پنل باز نکنه)
PV_TRIGGER_RE = re.compile(r"^\s*/?(lang|language|زبان|زبان هاپویی|hapoyi\s*lang(uage)?)\s*$", re.I)
GROUP_TRIGGER_RE = re.compile(r"^\s*(زبان هاپویی|زبان گروه|hapoyi\s*lang(uage)?|group\s*lang(uage)?)\s*$", re.I)


def is_lang_text(text: str, is_private: bool) -> bool:
    if not text:
        return False
    t = text.replace("\u200c", " ").strip()
    return bool((PV_TRIGGER_RE if is_private else GROUP_TRIGGER_RE).match(t))


# ---------------------------------------------------------------------------
# پیش‌پردازشِ هر آپدیت (group=-3؛ هرگز propagation رو قطع نمی‌کنه)
# ---------------------------------------------------------------------------
async def pre_handler(update: Update, context: ContextTypes.DEFAULT_TYPE):
    try:
        chat = update.effective_chat
        user = update.effective_user
        if chat is not None:
            i18n.CURRENT_CHAT.set(chat.id)
        i18n.CURRENT_USER.set(user.id if user is not None else None)
        if user is not None:
            chat_prefs.remember_username(user.id, user.username)
            if chat is not None and chat.type == "private":
                chat_prefs.mark_pm(user.id)          # از این به بعد منشنِ این کاربر text_mention می‌شه
        msg = update.message
        if msg is not None and msg.text and chat is not None:
            lang = chat_prefs.get_lang(user.id) if user is not None else i18n.DEFAULT   # زبانِ شخصیِ فرستنده، هرجا که باشه
            if lang != i18n.DEFAULT:
                new = i18n.to_fa(msg.text, lang)    # دستورِ انگلیسی → معادلِ فارسی
                if new != msg.text:
                    with msg._unfrozen():
                        msg.text = new
    except Exception:
        logger.exception("lang pre_handler failed")


# ---------------------------------------------------------------------------
# نمایش
# ---------------------------------------------------------------------------
def _rows(scope, uid, current):
    rows = []
    for code, name in i18n.available().items():
        mark = "✅ " if code == current else ""
        rows.append([B(f"{mark}{name}", callback_data=f"lang:set:{scope}:{code}:{uid}")])
    return rows


def picker(user_id):
    cur = chat_prefs.get_lang(user_id)
    text = "🌐 Language / زبان\n\nزبانِ خودت رو انتخاب کن (همه‌جا، حتی تو گروه‌هایِ فارسی، برایِ خودت اعمال می‌شه) /\nChoose your language (applies to you everywhere, even in Persian groups):"
    return text, K(_rows("u", user_id, cur))


async def show_picker(update: Update, context: ContextTypes.DEFAULT_TYPE):
    user = update.effective_user
    text, kb = picker(user.id)
    await update.message.reply_text(text, reply_markup=kb)


async def cmd_lang(update: Update, context: ContextTypes.DEFAULT_TYPE):
    await show_picker(update, context)


async def text_lang(update: Update, context: ContextTypes.DEFAULT_TYPE):
    chat = update.effective_chat
    if update.message and update.message.text and is_lang_text(update.message.text, chat.type == "private"):
        await show_picker(update, context)


# ---------------------------------------------------------------------------
# کالبک
# ---------------------------------------------------------------------------
async def lang_callback(update: Update, context: ContextTypes.DEFAULT_TYPE) -> bool:
    q = update.callback_query
    parts = (q.data or "").split(":")
    if not parts or parts[0] != "lang":
        return False
    user, chat = update.effective_user, update.effective_chat
    try:
        owner = int(parts[-1])
    except (ValueError, IndexError):
        await q.answer()
        return True
    if user.id != owner:
        await q.answer("🚫 این منو برای شما نیست. / Not your menu.", show_alert=True)
        return True

    action = parts[1] if len(parts) > 1 else ""
    if action == "menu":
        text, kb = picker(user.id)
        await q.answer()
        await q.edit_message_text(text, reply_markup=kb)
        return True

    if action == "set" and len(parts) >= 5:
        code = parts[3]
        if code not in i18n.available():
            await q.answer("?", show_alert=True)
            return True
        chat_prefs.set_lang(user.id, code)          # فقط زبانِ شخصیِ خودِ کاربر
        msg = i18n.t("lang_set_user", code, name=i18n.available()[code])
        await q.answer()
        text, kb = picker(user.id)
        try:
            await q.edit_message_text(msg + "\n\n" + text, reply_markup=kb)
        except Exception as e:
            if "not modified" not in str(e).lower():
                raise
        return True

    await q.answer()
    return True
