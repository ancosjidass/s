# -*- coding: utf-8 -*-
"""
🌌 FRONTIER — منطقِ خالص (بدونِ دیتابیس/تلگرام). همه‌ی توابع قابل‌تست و Deterministic‌ان.

از موتورِ نبردِ موجود (war_engine) دوباره استفاده می‌شه: PvE فقط «دشمنِ ساختگی» (سازه‌ی دفاعی با ترکیبِ
زمینی/هوایی) می‌سازه و همون E.resolve / E.attack_side / E.apply_casualties رو صدا می‌زنه؛ فرمولِ جنگ دست‌نخورده.
"""
import hashlib
import json
import random

import war_engine as E

ROUTE_KEYS = ("assault", "infiltration", "logistics")


def parse_routes(raw, default):
    try:
        d = json.loads(raw) if isinstance(raw, str) else dict(raw or {})
    except (TypeError, ValueError):
        d = {}
    out = {}
    for k in ROUTE_KEYS:
        base = dict(default[k])
        base.update({kk: vv for kk, vv in (d.get(k) or {}).items() if kk in base})
        out[k] = base
    return out


def csv_floats(text, default):
    try:
        v = [float(x) for x in str(text).split(",") if x.strip() != ""]
        return v or list(default)
    except ValueError:
        return list(default)


# ---------------------------------------------------------------------------
# دشمن و مسیر
# ---------------------------------------------------------------------------

def enemy_structures(power, ground_pct, air_pct, power_mult=1.0, def_mult=1.0):
    """قدرتِ دفاعِ دشمن رو به سازه‌های موتور تبدیل می‌کنه (زمینی/هوایی/Generic) تا ماتریسِ کانتر اثر بذاره."""
    g = max(0, min(100, int(ground_pct))) / 100.0
    a = max(0, min(100, int(air_pct))) / 100.0
    if g + a > 1.0:
        s = g + a
        g, a = g / s, a / s
    total = max(0.0, float(power)) * power_mult * def_mult
    structs = []
    if g > 0:
        structs.append({"type": "ground", "power": total * g})
    if a > 0:
        structs.append({"type": "air", "power": total * a})
    rest = 1.0 - g - a
    if rest > 1e-9:
        structs.append({"type": "generic", "power": total * rest})
    return structs


def stealth_factor(army, defs, stealth_cats):
    """سهمِ ظرفیتِ نیروهای «پنهان‌کار» (هوایی/ویژه/موشکی) در ارتشِ اعزامی → ۰..۱ (۵۰٪ سهم = حداکثر)."""
    tot = st = 0
    for k, v in army.items():
        if k.startswith("_"):
            continue
        d = defs.get(k)
        if not d:
            continue
        n = (v.get("h", 0) + v.get("d", 0)) * max(1, d.housing)
        tot += n
        if d.category in stealth_cats:
            st += n
    if tot <= 0:
        return 0.0
    return max(0.0, min(1.0, (st / tot) * 2.0))


def route_effects(route_cfg, stealth, stealth_bonus_pct=25.0):
    """اثرِ واقعیِ مسیر روی نتیجه (نه فقط متن)."""
    r = route_cfg
    return {
        "atk": r["atk"], "cas": r["cas"], "pts": r["pts"], "dur": r["dur"], "rew": r["rew"],
        "def_mult": 1.0 - r["pen"] * stealth,
        "clue_pct": (r["clue"] + (stealth_bonus_pct * stealth if r["clue"] > 0 else 0.0)),
        "mat": r["mat"],
    }


def run_node(seed, army_units, node, params, readiness, route_fx, event_power=1.0, atk_extra=1.0,
             research_atk=1.0):
    """عملیاتِ عادی (scout/operation/elite/secret): همون E.resolve."""
    structs = enemy_structures(node["power"], node["ground_pct"], node["air_pct"], event_power, route_fx["def_mult"])
    res = E.resolve(seed, army_units, structs, [], params, readiness, 100.0,
                    atk_mult=route_fx["atk"] * atk_extra, casualty_mult=route_fx["cas"],
                    atk_research=research_atk, def_research=1.0, wall_mult=node.get("wall", 1.0))
    return res


# ---------------------------------------------------------------------------
# باس
# ---------------------------------------------------------------------------

def phase_of(phases, hp, hp_max):
    """فاز = آخرین فازی که at(٪) اش ≥ درصدِ HPِ باقی‌مونده."""
    if not phases:
        return 0, {"name": "—", "def": 1.0, "ret": 1.0, "weak": "", "weak_mult": 1.0, "note": ""}
    pct = 100.0 * max(0.0, hp) / hp_max if hp_max > 0 else 0.0
    idx = 0
    for i, ph in enumerate(phases):
        if pct <= float(ph.get("at", 100)) + 1e-9:
            idx = i
    return idx, phases[idx]


def boss_attack(seed, army_units, boss, phase, params, readiness, route_fx, dmg_scale=100.0,
                ret_k=1.0, atk_extra=1.0, research_atk=1.0, event_power=1.0):
    """
    یک حمله به باس. آسیب = قدرتِ مؤثرِ ارتش × مقاومتِ هر دسته × ضعفِ فاز × مقیاس.
    اگه ارتش از «دفاعِ فاز» ضعیف‌تر باشه آسیب کم می‌شه (ضدِ اسپمِ نیروی ضعیف) و تلفات بیشتر.
    Infiltration: نقطه‌ضعف رو بهتر می‌زنه؛ Logistics: آسیب نمی‌زنه (فقط باف).
    """
    rng = random.Random(seed)
    A, by_cat, support = E.attack_side(army_units, params, readiness, route_fx["atk"] * atk_extra, research_atk)
    resist = boss.get("resist", {})
    weak, weak_mult = phase.get("weak", ""), float(phase.get("weak_mult", 1.0))
    tot_raw = sum(by_cat.values())
    wsum = 0.0
    for cat, a in by_cat.items():
        m = float(resist.get(cat, 1.0))
        if weak and cat == weak:
            m *= weak_mult
        wsum += a * m
    # A شاملِ آمادگی/ضریبِ مسیر/پشتیبانی‌ست؛ مقاومتِ باس به‌صورتِ میانگینِ وزنی روش اعمال می‌شه
    eff = A * (wsum / tot_raw) if tot_raw > 0 else 0.0
    D = max(1.0, float(boss["defense"]) * float(phase.get("def", 1.0)) * event_power)
    ratio = eff / D
    soak = min(1.0, 0.35 + 0.65 * ratio)
    noise = 1.0 + rng.uniform(-params.rnd, params.rnd)
    dmg = max(0.0, eff * dmg_scale * soak * noise)
    if route_fx.get("no_damage"):
        dmg = 0.0
    pressure = 3.0 if eff <= 0 else max(0.25, min(3.0, D / eff))
    ret = float(phase.get("ret", 1.0)) * ret_k
    cas = E.apply_casualties(army_units, params.atk_destroy * pressure, params.atk_damage * pressure,
                             route_fx["cas"] * ret, rng)
    lost = sum(v[2] for v in cas.values())
    return {"damage": round(dmg, 1), "eff_power": round(eff, 2), "ratio": round(ratio, 4), "soak": round(soak, 3),
            "pressure": round(pressure, 3), "support_bonus": round(support, 4),
            "atk_units": {k: {"h": v[0], "d": v[1], "x": v[2]} for k, v in cas.items()}, "lost": int(lost)}


# ---------------------------------------------------------------------------
# بازده‌ی نزولی / سقف‌ها
# ---------------------------------------------------------------------------

def repeat_mult(steps, n_done_today):
    """ضریبِ پاداشِ تکرار: steps[i] برای (i+1)‌امین تکرارِ همان node در همان روز؛ بعدش آخرین مقدار."""
    if n_done_today < 0:
        n_done_today = 0
    return steps[min(n_done_today, len(steps) - 1)] if steps else 1.0


def capped_points(points_today, add, cap, soft_ratio, soft_mult):
    """امتیازِ فتحِ روزانه: تا soft_ratio×cap کامل، بعدش با soft_mult، و هرگز بیشتر از cap."""
    if cap <= 0 or add <= 0:
        return 0.0
    soft_start = cap * soft_ratio
    got = 0.0
    room = max(0.0, cap - points_today)
    full = max(0.0, min(add, soft_start - points_today))
    got += full
    rest = add - full
    if rest > 0:
        got += rest * soft_mult
    return max(0.0, min(got, room))


def daily_cap_hours(base, th_bonus, th_level):
    return base + th_bonus * max(0, th_level - 1)


# ---------------------------------------------------------------------------
# رقابتِ فصلی (ضدِ برتریِ دائمیِ قبیله‌های بزرگ)
# ---------------------------------------------------------------------------

def bracket_of(members_n, small_max, medium_max):
    if members_n <= small_max:
        return "small"
    if members_n <= medium_max:
        return "medium"
    return "large"


def clan_rating(points, members_n, exponent, boss_kills, discoveries, active_members, w_boss, w_disc, w_part):
    """
    امتیازِ نهایی = فعالیتِ نرمال‌شده‌ی به اندازه‌ی قبیله + باس + کشف + مشارکتِ فراگیر.
    - points: مجموعِ امتیازِ فتحِ *سقف‌خورده* (هر عضو سقفِ روزانه داره) تقسیم بر N^exp → قبیله‌ی کوچک مظلوم نمی‌شه.
    - مشارکت: نسبتِ اعضای فعال به کلِ اعضا → ۲۵ نفرِ نیمه‌فعال نمی‌تونه ۸ نفرِ پرانرژی رو ببره.
    """
    n = max(1, int(members_n))
    activity = points / (n ** exponent)
    part = (active_members / n) * w_part
    return round(activity + boss_kills * w_boss + discoveries * w_disc + part, 2)


# ---------------------------------------------------------------------------
# اتاقِ مخفی
# ---------------------------------------------------------------------------

def signal_answer(user_id, node_key, n_options=3):
    """پاسخِ درستِ سیگنال برای هر بازیکن متفاوته (با اشتراکِ جواب در گروه خراب نمی‌شه)؛ ولی Deterministic."""
    h = hashlib.sha256(f"frontier:{user_id}:{node_key}".encode()).digest()
    return int.from_bytes(h[:4], "big") % max(1, n_options)


def signal_hint(user_id, node_key, n_options=3):
    """یک گزینه‌ی غلط که با سرنخِ کافی حذف می‌شه (همیشه غیر از جوابِ درست)."""
    ans = signal_answer(user_id, node_key, n_options)
    h = hashlib.sha256(f"hint:{user_id}:{node_key}".encode()).digest()
    wrong = [i for i in range(n_options) if i != ans]
    return wrong[int.from_bytes(h[:2], "big") % len(wrong)]


def clue_roll(seed, pct):
    return random.Random(seed ^ 0x5EED).random() * 100.0 < pct


def power_tier_label(ratio):
    """برچسبِ ریسک برای نمایش (عددِ دقیقِ دشمن لو نمی‌ره)."""
    if ratio >= 2.2:
        return "🟢 خیلی آسون"
    if ratio >= 1.4:
        return "🟢 مناسب"
    if ratio >= 1.0:
        return "🟡 پرریسک"
    if ratio >= 0.7:
        return "🟠 خطرناک"
    return "🔴 خودکشی"
