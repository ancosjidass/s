# -*- coding: utf-8 -*-
"""
🃏 اونو هاپویی

چرخه‌ی بازی:
۱. از منویِ «کازینو هاپویی» دکمه‌ی «🃏 اونو» رو می‌زنی -> مثلِ بقیه‌ی بازی‌ها
   اول مبلغِ ورودی و تعدادِ نفرات (۲ تا ۴) رو می‌چینی.
۲. «شروع» -> یه لابی تو خودِ گروه باز می‌شه و بقیه با دکمه می‌پیوندن. اگه تو
   مهلتِ لابی (پیش‌فرض ۲۰۰ ثانیه، از پنل قابلِ‌تغییر) پر نشه، بازی خودکار لغو
   و پولِ همه برگشت داده می‌شه.
۳. وقتی پر شد، کارت‌ها پخش می‌شن و بازی می‌ره تو پیویِ هر بازیکن: دستِ خودت رو
   فقط خودت می‌بینی. تو گروه فقط کارتِ روشده‌ی وسط، نوبتِ کی‌ئه و تعدادِ کارتِ
   هرکس نشون داده می‌شه (دقیقاً همون چیزایی که تو اونویِ واقعی هم رو میز
   معلومه).
۴. هر نوبت ۸۰ ثانیه مهلت داره؛ نزنی، نوبتت رد می‌شه. دو بار که رد شد، از بازی
   حذف می‌شی و بازی بینِ بقیه ادامه پیدا می‌کنه.
۵. هرکی اول کارتاش تموم شه برنده‌ست و کلِ پولِ میز رو می‌بره.

نکته‌ی مهمِ فنی: کلِ منطقِ کارت‌ها تو uno_engine.py (کاملاً جدا و تست‌شده)
پیاده شده؛ این فایل فقط رابطِ تلگرام/دیتابیسه.
"""
import asyncio
import datetime
import json
import random

from telegram import InlineKeyboardButton, InlineKeyboardMarkup

import db
import uno_engine as ue
from handlers import fmt, ask_for_input, is_reply_to_prompt, parse_amount

# قفلِ per-round - دقیقاً همون الگویِ casino.with_round_lock. بدونِ این، دو
# کلیکِ پشتِ‌سرهم (یا نتِ بد که همون کالبک رو دوباره می‌فرسته) می‌تونستن هر دو
# از یه چکِ یکسان رد بشن و مثلاً یه نفر رو دوبار به بازی اضافه کنن یا یه کارت
# رو دوبار بندازن.
_round_locks = {}


def _get_round_lock(round_id: int) -> asyncio.Lock:
    lock = _round_locks.get(round_id)
    if lock is None:
        lock = asyncio.Lock()
        _round_locks[round_id] = lock
    return lock


def with_round_lock(func):
    async def wrapper(update, context):
        try:
            rid = int(update.callback_query.data.split(":")[1])
        except (ValueError, IndexError, AttributeError):
            await func(update, context)
            return
        async with _get_round_lock(rid):
            await func(update, context)
        session = db.get_session()
        try:
            r = session.get(db.UnoRound, rid)
            if not r or r.status in ("resolved", "cancelled"):
                _round_locks.pop(rid, None)
        finally:
            session.close()
    return wrapper


def _now():
    return datetime.datetime.utcnow()


SETUP_ABANDON_TIMEOUT_SECONDS = 60  # اگه کاربر بازی رو بسازه ولی هیچ‌وقت «شروع» رو نزنه (یا پیامش رو پاک کنه)، بعدِ این‌همه ثانیه رها می‌شه


def _cfg_int(session, key):
    return int(db.cfg_get_float(session, key) or 0)


# ---------------------------------------------------------------------------
# کمکی‌های دیتابیس
# ---------------------------------------------------------------------------

def _players(session, rid, include_eliminated=False):
    q = session.query(db.UnoPlayer).filter_by(round_id=rid)
    if not include_eliminated:
        q = q.filter(db.UnoPlayer.eliminated == False)  # noqa: E712
    return q.order_by(db.UnoPlayer.seat).all()


def _hand(p):
    try:
        return json.loads(p.hand_json or "[]")
    except ValueError:
        return []


def _set_hand(p, cards):
    p.hand_json = json.dumps(cards)


def _pile(r):
    try:
        return json.loads(r.draw_pile_json or "[]")
    except ValueError:
        return []


def _set_pile(r, cards):
    r.draw_pile_json = json.dumps(cards)


def _name(session, uid):
    u = session.get(db.User, uid)
    return u.display_name() if u else str(uid)


def user_has_active_uno(session, user_id) -> bool:
    """برای اینکه یه نفر نتونه هم‌زمان دو تا اونو داشته باشه (یا با دوبار کلیک
    دو تا بسازه)."""
    return bool(
        session.query(db.UnoRound)
        .filter(
            db.UnoRound.status.in_(("setup", "lobby", "playing")),
            (db.UnoRound.initiator_id == user_id) |
            (db.UnoRound.id.in_(
                session.query(db.UnoPlayer.round_id).filter(db.UnoPlayer.user_id == user_id)
            )),
        )
        .first()
    )


# ---------------------------------------------------------------------------
# ساخت / تنظیمات
# ---------------------------------------------------------------------------

def _setup_text_kb(r):
    amount_txt = (fmt(r.entry_amount) + " 🪙") if r.entry_amount else "— تنظیم نشده —"
    players_txt = str(r.target_players) if r.target_players else "— تنظیم نشده —"
    text = (
        "🃏 اونو هاپویی\n\n"
        f"💰 مبلغ ورودی: {amount_txt}\n"
        f"👥 تعداد بازیکن: {players_txt}"
    )
    rows = [
        [InlineKeyboardButton("💰 انتخاب مبلغ ورودی", callback_data=f"uno_amt:{r.id}")],
        [InlineKeyboardButton("👥 انتخاب تعداد بازیکن", callback_data=f"uno_plr:{r.id}")],
    ]
    if r.entry_amount and r.target_players:
        rows.append([InlineKeyboardButton("▶️ شروع بازی", callback_data=f"uno_start:{r.id}")])
    rows.append([InlineKeyboardButton("❌ لغو", callback_data=f"uno_cancel:{r.id}")])
    return text, InlineKeyboardMarkup(rows)


async def cb_uno_new(update, context):
    """از منویِ کازینو - ساختِ یه دورِ جدید."""
    parts = update.callback_query.data.split(":")
    owner_id = int(parts[1]) if len(parts) > 1 else update.effective_user.id
    if update.effective_user.id != owner_id:
        await update.callback_query.answer(
            "⛔️ این منو مالِ تو نیست! برای بازکردنِ کازینوی خودت بنویس «کازینو هاپویی».",
            show_alert=True)
        return
    import casino
    session = db.get_session()
    try:
        if user_has_active_uno(session, owner_id) or casino._user_has_active_round(session, owner_id):
            await update.callback_query.answer(
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, owner_id)
        if remaining > 0:
            await update.callback_query.answer(
                f"⏳ خودت تازه یه کازینو تموم کردی. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        r = db.UnoRound(
            chat_id=update.effective_chat.id,
            message_id=update.callback_query.message.message_id,
            initiator_id=owner_id,
            status="setup",
        )
        session.add(r)
        session.commit()
        text, kb = _setup_text_kb(r)
        await update.callback_query.edit_message_text(text, reply_markup=kb)
    finally:
        session.close()


async def _check_initiator(update, r):
    if not r or update.effective_user.id != r.initiator_id:
        await update.callback_query.answer("⛔️ این بازی مال تو نیست!", show_alert=True)
        return False
    return True


@with_round_lock
async def cb_uno_amt(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        presets = [int(x) for x in (db.cfg_get(session, "casino_preset_amounts") or "").split(",") if x.strip().isdigit()]
        rows, row = [], []
        for amt in presets:
            row.append(InlineKeyboardButton(fmt(amt), callback_data=f"uno_setamt:{rid}:{amt}"))
            if len(row) == 3:
                rows.append(row)
                row = []
        if row:
            rows.append(row)
        rows.append([InlineKeyboardButton("✏️ مبلغ دلخواه", callback_data=f"uno_amt_custom:{rid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"uno_back:{rid}")])
        await update.callback_query.edit_message_text("💰 مبلغ ورودی رو انتخاب کن:", reply_markup=InlineKeyboardMarkup(rows))
    finally:
        session.close()


@with_round_lock
async def cb_uno_amt_custom(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        await ask_for_input(update, context, "✏️ مبلغ ورودی دلخواه رو به عدد بفرست (مثلا 5m یا 2b):",
                             {"type": "amount", "round_id": rid}, "uno_awaiting")
    finally:
        session.close()


@with_round_lock
async def cb_uno_setamt(update, context):
    _, rid, amt = update.callback_query.data.split(":")
    rid, amt = int(rid), int(amt)
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not await _check_initiator(update, r):
            return
        max_bet = db.cfg_get_float(session, "casino_max_bet")
        if max_bet and amt > max_bet:
            await update.callback_query.answer(f"❌ حداکثر مبلغِ مجاز {fmt(max_bet)} 🪙 است.", show_alert=True)
            return
        r.entry_amount = amt
        session.commit()
        text, kb = _setup_text_kb(r)
        await update.callback_query.edit_message_text(text, reply_markup=kb)
    finally:
        session.close()


@with_round_lock
async def cb_uno_plr(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not await _check_initiator(update, r):
            return
        rows = [[InlineKeyboardButton(f"{n} نفر", callback_data=f"uno_setplr:{rid}:{n}") for n in (2, 3, 4)]]
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"uno_back:{rid}")])
        await update.callback_query.edit_message_text("👥 تعداد بازیکن رو انتخاب کن (۲ تا ۴):", reply_markup=InlineKeyboardMarkup(rows))
    finally:
        session.close()


@with_round_lock
async def cb_uno_setplr(update, context):
    _, rid, n = update.callback_query.data.split(":")
    rid, n = int(rid), int(n)
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not await _check_initiator(update, r):
            return
        r.target_players = max(2, min(4, n))
        session.commit()
        text, kb = _setup_text_kb(r)
        await update.callback_query.edit_message_text(text, reply_markup=kb)
    finally:
        session.close()


@with_round_lock
async def cb_uno_back(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not await _check_initiator(update, r):
            return
        text, kb = _setup_text_kb(r)
        await update.callback_query.edit_message_text(text, reply_markup=kb)
    finally:
        session.close()


@with_round_lock
async def cb_uno_cancel(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status in ("resolved", "cancelled"):
            await update.callback_query.answer("این بازی از قبل تموم شده.", show_alert=True)
            return
        await _refund_all(session, r)
        r.status = "cancelled"
        r.ended_at = _now()
        session.commit()
        await update.callback_query.edit_message_text("❌ بازیِ اونو لغو شد؛ مبلغِ همه برگشت داده شد.")
    finally:
        session.close()


@with_round_lock
async def cb_uno_leave(update, context):
    """فقط تو مرحله‌ی lobby و فقط برای بازی‌هایی که ظرفیتشون ۳ یا ۴ نفره‌ست
    (تو _lobby_text_kb این دکمه اصلاً برای ۲نفره‌ها ساخته نمی‌شه). هر بازیکنی
    که پیوسته - جز سازنده - می‌تونه بزنتش؛ پولش برمی‌گرده و از بازی حذف می‌شه،
    بدونِ اینکه کلِ بازی لغو بشه. سازنده اگه بخواد بره باید کلِ بازی رو با
    دکمه‌ی «لغو بازی» لغو کنه (پولِ بقیه هم برمی‌گرده)."""
    rid = int(update.callback_query.data.split(":")[1])
    uid = update.effective_user.id
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not r or r.status != "lobby":
            await update.callback_query.answer("❌ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if uid == r.initiator_id:
            await update.callback_query.answer(
                "⛔️ تو سازنده‌ی این بازی‌ای! اگه می‌خوای بیخیالش بشی، رو دکمه‌ی «لغو بازی» بزن (پولِ همه برمی‌گرده).",
                show_alert=True)
            return
        player = session.query(db.UnoPlayer).filter_by(round_id=rid, user_id=uid).first()
        if not player:
            await update.callback_query.answer("⛔️ تو عضوِ این بازی نیستی.", show_alert=True)
            return

        user = session.get(db.User, uid)
        if user and r.entry_amount:
            user.hop_points += r.entry_amount
        session.delete(player)
        r.last_action_at = _now()
        session.commit()
        await update.callback_query.answer("🚪 از بازی خارج شدی؛ پولت برگشت داده شد.")

        text, kb = _lobby_text_kb(session, r)
        await _edit_group(context, r, text, kb)
    finally:
        session.close()


async def _refund_all(session, r):
    for p in _players(session, r.id, include_eliminated=True):
        u = session.get(db.User, p.user_id)
        if u and r.entry_amount:
            u.hop_points += r.entry_amount


# ---------------------------------------------------------------------------
# لابیِ گروه
# ---------------------------------------------------------------------------

def _lobby_text_kb(session, r):
    players = _players(session, r.id)
    names = "\n".join(f"  {i + 1}. {_name(session, p.user_id)}" for i, p in enumerate(players)) or "  — هنوز کسی —"
    timeout = _cfg_int(session, "uno_lobby_timeout_seconds")
    text = (
        "🃏 اونو هاپویی\n\n"
        f"💰 ورودی: {fmt(r.entry_amount)} 🪙\n"
        f"👥 بازیکن‌ها ({len(players)}/{r.target_players}):\n{names}\n\n"
        f"⏳ اگه تا {timeout} ثانیه پر نشه، بازی لغو و پول‌ها برگشت داده می‌شه.\n"
        "📩 بعد از پرشدن، بازی تو پیویِ هر بازیکن انجام می‌شه — حتماً ربات رو استارت کرده باش."
    )
    rows = [[InlineKeyboardButton("🎮 پیوستن به بازی", callback_data=f"uno_join:{r.id}")]]
    # دکمه‌ی «لغو» همیشه تو لابی هست (فقط سازنده واقعاً می‌تونه بزنتش - چک تو
    # خودِ هندلر انجام می‌شه). دکمه‌ی «ترکِ بازی» فقط وقتی می‌آد که ظرفیت ۳ یا
    # ۴ نفره باشه؛ چون تو حالتِ ۲نفره به‌محضِ پیوستنِ نفرِ دوم بازی فوراً شروع
    # می‌شه و اصلاً فرصتی برای دیدنِ این دکمه نیست.
    rows.append([InlineKeyboardButton("❌ لغو بازی (فقط سازنده)", callback_data=f"uno_cancel:{r.id}")])
    if r.target_players and r.target_players >= 3:
        rows.append([InlineKeyboardButton("🚪 ترک بازی", callback_data=f"uno_leave:{r.id}")])
    kb = InlineKeyboardMarkup(rows)
    return text, kb


@with_round_lock
async def cb_uno_start(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        if not r.entry_amount or not r.target_players:
            await update.callback_query.answer("اول مبلغ و تعدادِ بازیکن رو مشخص کن.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if (user.hop_points or 0) < r.entry_amount:
            await update.callback_query.answer(f"❌ موجودی کافی نیست! {fmt(r.entry_amount)} 🪙 لازمه.", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.UnoPlayer(round_id=r.id, user_id=user.telegram_id, seat=0))
        r.status = "lobby"
        r.lobby_opened_at = _now()
        r.last_action_at = _now()
        session.commit()
        text, kb = _lobby_text_kb(session, r)
        await update.callback_query.edit_message_text(text, reply_markup=kb)
        _schedule(context, _lobby_timeout, rid, _cfg_int(session, "uno_lobby_timeout_seconds"))
    finally:
        session.close()


@with_round_lock
async def cb_uno_join(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    uid = update.effective_user.id
    import casino
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, rid)
        if not r or r.status != "lobby":
            await update.callback_query.answer("❌ این بازی دیگه فعال نیست.", show_alert=True)
            return
        existing = session.query(db.UnoPlayer).filter_by(round_id=rid, user_id=uid).first()
        if existing:
            await update.callback_query.answer("تو از قبل تو این بازی هستی!", show_alert=True)
            return
        players = _players(session, rid)
        if len(players) >= r.target_players:
            await update.callback_query.answer("❌ ظرفیتِ بازی پر شده.", show_alert=True)
            return
        if user_has_active_uno(session, uid) or casino._user_has_active_round(session, uid):
            await update.callback_query.answer(
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.", show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, uid)
        if remaining > 0:
            await update.callback_query.answer(
                f"⏳ خودت تازه یه کازینو تموم کردی. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if (user.hop_points or 0) < r.entry_amount:
            await update.callback_query.answer(f"❌ موجودی کافی نیست! {fmt(r.entry_amount)} 🪙 لازمه.", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        session.add(db.UnoPlayer(round_id=rid, user_id=uid, seat=len(players)))
        r.last_action_at = _now()
        session.commit()

        players = _players(session, rid)
        if len(players) >= r.target_players:
            await _begin_game(context, session, r)
            return
        text, kb = _lobby_text_kb(session, r)
        try:
            await update.callback_query.edit_message_text(text, reply_markup=kb)
        except Exception:
            pass
    finally:
        session.close()


# ---------------------------------------------------------------------------
# شروعِ واقعیِ بازی
# ---------------------------------------------------------------------------

async def _begin_game(context, session, r):
    players = _players(session, r.id)
    n = len(players)
    hand_size = _cfg_int(session, "uno_start_hand_size") or 7
    specials = _cfg_int(session, "uno_special_cards_total") or 4

    deck = ue.build_deck(n, specials)
    hands, pile, start_card, color = ue.deal(deck, n, hand_size, specials)

    for p, h in zip(players, hands):
        _set_hand(p, h)
    _set_pile(r, pile)
    r.discard_top = start_card
    r.active_color = color
    r.pending_draw = 0
    r.direction = 1
    r.status = "playing"
    r.turn_user_id = players[0].user_id
    r.turn_seq = 1
    r.turn_started_at = _now()
    r.turn_deadline_at = _now() + datetime.timedelta(seconds=_cfg_int(session, "uno_turn_seconds") or 80)
    r.last_action_at = _now()
    session.commit()

    await _render_group(context, session, r)
    ok = True
    for p in players:
        if not await _send_hand_dm(context, session, r, p):
            ok = False
    if not ok:
        # حداقل یه نفر پیویِ بات رو استارت نکرده - بازی قابلِ‌انجام نیست، پس
        # کاملاً برش می‌گردونیم (پول همه برمی‌گرده) به‌جایِ اینکه نصفه گیر کنه.
        await _abort_unreachable(context, session, r)
        return
    _schedule(context, _turn_timeout, r.id, _cfg_int(session, "uno_turn_seconds") or 80, r.turn_seq)


async def _abort_unreachable(context, session, r):
    await _refund_all(session, r)
    r.status = "cancelled"
    r.ended_at = _now()
    session.commit()
    txt = ("❌ بازی لغو شد: حداقل یکی از بازیکن‌ها ربات رو تو پیوی استارت نکرده، "
           "پس نمی‌شد کارت‌هاش رو براش فرستاد.\n"
           "مبلغِ همه برگشت داده شد. (اول ربات رو تو پیوی /start بزنید، بعد دوباره امتحان کنید.)")
    await _edit_group(context, r, txt, None)


# ---------------------------------------------------------------------------
# نمایشِ گروه (چیزهایی که برای همه معلومه)
# ---------------------------------------------------------------------------

async def _edit_group(context, r, text, kb):
    try:
        await context.bot.edit_message_text(
            chat_id=r.chat_id, message_id=r.message_id, text=text, reply_markup=kb)
    except Exception:
        try:
            msg = await context.bot.send_message(r.chat_id, text, reply_markup=kb)
            r.message_id = msg.message_id
        except Exception:
            pass


async def _render_group(context, session, r):
    """تو گروه فقط اطلاعاتِ عمومی: کارتِ روشده‌ی وسط، رنگِ جاری، نوبتِ کی، و
    تعدادِ کارتِ هر بازیکن. خودِ دستِ کسی این‌جا لو نمی‌ره."""
    players = _players(session, r.id)
    lines = ["🃏 اونو هاپویی\n"]
    lines.append(f"🎴 کارتِ رو میز: {ue.card_label(r.discard_top)}")
    lines.append(f"🎨 رنگِ جاری: {ue.COLOR_EMOJI.get(r.active_color, '—')} {ue.COLOR_NAME.get(r.active_color, '—')}")
    if r.pending_draw:
        lines.append(f"⚠️ جریمه‌ی روی میز: +{r.pending_draw} (نفرِ بعدی یا جواب می‌ده یا می‌کشه)")
    lines.append(f"🔁 جهت: {'➡️' if (r.direction or 1) > 0 else '⬅️'}")
    max_turns = _cfg_int(session, "uno_max_turns") or 20
    lines.append(f"🔢 نوبت: {r.turn_seq or 0} از {max_turns}")
    lines.append("")
    for p in players:
        mark = "👉 " if p.user_id == r.turn_user_id else "     "
        lines.append(f"{mark}{_name(session, p.user_id)} — {len(_hand(p))} کارت")
    dropped = [p for p in _players(session, r.id, include_eliminated=True) if p.eliminated]
    if dropped:
        lines.append("\n❌ حذف‌شده‌ها: " + "، ".join(_name(session, p.user_id) for p in dropped))
    secs = _cfg_int(session, "uno_turn_seconds") or 80
    lines.append(f"\n⏳ هر نوبت {secs} ثانیه مهلت داره. بازی تو پیویِ بازیکن‌ها انجام می‌شه.")
    lines.append(f"💰 جایزه‌ی کل: {fmt((r.entry_amount or 0) * len(_players(session, r.id, include_eliminated=True)))} 🪙")
    await _edit_group(context, r, "\n".join(lines), None)


# ---------------------------------------------------------------------------
# پیویِ بازیکن (دستِ خودش)
# ---------------------------------------------------------------------------

def _hand_keyboard(r, p, my_turn):
    hand = _hand(p)
    rows = []
    if my_turn:
        playable = set(ue.playable_cards(hand, r.discard_top, r.active_color, r.pending_draw or 0))
        row = []
        for idx, card in enumerate(hand):
            mark = "" if card in playable else "🚫 "
            cb = (f"uno_play:{r.id}:{idx}" if card in playable else f"uno_nope:{r.id}:{idx}")
            row.append(InlineKeyboardButton(f"{mark}{ue.card_label(card)}", callback_data=cb))
            if len(row) == 2:
                rows.append(row)
                row = []
        if row:
            rows.append(row)
        draw_n = r.pending_draw or 1
        rows.append([InlineKeyboardButton(f"🫳 کشیدن کارت از وسط ({draw_n})", callback_data=f"uno_draw:{r.id}")])
    else:
        row = []
        for card in hand:
            row.append(InlineKeyboardButton(ue.card_label(card), callback_data=f"uno_noop:{r.id}"))
            if len(row) == 2:
                rows.append(row)
                row = []
        if row:
            rows.append(row)
    rows.append([InlineKeyboardButton("🔄 بروزرسانی", callback_data=f"uno_refresh:{r.id}")])
    return InlineKeyboardMarkup(rows)


def _hand_text(session, r, p, my_turn):
    lines = ["🃏 اونو هاپویی — دستِ تو\n"]
    lines.append(f"🎴 رو میز: {ue.card_label(r.discard_top)}")
    lines.append(f"🎨 رنگِ جاری: {ue.COLOR_EMOJI.get(r.active_color, '—')} {ue.COLOR_NAME.get(r.active_color, '—')}")
    if r.pending_draw:
        lines.append(f"⚠️ جریمه‌ی روی میز: +{r.pending_draw}")
    lines.append("")
    for other in _players(session, r.id):
        if other.user_id == p.user_id:
            continue
        lines.append(f"• {_name(session, other.user_id)}: {len(_hand(other))} کارت")
    lines.append("")
    if my_turn:
        secs = _cfg_int(session, "uno_turn_seconds") or 80
        maxmiss = _cfg_int(session, "uno_max_missed_turns") or 2
        lines.append(f"👉 نوبتِ توئه! {secs} ثانیه وقت داری.")
        lines.append(f"(نوبتِ ردشده: {p.missed_turns}/{maxmiss} — به {maxmiss} که برسه از بازی حذف می‌شی.)")
        if r.pending_draw:
            lines.append("کارتِ جریمه‌دار یا «ویژه» بنداز، وگرنه باید بکشی.")
        lines.append("🚫 یعنی اون کارت الان قابلِ‌انداختن نیست.")
    else:
        lines.append(f"⏳ منتظرِ نوبتِ {_name(session, r.turn_user_id)}...")
    return "\n".join(lines)


async def _send_hand_dm(context, session, r, p) -> bool:
    my_turn = (r.turn_user_id == p.user_id)
    text = _hand_text(session, r, p, my_turn)
    kb = _hand_keyboard(r, p, my_turn)
    try:
        if p.dm_message_id:
            try:
                await context.bot.edit_message_text(
                    chat_id=p.user_id, message_id=p.dm_message_id, text=text, reply_markup=kb)
                return True
            except Exception:
                pass
        msg = await context.bot.send_message(p.user_id, text, reply_markup=kb)
        p.dm_message_id = msg.message_id
        session.commit()
        return True
    except Exception:
        return False


async def _refresh_all_dms(context, session, r):
    for p in _players(session, r.id):
        await _send_hand_dm(context, session, r, p)


# ---------------------------------------------------------------------------
# حرکت‌ها
# ---------------------------------------------------------------------------

async def _load_playing(session, update, rid):
    r = session.get(db.UnoRound, rid)
    if not r or r.status != "playing":
        await update.callback_query.answer("❌ این بازی دیگه فعال نیست.", show_alert=True)
        return None, None
    p = session.query(db.UnoPlayer).filter_by(round_id=rid, user_id=update.effective_user.id).first()
    if not p or p.eliminated:
        await update.callback_query.answer("❌ تو تو این بازی نیستی.", show_alert=True)
        return None, None
    return r, p


async def cb_uno_noop(update, context):
    await update.callback_query.answer("الان نوبتِ تو نیست.")


async def cb_uno_nope(update, context):
    await update.callback_query.answer("🚫 این کارت با کارتِ رو میز جور نیست.")


@with_round_lock
async def cb_uno_refresh(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r, p = await _load_playing(session, update, rid)
        if not r:
            return
        await _send_hand_dm(context, session, r, p)
        await update.callback_query.answer("بروزرسانی شد.")
    finally:
        session.close()


@with_round_lock
async def cb_uno_play(update, context):
    _, rid, idx = update.callback_query.data.split(":")
    rid, idx = int(rid), int(idx)
    session = db.get_session()
    try:
        r, p = await _load_playing(session, update, rid)
        if not r:
            return
        if r.turn_user_id != p.user_id:
            await update.callback_query.answer("⏳ الان نوبتِ تو نیست.", show_alert=True)
            return
        hand = _hand(p)
        if idx < 0 or idx >= len(hand):
            await update.callback_query.answer("❌ این کارت دیگه دستت نیست.", show_alert=True)
            return
        card = hand[idx]
        if not ue.can_play(card, r.discard_top, r.active_color, r.pending_draw or 0):
            await update.callback_query.answer("🚫 این کارت الان قابلِ‌انداختن نیست.", show_alert=True)
            return

        # کارت‌هایی که رنگ ندارن -> اول باید رنگ انتخاب شه
        if card in (ue.WILD, ue.WILD_DRAW4, ue.SPECIAL):
            rows = [[
                InlineKeyboardButton(f"{ue.COLOR_EMOJI[c]} {ue.COLOR_NAME[c]}",
                                     callback_data=f"uno_color:{rid}:{idx}:{c}")
                for c in ue.COLORS[:2]
            ], [
                InlineKeyboardButton(f"{ue.COLOR_EMOJI[c]} {ue.COLOR_NAME[c]}",
                                     callback_data=f"uno_color:{rid}:{idx}:{c}")
                for c in ue.COLORS[2:]
            ]]
            await update.callback_query.edit_message_text(
                f"🎨 با «{ue.card_label(card)}» چه رنگی رو انتخاب می‌کنی؟",
                reply_markup=InlineKeyboardMarkup(rows))
            return

        await _do_play(context, session, r, p, idx, chosen_color=None)
    finally:
        session.close()


@with_round_lock
async def cb_uno_color(update, context):
    _, rid, idx, color = update.callback_query.data.split(":")
    rid, idx = int(rid), int(idx)
    session = db.get_session()
    try:
        r, p = await _load_playing(session, update, rid)
        if not r:
            return
        if r.turn_user_id != p.user_id:
            await update.callback_query.answer("⏳ الان نوبتِ تو نیست.", show_alert=True)
            return
        hand = _hand(p)
        if idx < 0 or idx >= len(hand) or color not in ue.COLORS:
            await update.callback_query.answer("❌ انتخاب معتبر نیست.", show_alert=True)
            return
        await _do_play(context, session, r, p, idx, chosen_color=color)
    finally:
        session.close()


async def _do_play(context, session, r, p, idx, chosen_color):
    hand = _hand(p)
    card = hand.pop(idx)
    _set_hand(p, hand)

    if card == ue.SPECIAL:
        r.pending_draw = ue.apply_special(r.pending_draw or 0)
        r.active_color = chosen_color
    elif card in (ue.WILD, ue.WILD_DRAW4):
        r.pending_draw = (r.pending_draw or 0) + ue.card_draw_amount(card)
        r.active_color = chosen_color
    else:
        r.pending_draw = (r.pending_draw or 0) + ue.card_draw_amount(card)
        r.active_color = ue.card_color(card)
    r.discard_top = card
    p.missed_turns = 0
    r.last_action_at = _now()

    face = ue.card_face(card)
    extra_steps = 0
    if face == "R":
        alive = _players(session, r.id)
        if len(alive) == 2:
            extra_steps = 1  # تو بازیِ دونفره، «برعکس» عملاً یعنی ردکردنِ نوبتِ حریف
        else:
            r.direction = -(r.direction or 1)
    elif face == "S":
        extra_steps = 1

    # برنده؟
    if not hand:
        await _finish(context, session, r, winner=p)
        return

    session.commit()
    await _advance_turn(context, session, r, from_seat=p.seat, extra_steps=extra_steps)


@with_round_lock
async def cb_uno_draw(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r, p = await _load_playing(session, update, rid)
        if not r:
            return
        if r.turn_user_id != p.user_id:
            await update.callback_query.answer("⏳ الان نوبتِ تو نیست.", show_alert=True)
            return
        count = r.pending_draw or 1
        pile = _pile(r)
        history = [r.discard_top]
        drawn = ue.draw_cards(pile, count, history)
        hand = _hand(p)
        hand.extend(drawn)
        _set_hand(p, hand)
        _set_pile(r, pile)
        r.pending_draw = 0
        p.missed_turns = 0
        r.last_action_at = _now()
        session.commit()
        await update.callback_query.answer(f"🫳 {len(drawn)} کارت کشیدی.")
        await _advance_turn(context, session, r, from_seat=p.seat)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# گردشِ نوبت / تایم‌اوت
# ---------------------------------------------------------------------------

async def _finish_by_turn_limit(context, session, r):
    """بازی طولانی نشه: بعد از رسیدن به سقفِ نوبت‌ها (پیش‌فرض ۲۰)، به‌جایِ ادامه
    دادن، تعدادِ کارتِ باقی‌مونده‌ی هرکس مقایسه می‌شه - دقیقاً مثلِ اونویِ واقعی
    وقتی بازی طول می‌کشه: کمترین کارت می‌بره، مساوی بودن یعنی بازی مساویه (و
    طبقِ همون منطقِ همیشگیِ «بدونِ برنده»، مبلغِ همه برمی‌گرده)."""
    alive = _players(session, r.id)
    if not alive:
        await _finish(context, session, r, winner=None, intro="⏱ نوبت‌ها تموم شد.")
        return
    sizes = {p.id: len(_hand(p)) for p in alive}
    best = min(sizes.values())
    winners = [p for p in alive if sizes[p.id] == best]
    lines = ["⏱ سقفِ نوبت‌ها رسید! تعدادِ کارتِ باقی‌مونده:"]
    for p in sorted(alive, key=lambda p: sizes[p.id]):
        lines.append(f"  • {_name(session, p.user_id)}: {sizes[p.id]} کارت")
    intro = "\n".join(lines)
    if len(winners) == 1:
        await _finish(context, session, r, winner=winners[0], intro=intro)
    else:
        await _finish(context, session, r, winner=None, intro=intro + "\n\n🤝 مساوی شدن.")


async def _advance_turn(context, session, r, from_seat, extra_steps=0):
    alive = _players(session, r.id)
    if len(alive) <= 1:
        await _finish(context, session, r, winner=alive[0] if alive else None)
        return
    max_turns = _cfg_int(session, "uno_max_turns") or 20
    if (r.turn_seq or 0) >= max_turns:
        await _finish_by_turn_limit(context, session, r)
        return
    seats = [p.seat for p in alive]
    nxt = ue.next_seat(from_seat, seats, r.direction or 1, 1 + extra_steps)
    target = next(p for p in alive if p.seat == nxt)
    r.turn_user_id = target.user_id
    r.turn_seq = (r.turn_seq or 0) + 1
    r.turn_started_at = _now()
    secs = _cfg_int(session, "uno_turn_seconds") or 80
    r.turn_deadline_at = _now() + datetime.timedelta(seconds=secs)
    session.commit()
    await _render_group(context, session, r)
    await _refresh_all_dms(context, session, r)
    _schedule(context, _turn_timeout, r.id, secs, r.turn_seq)


async def _turn_timeout(context, rid, seq):
    """نوبتی که تو مهلت بازی نشد رد می‌شه. seq تضمین می‌کنه تایمرِ یه نوبتِ
    قدیمی (که از قبل بازی شده) نتونه نوبتِ فعلی رو اشتباهی رد کنه."""
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.UnoRound, rid)
            if not r or r.status != "playing" or (r.turn_seq or 0) != seq:
                return
            p = session.query(db.UnoPlayer).filter_by(round_id=rid, user_id=r.turn_user_id).first()
            if not p:
                return
            maxmiss = _cfg_int(session, "uno_max_missed_turns") or 2
            p.missed_turns = (p.missed_turns or 0) + 1
            from_seat = p.seat
            note = f"⏱ نوبتِ {_name(session, p.user_id)} رد شد ({p.missed_turns}/{maxmiss})."
            if p.missed_turns >= maxmiss:
                p.eliminated = True
                note = f"❌ {_name(session, p.user_id)} به‌خاطرِ {maxmiss} بار ردکردنِ نوبت از بازی حذف شد."
                # کارت‌هاش برمی‌گرده تو دسته تا بازیِ بقیه قفل نشه
                pile = _pile(r)
                pile.extend(_hand(p))
                random.shuffle(pile)
                _set_pile(r, pile)
                _set_hand(p, [])
                try:
                    await context.bot.send_message(p.user_id, note)
                except Exception:
                    pass
            session.commit()
            try:
                await context.bot.send_message(r.chat_id, note)
            except Exception:
                pass
            alive = _players(session, r.id)
            if len(alive) <= 1:
                await _finish(context, session, r, winner=alive[0] if alive else None)
                return
            await _advance_turn(context, session, r, from_seat=from_seat)
        finally:
            session.close()


async def _lobby_timeout(context, rid):
    async with _get_round_lock(rid):
        session = db.get_session()
        try:
            r = session.get(db.UnoRound, rid)
            if not r or r.status != "lobby":
                return
            players = _players(session, rid)
            if len(players) >= (r.target_players or 99):
                return
            await _refund_all(session, r)
            r.status = "cancelled"
            r.ended_at = _now()
            session.commit()
            if len(players) <= 1:
                txt = "❌ هیچکس نپیوست؛ بازیِ اونو لغو شد و مبلغ برگشت داده شد."
            else:
                txt = (f"❌ به تعداد کافی بازیکن نپیوست ({len(players)}/{r.target_players})؛ "
                       "بازی لغو شد و مبلغ‌ها برگشت داده شد.")
            await _edit_group(context, r, txt, None)
        finally:
            session.close()
            _round_locks.pop(rid, None)


async def _finish(context, session, r, winner, intro=""):
    all_players = _players(session, r.id, include_eliminated=True)
    pot = (r.entry_amount or 0) * len(all_players)
    r.status = "resolved"
    r.ended_at = _now()
    if winner:
        r.winner_id = winner.user_id
        u = session.get(db.User, winner.user_id)
        if u:
            u.hop_points = (u.hop_points or 0) + pot
        txt = (f"🏆 {_name(session, winner.user_id)} برنده‌ی اونو شد!\n\n"
               f"💰 جایزه: {fmt(pot)} 🪙")
    else:
        for p in all_players:
            u = session.get(db.User, p.user_id)
            if u and r.entry_amount:
                u.hop_points += r.entry_amount
        txt = "🤝 بازی بدونِ برنده تموم شد؛ مبلغِ همه برگشت داده شد."
    if intro:
        txt = f"{intro}\n\n{txt}"
    session.commit()
    await _edit_group(context, r, txt, None)
    for p in all_players:
        try:
            await context.bot.edit_message_text(
                chat_id=p.user_id, message_id=p.dm_message_id, text=txt, reply_markup=None)
        except Exception:
            try:
                await context.bot.send_message(p.user_id, txt)
            except Exception:
                pass
    _round_locks.pop(r.id, None)


# ---------------------------------------------------------------------------
# زمان‌بندی (با job_queue، وگرنه asyncio)
# ---------------------------------------------------------------------------

def _schedule(context, coro_fn, rid, delay, *args):
    async def runner():
        await asyncio.sleep(delay)
        try:
            await coro_fn(context, rid, *args)
        except Exception:
            pass
    asyncio.create_task(runner())


# ---------------------------------------------------------------------------
# جاروکشِ دورهای رهاشده (از jobs.tick_job صدا زده می‌شه)
# ---------------------------------------------------------------------------

async def tick_uno(session, context):
    """اگه ربات وسطِ یه بازی ری‌استارت شده باشه، تایمرهایِ درون‌حافظه‌ای از بین
    می‌رن و بازی برای همیشه گیر می‌کرد. این تیک (هر ۶۰ ثانیه) همون‌ها رو بر
    اساسِ deadlineِ ذخیره‌شده تو دیتابیس جمع می‌کنه."""
    now = _now()
    # مرحله‌ی setup (بازی ساخته شده - initiator مبلغ/تعدادِ نفرات رو می‌چینه -
    # ولی هیچ‌وقت «شروع» زده نشده، مثلاً پیامش رو پاک کرده و رفته): بدونِ این
    # جاروب، این دور برای همیشه «setup» می‌موند و چون user_has_active_uno این
    # وضعیت رو هم فعال حساب می‌کنه، initiator برای همیشه از ساختِ هر بازیِ
    # کازینوییِ دیگه‌ای (نه فقط اونو) قفل می‌شد - دقیقاً همون باگی که این جاروب
    # برای casino/battleship/guessnum/mastermind از قبل رفع شده بود، برای اونو
    # جا افتاده بود.
    stale_setup = (
        session.query(db.UnoRound)
        .filter(db.UnoRound.status == "setup")
        .all()
    )
    for r in stale_setup:
        ref = r.created_at
        if ref and (now - ref).total_seconds() >= SETUP_ABANDON_TIMEOUT_SECONDS:
            await _refund_all(session, r)
            r.status = "cancelled"
            r.ended_at = now
            session.commit()
            try:
                if r.message_id:
                    await context.bot.edit_message_text(
                        chat_id=r.chat_id, message_id=r.message_id,
                        text="⏳ این بازیِ اونو به‌خاطرِ عدمِ فعالیت لغو شد.")
            except Exception:
                pass

    stale_lobby = (
        session.query(db.UnoRound)
        .filter(db.UnoRound.status == "lobby")
        .all()
    )
    for r in stale_lobby:
        ref = r.lobby_opened_at or r.created_at
        limit = _cfg_int(session, "uno_lobby_timeout_seconds") or 200
        if ref and (now - ref).total_seconds() >= limit:
            await _lobby_timeout(context, r.id)

    stale_turns = (
        session.query(db.UnoRound)
        .filter(db.UnoRound.status == "playing", db.UnoRound.turn_deadline_at < now)
        .all()
    )
    for r in stale_turns:
        await _turn_timeout(context, r.id, r.turn_seq or 0)


# ---------------------------------------------------------------------------
# ورودیِ متنیِ منتظرِ مبلغِ دلخواه (m/b هم قبول می‌شه، دقیقاً مثلِ کازینو)
# ---------------------------------------------------------------------------

async def uno_awaiting_handler(update, context):
    state = context.user_data.get("uno_awaiting")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return
    text = (update.message.text or "").strip()
    parsed = parse_amount(text)
    if parsed is None or parsed != int(parsed) or parsed <= 0:
        context.user_data.pop("uno_awaiting", None)
        await update.message.reply_text("❌ مقدار اشتباه است (باید عددِ بزرگ‌تر از صفر باشه)؛ عملیات لغو شد.")
        return
    value = int(parsed)
    session = db.get_session()
    try:
        r = session.get(db.UnoRound, state["round_id"])
        if not r or r.status != "setup":
            context.user_data.pop("uno_awaiting", None)
            await update.message.reply_text("این بازی دیگه فعال نیست.")
            return
        import casino
        if casino.max_bet_exceeded(session, value):
            context.user_data.pop("uno_awaiting", None)
            await update.message.reply_text(
                f"❌ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست؛ عملیات لغو شد.")
            return
        r.entry_amount = value
        session.commit()
        context.user_data.pop("uno_awaiting", None)
        text_out, kb = _setup_text_kb(r)
        try:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.message_id, text=text_out, reply_markup=kb)
        except Exception:
            await context.bot.send_message(r.chat_id, text_out, reply_markup=kb)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مسیریاب
# ---------------------------------------------------------------------------

UNO_PREFIX_MAP = {
    "uno_new": cb_uno_new,
    "uno_amt": cb_uno_amt,
    "uno_amt_custom": cb_uno_amt_custom,
    "uno_setamt": cb_uno_setamt,
    "uno_plr": cb_uno_plr,
    "uno_setplr": cb_uno_setplr,
    "uno_back": cb_uno_back,
    "uno_cancel": cb_uno_cancel,
    "uno_start": cb_uno_start,
    "uno_join": cb_uno_join,
    "uno_leave": cb_uno_leave,
    "uno_play": cb_uno_play,
    "uno_color": cb_uno_color,
    "uno_draw": cb_uno_draw,
    "uno_refresh": cb_uno_refresh,
    "uno_noop": cb_uno_noop,
    "uno_nope": cb_uno_nope,
}


async def uno_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    handler = UNO_PREFIX_MAP.get(data.split(":")[0])
    if handler:
        await handler(update, context)
        return True
    return False
