# -*- coding: utf-8 -*-
"""تستِ مافیا/گرگینه با آبجکت‌هایِ جعلیِ تلگرام (بدونِ اینترنت / توکنِ واقعی)."""
import asyncio
import datetime
import os
import random
import tempfile

_tmp = tempfile.mkdtemp()
os.environ["DB_PATH"] = os.path.join(_tmp, "t.db")
os.environ["BOT_TOKEN"] = "1:x"
os.environ["OWNER_ID"] = "999"

import db  # noqa: E402
import casino  # noqa: E402
import mafia  # noqa: E402
import roulette  # noqa: E402
import uno  # noqa: E402
from telegram.ext import ApplicationHandlerStop  # noqa: E402

db.init_db()


# ---------------------------------------------------------------- fakes
class FakeBot:
    def __init__(self):
        self.edits = []
        self.sent = []
        self.deleted = []
        self.next_id = 5000
        self.fail_send_ids = set()   # user_id هایی که DM بهشون همیشه شکست می‌خوره
        self.transient = {}
        self.restricted = []   # [(chat_id, user_id, can_send_messages), ...]

    async def restrict_chat_member(self, chat_id=None, user_id=None, permissions=None, **kw):
        self.restricted.append((chat_id, user_id, getattr(permissions, "can_send_messages", None)))

    async def get_me(self):
        return FakeUser(1, username="hopbot")

    async def get_chat_member(self, chat_id, user_id):
        class _M:
            pass
        m = _M()
        if chat_id == mafia.SUPPORT_GROUP_HANDLE:
            m.status = "left" if user_id in getattr(self, "non_members", set()) else "member"
            return m
        if user_id == 1:   # خودِ بات
            m.status = "administrator"
            m.can_restrict_members = True
            m.can_send_messages = True
            return m
        last = None
        for c, u, allow in self.restricted:
            if c == chat_id and u == user_id:
                last = allow
        m.status = "member"
        m.can_restrict_members = False
        m.can_send_messages = True if last is None else last
        return m

    async def edit_message_text(self, chat_id=None, message_id=None, text=None, reply_markup=None, **kw):
        if self.transient.get(message_id, 0) > 0:
            self.transient[message_id] -= 1
            raise Exception("Timed out")
        if message_id in getattr(self, "fail_edit_ids", set()):
            raise Exception("Bad Request: message to edit not found")
        self.edits.append((chat_id, message_id, text, reply_markup))

    async def send_message(self, chat_id=None, text=None, reply_markup=None, **kw):
        if chat_id in self.fail_send_ids:
            raise Exception("Forbidden: bot was blocked by the user")
        self.next_id += 1
        self.sent.append((chat_id, text, self.next_id))
        return FakeMsg(chat_id, self.next_id)

    async def delete_message(self, chat_id=None, message_id=None):
        self.deleted.append((chat_id, message_id))

    def last_edit(self, message_id):
        for e in reversed(self.edits):
            if e[1] == message_id:
                return e
        for c, t, mid in reversed(self.sent):
            if mid == message_id:
                return (c, mid, t, None)
        return None

    def last_sent_to(self, chat_id):
        for c, t, mid in reversed(self.sent):
            if c == chat_id:
                return (c, t, mid)
        return None


class FakeMsg:
    def __init__(self, chat_id, message_id):
        self.chat_id = chat_id
        self.message_id = message_id


class FakeQuery:
    def __init__(self, bot, data, chat_id, message_id):
        self.bot = bot
        self.data = data
        self.message = FakeMsg(chat_id, message_id)
        self.answers = []

    async def answer(self, text=None, show_alert=False):
        self.answers.append((text, show_alert))

    async def edit_message_text(self, text, reply_markup=None):
        await self.bot.edit_message_text(self.message.chat_id, self.message.message_id, text, reply_markup)
        return FakeMsg(self.message.chat_id, self.message.message_id)


class FakeUser:
    def __init__(self, uid, username=None, first="U"):
        self.id = uid
        self.username = username or f"u{uid}"
        self.first_name = first or f"U{uid}"


class FakeChat:
    def __init__(self, cid, typ="supergroup"):
        self.id = cid
        self.type = typ


class FakeUpdate:
    def __init__(self, user, chat, query=None, text=None, reply_to=None):
        self.effective_user = user
        self.effective_chat = chat
        self.callback_query = query
        self.message = None
        if text is not None:
            self.message = FakeTextMessage(text, chat, reply_to, user)


class FakeTextMessage:
    def __init__(self, text, chat, reply_to, user):
        self.text = text
        self.chat = chat
        self.reply_to_message = reply_to
        self.replies = []

    async def reply_text(self, text, **kw):
        self.replies.append(text)


class FakeCtx:
    def __init__(self, bot):
        self.bot = bot
        self.user_data = {}
        self.job_queue = None


BOT = FakeBot()
CTX = {}
_msg_counter = [100]
passed = []


def ctx_for(uid):
    if uid not in CTX:
        CTX[uid] = FakeCtx(BOT)
    return CTX[uid]


def new_panel(chat_id):
    _msg_counter[0] += 1
    return _msg_counter[0]


def ok(name):
    passed.append(name)
    print("  ✓", name)


async def press(user, chat, msg_id, data):
    q = FakeQuery(BOT, data, chat.id, msg_id)
    upd = FakeUpdate(user, chat, q)
    if data.startswith("mf_"):
        assert await mafia.mf_callback_router(upd, ctx_for(user.id))
    elif data.startswith("rr_"):
        assert await roulette.rr_callback_router(upd, ctx_for(user.id))
    elif data.startswith("casino"):
        assert await casino.casino_callback_router(upd, ctx_for(user.id))
    else:
        raise AssertionError(data)
    return q


def mk_user(uid, balance):
    s = db.get_session()
    try:
        u = db.get_or_create_user(s, FakeUser(uid))
        u.hop_points = balance
        s.commit()
    finally:
        s.close()


def bal(uid):
    s = db.get_session()
    try:
        return db.get_or_create_user(s, FakeUser(uid)).hop_points
    finally:
        s.close()


def rnd(rid):
    s = db.get_session()
    try:
        r = s.get(db.MafiaRound, rid)
        s.expunge(r)
        return r
    finally:
        s.close()


def players_of(rid):
    s = db.get_session()
    try:
        return {p.user_id: (p.role, p.alive, p.out_reason) for p in mafia._all_players(s, rid)}
    finally:
        s.close()


def cancel_all_lobbies():
    s = db.get_session()
    for r in s.query(db.MafiaRound).filter(db.MafiaRound.status.in_(("lobby", "setup"))).all():
        r.status = "cancelled"
    s.commit()
    s.close()


def latest_round_id(mode=None):
    s = db.get_session()
    try:
        q = s.query(db.MafiaRound)
        if mode:
            q = q.filter_by(mode=mode)
        r = q.order_by(db.MafiaRound.id.desc()).first()
        return r.id
    finally:
        s.close()


def last_alert(q):
    return q.answers[-1] if q.answers else None


def dm_of(uid):
    s = db.get_session()
    try:
        p = s.query(db.MafiaPlayer).filter(db.MafiaPlayer.user_id == uid).order_by(db.MafiaPlayer.id.desc()).first()
        return p.dm_message_id if p else None
    finally:
        s.close()


def panel_for(rid, uid):
    """آخرین پنلِ فعالِ این بازیکن برای این دور رو برمی‌گردونه (dm_message_id)."""
    s = db.get_session()
    try:
        p = mafia._get_player(s, rid, uid)
        return p.dm_message_id if p else None
    finally:
        s.close()


async def setup_group_game(owner_id, n, chat_id, scenario="classic", stake=1000, extra_users=None):
    """یه بازیِ گروهیِ کامل تا مرحله‌ی شروعِ بازی (night) رو می‌سازه؛ (rid, uids, users, chat, panel)."""
    uids = [owner_id + i for i in range(n)]
    for u in uids:
        mk_user(u, 10_000_000)
    users = {u: FakeUser(u) for u in uids}
    chat = FakeChat(chat_id)
    panel = new_panel(chat.id)
    await press(users[owner_id], chat, panel, f"mf_new:{owner_id}")
    await press(users[owner_id], chat, panel, f"mf_mode_group:{owner_id}")
    await press(users[owner_id], chat, panel, f"mf_scn:{owner_id}:{scenario}")
    rid = latest_round_id("group")
    await press(users[owner_id], chat, panel, f"mf_amt_pick:{rid}:{stake}")
    await press(users[owner_id], chat, panel, f"mf_plr_pick:{rid}:{n}")
    await press(users[owner_id], chat, panel, f"mf_start:{rid}")
    for u in uids[1:]:
        await press(users[u], chat, panel, f"mf_join:{rid}")
    r = rnd(rid)
    assert r.status == "night", r.status
    return rid, uids, users, chat, panel


def role_map(rid):
    s = db.get_session()
    try:
        return {p.user_id: p.role for p in mafia._all_players(s, rid)}
    finally:
        s.close()


async def mafia_act(rid, users, roles, target_uid_or_skip):
    """همه‌ی مافیاهای زنده رو مجبور می‌کنه رویِ یه هدفِ مشترک رای بدن (یا رد کنن)."""
    r = rnd(rid)
    mafia_uids = [u for u, ro in roles.items() if ro == "mafia" and players_of(rid)[u][1]]
    for u in mafia_uids:
        panel = panel_for(rid, u)
        chat = FakeChat(u, "private")
        await press(users[u], chat, panel, f"mf_act:{rid}:{r.phase_seq}:{target_uid_or_skip}")


async def role_act(rid, users, roles, role_name, target_uid_or_skip):
    r = rnd(rid)
    uid = next((u for u, ro in roles.items() if ro == role_name and players_of(rid)[u][1]), None)
    if uid is None:
        return None
    panel = panel_for(rid, uid)
    chat = FakeChat(uid, "private")
    q = await press(users[uid], chat, panel, f"mf_act:{rid}:{r.phase_seq}:{target_uid_or_skip}")
    return q


async def _drain_day_speak(rid, users):
    """فازِ شیفتِ صحبتِ روز رو (اگه لابیِ محلی و فعال باشه) با زدنِ «ردِ نوبت» برایِ
    هرکس سریع رد می‌کنه تا برسیم به رای‌گیریِ واقعی - تستِ رای‌گیری/بردهایِ قدیمی
    دقیقاً همینو امتحان می‌کردن و نباید با اومدنِ این فازِ جدید بشکنن."""
    for _ in range(100):
        r = rnd(rid)
        if r.status != "day" or not r.day_speak_active:
            return
        order = mafia._day_speak_order_list(r)
        idx = r.day_speak_index or 0
        if idx >= len(order):
            return
        uid = order[idx]
        await press(users[uid], FakeChat(r.chat_id), r.day_speak_message_id, f"mf_dspass:{rid}:{r.day_speak_seq}")


async def do_vote(rid, users, uid, target_uid_or_zero):
    await _drain_day_speak(rid, users)
    r = rnd(rid)
    chat = FakeChat(-999999)  # گروه (نمی‌دونیم دقیقاً کدوم چت - برایِ کالبک مهم نیست)
    panel = panel_for(rid, uid) if rnd(rid).mode == "global" else rnd(rid).message_id
    return await press(users[uid], FakeChat(uid, "private") if rnd(rid).mode == "global" else chat, panel,
                       f"mf_vote:{rid}:{r.phase_seq}:{target_uid_or_zero}")


async def run_full_night(rid, users, roles, group_chat=None, mafia_target=0, doctor_target=None,
                          detective_target=None, bodyguard_target=None, sniper_target=None):
    """یه شب رو کامل با اقدام‌هایِ مشخص پیش می‌بره (هرکدوم None یعنی «رد کن»)."""
    r = rnd(rid)
    if r.status != "night":
        return
    await mafia_act(rid, users, roles, mafia_target if mafia_target is not None else 0)
    if "doctor" in roles.values():
        await role_act(rid, users, roles, "doctor", doctor_target if doctor_target is not None else 0)
    if "detective" in roles.values():
        await role_act(rid, users, roles, "detective", detective_target if detective_target is not None else 0)
    if "bodyguard" in roles.values():
        await role_act(rid, users, roles, "bodyguard", bodyguard_target if bodyguard_target is not None else 0)
    if "sniper" in roles.values():
        sniper_uid = next((u for u, ro in roles.items() if ro == "sniper"), None)
        if sniper_uid and not players_of(rid)[sniper_uid][1] is False:
            pl = players_of(rid).get(sniper_uid)
            if pl and pl[1]:  # زنده
                s_ = db.get_session()
                sp = mafia._get_player(s_, rid, sniper_uid)
                used = sp.sniper_used if sp else True
                s_.close()
                if not used:
                    await role_act(rid, users, roles, "sniper", sniper_target if sniper_target is not None else 0)


async def test_classic_group_full_game():
    print("test_classic_group_full_game")
    rid, uids, users, chat, panel = await setup_group_game(10000, 5, -500001, scenario="classic")
    roles = role_map(rid)
    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    doctor_uid = next(u for u, ro in roles.items() if ro == "doctor")
    detective_uid = next(u for u, ro in roles.items() if ro == "detective")
    citizens = [u for u, ro in roles.items() if ro == "citizen"]
    assert len(citizens) == 2 and sorted(roles.values()) == ["citizen", "citizen", "detective", "doctor", "mafia"]
    ok("classic 5p role distribution correct")

    # نامعتبر: مافیا نمی‌تونه خودش رو بزنه (نباید تو دکمه‌ها باشه، ولی مستقیم هم رد می‌شه)
    r = rnd(rid)
    mp = panel_for(rid, mafia_uid)
    q = await press(users[mafia_uid], FakeChat(mafia_uid, "private"), mp, f"mf_act:{rid}:{r.phase_seq}:{mafia_uid}")
    assert last_alert(q)[1] is True
    assert rnd(rid).status == "night"
    ok("mafia cannot target itself")

    # کارآگاه رویِ مافیا استعلام می‌گیره -> پیغامِ فوریِ «مافیاست»
    q = await role_act(rid, users, roles, "detective", mafia_uid)
    assert last_alert(q)[1] is False and "استعلام ثبت شد" in last_alert(q)[0]
    dtxt = dm_text(rid, detective_uid)
    assert "مافیاست" in dtxt and uname(mafia_uid) in dtxt, dtxt
    ok("detective result is written in the (now button-less) panel with the target's @id")
    # هر شب فقط یک استعلام: کلیکِ دوم رد می‌شه و انتخابِ اول عوض نمی‌شه
    q = await role_act(rid, users, roles, "detective", citizens[0])
    assert last_alert(q)[1] is True and "قبلاً" in last_alert(q)[0]
    assert "مافیاست" in dm_text(rid, detective_uid)
    ok("detective cannot inquire a second time in the same night")

    # دکتر رو یه شهروند رو نجات می‌ده (بی‌ربط چون مافیا یه شهروندِ دیگه رو می‌زنه)
    victim = citizens[0]
    saved = citizens[1]
    await role_act(rid, users, roles, "doctor", saved)
    await mafia_act(rid, users, roles, victim)
    r = rnd(rid)
    assert r.status == "day", r.status  # همه اقدام کردن -> زودتر تموم شد
    st = players_of(rid)
    assert st[victim][1] is False and "به دستِ مافیا کشته شد" in st[victim][2]
    assert st[saved][1] is True
    ok("early night resolution + doctor irrelevant save + mafia kill applied with reason")

    # رای‌گیریِ روز: همه رویِ مافیا رای می‌دن -> اعدام و شهر می‌بره
    alive = [u for u in uids if players_of(rid)[u][1]]
    for u in alive:
        await do_vote(rid, users, u, mafia_uid)
    r = rnd(rid)
    assert r.status == "resolved" and r.winner_side == "town"
    assert players_of(rid)[mafia_uid][1] is False
    win_amt = 1000 * mafia.WIN_MULTIPLIER
    for u in alive:
        if u != mafia_uid:
            assert bal(u) == 10_000_000 - 1000 + win_amt, (u, bal(u))
    assert bal(mafia_uid) == 10_000_000 - 1000
    assert bal(victim) == 10_000_000 - 1000  # حذف‌شده‌ی تیمِ بازنده هم چیزی نمی‌گیره چون تیمِ برنده نبود... صبر کن مافیا بود قربانی
    for u in uids:
        s = db.get_session()
        assert not casino._user_has_active_round(s, u)
        s.close()
    assert "شهر بردن" in BOT.last_edit(panel)[2]
    ok("day vote lynches mafia, town wins, winners paid 5.5x stake, mafia gets nothing, all released")


async def test_mafia_wins_by_parity():
    print("test_mafia_wins_by_parity")
    rid, uids, users, chat, panel = await setup_group_game(10100, 5, -500002, scenario="classic")
    roles = role_map(rid)
    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    others = [u for u in uids if u != mafia_uid]
    # سه شب پشتِ‌سرهم مافیا یکی از غیرمافیاها رو می‌زنه (بدونِ دکتر/کارآگاه دخالتی)
    killed = []
    for _ in range(10):
        r = rnd(rid)
        if r.status != "night":
            break
        st = players_of(rid)
        target = next(u for u in others if st[u][1])
        await run_full_night(rid, users, roles, mafia_target=target)
        r = rnd(rid)
        if r.status == "resolved":
            break
        # روز: هیچ‌کس رای نده (تساوی/بی‌رای) -> شب بعد
        alive = [u for u in uids if players_of(rid)[u][1]]
        for u in alive:
            await do_vote(rid, users, u, 0)
        killed.append(target)
    r = rnd(rid)
    assert r.status == "resolved" and r.winner_side == "mafia"
    assert bal(mafia_uid) == 10_000_000 - 1000 + 1000 * mafia.WIN_MULTIPLIER
    for u in killed:
        assert bal(u) == 10_000_000 - 1000
    ok("mafia reaches parity by repeated kills + no-lynch days, mafia wins, only mafia paid")


async def test_advanced_bodyguard_and_sniper():
    print("test_advanced_bodyguard_and_sniper")
    rid, uids, users, chat, panel = await setup_group_game(10200, 6, -500003, scenario="advanced")
    roles = role_map(rid)
    assert sorted(roles.values()) == sorted(["mafia", "detective", "bodyguard", "sniper", "citizen", "citizen"])
    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    bodyguard_uid = next(u for u, ro in roles.items() if ro == "bodyguard")
    sniper_uid = next(u for u, ro in roles.items() if ro == "sniper")
    detective_uid = next(u for u, ro in roles.items() if ro == "detective")
    citizen_uid = next(u for u, ro in roles.items() if ro == "citizen")

    # شبِ اول: محافظ از یه شهروند دفاع می‌کنه، مافیا میره سراغِ همون بنده‌خدا -> محافظ به‌جاش می‌میره
    await role_act(rid, users, roles, "bodyguard", citizen_uid)
    await mafia_act(rid, users, roles, citizen_uid)
    # تک‌تیرانداز این شب رد می‌کنه، کارآگاه هم رد می‌کنه (پارامترهایِ پیش‌فرضِ None -> ۰)
    await role_act(rid, users, roles, "sniper", 0)
    await role_act(rid, users, roles, "detective", 0)
    r = rnd(rid)
    assert r.status == "day", r.status
    st = players_of(rid)
    assert st[bodyguard_uid][1] is False and "محافظت" in st[bodyguard_uid][2]
    assert st[citizen_uid][1] is True
    ok("bodyguard dies in place of the protected target")

    # هیچ‌کس رای نمی‌ده -> شبِ بعد
    for u in [u for u in uids if players_of(rid)[u][1]]:
        await do_vote(rid, users, u, 0)
    r = rnd(rid)
    assert r.status == "night"

    # شبِ دوم: تک‌تیرانداز مافیا رو می‌زنه (شلیکِ همیشه‌کشنده) -> شهر می‌بره
    await mafia_act(rid, users, roles, 0)  # مافیا رد می‌کنه (بی‌ربط، تک‌تیرانداز قبلش عمل می‌کنه)
    if detective_uid in players_of(rid) and players_of(rid)[detective_uid][1]:
        await role_act(rid, users, roles, "detective", 0)
    q = await role_act(rid, users, roles, "sniper", mafia_uid)
    assert last_alert(q)[0] and "هدف درست بود" not in last_alert(q)[0]  # توستِ خودِ شلیک، نه نتیجه
    r = rnd(rid)
    assert r.status == "resolved" and r.winner_side == "town"
    st = players_of(rid)
    assert st[mafia_uid][1] is False and "تک‌تیرانداز" in st[mafia_uid][2] and "هدف درست بود" in st[mafia_uid][2]
    ok("sniper's unconditional shot kills mafia (bypasses no protection), town wins")

    # تک‌تیرانداز دیگه گلوله نداره -> پنلش تو شبِ بعدی (اگه بازی ادامه داشت) نباید نمایش داده بشه
    s = db.get_session()
    sp = mafia._get_player(s, rid, sniper_uid)
    assert sp.sniper_used is True
    s.close()


async def test_sniper_misfire_kills_innocent():
    print("test_sniper_misfire_kills_innocent")
    rid, uids, users, chat, panel = await setup_group_game(10300, 6, -500004, scenario="advanced")
    roles = role_map(rid)
    citizen_uid = next(u for u, ro in roles.items() if ro == "citizen")
    await mafia_act(rid, users, roles, 0)
    await role_act(rid, users, roles, "bodyguard", 0)
    await role_act(rid, users, roles, "detective", 0)
    q = await role_act(rid, users, roles, "sniper", citizen_uid)
    r = rnd(rid)
    st = players_of(rid)
    assert st[citizen_uid][1] is False and "هدف اشتباه بود" in st[citizen_uid][2]
    ok("sniper misfire kills an innocent target, reason recorded")


async def test_quick_scenario_no_detective():
    print("test_quick_scenario_no_detective")
    rid, uids, users, chat, panel = await setup_group_game(10400, 5, -500005, scenario="quick")
    roles = role_map(rid)
    assert "detective" not in roles.values()
    assert sorted(roles.values()) == ["citizen", "citizen", "citizen", "doctor", "mafia"]
    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    doctor_uid = next(u for u, ro in roles.items() if ro == "doctor")
    other = next(u for u in uids if roles[u] == "citizen")
    # دکتر خودِ هدف رو نجات می‌ده
    await role_act(rid, users, roles, "doctor", other)
    await mafia_act(rid, users, roles, other)
    r = rnd(rid)
    assert r.status == "day"
    st = players_of(rid)
    assert st[other][1] is True  # نجات پیدا کرد
    assert all(st[u][1] for u in uids)  # هیچ‌کس نمرد
    ok("quick scenario: no detective role, doctor save prevents the kill")


async def test_psycho_win_by_lynch():
    print("test_psycho_win_by_lynch")
    rid, uids, users, chat, panel = await setup_group_game(10500, 5, -500006, scenario="psycho")
    roles = role_map(rid)
    assert "psycho" in roles.values()
    psycho_uid = next(u for u, ro in roles.items() if ro == "psycho")
    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    await mafia_act(rid, users, roles, 0)
    if "doctor" in roles.values():
        await role_act(rid, users, roles, "doctor", 0)
    r = rnd(rid)
    assert r.status == "day"
    for u in [u for u in uids if players_of(rid)[u][1]]:
        await do_vote(rid, users, u, psycho_uid)
    r = rnd(rid)
    assert r.status == "resolved" and r.winner_side == "psycho"
    assert bal(psycho_uid) == 10_000_000 - 1000 + 1000 * mafia.WIN_MULTIPLIER
    for u in uids:
        if u != psycho_uid:
            assert bal(u) == 10_000_000 - 1000, u  # نه شهر نه مافیا چیزی گرفتن
    assert players_of(rid)[psycho_uid][1] is False
    assert "روانی" in BOT.last_edit(panel)[2] and "برد" in BOT.last_edit(panel)[2]
    ok("psycho lynched -> instant solo win, everyone else just loses their stake")


async def test_psycho_gets_nothing_if_town_wins_normally():
    print("test_psycho_gets_nothing_if_town_wins_normally")
    rid, uids, users, chat, panel = await setup_group_game(10600, 5, -500007, scenario="psycho")
    roles = role_map(rid)
    psycho_uid = next(u for u, ro in roles.items() if ro == "psycho")
    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    await mafia_act(rid, users, roles, 0)
    if "doctor" in roles.values():
        await role_act(rid, users, roles, "doctor", 0)
    r = rnd(rid)
    for u in [u for u in uids if players_of(rid)[u][1]]:
        await do_vote(rid, users, u, mafia_uid)   # مافیا اعدام می‌شه، نه روانی
    r = rnd(rid)
    assert r.status == "resolved" and r.winner_side == "town"
    assert bal(psycho_uid) == 10_000_000 - 1000, "روانی نه تو تیمِ برنده‌ست نه بازنده - نباید چیزی بگیره"
    ok("psycho survives town's normal win but gets nothing (not on winning team)")


async def test_draw_finish_path():
    print("test_draw_finish_path")
    # با قوانینِ فعلی (مافیا با برابری فوراً می‌بره)، مساوی‌شدنِ واقعی از دلِ یه بازیِ
    # عادی پیش نمی‌آد؛ ولی مسیرِ کدِ "مساوی" (برایِ قوانین/نقش‌هایِ آینده) رو مستقیم تست
    # می‌کنیم تا مطمئن باشیم اگه یه‌جا برسه، درست پول برمی‌گردونه.
    rid, uids, users, chat, panel = await setup_group_game(10700, 5, -500008, scenario="classic")
    before = {u: bal(u) for u in uids}
    s = db.get_session()
    r = s.get(db.MafiaRound, rid)
    players = mafia._all_players(s, rid)
    for p in players:
        p.alive = False
        p.out_reason = "برای تستِ مستقیمِ مسیرِ مساوی حذف شد"
    s.commit()
    win = mafia._check_win(mafia._all_players(s, rid))
    assert win == "draw"
    s.close()

    session2 = db.get_session()
    r2 = session2.get(db.MafiaRound, rid)
    await mafia._finish_game(ctx_for(uids[0]), session2, r2, "draw")
    session2.close()
    r3 = rnd(rid)
    assert r3.status == "resolved" and r3.winner_side == "draw"
    for u in uids:
        assert bal(u) == before[u] + 1000  # هرکی زنده بود سهمش برنمی‌گرده - همه‌شون این‌جا مرده بودن، پس فقط رفاندِ اصلی
    ok("_finish_game('draw') path refunds every player's stake correctly")


async def test_day_vote_tie_no_lynch():
    print("test_day_vote_tie_no_lynch")
    rid, uids, users, chat, panel = await setup_group_game(10800, 6, -500009, scenario="classic")
    roles = role_map(rid)
    await mafia_act(rid, users, roles, 0)
    if "doctor" in roles.values():
        await role_act(rid, users, roles, "doctor", 0)
    if "detective" in roles.values():
        await role_act(rid, users, roles, "detective", 0)
    r = rnd(rid)
    assert r.status == "day"
    alive = uids  # هیچ‌کس نمرده هنوز
    # ۶ نفر، سه گروهِ دوتایی روی سه هدفِ مختلف: هیچ‌کس به حدِ نصابِ ۳ رای نمی‌رسه
    for i, u in enumerate(alive):
        await do_vote(rid, users, u, alive[5 - (i // 2)])
    r = rnd(rid)
    assert r.status == "night" and r.day_number == 2
    for u in alive:
        assert players_of(rid)[u][1] is True
    assert "تساوی" in r.log_text or "کسی اعدام نشد" in r.log_text
    ok("tied day vote -> nobody lynched, game proceeds to next night")


async def test_no_lynch_when_all_abstain():
    print("test_no_lynch_when_all_abstain")
    rid, uids, users, chat, panel = await setup_group_game(10900, 5, -500010, scenario="quick")
    roles = role_map(rid)
    await mafia_act(rid, users, roles, 0)
    if "doctor" in roles.values():
        await role_act(rid, users, roles, "doctor", 0)
    r = rnd(rid)
    for u in uids:
        await do_vote(rid, users, u, 0)
    r = rnd(rid)
    assert r.status == "night" and r.day_number == 2
    ok("everyone abstains -> nobody lynched")


async def test_afk_night_timeout_resolves_with_partial_actions():
    print("test_afk_night_timeout_resolves_with_partial_actions")
    rid, uids, users, chat, panel = await setup_group_game(11000, 5, -500011, scenario="classic")
    roles = role_map(rid)
    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    citizens = [u for u in uids if roles[u] == "citizen"]
    # فقط مافیا اقدام می‌کنه؛ دکتر و کارآگاه هیچی نمی‌زنن (AFK)
    await mafia_act(rid, users, roles, citizens[0])
    r = rnd(rid)
    assert r.status == "night"  # هنوز منتظرِ دکتر/کارآگاهه
    s = db.get_session()
    x = s.get(db.MafiaRound, rid)
    x.phase_deadline_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
    s.commit()
    s.close()
    await mafia._night_timeout(ctx_for(mafia_uid), rid, r.phase_seq)
    r2 = rnd(rid)
    assert r2.status == "day"
    st = players_of(rid)
    assert st[citizens[0]][1] is False
    ok("night timeout resolves with only submitted actions (AFK roles just skip)")

    # تایمرِ قدیمی (seq اشتباه) نباید دوباره اجرا بشه
    await mafia._night_timeout(ctx_for(mafia_uid), rid, r.phase_seq)
    assert rnd(rid).status == "day"
    ok("stale night timer is ignored")


async def test_day_vote_timeout():
    print("test_day_vote_timeout")
    rid, uids, users, chat, panel = await setup_group_game(11100, 5, -500012, scenario="quick")
    roles = role_map(rid)
    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    await mafia_act(rid, users, roles, 0)
    if "doctor" in roles.values():
        await role_act(rid, users, roles, "doctor", 0)
    r = rnd(rid)
    assert r.status == "day"
    alive = [u for u in uids if players_of(rid)[u][1]]
    for u in alive[:-1]:
        await do_vote(rid, users, u, mafia_uid)
    r = rnd(rid)  # do_vote ممکنه فازِ شیفتِ صحبت رو رد کرده باشه و phase_seq رو عوض کرده باشه
    # آخری رای نمی‌ده؛ تایم‌اوت باید با همین رای‌ها تصمیم بگیره
    s = db.get_session()
    x = s.get(db.MafiaRound, rid)
    x.phase_deadline_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
    s.commit()
    s.close()
    await mafia._day_timeout(ctx_for(mafia_uid), rid, r.phase_seq)
    r2 = rnd(rid)
    assert r2.status == "resolved" and r2.winner_side == "town"
    ok("day vote timeout resolves with partial votes")


async def test_custom_amount_and_setup_cancel():
    print("test_custom_amount_and_setup_cancel")
    mk_user(11200, 5_000_000)
    u = FakeUser(11200)
    chat = FakeChat(-500013)
    panel = new_panel(chat.id)
    await press(u, chat, panel, "mf_new:11200")
    await press(u, chat, panel, "mf_mode_group:11200")
    await press(u, chat, panel, "mf_scn:11200:classic")
    rid = latest_round_id("group")
    ctx = ctx_for(11200)

    await press(u, chat, panel, f"mf_amt_menu:{rid}")
    await press(u, chat, panel, f"mf_amt_custom:{rid}")
    assert ctx.user_data.get("mf_awaiting")
    await press(u, chat, panel, f"mf_amtx:{rid}")
    assert not ctx.user_data.get("mf_awaiting")
    assert rnd(rid).status == "setup"
    ok("custom-amount cancel returns to setup, round alive")

    await press(u, chat, panel, f"mf_amt_menu:{rid}")
    await press(u, chat, panel, f"mf_amt_custom:{rid}")
    upd = FakeUpdate(u, chat, text="abc")
    try:
        await mafia.mf_awaiting_handler(upd, ctx)
        raise AssertionError("expected Stop")
    except ApplicationHandlerStop:
        pass
    e = BOT.last_edit(panel)
    assert "مقدار اشتباه" in e[2] and rnd(rid).entry_amount is None
    ok("invalid custom amount restores setup panel with error")

    await press(u, chat, panel, f"mf_amt_menu:{rid}")
    await press(u, chat, panel, f"mf_amt_custom:{rid}")
    upd = FakeUpdate(u, chat, text="3m")
    try:
        await mafia.mf_awaiting_handler(upd, ctx)
    except ApplicationHandlerStop:
        pass
    assert rnd(rid).entry_amount == 3_000_000
    ok("valid custom amount (3m) accepted")

    await press(u, chat, panel, f"mf_plr_pick:{rid}:7")
    assert rnd(rid).target_players == 7
    q = await press(u, chat, panel, f"mf_plr_pick:{rid}:20")
    assert last_alert(q)[1] is True and rnd(rid).target_players == 7
    ok("player-count outside 5..8 rejected in group setup")

    await press(u, chat, panel, f"mf_back:{rid}")
    assert rnd(rid).status == "cancelled"
    assert "کجا بازی کنیم" in BOT.last_edit(panel)[2]
    s = db.get_session()
    assert not casino._user_has_active_round(s, 11200)
    s.close()
    ok("back from setup cancels round, shows mode menu, user released")


async def test_group_lobby_timeout_no_hopoo():
    print("test_group_lobby_timeout_no_hopoo")
    mk_user(11300, 1_000_000)
    u = FakeUser(11300)
    chat = FakeChat(-500014)
    panel = new_panel(chat.id)
    await press(u, chat, panel, "mf_new:11300")
    await press(u, chat, panel, "mf_mode_group:11300")
    await press(u, chat, panel, "mf_scn:11300:quick")
    rid = latest_round_id("group")
    await press(u, chat, panel, f"mf_amt_pick:{rid}:500")
    await press(u, chat, panel, f"mf_plr_pick:{rid}:5")
    await press(u, chat, panel, f"mf_start:{rid}")
    assert bal(11300) == 999_500
    s = db.get_session()
    x = s.get(db.MafiaRound, rid)
    x.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=mafia.LOBBY_SECONDS + 1)
    s.commit()
    s.close()
    await mafia._lobby_timeout(ctx_for(11300), rid)
    assert rnd(rid).status == "cancelled" and bal(11300) == 1_000_000
    assert "هیچ هاپویی نیومد" in BOT.last_edit(panel)[2]
    s = db.get_session()
    assert not casino._user_has_active_round(s, 11300)
    s.close()
    ok("group lobby with only the creator times out -> 'nobody came', refund, released")

    # لابیِ نیمه‌پر
    panel2 = new_panel(chat.id)
    mk_user(11301, 1_000_000)
    await press(u, chat, panel2, "mf_new:11300")
    await press(u, chat, panel2, "mf_mode_group:11300")
    await press(u, chat, panel2, "mf_scn:11300:quick")
    rid2 = latest_round_id("group")
    await press(u, chat, panel2, f"mf_amt_pick:{rid2}:500")
    await press(u, chat, panel2, f"mf_plr_pick:{rid2}:6")
    await press(u, chat, panel2, f"mf_start:{rid2}")
    await press(FakeUser(11301), chat, panel2, f"mf_join:{rid2}")
    s = db.get_session()
    x = s.get(db.MafiaRound, rid2)
    x.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=mafia.LOBBY_SECONDS + 1)
    s.commit()
    s.close()
    await mafia._lobby_timeout(ctx_for(11300), rid2)
    e = BOT.last_edit(panel2)
    assert "(2/6)" in e[2] and "هیچ هاپویی" not in e[2]
    assert bal(11300) == 1_000_000 and bal(11301) == 1_000_000
    ok("partial group lobby timeout: correct wording, everyone refunded")


async def test_creator_cancel_and_leave():
    print("test_creator_cancel_and_leave")
    rid = None
    mk_user(11400, 1_000_000)
    mk_user(11401, 1_000_000)
    u1, u2 = FakeUser(11400), FakeUser(11401)
    chat = FakeChat(-500015)
    panel = new_panel(chat.id)
    await press(u1, chat, panel, "mf_new:11400")
    await press(u1, chat, panel, "mf_mode_group:11400")
    await press(u1, chat, panel, "mf_scn:11400:quick")
    rid = latest_round_id("group")
    await press(u1, chat, panel, f"mf_amt_pick:{rid}:500")
    await press(u1, chat, panel, f"mf_plr_pick:{rid}:5")
    await press(u1, chat, panel, f"mf_start:{rid}")
    await press(u2, chat, panel, f"mf_join:{rid}")
    # عضوِ عادی نمی‌تونه لغو کنه؛ سازنده هم نمی‌تونه "ترک" بزنه
    q = await press(u2, chat, panel, f"mf_cancel:{rid}")
    assert last_alert(q)[1] is True and rnd(rid).status == "lobby"
    q = await press(u1, chat, panel, f"mf_leave:{rid}")
    assert last_alert(q)[1] is True
    # عضو ترک می‌کنه
    await press(u2, chat, panel, f"mf_leave:{rid}")
    assert bal(11401) == 1_000_000 and "(1/5)" in BOT.last_edit(panel)[2]
    # سازنده لغو می‌کنه
    await press(u1, chat, panel, f"mf_cancel:{rid}")
    assert rnd(rid).status == "cancelled" and bal(11400) == 1_000_000
    ok("only creator can cancel, only non-creator can leave, refunds correct")


async def test_busy_lock_with_other_casino_games():
    print("test_busy_lock_with_other_casino_games")
    mk_user(11500, 1_000_000)
    u = FakeUser(11500)
    chat = FakeChat(-500016)
    panel = new_panel(chat.id)
    await press(u, chat, panel, "mf_new:11500")
    await press(u, chat, panel, "mf_mode_group:11500")
    await press(u, chat, panel, "mf_scn:11500:quick")
    rid = latest_round_id("group")
    # وسطِ setup مافیا نمی‌تونه رولت هم باز کنه
    p2 = new_panel(chat.id)
    q = await press(u, chat, p2, "rr_new:11500")
    assert last_alert(q)[0].startswith("⛔️ تو همین الان")
    # کازینوی کلاسیک هم همینطور
    p3 = new_panel(chat.id)
    q = await press(u, chat, p3, "casino_game:bw:11500")
    assert last_alert(q)[0].startswith("⛔️ تو همین الان")
    await press(u, chat, panel, f"mf_cancel:{rid}")
    q = await press(u, chat, p3, "casino_game:bw:11500")
    s = db.get_session()
    assert casino._user_has_active_round(s, 11500) is True
    s.close()
    q = await press(u, chat, new_panel(chat.id), "mf_new:11500")
    assert last_alert(q)[0].startswith("⛔️ تو همین الان")
    ok("mafia setup blocks/blocked-by other casino games")


async def test_dm_unreachable_aborts_game():
    print("test_dm_unreachable_aborts_game")
    uids = [11600, 11601, 11602, 11603, 11604]
    for u in uids:
        mk_user(u, 1_000_000)
    users = {u: FakeUser(u) for u in uids}
    chat = FakeChat(-500017)
    panel = new_panel(chat.id)
    await press(users[11600], chat, panel, "mf_new:11600")
    await press(users[11600], chat, panel, "mf_mode_group:11600")
    await press(users[11600], chat, panel, "mf_scn:11600:quick")
    rid = latest_round_id("group")
    await press(users[11600], chat, panel, f"mf_amt_pick:{rid}:500")
    await press(users[11600], chat, panel, f"mf_plr_pick:{rid}:5")
    await press(users[11600], chat, panel, f"mf_start:{rid}")
    BOT.fail_send_ids.add(11603)  # این یکی هیچ‌وقت ربات رو استارت نکرده
    for u in uids[1:]:
        await press(users[u], chat, panel, f"mf_join:{rid}")
    r = rnd(rid)
    assert r.status == "cancelled"
    for u in uids:
        assert bal(u) == 1_000_000
        s = db.get_session()
        assert not casino._user_has_active_round(s, u)
        s.close()
    assert "پیوی" in BOT.last_edit(panel)[2] or "استارت نکرده" in BOT.last_edit(panel)[2]
    BOT.fail_send_ids.discard(11603)
    ok("unreachable player at game start aborts + refunds everyone, all released")




async def test_global_matchmaking_basic():
    print("test_global_matchmaking_basic")
    uids = [12000, 12001, 12002, 12003, 12004]
    for u in uids:
        mk_user(u, 1_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-600000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    T = mafia.GLOBAL_TIERS[0]

    await press(users[12000], chats[12000], panels[12000], "mf_new:12000")
    kb0 = BOT.last_edit(panels[12000])[3]
    assert any("لابی تو همین گروه" in b.text for row in kb0.inline_keyboard for b in row)
    await press(users[12000], chats[12000], panels[12000], "mf_mode_global:12000")
    assert "یه سناریو" in BOT.last_edit(panels[12000])[2]
    await press(users[12000], chats[12000], panels[12000], "mf_gscn:12000:classic")
    kb = BOT.last_edit(panels[12000])[3]
    labels = [b.text for row in kb.inline_keyboard for b in row]
    assert any(mafia.fmt(T) in l for l in labels)
    await press(users[12000], chats[12000], panels[12000], f"mf_gtier:12000:classic:{T}")
    kb = BOT.last_edit(panels[12000])[3]
    assert [b.text for b in kb.inline_keyboard[0]] == [f"👥 {n} نفره" for n in mafia.GLOBAL_PLAYER_TIERS]
    ok("global entry flow: mode -> scenario -> stake tier -> player-count tier (5/8/11)")

    # میزِ نامعتبر
    q = await press(users[12000], chats[12000], panels[12000], "mf_gjoin:12000:classic:12345:5")
    assert last_alert(q)[1] is True and bal(12000) == 1_000_000_000
    q = await press(users[12000], chats[12000], panels[12000], f"mf_gjoin:12000:classic:{T}:6")
    assert last_alert(q)[1] is True  # ۶ جزوِ ۵/۸/۱۱ نیست
    ok("tampered tier/count rejected")

    for u in uids:
        await press(users[u], chats[u], panels[u], f"mf_gjoin:{u}:classic:{T}:5")
    rid = latest_round_id("global")
    r = rnd(rid)
    assert r.status == "night" and r.mode == "global"
    roles = role_map(rid)
    assert sorted(roles.values()) == ["citizen", "citizen", "detective", "doctor", "mafia"]
    for u in uids:
        assert bal(u) == 1_000_000_000 - T
    ok("5 players queue for the same scenario/stake/count -> matched into one game")

    # پنلِ شخصیِ هرکس: نقش‌دار پنلِ اقدام داره، بقیه وضعیتِ عمومی
    for u in uids:
        e = BOT.last_edit(panel_for(rid, u))
        if roles[u] in mafia.NIGHT_ACTION_ROLES:
            assert e[3] is not None, (u, roles[u])
        else:
            assert "منتظرِ بقیه" in e[2]
    ok("global mode: personal DM panels per role, action buttons only for actionable roles")

    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    citizens = [u for u, ro in roles.items() if ro == "citizen"]
    r = rnd(rid)
    await role_act(rid, users, roles, "doctor", 0)
    await role_act(rid, users, roles, "detective", 0)
    await mafia_act(rid, users, roles, citizens[0])
    r = rnd(rid)
    assert r.status == "day" and r.day_speak_active, "روزِ جهانی هم اول نوبتِ صحبت داره"
    for u in uids:
        e = BOT.last_edit(panel_for(rid, u))
        assert "نوبت" in e[2] or "حذف شدی" in e[2]
    await _drain_day_speak(rid, users)
    r = rnd(rid)
    assert r.status == "day" and not r.day_speak_active
    for u in uids:
        e = BOT.last_edit(panel_for(rid, u))
        assert "رای‌گیری" in e[2] or "حذف شدی" in e[2]
    ok("global day phase: speak turns first, then every player's own panel shows the vote UI")

    alive = [u for u in uids if players_of(rid)[u][1]]
    for u in alive:
        await do_vote(rid, users, u, mafia_uid)
    r = rnd(rid)
    assert r.status == "resolved" and r.winner_side == "town"
    for u in uids:
        e = BOT.last_edit(panel_for(rid, u))
        assert "پایانِ بازی" in e[2]
    win_amt = T * mafia.WIN_MULTIPLIER
    for u in alive:
        if u != mafia_uid:
            assert bal(u) == 1_000_000_000 - T + win_amt
    ok("global game resolves fully with correct payouts, all panels show final result")
    for u in uids:
        s = db.get_session()
        assert not casino._user_has_active_round(s, u)
        s.close()


async def test_global_leave_and_partial_matching():
    print("test_global_leave_and_partial_matching")
    uids = [12100, 12101, 12102]
    for u in uids:
        mk_user(u, 1_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-610000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    T = mafia.GLOBAL_TIERS[1]

    await press(users[12100], chats[12100], panels[12100], f"mf_gjoin:12100:quick:{T}:8")
    rid = latest_round_id("global")
    assert bal(12100) == 1_000_000_000 - T
    assert "(1/8)" in BOT.last_edit(panel_for(rid, 12100))[2]

    # سناریوی متفاوت -> میزِ جدید
    await press(users[12101], chats[12101], panels[12101], f"mf_gjoin:12101:classic:{T}:8")
    rid2 = latest_round_id("global")
    assert rid2 != rid
    q = await press(users[12101], chats[12101], panels[12101], f"mf_gleave:{rid2}:12101")
    assert bal(12101) == 1_000_000_000 and rnd(rid2).status == "cancelled"
    ok("different scenario => separate table; last leaver cancels the empty table")

    # همون سناریو/مبلغ/تعداد -> با هم می‌افتن
    await press(users[12101], chats[12101], panels[12101], f"mf_gjoin:12101:quick:{T}:8")
    assert len(players_of(rid)) == 2 and 12101 in players_of(rid)
    assert "(2/8)" in BOT.last_edit(panel_for(rid, 12100))[2] and "(2/8)" in BOT.last_edit(panel_for(rid, 12101))[2]
    ok("same scenario+stake+count matchmake together, counters update on everyone's panel")

    # منصرف‌شدنِ کسی که تنها نیست: برایِ بقیه شمارنده کم می‌شه، خودش آزاد می‌شه
    q = await press(users[12100], chats[12100], panels[12100], f"mf_gleave:{rid}:12100")
    assert last_alert(q)[1] is False
    assert bal(12100) == 1_000_000_000 and len(players_of(rid)) == 1
    assert "(1/8)" in BOT.last_edit(panel_for(rid, 12101))[2]
    s = db.get_session()
    assert not casino._user_has_active_round(s, 12100)
    s.close()
    ok("leaving a non-empty global lobby refunds + releases, others see updated count")

    # کسِ دیگه نمی‌تونه دکمه‌ی «منصرف شدم»ِ مالِ یکی دیگه رو بزنه
    await press(users[12100], chats[12100], panels[12100], f"mf_gjoin:12100:quick:{T}:8")
    q = await press(users[12102], chats[12102], panels[12102], f"mf_gleave:{rid}:12100")
    assert last_alert(q)[1] is True
    ok("gleave button is restricted to its own owner")


async def test_global_near_expiry_not_offered():
    print("test_global_near_expiry_not_offered")
    uids = [12200, 12201]
    for u in uids:
        mk_user(u, 1_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-620000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    T = mafia.GLOBAL_TIERS[2]
    await press(users[12200], chats[12200], panels[12200], f"mf_gjoin:12200:classic:{T}:8")
    rid_old = latest_round_id("global")
    s = db.get_session()
    x = s.get(db.MafiaRound, rid_old)
    x.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(
        seconds=mafia.GLOBAL_WAIT_SECONDS - mafia.GLOBAL_JOIN_MIN_REMAINING + 5)
    s.commit()
    s.close()
    await press(users[12201], chats[12201], panels[12201], f"mf_gjoin:12201:classic:{T}:8")
    rid_new = latest_round_id("global")
    assert rid_new != rid_old
    ok("table close to its cancel deadline is not offered to a new joiner")


async def test_global_lobby_timeout_and_full_but_unstarted():
    print("test_global_lobby_timeout_and_full_but_unstarted")
    uids = [12300, 12301]
    for u in uids:
        mk_user(u, 1_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-630000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    T = mafia.GLOBAL_TIERS[0]
    await press(users[12300], chats[12300], panels[12300], f"mf_gjoin:12300:quick:{T}:11")
    rid = latest_round_id("global")
    await press(users[12301], chats[12301], panels[12301], f"mf_gjoin:12301:quick:{T}:11")
    s = db.get_session()
    x = s.get(db.MafiaRound, rid)
    x.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=mafia.GLOBAL_WAIT_SECONDS + 1)
    s.commit()
    s.close()
    await mafia.tick_mafia(db.get_session(), ctx_for(12300))
    assert rnd(rid).status == "cancelled"
    assert bal(12300) == 1_000_000_000 and bal(12301) == 1_000_000_000
    for u in uids:
        e = BOT.last_edit(panel_for(rid, u))
        assert "لغو" in e[2]
    ok("11-player global table times out cleanly (mins/tiers), both panels updated, refunded")

    # لابیِ پر ولی شروع‌نشده (شبیه‌سازیِ کرش بعد از commit) -> جاروب شروعش می‌کنه
    uids11 = list(range(12400, 12411))
    for u in uids11:
        mk_user(u, 1_000_000_000)
    users11 = {u: FakeUser(u) for u in uids11}
    chats11 = {u: FakeChat(-640000 - u) for u in uids11}
    panels11 = {u: new_panel(chats11[u].id) for u in uids11}
    orig = mafia._after_join

    async def boom(context, rid_):
        s_ = db.get_session()
        full = len(mafia._all_players(s_, rid_)) >= 11
        s_.close()
        if full:
            raise RuntimeError("crashed after commit")
        await orig(context, rid_)
    mafia._after_join = boom
    try:
        for u in uids11[:-1]:
            await press(users11[u], chats11[u], panels11[u], f"mf_gjoin:{u}:advanced:{T}:11")
        try:
            await press(users11[uids11[-1]], chats11[uids11[-1]], panels11[uids11[-1]],
                       f"mf_gjoin:{uids11[-1]}:advanced:{T}:11")
        except RuntimeError:
            pass
    finally:
        mafia._after_join = orig
    rid11 = latest_round_id("global")
    r = rnd(rid11)
    assert r.status == "lobby" and len(players_of(rid11)) == 11
    await mafia.tick_mafia(db.get_session(), ctx_for(uids11[0]))
    assert rnd(rid11).status == "night"
    roles11 = role_map(rid11)
    assert sorted(roles11.values()) == sorted(
        ["mafia"] * 3 + ["detective", "bodyguard", "sniper"] + ["citizen"] * 5)
    ok("full-but-unstarted 11-player global lobby is started by the sweep; n=11 role table correct")


async def test_concurrent_actions_and_votes():
    print("test_concurrent_actions_and_votes")
    rid, uids, users, chat, panel = await setup_group_game(12500, 5, -650001, scenario="classic")
    roles = role_map(rid)
    mafia_uid = next(u for u, ro in roles.items() if ro == "mafia")
    citizens = [u for u, ro in roles.items() if ro == "citizen"]
    r = rnd(rid)
    # چند کلیکِ هم‌زمانِ مافیا رو دو تا هدفِ مختلف - فقط یکی باید بمونه
    await asyncio.gather(*[
        press(users[mafia_uid], FakeChat(mafia_uid, "private"), panel_for(rid, mafia_uid),
             f"mf_act:{rid}:{r.phase_seq}:{citizens[0]}"),
        press(users[mafia_uid], FakeChat(mafia_uid, "private"), panel_for(rid, mafia_uid),
             f"mf_act:{rid}:{r.phase_seq}:{citizens[1]}"),
    ])
    await role_act(rid, users, roles, "doctor", 0)
    await role_act(rid, users, roles, "detective", 0)
    r2 = rnd(rid)
    assert r2.status == "day"
    dead = [u for u in uids if not players_of(rid)[u][1]]
    assert len(dead) == 1
    ok("concurrent mafia double-click: exactly one target locked in")

    await _drain_day_speak(rid, users)
    alive = [u for u in uids if players_of(rid)[u][1]]
    await asyncio.gather(*[press(users[u], chat, panel_for(rid, u) if rnd(rid).mode == "global" else panel,
                                 f"mf_vote:{rid}:{rnd(rid).phase_seq}:{mafia_uid}") for u in alive])
    r3 = rnd(rid)
    assert r3.status == "resolved"
    ok("concurrent votes all register correctly, game resolves once")


async def test_admin_config_mafia():
    print("test_admin_config_mafia")
    import admin
    keys = dict(admin.CFG_CASINO_KEYS)
    assert "casino_mafia_night_seconds" in keys and "casino_mafia_day_seconds" in keys
    for key, bad in [("casino_mafia_night_seconds", "5"), ("casino_mafia_night_seconds", "9999"),
                     ("casino_mafia_day_seconds", "abc"), ("casino_mafia_day_seconds", "3.5")]:
        assert mafia.validate_cfg(key, bad), (key, bad)
    for key, good in [("casino_mafia_night_seconds", "15"), ("casino_mafia_night_seconds", "600"),
                      ("casino_mafia_day_seconds", "90")]:
        assert mafia.validate_cfg(key, good) is None

    admin_user = FakeUser(999)
    achat = FakeChat(999, "private")
    apanel = new_panel(achat.id)
    actx = ctx_for(999)
    q = FakeQuery(BOT, "admin_cfg_edit:casino_mafia_night_seconds", achat.id, apanel)
    await admin.cb_admin_cfg_edit(FakeUpdate(admin_user, achat, q), actx)
    upd = FakeUpdate(admin_user, achat, text="30")
    try:
        await admin.admin_awaiting_handler(upd, actx)
    except ApplicationHandlerStop:
        pass
    s = db.get_session()
    assert db.cfg_get(s, "casino_mafia_night_seconds") == "30"
    s.close()
    ok("admin panel: mafia night/day seconds are listed, validated, and saved")

    # اعمال‌شدنش رو تو یه بازیِ درحال‌اجرا چک کن: از فازِ بعدی
    rid, uids, users, chat, panel = await setup_group_game(12600, 5, -650002, scenario="quick")
    r = rnd(rid)
    assert (r.phase_deadline_at - r.phase_started_at).total_seconds() == 30
    s = db.get_session()
    db.cfg_set(s, "casino_mafia_night_seconds", "45")
    s.close()
    roles = role_map(rid)
    await mafia_act(rid, users, roles, 0)
    if "doctor" in roles.values():
        await role_act(rid, users, roles, "doctor", 0)
    r2 = rnd(rid)
    assert r2.status == "day"
    for u in [u for u in uids if players_of(rid)[u][1]]:
        await do_vote(rid, users, u, 0)
    r3 = rnd(rid)
    assert r3.status == "night"
    assert (r3.phase_deadline_at - r3.phase_started_at).total_seconds() == 45
    ok("changed night-seconds config applies to the next night phase of a running game")
    s = db.get_session()
    db.cfg_set(s, "casino_mafia_night_seconds", "60")
    s.close()



async def test_random_simulation():
    print("test_random_simulation (random games across scenarios/counts/modes)")
    cancel_all_lobbies()  # پاک‌کردنِ لابی‌هایِ ناقصِ باقی‌مونده از تست‌هایِ قبلی؛ وگرنه مچ‌میکینگِ تصادفی
                          # ممکنه بی‌خبر با یه لابیِ قدیمی/باقی‌مونده ترکیب بشه و شمارشِ تست به‌هم بریزه
    random.seed(11)
    uid_pool = list(range(20000, 20120))
    for u in uid_pool:
        mk_user(u, 10_000_000_000)
    users = {u: FakeUser(u) for u in uid_pool}
    total0 = sum(bal(u) for u in uid_pool)
    n_games = 80
    for g in range(n_games):
        scenario = random.choice(mafia.SCENARIOS)
        mode = random.choice(["group", "global"])
        n = random.choice([5, 6, 7, 8]) if mode == "group" else random.choice(mafia.GLOBAL_PLAYER_TIERS)
        ps = random.sample(uid_pool, n)
        stake = random.choice([500, 1000, 5000])
        if mode == "group":
            c = FakeChat(-700000 - g)
            pn = new_panel(c.id)
            await press(users[ps[0]], c, pn, f"mf_new:{ps[0]}")
            await press(users[ps[0]], c, pn, f"mf_mode_group:{ps[0]}")
            await press(users[ps[0]], c, pn, f"mf_scn:{ps[0]}:{scenario}")
            rid = latest_round_id("group")
            await press(users[ps[0]], c, pn, f"mf_amt_pick:{rid}:{stake}")
            await press(users[ps[0]], c, pn, f"mf_plr_pick:{rid}:{n}")
            await press(users[ps[0]], c, pn, f"mf_start:{rid}")
            for u in ps[1:]:
                await press(users[u], c, pn, f"mf_join:{rid}")
        else:
            T = random.choice(mafia.GLOBAL_TIERS)
            chats = {u: FakeChat(-800000 - u) for u in ps}
            panels = {u: new_panel(chats[u].id) for u in ps}
            for u in ps:
                await press(users[u], chats[u], panels[u], f"mf_gjoin:{u}:{scenario}:{T}:{n}")
            rid = latest_round_id("global")
        r = rnd(rid)
        assert r.status == "night", (mode, scenario, n, r.status)
        roles = role_map(rid)
        before = {u: bal(u) for u in ps}
        steps = 0
        while rnd(rid).status in ("night", "day"):
            steps += 1
            assert steps < 60, f"game stuck (mode={mode} scenario={scenario} n={n})"
            r = rnd(rid)
            if r.status == "night":
                alive_map = players_of(rid)
                mafia_alive = [u for u, ro in roles.items() if ro == "mafia" and alive_map[u][1]]
                targets = [u for u, ro in roles.items() if ro != "mafia" and alive_map[u][1]]
                if mafia_alive and targets:
                    tgt = random.choice(targets)
                    await mafia_act(rid, users, roles, tgt)
                else:
                    await mafia_act(rid, users, roles, 0)
                for role_name in ("doctor", "detective", "bodyguard", "sniper"):
                    if role_name in roles.values():
                        uid = next((u for u, ro in roles.items() if ro == role_name), None)
                        if uid is not None and alive_map.get(uid, (None, False))[1]:
                            s_ = db.get_session()
                            sp = mafia._get_player(s_, rid, uid)
                            used = sp.sniper_used if sp else True
                            s_.close()
                            if role_name == "sniper" and used:
                                continue
                            others = [u for u in alive_map if alive_map[u][1] and u != uid]
                            choice = random.choice([0] + others) if others else 0
                            await role_act(rid, users, roles, role_name, choice)
            else:
                alive = [u for u in ps if players_of(rid)[u][1]]
                for u in alive:
                    choice = random.choice([0] + [x for x in alive if x != u])
                    await do_vote(rid, users, u, choice)
        r = rnd(rid)
        assert r.status == "resolved", (mode, scenario, n)
        st = players_of(rid)
        win_amt = r.entry_amount * mafia.WIN_MULTIPLIER
        if r.winner_side == "draw":
            for u in ps:
                assert bal(u) == before[u] + r.entry_amount, (g, u, "draw")
        elif r.winner_side == "psycho":
            psycho_uid = next((u for u, ro in roles.items() if ro == "psycho"), None)
            assert psycho_uid is not None
            for u in ps:
                if u == psycho_uid:
                    assert bal(u) == before[u] + win_amt, (g, u)
                else:
                    assert bal(u) == before[u], (g, u)
        else:
            winning_roles = {"mafia"} if r.winner_side == "mafia" else set(mafia.TOWN_ROLES)
            for u in ps:
                is_winner = st[u][1] and roles[u] in winning_roles
                expect = before[u] + win_amt if is_winner else before[u]
                assert bal(u) == expect, (g, u, roles[u], st[u], r.winner_side)
        for u in ps:
            s_ = db.get_session()
            assert not casino._user_has_active_round(s_, u), (g, u)
            s_.close()
    total1 = sum(bal(u) for u in uid_pool)
    ok(f"{n_games} random games across all scenarios/counts/modes: correct winners, exact 5.5x payouts, "
       "nobody stuck")
    print(f"    (house delta over {n_games} games: {total1 - total0:+,.0f} hop)")

def uname(uid):
    s = db.get_session()
    try:
        return mafia._name(s, uid)
    finally:
        s.close()


def dm_text(rid, uid):
    e = BOT.last_edit(panel_for(rid, uid))
    return (e[2] if e and len(e) > 2 else "") or ""


def group_text(rid):
    e = BOT.last_edit(rnd(rid).message_id)
    return (e[2] if e and len(e) > 2 else "") or ""


def dm_has_button(rid, uid, prefix):
    e = BOT.last_edit(panel_for(rid, uid))
    kb = e[3] if e and len(e) > 3 else None
    if not kb:
        return False
    return any((b.callback_data or "").startswith(prefix) for row in kb.inline_keyboard for b in row)


async def speak_reply(rid, users, uid, text, reply_to_id=None):
    """uid تو پیوی روی پنلِ بازیِ خودش (یا reply_to_id) ریپلای می‌کنه."""
    upd = FakeUpdate(users[uid], FakeChat(uid, "private"),
                     text=text, reply_to=FakeMsg(uid, reply_to_id if reply_to_id is not None else panel_for(rid, uid)))
    return await mafia.handle_day_speech(upd, ctx_for(uid))


async def to_day(rid, users, roles):
    await mafia_act(rid, users, roles, 0)
    for ro in ("doctor", "detective", "bodyguard"):
        if ro in roles.values():
            await role_act(rid, users, roles, ro, 0)
    r = rnd(rid)
    if r.status == "night":   # تک‌تیرانداز/... اگه مونده باشه با تایم‌اوت جلو می‌ره
        s_ = db.get_session()
        xr = s_.get(db.MafiaRound, rid)
        xr.phase_deadline_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
        s_.commit()
        s_.close()
        await mafia._night_timeout(ctx_for(1), rid, r.phase_seq)
    r = rnd(rid)
    assert r.status == "day" and r.day_speak_active, r.status
    return r


async def test_day_speak_dm_reply_group_mode():
    print("test_day_speak_dm_reply_group_mode")
    rid, uids, users, chat, panel = await setup_group_game(13000, 5, -700500, scenario="quick")
    roles = role_map(rid)
    restricted_before = len(BOT.restricted)
    r = await to_day(rid, users, roles)
    order = mafia._day_speak_order_list(r)
    alive = [u for u in uids if players_of(rid)[u][1]]
    assert sorted(order) == sorted(alive), "صفِ نوبت باید دقیقاً همون زنده‌ها باشه"
    ok("day starts with a speak queue of exactly the alive players")

    # پنلِ خصوصی: صاحبِ نوبت راهنمایِ ریپلای + دکمه‌ها؛ بقیه فقط اسمِ نفرِ فعلی
    first, second, third = order[0], order[1], order[2]
    assert "نوبتِ توئه" in dm_text(rid, first) and "ریپلای" in dm_text(rid, first)
    assert dm_has_button(rid, first, "mf_dspass") and dm_has_button(rid, first, "mf_dsdone")
    assert uname(first) in dm_text(rid, second) and not dm_has_button(rid, second, "mf_dspass")
    assert uname(first) in group_text(rid), "پنلِ گروه هم باید نوبتِ فعلی رو نشون بده"
    ping = [t for c, t, mid in BOT.sent if c == first and "نوبتِ صحبتِ توئه" in (t or "")]
    assert ping, "صاحبِ نوبت باید یه پیامِ خبردهنده تو پیوی بگیره"
    assert r.day_speak_deadline_at is not None
    left = (r.day_speak_deadline_at - datetime.datetime.utcnow()).total_seconds()
    assert 170 < left <= 181, f"مهلتِ هر نوبت باید ۱۸۰ ثانیه باشه ({left})"
    ok("speaker's private panel has reply instructions + buttons, others see whose turn it is; 180s deadline")

    # بدونِ ریپلای / ریپلای روی پیامِ دیگه / نفرِ بی‌نوبت → هیچ اتفاقی
    upd = FakeUpdate(users[first], FakeChat(first, "private"), text="بدونِ ریپلای")
    assert await mafia.handle_day_speech(upd, ctx_for(first)) is False
    assert await speak_reply(rid, users, first, "ریپلای اشتباه", reply_to_id=1) is False
    assert await speak_reply(rid, users, third, "نوبتِ من نیست!") is False
    assert rnd(rid).day_speak_index == 0
    ok("non-reply / reply to a wrong message / message from someone not on turn are all ignored")

    # نفرِ اول حرف می‌زنه
    assert await speak_reply(rid, users, first, "سلام بچه‌ها\nخوش اومدین، امیدوارم بازی خوبی داشته باشین") is True
    assert rnd(rid).day_speak_index == 1
    line1 = f"{uname(first)} : سلام بچه‌ها خوش اومدین، امیدوارم بازی خوبی داشته باشین"
    for u in alive:
        assert line1 in dm_text(rid, u), f"حرفِ نفرِ اول باید تو پنلِ {u} نوشته بشه"
    assert line1 in group_text(rid), "تو پنلِ گروه هم باید نوشته بشه"
    ok("a reply on the panel is recorded and shown in EVERY player's panel + the group panel")

    # نفرِ دوم «ردِ نوبت» → حرف نزد
    r3 = rnd(rid)
    q = await press(users[second], FakeChat(second, "private"), panel_for(rid, second), f"mf_dspass:{rid}:{r3.day_speak_seq}")
    assert last_alert(q) is not None and rnd(rid).day_speak_index == 2
    assert f"{uname(second)} : حرف نزد" in dm_text(rid, first)
    ok("'skip turn' → '<name> : حرف نزد' on everyone's panel")

    # دکمه‌ی نفرِ دیگه کار نمی‌کنه
    r4 = rnd(rid)
    bad_q = await press(users[first], FakeChat(first, "private"), panel_for(rid, first), f"mf_dspass:{rid}:{r4.day_speak_seq}")
    assert "الان نوبتِ تو نیست" in (last_alert(bad_q)[0] or "") and rnd(rid).day_speak_index == 2
    ok("only the current speaker's buttons are honored")

    # نفرِ سوم اصلاً جواب نمی‌ده → تایم‌اوت
    s_ = db.get_session()
    xr = s_.get(db.MafiaRound, rid)
    xr.day_speak_deadline_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
    s_.commit()
    s_.close()
    await mafia._day_speak_timeout(ctx_for(third), rid, r4.day_speak_seq)
    assert rnd(rid).day_speak_index == 3
    assert f"{uname(third)} : حرف نزد" in dm_text(rid, first)
    ok("a turn that expires (180s) is skipped and written as 'حرف نزد'")

    # نفرِ چهارم «اتمامِ صحبت» می‌زنه (بدونِ حرف) → حرف نزد؛ بعد پنجمی حرف می‌زنه
    r5 = rnd(rid)
    fourth, fifth = order[3], order[4]
    await press(users[fourth], FakeChat(fourth, "private"), panel_for(rid, fourth), f"mf_dsdone:{rid}:{r5.day_speak_seq}")
    assert f"{uname(fourth)} : حرف نزد" in dm_text(rid, fifth)
    assert await speak_reply(rid, users, fifth, "من فقط یه شهروندم") is True
    r6 = rnd(rid)
    assert r6.status == "day" and not r6.day_speak_active and r6.phase_deadline_at is not None
    assert dm_has_button(rid, first, "mf_vote"), "بعدِ صحبت‌ها رای‌گیری با دکمه تو پنلِ خصوصی باز می‌شه"
    for u in alive:
        assert line1 in dm_text(rid, u) and f"{uname(fifth)} : من فقط یه شهروندم" in dm_text(rid, u), \
            "صحبت‌ها موقعِ رای‌گیری هم تو پنل می‌مونن"
    assert "روزِ 1" in dm_text(rid, first) or "روزِ ۱" in dm_text(rid, first) or "صحبت‌هایِ روزِ 1" in dm_text(rid, first)
    ok("after the last turn voting opens (buttons in DM) and the day's speeches stay on the panels")

    # همه رای نمی‌دم → شب ۲؛ صحبت‌هایِ روز ۱ هنوز تو پنل‌ها هست
    for u in alive:
        await do_vote(rid, users, u, 0)
    r7 = rnd(rid)
    assert r7.status == "night" and r7.day_number == 2
    for u in alive:
        assert line1 in dm_text(rid, u), f"تا پایانِ شبِ ۱... صحبت‌هایِ روز ۱ باید تو پنلِ {u} بمونه"
    assert line1 in group_text(rid)
    ok("speeches of day 1 survive through the whole following night (DM panels + group panel)")

    # شب ۲ تموم → روز ۲: پنل‌ها برایِ روز ۲ آماده می‌شن و حرف‌هایِ روز ۱ پاک می‌شن
    r8 = await to_day(rid, users, role_map(rid))
    alive2 = [u for u in uids if players_of(rid)[u][1]]
    for u in alive2:
        txt = dm_text(rid, u)
        assert line1 not in txt, "با شروعِ روزِ ۲ حرف‌هایِ روزِ ۱ باید پاک بشن"
        assert "روزِ 2" in txt
    ok("day 2 starts with a fresh speech list (day 1's speeches are gone)")
    assert len(BOT.restricted) == restricted_before, "دیگه هیچ‌کس تو گروه ساکت/محدود نمی‌شه"
    ok("nobody is ever muted/restricted in the group anymore")


async def test_day_speak_global_mode():
    print("test_day_speak_global_mode")
    users_by_id, chats, panels = {}, {}, {}
    T = mafia.GLOBAL_TIERS[0]
    n = mafia.GLOBAL_PLAYER_TIERS[0]
    ps = list(range(14000, 14000 + n))
    for u in ps:
        mk_user(u, 10_000_000)
        users_by_id[u] = FakeUser(u)
        chats[u] = FakeChat(-900000 - u, "private")
        panels[u] = new_panel(chats[u].id)
    for u in ps:
        await press(users_by_id[u], chats[u], panels[u], f"mf_gjoin:{u}:quick:{T}:{n}")
    rid = latest_round_id("global")
    roles = role_map(rid)
    r = await to_day(rid, users_by_id, roles)
    assert r.mode == "global" and r.day_speak_active, "لابیِ جهانی هم باید نوبتِ صحبت داشته باشه"
    order = mafia._day_speak_order_list(r)
    first, second = order[0], order[1]
    assert "نوبتِ توئه" in dm_text(rid, first) and dm_has_button(rid, first, "mf_dspass")
    ok("global lobby also gets the speak-turn phase")

    assert await speak_reply(rid, users_by_id, first, "سلام، بازیِ خوبی داشته باشین") is True
    line = f"{uname(first)} : سلام، بازیِ خوبی داشته باشین"
    alive = [u for u in ps if players_of(rid)[u][1]]
    assert all(line in dm_text(rid, u) for u in alive)
    ok("global: reply on own panel is written into everyone's panel")

    r2 = rnd(rid)
    await press(users_by_id[second], FakeChat(second, "private"), panel_for(rid, second), f"mf_dspass:{rid}:{r2.day_speak_seq}")
    assert f"{uname(second)} : حرف نزد" in dm_text(rid, first)
    ok("global: skipped turn shows 'حرف نزد'")

    await _drain_day_speak(rid, users_by_id)
    r3 = rnd(rid)
    assert r3.status == "day" and not r3.day_speak_active and r3.phase_deadline_at is not None
    for u in alive:
        await do_vote(rid, users_by_id, u, 0)
    assert rnd(rid).status == "night"
    ok("global: voting proceeds after the speeches; game goes on to the next night")


async def test_private_lock_exempts_current_speaker():
    print("test_private_lock_exempts_current_speaker")
    import main
    rid, uids, users, chat, panel = await setup_group_game(13500, 5, -700600, scenario="quick")
    roles = role_map(rid)
    r = await to_day(rid, users, roles)
    order = mafia._day_speak_order_list(r)
    cur, other = order[0], order[1]
    s = db.get_session()
    db.cfg_set(s, "private_chat_enabled", "0")
    s.commit()
    s.close()
    try:
        priv_c = FakeChat(cur, "private")
        upd = FakeUpdate(FakeUser(cur), priv_c, text="حرفِ من", reply_to=FakeMsg(cur, panel_for(rid, cur)))
        assert await main._private_chat_blocked(upd) is False, "ریپلایِ صاحبِ نوبت باید با پیویِ خاموش هم کار کنه"
        upd2 = FakeUpdate(FakeUser(other), FakeChat(other, "private"), text="حرفِ من",
                          reply_to=FakeMsg(other, panel_for(rid, other)))
        assert await main._private_chat_blocked(upd2) is True, "کسی که نوبتش نیست همچنان قفل می‌مونه"
        ok("private-chat lock lets the current speaker's reply through (and only theirs)")
    finally:
        s = db.get_session()
        db.cfg_set(s, "private_chat_enabled", "1")
        s.commit()
        s.close()


async def test_mafia_dm_exempt_from_private_chat_lock():
    print("test_mafia_dm_exempt_from_private_chat_lock")
    import main
    s = db.get_session()
    try:
        db.cfg_set(s, "private_chat_enabled", "0")   # پیویِ عمومی خاموش
        s.commit()
    finally:
        s.close()
    try:
        plain_user = FakeUser(15000)
        priv = FakeChat(15000, "private")
        mf_upd = FakeUpdate(plain_user, priv, FakeQuery(BOT, "mf_act:1:1:0", priv.id, 1))
        assert await main._private_chat_blocked(mf_upd) is False, \
            "دکمه‌های مافیا (mf_...) باید حتی با خاموش‌بودنِ پیویِ عمومی کار کنن"

        other_upd = FakeUpdate(plain_user, priv, FakeQuery(BOT, "casino_menu", priv.id, 1))
        assert await main._private_chat_blocked(other_upd) is True, \
            "بقیه‌ی دکمه‌ها (غیرِ مافیا/نبردِ دریایی/...) باید طبقِ معمول با پیویِ خاموش قفل بمونن"

        text_upd = FakeUpdate(plain_user, priv, text="سلام")
        assert await main._private_chat_blocked(text_upd) is True, \
            "یه پیامِ متنیِ سادهٔ غیرمرتبط با هیچ استثنایی، باید همچنان قفل بمونه"
        ok("mafia's DM buttons (mf_...) bypass the 'public PM disabled' lock, exactly like battleship/mastermind/uno, "
           "while unrelated DM traffic stays locked")
    finally:
        s = db.get_session()
        db.cfg_set(s, "private_chat_enabled", "1")   # برگردوندنِ پیشِ‌فرض برایِ بقیه‌ی تست‌ها
        s.commit()
        s.close()


async def test_no_group_membership_required():
    print("test_no_group_membership_required")
    uid = 16000
    mk_user(uid, 10_000_000)
    BOT.non_members = {uid}
    try:
        u = FakeUser(uid)
        grp = FakeChat(-800016)
        edits_before, sent_before = len(BOT.edits), len(BOT.sent)
        await press(u, grp, new_panel(grp.id), f"mf_new:{uid}")
        shown = [t for c, m, t, kb in BOT.edits[edits_before:]] + [t for c, t, mid in BOT.sent[sent_before:]]
        assert not any("عضو" in (t or "") and "گپ" in (t or "") for t in shown), "دیگه نباید عضویتِ گپ چک بشه"
        assert any("کجا بازی" in (t or "") or "سناریو" in (t or "") for t in shown), "منوی مافیا باید باز بشه"
        ok("no group-membership check anymore: a non-member sees the normal mafia menu")
    finally:
        BOT.non_members = set()


async def test_vote_majority_and_lottery():
    print("test_vote_majority_and_lottery")

    class FP:
        def __init__(self, uid, vote=None, alive=True):
            self.user_id, self.day_vote_id, self.alive = uid, vote, alive

    def run(votes):
        return mafia._tally_lynch_target([FP(i + 1, v) for i, v in enumerate(votes)])

    # ۵ نفر: یک رای تنها کافی نیست
    assert run([2, None, None, None, None])[0] is None
    # ۵ نفر: ۳ رای (نصفِ ۵ = ۲٫۵ → ۳) اعدام می‌کنه
    assert run([2, 2, 2, 0, None])[0] == 2
    # ۵ نفر: ۲-۲-۱ به حدِ نصاب نمی‌رسه
    assert run([2, 1, 2, 1, 0])[0] is None
    # ۴ نفر: ۲-۲ به حدِ نصاب می‌رسه و بینشون قرعه می‌شه
    seen = set()
    for _ in range(60):
        t, v, tied = run([2, 1, 2, 1])
        assert sorted(tied) == [1, 2] and t in (1, 2) and v == 2
        seen.add(t)
    assert seen == {1, 2}
    ok("majority threshold (>= half of alive) + random draw between tied top candidates")


async def main():
    tests = [
        test_classic_group_full_game, test_mafia_wins_by_parity, test_advanced_bodyguard_and_sniper,
        test_sniper_misfire_kills_innocent, test_quick_scenario_no_detective, test_psycho_win_by_lynch,
        test_psycho_gets_nothing_if_town_wins_normally, test_draw_finish_path,
        test_day_vote_tie_no_lynch, test_no_lynch_when_all_abstain, test_vote_majority_and_lottery,
        test_afk_night_timeout_resolves_with_partial_actions, test_day_vote_timeout,
        test_day_speak_dm_reply_group_mode, test_day_speak_global_mode,
        test_private_lock_exempts_current_speaker, test_mafia_dm_exempt_from_private_chat_lock,
        test_no_group_membership_required,
        test_custom_amount_and_setup_cancel, test_group_lobby_timeout_no_hopoo, test_creator_cancel_and_leave,
        test_busy_lock_with_other_casino_games, test_dm_unreachable_aborts_game,
        test_global_matchmaking_basic, test_global_leave_and_partial_matching,
        test_global_near_expiry_not_offered, test_global_lobby_timeout_and_full_but_unstarted,
        test_concurrent_actions_and_votes, test_admin_config_mafia, test_random_simulation,
    ]
    for t in tests:
        await t()
    print(f"\nALL {len(passed)} CHECKS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
