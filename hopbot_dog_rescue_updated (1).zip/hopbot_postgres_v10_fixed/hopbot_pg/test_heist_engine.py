# -*- coding: utf-8 -*-
"""
تست‌های موتورِ خالصِ «سرقت تیمی هاپویی» (بدونِ دیتابیس/تلگرام).
اجرا:  python3 -m unittest test_heist_engine -v
"""
import unittest

import heist_engine as E

CFG = {
    "spy_base_colors": 8, "spy_per_skill_colors": 1, "spy_min_colors": 3, "spy_max_skill": 0,
    "safe_per_skill_pct": 1, "safe_min_pct": 0, "safe_max_pct": 100, "safe_max_skill": 5,
    "carrier_base_sec": 15, "carrier_per_skill_sec": 1, "carrier_min_sec": 3, "carrier_max_skill": 0,
    "driver_base_sec": 165, "driver_per_skill_sec": 14, "driver_min_sec": 30, "driver_max_skill": 0,
}
PAL = ["🟨", "🟥", "🟦", "🟩", "🟪", "🟧", "⬜", "🟫"]
POOL = [{"id": 1, "name": "A", "base_value": 50_000_000, "weight": 1, "fail_pct": None, "variance": None},
        {"id": 2, "name": "B", "base_value": 25_000_000, "weight": 1, "fail_pct": None, "variance": None}]


class Roles(unittest.TestCase):
    def test_slot_to_role_order(self):
        self.assertEqual([E.role_of_slot(i) for i in (1, 2, 3, 4)], ["spy", "safe", "carrier", "driver"])

    def test_invalid_slot(self):
        for bad in (0, 5, -1):
            with self.assertRaises(ValueError):
                E.role_of_slot(bad)

    def test_team_size_is_four(self):
        self.assertEqual(E.TEAM_SIZE, 4)


class StateMachine(unittest.TestCase):
    def test_happy_path(self):
        self.assertTrue(E.can_transition(E.RECRUITING, E.FULL))
        for a, b in ((E.SPY, E.SAFE), (E.SAFE, E.CARRIER), (E.CARRIER, E.DRIVER), (E.DRIVER, E.SETTLED)):
            self.assertTrue(E.can_transition(a, b))

    def test_police_can_end_every_phase(self):
        for ph in E.PHASE_ORDER:
            self.assertTrue(E.can_transition(ph, E.SETTLED), ph)

    def test_no_skipping_or_going_back(self):
        self.assertFalse(E.can_transition(E.SPY, E.CARRIER))
        self.assertFalse(E.can_transition(E.CARRIER, E.SAFE))
        self.assertFalse(E.can_transition(E.SETTLED, E.SPY))
        self.assertFalse(E.can_transition(E.CANCELLED, E.RECRUITING))

    def test_phase_roles(self):
        self.assertEqual([E.PHASE_ROLE[p] for p in E.PHASE_ORDER], list(E.ROLES))
        self.assertIsNone(E.next_phase(E.DRIVER))


class Skills(unittest.TestCase):
    def test_spy_colors_decrease_with_skill(self):
        self.assertEqual([E.spy_length(CFG, s) for s in range(0, 4)], [8, 7, 6, 5])

    def test_spy_minimum_floor(self):
        self.assertEqual(E.spy_length(CFG, 100), 3)
        self.assertGreaterEqual(E.spy_length(dict(CFG, spy_min_colors=0), 100), 1)

    def test_safe_failure_pct_and_max_skill(self):
        self.assertEqual([E.item_fail_pct(12, CFG, s) for s in range(0, 6)], [12, 11, 10, 9, 8, 7])
        self.assertEqual(E.item_fail_pct(12, CFG, 50), 7)           # بیشتر از سقفِ مؤثر اثر نداره

    def test_safe_floor_and_ceiling(self):
        self.assertEqual(E.item_fail_pct(3, dict(CFG, safe_min_pct=2), 5), 2)
        self.assertEqual(E.item_fail_pct(120, CFG, 0), 100)

    def test_carrier_time_and_minimum(self):
        self.assertEqual([E.carrier_seconds(CFG, s) for s in (0, 1, 3)], [15, 14, 12])
        self.assertEqual(E.carrier_seconds(CFG, 999), 3)

    def test_driver_time_and_minimum(self):
        self.assertEqual([E.driver_seconds(CFG, s) for s in (0, 1, 2, 3)], [165, 151, 137, 123])
        self.assertEqual(E.driver_seconds(CFG, 50), 30)             # منفی/صفر نمی‌شه

    def test_negative_skill_treated_as_zero(self):
        self.assertEqual(E.driver_seconds(CFG, -5), 165)

    def test_config_driven_not_hardcoded(self):
        c = dict(CFG, driver_base_sec=100, driver_per_skill_sec=10, driver_min_sec=60)
        self.assertEqual([E.driver_seconds(c, s) for s in (0, 2, 9)], [100, 80, 60])


class SpyPuzzle(unittest.TestCase):
    def test_deterministic_per_seed_and_attempt(self):
        a = E.gen_sequence(123, 0, 8, 8)
        self.assertEqual(a, E.gen_sequence(123, 0, 8, 8))
        self.assertNotEqual(a, E.gen_sequence(123, 1, 8, 8))     # تلاشِ جدید = توالیِ جدید (با احتمالِ بسیار بالا)

    def test_no_repeat_by_default(self):
        s = E.gen_sequence(5, 0, 8, 8)
        self.assertEqual(len(set(s)), 8)

    def test_repeat_allowed_when_longer_than_pool(self):
        self.assertEqual(len(E.gen_sequence(5, 0, 10, 4)), 10)

    def test_reverse_display_only_changes_display(self):
        seq = [0, 1, 2, 3]
        self.assertEqual(E.render_colors(seq, PAL), "🟨 🟥 🟦 🟩")
        self.assertEqual(E.reverse_display(seq, PAL), "🟩 🟦 🟥 🟨")
        self.assertTrue(E.sequence_ok(seq, [0, 1, 2, 3]))        # مقایسه همچنان چپ→راست
        self.assertFalse(E.sequence_ok(seq, [3, 2, 1, 0]))

    def test_empty_pool_rejected(self):
        with self.assertRaises(ValueError):
            E.gen_sequence(1, 0, 3, 0)


class Items(unittest.TestCase):
    def test_count_cells_unique(self):
        items = E.place_items(77, 20, POOL, 5, 1_000_000)
        self.assertEqual(len(items), 5)
        self.assertEqual(len({i["cell"] for i in items}), 5)
        self.assertTrue(all(0 <= i["cell"] < 20 for i in items))

    def test_count_never_exceeds_cells(self):
        self.assertEqual(len(E.place_items(1, 4, POOL, 99, 0)), 4)

    def test_empty_pool_or_zero(self):
        self.assertEqual(E.place_items(1, 20, [], 5, 0), [])
        self.assertEqual(E.place_items(1, 20, POOL, 0, 0), [])

    def test_value_variance_bounds_and_independence(self):
        vals = []
        for seed in range(200):
            for it in E.place_items(seed, 20, [POOL[0]], 5, 1_000_000):
                self.assertTrue(49_000_000 <= it["value"] <= 51_000_000)
                vals.append(it["value"])
        self.assertGreater(len(set(vals)), 100)                  # هر آیتم مقدارِ مستقلِ خودش رو داره

    def test_zero_variance_is_exact(self):
        for it in E.place_items(3, 20, [POOL[0]], 5, 0):
            self.assertEqual(it["value"], 50_000_000)

    def test_item_level_variance_override(self):
        pool = [dict(POOL[0], variance=0)]
        for it in E.place_items(3, 20, pool, 5, 5_000_000):
            self.assertEqual(it["value"], 50_000_000)

    def test_replay_is_identical(self):
        self.assertEqual(E.place_items(9, 20, POOL, 5, 1_000_000), E.place_items(9, 20, POOL, 5, 1_000_000))

    def test_seed_is_server_generated_and_varies(self):
        seeds = {E.new_seed() for _ in range(50)}
        self.assertEqual(len(seeds), 50)

    def test_failure_rolls_independent_and_reproducible(self):
        items = [{"cell": c} for c in range(5)]
        r1 = E.roll_failures(42, items, [50] * 5)
        self.assertEqual(r1, E.roll_failures(42, items, [50] * 5))
        # با یه آیتمِ کمتر، Rollِ بقیه عوض نمی‌شه (استریمِ مستقل)
        self.assertEqual(r1[:3], E.roll_failures(42, items[:3], [50] * 3))

    def test_failure_pct_extremes(self):
        items = [{"cell": c} for c in range(200)]
        self.assertFalse(any(E.roll_failures(1, items, [0] * 200)))
        self.assertTrue(all(E.roll_failures(1, items, [100] * 200)))

    def test_failure_rate_roughly_matches(self):
        n = 5000
        items = [{"cell": c} for c in range(n)]
        lost = sum(E.roll_failures(7, items, [12] * n))
        self.assertTrue(0.09 * n < lost < 0.15 * n)


class Split(unittest.TestCase):
    def test_equal_split_exact(self):
        total, shares = E.split_loot(48_000_000, 4, "normalize")
        self.assertEqual((total, shares), (48_000_000, [12_000_000] * 4))

    def test_normalize_drops_remainder(self):
        total, shares = E.split_loot(10, 4, "normalize")
        self.assertEqual((total, shares), (8, [2, 2, 2, 2]))

    def test_creator_gets_remainder(self):
        total, shares = E.split_loot(10, 4, "creator", creator_idx=0)
        self.assertEqual((total, shares), (10, [4, 2, 2, 2]))

    def test_random_remainder_conserves_total_and_is_reproducible(self):
        t1, s1 = E.split_loot(11, 4, "random", seed=5)
        self.assertEqual(t1, 11)
        self.assertEqual(sum(s1), 11)
        self.assertEqual(s1, E.split_loot(11, 4, "random", seed=5)[1])

    def test_zero_and_negative(self):
        self.assertEqual(E.split_loot(0, 4, "normalize"), (0, [0, 0, 0, 0]))
        self.assertEqual(E.split_loot(-5, 4, "normalize")[0], 0)


class Format(unittest.TestCase):
    def test_clock(self):
        self.assertEqual(E.fmt_clock(134), "02:14")
        self.assertEqual(E.fmt_clock(-5), "00:00")
        self.assertEqual(E.fmt_long(7 * 3600 + 32 * 60 + 14), "07:32:14")
        self.assertEqual(E.fmt_duration_fa(180), "3 ساعت")


if __name__ == "__main__":
    unittest.main()
