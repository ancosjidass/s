# -*- coding: utf-8 -*-
"""
«قاچاق هاپویی» - سیستمِ کاملاً مستقل و ادمین‌محور. در ابتدا کاملاً خالیه: هیچ
کالا/مرحله/گزینه/نیرویی پیش‌فرض ساخته نمی‌شه.

معماری: از الگوهایِ همینِ پروژه استفاده شده (ask_for_input/send_response/
_verify_panel_owner از handlers.py، الگویِ PREFIX_MAP مثلِ chef.py/attack.py).
تنها سیستمِ قبلی که مجازه اثر بذاره «اسلحه»ست، و اونم مستقیماً از inventory
تجهیزشده‌ی attack.py (get_equipped/consume_use) استفاده می‌کنه - نه یه سیستمِ
اسلحه‌ی موازیِ جدید.

نکته‌ی تاریخ/روز: کلِ پروژه (زندان، بانک، تاکسی، گروگان و...) از
datetime.utcnow() برای همه‌چیز استفاده می‌کنه و هیچ تنظیمِ timezone ای جایی تو
پروژه تعریف نشده؛ پس «روزِ جدید» اینجا هم بر همون مبنا (تاریخِ UTC) محاسبه
می‌شه - دقیقاً هم‌راستا با معماریِ فعلی.
"""
import datetime
import json
import random

from sqlalchemy.exc import IntegrityError
from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationHandlerStop

import db
import handlers
import economy
import attack  # فقط برایِ استفاده‌ی مجدد از get_equipped/consume_use (اسلحه)
from handlers import fmt, send_response, _verify_panel_owner, ask_for_input, ask_for_input_reply, is_reply_to_prompt


def _nowt():
    return datetime.datetime.utcnow()


def today_str():
    """تاریخِ «امروز» به شکلِ YYYY-MM-DD بر اساسِ UTC - هم‌راستا با بقیه‌ی
    پروژه که همه‌جا از UTC استفاده می‌کنه (نگاه کن به داکِ بالایِ فایل)."""
    return _nowt().strftime("%Y-%m-%d")


# ---------------------------------------------------------------------------
# محدودیتِ روزانه (کاربر + کالا + روز) - با UniqueConstraint تو دیتابیس، پس
# حتی دو درخواستِ هم‌زمان هم فقط یکی‌شون موفق به رزرو می‌شه.
# ---------------------------------------------------------------------------

def has_used_today(session, user_id, good_id) -> bool:
    return (
        session.query(db.SmugglingDailyUsage)
        .filter_by(user_id=user_id, good_id=good_id, usage_date=today_str())
        .first()
        is not None
    )


def try_reserve_daily_slot(session, user_id, good_id) -> bool:
    """تلاش می‌کنه سهمِ امروزِ این (کاربر+کالا) رو رزرو کنه. اگه از قبل مصرف
    شده باشه (چه موفق چه ناموفق - هر دو یعنی «تلاش شده») False برمی‌گردونه.
    با commit فوری و گرفتنِ IntegrityError، حتی تو Race Condition هم فقط یکی
    از دو درخواستِ هم‌زمان برنده می‌شه."""
    row = db.SmugglingDailyUsage(user_id=user_id, good_id=good_id, usage_date=today_str(), status="reserved")
    session.add(row)
    try:
        session.commit()
        return True
    except IntegrityError:
        session.rollback()
        return False


# ---------------------------------------------------------------------------
# کمکی‌های Trust
# ---------------------------------------------------------------------------

def get_or_create_trust(session, user_id, helper: db.SmugglingHelper) -> db.SmugglingHelperTrust:
    row = session.query(db.SmugglingHelperTrust).filter_by(user_id=user_id, helper_id=helper.id).first()
    if row:
        _apply_decay(session, row, helper)
        return row
    row = db.SmugglingHelperTrust(user_id=user_id, helper_id=helper.id, trust=helper.trust_initial or 0, updated_at=_nowt())
    session.add(row)
    session.flush()
    return row


def _apply_decay(session, trust_row: db.SmugglingHelperTrust, helper: db.SmugglingHelper):
    """کاهشِ Trust به‌خاطرِ عدم‌استفاده - به‌صورتِ Lazy (نه با جاب) محاسبه
    می‌شه: هر بار Trust خونده می‌شه، تعدادِ دوره‌های سپری‌شده از آخرین استفاده
    حساب و کسر می‌شه (شبیهِ همون الگویِ Lazy که تو بوسترها/گروگان استفاده شده)."""
    if not helper.inactivity_days_for_decay or not trust_row.last_used_at:
        return
    days_passed = (_nowt() - trust_row.last_used_at).total_seconds() / 86400.0
    periods = int(days_passed // helper.inactivity_days_for_decay)
    if periods <= 0:
        return
    trust_row.trust = max(helper.trust_min or 0, trust_row.trust - periods * (helper.trust_decay_amount or 0))
    # جلوگیری از کسرِ مکررِ همون دوره‌ها تو خون��ن‌های بعدی
    trust_row.last_used_at = trust_row.last_used_at + datetime.timedelta(days=periods * helper.inactivity_days_for_decay)
    session.flush()


def gain_trust_from_use(session, trust_row: db.SmugglingHelperTrust, helper: db.SmugglingHelper):
    trust_row.trust = min(helper.trust_max or 100, trust_row.trust + (helper.trust_gain_per_use or 0))
    trust_row.last_used_at = _nowt()
    trust_row.updated_at = _nowt()


# ---------------------------------------------------------------------------
# پیداکردنِ Ruleها/Thresholdهایِ منطبق (اختصاصی‌ترین اول)
# ---------------------------------------------------------------------------

def _specificity(row):
    score = 0
    if row.good_id is not None:
        score += 1
    if row.stage_id is not None:
        score += 1
    if row.option_id is not None:
        score += 1
    return score


def _matching_rules(rows, good_id, stage_id, option_id):
    out = []
    for r in rows:
        if r.good_id is not None and r.good_id != good_id:
            continue
        if r.stage_id is not None and r.stage_id != stage_id:
            continue
        if r.option_id is not None and r.option_id != option_id:
            continue
        out.append(r)
    return out


def helpers_available_for_stage(session, good_id, stage_id):
    """همه‌ی نیروهای کمکیِ فعالی که حداقل یه Ruleِ فعال روی یکی از گزینه‌هایِ
    این مرحله (یا کلِ این مرحله/کالا) دارن - فارغ از اینکه کاربر مالکشون هست
    یا نه (برایِ نمایش تو صفحه‌ی «خرید نیروی کمکی»). برمی‌گردونه لیستی از
    (helper, [اسمِ گزینه‌هایی که روش اثر داره])."""
    options = session.query(db.SmugglingOption).filter_by(stage_id=stage_id, active=True).all()
    option_by_id = {o.id: o for o in options}
    rules = session.query(db.SmugglingHelperRule).filter_by(active=True).all()
    helper_option_names = {}
    for r in rules:
        if r.good_id is not None and r.good_id != good_id:
            continue
        if r.stage_id is not None and r.stage_id != stage_id:
            continue
        if r.option_id is not None:
            opt = option_by_id.get(r.option_id)
            if not opt:
                continue
            helper_option_names.setdefault(r.helper_id, set()).add(opt.name)
        else:
            helper_option_names.setdefault(r.helper_id, set()).update(o.name for o in options)
    result = []
    for helper_id, opt_names in helper_option_names.items():
        helper = session.get(db.SmugglingHelper, helper_id)
        if helper and helper.active:
            result.append((helper, sorted(opt_names)))
    result.sort(key=lambda x: x[0].name)
    return result


def eligible_helpers_for_option(session, user_id, good_id, stage_id, option_id):
    """نیروهایی که کاربر مالکشونه (uses_remaining/expiry معتبر) و حداقل یه
    Ruleِ فعال براشون رویِ این good+stage+option تعریف شده - وگرنه پیش‌فرض
    ممنوعه."""
    nowt = _nowt()
    owned = (
        session.query(db.SmugglingUserHelper)
        .filter(db.SmugglingUserHelper.user_id == user_id)
        .filter((db.SmugglingUserHelper.uses_remaining.is_(None)) | (db.SmugglingUserHelper.uses_remaining > 0))
        .filter((db.SmugglingUserHelper.expires_at.is_(None)) | (db.SmugglingUserHelper.expires_at > nowt))
        .all()
    )
    result = []
    for uh in owned:
        helper = session.get(db.SmugglingHelper, uh.helper_id)
        if not helper or not helper.active:
            continue
        rules = session.query(db.SmugglingHelperRule).filter_by(helper_id=helper.id, active=True).all()
        matched = _matching_rules(rules, good_id, stage_id, option_id)
        if not matched:
            continue
        rule = max(matched, key=_specificity)
        trust_row = get_or_create_trust(session, user_id, helper)
        if trust_row.trust < (rule.min_trust or 0):
            continue
        result.append((uh, helper, rule, trust_row))
    return result


def _combine(mode, values, cap):
    if not values:
        return 0.0
    if mode == "strongest":
        return max(values, key=abs)
    total = sum(values)
    if mode == "capped_sum" and cap is not None:
        if total > 0:
            return min(total, cap)
        return max(total, -cap)
    return total


# ---------------------------------------------------------------------------
# محاسبه‌ی اثرِ نهاییِ یه گزینه (کالا+مرحله+گزینه کاملاً مستقل از بقیه‌ی کالاها)
# ---------------------------------------------------------------------------

def compute_effective_option(session, user, good: db.SmugglingGood, stage: db.SmugglingStage,
                              option: db.SmugglingOption, helper_choice_id=None, use_gun=False):
    """برمی‌گردونه dict شاملِ success_pct مؤثر، reward مؤثر، penalty مؤثر، و
    جزئیاتِ اثرهایِ اعمال‌شده (برایِ لاگ/نمایش). هیچ‌کدوم از این محاسبات به
    کالایِ دیگه‌ای وابسته نیست - همه چیز مستقیماً از رویِ همین
    good_id+stage_id+option_id خونده می‌شه."""
    success_effects, reward_effects, penalty_effects = [], [], []
    used_helper_ids = []
    gun_inv_id = None
    gun_rule_id = None

    if helper_choice_id:
        uh = session.get(db.SmugglingUserHelper, helper_choice_id)
        if uh and uh.user_id == user.telegram_id:
            helper = session.get(db.SmugglingHelper, uh.helper_id)
            if helper and helper.active:
                rules = session.query(db.SmugglingHelperRule).filter_by(helper_id=helper.id, active=True).all()
                matched = _matching_rules(rules, good.id, stage.id, option.id)
                if matched:
                    rule = max(matched, key=_specificity)
                    trust_row = get_or_create_trust(session, user.telegram_id, helper)
                    if trust_row.trust >= (rule.min_trust or 0):
                        thresholds = session.query(db.SmugglingTrustThreshold).filter_by(helper_id=helper.id, active=True).all()
                        matched_th = [t for t in _matching_rules(thresholds, good.id, stage.id, option.id) if trust_row.trust >= t.min_trust]
                        s_vals = [rule.effect_success_pct] + [t.effect_success_pct for t in matched_th]
                        r_vals = [rule.effect_reward_pct] + [t.effect_reward_pct for t in matched_th]
                        p_vals = [rule.effect_penalty_pct] + [t.effect_penalty_pct for t in matched_th]
                        risk_vals = [rule.effect_risk_pct] + [t.effect_risk_pct for t in matched_th]
                        cap = helper.effect_cap_pct
                        mode = helper.effect_combination_mode or "sum"
                        success_effects.append(_combine(mode, s_vals, cap) - _combine(mode, risk_vals, cap))
                        reward_effects.append(_combine(mode, r_vals, cap))
                        penalty_effects.append(_combine(mode, p_vals, cap))
                        used_helper_ids.append(helper.id)

    if use_gun:
        gun_inv = attack.get_equipped(session, user.telegram_id, "gun")
        if gun_inv and (gun_inv.uses_remaining is None or gun_inv.uses_remaining > 0):
            gun_rules = session.query(db.SmugglingGunRule).filter_by(active=True).all()
            matched = _matching_rules(gun_rules, good.id, stage.id, option.id)
            if matched:
                rule = max(matched, key=_specificity)
                gun_item = session.get(db.ShopItem, gun_inv.shop_item_id)
                if rule.power_per_trust:
                    gun_trust_equiv = (gun_item.power or 0) / rule.power_per_trust
                    success_effects.append(
                        gun_trust_equiv * (rule.effect_success_pct_per_trust or 0)
                        - gun_trust_equiv * (rule.effect_risk_pct_per_trust or 0)
                    )
                    gun_inv_id = gun_inv.id
                    gun_rule_id = rule.id

    effective_success = max(0.0, min(100.0, option.success_pct + sum(success_effects)))
    effective_reward = max(0.0, option.reward_bonus + option.reward_bonus * (sum(reward_effects) / 100.0))
    effective_penalty_amount = max(0.0, option.penalty_amount + option.penalty_amount * (sum(penalty_effects) / 100.0))
    effective_penalty_pct = max(0.0, option.penalty_pct)

    return {
        "success_pct": effective_success,
        "reward_bonus": effective_reward,
        "penalty_amount": effective_penalty_amount,
        "penalty_pct": effective_penalty_pct,
        "used_helper_ids": used_helper_ids,
        "gun_inv_id": gun_inv_id,
        "gun_rule_id": gun_rule_id,
    }


# ---------------------------------------------------------------------------
# ورودی: تایپِ «قاچاق هاپویی»
# ---------------------------------------------------------------------------

async def handle_smuggling_trigger(update, context):
    """اگه همین الان یه عملیاتِ فعال داره، به‌جایِ بازکردنِ لیستِ جدید، وضعیتِ
    همون رو نشون می‌ده - چه وسطِ یه انتظارِ زمان‌دار باشه (می‌نویسه چقدر مونده)
    چه منتظرِ انتخابِ گزینه‌ی مرحله‌ی جاری. قبلاً این چک نبود و بات فکر می‌کرد
    یه قاچاقِ جدیده."""
    owner_id = update.effective_user.id
    session = db.get_session()
    try:
        op = (
            session.query(db.SmugglingOperation)
            .filter_by(user_id=owner_id, status="active")
            .order_by(db.SmugglingOperation.id.desc())
            .first()
        )
        if op:
            good = session.get(db.SmugglingGood, op.good_id)
            gname = good.name if good else "کالا"
            left = _remaining_wait(op)
            if left.total_seconds() > 0:
                await send_response(
                    update,
                    f"📦 {gname} — عملیاتت هنوز در جریانه.\n\n" + _pending_text(op),
                    _pending_keyboard(op),
                )
                return
            stages = _stage_list(session, op.good_id)
            try:
                stage = stages[op.current_stage_order - 1]
            except IndexError:
                stage = None
            if stage:
                if op.stage_ready_at:
                    # انتظارش تموم شده ولی هنوز مرحله‌ی بعدی رندر نشده بود
                    op.stage_ready_at = None
                    note = op.pending_note or ""
                    op.pending_note = ""
                    session.commit()
                    if note:
                        await send_response(update, f"✅ انتظارِ مرحله تموم شد!\n\n{note}", None)
                await _render_stage(update, context, session, op, stage, owner_id)
                return
    finally:
        session.close()
    await _show_today_list(update, context)


async def cb_smg_pending(update, context):
    """دکمه‌ی «بررسیِ وضعیت» زیرِ یه مرحله‌ی زمان‌دار."""
    _, op_id, owner_id = update.callback_query.data.split(":")
    op_id, owner_id = int(op_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        op = session.get(db.SmugglingOperation, op_id)
        if not op or op.user_id != owner_id or op.status != "active":
            await update.callback_query.answer("❌ این عملیات دیگه فعال نیست.", show_alert=True)
            return
        left = _remaining_wait(op)
        if left.total_seconds() > 0:
            await update.callback_query.answer(f"⏳ هنوز {fmt_wait(left)} مونده.", show_alert=True)
            return
        stages = _stage_list(session, op.good_id)
        try:
            stage = stages[op.current_stage_order - 1]
        except IndexError:
            await update.callback_query.answer("❌ خطا در مراحل.", show_alert=True)
            return
        op.stage_ready_at = None
        note = op.pending_note or ""
        op.pending_note = ""
        session.commit()
        if note:
            await send_response(update, f"✅ انتظارِ مرحله تموم شد!\n\n{note}", None)
        await _render_stage(update, context, session, op, stage, owner_id)
    finally:
        session.close()


async def cb_smg_abort_ask(update, context):
    _, op_id, owner_id = update.callback_query.data.split(":")
    op_id, owner_id = int(op_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    rows = [[
        InlineKeyboardButton("✅ بله، لغو کن", callback_data=f"smg_abort_do:{op_id}:{owner_id}"),
        InlineKeyboardButton("🔙 نه", callback_data=f"smg_pending:{op_id}:{owner_id}"),
    ]]
    await send_response(
        update,
        "⚠️ مطمئنی می‌خوای عملیات رو لغو کنی؟\nهزینه‌ای که دادی برنمی‌گرده و سهمِ امروزت از این کالا مصرف‌شده می‌مونه.",
        InlineKeyboardMarkup(rows),
    )


async def cb_smg_abort_do(update, context):
    _, op_id, owner_id = update.callback_query.data.split(":")
    op_id, owner_id = int(op_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        op = session.get(db.SmugglingOperation, op_id)
        if not op or op.user_id != owner_id or op.status != "active":
            await update.callback_query.answer("❌ این عملیات دیگه فعال نیست.", show_alert=True)
            return
        op.status = "cancelled"
        op.ended_at = _nowt()
        op.result_note = "لغو توسطِ خودِ پلیر"
        session.commit()
    finally:
        session.close()
    await send_response(update, "🛑 عملیات لغو شد.", None)


async def cb_smg_home(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await _show_today_list(update, context)


async def _show_today_list(update, context):
    owner_id = update.effective_user.id
    session = db.get_session()
    try:
        goods = session.query(db.SmugglingGood).filter_by(active=True, show_in_today=True).order_by(db.SmugglingGood.id).all()
        if not goods:
            await send_response(update, "🚚 قاچاق‌های امروز\n\nهنوز هیچ کالایی برای قاچاق تعریف نشده.", None)
            return
        rows = []
        lines = ["🚚 قاچاق‌های امروز\n"]
        for g in goods:
            used = has_used_today(session, owner_id, g.id)
            n_stages = session.query(db.SmugglingStage).filter_by(good_id=g.id, active=True).count()
            tag = " (امروز انجام دادی ✅)" if used else ""
            lines.append(
                f"\n📦 {g.name}{tag}\nریسکِ کلی: {fmt(g.overall_risk_display or 0)}٪ | پاداش: {fmt(g.reward)} 🪙 | "
                f"هزینه: {fmt(g.cost)} 🪙 | مراحل: {n_stages}"
            )
            rows.append([InlineKeyboardButton(f"📦 {g.name}", callback_data=f"smg_good_view:{g.id}:{owner_id}")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_smg_good_view(update, context):
    _, gid, owner_id = update.callback_query.data.split(":")
    gid, owner_id = int(gid), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        g = session.get(db.SmugglingGood, gid)
        if not g or not g.active:
            await send_response(update, "❌ این کالا دیگه موجود نیست.", None)
            return
        n_stages = session.query(db.SmugglingStage).filter_by(good_id=g.id, active=True).count()
        already = has_used_today(session, owner_id, gid)
        text = (
            f"📦 {g.name}\n{g.description or ''}\n\n"
            f"ریسکِ کلی: {fmt(g.overall_risk_display or 0)}٪\nپاداش: {fmt(g.reward)} 🪙\nهزینه: {fmt(g.cost)} 🪙\n"
            f"تعدادِ مراحل: {n_stages}\n"
        )
        if g.min_level:
            text += f"حداقلِ سطحِ لازم: {g.min_level}\n"
        rows = []
        if already:
            text += "\n❌ امروز این کالا رو قبلاً قاچاق کردی؛ فردا دوباره امکانش هست."
        else:
            rows.append([InlineKeyboardButton("🚀 شروعِ عملیات", callback_data=f"smg_start:{gid}:{owner_id}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"smg_home:{owner_id}")])
        await send_response(update, text.strip(), InlineKeyboardMarkup(rows))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# شروعِ عملیات
# ---------------------------------------------------------------------------

async def cb_smg_start(update, context):
    _, gid, owner_id = update.callback_query.data.split(":")
    gid, owner_id = int(gid), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        g = session.get(db.SmugglingGood, gid)
        if not g or not g.active:
            await update.callback_query.answer("❌ این کالا دیگه موجود نیست.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if g.min_level and (user.level or 1) < g.min_level:
            await update.callback_query.answer(f"❌ حداقل باید سطح {g.min_level} باشی.", show_alert=True)
            return

        if db.cfg_get(session, "smuggling_allow_concurrent_operations") != "1":
            active_op = session.query(db.SmugglingOperation).filter_by(user_id=owner_id, status="active").first()
            if active_op:
                await update.callback_query.answer("❌ یه عملیاتِ دیگه‌ات هنوز فعاله؛ اول اونو تموم کن.", show_alert=True)
                return

        if has_used_today(session, owner_id, gid):
            await update.callback_query.answer("❌ امروز این کالا رو قبلاً قاچاق کردی.", show_alert=True)
            return

        stages = session.query(db.SmugglingStage).filter_by(good_id=gid, active=True).order_by(db.SmugglingStage.order_index).all()
        if not stages:
            await update.callback_query.answer("❌ هنوز مرحله‌ای برای این کالا تعریف نشده.", show_alert=True)
            return

        if g.cost and user.hop_points < g.cost - 0.5:
            await update.callback_query.answer(f"❌ موجودی کافی نیست! {fmt(g.cost)} 🪙 لازمه.", show_alert=True)
            return

        # رزروِ سهمِ روزانه - این خطِ اول باید موفق بشه، وگرنه یعنی یکی دیگه (یا
        # همین کاربر تو یه تلاشِ هم‌زمانِ دیگه) زودتر برده
        if not try_reserve_daily_slot(session, owner_id, gid):
            await update.callback_query.answer("❌ امروز این کالا رو قبلاً قاچاق کردی.", show_alert=True)
            return

        if g.cost:
            user.hop_points -= g.cost

        op = db.SmugglingOperation(
            user_id=owner_id, good_id=gid, chat_id=update.effective_chat.id,
            current_stage_order=1, total_stages=len(stages), status="active", cost_paid=g.cost or 0,
        )
        session.add(op)
        session.commit()

        usage_row = session.query(db.SmugglingDailyUsage).filter_by(user_id=owner_id, good_id=gid, usage_date=today_str()).first()
        if usage_row:
            usage_row.operation_id = op.id
            session.commit()

        await _render_stage(update, context, session, op, stages[0], owner_id, first=True)
    finally:
        session.close()


def _stage_list(session, good_id):
    return session.query(db.SmugglingStage).filter_by(good_id=good_id, active=True).order_by(db.SmugglingStage.order_index).all()


async def _render_stage(update, context, session, op: db.SmugglingOperation, stage: db.SmugglingStage, owner_id, first=False):
    options = session.query(db.SmugglingOption).filter_by(stage_id=stage.id, active=True).all()
    rows = [[InlineKeyboardButton(o.name, callback_data=f"smg_opt:{op.id}:{o.id}:{owner_id}")] for o in options]
    rows.append([InlineKeyboardButton("🛒 نیروهای کمکی", callback_data=f"smg_helpers:{op.id}:{owner_id}")])
    text = (
        f"🚚 مرحله‌ی {op.current_stage_order} از {op.total_stages}\n\n"
        f"{stage.name}\n{stage.description or ''}"
    )
    if not options:
        text += "\n\n⚠️ برای این مرحله هنوز گزینه‌ای تعریف نشده."
    msg = await send_response(update, text.strip(), InlineKeyboardMarkup(rows) if rows else None)
    op.last_action_at = _nowt()
    if msg is not None:
        op.chat_id = msg.chat_id
        op.message_id = msg.message_id
    session.commit()


async def cb_smg_option(update, context):
    _, op_id, opt_id, owner_id = update.callback_query.data.split(":")
    op_id, opt_id, owner_id = int(op_id), int(opt_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        op = session.get(db.SmugglingOperation, op_id)
        if not op or op.user_id != owner_id or op.status != "active":
            await update.callback_query.answer("❌ این عملیات دیگه فعال نیست.", show_alert=True)
            return
        option = session.get(db.SmugglingOption, opt_id)
        if not option or not option.active or option.good_id != op.good_id:
            await update.callback_query.answer("❌ این گزینه معتبر نیست.", show_alert=True)
            return
        op.last_action_at = _nowt()
        session.commit()
        stages = _stage_list(session, op.good_id)
        try:
            stage = stages[op.current_stage_order - 1]
        except IndexError:
            await update.callback_query.answer("❌ خطا در مراحل.", show_alert=True)
            return
        if option.stage_id != stage.id:
            await update.callback_query.answer("❌ این گزینه مالِ این مرحله نیست.", show_alert=True)
            return

        eligible = eligible_helpers_for_option(session, owner_id, op.good_id, stage.id, option.id)
        gun_eq = attack.get_equipped(session, owner_id, "gun")
        gun_rules = session.query(db.SmugglingGunRule).filter_by(active=True).all()
        gun_allowed = bool(gun_eq) and bool(_matching_rules(gun_rules, op.good_id, stage.id, option.id))

        if eligible or gun_allowed:
            rows = []
            for uh, helper, rule, trust_row in eligible:
                rows.append([InlineKeyboardButton(
                    f"🤝 {helper.name} (Trust {fmt(trust_row.trust)})",
                    callback_data=f"smg_resolve:{op.id}:{option.id}:h{uh.id}:{owner_id}",
                )])
            if gun_allowed:
                rows.append([InlineKeyboardButton("🔫 استفاده از اسلحه", callback_data=f"smg_resolve:{op.id}:{option.id}:g:{owner_id}")])
            rows.append([InlineKeyboardButton("▶️ بدونِ نیرو/اسلحه", callback_data=f"smg_resolve:{op.id}:{option.id}:n:{owner_id}")])
            await send_response(update, "می‌خوای از نیروی کمکی یا اسلحه استفاده کنی؟", InlineKeyboardMarkup(rows))
            return

        await _resolve_option(update, context, session, op, option, stage, helper_choice_id=None, use_gun=False)
    finally:
        session.close()


async def cb_smg_resolve(update, context):
    _, op_id, opt_id, choice, owner_id = update.callback_query.data.split(":")
    op_id, opt_id, owner_id = int(op_id), int(opt_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        op = session.get(db.SmugglingOperation, op_id)
        if not op or op.user_id != owner_id or op.status != "active":
            await update.callback_query.answer("❌ این عملیات دیگه فعال نیست.", show_alert=True)
            return
        option = session.get(db.SmugglingOption, opt_id)
        stages = _stage_list(session, op.good_id)
        try:
            stage = stages[op.current_stage_order - 1]
        except IndexError:
            await update.callback_query.answer("❌ خطا در مراحل.", show_alert=True)
            return
        if not option or option.stage_id != stage.id:
            await update.callback_query.answer("❌ این گزینه معتبر نیست.", show_alert=True)
            return

        op.last_action_at = _nowt()
        session.commit()

        helper_choice_id = None
        use_gun = False
        if choice.startswith("h"):
            helper_choice_id = int(choice[1:])
            uh = session.get(db.SmugglingUserHelper, helper_choice_id)
            if not uh or uh.user_id != owner_id or (uh.uses_remaining is not None and uh.uses_remaining <= 0):
                await update.callback_query.answer("❌ این نیرو دیگه معتبر نیست.", show_alert=True)
                return
        elif choice == "g":
            use_gun = True

        await _resolve_option(update, context, session, op, option, stage, helper_choice_id, use_gun)
    finally:
        session.close()


async def _resolve_option(update, context, session, op: db.SmugglingOperation, option: db.SmugglingOption,
                           stage: db.SmugglingStage, helper_choice_id, use_gun):
    good = session.get(db.SmugglingGood, op.good_id)
    user = session.get(db.User, op.user_id)
    eff = compute_effective_option(session, user, good, stage, option, helper_choice_id, use_gun)

    roll = random.uniform(0, 100)
    passed = roll < eff["success_pct"]

    if helper_choice_id:
        uh = session.get(db.SmugglingUserHelper, helper_choice_id)
        helper = session.get(db.SmugglingHelper, uh.helper_id)
        trust_row = get_or_create_trust(session, user.telegram_id, helper)
        gain_trust_from_use(session, trust_row, helper)
        if uh.uses_remaining is not None:
            uh.uses_remaining -= 1
            if uh.uses_remaining <= 0:
                session.delete(uh)
    if eff["gun_inv_id"]:
        gun_rule = session.get(db.SmugglingGunRule, eff["gun_rule_id"])
        if gun_rule and gun_rule.consumes_use:
            gun_inv = session.get(db.InventoryItem, eff["gun_inv_id"])
            attack.consume_use(session, gun_inv)

    session.add(db.SmugglingOperationStage(
        operation_id=op.id, stage_id=stage.id, option_id=option.id,
        success_chance_used=eff["success_pct"], success_roll=roll, passed=passed,
        helpers_used_json=json.dumps(eff["used_helper_ids"]), gun_rule_id=eff["gun_rule_id"],
    ))

    owner_id = op.user_id
    if not passed:
        op.status = "failed"
        op.ended_at = _nowt()
        penalty = eff["penalty_amount"]
        if eff["penalty_pct"]:
            penalty += (user.hop_points or 0) * (eff["penalty_pct"] / 100.0)
        penalty = min(penalty, user.hop_points or 0) if penalty > 0 else 0
        if penalty > 0:
            user.hop_points -= penalty
        op.penalty_total = penalty
        op.result_note = option.fail_text or ""

        # شکستِ عملیات -> زندانِ هاپویی (پیش‌فرض ۳۰ دقیقه با وثیقه‌ی ۱۴.۵ میلیون؛
        # هردو از پنلِ «⚙️ تنظیماتِ کلیِ قاچاق» قابلِ تغییرن، ۰ دقیقه یعنی خاموش)
        jail_min = int(db.cfg_get_float(session, "smuggling_fail_jail_minutes") or 0)
        jail_bail = db.cfg_get_float(session, "smuggling_fail_jail_bail") or 0
        jail_line = ""
        if jail_min > 0 and not handlers.is_owner(user.telegram_id):
            user.jailed_until = _nowt() + datetime.timedelta(minutes=jail_min)
            user.jail_bail_amount = jail_bail
            user.jail_reason = "smuggling"
            jail_line = (
                f"\n\n🔒 دستگیر شدی! {jail_min} دقیقه زندانِ هاپویی.\n"
                f"💸 برای آزادیِ زودهنگام بنویس «وثیقه» ({fmt(jail_bail)} 🪙)."
            )

        session.commit()
        text = f"💥 عملیات شکست خورد!\n\n{option.fail_text or ''}".strip()
        if penalty:
            text += f"\n\n⚠️ جریمه: {fmt(penalty)} 🪙"
        text += jail_line
        await send_response(update, text, None)
        return

    op.reward_total = (op.reward_total or 0) + eff["reward_bonus"]

    if op.current_stage_order >= op.total_stages:
        op.status = "success"
        op.ended_at = _nowt()
        total_reward = (good.reward or 0) + (op.reward_total or 0)
        user.hop_points += total_reward
        op.reward_total = total_reward
        op.result_note = option.success_text or ""
        session.commit()
        text = f"🎉 عملیات با موفقیت کامل شد!\n\n{option.success_text or ''}\n\n💰 پاداش: {fmt(total_reward)} 🪙".strip()
        await send_response(update, text, None)
        return

    op.current_stage_order += 1

    # گزینه‌ی زمان‌دار: تا وقتی مهلتش نرسیده، مرحله‌ی بعدی اصلاً باز نمی‌شه.
    # قبلاً time_minutes تو دیتابیس تعریف شده بود ولی هیچ‌جا خونده نمی‌شد -
    # برای همین «مسیرِ امنِ ۵۰ دقیقه» هیچ اثری نداشت و فوراً می‌رفت مرحله‌ی بعد.
    delay = option.time_minutes or 0
    if delay > 0:
        op.stage_ready_at = _nowt() + datetime.timedelta(minutes=delay)
        op.pending_note = option.success_text or "✅ موفق شدی!"
        session.commit()
        await send_response(update, _pending_text(op, option.success_text), _pending_keyboard(op))
        return

    op.stage_ready_at = None
    op.pending_note = ""
    session.commit()
    stages = _stage_list(session, op.good_id)
    next_stage = stages[op.current_stage_order - 1]
    note = option.success_text or "✅ موفق شدی!"
    await send_response(update, note, None)
    await _render_stage(update, context, session, op, next_stage, owner_id)


def _remaining_wait(op) -> datetime.timedelta:
    """چقدر از انتظارِ مرحله‌ی زمان‌دار مونده (اگه چیزی نمونده، صفر)."""
    if not op.stage_ready_at:
        return datetime.timedelta(0)
    left = op.stage_ready_at - _nowt()
    return left if left.total_seconds() > 0 else datetime.timedelta(0)


def fmt_wait(delta: datetime.timedelta) -> str:
    total = int(delta.total_seconds())
    if total <= 0:
        return "همین الان"
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    if h:
        return f"{h} ساعت و {m} دقیقه"
    if m:
        return f"{m} دقیقه و {s} ثانیه"
    return f"{s} ثانیه"


def _pending_text(op, success_text=None) -> str:
    left = _remaining_wait(op)
    parts = []
    if success_text:
        parts.append(success_text.strip())
    parts.append(
        f"⏳ در انتظارِ پایانِ مرحله...\n\n"
        f"مرحله‌ی بعدی ({op.current_stage_order} از {op.total_stages}) بعد از "
        f"{fmt_wait(left)} دیگه باز می‌شه.\n"
        f"هر وقت خواستی با نوشتنِ «قاچاق هاپویی» وضعیتت رو ببین — عملیاتت از بین نمی‌ره."
    )
    return "\n\n".join(parts)


def _pending_keyboard(op):
    return InlineKeyboardMarkup([
        [InlineKeyboardButton("🔄 بررسیِ وضعیت", callback_data=f"smg_pending:{op.id}:{op.user_id}")],
        [InlineKeyboardButton("🛑 لغوِ عملیات", callback_data=f"smg_abort_ask:{op.id}:{op.user_id}")],
    ])


# ---------------------------------------------------------------------------
# خریدِ نیروهای کمکی (از داخلِ خودِ عملیات، برای مرحله‌ی جاری)
# ---------------------------------------------------------------------------

async def _get_active_op_stage(session, op_id, owner_id):
    """عملیاتِ فعال + مرحله‌ی جاریش رو برمی‌گردونه، یا (None, None) اگه معتبر
    نبود."""
    op = session.get(db.SmugglingOperation, op_id)
    if not op or op.user_id != owner_id or op.status != "active":
        return None, None
    stages = _stage_list(session, op.good_id)
    try:
        stage = stages[op.current_stage_order - 1]
    except IndexError:
        return op, None
    return op, stage


async def cb_smg_helpers(update, context):
    """صفحه‌ی «نیروهای کمکی» برایِ مرحله‌ی جاری: اگه هیچ نیرویی برایِ این
    مرحله تعریف نشده باشه می‌نویسه وجود نداره، وگرنه لیستِ نیروها + دقیقاً
    رویِ کدوم گزینه اثر می‌ذارن رو نشون می‌ده، هرکدوم با یه دکمه‌ی خرید."""
    _, op_id, owner_id = update.callback_query.data.split(":")
    op_id, owner_id = int(op_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        op, stage = await _get_active_op_stage(session, op_id, owner_id)
        if not op:
            await update.callback_query.answer("❌ این عملیات دیگه فعال نیست.", show_alert=True)
            return
        if not stage:
            await update.callback_query.answer("❌ خطا در مراحل.", show_alert=True)
            return
        op.last_action_at = _nowt()
        session.commit()

        helpers = helpers_available_for_stage(session, op.good_id, stage.id)
        rows = []
        if not helpers:
            text = "❌ نیروی کمکی‌ای برای این مرحله وجود نداره."
        else:
            lines = ["🛒 نیروهای کمکیِ این مرحله:\n"]
            for helper, opt_names in helpers:
                affects = "، ".join(opt_names) if opt_names else "همه‌ی گزینه‌های این مرحله"
                lines.append(f"🤝 {helper.name} — {fmt(helper.price or 0)} 🪙\nاثر رو گزینه‌ی: {affects}\n")
                rows.append([InlineKeyboardButton(
                    f"🛒 خریدِ {helper.name}", callback_data=f"smg_helper_buy_ask:{op.id}:{helper.id}:{owner_id}",
                )])
            text = "\n".join(lines).strip()
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"smg_helper_back_stage:{op.id}:{owner_id}")])
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_smg_helper_back_stage(update, context):
    _, op_id, owner_id = update.callback_query.data.split(":")
    op_id, owner_id = int(op_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        op, stage = await _get_active_op_stage(session, op_id, owner_id)
        if not op:
            await update.callback_query.answer("❌ این عملیات دیگه فعال نیست.", show_alert=True)
            return
        if not stage:
            await update.callback_query.answer("❌ خطا در مراحل.", show_alert=True)
            return
        await _render_stage(update, context, session, op, stage, owner_id)
    finally:
        session.close()


async def cb_smg_helper_buy_ask(update, context):
    """صفحه‌ی «آیا مطمئنی؟» برایِ خریدِ یه نیرویِ کمکیِ خاص."""
    _, op_id, helper_id, owner_id = update.callback_query.data.split(":")
    op_id, helper_id, owner_id = int(op_id), int(helper_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        op, stage = await _get_active_op_stage(session, op_id, owner_id)
        if not op:
            await update.callback_query.answer("❌ این عملیات دیگه فعال نیست.", show_alert=True)
            return
        helper = session.get(db.SmugglingHelper, helper_id)
        if not helper or not helper.active:
            await update.callback_query.answer("❌ این نیرو دیگه موجود نیست.", show_alert=True)
            return
        op.last_action_at = _nowt()
        session.commit()
        text = (
            f"⚠️ آیا مطمئنی می‌خوای «{helper.name}» رو به قیمتِ {fmt(helper.price or 0)} 🪙 بخری؟\n"
            f"{helper.description or ''}".strip()
        )
        rows = [
            [InlineKeyboardButton("✅ تایید", callback_data=f"smg_helper_buy_confirm:{op.id}:{helper.id}:{owner_id}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data=f"smg_helpers:{op.id}:{owner_id}")],
        ]
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_smg_helper_buy_confirm(update, context):
    """خریدِ واقعی؛ بعدش برمی‌گرده به همون صفحه‌ی «نیروهای کمکی» (یه قدم
    عقب، دقیقاً طبقِ درخواست)."""
    _, op_id, helper_id, owner_id = update.callback_query.data.split(":")
    op_id, helper_id, owner_id = int(op_id), int(helper_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        op, stage = await _get_active_op_stage(session, op_id, owner_id)
        if not op:
            await update.callback_query.answer("❌ این عملیات دیگه فعال نیست.", show_alert=True)
            return
        helper = session.get(db.SmugglingHelper, helper_id)
        if not helper or not helper.active:
            await update.callback_query.answer("❌ این نیرو دیگه موجود نیست.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        price = helper.price or 0
        if user.hop_points < price - 0.5:
            await update.callback_query.answer(f"❌ موجودی کافی نیست! {fmt(price)} 🪙 لازمه.", show_alert=True)
            return
        user.hop_points -= price
        expires_at = None
        if helper.duration_minutes:
            expires_at = _nowt() + datetime.timedelta(minutes=helper.duration_minutes)
        session.add(db.SmugglingUserHelper(
            user_id=owner_id, helper_id=helper.id, uses_remaining=helper.uses, expires_at=expires_at,
        ))
        op.last_action_at = _nowt()
        session.commit()
        await update.callback_query.answer(f"✅ «{helper.name}» خریداری شد.", show_alert=True)
    finally:
        session.close()
    await cb_smg_helpers(update, context)


# ---------------------------------------------------------------------------
# لغوِ خودکارِ عملیاتِ بی‌حرکت‌مونده
# ---------------------------------------------------------------------------

async def tick_smuggling_operation_timeouts(session, context):
    """عملیات‌هایِ فعالی که یا واقعاً بی‌حرکت موندن یا از مرزِ روزِ تقویمی
    (UTC) رد شدن رو خودکار لغو می‌کنه.

    نکته‌ی مهم (باگی که رفع شد): تا قبلِ این، به‌محضِ تموم‌شدنِ انتظارِ یه
    گزینه‌ی زمان‌دار (stage_ready_at)، همون لحظه به‌عنوانِ «آخرین حرکت» حساب
    می‌شد و همون مهلتِ کوتاهِ بی‌حرکتی (پیش‌فرض ۱۲۰ ثانیه) روش اعمال می‌شد -
    یعنی اگه کاربر ثانیه‌ای بعدِ اتمامِ انتظار برنگرده، عملیات خودکار لغو
    می‌شد؛ درحالی‌که کلِ فلسفه‌ی گزینه‌ی زمان‌دار همینه که بره و هرچقدر خواست
    (حتی چند ساعت بعد) برگرده. الان بعدِ رسیدنِ stage_ready_at، عملیات دیگه
    اصلاً مشمولِ مهلتِ کوتاهِ بی‌حرکتی نمی‌شه؛ تنها چیزی که همچنان می‌تونه
    لغوش کنه رد شدنِ از مرزِ روزه (پایین‌تر)."""
    timeout_s = int(db.cfg_get_float(session, "smuggling_inactivity_timeout_seconds"))
    cutoff = _nowt() - datetime.timedelta(seconds=timeout_s)
    today = today_str()
    stale = session.query(db.SmugglingOperation).filter(db.SmugglingOperation.status == "active").all()
    for op in stale:
        cancel_note = None

        started_day = (op.started_at or _nowt()).strftime("%Y-%m-%d")
        if started_day != today:
            # مرزِ روز رد شده: این عملیات، حتی اگه هنوز وسطِ انتظارِ یه گزینه‌ی
            # زمان‌دار هم باشه، دیگه معتبر نیست و انگار که اصلاً اتفاق نیفتاده
            # لغو می‌شه (بدونِ جریمه) تا کاربر بتونه از نو شروع کنه.
            cancel_note = "این عملیات به روزِ بعد رسید و به‌صورتِ خودکار لغو شد؛ انگار که اصلاً شروع نشده بود."
        elif op.stage_ready_at and op.stage_ready_at > _nowt():
            # وسطِ انتظارِ یه گزینه‌ی زمان‌داره - هنوز اصلاً بهش دست نزن
            continue
        elif op.stage_ready_at and op.stage_ready_at <= _nowt():
            # انتظارِ زمان‌دار همون امروز تموم شده - دیگه هیچ مهلتِ بی‌حرکتی‌ای
            # روش اعمال نمی‌شه؛ هرچقدر هم که امروز طول بکشه تا کاربر برگرده،
            # مشکلی نیست (فقط مرزِ روز که بالاتر چک شد می‌تونه لغوش کنه)
            continue
        else:
            last = op.last_action_at or op.started_at
            if last is None or last >= cutoff:
                continue
            cancel_note = "لغوِ خودکار به‌خاطرِ بی‌حرکتی"

        op.status = "cancelled"
        op.ended_at = _nowt()
        op.result_note = cancel_note
        if op.chat_id and op.message_id:
            try:
                await context.bot.edit_message_text(
                    chat_id=op.chat_id, message_id=op.message_id,
                    text=f"⏱ {cancel_note}",
                )
            except Exception:
                pass
        session.commit()


# ---------------------------------------------------------------------------
# مسیریاب
# ---------------------------------------------------------------------------

SMG_PREFIX_MAP = {
    "smg_home": cb_smg_home,
    "smg_good_view": cb_smg_good_view,
    "smg_start": cb_smg_start,
    "smg_opt": cb_smg_option,
    "smg_resolve": cb_smg_resolve,
    "smg_helpers": cb_smg_helpers,
    "smg_helper_back_stage": cb_smg_helper_back_stage,
    "smg_helper_buy_ask": cb_smg_helper_buy_ask,
    "smg_helper_buy_confirm": cb_smg_helper_buy_confirm,
    "smg_pending": cb_smg_pending,
    "smg_abort_ask": cb_smg_abort_ask,
    "smg_abort_do": cb_smg_abort_do,
}


async def smg_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = SMG_PREFIX_MAP.get(prefix)
    if handler:
        await handler(update, context)
        return True
    return False


# ---------------------------------------------------------------------------
# پنلِ ادمین (CRUD کامل - از الگویِ ADMIN_PREFIX_CALLBACK_MAP.update(...) که
# guide.py استفاده می‌کنه پیروی می‌کنه؛ نگاه کن به انتهایِ admin.py)
# ---------------------------------------------------------------------------

from handlers import is_owner  # noqa: E402


def _parse_pipe(text, field_names, optional_fields=frozenset(), int_fields=frozenset(), text_fields=frozenset()):
    parts = [p.strip() for p in text.split("|")]
    if len(parts) != len(field_names):
        raise ValueError(f"باید دقیقاً {len(field_names)} فیلد با | جدا بفرستی")
    out = {}
    for name, raw in zip(field_names, parts):
        if name in text_fields:
            out[name] = raw
            continue
        if name in optional_fields and raw == "-":
            out[name] = None
            continue
        try:
            val = float(raw)
        except ValueError:
            raise ValueError(f"مقدارِ «{raw}» برایِ {name} عددی نیست")
        if name in int_fields:
            val = int(val)
        out[name] = val
    return out


def _id_or_none(v):
    return None if v is None else int(v)


async def cb_admin_smg_menu(update, context):
    rows = [
        [InlineKeyboardButton("📦 کالاهایِ قاچاق", callback_data="admin_smg_goods")],
        [InlineKeyboardButton("🗂 دسته‌مرحله‌ها", callback_data="admin_smg_tplgroups")],
        [InlineKeyboardButton("🤝 نیروهایِ کمکی", callback_data="admin_smg_helpers")],
        [InlineKeyboardButton("🔫 قوانینِ اسلحه", callback_data="admin_smg_gun_rules")],
        [InlineKeyboardButton("⚙️ تنظیماتِ کلی", callback_data="admin_smg_cfg")],
        [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_panel")],
    ]
    await send_response(update, "📦 قاچاق هاپویی - مدیریت:", InlineKeyboardMarkup(rows))


# ---- کالاها -----------------------------------------------------------

_GOOD_FIELDS = ["name", "description", "cost", "reward", "overall_risk_display", "min_level", "duration_minutes", "daily_limit_per_user"]
_GOOD_HINT = "نام | توضیح | هزینه | پاداش | ریسکِ کلی(نمایشی، یا -) | حداقلِ سطح(یا -) | مدت به دقیقه(یا -) | محدودیتِ روزانه"
_GOOD_OPT = {"overall_risk_display", "min_level", "duration_minutes"}
_GOOD_INT = {"min_level", "duration_minutes", "daily_limit_per_user"}
_GOOD_TXT = {"name", "description"}


async def cb_admin_smg_goods(update, context):
    session = db.get_session()
    try:
        goods = session.query(db.SmugglingGood).order_by(db.SmugglingGood.id).all()
        rows = []
        for g in goods:
            tag = "✅" if g.active else "⛔️"
            rows.append([InlineKeyboardButton(f"{tag} #{g.id} {g.name}", callback_data=f"admin_smg_good_view:{g.id}")])
        rows.append([InlineKeyboardButton("➕ کالایِ جدید", callback_data="admin_smg_good_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_smg_menu")])
        text = "📦 کالاهایِ قاچاق:" if goods else "📦 هنوز هیچ کالایی نساختی."
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_good_add(update, context):
    await ask_for_input(update, context, f"📝 اطلاعاتِ کالایِ جدید رو با | جدا بفرست:\n\n{_GOOD_HINT}", {"type": "smg_good_add"}, "admin_state")


async def cb_admin_smg_good_view(update, context):
    gid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.SmugglingGood, gid)
        if not g:
            await send_response(update, "این کالا پیدا نشد.", None)
            return
        n_stages = session.query(db.SmugglingStage).filter_by(good_id=gid).count()
        text = (
            f"📦 #{g.id} {g.name}\n{g.description or ''}\n\n"
            f"هزینه: {fmt(g.cost)} | پاداش: {fmt(g.reward)} | ریسکِ نمایشی: {fmt(g.overall_risk_display or 0)}٪\n"
            f"حداقلِ سطح: {g.min_level or '-'} | مدت: {g.duration_minutes or '-'} دقیقه | محدودیتِ روزانه: {g.daily_limit_per_user}\n"
            f"مراحل: {n_stages}\n\nفعال: {'✅' if g.active else '⛔️'} | تویِ «امروز»: {'✅' if g.show_in_today else '⛔️'}"
        )
        edit_labels = {
            "name": "✏️ نام", "description": "✏️ توضیح", "cost": "✏️ هزینه", "reward": "✏️ پاداش",
            "overall_risk_display": "✏️ ریسکِ نمایشی", "min_level": "✏️ حداقلِ سطح",
            "duration_minutes": "✏️ مدت", "daily_limit_per_user": "✏️ محدودیتِ روزانه",
        }
        rows = [[InlineKeyboardButton(label, callback_data=f"admin_smg_good_edit_ask:{gid}:{field}")] for field, label in edit_labels.items()]
        rows.append([InlineKeyboardButton("🗂 مدیریتِ مراحل", callback_data=f"admin_smg_stages:{gid}")])
        rows.append([InlineKeyboardButton("⛔️ غیرفعال کردن" if g.active else "✅ فعال کردن", callback_data=f"admin_smg_good_toggle:{gid}")])
        rows.append([InlineKeyboardButton("👁 حذف از «امروز»" if g.show_in_today else "👁 افزودن به «امروز»", callback_data=f"admin_smg_good_toggle_today:{gid}")])
        rows.append([InlineKeyboardButton("🗑 حذفِ کالا", callback_data=f"admin_smg_good_delete_ask:{gid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_smg_goods")])
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_good_edit_ask(update, context):
    _, gid, field = update.callback_query.data.split(":")
    await ask_for_input(update, context, "✏️ مقدارِ جدید رو بفرست:", {"type": "smg_good_edit", "id": int(gid), "field": field}, "admin_state")


async def cb_admin_smg_good_toggle(update, context):
    gid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.SmugglingGood, gid)
        if g:
            g.active = not g.active
            session.commit()
    finally:
        session.close()
    await cb_admin_smg_good_view(update, context)


async def cb_admin_smg_good_toggle_today(update, context):
    gid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.SmugglingGood, gid)
        if g:
            g.show_in_today = not g.show_in_today
            session.commit()
    finally:
        session.close()
    await cb_admin_smg_good_view(update, context)


async def cb_admin_smg_good_delete_ask(update, context):
    gid = int(update.callback_query.data.split(":")[1])
    rows = [[
        InlineKeyboardButton("✅ بله، حذفش کن", callback_data=f"admin_smg_good_delete_confirm:{gid}"),
        InlineKeyboardButton("❌ نه", callback_data=f"admin_smg_good_view:{gid}"),
    ]]
    await send_response(update, "مطمئنی؟ همه‌ی مراحل/گزینه‌های این کالا هم حذف می‌شن.", InlineKeyboardMarkup(rows))


async def cb_admin_smg_good_delete_confirm(update, context):
    gid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        stage_ids = [s.id for s in session.query(db.SmugglingStage.id).filter_by(good_id=gid).all()]
        if stage_ids:
            session.query(db.SmugglingOption).filter(db.SmugglingOption.stage_id.in_(stage_ids)).delete(synchronize_session=False)
        session.query(db.SmugglingStage).filter_by(good_id=gid).delete(synchronize_session=False)
        g = session.get(db.SmugglingGood, gid)
        if g:
            session.delete(g)
        session.commit()
    finally:
        session.close()
    await cb_admin_smg_goods(update, context)


# ---- مراحل --------------------------------------------------------------

_STAGE_FIELDS = ["name", "description", "slot_index", "order_index"]
_STAGE_HINT = "نام | توضیح | شماره‌ی اسلات (۱ تا ۲۵) | ترتیبِ نمایش"
_STAGE_INT = {"slot_index", "order_index"}
_STAGE_TXT = {"name", "description"}


async def cb_admin_smg_stages(update, context):
    gid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        stages = session.query(db.SmugglingStage).filter_by(good_id=gid).order_by(db.SmugglingStage.order_index).all()
        rows = []
        for s in stages:
            tag = "✅" if s.active else "⛔️"
            rows.append([InlineKeyboardButton(f"{tag} #{s.id} {s.name}", callback_data=f"admin_smg_stage_view:{s.id}")])
        rows.append([InlineKeyboardButton("➕ مرحله‌ی جدید", callback_data=f"admin_smg_stage_add:{gid}")])
        rows.append([InlineKeyboardButton("📋 اعمالِ یه دسته‌مرحله (کپیِ مراحل)", callback_data=f"admin_smg_good_apply_tpl_ask:{gid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_good_view:{gid}")])
        text = f"🗂 مراحلِ کالایِ #{gid} ({len(stages)}/25):"
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_good_apply_tpl_ask(update, context):
    """به‌جایِ ساختنِ دستیِ تک‌تکِ مرحله/گزینه برایِ این کالا، آیدیِ یه
    «دسته‌مرحله»ی از قبل ساخته‌شده رو می‌گیره و یه کپیِ کاملاً مستقل از همه‌ی
    مراحل/گزینه‌هاش رو به این کالا اضافه می‌کنه (کالاهایِ دیگه‌ای که قبلاً از
    همین دسته استفاده کردن دست‌نخورده می‌مونن، چون کپیِ هرکدوم جداست)."""
    gid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        groups = session.query(db.SmugglingStageTemplateGroup).order_by(db.SmugglingStageTemplateGroup.id).all()
        if not groups:
            await update.callback_query.answer("هنوز هیچ دسته‌مرحله‌ای نساختی؛ اول از «قاچاق هاپویی ← دسته‌مرحله‌ها» یکی بساز.", show_alert=True)
            return
        listing = "\n".join(f"#{g.id} {g.name}" for g in groups)
    finally:
        session.close()
    await ask_for_input(
        update, context,
        f"📋 آیدیِ دسته‌مرحله‌ای که می‌خوای رو این کالا کپی بشه رو بفرست:\n\n{listing}",
        {"type": "smg_good_apply_tpl", "good_id": gid}, "admin_state",
    )


async def cb_admin_smg_stage_add(update, context):
    gid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, f"📝 اطلاعاتِ مرحله‌ی جدید رو با | جدا بفرست:\n\n{_STAGE_HINT}", {"type": "smg_stage_add", "good_id": gid}, "admin_state")


async def cb_admin_smg_stage_view(update, context):
    sid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        s = session.get(db.SmugglingStage, sid)
        if not s:
            await send_response(update, "این مرحله پیدا نشد.", None)
            return
        n_opts = session.query(db.SmugglingOption).filter_by(stage_id=sid).count()
        text = f"🗂 #{s.id} {s.name}\n{s.description or ''}\n\nاسلات: {s.slot_index} | ترتیب: {s.order_index} | گزینه‌ها: {n_opts}\nفعال: {'✅' if s.active else '⛔️'}"
        edit_labels = {"name": "✏️ نام", "description": "✏️ توضیح", "slot_index": "✏️ اسلات", "order_index": "✏️ ترتیب"}
        rows = [[InlineKeyboardButton(label, callback_data=f"admin_smg_stage_edit_ask:{sid}:{field}")] for field, label in edit_labels.items()]
        rows.append([InlineKeyboardButton("🎛 مدیریتِ گزینه‌ها", callback_data=f"admin_smg_options:{sid}")])
        rows.append([InlineKeyboardButton("⛔️ غیرفعال کردن" if s.active else "✅ فعال کردن", callback_data=f"admin_smg_stage_toggle:{sid}")])
        rows.append([InlineKeyboardButton("🗑 حذفِ مرحله", callback_data=f"admin_smg_stage_delete_ask:{sid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_stages:{s.good_id}")])
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_stage_edit_ask(update, context):
    _, sid, field = update.callback_query.data.split(":")
    await ask_for_input(update, context, "✏️ مقدارِ جدید رو بفرست:", {"type": "smg_stage_edit", "id": int(sid), "field": field}, "admin_state")


async def cb_admin_smg_stage_toggle(update, context):
    sid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        s = session.get(db.SmugglingStage, sid)
        if s:
            s.active = not s.active
            session.commit()
    finally:
        session.close()
    await cb_admin_smg_stage_view(update, context)


async def cb_admin_smg_stage_delete_ask(update, context):
    sid = int(update.callback_query.data.split(":")[1])
    rows = [[
        InlineKeyboardButton("✅ بله", callback_data=f"admin_smg_stage_delete_confirm:{sid}"),
        InlineKeyboardButton("❌ نه", callback_data=f"admin_smg_stage_view:{sid}"),
    ]]
    await send_response(update, "مطمئنی؟ گزینه‌های این مرحله هم حذف می‌شن.", InlineKeyboardMarkup(rows))


async def cb_admin_smg_stage_delete_confirm(update, context):
    sid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        s = session.get(db.SmugglingStage, sid)
        gid = s.good_id if s else None
        session.query(db.SmugglingOption).filter_by(stage_id=sid).delete(synchronize_session=False)
        if s:
            session.delete(s)
        session.commit()
    finally:
        session.close()
    if gid:
        update.callback_query.data = f"admin_smg_stages:{gid}"
        await cb_admin_smg_stages(update, context)


# ---- گزینه‌ها -------------------------------------------------------------

_OPTION_FIELDS = ["name", "description", "risk_pct", "success_pct", "reward_bonus", "penalty_amount", "penalty_pct", "time_minutes"]
_OPTION_HINT = "نامِ دکمه | توضیح | ریسک(نمایشی٪) | شانسِ موفقیت٪ | پاداشِ اضافه | جریمه(مبلغ) | جریمه(٪ از هاپِ کاربر) | زمان به دقیقه(یا -)"
_OPTION_OPT = {"time_minutes"}
_OPTION_INT = {"time_minutes"}
_OPTION_TXT = {"name", "description"}


async def cb_admin_smg_options(update, context):
    sid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        options = session.query(db.SmugglingOption).filter_by(stage_id=sid).all()
        rows = []
        for o in options:
            tag = "✅" if o.active else "⛔️"
            rows.append([InlineKeyboardButton(f"{tag} #{o.id} {o.name}", callback_data=f"admin_smg_option_view:{o.id}")])
        rows.append([InlineKeyboardButton("➕ گزینه‌ی جدید", callback_data=f"admin_smg_option_add:{sid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_stage_view:{sid}")])
        await send_response(update, f"🎛 گزینه‌هایِ مرحله‌ی #{sid}:", InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_option_add(update, context):
    sid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, f"📝 اطلاعاتِ گزینه‌ی جدید رو با | جدا بفرست:\n\n{_OPTION_HINT}", {"type": "smg_option_add", "stage_id": sid}, "admin_state")


async def cb_admin_smg_option_view(update, context):
    oid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        o = session.get(db.SmugglingOption, oid)
        if not o:
            await send_response(update, "این گزینه پیدا نشد.", None)
            return
        text = (
            f"🎛 #{o.id} {o.name}\n{o.description or ''}\n\n"
            f"ریسک: {fmt(o.risk_pct)}٪ | شانسِ موفقیت: {fmt(o.success_pct)}٪\n"
            f"پاداشِ اضافه: {fmt(o.reward_bonus)} | جریمه: {fmt(o.penalty_amount)} + {fmt(o.penalty_pct)}٪\n"
            f"زمان: {o.time_minutes or '-'} دقیقه\nفعال: {'✅' if o.active else '⛔️'}\n\n"
            f"متنِ موفقیت: {o.success_text or '-'}\nمتنِ شکست: {o.fail_text or '-'}"
        )
        edit_labels = {
            "name": "✏️ نام", "description": "✏️ توضیح", "risk_pct": "✏️ ریسک", "success_pct": "✏️ شانسِ موفقیت",
            "reward_bonus": "✏️ پاداشِ اضافه", "penalty_amount": "✏️ جریمه(مبلغ)", "penalty_pct": "✏️ جریمه(٪)",
            "time_minutes": "✏️ زمان", "success_text": "✏️ متنِ موفقیت", "fail_text": "✏️ متنِ شکست",
        }
        rows = [[InlineKeyboardButton(label, callback_data=f"admin_smg_option_edit_ask:{oid}:{field}")] for field, label in edit_labels.items()]
        rows.append([InlineKeyboardButton("🎯 شانسِ واقعیِ این گزینه", callback_data=f"admin_smg_option_realchance:{oid}")])
        rows.append([InlineKeyboardButton("⛔️ غیرفعال کردن" if o.active else "✅ فعال کردن", callback_data=f"admin_smg_option_toggle:{oid}")])
        rows.append([InlineKeyboardButton("🗑 حذفِ گزینه", callback_data=f"admin_smg_option_delete_ask:{oid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_options:{o.stage_id}")])
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_option_realchance(update, context):
    """«شانسِ واقعیِ فلان دکمه در فلان مرحله» - نشون می‌ده یه پلیر واقعاً با چه
    درصدی این گزینه رو رد می‌کنه: هم شانسِ خامِ تنظیم‌شده، هم شانس بعد از
    اعمالِ هر نیرویِ کمکیِ مجاز (و اسلحه)، تا معلوم شه اون ۵۰٪ی که ست کردی با
    نیروی کمکی دقیقاً به چند درصد می‌رسه."""
    oid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        o = session.get(db.SmugglingOption, oid)
        if not o:
            await update.callback_query.answer("❌ پیدا نشد.", show_alert=True)
            return
        stage = session.get(db.SmugglingStage, o.stage_id)
        good = session.get(db.SmugglingGood, o.good_id)
        base = max(0.0, min(100.0, o.success_pct or 0))
        lines = [
            f"🎯 شانسِ واقعیِ «{o.name}»",
            f"📦 کالا: {good.name if good else '-'} | 🗂 مرحله: {stage.name if stage else '-'}\n",
            f"• شانسِ خام (بدونِ هیچ نیرو/اسلحه): {fmt(base)}٪",
            f"• یعنی از هر ۱۰۰ بار، حدوداً {int(round(base))} بار رد می‌شه و {int(round(100 - base))} بار شکست می‌خوره.\n",
        ]

        # اثرِ تک‌تکِ نیروهایِ کمکیِ مجاز رو همین گزینه
        rules = session.query(db.SmugglingHelperRule).filter_by(active=True).all()
        matched_rules = _matching_rules(rules, o.good_id, o.stage_id, o.id)
        by_helper = {}
        for r in matched_rules:
            cur = by_helper.get(r.helper_id)
            if cur is None or _specificity(r) > _specificity(cur):
                by_helper[r.helper_id] = r

        if not by_helper:
            lines.append("🤝 هیچ نیرویِ کمکی‌ای رو این گزینه اثر نداره (هیچ قانونِ محدوده‌ی اثری براش ثبت نشده).")
        else:
            lines.append("🤝 با نیروهایِ کمکی:")
            thresholds_all = session.query(db.SmugglingTrustThreshold).filter_by(active=True).all()
            for helper_id, rule in by_helper.items():
                helper = session.get(db.SmugglingHelper, helper_id)
                if not helper or not helper.active:
                    continue
                mode = helper.effect_combination_mode or "sum"
                cap = helper.effect_cap_pct
                # حالتِ پایه: فقط خودِ Rule (یعنی حداقلِ Trustِ لازم رو داره)
                delta_min = _combine(mode, [rule.effect_success_pct], cap) - _combine(mode, [rule.effect_risk_pct], cap)
                # حالتِ بیشینه: همه‌ی Thresholdهایِ این نیرو رو این گزینه هم فعال شدن
                ths = _matching_rules([t for t in thresholds_all if t.helper_id == helper_id], o.good_id, o.stage_id, o.id)
                s_vals = [rule.effect_success_pct] + [t.effect_success_pct for t in ths]
                r_vals = [rule.effect_risk_pct] + [t.effect_risk_pct for t in ths]
                delta_max = _combine(mode, s_vals, cap) - _combine(mode, r_vals, cap)
                low = max(0.0, min(100.0, base + delta_min))
                high = max(0.0, min(100.0, base + delta_max))
                if ths:
                    lines.append(
                        f"  • {helper.name} (حداقل Trust {fmt(rule.min_trust or 0)}): "
                        f"{fmt(low)}٪ ← تا {fmt(high)}٪ با Trustِ بالا ({len(ths)} آستانه)"
                    )
                else:
                    lines.append(f"  • {helper.name} (حداقل Trust {fmt(rule.min_trust or 0)}): {fmt(low)}٪")

        gun_rules = session.query(db.SmugglingGunRule).filter_by(active=True).all()
        gmatched = _matching_rules(gun_rules, o.good_id, o.stage_id, o.id)
        if gmatched:
            gr = max(gmatched, key=_specificity)
            if gr.power_per_trust:
                lines.append(
                    f"\n🔫 اسلحه: به‌ازای هر {fmt(gr.power_per_trust)} قدرت، "
                    f"{fmt(gr.effect_success_pct_per_trust or 0)}٪ شانس و "
                    f"{fmt(gr.effect_risk_pct_per_trust or 0)}٪ ریسک اضافه می‌شه."
                )
            else:
                lines.append("\n🔫 اسلحه: قانون هست ولی «قدرت به‌ازای هر Trust» صفره، پس عملاً بی‌اثره.")
        else:
            lines.append("\n🔫 اسلحه رو این گزینه اثر نداره.")

        lines.append(
            "\n📝 نکته: اگه یه پلیر چند نیرو داشته باشه، فقط همونی که تو خودِ لحظه‌ی "
            "بازی انتخاب می‌کنه اعمال می‌شه (نه همه با هم)، پس عددِ نهایی بینِ همین‌هاست."
        )
        rows = [[InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_option_view:{oid}")]]
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_option_edit_ask(update, context):
    _, oid, field = update.callback_query.data.split(":")
    await ask_for_input(update, context, "✏️ مقدارِ جدید رو بفرست:", {"type": "smg_option_edit", "id": int(oid), "field": field}, "admin_state")


async def cb_admin_smg_option_toggle(update, context):
    oid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        o = session.get(db.SmugglingOption, oid)
        if o:
            o.active = not o.active
            session.commit()
    finally:
        session.close()
    await cb_admin_smg_option_view(update, context)


async def cb_admin_smg_option_delete_ask(update, context):
    oid = int(update.callback_query.data.split(":")[1])
    rows = [[
        InlineKeyboardButton("✅ بله", callback_data=f"admin_smg_option_delete_confirm:{oid}"),
        InlineKeyboardButton("❌ نه", callback_data=f"admin_smg_option_view:{oid}"),
    ]]
    await send_response(update, "مطمئنی؟", InlineKeyboardMarkup(rows))


async def cb_admin_smg_option_delete_confirm(update, context):
    oid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        o = session.get(db.SmugglingOption, oid)
        sid = o.stage_id if o else None
        if o:
            session.delete(o)
            session.commit()
    finally:
        session.close()
    if sid:
        update.callback_query.data = f"admin_smg_options:{sid}"
        await cb_admin_smg_options(update, context)


# ---- دسته‌مرحله‌ها (قالبِ آماده‌یِ مرحله+گزینه) ----------------------------
#
# این بخش کاملاً جدا از کالاهاست: هرچی این‌جا ساخته می‌شه فقط یه «قالب»ه و
# مستقیم رو هیچ کالایی اثر نداره؛ تا وقتی ادمین از صفحه‌ی «مراحلِ کالا» دکمه‌ی
# «اعمالِ یه دسته‌مرحله» رو نزنه و آیدیِ این‌جا رو نده، هیچ اتفاقی نمی‌افته.
# بعدِ اعمال‌شدن هم، کپیِ ساخته‌شده کاملاً مستقل از قالب و از کپی‌هایِ روی
# کالاهایِ دیگه‌ست - تغییردادنِ بعدیِ قالب رو کالاهایی که قبلاً کپی گرفتن اثر
# نمی‌ذاره، و برعکس.

_TPL_STAGE_FIELDS = _STAGE_FIELDS
_TPL_STAGE_HINT = _STAGE_HINT
_TPL_STAGE_INT = _STAGE_INT
_TPL_STAGE_TXT = _STAGE_TXT

_TPL_OPTION_FIELDS = _OPTION_FIELDS
_TPL_OPTION_HINT = _OPTION_HINT
_TPL_OPTION_OPT = _OPTION_OPT
_TPL_OPTION_INT = _OPTION_INT
_TPL_OPTION_TXT = _OPTION_TXT


async def cb_admin_smg_tplgroups(update, context):
    session = db.get_session()
    try:
        groups = session.query(db.SmugglingStageTemplateGroup).order_by(db.SmugglingStageTemplateGroup.id).all()
        rows = []
        for g in groups:
            n_stages = session.query(db.SmugglingStageTemplate).filter_by(group_id=g.id).count()
            rows.append([InlineKeyboardButton(f"🗂 #{g.id} {g.name} ({n_stages} مرحله)", callback_data=f"admin_smg_tplgroup_view:{g.id}")])
        rows.append([InlineKeyboardButton("➕ دسته‌مرحله‌ی جدید", callback_data="admin_smg_tplgroup_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_smg_menu")])
        text = (
            "🗂 دسته‌مرحله‌ها:\n\n"
            "این‌جا می‌تونی یه‌بار یه دسته از مرحله+گزینه بسازی و بعد موقعِ "
            "ساختن یا ادامه‌دادنِ هر کالا، فقط آیدیِ همین دسته رو بدی تا یه کپیِ "
            "کاملِ مستقل از مراحلش رو بگیره - به‌جایِ اینکه هر بار از اول مرحله "
            "بسازی. بعدِ کپی‌شدن، شانسِ موفقیتِ هر گزینه رو می‌شه تو هر کالا جدا "
            "و متفاوت تنظیم کرد."
            if not groups else "🗂 دسته‌مرحله‌ها:"
        )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_tplgroup_add(update, context):
    await ask_for_input(update, context, "📝 نام | توضیحِ دسته‌مرحله رو با | جدا بفرست:", {"type": "smg_tplgroup_add"}, "admin_state")


async def cb_admin_smg_tplgroup_view(update, context):
    tgid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        g = session.get(db.SmugglingStageTemplateGroup, tgid)
        if not g:
            await send_response(update, "این دسته‌مرحله پیدا نشد.", None)
            return
        n_stages = session.query(db.SmugglingStageTemplate).filter_by(group_id=tgid).count()
        text = f"🗂 #{g.id} {g.name}\n{g.description or ''}\n\nمراحلِ این دسته: {n_stages}"
        rows = [
            [InlineKeyboardButton("✏️ نام", callback_data=f"admin_smg_tplgroup_edit_ask:{tgid}:name")],
            [InlineKeyboardButton("✏️ توضیح", callback_data=f"admin_smg_tplgroup_edit_ask:{tgid}:description")],
            [InlineKeyboardButton("🗂 مدیریتِ مراحلِ این دسته", callback_data=f"admin_smg_tplstages:{tgid}")],
            [InlineKeyboardButton("🗑 حذفِ دسته‌مرحله", callback_data=f"admin_smg_tplgroup_delete_ask:{tgid}")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_smg_tplgroups")],
        ]
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_tplgroup_edit_ask(update, context):
    _, tgid, field = update.callback_query.data.split(":")
    await ask_for_input(update, context, "✏️ مقدارِ جدید رو بفرست:", {"type": "smg_tplgroup_edit", "id": int(tgid), "field": field}, "admin_state")


async def cb_admin_smg_tplgroup_delete_ask(update, context):
    tgid = int(update.callback_query.data.split(":")[1])
    rows = [[
        InlineKeyboardButton("✅ بله، حذفش کن", callback_data=f"admin_smg_tplgroup_delete_confirm:{tgid}"),
        InlineKeyboardButton("❌ نه", callback_data=f"admin_smg_tplgroup_view:{tgid}"),
    ]]
    await send_response(
        update,
        "مطمئنی؟ همه‌ی مراحل/گزینه‌هایِ این قالب هم حذف می‌شن - ولی کپی‌هایی که "
        "قبلاً رو کالاهایِ مختلف گرفته شده دست‌نخورده می‌مونن.",
        InlineKeyboardMarkup(rows),
    )


async def cb_admin_smg_tplgroup_delete_confirm(update, context):
    tgid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        st_ids = [s.id for s in session.query(db.SmugglingStageTemplate.id).filter_by(group_id=tgid).all()]
        if st_ids:
            session.query(db.SmugglingOptionTemplate).filter(db.SmugglingOptionTemplate.stage_template_id.in_(st_ids)).delete(synchronize_session=False)
        session.query(db.SmugglingStageTemplate).filter_by(group_id=tgid).delete(synchronize_session=False)
        g = session.get(db.SmugglingStageTemplateGroup, tgid)
        if g:
            session.delete(g)
        session.commit()
    finally:
        session.close()
    await cb_admin_smg_tplgroups(update, context)


async def cb_admin_smg_tplstages(update, context):
    tgid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        stages = session.query(db.SmugglingStageTemplate).filter_by(group_id=tgid).order_by(db.SmugglingStageTemplate.order_index).all()
        rows = []
        for s in stages:
            n_opts = session.query(db.SmugglingOptionTemplate).filter_by(stage_template_id=s.id).count()
            rows.append([InlineKeyboardButton(f"🗂 #{s.id} {s.name} ({n_opts} گزینه)", callback_data=f"admin_smg_tplstage_view:{s.id}")])
        rows.append([InlineKeyboardButton("➕ مرحله‌ی جدید", callback_data=f"admin_smg_tplstage_add:{tgid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_tplgroup_view:{tgid}")])
        text = f"🗂 مراحلِ دسته‌مرحله‌یِ #{tgid} ({len(stages)}/25):"
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_tplstage_add(update, context):
    tgid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, f"📝 اطلاعاتِ مرحله‌ی جدید رو با | جدا بفرست:\n\n{_TPL_STAGE_HINT}", {"type": "smg_tplstage_add", "group_id": tgid}, "admin_state")


async def cb_admin_smg_tplstage_view(update, context):
    stid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        s = session.get(db.SmugglingStageTemplate, stid)
        if not s:
            await send_response(update, "این مرحله پیدا نشد.", None)
            return
        n_opts = session.query(db.SmugglingOptionTemplate).filter_by(stage_template_id=stid).count()
        text = f"🗂 #{s.id} {s.name}\n{s.description or ''}\n\nاسلات: {s.slot_index} | ترتیب: {s.order_index} | گزینه‌ها: {n_opts}"
        edit_labels = {"name": "✏️ نام", "description": "✏️ توضیح", "slot_index": "✏️ اسلات", "order_index": "✏️ ترتیب"}
        rows = [[InlineKeyboardButton(label, callback_data=f"admin_smg_tplstage_edit_ask:{stid}:{field}")] for field, label in edit_labels.items()]
        rows.append([InlineKeyboardButton("🎛 مدیریتِ گزینه‌ها", callback_data=f"admin_smg_tploptions:{stid}")])
        rows.append([InlineKeyboardButton("🗑 حذفِ مرحله", callback_data=f"admin_smg_tplstage_delete_ask:{stid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_tplstages:{s.group_id}")])
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_tplstage_edit_ask(update, context):
    _, stid, field = update.callback_query.data.split(":")
    await ask_for_input(update, context, "✏️ مقدارِ جدید رو بفرست:", {"type": "smg_tplstage_edit", "id": int(stid), "field": field}, "admin_state")


async def cb_admin_smg_tplstage_delete_ask(update, context):
    stid = int(update.callback_query.data.split(":")[1])
    rows = [[
        InlineKeyboardButton("✅ بله", callback_data=f"admin_smg_tplstage_delete_confirm:{stid}"),
        InlineKeyboardButton("❌ نه", callback_data=f"admin_smg_tplstage_view:{stid}"),
    ]]
    await send_response(update, "مطمئنی؟ گزینه‌های این مرحله هم حذف می‌شن.", InlineKeyboardMarkup(rows))


async def cb_admin_smg_tplstage_delete_confirm(update, context):
    stid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        s = session.get(db.SmugglingStageTemplate, stid)
        tgid = s.group_id if s else None
        session.query(db.SmugglingOptionTemplate).filter_by(stage_template_id=stid).delete(synchronize_session=False)
        if s:
            session.delete(s)
        session.commit()
    finally:
        session.close()
    if tgid:
        update.callback_query.data = f"admin_smg_tplstages:{tgid}"
        await cb_admin_smg_tplstages(update, context)


async def cb_admin_smg_tploptions(update, context):
    stid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        options = session.query(db.SmugglingOptionTemplate).filter_by(stage_template_id=stid).all()
        rows = []
        for o in options:
            rows.append([InlineKeyboardButton(f"🎛 #{o.id} {o.name}", callback_data=f"admin_smg_tploption_view:{o.id}")])
        rows.append([InlineKeyboardButton("➕ گزینه‌ی جدید", callback_data=f"admin_smg_tploption_add:{stid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_tplstage_view:{stid}")])
        await send_response(update, f"🎛 گزینه‌هایِ مرحله‌ی #{stid}:", InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_tploption_add(update, context):
    stid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, f"📝 اطلاعاتِ گزینه‌ی جدید رو با | جدا بفرست:\n\n{_TPL_OPTION_HINT}", {"type": "smg_tploption_add", "stage_template_id": stid}, "admin_state")


async def cb_admin_smg_tploption_view(update, context):
    oid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        o = session.get(db.SmugglingOptionTemplate, oid)
        if not o:
            await send_response(update, "این گزینه پیدا نشد.", None)
            return
        text = (
            f"🎛 #{o.id} {o.name}\n{o.description or ''}\n\n"
            f"ریسک: {fmt(o.risk_pct)}٪ | شانسِ موفقیت: {fmt(o.success_pct)}٪\n"
            f"پاداشِ اضافه: {fmt(o.reward_bonus)} | جریمه: {fmt(o.penalty_amount)} + {fmt(o.penalty_pct)}٪\n"
            f"زمان: {o.time_minutes or '-'} دقیقه\n\n"
            f"متنِ موفقیت: {o.success_text or '-'}\nمتنِ شکست: {o.fail_text or '-'}"
        )
        edit_labels = {
            "name": "✏️ نام", "description": "✏️ توضیح", "risk_pct": "✏️ ریسک", "success_pct": "✏️ شانسِ موفقیت",
            "reward_bonus": "✏️ پاداشِ اضافه", "penalty_amount": "✏️ جریمه(مبلغ)", "penalty_pct": "✏️ جریمه(٪)",
            "time_minutes": "✏️ زمان", "success_text": "✏️ متنِ موفقیت", "fail_text": "✏️ متنِ شکست",
        }
        rows = [[InlineKeyboardButton(label, callback_data=f"admin_smg_tploption_edit_ask:{oid}:{field}")] for field, label in edit_labels.items()]
        rows.append([InlineKeyboardButton("🗑 حذفِ گزینه", callback_data=f"admin_smg_tploption_delete_ask:{oid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_tploptions:{o.stage_template_id}")])
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_tploption_edit_ask(update, context):
    _, oid, field = update.callback_query.data.split(":")
    await ask_for_input(update, context, "✏️ مقدارِ جدید رو بفرست:", {"type": "smg_tploption_edit", "id": int(oid), "field": field}, "admin_state")


async def cb_admin_smg_tploption_delete_ask(update, context):
    oid = int(update.callback_query.data.split(":")[1])
    rows = [[
        InlineKeyboardButton("✅ بله", callback_data=f"admin_smg_tploption_delete_confirm:{oid}"),
        InlineKeyboardButton("❌ نه", callback_data=f"admin_smg_tploption_view:{oid}"),
    ]]
    await send_response(update, "مطمئنی؟", InlineKeyboardMarkup(rows))


async def cb_admin_smg_tploption_delete_confirm(update, context):
    oid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        o = session.get(db.SmugglingOptionTemplate, oid)
        stid = o.stage_template_id if o else None
        if o:
            session.delete(o)
            session.commit()
    finally:
        session.close()
    if stid:
        update.callback_query.data = f"admin_smg_tploptions:{stid}"
        await cb_admin_smg_tploptions(update, context)


# ---- نیروهایِ کمکی --------------------------------------------------------

_HELPER_FIELDS = ["name", "description", "price", "level", "power", "uses", "duration_minutes", "trust_initial", "trust_min", "trust_max"]
_HELPER_HINT = "نام | توضیح | قیمت | سطح(یا-) | قدرت(یا-) | تعدادِ استفاده(یا-) | مدت به دقیقه(یا- برایِ دائمی) | Trustِ اولیه | Trustِ حداقل | Trustِ حداکثر"
_HELPER_OPT = {"level", "power", "uses", "duration_minutes"}
_HELPER_INT = {"level", "uses", "duration_minutes"}
_HELPER_TXT = {"name", "description"}
_HELPER_EDIT_FIELDS = {
    "name": "✏️ نام", "description": "✏️ توضیح", "price": "✏️ قیمت", "level": "✏️ سطح", "power": "✏️ قدرت",
    "uses": "✏️ تعدادِ استفاده", "duration_minutes": "✏️ مدت", "trust_initial": "✏️ Trustِ اولیه",
    "trust_min": "✏️ Trustِ حداقل", "trust_max": "✏️ Trustِ حداکثر",
    "trust_gain_per_payment": "✏️ افزایشِ Trust با پرداخت", "payment_amount_for_gain": "✏️ مبلغِ لازم برایِ اون افزایش",
    "trust_gain_per_use": "✏️ افزایشِ Trust با هر استفاده", "inactivity_days_for_decay": "✏️ مدتِ عدمِ‌استفاده (روز)",
    "trust_decay_amount": "✏️ مقدارِ کاهشِ Trust بعدِ اون مدت", "effect_combination_mode": "✏️ نحوه‌یِ ترکیبِ اثرها (sum/strongest/capped_sum)",
    "effect_cap_pct": "✏️ سقفِ اثر (فقط برایِ capped_sum)",
}
_HELPER_TXT_EDIT_FIELDS = {"name", "description", "effect_combination_mode"}
_HELPER_OPT_EDIT_FIELDS = {"level", "power", "uses", "duration_minutes", "payment_amount_for_gain", "inactivity_days_for_decay", "effect_cap_pct"}
_HELPER_INT_EDIT_FIELDS = {"level", "uses", "duration_minutes"}


async def cb_admin_smg_helpers(update, context):
    session = db.get_session()
    try:
        helpers = session.query(db.SmugglingHelper).order_by(db.SmugglingHelper.id).all()
        rows = []
        warn_count = 0
        for h in helpers:
            tag = "✅" if h.active else "⛔️"
            # نیرویی که هیچ قانونِ محدوده‌ی اثری نداره هیچ‌جا به پلیرها نشون
            # داده نمی‌شه - این دقیقاً همون باگی بود که ازش گفتی، پس این‌جا
            # صریحاً علامت می‌خوره تا از چشم نیفته.
            if session.query(db.SmugglingHelperRule).filter_by(helper_id=h.id, active=True).count() == 0:
                tag += "⚠️"
                warn_count += 1
            rows.append([InlineKeyboardButton(f"{tag} #{h.id} {h.name}", callback_data=f"admin_smg_helper_view:{h.id}")])
        rows.append([InlineKeyboardButton("➕ نیرویِ جدید", callback_data="admin_smg_helper_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_smg_menu")])
        text = "🤝 نیروهایِ کمکی:" if helpers else "🤝 هنوز هیچ نیرویی نساختی."
        if warn_count:
            text += (
                f"\n\n⚠️ {warn_count} تا از نیروها هیچ «قانونِ محدوده‌ی اثر» ندارن، "
                "برای همین تو صفحه‌ی «🛒 نیروهای کمکی»یِ پلیرها اصلاً نشون داده نمی‌شن. "
                "بازشون کن و دکمه‌ی «⚡️ اعمال رو همه‌ی مراحل» رو بزن."
            )
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_helper_add(update, context):
    await ask_for_input(update, context, f"📝 اطلاعاتِ نیرویِ جدید رو با | جدا بفرست:\n\n{_HELPER_HINT}", {"type": "smg_helper_add"}, "admin_state")


async def cb_admin_smg_helper_view(update, context):
    hid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        h = session.get(db.SmugglingHelper, hid)
        if not h:
            await send_response(update, "این نیرو پیدا نشد.", None)
            return
        n_rules = session.query(db.SmugglingHelperRule).filter_by(helper_id=hid).count()
        n_th = session.query(db.SmugglingTrustThreshold).filter_by(helper_id=hid).count()
        text = (
            f"🤝 #{h.id} {h.name}\n{h.description or ''}\n\n"
            f"قیمت: {fmt(h.price)} | سطح: {h.level or '-'} | قدرت: {h.power or '-'} | استفاده: {h.uses or 'نامحدود'} | مدت: {h.duration_minutes or 'دائمی'}\n"
            f"Trust: اولیه={fmt(h.trust_initial)} حداقل={fmt(h.trust_min)} حداکثر={fmt(h.trust_max)}\n"
            f"افزایشِ Trust با پرداخت: +{fmt(h.trust_gain_per_payment)} به‌ازایِ هر {fmt(h.payment_amount_for_gain or 0)} 🪙\n"
            f"افزایشِ Trust با هر استفاده: +{fmt(h.trust_gain_per_use)}\n"
            f"کاهشِ Trust: -{fmt(h.trust_decay_amount)} بعدِ هر {fmt(h.inactivity_days_for_decay or 0)} روز عدمِ‌استفاده\n"
            f"نحوه‌یِ ترکیبِ اثرها: {h.effect_combination_mode} (سقف: {h.effect_cap_pct or '-'})\n"
            f"قوانین: {n_rules} | Threshold: {n_th}\nفعال: {'✅' if h.active else '⛔️'}"
        )
        n_active_rules = session.query(db.SmugglingHelperRule).filter_by(helper_id=hid, active=True).count()
        if n_active_rules == 0:
            text += (
                "\n\n⚠️ این نیرو هیچ قانونِ محدوده‌ی اثرِ فعالی نداره!\n"
                "تا وقتی حداقل یه قانون براش نسازی، هیچ پلیری این نیرو رو تو صفحه‌ی "
                "«🛒 نیروهای کمکی» نمی‌بینه و نمی‌تونه بخردش (پیش‌فرضِ سیستم اینه که "
                "هر نیرو همه‌جا ممنوعه مگه صریحاً مجاز شه).\n"
                "سریع‌ترین راه: دکمه‌ی «⚡️ اعمال رو همه‌ی مراحل» پایین."
            )
        rows = [[InlineKeyboardButton(label, callback_data=f"admin_smg_helper_edit_ask:{hid}:{field}")] for field, label in _HELPER_EDIT_FIELDS.items()]
        if n_active_rules == 0:
            rows.append([InlineKeyboardButton("⚡️ اعمال رو همه‌ی مراحل (رفعِ سریع)", callback_data=f"admin_smg_helper_allowall:{hid}")])
        rows.append([InlineKeyboardButton("📐 قوانینِ محدوده‌ی اثر", callback_data=f"admin_smg_helper_rules:{hid}")])
        rows.append([InlineKeyboardButton("📊 Threshold هایِ Trust", callback_data=f"admin_smg_helper_thresholds:{hid}")])
        rows.append([InlineKeyboardButton("⛔️ غیرفعال کردن" if h.active else "✅ فعال کردن", callback_data=f"admin_smg_helper_toggle:{hid}")])
        rows.append([InlineKeyboardButton("🗑 حذفِ نیرو", callback_data=f"admin_smg_helper_delete_ask:{hid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_smg_helpers")])
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_helper_allowall(update, context):
    """رفعِ سریعِ «نیرو رو ساختم ولی به پلیرها نشون داده نمی‌شه»: یه قانونِ
    سراسری (همه‌ی کالاها/مراحل/گزینه‌ها) براش می‌سازه تا فوراً قابلِ‌دیدن و
    خریدن بشه. مقدارِ اثرش رو بعداً از «📐 قوانینِ محدوده‌ی اثر» دقیق می‌کنی."""
    hid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        h = session.get(db.SmugglingHelper, hid)
        name = h.name if h else str(hid)
    finally:
        session.close()
    rows = [[
        InlineKeyboardButton("✅ بله، بساز", callback_data=f"admin_smg_helper_allowall_do:{hid}"),
        InlineKeyboardButton("❌ نه", callback_data=f"admin_smg_helper_view:{hid}"),
    ]]
    await send_response(
        update,
        f"⚡️ برای «{name}» یه قانونِ سراسری ساخته می‌شه:\n\n"
        "• رو همه‌ی کالاها، همه‌ی مراحل و همه‌ی گزینه‌ها اثر می‌ذاره\n"
        "• حداقل Trustِ لازم: ۰\n"
        "• اثرِ شانس: +۱۰٪ (بعداً از «📐 قوانینِ محدوده‌ی اثر» قابلِ تغییره)\n\n"
        "از این به بعد پلیرها این نیرو رو تو صفحه‌ی «🛒 نیروهای کمکی» می‌بینن. ادامه بدم؟",
        InlineKeyboardMarkup(rows),
    )


async def cb_admin_smg_helper_allowall_do(update, context):
    hid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        h = session.get(db.SmugglingHelper, hid)
        if not h:
            await send_response(update, "این نیرو پیدا نشد.", None)
            return
        session.add(db.SmugglingHelperRule(
            helper_id=hid, good_id=None, stage_id=None, option_id=None,
            min_trust=0, effect_success_pct=10, effect_risk_pct=0,
            effect_reward_pct=0, effect_penalty_pct=0, active=True,
        ))
        session.commit()
    finally:
        session.close()
    await cb_admin_smg_helper_view(update, context)


async def cb_admin_smg_helper_edit_ask(update, context):
    _, hid, field = update.callback_query.data.split(":")
    hint = " («-» یعنی نامحدود/بدونِ‌مقدار)" if field in _HELPER_OPT_EDIT_FIELDS else ""
    await ask_for_input(update, context, f"✏️ مقدارِ جدید رو بفرست{hint}:", {"type": "smg_helper_edit", "id": int(hid), "field": field}, "admin_state")


async def cb_admin_smg_helper_toggle(update, context):
    hid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        h = session.get(db.SmugglingHelper, hid)
        if h:
            h.active = not h.active
            session.commit()
    finally:
        session.close()
    await cb_admin_smg_helper_view(update, context)


async def cb_admin_smg_helper_delete_ask(update, context):
    hid = int(update.callback_query.data.split(":")[1])
    rows = [[
        InlineKeyboardButton("✅ بله", callback_data=f"admin_smg_helper_delete_confirm:{hid}"),
        InlineKeyboardButton("❌ نه", callback_data=f"admin_smg_helper_view:{hid}"),
    ]]
    await send_response(update, "مطمئنی؟ قوانین/Thresholdهاش هم حذف می‌شن.", InlineKeyboardMarkup(rows))


async def cb_admin_smg_helper_delete_confirm(update, context):
    hid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        session.query(db.SmugglingHelperRule).filter_by(helper_id=hid).delete(synchronize_session=False)
        session.query(db.SmugglingTrustThreshold).filter_by(helper_id=hid).delete(synchronize_session=False)
        h = session.get(db.SmugglingHelper, hid)
        if h:
            session.delete(h)
        session.commit()
    finally:
        session.close()
    await cb_admin_smg_helpers(update, context)


# ---- قوانینِ محدوده‌ی اثرِ نیرو -------------------------------------------

_HRULE_FIELDS = ["good_id", "stage_id", "option_id", "min_trust", "effect_success_pct", "effect_risk_pct", "effect_reward_pct", "effect_penalty_pct"]
_HRULE_HINT = "آیدیِ کالا(یا-) | آیدیِ مرحله(یا-) | آیدیِ گزینه(یا-) | حداقلِ Trust | اثرِ٪ رویِ شانس | اثرِ٪ رویِ ریسک | اثرِ٪ رویِ پاداش | اثرِ٪ رویِ جریمه\n\n«-» یعنی این سطح رو محدود نکن (روی همه اعمال شه).\nآیدیِ کالا/مرحله/گزینه رو از صفحه‌ی همون‌ها می‌تونی ببینی."
_HRULE_OPT = {"good_id", "stage_id", "option_id"}
_HRULE_INT = {"good_id", "stage_id", "option_id"}


async def cb_admin_smg_helper_rules(update, context):
    hid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        rules = session.query(db.SmugglingHelperRule).filter_by(helper_id=hid).all()
        lines = ["📐 قوانینِ محدوده‌ی اثر:\n"]
        rows = []
        for r in rules:
            lines.append(
                f"\n#{r.id}: کالا={r.good_id or 'همه'} مرحله={r.stage_id or 'همه'} گزینه={r.option_id or 'همه'} | "
                f"minTrust={fmt(r.min_trust)} | شانس+{fmt(r.effect_success_pct)}٪ ریسک+{fmt(r.effect_risk_pct)}٪ "
                f"پاداش+{fmt(r.effect_reward_pct)}٪ جریمه+{fmt(r.effect_penalty_pct)}٪"
            )
            rows.append([InlineKeyboardButton(f"🗑 حذفِ #{r.id}", callback_data=f"admin_smg_hrule_delete:{r.id}:{hid}")])
        rows.append([InlineKeyboardButton("➕ قانونِ جدید", callback_data=f"admin_smg_hrule_add:{hid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_helper_view:{hid}")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_hrule_add(update, context):
    hid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, f"📝 قانونِ جدید رو با | جدا بفرست:\n\n{_HRULE_HINT}", {"type": "smg_hrule_add", "helper_id": hid}, "admin_state")


async def cb_admin_smg_hrule_delete(update, context):
    _, rid, hid = update.callback_query.data.split(":")
    session = db.get_session()
    try:
        r = session.get(db.SmugglingHelperRule, int(rid))
        if r:
            session.delete(r)
            session.commit()
    finally:
        session.close()
    update.callback_query.data = f"admin_smg_helper_rules:{hid}"
    await cb_admin_smg_helper_rules(update, context)


# ---- Thresholdهایِ Trust --------------------------------------------------

_THRESH_FIELDS = ["good_id", "stage_id", "option_id", "min_trust", "effect_success_pct", "effect_reward_pct", "effect_risk_pct", "effect_penalty_pct"]
_THRESH_HINT = "آیدیِ کالا(یا-) | آیدیِ مرحله(یا-) | آیدیِ گزینه(یا-) | حداقلِ Trustِ لازم برایِ این Threshold | اثرِ٪ شانس | اثرِ٪ پاداش | اثرِ٪ ریسک | اثرِ٪ جریمه"
_THRESH_OPT = {"good_id", "stage_id", "option_id"}
_THRESH_INT = {"good_id", "stage_id", "option_id"}


async def cb_admin_smg_helper_thresholds(update, context):
    hid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        rows_db = session.query(db.SmugglingTrustThreshold).filter_by(helper_id=hid).all()
        lines = ["📊 Threshold هایِ Trust:\n"]
        rows = []
        for t in rows_db:
            lines.append(
                f"\n#{t.id}: کالا={t.good_id or 'همه'} مرحله={t.stage_id or 'همه'} گزینه={t.option_id or 'همه'} | "
                f"Trust>={fmt(t.min_trust)} → شانس+{fmt(t.effect_success_pct)}٪ پاداش+{fmt(t.effect_reward_pct)}٪"
            )
            rows.append([InlineKeyboardButton(f"🗑 حذفِ #{t.id}", callback_data=f"admin_smg_thresh_delete:{t.id}:{hid}")])
        rows.append([InlineKeyboardButton("➕ Thresholdِ جدید", callback_data=f"admin_smg_thresh_add:{hid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"admin_smg_helper_view:{hid}")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_thresh_add(update, context):
    hid = int(update.callback_query.data.split(":")[1])
    await ask_for_input(update, context, f"📝 Thresholdِ جدید رو با | جدا بفرست:\n\n{_THRESH_HINT}", {"type": "smg_thresh_add", "helper_id": hid}, "admin_state")


async def cb_admin_smg_thresh_delete(update, context):
    _, tid, hid = update.callback_query.data.split(":")
    session = db.get_session()
    try:
        t = session.get(db.SmugglingTrustThreshold, int(tid))
        if t:
            session.delete(t)
            session.commit()
    finally:
        session.close()
    update.callback_query.data = f"admin_smg_helper_thresholds:{hid}"
    await cb_admin_smg_helper_thresholds(update, context)


# ---- قوانینِ اسلحه ---------------------------------------------------------

_GUNRULE_FIELDS = ["good_id", "stage_id", "option_id", "power_per_trust", "effect_success_pct_per_trust", "effect_risk_pct_per_trust", "consumes_use"]
_GUNRULE_HINT = "آیدیِ کالا(یا-) | آیدیِ مرحله(یا-) | آیدیِ گزینه(یا-) | هر چند قدرتِ اسلحه = ۱ Trust | اثرِ٪ شانس به‌ازایِ هر Trust | اثرِ٪ ریسک به‌ازایِ هر Trust | مصرف‌شدنِ اسلحه (۱=بله/۰=نه)"
_GUNRULE_OPT = {"good_id", "stage_id", "option_id"}
_GUNRULE_INT = {"good_id", "stage_id", "option_id", "consumes_use"}


async def cb_admin_smg_gun_rules(update, context):
    session = db.get_session()
    try:
        rules = session.query(db.SmugglingGunRule).all()
        lines = ["🔫 قوانینِ اسلحه (تنها سیستمِ قبلیِ مجاز تو قاچاق):\n"]
        rows = []
        for r in rules:
            lines.append(
                f"\n#{r.id}: کالا={r.good_id or 'همه'} مرحله={r.stage_id or 'همه'} گزینه={r.option_id or 'همه'} | "
                f"هر {fmt(r.power_per_trust or 0)} قدرت=۱Trust | شانس+{fmt(r.effect_success_pct_per_trust)}٪/Trust | "
                f"{'مصرف می‌شه' if r.consumes_use else 'مصرف نمی‌شه'} | {'فعال' if r.active else 'غیرفعال'}"
            )
            rows.append([InlineKeyboardButton(f"🗑 حذفِ #{r.id}", callback_data=f"admin_smg_gunrule_delete:{r.id}")])
        rows.append([InlineKeyboardButton("➕ قانونِ جدید", callback_data="admin_smg_gunrule_add")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data="admin_smg_menu")])
        await send_response(update, "\n".join(lines), InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_gunrule_add(update, context):
    await ask_for_input(update, context, f"📝 قانونِ اسلحه‌یِ جدید رو با | جدا بفرست:\n\n{_GUNRULE_HINT}", {"type": "smg_gunrule_add"}, "admin_state")


async def cb_admin_smg_gunrule_delete(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.SmugglingGunRule, rid)
        if r:
            session.delete(r)
            session.commit()
    finally:
        session.close()
    await cb_admin_smg_gun_rules(update, context)


# ---- تنظیماتِ کلی -----------------------------------------------------------

async def cb_admin_smg_cfg(update, context):
    session = db.get_session()
    try:
        cur = db.cfg_get(session, "smuggling_allow_concurrent_operations")
        timeout_s = db.cfg_get_int(session, "smuggling_inactivity_timeout_seconds")
        jail_min = db.cfg_get_int(session, "smuggling_fail_jail_minutes")
        jail_bail = db.cfg_get_float(session, "smuggling_fail_jail_bail")
        text = (
            f"⚙️ تنظیماتِ کلیِ قاچاق\n\n"
            f"اجازه‌ی چند عملیاتِ هم‌زمان: {'✅ بله' if cur == '1' else '⛔️ نه (پیش‌فرض)'}\n"
            f"⏱ مهلتِ بی‌حرکتی قبلِ لغوِ خودکار: {timeout_s} ثانیه\n"
            f"   (مرحله‌های زمان‌دار از این مهلت مستثنان)\n\n"
            f"🔒 زندان بعدِ شکستِ عملیات: {jail_min} دقیقه (۰ = خاموش)\n"
            f"💸 وثیقه‌ی آزادی از اون زندان: {fmt(jail_bail)} 🪙"
        )
        rows = [
            [InlineKeyboardButton("🔁 تغییرِ این تنظیم", callback_data="admin_smg_cfg_toggle_concurrent")],
            [InlineKeyboardButton("✏️ ویرایشِ مهلتِ بی‌حرکتی (ثانیه)", callback_data="admin_cfg_edit:smuggling_inactivity_timeout_seconds")],
            [InlineKeyboardButton("✏️ دقیقه‌ی زندانِ بعدِ شکست", callback_data="admin_cfg_edit:smuggling_fail_jail_minutes")],
            [InlineKeyboardButton("✏️ وثیقه‌ی زندانِ بعدِ شکست", callback_data="admin_cfg_edit:smuggling_fail_jail_bail")],
            [InlineKeyboardButton("🔙 بازگشت", callback_data="admin_smg_menu")],
        ]
        await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_admin_smg_cfg_toggle_concurrent(update, context):
    session = db.get_session()
    try:
        cur = db.cfg_get(session, "smuggling_allow_concurrent_operations")
        db.cfg_set(session, "smuggling_allow_concurrent_operations", "0" if cur == "1" else "1")
        session.commit()
    finally:
        session.close()
    await cb_admin_smg_cfg(update, context)


ADMIN_SMG_CALLBACKS = {
    "admin_smg_menu": cb_admin_smg_menu,
    "admin_smg_goods": cb_admin_smg_goods,
    "admin_smg_good_add": cb_admin_smg_good_add,
    "admin_smg_good_view": cb_admin_smg_good_view,
    "admin_smg_good_edit_ask": cb_admin_smg_good_edit_ask,
    "admin_smg_good_toggle": cb_admin_smg_good_toggle,
    "admin_smg_good_toggle_today": cb_admin_smg_good_toggle_today,
    "admin_smg_good_delete_ask": cb_admin_smg_good_delete_ask,
    "admin_smg_good_delete_confirm": cb_admin_smg_good_delete_confirm,
    "admin_smg_stages": cb_admin_smg_stages,
    "admin_smg_stage_add": cb_admin_smg_stage_add,
    "admin_smg_stage_view": cb_admin_smg_stage_view,
    "admin_smg_stage_edit_ask": cb_admin_smg_stage_edit_ask,
    "admin_smg_stage_toggle": cb_admin_smg_stage_toggle,
    "admin_smg_stage_delete_ask": cb_admin_smg_stage_delete_ask,
    "admin_smg_stage_delete_confirm": cb_admin_smg_stage_delete_confirm,
    "admin_smg_options": cb_admin_smg_options,
    "admin_smg_option_add": cb_admin_smg_option_add,
    "admin_smg_option_view": cb_admin_smg_option_view,
    "admin_smg_option_realchance": cb_admin_smg_option_realchance,
    "admin_smg_option_edit_ask": cb_admin_smg_option_edit_ask,
    "admin_smg_option_toggle": cb_admin_smg_option_toggle,
    "admin_smg_option_delete_ask": cb_admin_smg_option_delete_ask,
    "admin_smg_option_delete_confirm": cb_admin_smg_option_delete_confirm,
    "admin_smg_good_apply_tpl_ask": cb_admin_smg_good_apply_tpl_ask,
    "admin_smg_tplgroups": cb_admin_smg_tplgroups,
    "admin_smg_tplgroup_add": cb_admin_smg_tplgroup_add,
    "admin_smg_tplgroup_view": cb_admin_smg_tplgroup_view,
    "admin_smg_tplgroup_edit_ask": cb_admin_smg_tplgroup_edit_ask,
    "admin_smg_tplgroup_delete_ask": cb_admin_smg_tplgroup_delete_ask,
    "admin_smg_tplgroup_delete_confirm": cb_admin_smg_tplgroup_delete_confirm,
    "admin_smg_tplstages": cb_admin_smg_tplstages,
    "admin_smg_tplstage_add": cb_admin_smg_tplstage_add,
    "admin_smg_tplstage_view": cb_admin_smg_tplstage_view,
    "admin_smg_tplstage_edit_ask": cb_admin_smg_tplstage_edit_ask,
    "admin_smg_tplstage_delete_ask": cb_admin_smg_tplstage_delete_ask,
    "admin_smg_tplstage_delete_confirm": cb_admin_smg_tplstage_delete_confirm,
    "admin_smg_tploptions": cb_admin_smg_tploptions,
    "admin_smg_tploption_add": cb_admin_smg_tploption_add,
    "admin_smg_tploption_view": cb_admin_smg_tploption_view,
    "admin_smg_tploption_edit_ask": cb_admin_smg_tploption_edit_ask,
    "admin_smg_tploption_delete_ask": cb_admin_smg_tploption_delete_ask,
    "admin_smg_tploption_delete_confirm": cb_admin_smg_tploption_delete_confirm,
    "admin_smg_helpers": cb_admin_smg_helpers,
    "admin_smg_helper_allowall": cb_admin_smg_helper_allowall,
    "admin_smg_helper_allowall_do": cb_admin_smg_helper_allowall_do,
    "admin_smg_helper_add": cb_admin_smg_helper_add,
    "admin_smg_helper_view": cb_admin_smg_helper_view,
    "admin_smg_helper_edit_ask": cb_admin_smg_helper_edit_ask,
    "admin_smg_helper_toggle": cb_admin_smg_helper_toggle,
    "admin_smg_helper_delete_ask": cb_admin_smg_helper_delete_ask,
    "admin_smg_helper_delete_confirm": cb_admin_smg_helper_delete_confirm,
    "admin_smg_helper_rules": cb_admin_smg_helper_rules,
    "admin_smg_hrule_add": cb_admin_smg_hrule_add,
    "admin_smg_hrule_delete": cb_admin_smg_hrule_delete,
    "admin_smg_helper_thresholds": cb_admin_smg_helper_thresholds,
    "admin_smg_thresh_add": cb_admin_smg_thresh_add,
    "admin_smg_thresh_delete": cb_admin_smg_thresh_delete,
    "admin_smg_gun_rules": cb_admin_smg_gun_rules,
    "admin_smg_gunrule_add": cb_admin_smg_gunrule_add,
    "admin_smg_gunrule_delete": cb_admin_smg_gunrule_delete,
    "admin_smg_cfg": cb_admin_smg_cfg,
    "admin_smg_cfg_toggle_concurrent": cb_admin_smg_cfg_toggle_concurrent,
}


async def smuggling_awaiting_handler(update, context, state):
    """از admin.py صدا زده می‌شه (دقیقاً هم‌الگو با guide.help_awaiting_handler)."""
    text = (update.message.text or "").strip()
    stype = state["type"]
    session = db.get_session()
    try:
        if stype == "smg_good_add":
            try:
                fields = _parse_pipe(text, _GOOD_FIELDS, _GOOD_OPT, _GOOD_INT, _GOOD_TXT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            g = db.SmugglingGood(active=True, show_in_today=True, **fields)
            session.add(g)
            session.commit()
            await update.message.reply_text(f"✅ کالایِ «{g.name}» ساخته شد (#{g.id}).")

        elif stype == "smg_good_edit":
            g = session.get(db.SmugglingGood, state["id"])
            if not g:
                await update.message.reply_text("❌ این کالا پیدا نشد.")
                raise ApplicationHandlerStop
            field = state["field"]
            try:
                value = text if field in _GOOD_TXT else (None if field in _GOOD_OPT and text == "-" else _coerce(field, text, _GOOD_INT))
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            setattr(g, field, value)
            session.commit()
            await update.message.reply_text(f"✅ «{g.name}» به‌روزرسانی شد.")

        elif stype == "smg_stage_add":
            try:
                fields = _parse_pipe(text, _STAGE_FIELDS, set(), _STAGE_INT, _STAGE_TXT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            s = db.SmugglingStage(good_id=state["good_id"], active=True, **fields)
            session.add(s)
            session.commit()
            await update.message.reply_text(f"✅ مرحله‌ی «{s.name}» ساخته شد (#{s.id}).")

        elif stype == "smg_stage_edit":
            s = session.get(db.SmugglingStage, state["id"])
            if not s:
                await update.message.reply_text("❌ این مرحله پیدا نشد.")
                raise ApplicationHandlerStop
            field = state["field"]
            try:
                value = text if field in _STAGE_TXT else _coerce(field, text, _STAGE_INT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            setattr(s, field, value)
            session.commit()
            await update.message.reply_text(f"✅ «{s.name}» به‌روزرسانی شد.")

        elif stype == "smg_option_add":
            try:
                fields = _parse_pipe(text, _OPTION_FIELDS, _OPTION_OPT, _OPTION_INT, _OPTION_TXT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            stage = session.get(db.SmugglingStage, state["stage_id"])
            if not stage:
                await update.message.reply_text("❌ این مرحله پیدا نشد.")
                raise ApplicationHandlerStop
            o = db.SmugglingOption(stage_id=stage.id, good_id=stage.good_id, active=True, **fields)
            session.add(o)
            session.commit()
            await update.message.reply_text(f"✅ گزینه‌ی «{o.name}» ساخته شد (#{o.id}).")

        elif stype == "smg_option_edit":
            o = session.get(db.SmugglingOption, state["id"])
            if not o:
                await update.message.reply_text("❌ این گزینه پیدا نشد.")
                raise ApplicationHandlerStop
            field = state["field"]
            txt_fields = _OPTION_TXT | {"success_text", "fail_text"}
            try:
                value = text if field in txt_fields else (None if field in _OPTION_OPT and text == "-" else _coerce(field, text, _OPTION_INT))
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            setattr(o, field, value)
            session.commit()
            await update.message.reply_text(f"✅ «{o.name}» به‌روزرسانی شد.")

        elif stype == "smg_tplgroup_add":
            parts = [p.strip() for p in text.split("|")]
            if len(parts) != 2:
                await update.message.reply_text("❌ باید دقیقاً به‌شکلِ «نام | توضیح» بفرستی؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            g = db.SmugglingStageTemplateGroup(name=parts[0], description=parts[1])
            session.add(g)
            session.commit()
            await update.message.reply_text(f"✅ دسته‌مرحله‌یِ «{g.name}» ساخته شد (#{g.id}).")

        elif stype == "smg_tplgroup_edit":
            g = session.get(db.SmugglingStageTemplateGroup, state["id"])
            if not g:
                await update.message.reply_text("❌ این دسته‌مرحله پیدا نشد.")
                raise ApplicationHandlerStop
            setattr(g, state["field"], text)
            session.commit()
            await update.message.reply_text(f"✅ «{g.name}» به‌روزرسانی شد.")

        elif stype == "smg_tplstage_add":
            try:
                fields = _parse_pipe(text, _TPL_STAGE_FIELDS, set(), _TPL_STAGE_INT, _TPL_STAGE_TXT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            group = session.get(db.SmugglingStageTemplateGroup, state["group_id"])
            if not group:
                await update.message.reply_text("❌ این دسته‌مرحله پیدا نشد.")
                raise ApplicationHandlerStop
            s = db.SmugglingStageTemplate(group_id=group.id, **fields)
            session.add(s)
            session.commit()
            await update.message.reply_text(f"✅ مرحله‌ی «{s.name}» به دسته‌مرحله اضافه شد (#{s.id}).")

        elif stype == "smg_tplstage_edit":
            s = session.get(db.SmugglingStageTemplate, state["id"])
            if not s:
                await update.message.reply_text("❌ این مرحله پیدا نشد.")
                raise ApplicationHandlerStop
            field = state["field"]
            try:
                value = text if field in _TPL_STAGE_TXT else _coerce(field, text, _TPL_STAGE_INT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            setattr(s, field, value)
            session.commit()
            await update.message.reply_text(f"✅ «{s.name}» به‌روزرسانی شد.")

        elif stype == "smg_tploption_add":
            try:
                fields = _parse_pipe(text, _TPL_OPTION_FIELDS, _TPL_OPTION_OPT, _TPL_OPTION_INT, _TPL_OPTION_TXT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            stage_tpl = session.get(db.SmugglingStageTemplate, state["stage_template_id"])
            if not stage_tpl:
                await update.message.reply_text("❌ این مرحله پیدا نشد.")
                raise ApplicationHandlerStop
            o = db.SmugglingOptionTemplate(stage_template_id=stage_tpl.id, **fields)
            session.add(o)
            session.commit()
            await update.message.reply_text(f"✅ گزینه‌ی «{o.name}» به مرحله اضافه شد (#{o.id}).")

        elif stype == "smg_tploption_edit":
            o = session.get(db.SmugglingOptionTemplate, state["id"])
            if not o:
                await update.message.reply_text("❌ این گزینه پیدا نشد.")
                raise ApplicationHandlerStop
            field = state["field"]
            txt_fields = _TPL_OPTION_TXT | {"success_text", "fail_text"}
            try:
                value = text if field in txt_fields else (None if field in _TPL_OPTION_OPT and text == "-" else _coerce(field, text, _TPL_OPTION_INT))
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            setattr(o, field, value)
            session.commit()
            await update.message.reply_text(f"✅ «{o.name}» به‌روزرسانی شد.")

        elif stype == "smg_good_apply_tpl":
            # کپیِ یه دسته‌مرحله رو مراحلِ یه کالایِ واقعی. هر ردیفِ کپی‌شده
            # (هم مرحله هم گزینه) یه آیدیِ کاملاً تازه می‌گیره - پس این کپی از
            # قالب و از هر کپیِ دیگه‌ای که رو کالاهایِ دیگه از همین دسته گرفته
            # شده، کاملاً مستقله؛ می‌شه بعداً success_pct یا هرچیزِ دیگه‌ای رو
            # تو هر گزینه‌ی این کالا جدا عوض کرد بدونِ اینکه رو بقیه اثر بذاره.
            # ضمناً چون نیروهایِ کمکی صرفاً بر اساسِ همین آیدی‌های واقعی (یا
            # good_id/stage_id/option_id=None به‌معنیِ «همه») تطبیق داده می‌شن
            # (نه یه لیستِ ازپیش‌ذخیره‌شده)، یه Ruleِ سراسری یا good-scoped از
            # قبل، خودکار رو مراحل/گزینه‌هایِ تازه‌کپی‌شده هم اثر می‌ذاره؛ فقط
            # Ruleهایِ مخصوصِ یه stage/option خاص باید دستی برایِ نمونه‌ی تازه
            # هم ساخته بشن (دقیقاً مثلِ قبل، برایِ هر مرحله‌ی دستی‌ساخته‌شده).
            try:
                tgid = int(text)
            except ValueError:
                await update.message.reply_text("❌ باید یه عددِ صحیح (آیدیِ دسته‌مرحله) بفرستی؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            good = session.get(db.SmugglingGood, state["good_id"])
            if not good:
                await update.message.reply_text("❌ این کالا پیدا نشد.")
                raise ApplicationHandlerStop
            group = session.get(db.SmugglingStageTemplateGroup, tgid)
            if not group:
                await update.message.reply_text(f"❌ دسته‌مرحله‌ی #{tgid} پیدا نشد.")
                raise ApplicationHandlerStop
            stage_tpls = (
                session.query(db.SmugglingStageTemplate)
                .filter_by(group_id=tgid)
                .order_by(db.SmugglingStageTemplate.order_index)
                .all()
            )
            if not stage_tpls:
                await update.message.reply_text(f"❌ دسته‌مرحله‌ی «{group.name}» هنوز هیچ مرحله‌ای نداره.")
                raise ApplicationHandlerStop
            n_stages = n_options = 0
            for st in stage_tpls:
                new_stage = db.SmugglingStage(
                    good_id=good.id, name=st.name, description=st.description,
                    slot_index=st.slot_index, order_index=st.order_index, active=True,
                )
                session.add(new_stage)
                session.flush()  # تا new_stage.id برای گزینه‌ها آماده باشه
                n_stages += 1
                opt_tpls = session.query(db.SmugglingOptionTemplate).filter_by(stage_template_id=st.id).all()
                for ot in opt_tpls:
                    session.add(db.SmugglingOption(
                        stage_id=new_stage.id, good_id=good.id, name=ot.name, description=ot.description,
                        risk_pct=ot.risk_pct, success_pct=ot.success_pct, reward_bonus=ot.reward_bonus,
                        penalty_amount=ot.penalty_amount, penalty_pct=ot.penalty_pct, time_minutes=ot.time_minutes,
                        success_text=ot.success_text, fail_text=ot.fail_text, active=True,
                    ))
                    n_options += 1
            session.commit()
            await update.message.reply_text(
                f"✅ {n_stages} مرحله و {n_options} گزینه از دسته‌مرحله‌یِ «{group.name}» رو کالایِ «{good.name}» کپی شد.\n\n"
                "می‌تونی الان از «🗂 مدیریتِ مراحل» همون کالا بری تو هرکدوم و مثلاً شانسِ موفقیتِ گزینه‌ها رو مالِ همین کالا جدا تنظیم کنی؛ "
                "کالاهایِ دیگه‌ای که از همین دسته‌مرحله استفاده کردن/می‌کنن دست‌نخورده می‌مونن.\n\n"
                "⚠️ اگه برایِ این دسته‌مرحله رویِ یه کالایِ دیگه Ruleِ نیرویِ کمکیِ مخصوصِ یه مرحله/گزینه‌یِ خاص ساخته بودی، "
                "اون Rule فقط مالِ همون آیدیِ قبلیه و خودکار به این کپیِ تازه اعمال نمی‌شه - باید براش دوباره Rule بسازی "
                "(یه Ruleِ سراسری یا مخصوصِ کلِ این کالا اما نیازی به این‌کار نداره، چون خودکار شاملِ مراحلِ تازه هم می‌شه)."
            )

        elif stype == "smg_helper_add":
            try:
                fields = _parse_pipe(text, _HELPER_FIELDS, _HELPER_OPT, _HELPER_INT, _HELPER_TXT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            h = db.SmugglingHelper(active=True, effect_combination_mode="sum", **fields)
            session.add(h)
            session.commit()
            await update.message.reply_text(f"✅ نیرویِ «{h.name}» ساخته شد (#{h.id}).")

        elif stype == "smg_helper_edit":
            h = session.get(db.SmugglingHelper, state["id"])
            if not h:
                await update.message.reply_text("❌ این نیرو پیدا نشد.")
                raise ApplicationHandlerStop
            field = state["field"]
            try:
                if field in _HELPER_TXT_EDIT_FIELDS:
                    value = text
                elif field in _HELPER_OPT_EDIT_FIELDS and text == "-":
                    value = None
                else:
                    value = _coerce(field, text, _HELPER_INT_EDIT_FIELDS)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            setattr(h, field, value)
            session.commit()
            await update.message.reply_text(f"✅ «{h.name}» به‌روزرسانی شد.")

        elif stype == "smg_hrule_add":
            try:
                fields = _parse_pipe(text, _HRULE_FIELDS, _HRULE_OPT, _HRULE_INT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            for k in ("good_id", "stage_id", "option_id"):
                fields[k] = _id_or_none(fields[k])
            r = db.SmugglingHelperRule(helper_id=state["helper_id"], active=True, **fields)
            session.add(r)
            session.commit()
            await update.message.reply_text(f"✅ قانونِ #{r.id} اضافه شد.")

        elif stype == "smg_thresh_add":
            try:
                fields = _parse_pipe(text, _THRESH_FIELDS, _THRESH_OPT, _THRESH_INT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            for k in ("good_id", "stage_id", "option_id"):
                fields[k] = _id_or_none(fields[k])
            t = db.SmugglingTrustThreshold(helper_id=state["helper_id"], active=True, **fields)
            session.add(t)
            session.commit()
            await update.message.reply_text(f"✅ Thresholdِ #{t.id} اضافه شد.")

        elif stype == "smg_gunrule_add":
            try:
                fields = _parse_pipe(text, _GUNRULE_FIELDS, _GUNRULE_OPT, _GUNRULE_INT)
            except ValueError as e:
                await update.message.reply_text(f"❌ {e}؛ عملیات لغو شد.")
                raise ApplicationHandlerStop
            for k in ("good_id", "stage_id", "option_id"):
                fields[k] = _id_or_none(fields[k])
            fields["consumes_use"] = bool(fields["consumes_use"])
            r = db.SmugglingGunRule(active=True, **fields)
            session.add(r)
            session.commit()
            await update.message.reply_text(f"✅ قانونِ اسلحه‌یِ #{r.id} اضافه شد.")

        else:
            raise ApplicationHandlerStop
    finally:
        session.close()
    raise ApplicationHandlerStop


def _coerce(field, raw, int_fields):
    try:
        val = float(raw)
    except ValueError:
        raise ValueError(f"مقدارِ «{raw}» برایِ {field} عددی نیست")
    if field in int_fields:
        val = int(val)
    return val
