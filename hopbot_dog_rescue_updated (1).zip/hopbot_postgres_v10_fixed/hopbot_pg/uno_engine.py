# -*- coding: utf-8 -*-
"""
موتورِ خالصِ بازیِ «اونو هاپویی» - هیچ ربطی به تلگرام/دیتابیس نداره، فقط منطقِ
کارت‌هاست. جدا نگه داشته شده تا بشه کاملاً و سریع تستش کرد (پایینِ همین فایل
یه سلف‌تست هست) و مطمئن شد بازی «قابلِ‌انجام» و بی‌باگه.

کدگذاریِ کارت‌ها (رشته‌ی کوتاه، چون مستقیم تو JSON ذخیره می‌شن):
    "r5"   -> رنگِ قرمز، عددِ ۵
    "gS"   -> سبز، ردکردنِ نوبت (Skip)
    "bR"   -> آبی، برعکس‌کردنِ جهت (Reverse)
    "y+2"  -> زرد، نفرِ بعدی ۲ تا بکشه
    "w"    -> وایلد (هر رنگی - رنگش رو خودت انتخاب می‌کنی)
    "w+4"  -> وایلدِ +۴
    "X"    -> کارتِ «ویژه» (مخصوصِ همین بات - پایین توضیح داده شده)

رنگ‌ها: r/g/b/y

کارتِ «ویژه» (X):
- کلاً ۴ تا تو بازیه (قابلِ‌تنظیم): ۱ دونه از اول تو دستِ یکی از بازیکن‌هایِ
  شانسی گذاشته می‌شه، ۳ تایِ بقیه داخلِ دسته‌ی کارتِ وسط پخش می‌شن.
- رو هر رنگ/عددی می‌شه انداختش (مثلِ وایلد) و موقعِ انداختن، رنگِ جاری رو خودت
  انتخاب می‌کنی.
- اثرش: کلِ جریمه‌ی تجمعیِ روی میز (pending_draw) رو صفر می‌کنه و به‌جاش به
  نفرِ بعدی منتقل + ۲ تا اضافه می‌کنه. یعنی هم سپره هم حمله - این تنها کارتیه
  که می‌تونه یه زنجیره‌ی +۴/+۶ رو از رو خودت برداره.
"""
import random

COLORS = ["r", "g", "b", "y"]
COLOR_EMOJI = {"r": "🔴", "g": "🟢", "b": "🔵", "y": "🟡"}
COLOR_NAME = {"r": "قرمز", "g": "سبز", "b": "آبی", "y": "زرد"}

SPECIAL = "X"
WILD = "w"
WILD_DRAW4 = "w+4"

# جریمه‌ی هر کارتِ کشیدنی
DRAW_VALUES = {"+2": 2, "+4": 4, "+6": 6}


# ---------------------------------------------------------------------------
# تجزیه‌ی کارت
# ---------------------------------------------------------------------------

def card_color(card: str):
    """رنگِ ذاتیِ کارت، یا None برای وایلد/ویژه (که رنگ ندارن)."""
    if card in (WILD, WILD_DRAW4, SPECIAL):
        return None
    return card[0] if card and card[0] in COLORS else None


def card_face(card: str) -> str:
    """بخشِ غیررنگیِ کارت: عدد یا S/R یا +2/+4/+6 یا خودِ w / w+4 / X."""
    if card in (WILD, WILD_DRAW4, SPECIAL):
        return card
    return card[1:]


def card_draw_amount(card: str) -> int:
    """اگه کارت جریمه‌ی کشیدن داره، مقدارش؛ وگرنه ۰."""
    face = card_face(card)
    if card == WILD_DRAW4:
        return 4
    if card == SPECIAL:
        return 0  # اثرش جداگونه حساب می‌شه (نگاه کن به apply_special)
    return DRAW_VALUES.get(face, 0)


def card_label(card: str) -> str:
    """نمایشِ فارسیِ خوانا رو خودِ دکمه."""
    if card == SPECIAL:
        return "🌟 ویژه"
    if card == WILD:
        return "🌈 رنگی"
    if card == WILD_DRAW4:
        return "🌈 رنگی +۴"
    c = card_color(card)
    face = card_face(card)
    emoji = COLOR_EMOJI.get(c, "")
    if face == "S":
        return f"{emoji} رد کن"
    if face == "R":
        return f"{emoji} برعکس"
    if face.startswith("+"):
        return f"{emoji} +{face[1:]}"
    return f"{emoji} {face}"


# ---------------------------------------------------------------------------
# ساختِ دسته
# ---------------------------------------------------------------------------

def build_deck(num_players: int, specials_total: int = 4, rng=None) -> list:
    """دسته‌ی کاملِ بازی. اندازه‌اش با تعدادِ بازیکن‌ها کمی تنظیم می‌شه تا هیچ‌وقت
    وسطِ بازی کارت کم نیاد (کشیدن‌های زنجیره‌ای +۶ می‌تونه سریع مصرف کنه)."""
    rng = rng or random
    deck = []
    for c in COLORS:
        deck.append(f"{c}0")
        for n in range(1, 10):
            deck.append(f"{c}{n}")
            deck.append(f"{c}{n}")
        for face in ("S", "R", "+2"):
            deck.append(f"{c}{face}")
            deck.append(f"{c}{face}")
        deck.append(f"{c}+4")
        deck.append(f"{c}+6")
    for _ in range(4):
        deck.append(WILD)
        deck.append(WILD_DRAW4)
    # توجه: کارت‌هایِ «ویژه» عمداً این‌جا اضافه نمی‌شن. اگه تو خودِ دسته بودن،
    # موقعِ پخشِ کارتِ اولیه ممکن بود یکیشون تصادفی دستِ یه بازیکن بیفته و اون
    # قانونِ «دقیقاً ۱ دونه دستِ یه پلیر، ۳ تایِ بقیه وسط» می‌شکست. پس تویِ
    # deal() و بعد از پخشِ کارت‌ها جاگذاری می‌شن.
    if num_players >= 3:
        # فقط کارت‌هایِ عددیِ ساده تکثیر می‌شن - نه ویژه/وایلد/جریمه‌دار، وگرنه
        # تعدادِ کلِ کارتِ «ویژه» از ۴ تا بیشتر می‌شد و قانونِ بازی می‌شکست.
        plain = [c for c in deck if card_color(c) and card_draw_amount(c) == 0
                 and card_face(c) not in ("S", "R")]
        deck = deck + plain
    rng.shuffle(deck)
    return deck


def deal(deck: list, num_players: int, hand_size: int, specials_total: int = 4, rng=None):
    """کارتِ اولیه رو پخش می‌کنه و کارتِ شروعِ روی میز رو انتخاب می‌کنه.

    برمی‌گردونه (hands, draw_pile, start_card, active_color).
    کارتِ شروع همیشه یه کارتِ عددیِ ساده‌ست (نه وایلد/ویژه/جریمه‌دار) تا بازی
    از همون اول با یه زنجیره‌ی جریمه یا رنگِ نامعلوم شروع نشه.
    """
    rng = rng or random
    hands = [[] for _ in range(num_players)]
    for _ in range(hand_size):
        for h in hands:
            h.append(deck.pop())
    # یه کارتِ شروعِ تمیز پیدا کن
    start_idx = None
    for i in range(len(deck) - 1, -1, -1):
        card = deck[i]
        if card_color(card) and card_draw_amount(card) == 0 and card_face(card) not in ("S", "R"):
            start_idx = i
            break
    if start_idx is None:
        start_card = deck.pop()
    else:
        start_card = deck.pop(start_idx)

    # حالا کارت‌هایِ ویژه رو جاگذاری کن: دقیقاً ۱ دونه دستِ یه بازیکنِ شانسی،
    # بقیه‌شون قاطیِ دسته‌ی وسط (که مخفیه) بُر می‌خورن.
    lucky = rng.randrange(num_players)
    hands[lucky].append(SPECIAL)
    for _ in range(max(0, specials_total - 1)):
        deck.insert(rng.randrange(len(deck) + 1), SPECIAL)

    return hands, deck, start_card, card_color(start_card)


# ---------------------------------------------------------------------------
# قانونِ مجازبودنِ حرکت
# ---------------------------------------------------------------------------

def can_play(card: str, top_card: str, active_color: str, pending_draw: int) -> bool:
    """آیا این کارت رو می‌شه الان انداخت؟

    اگه یه جریمه‌ی تجمعی روی میزه (pending_draw > 0)، فقط با یه کارتِ جریمه‌دارِ
    دیگه (یا کارتِ ویژه) می‌شه جواب داد - وگرنه باید بکشی. این همون قانونِ
    «استک‌کردن»ه که بازی رو جذاب نگه می‌داره ولی بن‌بست نمی‌سازه، چون کشیدن
    همیشه ممکنه.
    """
    if pending_draw > 0:
        return card == SPECIAL or card_draw_amount(card) > 0
    if card in (WILD, WILD_DRAW4, SPECIAL):
        return True
    if card_color(card) == active_color:
        return True
    top_face = card_face(top_card)
    if top_card not in (WILD, WILD_DRAW4, SPECIAL) and card_face(card) == top_face:
        return True
    return False


def playable_cards(hand: list, top_card: str, active_color: str, pending_draw: int) -> list:
    return [c for c in hand if can_play(c, top_card, active_color, pending_draw)]


def apply_special(pending_draw: int) -> int:
    """اثرِ کارتِ ویژه: جریمه‌ی روی خودت پاک می‌شه و +۲ به نفرِ بعدی می‌ره."""
    return pending_draw + 2


def draw_cards(draw_pile: list, count: int, discard_history: list = None, rng=None):
    """count تا کارت از دسته می‌کشه. اگه دسته ته کشید و تاریخچه‌ی روشده‌ها
    موجود بود، اونا رو دوباره بُر می‌زنه و به دسته برمی‌گردونه (به‌جز کارتِ
    رویِ میز) - این تضمین می‌کنه بازی هیچ‌وقت به‌خاطرِ تمام‌شدنِ کارت قفل نشه."""
    rng = rng or random
    drawn = []
    for _ in range(count):
        if not draw_pile:
            if discard_history and len(discard_history) > 1:
                recycled = discard_history[:-1]
                del discard_history[:-1]
                rng.shuffle(recycled)
                draw_pile.extend(recycled)
            else:
                break
        drawn.append(draw_pile.pop())
    return drawn


def next_seat(current_seat: int, seats: list, direction: int, steps: int = 1) -> int:
    """نشستِ بعدی بینِ بازیکن‌هایِ هنوز-در-بازی (seats مرتب‌شده)."""
    if not seats:
        return current_seat
    if current_seat in seats:
        idx = seats.index(current_seat)
    else:
        # بازیکنِ فعلی حذف شده - از نزدیک‌ترین نشستِ بعدی ادامه بده
        later = [s for s in seats if s > current_seat]
        idx = seats.index(later[0]) if later else 0
        steps -= 1
    return seats[(idx + direction * steps) % len(seats)]


# ---------------------------------------------------------------------------
# سلف‌تست
# ---------------------------------------------------------------------------

if __name__ == "__main__":
    rng = random.Random(7)
    problems = 0
    for trial in range(400):
        n = rng.choice([2, 3, 4])
        deck = build_deck(n, 4, rng)
        assert deck.count(SPECIAL) == 0, "ویژه‌ها باید تو deal اضافه شن نه build_deck"
        hands, pile, top, color = deal(deck, n, 7, 4, rng)
        assert sum(h.count(SPECIAL) for h in hands) == 1, "باید دقیقا ۱ ویژه دستِ بازیکن‌ها باشه"
        assert pile.count(SPECIAL) == 3, "باید دقیقا ۳ ویژه تو دسته‌ی وسط باشه"
        assert color is not None, "رنگِ شروع باید معلوم باشه"
        assert card_draw_amount(top) == 0, "کارتِ شروع نباید جریمه‌دار باشه"

        # یه بازیِ کامل رو با بازیکن‌های تصادفی شبیه‌سازی کن
        seats = list(range(n))
        pending, direction, seat = 0, 1, 0
        history = [top]
        turns = 0
        while len(seats) > 1 and turns < 4000:
            turns += 1
            hand = hands[seat]
            opts = playable_cards(hand, top, color, pending)
            if opts:
                card = rng.choice(opts)
                hand.remove(card)
                history.append(card)
                if card == SPECIAL:
                    pending = apply_special(pending)
                    color = rng.choice(COLORS)
                elif card in (WILD, WILD_DRAW4):
                    pending += card_draw_amount(card)
                    color = rng.choice(COLORS)
                else:
                    pending += card_draw_amount(card)
                    color = card_color(card)
                top = card
                if not hand:
                    seats.remove(seat)
                    if not seats:
                        break
                    seat = next_seat(seat, seats, direction, 1)
                    continue
                if card_face(card) == "R":
                    direction *= -1
                elif card_face(card) == "S":
                    seat = next_seat(seat, seats, direction, 1)
            else:
                got = draw_cards(pile, max(1, pending), history, rng)
                hand.extend(got)
                pending = 0
                if not got and not pile:
                    break  # کارت تموم شد - نباید پیش بیاد
            seat = next_seat(seat, seats, direction, 1)
        if turns >= 4000:
            problems += 1
    print("بازی‌هایی که قفل شدن یا بی‌پایان موندن:", problems, "از ۴۰۰")
    print("✅ موتورِ اونو سالمه" if problems == 0 else "❌ مشکل داره")
