# -*- coding: utf-8 -*-
"""
ذخیره‌ی ترجیحاتِ هر چت:
  • زبان: برایِ پیوی (chat_id > 0) زبانِ همون کاربر، برایِ گروه (chat_id < 0) زبانِ گروه (فقط ادمینِ گروه عوضش می‌کنه).
  • pm_users: کاربرهایی که تا حالا تو پیوی با بات حرف زدن (فقط برایِ اینها منشنِ text_mention مطمئنه؛ بقیه لینکِ قابل‌کلیکِ جایگزین می‌گیرن).
جدول‌ها خودکار ساخته می‌شن (init()). همه‌ی خوندن‌ها کَش می‌شن تا ارسالِ پیام کند نشه.
"""
import logging
import time

from sqlalchemy import BigInteger, Boolean, Column, DateTime, String
import datetime

import db

logger = logging.getLogger(__name__)

DEFAULT = "fa"


class ChatLang(db.Base):
    __tablename__ = "chat_langs"
    chat_id = Column(BigInteger, primary_key=True)
    lang = Column(String, nullable=False, default=DEFAULT)
    updated_at = Column(DateTime, default=datetime.datetime.utcnow)


class PmUser(db.Base):
    __tablename__ = "pm_users"
    user_id = Column(BigInteger, primary_key=True)
    first_at = Column(DateTime, default=datetime.datetime.utcnow)


_lang_cache = {}       # chat_id -> lang
_pm_cache = set()      # user_ids که می‌دونیم تو پیوی بودن
_pm_loaded = False
_user_cache = {}       # uid -> (ts, username)
_USER_TTL = 600


def init():
    db.Base.metadata.create_all(db.engine, tables=[ChatLang.__table__, PmUser.__table__])
    global _pm_loaded
    s = db.get_session()
    try:
        for (uid,) in s.query(PmUser.user_id).all():
            _pm_cache.add(int(uid))
        for cid, lang in s.query(ChatLang.chat_id, ChatLang.lang).all():
            _lang_cache[int(cid)] = lang or DEFAULT
        _pm_loaded = True
    finally:
        s.close()


# ---------------------------------------------------------------- زبان
def get_lang(chat_id) -> str:
    """زبانِ یه چت (پیوی/گروه). پیش‌فرض فارسی."""
    if chat_id is None:
        return DEFAULT
    try:
        cid = int(chat_id)
    except (TypeError, ValueError):
        return DEFAULT
    hit = _lang_cache.get(cid)
    if hit is not None:
        return hit
    s = db.get_session()
    try:
        row = s.get(ChatLang, cid)
        lang = (row.lang if row and row.lang else DEFAULT)
    except Exception:
        logger.exception("get_lang failed")
        lang = DEFAULT
    finally:
        s.close()
    _lang_cache[cid] = lang
    return lang


def set_lang(chat_id, lang: str):
    cid = int(chat_id)
    s = db.get_session()
    try:
        row = s.get(ChatLang, cid)
        if row is None:
            s.add(ChatLang(chat_id=cid, lang=lang))
        else:
            row.lang = lang
            row.updated_at = datetime.datetime.utcnow()
        s.commit()
    finally:
        s.close()
    _lang_cache[cid] = lang


# ---------------------------------------------------------------- پیوی‌های شناخته‌شده
def mark_pm(user_id):
    uid = int(user_id)
    if uid in _pm_cache:
        return
    _pm_cache.add(uid)
    s = db.get_session()
    try:
        if s.get(PmUser, uid) is None:
            s.add(PmUser(user_id=uid))
            s.commit()
    except Exception:
        s.rollback()
        logger.exception("mark_pm failed")
    finally:
        s.close()


def is_pm_known(user_id) -> bool:
    return int(user_id) in _pm_cache


def username_of(uid):
    """یوزرنیمِ کاربر از جدولِ users (کَش‌شده)."""
    uid = int(uid)
    now = time.time()
    hit = _user_cache.get(uid)
    if hit and now - hit[0] < _USER_TTL:
        return hit[1]
    uname = None
    s = db.get_session()
    try:
        u = s.get(db.User, uid)
        uname = (u.username or None) if u else None
    except Exception:
        uname = None
    finally:
        s.close()
    _user_cache[uid] = (now, uname)
    return uname


def remember_username(uid, username):
    _user_cache[int(uid)] = (time.time(), username or None)
