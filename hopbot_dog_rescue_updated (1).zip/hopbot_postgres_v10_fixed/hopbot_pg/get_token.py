# -*- coding: utf-8 -*-
"""
اسکریپت یک‌بارمصرف برای گرفتنِ token.json جیمیل (Gmail API، اسکوپِ gmail.send).

نحوه‌ی اجرا (رو همون سروری که بات روشه، یا رو سیستم خودت اگه مرورگر داری):
    pip install google-auth-oauthlib google-api-python-client
    python get_token.py

یه لینک تو ترمینال چاپ می‌شه (یا خودکار مرورگر باز می‌شه اگه سیستم گرافیکی داشته باشی)،
وارد همون جیمیلی شو که می‌خوای باهاش کد بفرستی و اجازه بده. بعدش یه فایلِ token.json
کنارِ همین اسکریپت ساخته می‌شه — اون فایل رو نگه دار، دیگه لازم نیست این اسکریپت رو
دوباره اجرا کنی (مگر اینکه token باطل بشه).

credentials.json باید کنارِ همین اسکریپت باشه (همونی که از Google Cloud Console دانلود کردی).
"""
import os
from google_auth_oauthlib.flow import InstalledAppFlow

SCOPES = ["https://www.googleapis.com/auth/gmail.send"]
HERE = os.path.dirname(os.path.abspath(__file__))
CREDENTIALS_PATH = os.path.join(HERE, "credentials.json")
TOKEN_PATH = os.path.join(HERE, "token.json")


def main():
    if not os.path.exists(CREDENTIALS_PATH):
        print(f"❌ فایلِ credentials.json پیدا نشد. باید کنارِ همین اسکریپت باشه: {CREDENTIALS_PATH}")
        return

    flow = InstalledAppFlow.from_client_secrets_file(CREDENTIALS_PATH, SCOPES)
    # اگه رو سرورِ بدونِ مرورگر (headless) هستی، run_local_server ممکنه کار نکنه؛
    # تو اون حالت از run_console() به‌جاش استفاده کن (خط زیر رو عوض کن).
    creds = flow.run_local_server(port=0)

    with open(TOKEN_PATH, "w") as f:
        f.write(creds.to_json())

    print(f"✅ تمام شد! token.json ساخته شد: {TOKEN_PATH}")
    print("این فایل رو نگه دار، بات باهاش کد می‌فرسته. دیگه نیازی به اجرای دوباره‌ی این اسکریپت نیست.")


if __name__ == "__main__":
    main()
