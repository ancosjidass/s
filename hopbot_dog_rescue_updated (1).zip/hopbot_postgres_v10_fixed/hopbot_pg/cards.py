# -*- coding: utf-8 -*-
"""
کارتِ هاپویی 🎴 - ایونتِ موقتِ جمع‌آوریِ کارت (شبیهِ گاچا/کارت‌بازی).

با تایپِ «کارت هاپویی» فعال می‌شه. یه ایونتِ موقته (پیش‌فرض ۳۰ روز، از پنل
قابل‌تغییر) که مالک باید صریحاً شروعش کنه؛ وگرنه هرجایی از این قابلیت
استفاده بشه (توکن/خرید/آگهی) می‌گه ایونت فعال نیست.

۳ لیستِ کارت هست: کمیاب (list_no=1)، جنگلی/خیلی‌کمیاب (list_no=2)، لجند
(list_no=3). هر روز یه سری توکنِ رایگان می‌گیری (که ممکنه کارتِ تکراری بده -
هرچی کارتِ بیشتری از یه لیست داشته باشی، شانسِ تکراری‌گرفتن بیشتر می‌شه، ولی
هیچ‌وقت از یه سقفِ مشخص (پیش‌فرض ۷۰٪) بیشتر نمی‌شه) و می‌تونی تا سقفِ روزانه‌ای
هم توکنِ خریدنی بگیری (که هیچ‌وقت تکراری نمی‌ده - فقط از بینِ کارت‌هایی که هنوز
نداری).

تکمیلِ هر لیست یه جایزه‌ی خاص می‌ده (نگاه کن به _apply_list_reward). کارتِ
تکراری رو می‌شه به یه پلیرِ دیگه (که همون کارت رو تو «آگهی‌های کارت» درخواست
داده) اهدا کرد؛ کارتِ اصلی (تنها نسخه) رو نمی‌شه اهدا کرد. بعدِ اتمامِ ایونت،
هر کارتِ تکراریِ باقی‌مونده رو می‌شه به خودِ بازی فروخت (نگاه کن به
cb_cards_sell_duplicates).
"""
import datetime
import random
import re

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationHandlerStop

import db
import keyboards as kb
from handlers import fmt, send_response, _verify_panel_owner, ask_for_input, is_reply_to_prompt, parse_amount
from myawy import _format_remaining

LIST_NAMES = {1: "🔹 کمیاب", 2: "🔸 جنگلی (خیلی‌کمیاب)", 3: "👑 لجند"}
LIST_FREE_TOKEN_FIELD = {1: "free_rare", 2: "free_wild", 3: "free_legend"}
LIST_FREE_TOKEN_CFG = {1: "card_daily_free_rare", 2: "card_daily_free_wild", 3: "card_daily_free_legend"}
LIST_PRICE_CFG = {1: "card_paid_price_rare", 2: "card_paid_price_wild", 3: "card_paid_price_legend"}
LIST_PROGRESS_FIELD = {1: "list1_reward_claimed", 2: "list2_reward_claimed", 3: "list3_reward_claimed"}

_FA_DIGITS = str.maketrans("۰۱۲۳۴۵۶۷۸۹", "0123456789")


def _normalize_digits(text: str) -> str:
    return text.translate(_FA_DIGITS)


def parse_emoji_list(text: str) -> dict:
    """ورودی مثلِ «۱: 🫪۲:🤩۳:🤣» رو به {1: '🫪', 2: '🤩', 3: '🤣'} تبدیل می‌کنه."""
    text = _normalize_digits(text)
    pattern = re.compile(r"(\d+)\s*[:：]\s*([^\d]+?)(?=\d+\s*[:：]|$)", re.UNICODE)
    result = {}
    for m in pattern.finditer(text):
        idx = int(m.group(1))
        emoji = m.group(2).strip()
        if emoji:
            result[idx] = emoji
    return result


def parse_percent_list(text: str) -> dict:
    """ورودی مثلِ «۱—۲٪ ۲—۱۷٪» یا «۱۷🤡 — ۵.۵۱٪» رو به {1: 2.0, 2: 17.0, 17: 5.51} تبدیل می‌کنه."""
    text = _normalize_digits(text).replace("٪", "%")
    pattern = re.compile(r"(\d+)[^\d.\-—–]*[-—–]\s*([\d.]+)\s*%?", re.UNICODE)
    result = {}
    for m in pattern.finditer(text):
        idx = int(m.group(1))
        pct = float(m.group(2))
        result[idx] = pct
    return result


# ---------------------------------------------------------------------------
# کمکی‌های پایه
# ---------------------------------------------------------------------------

def get_active_event(session):
    return session.query(db.CardEvent).filter_by(is_active=True).first()


def _today_key() -> str:
    return datetime.date.today().isoformat()


def _sync_daily_tokens(session, event, user_id: int):
    row = session.query(db.UserCardTokens).filter_by(event_id=event.id, user_id=user_id).first()
    key = _today_key()
    if not row:
        row = db.UserCardTokens(
            event_id=event.id, user_id=user_id, day_key=key,
            free_rare=db.cfg_get_int(session, "card_daily_free_rare"),
            free_wild=db.cfg_get_int(session, "card_daily_free_wild"),
            free_legend=db.cfg_get_int(session, "card_daily_free_legend"),
            paid_used=0,
        )
        session.add(row)
        return row
    if row.day_key != key:
        row.day_key = key
        row.free_rare = db.cfg_get_int(session, "card_daily_free_rare")
        row.free_wild = db.cfg_get_int(session, "card_daily_free_wild")
        row.free_legend = db.cfg_get_int(session, "card_daily_free_legend")
        row.paid_used = 0
    return row


def _slots_for_list(session, event, list_no: int):
    return (
        session.query(db.CardSlot)
        .filter_by(event_id=event.id, list_no=list_no)
        .order_by(db.CardSlot.slot_index)
        .all()
    )


def _owned_slot_ids(session, event, user_id: int) -> set:
    rows = session.query(db.UserCard).filter_by(event_id=event.id, user_id=user_id).filter(db.UserCard.count > 0).all()
    return {r.slot_id for r in rows}


def _get_or_create_progress(session, event, user_id: int):
    p = session.query(db.UserCardProgress).filter_by(event_id=event.id, user_id=user_id).first()
    if not p:
        p = db.UserCardProgress(event_id=event.id, user_id=user_id)
        session.add(p)
    return p


# ---------------------------------------------------------------------------
# کشیدنِ کارت
# ---------------------------------------------------------------------------

def _draw_slot(session, event, user_id: int, list_no: int, guarantee_new: bool):
    """یه CardSlot برمی‌گردونه (یا None اگه چیزی برای کشیدن نمونده)."""
    slots = _slots_for_list(session, event, list_no)
    if not slots:
        return None
    owned_counts = {
        uc.slot_id: uc.count
        for uc in session.query(db.UserCard).filter_by(event_id=event.id, user_id=user_id).all()
    }
    owned_ids = {sid for sid, c in owned_counts.items() if c > 0}
    unowned = [s for s in slots if s.id not in owned_ids]
    owned = [s for s in slots if s.id in owned_ids]

    if guarantee_new:
        if not unowned:
            return None
        weights = [max(0.0001, s.base_percent) for s in unowned]
        return random.choices(unowned, weights=weights, k=1)[0]

    # سقفِ تعدادِ کارتِ تکراری - کارت‌هایی که بهش رسیدن دیگه جزوِ «پولِ تکراری» حساب نمی‌شن
    max_extra = db.cfg_get_int(session, "card_duplicate_max_extra_copies")
    dup_eligible = [s for s in owned if owned_counts.get(s.id, 0) < 1 + max_extra]

    if not unowned:
        if not dup_eligible:
            return None
        weights = [max(0.0001, s.base_percent) for s in dup_eligible]
        return random.choices(dup_eligible, weights=weights, k=1)[0]

    cap = db.cfg_get_float(session, "card_duplicate_cap_pct")
    owned_sum = sum(s.base_percent for s in dup_eligible)
    dup_pct = min(cap, owned_sum)
    roll = random.uniform(0, 100)
    if roll < dup_pct and dup_eligible:
        weights = [max(0.0001, s.base_percent) for s in dup_eligible]
        return random.choices(dup_eligible, weights=weights, k=1)[0]
    weights = [max(0.0001, s.base_percent) for s in unowned]
    return random.choices(unowned, weights=weights, k=1)[0]


def _grant_card(session, event, user, slot):
    """کارت رو به کاربر اضافه می‌کنه. برمی‌گردونه (is_new: bool, list_completed: bool)."""
    row = session.query(db.UserCard).filter_by(event_id=event.id, user_id=user.telegram_id, slot_id=slot.id).first()
    is_new = row is None or row.count <= 0
    if row:
        row.count += 1
    else:
        session.add(db.UserCard(event_id=event.id, user_id=user.telegram_id, slot_id=slot.id, count=1))
    list_completed = False
    if is_new:
        if slot.is_special and slot.special_reward_points:
            user.hop_points += slot.special_reward_points
        list_completed = _maybe_complete_list(session, event, user, slot.list_no)
    return is_new, list_completed


def _maybe_complete_list(session, event, user, list_no: int) -> bool:
    slots = _slots_for_list(session, event, list_no)
    if not slots:
        return False
    owned_ids = _owned_slot_ids(session, event, user.telegram_id)
    if not all(s.id in owned_ids for s in slots):
        return False
    progress = _get_or_create_progress(session, event, user.telegram_id)
    field = LIST_PROGRESS_FIELD[list_no]
    if getattr(progress, field):
        return False
    setattr(progress, field, True)
    _apply_list_reward(session, event, user, list_no)
    return True


def _apply_list_reward(session, event, user, list_no: int):
    if list_no == 1:
        units = db.cfg_get_float(session, "card_list1_reward_crypto_units")
        currencies = session.query(db.Currency).all()
        if currencies:
            currency = random.choice(currencies)
            uc = session.query(db.UserCurrency).filter_by(user_id=user.telegram_id, currency_id=currency.id).first()
            if not uc:
                uc = db.UserCurrency(user_id=user.telegram_id, currency_id=currency.id, amount=0)
                session.add(uc)
            uc.amount = (uc.amount or 0) + units
    elif list_no == 2:
        import economy
        economy.sync_dog_food(session, user)
        units = db.cfg_get_float(session, "card_list2_reward_food_units")
        minutes_per_unit = db.cfg_get_float(session, "chef_dog_food_minutes_per_unit")
        cap_minutes = economy.dog_food_capacity_minutes(session, user)
        user.dog_food = min(cap_minutes, (user.dog_food or 0) + units * minutes_per_unit)
    elif list_no == 3:
        points = db.cfg_get_float(session, "card_list3_reward_bank_points")
        user.bank_balance = (user.bank_balance or 0) + points


# ---------------------------------------------------------------------------
# نمایشِ خانه
# ---------------------------------------------------------------------------

def _has_sellable_duplicates(session, user_id: int) -> bool:
    ended_ids = [e for e, in session.query(db.CardEvent.id).filter_by(is_active=False).all()]
    if not ended_ids:
        return False
    return (
        session.query(db.UserCard)
        .filter(db.UserCard.user_id == user_id, db.UserCard.event_id.in_(ended_ids), db.UserCard.count > 1)
        .first()
        is not None
    )


async def handle_cards_trigger(update, context):
    await show_cards_home(update, context)


async def show_cards_home(update, context):
    session = db.get_session()
    try:
        user = db.get_or_create_user(session, update.effective_user)
        event = get_active_event(session)
        has_sellable = _has_sellable_duplicates(session, user.telegram_id)
        if not event:
            session.commit()
            await send_response(
                update, "🎴 الان هیچ ایونتِ کارتِ هاپویی‌ای فعال نیست.",
                kb.cards_home_keyboard(user.telegram_id, active=False, has_sellable=has_sellable),
            )
            return
        tokens = _sync_daily_tokens(session, event, user.telegram_id)
        session.commit()
        nowt = datetime.datetime.utcnow()
        remain = _format_remaining(event.ends_at - nowt) if event.ends_at > nowt else "به‌زودی تموم می‌شه"
        lines = [
            "🎴 کارتِ هاپویی\n",
            f"⏳ تا پایانِ ایونت: {remain}",
            f"🎟 توکنِ رایگانِ امروز: 🔹{tokens.free_rare} | 🔸{tokens.free_wild} | 👑{tokens.free_legend}",
            f"💳 توکنِ خریدنیِ امروز: {tokens.paid_used}/{db.cfg_get_int(session, 'card_daily_paid_max')}",
        ]
        await send_response(update, "\n".join(lines), kb.cards_home_keyboard(user.telegram_id, active=True, has_sellable=has_sellable))
    finally:
        session.close()


async def cb_cards_home(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await show_cards_home(update, context)


async def cb_cards_list_view(update, context):
    _, list_no, owner_id = update.callback_query.data.split(":")[:3]
    list_no, owner_id = int(list_no), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        event = get_active_event(session)
        if not event:
            session.commit()
            await update.callback_query.answer("الان هیچ ایونتی فعال نیست.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        tokens = _sync_daily_tokens(session, event, user.telegram_id)
        slots = _slots_for_list(session, event, list_no)
        owned = {
            uc.slot_id: uc.count
            for uc in session.query(db.UserCard).filter_by(event_id=event.id, user_id=user.telegram_id).all()
        }
        grid_parts = []
        for s in slots:
            if owned.get(s.id, 0) > 0:
                tag = f"×{owned[s.id]}" if owned[s.id] > 1 else ""
                grid_parts.append(f"{s.emoji}{tag}")
            else:
                grid_parts.append("❔")
        grid = " ".join(grid_parts)
        owned_count = sum(1 for s in slots if owned.get(s.id, 0) > 0)
        free_count = getattr(tokens, LIST_FREE_TOKEN_FIELD[list_no])
        price = db.cfg_get_float(session, LIST_PRICE_CFG[list_no])
        session.commit()
        text = (
            f"{LIST_NAMES[list_no]}\n\n{grid or '(خالیه - مالک هنوز کارتی تعریف نکرده)'}\n\n"
            f"جمع‌شده: {owned_count}/{len(slots)}\n"
            f"🎟 توکنِ رایگانِ امروز: {free_count}"
        )
        await send_response(update, text, kb.cards_list_keyboard(list_no, owner_id, free_count > 0, price))
    finally:
        session.close()


# ---------------------------------------------------------------------------
# کشیدنِ توکن / خریدِ توکن
# ---------------------------------------------------------------------------

async def _notify_special(context, owner_id: int, slot):
    if not (slot.is_special and slot.special_reward_points):
        return
    try:
        await context.bot.send_message(
            owner_id,
            f"🎊 کارتِ ویژه‌ی {slot.emoji} گرفتی! {fmt(slot.special_reward_points)} 🪙 بهت اضافه شد.",
        )
    except Exception:
        pass


async def cb_cards_draw_free(update, context):
    _, list_no, owner_id = update.callback_query.data.split(":")
    list_no, owner_id = int(list_no), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        event = get_active_event(session)
        if not event:
            session.commit()
            await update.callback_query.answer("الان هیچ ایونتی فعال نیست.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        tokens = _sync_daily_tokens(session, event, user.telegram_id)
        field = LIST_FREE_TOKEN_FIELD[list_no]
        if getattr(tokens, field) <= 0:
            session.commit()
            await update.callback_query.answer("توکنِ رایگانِ امروزت برای این لیست تموم شده.", show_alert=True)
            return
        slot = _draw_slot(session, event, user.telegram_id, list_no, guarantee_new=False)
        if not slot:
            session.commit()
            await update.callback_query.answer("این لیست هنوز کارتی نداره - مالک باید از پنل تنظیمش کنه.", show_alert=True)
            return
        setattr(tokens, field, getattr(tokens, field) - 1)
        is_new, list_completed = _grant_card(session, event, user, slot)
        special = slot.is_special and is_new
        session.commit()
        msg = f"{slot.emoji} گرفتی!" + (" ✨ (جدید)" if is_new else " (تکراری)")
        if list_completed:
            msg += "\n🎉 لیست کامل شد! جایزه‌ت واریز شد."
        await update.callback_query.answer(msg, show_alert=True)
        if special:
            await _notify_special(context, owner_id, slot)
    finally:
        session.close()
    await cb_cards_list_view(update, context)


async def cb_cards_buy_token(update, context):
    _, list_no, owner_id = update.callback_query.data.split(":")
    list_no, owner_id = int(list_no), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        event = get_active_event(session)
        if not event:
            session.commit()
            await update.callback_query.answer("الان هیچ ایونتی فعال نیست.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        tokens = _sync_daily_tokens(session, event, user.telegram_id)
        max_paid = db.cfg_get_int(session, "card_daily_paid_max")
        if tokens.paid_used >= max_paid:
            session.commit()
            await update.callback_query.answer("سقفِ خریدِ توکنِ امروزت تموم شده.", show_alert=True)
            return
        price = db.cfg_get_float(session, LIST_PRICE_CFG[list_no])
        if user.hop_points < price - 0.5:
            session.commit()
            await update.callback_query.answer(f"موجودی کافی نیست! {fmt(price)} 🪙 لازمه.", show_alert=True)
            return
        slot = _draw_slot(session, event, user.telegram_id, list_no, guarantee_new=True)
        if not slot:
            session.commit()
            await update.callback_query.answer("این لیست رو کامل کردی - کارتِ جدیدی نمونده که بخری.", show_alert=True)
            return
        user.hop_points -= price
        tokens.paid_used += 1
        is_new, list_completed = _grant_card(session, event, user, slot)
        special = slot.is_special and is_new
        session.commit()
        msg = f"✅ {slot.emoji} خریدی (بدونِ تکراری)!"
        if list_completed:
            msg += "\n🎉 لیست کامل شد! جایزه‌ت واریز شد."
        await update.callback_query.answer(msg, show_alert=True)
        if special:
            await _notify_special(context, owner_id, slot)
    finally:
        session.close()
    await cb_cards_list_view(update, context)


# ---------------------------------------------------------------------------
# آگهی‌های کارت (خرید/فروشِ واقعی بینِ پلیرها - هر کارتی، هر قیمتی)
# ---------------------------------------------------------------------------

async def cb_cards_market(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        event = get_active_event(session)
        if not event:
            session.commit()
            await update.callback_query.answer("الان هیچ ایونتی فعال نیست.", show_alert=True)
            return
        listings = (
            session.query(db.CardListing)
            .filter_by(event_id=event.id, is_sold=False)
            .order_by(db.CardListing.created_at.desc())
            .limit(30)
            .all()
        )
        items = []
        for listing in listings:
            if listing.seller_id == owner_id:
                continue
            slot = session.get(db.CardSlot, listing.slot_id)
            seller = session.get(db.User, listing.seller_id)
            items.append((listing.id, f"{slot.emoji if slot else '?'} - {fmt(listing.price)}🪙 (فروشنده: {seller.display_name() if seller else listing.seller_id})"))
        my_count = session.query(db.CardListing).filter_by(event_id=event.id, seller_id=owner_id, is_sold=False).count()
        session.commit()
        text = "📋 آگهی‌های فروشِ کارت:" if items else "📋 فعلاً هیچ کارتی برای فروش گذاشته نشده."
        await send_response(update, text, kb.cards_market_keyboard(items, owner_id, my_count))
    finally:
        session.close()


async def cb_cards_market_sell_ask(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        event = get_active_event(session)
        if not event:
            session.commit()
            await update.callback_query.answer("الان هیچ ایونتی فعال نیست.", show_alert=True)
            return
        session.commit()
        await send_response(update, "کارتِ کدوم لیست رو می‌خوای بفروشی؟", kb.cards_sell_pick_list_keyboard(owner_id))
    finally:
        session.close()


async def cb_cards_market_sell_list(update, context):
    _, list_no, owner_id = update.callback_query.data.split(":")
    list_no, owner_id = int(list_no), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        event = get_active_event(session)
        if not event:
            session.commit()
            await update.callback_query.answer("الان هیچ ایونتی فعال نیست.", show_alert=True)
            return
        slots = _slots_for_list(session, event, list_no)
        owned = {
            uc.slot_id: uc.count
            for uc in session.query(db.UserCard).filter_by(event_id=event.id, user_id=owner_id).all()
            if uc.count > 0
        }
        my_slots = [(s, owned[s.id]) for s in slots if s.id in owned]
        session.commit()
        if not my_slots:
            await update.callback_query.answer("از این لیست هیچ کارتی نداری.", show_alert=True)
            return
        await send_response(update, "کدوم کارت رو می‌خوای بفروشی؟", kb.cards_sell_pick_slot_keyboard(my_slots, owner_id))
    finally:
        session.close()


async def cb_cards_market_sell_pick(update, context):
    _, slot_id, owner_id = update.callback_query.data.split(":")
    slot_id, owner_id = int(slot_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        card = session.query(db.UserCard).filter_by(user_id=owner_id, slot_id=slot_id).filter(db.UserCard.count > 0).first()
        if not card:
            session.commit()
            await update.callback_query.answer("این کارت رو دیگه نداری.", show_alert=True)
            return
        slot = session.get(db.CardSlot, slot_id)
        session.commit()
    finally:
        session.close()
    await ask_for_input(
        update, context, f"💰 {slot.emoji} رو با چه قیمتی بذاری برای فروش؟ (هاپ پوینت)",
        {"type": "cards_sell_price", "slot_id": slot_id}, "cards_awaiting",
    )


async def _render_market_mine(update, context, owner_id: int):
    session = db.get_session()
    try:
        event = get_active_event(session)
        items = []
        if event:
            listings = session.query(db.CardListing).filter_by(event_id=event.id, seller_id=owner_id, is_sold=False).all()
            for listing in listings:
                slot = session.get(db.CardSlot, listing.slot_id)
                items.append((listing.id, f"{slot.emoji if slot else '?'} - {fmt(listing.price)}🪙"))
        session.commit()
        text = "📋 آگهی‌های فروشِ من:" if items else "هیچ آگهیِ فعالی نداری."
        await send_response(update, text, kb.cards_market_mine_keyboard(items, owner_id))
    finally:
        session.close()


async def cb_cards_market_mine(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    await _render_market_mine(update, context, owner_id)


async def cb_cards_market_cancel(update, context):
    _, listing_id, owner_id = update.callback_query.data.split(":")
    listing_id, owner_id = int(listing_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        listing = session.get(db.CardListing, listing_id)
        if listing and listing.seller_id == owner_id and not listing.is_sold:
            card = session.query(db.UserCard).filter_by(event_id=listing.event_id, user_id=owner_id, slot_id=listing.slot_id).first()
            if card:
                card.count += 1
            else:
                session.add(db.UserCard(event_id=listing.event_id, user_id=owner_id, slot_id=listing.slot_id, count=1))
            session.delete(listing)
            session.commit()
    finally:
        session.close()
    await _render_market_mine(update, context, owner_id)


async def cb_cards_market_buy_ask(update, context):
    """قبلاً با یه کلیک خرید انجام می‌شد؛ حالا اول تاییدیه می‌گیریم."""
    _, listing_id, owner_id = update.callback_query.data.split(":")
    listing_id, owner_id = int(listing_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        listing = session.get(db.CardListing, listing_id)
        if not listing or listing.is_sold:
            await update.callback_query.answer("این آگهی دیگه موجود نیست.", show_alert=True)
            await cb_cards_market_render(update, context, owner_id)
            return
        if listing.seller_id == owner_id:
            await update.callback_query.answer("این آگهیِ خودته!", show_alert=True)
            return
        slot = session.get(db.CardSlot, listing.slot_id)
        seller = session.get(db.User, listing.seller_id)
        text = (
            f"📋 مطمئنی می‌خوای این کارت رو بخری؟\n\n"
            f"{slot.emoji if slot else '?'} کارت\n"
            f"💰 قیمت: {fmt(listing.price)} 🪙\n"
            f"👤 فروشنده: {seller.display_name() if seller else listing.seller_id}"
        )
        await send_response(update, text, kb.cards_market_buy_confirm_keyboard(listing_id, owner_id))
    finally:
        session.close()


async def cb_cards_market_buy_confirm(update, context):
    _, listing_id, owner_id = update.callback_query.data.split(":")
    listing_id, owner_id = int(listing_id), int(owner_id)
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        listing = session.get(db.CardListing, listing_id)
        if not listing or listing.is_sold:
            session.commit()
            await update.callback_query.answer("این آگهی دیگه موجود نیست.", show_alert=True)
            await cb_cards_market_render(update, context, owner_id)
            return
        if listing.seller_id == owner_id:
            session.commit()
            await update.callback_query.answer("این آگهیِ خودته!", show_alert=True)
            return
        buyer = db.get_or_create_user(session, update.effective_user)
        if buyer.hop_points < listing.price - 0.5:
            session.commit()
            await update.callback_query.answer(f"موجودی کافی نیست! {fmt(listing.price)} 🪙 لازمه.", show_alert=True)
            return
        seller = session.get(db.User, listing.seller_id)
        buyer.hop_points -= listing.price
        if seller:
            seller.hop_points += listing.price
        recv_card = session.query(db.UserCard).filter_by(event_id=listing.event_id, user_id=owner_id, slot_id=listing.slot_id).first()
        if recv_card:
            recv_card.count += 1
        else:
            session.add(db.UserCard(event_id=listing.event_id, user_id=owner_id, slot_id=listing.slot_id, count=1))
        listing.is_sold = True
        listing.buyer_id = owner_id
        listing.sold_at = db.now()
        slot = session.get(db.CardSlot, listing.slot_id)
        event = session.get(db.CardEvent, listing.event_id)
        if slot and event:
            _maybe_complete_list(session, event, buyer, slot.list_no)
        session.commit()
        await update.callback_query.answer("✅ کارت خریده شد!")
    finally:
        session.close()
    await cb_cards_market_render(update, context, owner_id)


async def cb_cards_market_render(update, context, owner_id: int):
    session = db.get_session()
    try:
        event = get_active_event(session)
        items = []
        if event:
            listings = (
                session.query(db.CardListing)
                .filter_by(event_id=event.id, is_sold=False)
                .order_by(db.CardListing.created_at.desc())
                .limit(30)
                .all()
            )
            for listing in listings:
                if listing.seller_id == owner_id:
                    continue
                slot = session.get(db.CardSlot, listing.slot_id)
                seller = session.get(db.User, listing.seller_id)
                items.append((listing.id, f"{slot.emoji if slot else '?'} - {fmt(listing.price)}🪙 (فروشنده: {seller.display_name() if seller else listing.seller_id})"))
        my_count = session.query(db.CardListing).filter_by(event_id=event.id, seller_id=owner_id, is_sold=False).count() if event else 0
        session.commit()
        text = "📋 آگهی‌های فروشِ کارت:" if items else "📋 فعلاً هیچ کارتی برای فروش گذاشته نشده."
        await send_response(update, text, kb.cards_market_keyboard(items, owner_id, my_count))
    finally:
        session.close()


async def cards_awaiting_handler(update, context):
    state = context.user_data.get("cards_awaiting")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return
    text = (update.message.text or "").strip()
    kind = state["type"]
    session = db.get_session()
    try:
        if kind == "cards_sell_price":
            price = parse_amount(text)
            if price is None or price <= 0:
                context.user_data.pop("cards_awaiting", None)
                await update.message.reply_text("❌ مقدار اشتباه است؛ عملیات لغو شد. دوباره از دکمه‌ی مربوطه شروع کن.")
                raise ApplicationHandlerStop
            user = db.get_or_create_user(session, update.effective_user)
            slot_id = state["slot_id"]
            card = session.query(db.UserCard).filter_by(user_id=user.telegram_id, slot_id=slot_id).filter(db.UserCard.count > 0).first()
            if not card:
                context.user_data.pop("cards_awaiting", None)
                await update.message.reply_text("❌ این کارت رو دیگه نداری.")
                raise ApplicationHandlerStop
            slot = session.get(db.CardSlot, slot_id)
            card.count -= 1
            session.add(db.CardListing(event_id=slot.event_id, seller_id=user.telegram_id, slot_id=slot_id, price=price))
            session.commit()
            context.user_data.pop("cards_awaiting", None)
            await update.message.reply_text(f"✅ {slot.emoji} با قیمتِ {fmt(price)} 🪙 گذاشته شد برای فروش.")
    finally:
        session.close()


# ---------------------------------------------------------------------------
# فروشِ کارت‌های تکراری (بعدِ اتمامِ ایونت)
# ---------------------------------------------------------------------------

async def cb_cards_sell_duplicates(update, context):
    owner_id = int(update.callback_query.data.split(":")[1])
    if not await _verify_panel_owner(update, owner_id):
        return
    session = db.get_session()
    try:
        ended_ids = [e for e, in session.query(db.CardEvent.id).filter_by(is_active=False).all()]
        cards = (
            session.query(db.UserCard)
            .filter(db.UserCard.user_id == owner_id, db.UserCard.event_id.in_(ended_ids), db.UserCard.count > 1)
            .all()
            if ended_ids else []
        )
        if not cards:
            session.commit()
            await update.callback_query.answer("کارتِ تکراریِ قابل‌فروشی نداری.", show_alert=True)
            return
        price = db.cfg_get_float(session, "card_duplicate_sell_price")
        user = db.get_or_create_user(session, update.effective_user)
        total_dupes = sum(c.count - 1 for c in cards)
        for c in cards:
            c.count = 1
        user.hop_points += total_dupes * price
        session.commit()
        await update.callback_query.answer(f"✅ {total_dupes} کارتِ تکراری فروختی و {fmt(total_dupes * price)} 🪙 گرفتی!", show_alert=True)
    finally:
        session.close()
    await show_cards_home(update, context)


# ---------------------------------------------------------------------------
# مسیریاب دکمه‌های شیشه‌ای
# ---------------------------------------------------------------------------

CARDS_PREFIX_MAP = {
    "cards_home": cb_cards_home,
    "cards_list_view": cb_cards_list_view,
    "cards_draw_free": cb_cards_draw_free,
    "cards_buy_token": cb_cards_buy_token,
    "cards_market": cb_cards_market,
    "cards_market_sell_ask": cb_cards_market_sell_ask,
    "cards_market_sell_list": cb_cards_market_sell_list,
    "cards_market_sell_pick": cb_cards_market_sell_pick,
    "cards_market_mine": cb_cards_market_mine,
    "cards_market_cancel": cb_cards_market_cancel,
    "cards_market_buy_ask": cb_cards_market_buy_ask,
    "cards_market_buy_confirm": cb_cards_market_buy_confirm,
    "cards_sell_duplicates": cb_cards_sell_duplicates,
}


async def cards_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = CARDS_PREFIX_MAP.get(prefix)
    if not handler:
        return False
    await handler(update, context)
    return True
