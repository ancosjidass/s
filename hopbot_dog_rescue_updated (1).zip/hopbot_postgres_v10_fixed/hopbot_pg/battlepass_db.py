# -*- coding: utf-8 -*-
"""
مدل‌ها + تنظیماتِ «بتل‌پسِ هاپویی» (Battle Pass).

ایده (الهام از کالاف دیوتی):
  • هر فصل (پیش‌فرض ۳۰ روز) ۱۰۰ تیر داره؛ هر تیر دو جایزه: مسیرِ رایگان + مسیرِ پریمیوم.
  • XP از ۳ جا میاد: چلنج‌هایِ روزانه/هفتگی/فصلی (۴ درجه‌ی سختی)، فعالیتِ روزانه (سقف‌دار) و استریک.
  • هرچی تیر بالاتر، XPِ لازم بیشتر (۵ «مرحله‌ی سختی»)؛ بعد از تیر ۱۰۰ «مسترى» بی‌نهایت.
  • فصل‌ها پشتِ‌هم میان (ادامه‌دار)، جایزه‌هایِ هر فصل جدا قابل‌تغییره و فصلِ بعد از فصلِ قبل کپی می‌شه.
  • پیشرفت از جدول‌هایِ خودِ بازی‌ها خونده می‌شه (مثلِ مأموریت‌ها)؛ به کدِ بازی‌ها دست نمی‌زنیم.
هر چیزِ عددی از پنلِ ادمین قابل‌تغییره.
"""
from sqlalchemy import (Column, Integer, BigInteger, Float, String, Boolean, DateTime, Text, Index,
                        UniqueConstraint)

import db
from db import Base, now

# کلید، برچسبِ فارسی، پیش‌فرض، توضیح
CFG = [
    ("bp_enabled", "🟢 بتل‌پس روشن باشه؟ (۱/۰)", "1", ""),
    ("bp_tz_minutes", "🕐 اختلافِ ساعتِ محلی با UTC (دقیقه)", "210", "ایران = ۲۱۰"),
    # --- هاپ بیشتر ---
    ("bp_hop_bonus_global_pct", "🦘 درصدِ هاپِ بیشتر برای همه (ایونت)", "0", "مثلاً ۲۰ یعنی هر «هاپ» ۲۰٪ بیشتر پول بده؛ برای ایونتِ موقت"),
    ("bp_hop_bonus_premium_pct", "👑 درصدِ هاپِ بیشتر برای پریمیوم", "10", ""),
    ("bp_hop_bonus_cap_pct", "🔒 سقفِ مجموعِ درصدِ هاپِ بیشتر", "150", "بوستر + تیرها + پریمیوم + ایونت"),
    # --- فصل ---
    ("bp_season_days", "📅 طولِ هر فصل (روز)", "30", ""),
    ("bp_tiers", "🎚 تعدادِ تیرها", "100", "۵ مرحله‌ی سختی = تیرها ÷ ۵"),
    ("bp_auto_next_season", "🔁 فصلِ بعد خودکار شروع بشه؟ (۱/۰)", "1", "ادامه‌دار بودنِ بتل‌پس"),
    ("bp_grace_days", "⏳ مهلتِ دریافتِ جایزه‌هایِ فصلِ تمام‌شده (روز)", "3", ""),
    ("bp_season_names", "🏷 اسمِ فصل‌ها (با | جدا کن؛ چرخشی)", "فصلِ شکارچی|فصلِ سایه|فصلِ طلایه‌دار|فصلِ طوفان|فصلِ افسانه", ""),
    # --- XP و سختی ---
    ("bp_stage_costs", "📈 XPِ لازم برای هر تیر در ۵ مرحله‌ی سختی (با کاما)", "500,750,1100,1500,2000", "تازه‌کار، سرباز، ستوان، سرگرد، افسانه"),
    ("bp_mastery_cost", "♾ XPِ لازم برای هر سطحِ «مسترى» (بعد از تیرِ آخر)", "3000", ""),
    ("bp_xp_global_pct", "⚡️ درصدِ XPِ بیشتر برای همه (ایونتِ آخرِ هفته)", "0", ""),
    ("bp_xp_premium_pct", "👑 درصدِ XPِ بیشترِ پریمیوم", "10", ""),
    ("bp_activity_cap_day", "🧮 سقفِ XPِ فعالیتِ روزانه", "1500", "ضدِ فارم؛ چلنج‌ها جدا حساب می‌شن"),
    ("bp_activity_weights",
     "🎮 XP به‌ازایِ هر فعالیت (معیار:XP با کاما)",
     "hops:4,casino_played:15,roulette_played:15,uno_played:20,mafia_played:25,guess_played:12,mind_played:12,"
     "ship_played:15,duel_played:15,rob_attempts:20,smuggle_started:10,smuggle_success:30,heist_played:40,"
     "heist_success:60,war_attacks:12,war_wins:25,myawy_posts:8,myawy_likes:2", ""),
    ("bp_backfill_days", "⏪ چند روزِ گذشته (اگه بازیکن سر نزده) فعالیت حساب بشه", "10", ""),
    ("bp_week_difficulty", "🔥 افزایشِ سختیِ چلنج‌ها در هر هفته‌ی فصل (ضریب)", "0.12", "۰.۱۲ = هفته‌ی ۴ حدود ۱.۴۸ برابرِ هفته‌ی ۱"),
    ("bp_level_scale", "🎯 افزایشِ سختیِ چلنج‌ها بر اساسِ لولِ بازیکن (ضریب)", "0.5", "۰ = بدونِ اثر"),
    ("bp_level_cap", "🎯 لولی که از اون به بعد سختیِ بیشتر نمی‌شه", "100", ""),
    ("bp_daily_diffs", "📅 درجه‌هایِ چلنجِ روزانه (۱ آسان … ۴ الیت)", "1,2,3", ""),
    ("bp_weekly_diffs", "🗓 درجه‌هایِ چلنجِ هفتگی", "1,2,3,4", ""),
    ("bp_season_challenges", "🏔 حداکثرِ چلنجِ فصلی که نشون داده می‌شه", "6", ""),
    ("bp_streak_xp_pct_per_day", "🔥 درصدِ XPِ بیشتر به‌ازایِ هر روزِ استریک", "3", ""),
    ("bp_streak_max_days", "🔥 سقفِ روزهایِ استریک برای بونوس", "10", ""),
    # --- پول ---
    ("bp_cash_unit", "💰 واحدِ پاداشِ نقدی (هاپ)", "100000", "کل مسیرِ رایگان ≈ ۲۷ میلیون و پریمیوم ≈ ۶۲ میلیون؛ درآمدِ پایه‌ی کارخونه ≈ ۵۲ میلیون در ماه"),
    ("bp_premium_price", "👑 قیمتِ پریمیوم (هاپ)", "30000000", "حدودِ نصفِ ارزشِ نقدیِ مسیرِ پریمیوم + بوسترها"),
    ("bp_skip_price", "⏭ قیمتِ پایه‌ی رد‌کردنِ یک تیر (هاپ)", "1500000", "هر مرحله‌ی سختی ۲۵٪ گران‌تر"),
    ("bp_leaderboard_size", "📋 تعدادِ نفراتِ جدولِ برترین‌ها", "10", ""),
]
CFG_DEFAULT = {k: v for k, _l, v, _h in CFG}
CFG_LABEL = {k: l for k, l, _v, _h in CFG}
CFG_HELP = {k: h for k, _l, _v, h in CFG}
db.DEFAULT_CONFIG.update(CFG_DEFAULT)
db.MODULE_LEVEL_GATES.setdefault("battlepass", "🎖 بتل‌پسِ هاپویی")
db.DEFAULT_CONFIG.setdefault("minlvl_battlepass", "0")

DIFF = {1: "⭐ آسان", 2: "⭐⭐ متوسط", 3: "⭐⭐⭐ سخت", 4: "💀 الیت"}
PERIODS = {"daily": "📅 روزانه", "weekly": "🗓 هفتگی", "season": "🏔 فصلی"}
STAGES = ["🪖 تازه‌کار", "🎖 سرباز", "🥈 ستوان", "🥇 سرگرد", "👑 افسانه"]

# انواعِ جایزه
KINDS = {
    "hop": "💰 هاپ پوینت (نقدی)",
    "hop_perm": "🦘 درصدِ هاپِ دائمی تا آخرِ فصل",
    "hop_boost": "🦘 بوسترِ درصدِ هاپ",
    "prod_boost": "🏭 بوسترِ تولیدِ کارخونه",
    "xp_boost": "⚡️ بوسترِ XP",
    "heist_loot": "🥷 بوسترِ غنیمتِ سرقت (تعدادی)",
    "heist_cd": "⏱ کاهشِ کول‌دانِ سرقت (تعدادی)",
    "jail_free": "🗝 کارتِ آزادیِ فوری از زندان",
    "shop_money": "💵 بوسترِ پولِ فروشگاه (ارزان‌ترینِ موجود)",
    "shop_power": "💪 بوسترِ قدرتِ فروشگاه (ارزان‌ترینِ موجود)",
    "xp": "⭐ XPِ مستقیم",
    "title": "🏷 لقب",
    "fr_fuel": "⛽ سوختِ Frontier (amount = مقدار)",
    "fr_atk": "💥 قدرتِ حمله‌ی Frontier (pct درصد، uses تعدادِ عملیات)",
    "fr_loot": "🎁 پاداشِ بیشترِ Frontier (pct درصد، uses تعدادِ عملیات)",
    "fr_mats": "🔩 موادِ جنگ (amount = مقدار)",
    "fr_clue": "🔎 سرنخِ اتاقِ مخفی (amount = تعداد)",
    "none": "— (خالی)",
}
# بوسترهایی که تو جدولِ bp_boosters می‌رن
BOOSTER_KINDS = {"hop_boost", "prod_boost", "xp_boost", "heist_loot", "heist_cd", "jail_free"}
BOOSTER_LABEL = {
    "hop_boost": "🦘 هاپِ بیشتر", "prod_boost": "🏭 تولیدِ کارخونه", "xp_boost": "⚡️ XP بتل‌پس",
    "heist_loot": "🥷 غنیمتِ سرقت", "heist_cd": "⏱ کول‌دانِ سرقت", "jail_free": "🗝 کارتِ آزادی",
}

CH_FIELDS = [
    ("title", "📛 عنوان", "str"),
    ("metric", "📏 معیار (از لیستِ معیارها)", "metric"),
    ("target", "🎯 تعدادِ پایه (با سختیِ فصل/لول بالا می‌ره)", "int"),
    ("xp", "⭐ XPِ پایه", "int"),
    ("diff", "🏷 درجه (۱ آسان، ۲ متوسط، ۳ سخت، ۴ الیت)", "int"),
    ("period", "⏱ دوره (daily/weekly/season)", "enum:daily|weekly|season"),
    ("unlock_week", "🔓 از هفته‌ی چندمِ فصل باز بشه (۰ = از اول)", "int"),
    ("min_level", "⭐ حداقل لولِ بازیکن", "int"),
    ("sort", "↕️ ترتیب", "int"),
]
CH_LABEL = {k: l for k, l, _t in CH_FIELDS}
CH_KIND = {k: t for k, _l, t in CH_FIELDS}


class BpSeason(Base):
    __tablename__ = "bp_seasons"
    id = Column(Integer, primary_key=True, autoincrement=True)
    number = Column(Integer, default=1)
    name = Column(String, default="")
    started_at = Column(DateTime, nullable=False)
    ends_at = Column(DateTime, nullable=False)
    status = Column(String, default="active", index=True)   # active / ended
    tiers = Column(Integer, default=100)
    created_at = Column(DateTime, default=now)


class BpPlayer(Base):
    """پیشرفتِ یه بازیکن تو یه فصل."""
    __tablename__ = "bp_players"
    user_id = Column(BigInteger, primary_key=True, autoincrement=False)
    season_id = Column(Integer, primary_key=True, autoincrement=False)
    xp = Column(Float, default=0)
    premium = Column(Boolean, default=False)
    premium_at = Column(DateTime, nullable=True)
    hop_perm_pct = Column(Float, default=0)
    titles = Column(Text, default="")
    streak = Column(Integer, default=0)
    best_streak = Column(Integer, default=0)
    last_streak_day = Column(String, default="")
    last_sync_at = Column(DateTime, nullable=True)
    last_sync_day = Column(String, default="")
    last_hop_count = Column(Integer, nullable=True)
    skips = Column(Integer, default=0)
    created_at = Column(DateTime, default=now)
    __table_args__ = (Index("ix_bp_players_season_xp", "season_id", "xp"),)


class BpDay(Base):
    """XPِ فعالیتِ هر روز (برای سقفِ روزانه و جلوگیریِ دوباره‌شماری) + تعدادِ هاپِ همون روز."""
    __tablename__ = "bp_days"
    user_id = Column(BigInteger, primary_key=True, autoincrement=False)
    season_id = Column(Integer, primary_key=True, autoincrement=False)
    day_key = Column(String, primary_key=True)
    xp = Column(Float, default=0)       # XPِ پایه‌ایِ اعتبارداده‌شده از فعالیتِ این روز
    hops = Column(Integer, default=0)


class BpTierDef(Base):
    __tablename__ = "bp_tier_defs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    season_id = Column(Integer, nullable=False)
    tier = Column(Integer, nullable=False)
    track = Column(String, nullable=False)          # free / premium
    kind = Column(String, default="hop")
    amount = Column(Float, default=0)               # هاپ / تعدادِ استفاده / XP / تعدادِ آیتم
    pct = Column(Float, default=0)                  # درصدِ اثر
    uses = Column(Integer, default=0)               # تعدادِ دفعاتِ استفاده (۰ = نامحدود)
    minutes = Column(Integer, default=0)            # مدتِ ماندگاری بعد از فعال‌سازی (۰ = بدونِ زمان)
    label = Column(String, default="")
    __table_args__ = (UniqueConstraint("season_id", "tier", "track", name="uq_bp_tier"),)


class BpClaim(Base):
    """دریافتِ جایزه‌ی تیر؛ UniqueConstraint جلوی دابل‌کلیک/ری‌استارت رو می‌گیره."""
    __tablename__ = "bp_claims"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    season_id = Column(Integer, nullable=False)
    tier = Column(Integer, nullable=False)          # > تعدادِ تیرها = سطحِ مسترى
    track = Column(String, nullable=False)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("user_id", "season_id", "tier", "track", name="uq_bp_claim"),)


class BpChallengeDef(Base):
    __tablename__ = "bp_challenge_defs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String, nullable=False)
    metric = Column(String, nullable=False)
    target = Column(Integer, default=1)
    xp = Column(Integer, default=100)
    diff = Column(Integer, default=1)
    period = Column(String, default="daily")
    unlock_week = Column(Integer, default=0)
    min_level = Column(Integer, default=0)
    sort = Column(Integer, default=0)
    enabled = Column(Boolean, default=True)
    deleted = Column(Boolean, default=False, index=True)


class BpChClaim(Base):
    __tablename__ = "bp_ch_claims"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    season_id = Column(Integer, nullable=False)
    ch_id = Column(Integer, nullable=False)
    period_key = Column(String, nullable=False)
    xp = Column(Float, default=0)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("user_id", "ch_id", "period_key", name="uq_bp_ch_claim"),)


class BpBooster(Base):
    """بوسترِ بتل‌پس. state: stored (تو کوله) → active (فعال) → used (تموم). از هر نوع فقط یکی هم‌زمان فعاله.
    زمانی: duration_min>0 (از لحظه‌ی فعال‌سازی)، تعدادی: uses_left>0؛ هر دو هم می‌شه."""
    __tablename__ = "bp_boosters"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    season_id = Column(Integer, default=0)
    kind = Column(String, nullable=False)
    pct = Column(Float, default=0)
    uses_left = Column(Integer, nullable=True)       # None = بدونِ محدودیتِ تعداد
    duration_min = Column(Integer, default=0)
    state = Column(String, default="stored", index=True)
    activated_at = Column(DateTime, nullable=True)
    ends_at = Column(DateTime, nullable=True)
    source = Column(String, default="")
    created_at = Column(DateTime, default=now)


def init_battlepass():
    Base.metadata.create_all(db.engine)
    s = db.get_session()
    try:
        have = {c.key for c in s.query(db.Config).all()}
        for k, v in CFG_DEFAULT.items():
            if k not in have:
                s.add(db.Config(key=k, value=v))
        if "minlvl_battlepass" not in have:
            s.add(db.Config(key="minlvl_battlepass", value="0"))
        s.commit()
        db.cfg_cache_clear()
    finally:
        s.close()
    import battlepass_engine as E
    s = db.get_session()
    try:
        E.seed_challenges_once(s)
        s.commit()
    finally:
        s.close()
