# -*- coding: utf-8 -*-
"""
حدسِ عدد 🔢 - بازیِ جدیدِ کازینو هاپویی.

- تک‌نفره (vs بات): بات یه عددِ مخفی بینِ ۱ تا gtn_max_number انتخاب می‌کنه.
  بازیکن با ریپلای‌کردنِ یه عدد رو پیامِ بازی حدس می‌زنه (حداکثر gtn_max_guesses
  بار). هر حدس جوابِ «بزرگتره/کوچیک‌تره/درسته» می‌گیره و تو همون پیام، زیرِ
  حدس‌های قبلی، اضافه می‌شه (چیزی پاک نمی‌شه). اگه ظرفیتِ حدس تموم بشه و درست
  نزده باشه، مبلغِ ورودیش رو می‌بازه؛ اگه درست بزنه، ۲.۵ برابرِ مبلغِ ورودیش
  رو می‌گیره.
- دونفره: سازنده (initiator) بعدِ اینکه نفرِ دوم پیوست، تو پیویِ بات یه عددِ
  مخفی انتخاب می‌کنه؛ نفرِ دوم تو خودِ گروه حدس می‌زنه (با همون قوانینِ بالا).
  اگه حدس‌زننده درست بزنه، ۲.۵ برابرِ مبلغِ خودش می‌گیره؛ اگه نزنه، سازنده
  ۱.۵ برابرِ مبلغِ خودش رو می‌گیره.
"""
import asyncio
import datetime
import json
import re

from telegram import InlineKeyboardButton, InlineKeyboardMarkup
from telegram.error import Forbidden, BadRequest

import db
import mentions
from handlers import fmt, send_response, is_reply_to_prompt, ask_for_input
import casino

SOLO_WIN_MULTIPLIER = 2.5
DUO_GUESSER_WIN_MULTIPLIER = 2.5
DUO_SETTER_WIN_MULTIPLIER = 1.5
SETUP_ABANDON_TIMEOUT_SECONDS = 60  # اگه کاربر بازی رو بسازه ولی هیچ‌وقت «شروع» رو نزنه، بعدِ این‌همه ثانیه رها می‌شه
SOLO_GUESS_TIMEOUT_SECONDS = 60   # تک‌نفره: اگه ۶۰ ثانیه حدس نزنه، می‌بازه
DUO_GUESS_TIMEOUT_SECONDS = 80    # دونفره: اگه حدس‌زننده ۸۰ ثانیه حدس نزنه، می‌بازه و سازنده می‌بره


def _touch(r):
    r.last_action_at = datetime.datetime.utcnow()

_round_locks = {}


def _get_round_lock(round_id: int) -> asyncio.Lock:
    lock = _round_locks.get(round_id)
    if lock is None:
        lock = asyncio.Lock()
        _round_locks[round_id] = lock
    return lock


def with_round_lock(func):
    async def wrapper(update, context):
        try:
            rid = int(update.callback_query.data.split(":")[1])
        except (ValueError, IndexError, AttributeError):
            await func(update, context)
            return
        async with _get_round_lock(rid):
            await func(update, context)
        session = db.get_session()
        try:
            r = session.get(db.GuessNumberRound, rid)
            if not r or r.status in ("resolved", "cancelled"):
                _round_locks.pop(rid, None)
        finally:
            session.close()
    return wrapper


def _load(text):
    try:
        return json.loads(text) if text else []
    except (TypeError, ValueError):
        return []


def _dump(obj):
    return json.dumps(obj)


def _limits(session):
    max_number = max(2, db.cfg_get_int(session, "gtn_max_number") or 1000)
    max_guesses = max(1, db.cfg_get_int(session, "gtn_max_guesses") or 5)
    return max_number, max_guesses


async def _check_initiator(update, r):
    if not r or update.effective_user.id != r.initiator_id:
        await update.callback_query.answer("⛔️ این بازی مال تو نیست! برای ساختن بازی خودت رو دکمه‌ی «حدس عدد» بزن.", show_alert=True)
        return False
    return True


def _end_round(r, status):
    r.status = status
    r.ended_at = datetime.datetime.utcnow()


# ---------------------------------------------------------------------------
# منوی انتخابِ حالت (تک‌نفره/دونفره)
# ---------------------------------------------------------------------------

async def cb_gtn_menu(update, context):
    parts = update.callback_query.data.split(":")
    owner_id = int(parts[1]) if len(parts) > 1 else update.effective_user.id
    if update.effective_user.id != owner_id:
        await update.callback_query.answer(
            "⛔️ این منو مالِ تو نیست! برای بازکردنِ کازینوی خودت، بنویس «کازینو هاپویی».",
            show_alert=True)
        return
    text = "🔢 حدس عدد\n\nحالتِ بازی رو انتخاب کن:"
    rows = [
        [InlineKeyboardButton("👤 تک‌نفره (در برابرِ بات)", callback_data=f"gtn_new:solo:{owner_id}")],
        [InlineKeyboardButton("👥 دونفره", callback_data=f"gtn_new:duo:{owner_id}")],
    ]
    await send_response(update, text, InlineKeyboardMarkup(rows))


async def cb_gtn_new(update, context):
    parts = update.callback_query.data.split(":")
    mode = parts[1]
    owner_id = int(parts[2]) if len(parts) > 2 else None
    if owner_id is not None and update.effective_user.id != owner_id:
        await update.callback_query.answer(
            "⛔️ این منو مالِ تو نیست! برای بازکردنِ کازینوی خودت، بنویس «کازینو هاپویی».",
            show_alert=True)
        return
    session = db.get_session()
    try:
        if casino._user_has_active_round(session, update.effective_user.id):
            await update.callback_query.answer(
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, update.effective_user.id)
        if remaining > 0:
            await update.callback_query.answer(
                f"⏳ کازینوی قبلیِ این گروه تازه تموم شده. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        max_number, max_guesses = _limits(session)
        r = db.GuessNumberRound(
            chat_id=update.effective_chat.id,
            message_id=update.callback_query.message.message_id,
            mode=mode,
            initiator_id=update.effective_user.id,
            status="setup",
            max_number=max_number,
            max_guesses=max_guesses,
        )
        session.add(r)
        session.commit()
        text, kb = _render_setup(r)
        await send_response(update, text, kb)
    finally:
        session.close()


def _render_setup(r):
    amount_txt = fmt(r.entry_amount) + " 🪙" if r.entry_amount else "— تنظیم نشده —"
    mode_txt = "تک‌نفره (در برابرِ بات)" if r.mode == "solo" else "دونفره"
    text = (
        f"🔢 حدس عدد ({mode_txt})\n\n"
        f"💰 مبلغ ورودی: {amount_txt}\n"
        f"📏 بازه: ۱ تا {r.max_number} | 🎯 تعدادِ حدس: {r.max_guesses}\n\n"
        + ("بعدِ انتخابِ مبلغ، بات یه عددِ مخفی انتخاب می‌کنه و می‌تونی شروع کنی."
           if r.mode == "solo" else
           "بعدِ انتخابِ مبلغ، تو گروه لابی می‌شه؛ یه نفرِ دیگه باید بپیونده تا حدس بزنه. "
           "تو (سازنده) بعدش تو پیویِ بات عددِ مخفی رو انتخاب می‌کنی.")
    )
    rows = [[InlineKeyboardButton("💰 انتخاب مبلغ ورودی", callback_data=f"gtn_amt_menu:{r.id}")]]
    if r.entry_amount:
        rows.append([InlineKeyboardButton("▶️ شروع بازی", callback_data=f"gtn_start:{r.id}")])
    rows.append([InlineKeyboardButton("🔙 بازگشت (تغییرِ نوعِ بازی)", callback_data=f"gtn_back_to_types:{r.id}"),
                 InlineKeyboardButton("❌ لغو", callback_data=f"gtn_cancel:{r.id}")])
    return text, InlineKeyboardMarkup(rows)


async def cb_gtn_back_to_types(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.GuessNumberRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه تو مرحله‌ی تنظیمات نیست.", show_alert=True)
            return
        _end_round(r, "cancelled")
        session.commit()
        text, kb = casino.menu_text_and_kb(r.initiator_id)
        await send_response(update, text, kb)
    finally:
        session.close()


async def cb_gtn_cancel(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.GuessNumberRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status not in ("setup", "lobby"):
            await update.callback_query.answer("⛔️ این بازی دیگه قابلِ لغو نیست.", show_alert=True)
            return
        # پولِ سازنده (initiator) فقط تو cb_gtn_start کم می‌شه - پس اگه هنوز تو
        # setup هستیم، چیزی برای برگردوندن نیست. اگه به لابی رسیده باشیم،
        # سازنده حتماً پرداخت کرده (تو start) و شاید حدس‌زننده هم پیوسته باشه.
        if r.entry_amount:
            u = session.get(db.User, r.initiator_id)
            if u and r.status == "lobby":
                u.hop_points += r.entry_amount
            if r.guesser_id:
                u2 = session.get(db.User, r.guesser_id)
                if u2:
                    u2.hop_points += r.entry_amount
        _end_round(r, "cancelled")
        session.commit()
        await send_response(update, "❌ بازی لغو شد.", None)
    finally:
        session.close()


async def cb_gtn_amt_menu(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.GuessNumberRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        rows = [[InlineKeyboardButton(f"{a:,}", callback_data=f"gtn_amt_pick:{rid}:{a}")] for a in casino._preset_amounts(session)]
        rows.append([InlineKeyboardButton("✏️ مبلغِ دلخواه", callback_data=f"gtn_amt_custom:{rid}")])
        rows.append([InlineKeyboardButton("🔙 بازگشت", callback_data=f"gtn_back:{rid}")])
        await send_response(update, "💰 مبلغِ ورودی رو انتخاب کن:", InlineKeyboardMarkup(rows))
    finally:
        session.close()


async def cb_gtn_amt_pick(update, context):
    _, rid, amount = update.callback_query.data.split(":")
    rid, amount = int(rid), float(amount)
    session = db.get_session()
    try:
        r = session.get(db.GuessNumberRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if casino.max_bet_exceeded(session, amount):
            await update.callback_query.answer(
                f"⛔️ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست.", show_alert=True)
            return
        r.entry_amount = amount
        session.commit()
        text, kb = _render_setup(r)
        await send_response(update, text, kb)
    finally:
        session.close()


async def cb_gtn_amt_custom(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.GuessNumberRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
    finally:
        session.close()
    await ask_for_input(update, context, "✏️ مبلغ ورودیِ دلخواه رو به عدد بفرست:", {"type": "amount", "round_id": rid}, "gtn_awaiting")


async def cb_gtn_back(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.GuessNumberRound, rid)
        if not await _check_initiator(update, r):
            return
        text, kb = _render_setup(r)
        await send_response(update, text, kb)
    finally:
        session.close()


async def gtn_awaiting_handler(update, context):
    from handlers import parse_amount
    state = context.user_data.get("gtn_awaiting")
    if not state:
        return
    if not is_reply_to_prompt(update, state):
        return
    context.user_data.pop("gtn_awaiting", None)
    rid = state["round_id"]
    amount = parse_amount(update.message.text or "")
    if amount is None or amount <= 0:
        await update.message.reply_text("❌ مقدار نامعتبره؛ عملیات لغو شد.")
        from telegram.ext import ApplicationHandlerStop
        raise ApplicationHandlerStop
    session = db.get_session()
    try:
        r = session.get(db.GuessNumberRound, rid)
        if not r or r.status != "setup" or update.effective_user.id != r.initiator_id:
            await update.message.reply_text("این بازی دیگه فعال نیست.")
            raise ApplicationHandlerStop
        if casino.max_bet_exceeded(session, amount):
            await update.message.reply_text(f"❌ حداکثر مبلغِ مجازِ قمار {fmt(casino._max_bet_limit(session))} 🪙 هست؛ عملیات لغو شد.")
            raise ApplicationHandlerStop
        r.entry_amount = amount
        session.commit()
        # همون فیکسِ battleship.bship_awaiting_handler: باید پیامِ اصلیِ بازی
        # (message_id) رو ادیت کنیم، نه یه پیامِ جدید بفرستیم.
        text, kb = _render_setup(r)
        try:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.message_id, text=text, reply_markup=kb)
        except Exception:
            msg = await update.message.reply_text(text, reply_markup=kb)
            r.message_id = msg.message_id
            session.commit()
    finally:
        session.close()
    from telegram.ext import ApplicationHandlerStop
    raise ApplicationHandlerStop


# ---------------------------------------------------------------------------
# شروع بازی
# ---------------------------------------------------------------------------

@with_round_lock
async def cb_gtn_start(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.GuessNumberRound, rid)
        if not await _check_initiator(update, r):
            return
        if r.status != "setup":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        if not r.entry_amount:
            await update.callback_query.answer("اول باید مبلغِ ورودی رو انتخاب کنی.", show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await update.callback_query.answer(f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount

        if r.mode == "solo":
            import random
            r.secret_number = random.randint(1, r.max_number)
            r.setter_id = None
            r.guesser_id = r.initiator_id
            r.status = "guessing"
            _touch(r)
            session.commit()
            text = _guess_status_text(r)
            msg = await send_response(update, text, None)
            if msg:
                r.message_id = msg.message_id
                session.commit()
        else:
            r.status = "lobby"
            r.lobby_opened_at = datetime.datetime.utcnow()
            session.commit()
            text = (
                f"🔢 حدس عدد (دونفره)\n\n"
                f"💰 مبلغ ورودی: {fmt(r.entry_amount)} 🪙\n"
                f"👤 سازنده (عددگذار): {mentions.of(update.effective_user)}\n\n"
                f"⏳ منتظرِ پیوستنِ نفرِ حدس‌زننده..."
            )
            rows = [
                [InlineKeyboardButton("🔢 پیوستن (حدس بزن)", callback_data=f"gtn_join:{rid}")],
                [InlineKeyboardButton("❌ لغو", callback_data=f"gtn_cancel:{rid}")],
            ]
            await send_response(update, text, InlineKeyboardMarkup(rows))
    finally:
        session.close()


@with_round_lock
async def cb_gtn_join(update, context):
    rid = int(update.callback_query.data.split(":")[1])
    session = db.get_session()
    try:
        r = session.get(db.GuessNumberRound, rid)
        if not r or r.status != "lobby":
            await update.callback_query.answer("⛔️ این بازی دیگه فعال نیست.", show_alert=True)
            return
        uid = update.effective_user.id
        if uid == r.initiator_id:
            await update.callback_query.answer("⛔️ نمی‌تونی با خودت بازی کنی!", show_alert=True)
            return
        if casino._user_has_active_round(session, uid):
            await update.callback_query.answer(
                "⛔️ تو همین الان یه بازیِ کازینوییِ نیمه‌کاره داری! اول اونو تموم یا لغو کن.",
                show_alert=True)
            return
        remaining = await casino._casino_cooldown_remaining_seconds(session, uid)
        if remaining > 0:
            await update.callback_query.answer(
                f"⏳ خودت تازه یه کازینو تموم کردی. تا {casino._format_cooldown_wait(remaining)}ی دیگه صبر کن.",
                show_alert=True)
            return
        user = db.get_or_create_user(session, update.effective_user)
        if user.hop_points < r.entry_amount - 0.5:
            await update.callback_query.answer(f"موجودی کافی نیست! ({fmt(user.hop_points)} 🪙 داری)", show_alert=True)
            return
        user.hop_points -= r.entry_amount
        r.guesser_id = uid
        r.setter_id = r.initiator_id
        r.status = "setting_number"
        session.commit()
        await update.callback_query.answer("✅ پیوستی!")
        await _ask_setter_for_number(context, session, r)
    finally:
        session.close()


async def _ask_setter_for_number(context, session, r):
    text = (
        f"🔢 حدسِ عدد\n\n"
        f"نفرِ دومت پیوست! حالا تو (سازنده) باید یه عددِ مخفی بینِ ۱ تا {r.max_number} انتخاب کنی.\n"
        "این عدد رو تو همین پیوی برام بفرست."
    )
    try:
        await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.message_id,
                                             text="🔢 حدسِ عدد\n\n⏳ سازنده داره تو پیویِ بات عددِ مخفی رو انتخاب می‌کنه...")
    except Exception:
        pass
    try:
        msg = await context.bot.send_message(r.setter_id, text)
        r.setter_dm_message_id = msg.message_id
        session.commit()
    except (Forbidden, BadRequest):
        u = session.get(db.User, r.guesser_id)
        if u and r.entry_amount:
            u.hop_points += r.entry_amount
        u2 = session.get(db.User, r.setter_id)
        if u2 and r.entry_amount:
            u2.hop_points += r.entry_amount
        _end_round(r, "cancelled")
        session.commit()
        try:
            await context.bot.edit_message_text(
                chat_id=r.chat_id, message_id=r.message_id,
                text="❌ بازیِ «حدسِ عدد» لغو شد چون نمی‌تونم به پیویِ سازنده پیام بدم "
                     "(باید اول یه‌بار تو پیویِ بات «استارت» بزنه). پول‌ها برگشت داده شد.")
        except Exception:
            pass


NUMBER_RE = re.compile(r"^\s*(\d+)\s*$")


async def handle_setter_number_dm(update, context):
    """پیامِ متنیِ عددِ مخفی که سازنده تو پیویِ بات می‌فرسته."""
    m = NUMBER_RE.match(update.message.text or "")
    if not m:
        return False
    session = db.get_session()
    try:
        r = (
            session.query(db.GuessNumberRound)
            .filter(
                db.GuessNumberRound.status == "setting_number",
                db.GuessNumberRound.setter_id == update.effective_user.id,
            )
            .order_by(db.GuessNumberRound.id.desc())
            .first()
        )
        if not r:
            return False
        n = int(m.group(1))
        if not (1 <= n <= r.max_number):
            await update.message.reply_text(f"❌ باید بینِ ۱ تا {r.max_number} باشه. دوباره بفرست:")
            return True
        r.secret_number = n
        r.status = "guessing"
        _touch(r)
        session.commit()
        await update.message.reply_text("✅ ثبت شد! الان نفرِ حدس‌زننده تو گروه شروع می‌کنه.")
        text = _guess_status_text(r)
        try:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.message_id, text=text)
        except Exception:
            pass
        return True
    finally:
        session.close()


# ---------------------------------------------------------------------------
# فازِ حدس‌زدن (تو گروه، با ریپلای متنی)
# ---------------------------------------------------------------------------

def _guess_status_text(r):
    guesses = _load(r.guesses)
    lines = [
        "🔢 حدسِ عدد" + (" (تک‌نفره - در برابرِ بات)" if r.mode == "solo" else " (دونفره)"),
        "",
        f"📏 بازه: ۱ تا {r.max_number} | 🎯 حدس‌های باقی‌مونده: {r.max_guesses - len(guesses)}/{r.max_guesses}",
        "",
    ]
    if guesses:
        for num, result in guesses:
            icon = {"bigger": "🔼", "smaller": "🔽", "correct": "✅"}.get(result, "•")
            label = {"bigger": "بزرگتره", "smaller": "کوچیک‌تره", "correct": "درسته!"}.get(result, result)
            lines.append(f"{icon} {num} → {label}")
        lines.append("")
    lines.append("یه عدد به‌عنوانِ حدس بفرست (لازم نیست ریپلای باشه، کافیه همین‌جا تو گروه بفرستی).")
    return "\n".join(lines)


async def handle_guess_text(update, context):
    """پیامِ متنیِ حدسِ عدد تو خودِ گروه. فقط وقتی اثر می‌کنه که تو همین چت یه
    GuessNumberRound با status=guessing باز باشه و فرستنده همون guesser_id
    باشه - برای جلوگیری از قاطی‌شدن با پیام‌های عادیِ عددی."""
    m = NUMBER_RE.match(update.message.text or "")
    if not m:
        return False
    session = db.get_session()
    try:
        r = (
            session.query(db.GuessNumberRound)
            .filter(
                db.GuessNumberRound.chat_id == update.effective_chat.id,
                db.GuessNumberRound.status == "guessing",
                db.GuessNumberRound.guesser_id == update.effective_user.id,
            )
            .order_by(db.GuessNumberRound.id.desc())
            .first()
        )
        if not r:
            return False
        async with _get_round_lock(r.id):
            session.refresh(r)
            if r.status != "guessing":
                return True
            n = int(m.group(1))
            if not (1 <= n <= r.max_number):
                await update.message.reply_text(f"❌ باید بینِ ۱ تا {r.max_number} باشه.")
                return True
            guesses = _load(r.guesses)
            if len(guesses) >= r.max_guesses:
                return True  # دیگه فرصتی نمونده - چیزی نگو، بازی داره resolve می‌شه
            if n == r.secret_number:
                guesses.append([n, "correct"])
                r.guesses = _dump(guesses)
                _touch(r)
                session.commit()
                await _resolve_win(context, session, r)
                return True
            result = "bigger" if n < r.secret_number else "smaller"
            guesses.append([n, result])
            r.guesses = _dump(guesses)
            exhausted = len(guesses) >= r.max_guesses
            _touch(r)
            session.commit()
            if exhausted:
                await _resolve_loss(context, session, r)
            else:
                text = _guess_status_text(r)
                try:
                    if r.message_id:
                        await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.message_id, text=text)
                    else:
                        await update.message.reply_text(text)
                except Exception:
                    await update.message.reply_text(text)
        return True
    finally:
        session.close()


async def _resolve_win(context, session, r):
    guesser = session.get(db.User, r.guesser_id)
    payout = (r.entry_amount or 0) * (DUO_GUESSER_WIN_MULTIPLIER if r.mode == "duo" else SOLO_WIN_MULTIPLIER)
    if guesser:
        guesser.hop_points += payout
    _end_round(r, "resolved")
    session.commit()
    guesser_label = guesser.display_name() if guesser else str(r.guesser_id)
    text = _guess_status_text(r) + f"\n\n🏆 {guesser_label} درست حدس زد و {fmt(payout)} 🪙 برد!"
    try:
        if r.message_id:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.message_id, text=text)
        else:
            await context.bot.send_message(r.chat_id, text)
    except Exception:
        pass


async def _resolve_loss(context, session, r):
    _end_round(r, "resolved")
    if r.mode == "solo":
        text = _guess_status_text(r) + f"\n\n😔 حدس‌هات تموم شد! عددِ مخفی {r.secret_number} بود. مبلغِ ورودیت رفت."
    else:
        setter = session.get(db.User, r.setter_id)
        payout = (r.entry_amount or 0) * DUO_SETTER_WIN_MULTIPLIER
        if setter:
            setter.hop_points += payout
        setter_label = setter.display_name() if setter else str(r.setter_id)
        text = (
            _guess_status_text(r)
            + f"\n\n😔 حدس‌ها تموم شد! عددِ مخفی {r.secret_number} بود.\n"
            f"🏆 {setter_label} (سازنده) {fmt(payout)} 🪙 گرفت!"
        )
    session.commit()
    try:
        if r.message_id:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.message_id, text=text)
        else:
            await context.bot.send_message(r.chat_id, text)
    except Exception:
        pass


async def _resolve_timeout_forfeit(context, session, r):
    """اگه تو فازِ guessing کسی که باید حدس می‌زد (تک‌نفره: خودِ بازیکن،
    دونفره: حدس‌زننده) بیش‌ازحد صبر نکنه، می‌بازه - نه اینکه فقط لغو/برگشتِ
    پول بشه. برای دونفره، سازنده (که منتظر مونده) برنده می‌شه و ۱.۵ برابرِ
    مبلغِ خودش رو می‌گیره (دقیقاً مثلِ باختنِ عادی)."""
    _end_round(r, "resolved")
    if r.mode == "solo":
        text = _guess_status_text(r) + "\n\n⏳ به‌خاطرِ تاخیر (بیش‌ازحد صبر شد) باختی! مبلغِ ورودیت رفت."
    else:
        setter = session.get(db.User, r.setter_id)
        payout = (r.entry_amount or 0) * DUO_SETTER_WIN_MULTIPLIER
        if setter:
            setter.hop_points += payout
        setter_label = setter.display_name() if setter else str(r.setter_id)
        text = (
            _guess_status_text(r)
            + f"\n\n⏳ حدس‌زننده به‌خاطرِ تاخیر باخت (بیش‌ازحد صبر کرد و حدس نزد)!\n"
            f"🏆 {setter_label} (سازنده) {fmt(payout)} 🪙 گرفت!"
        )
    session.commit()
    try:
        if r.message_id:
            await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.message_id, text=text)
        else:
            await context.bot.send_message(r.chat_id, text)
    except Exception:
        pass


# ---------------------------------------------------------------------------
# جاروبِ تایم‌اوت
# ---------------------------------------------------------------------------

async def sweep_timeouts(context):
    """لابیِ رهاشده (کسی برای حدس‌زدن نپیوسته)، سازنده‌ای که هیچ‌وقت عددِ
    مخفی رو تو پیوی نفرستاده، خودِ مرحله‌ی setup (بازیِ ساخته‌شده ولی هیچ‌وقت
    شروع نشده)، و همچنین خودِ فازِ guessing (اگه حدس‌زننده بیش‌ازحد صبر کنه و
    حدس نزنه، می‌بازه - نه صرفاً لغو/برگشتِ پول) رو مدیریت می‌کنه."""
    session = db.get_session()
    try:
        now = datetime.datetime.utcnow()
        timeout = casino._timeout_seconds(session)
        stale = (
            session.query(db.GuessNumberRound)
            .filter(db.GuessNumberRound.status.in_(("setup", "lobby", "setting_number")))
            .all()
        )
        changed = False
        for r in stale:
            if r.status == "setup":
                ref_time, limit = r.created_at, SETUP_ABANDON_TIMEOUT_SECONDS
            else:
                ref_time, limit = (r.lobby_opened_at or r.created_at), timeout
            if not ref_time or (now - ref_time).total_seconds() < limit:
                continue
            for uid in (r.initiator_id, r.guesser_id):
                if not uid:
                    continue
                u = session.get(db.User, uid)
                if u and r.entry_amount:
                    u.hop_points += r.entry_amount
            _end_round(r, "cancelled")
            changed = True
            text = "⏳ بازیِ «حدسِ عدد» به‌خاطرِ عدمِ فعالیت لغو شد. پول‌ها برگشت داده شد."
            try:
                if r.message_id:
                    await context.bot.edit_message_text(chat_id=r.chat_id, message_id=r.message_id, text=text)
            except Exception:
                pass
            if r.setter_id:
                try:
                    await context.bot.send_message(r.setter_id, text)
                except Exception:
                    pass
        if changed:
            session.commit()

        # فازِ guessing: تایم‌اوت = باخت، نه لغو
        guessing_stale = session.query(db.GuessNumberRound).filter(db.GuessNumberRound.status == "guessing").all()
        for r in guessing_stale:
            limit = SOLO_GUESS_TIMEOUT_SECONDS if r.mode == "solo" else DUO_GUESS_TIMEOUT_SECONDS
            ref_time = r.last_action_at or r.created_at
            if not ref_time or (now - ref_time).total_seconds() < limit:
                continue
            async with _get_round_lock(r.id):
                session.refresh(r)
                if r.status != "guessing":
                    continue
                await _resolve_timeout_forfeit(context, session, r)
    finally:
        session.close()


# ---------------------------------------------------------------------------
# مسیریابی
# ---------------------------------------------------------------------------

GTN_PREFIX_MAP = {
    "gtn_menu": cb_gtn_menu,
    "gtn_new": cb_gtn_new,
    "gtn_back_to_types": cb_gtn_back_to_types,
    "gtn_cancel": cb_gtn_cancel,
    "gtn_amt_menu": cb_gtn_amt_menu,
    "gtn_amt_pick": cb_gtn_amt_pick,
    "gtn_amt_custom": cb_gtn_amt_custom,
    "gtn_back": cb_gtn_back,
    "gtn_start": cb_gtn_start,
    "gtn_join": cb_gtn_join,
}


async def gtn_callback_router(update, context) -> bool:
    data = update.callback_query.data or ""
    prefix = data.split(":")[0]
    handler = GTN_PREFIX_MAP.get(prefix)
    if handler:
        await handler(update, context)
        return True
    return False
