# -*- coding: utf-8 -*-
"""
💾 سیو / بازیابی / لغو سیوِ اکانت روی جیمیل

- سیو: کاربر ایمیلِ جیمیلش رو می‌ده ← کدِ ۶ رقمی به ایمیل می‌ره ← ۱۸۰ ثانیه وقت داره وارد کنه ←
  اگه درست بود اکانت روی اون ایمیل سیو می‌شه. یه ایمیل فقط به یه اکانت وصل می‌شه
  («این ایمیل در حال حاضر به حساب دیگری متصل است»).
- لغو سیو: کدِ تایید به ایمیلِ فعلیِ اکانت می‌ره؛ درست وارد بشه ایمیل از اکانت جدا می‌شه.
- بازیابی: تو اکانتِ جدید ایمیل رو می‌زنه ← کد ← درست بود ← کلِ دیتای اکانتِ قدیمی (همه‌ی جدول‌ها)
  به اکانتِ جدید منتقل می‌شه (بدونِ هیچ بازیابیِ جداگونه‌ی دیتابیس؛ همه‌چیز تو یه تراکنش).
- امنیت: برای هر آیدی در ۲۴ ساعت حداکثر ۵ کد؛ برای هر ایمیل هم همین (تا کسی نتونه به یه ایمیل اسپم
  بفرسته)؛ هر کد حداکثر ۵ حدسِ غلط؛ کد فقط هَشش ذخیره می‌شه.

تنظیماتِ ایمیل (Gmail API، نه SMTP): GMAIL_TOKEN_PATH (مسیرِ token.json که با get_token.py ساختی)،
اختیاری: GMAIL_SENDER (برایِ هدرِ From؛ پیش‌فرض همون جیمیلی که token بهش تعلق داره)، GMAIL_CREDENTIALS_PATH
(مسیرِ credentials.json؛ فقط برایِ refresh اگه لازم بشه).
"""
import asyncio
import base64
import datetime
import hashlib
import hmac
import logging
import os
import re
import secrets
from email.message import EmailMessage

from google.auth.transport.requests import Request as GoogleAuthRequest
from google.oauth2.credentials import Credentials as GoogleCredentials
from googleapiclient.discovery import build as gmail_build
from googleapiclient.errors import HttpError as GmailHttpError

from sqlalchemy import BigInteger, Column, DateTime, Integer, String, text
from sqlalchemy.exc import IntegrityError
from telegram import InlineKeyboardButton as Btn, InlineKeyboardMarkup as Kb
from telegram.ext import ApplicationHandlerStop

import config
import db
from db import Base

logger = logging.getLogger(__name__)

CODE_TTL_SECONDS = 180
MAX_CODES_PER_DAY = 5
MAX_WRONG_ATTEMPTS = 5
WINDOW = datetime.timedelta(hours=24)

LIMIT_TEXT = "⛔️ شما محدود شدید؛ ۲۴ ساعت صبر کنید."
LINKED_ELSEWHERE_TEXT = "⛔️ این ایمیل در حال حاضر به حساب دیگری متصل است."
STATE_KEY = "acct_awaiting"

ALLOWED_DOMAINS = ("gmail.com", "googlemail.com")
_EMAIL_RE = re.compile(r"^[a-z0-9._+\-]{1,64}@([a-z0-9\-]+(?:\.[a-z0-9\-]+)+)$")


# ---------------------------------------------------------------------------
# جدول‌ها (با db.init_db / account_backup.init_backup ساخته می‌شن؛ جدولِ قدیمی ALTER نمی‌شه)
# ---------------------------------------------------------------------------
class AccountEmail(Base):
    """ایمیلِ سیوشده‌ی هر اکانت. هر اکانت حداکثر یه ایمیل، هر ایمیل حداکثر یه اکانت."""
    __tablename__ = "account_emails"
    user_id = Column(BigInteger, primary_key=True)
    email_norm = Column(String, nullable=False, unique=True)   # جیمیلِ نرمال‌شده (بدونِ نقطه/+tag)
    email_display = Column(String, nullable=False)             # همون که کاربر زده (برایِ ارسالِ کد)
    linked_at = Column(DateTime, default=datetime.datetime.utcnow)


class EmailCode(Base):
    __tablename__ = "email_codes"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)     # کسی که کد رو خواسته
    email_norm = Column(String, nullable=False, index=True)
    purpose = Column(String, nullable=False)                      # link / unlink / restore
    code_hash = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow, index=True)
    expires_at = Column(DateTime, nullable=False)
    attempts = Column(Integer, default=0)
    status = Column(String, default="pending")   # pending / used / verified / expired / failed / replaced / send_failed


class AccountMigrationSnapshot(Base):
    """نسخه‌ی پشتیبانِ کاملِ دیتای دو اکانت، قبل از هر بازیابی (برای بازگردانیِ دستی اگه لازم شد)."""
    __tablename__ = "account_migration_snapshots"
    id = Column(Integer, primary_key=True, autoincrement=True)
    created_at = Column(DateTime, default=datetime.datetime.utcnow, index=True)
    old_id = Column(BigInteger, nullable=False)
    new_id = Column(BigInteger, nullable=False)
    payload = Column(String, nullable=False)   # JSON: {table: [row, ...]}


def init_backup():
    Base.metadata.create_all(db.engine, tables=[AccountEmail.__table__, EmailCode.__table__,
                                                AccountMigrationSnapshot.__table__])


# ---------------------------------------------------------------------------
# ابزارهای ایمیل/کد
# ---------------------------------------------------------------------------
def _utcnow():
    return datetime.datetime.utcnow()


def normalize_email(raw):
    """(نرمال, نمایشی) یا (None, None). فقط جیمیل؛ نقطه‌ها و بخشِ +tag حذف می‌شن چون جیمیل
    همه‌ی اون شکل‌ها رو یه صندوق می‌دونه (جلویِ دورزدنِ «یه ایمیل = یه اکانت»)."""
    s = (raw or "").strip().lower()
    m = _EMAIL_RE.match(s)
    if not m:
        return None, None
    local, domain = s.split("@", 1)
    if domain not in ALLOWED_DOMAINS:
        return None, None
    base = local.split("+", 1)[0].replace(".", "")
    if not base:
        return None, None
    return f"{base}@gmail.com", s


def mask_email(email):
    local, _, domain = (email or "").partition("@")
    return (local[:1] + "***@" + domain) if local else "***"


def _secret():
    return (config.BOT_TOKEN or "x").encode()


def hash_code(code: str, email_norm: str, user_id: int) -> str:
    msg = f"{code}|{email_norm}|{user_id}".encode()
    return hmac.new(_secret(), msg, hashlib.sha256).hexdigest()


def new_code() -> str:
    return f"{secrets.randbelow(1_000_000):06d}"


GMAIL_SCOPES = ["https://www.googleapis.com/auth/gmail.send"]
_gmail_service = None  # کش می‌شه بعدِ اولین ساخت؛ هر بار کلاینتِ جدید نمی‌سازیم


def smtp_configured() -> bool:
    """اسمش به دلایلِ تاریخی smtp ـه؛ الان چک می‌کنه token.json برایِ Gmail API موجوده یا نه."""
    return os.path.exists(getattr(config, "GMAIL_TOKEN_PATH", ""))


def _load_gmail_creds() -> GoogleCredentials:
    token_path = config.GMAIL_TOKEN_PATH
    creds = GoogleCredentials.from_authorized_user_file(token_path, GMAIL_SCOPES)
    if creds.expired and creds.refresh_token:
        creds.refresh(GoogleAuthRequest())
        with open(token_path, "w") as f:
            f.write(creds.to_json())
    return creds


def _gmail_client():
    global _gmail_service
    if _gmail_service is None:
        creds = _load_gmail_creds()
        _gmail_service = gmail_build("gmail", "v1", credentials=creds, cache_discovery=False)
    return _gmail_service


_PURPOSE_INFO = {
    "link": ("💾", "سیو اکانت", "سیو کردنِ اکانتت روی این ایمیل"),
    "unlink": ("🗑", "لغو سیو اکانت", "جدا کردنِ این ایمیل از اکانتت (لغو سیو)"),
    "restore": ("♻️", "بازیابی اکانت", "بازیابیِ اکانتِ قبلیت روی این تلگرام"),
}


def _build_email_bodies(code: str, purpose: str):
    emoji, title, desc = _PURPOSE_INFO.get(purpose, ("🔐", "تایید", "تاییدِ هویتت"))
    minutes = CODE_TTL_SECONDS // 60
    text_body = (
        "🔐 کد ورود به حساب بات هاپویی تلگرام\n"
        "━━━━━━━━━━━━━━━━━━\n\n"
        f"🔢 کد تایید:  {code}\n\n"
        f"{emoji} این کد برای: {desc}\n"
        f"⏳ اعتبار: {minutes} دقیقه\n\n"
        "⚠️ این کد را به هیچ‌کس ندهید!\n"
        "اگه خودت درخواستش ندادی، این پیام رو نادیده بگیر.\n\n"
        "🎮 بات هاپویی"
    )
    html_body = f"""<!DOCTYPE html>
<html dir="rtl" lang="fa"><body style="margin:0;padding:16px;background:#f2f4f8;font-family:Tahoma,Arial,sans-serif;">
<div style="max-width:420px;margin:0 auto;background:#ffffff;border-radius:16px;padding:24px;text-align:center;direction:rtl;">
  <div style="font-size:42px;">🔐</div>
  <h2 style="margin:8px 0 4px;color:#1a1a2e;font-size:18px;">کد ورود به حساب بات هاپویی تلگرام</h2>
  <p style="margin:0 0 18px;color:#666;font-size:14px;">{emoji} {desc}</p>
  <div style="background:#eef2ff;border:2px dashed #6366f1;border-radius:12px;padding:16px;margin:0 0 18px;">
    <div style="font-size:12px;color:#6366f1;margin-bottom:6px;">🔢 کد تایید</div>
    <div dir="ltr" style="font-size:36px;font-weight:bold;letter-spacing:8px;color:#1a1a2e;">{code}</div>
  </div>
  <p style="margin:0 0 6px;color:#444;font-size:14px;">⏳ این کد تا <b>{minutes} دقیقه</b> اعتبار داره.</p>
  <p style="margin:0 0 6px;color:#d93025;font-size:15px;font-weight:bold;">⚠️ این کد را به هیچ‌کس ندهید!</p>
  <p style="margin:12px 0 0;color:#888;font-size:12px;">اگه خودت درخواستش ندادی، این پیام رو نادیده بگیر.</p>
  <p style="margin:16px 0 0;color:#aaa;font-size:12px;">🎮 بات هاپویی</p>
</div></body></html>"""
    return title, text_body, html_body


def _send_email_sync(to_addr: str, code: str, purpose: str):
    title, text_body, html_body = _build_email_bodies(code, purpose)
    msg = EmailMessage()
    msg["Subject"] = f"🔐 کد ورود به حساب بات هاپویی تلگرام — {title}"
    msg["From"] = getattr(config, "GMAIL_SENDER", "") or "me"
    msg["To"] = to_addr
    msg.set_content(text_body)
    msg.add_alternative(html_body, subtype="html")
    raw = base64.urlsafe_b64encode(msg.as_bytes()).decode()
    service = _gmail_client()
    service.users().messages().send(userId="me", body={"raw": raw}).execute()


async def _send_email(to_addr, code, purpose) -> bool:
    try:
        await asyncio.to_thread(_send_email_sync, to_addr, code, purpose)
        return True
    except Exception:
        logger.exception("ارسالِ ایمیلِ کد شکست خورد")
        return False


# ---------------------------------------------------------------------------
# لیمیتِ کد
# ---------------------------------------------------------------------------
def _codes_sent(session, *, user_id=None, email_norm=None) -> int:
    q = session.query(EmailCode).filter(
        EmailCode.created_at > _utcnow() - WINDOW,
        EmailCode.status != "send_failed",
    )
    if user_id is not None:
        q = q.filter(EmailCode.user_id == user_id)
    if email_norm is not None:
        q = q.filter(EmailCode.email_norm == email_norm)
    return q.count()


def is_rate_limited(session, user_id, email_norm) -> bool:
    return (_codes_sent(session, user_id=user_id) >= MAX_CODES_PER_DAY
            or _codes_sent(session, email_norm=email_norm) >= MAX_CODES_PER_DAY)


async def issue_code(session, user_id, email_norm, email_display, purpose):
    """(code_id, None) یا (None, پیامِ خطا). حدِ مجاز قبلِ ارسال چک می‌شه؛ اگه ارسال شکست بخوره
    از سهمیه کم نمی‌شه."""
    if not smtp_configured():
        return None, "⚠️ ارسالِ ایمیل هنوز تنظیم نشده؛ به مالکِ ربات بگو."
    if is_rate_limited(session, user_id, email_norm):
        return None, LIMIT_TEXT
    for old in session.query(EmailCode).filter_by(user_id=user_id, status="pending").all():
        old.status = "replaced"
    code = new_code()
    now = _utcnow()
    row = EmailCode(user_id=user_id, email_norm=email_norm, purpose=purpose,
                    code_hash=hash_code(code, email_norm, user_id), created_at=now,
                    expires_at=now + datetime.timedelta(seconds=CODE_TTL_SECONDS), attempts=0, status="pending")
    session.add(row)
    session.commit()
    rid = row.id
    ok = await _send_email(email_display, code, purpose)
    if not ok:
        row = session.get(EmailCode, rid)
        if row:
            row.status = "send_failed"
            session.commit()
        return None, "⚠️ ارسالِ ایمیل شکست خورد؛ چند دقیقه‌ی دیگه دوباره امتحان کن."
    return rid, None


def check_code(session, code_id, user_id, typed):
    """(ok, پیام). فقط روی کدِ pending و مالِ همین کاربر کار می‌کنه."""
    row = session.get(EmailCode, code_id)
    if not row or row.user_id != user_id or row.status != "pending":
        return False, "⛔️ این کد دیگه معتبر نیست؛ دوباره درخواست بده."
    if _utcnow() > row.expires_at:
        row.status = "expired"
        session.commit()
        return False, "⌛️ مهلتِ ۱۸۰ ثانیه تموم شد؛ دوباره درخواست بده."
    typed = re.sub(r"\D", "", typed or "")
    if not hmac.compare_digest(hash_code(typed, row.email_norm, user_id), row.code_hash):
        row.attempts = (row.attempts or 0) + 1
        if row.attempts >= MAX_WRONG_ATTEMPTS:
            row.status = "failed"
            session.commit()
            return False, "⛔️ بیش از حد کدِ اشتباه زدی؛ این کد باطل شد. دوباره درخواست بده."
        session.commit()
        return False, f"❌ کد اشتباهه. ({MAX_WRONG_ATTEMPTS - row.attempts} تلاشِ دیگه)"
    return True, ""


# ---------------------------------------------------------------------------
# انتقالِ کاملِ اکانت (بازیابی)
# ---------------------------------------------------------------------------
# ستون‌هایی که آیدیِ تلگرامِ یه کاربر توشونه (به‌جز جدولِ users که جدا مدیریت می‌شه).
USER_COLS = {
    "user_id", "owner_user_id", "attacker_id", "victim_id", "target_id", "buyer_id", "seller_id",
    "initiator_id", "player1_id", "player2_id", "turn_user_id", "night_target_id", "day_vote_id",
    "setter_id", "guesser_id", "host_id", "guest_id", "winner_id", "leader_id", "old_leader_id",
    "defender_id", "requester_id", "decided_by", "actor_id", "chef_user_id", "voter_user_id",
    "reporter_id", "reported_user_id",
}
# users: جدا؛ admin_users: دسترسیِ ادمین با ایمیل منتقل نمی‌شه؛ ایمیل/کدها: خودمون مدیریت می‌کنیم
SKIP_TABLES = {"users", "admin_users", "account_emails", "email_codes"}
# جدول‌هایِ «موجودی/وضعیتِ» هر اکانت: دیتای اکانتِ جدید کاملاً با دیتای قدیمی «جایگزین» می‌شه (نه ادغام؛ وگرنه
# مثلاً دو ردیفِ ارز برایِ یه کاربر می‌ماند). لاگ‌ها/بدهی‌ها اینجا نیستن و ادغام می‌شن (بدهی با بازیابی پاک نشه).
REPLACE_TABLES = {
    "user_currencies", "user_products", "user_cards", "user_card_tokens", "user_card_progress",
    "user_phones", "inventory_items", "active_boosters", "smuggling_helper_trust", "smuggling_user_helpers",
}


def _user_col_plan():
    """[(table, [user_cols], [cols_in_unique_or_pk])] از رویِ متادیتای واقعیِ همه‌ی جدول‌ها."""
    plan = []
    for table in Base.metadata.sorted_tables:
        if table.name in SKIP_TABLES:
            continue
        cols = [c.name for c in table.columns if c.name in USER_COLS]
        if not cols:
            continue
        unique_cols = {c.name for c in table.primary_key.columns}
        if table.name in REPLACE_TABLES and "user_id" in cols:
            unique_cols.add("user_id")
        for c in table.columns:
            if c.unique:
                unique_cols.add(c.name)
        for cons in table.constraints:
            if cons.__class__.__name__ == "UniqueConstraint":
                unique_cols.update(c.name for c in cons.columns)
        for idx in table.indexes:
            if idx.unique:
                unique_cols.update(c.name for c in idx.columns)
        plan.append((table.name, cols, [c for c in cols if c in unique_cols]))
    return plan


def restore_blockers(session, old_id, new_id):
    """متنِ خطا اگه الان نباید بازیابی انجام بشه، وگرنه None."""
    if old_id == new_id:
        return "این اکانت همونیه که ایمیل رو سیو کرده؛ چیزی برای بازیابی نیست."
    if session.get(db.User, old_id) is None:
        return "⚠️ اطلاعاتِ اکانتِ قدیمی پیدا نشد."
    import casino
    for uid in (old_id, new_id):
        if casino._user_has_active_round(session, uid):
            return "⛔️ یکی از دو اکانت وسطِ یه بازیِ کازینوییه؛ بعد از تمومِ بازی دوباره امتحان کن."
        msg = db.attack_busy_check_message(session, uid)
        if msg:
            return "⛔️ یکی از دو اکانت وسطِ عملیاتِ حمله/گروگانه؛ بعداً دوباره امتحان کن."
    try:
        import mafia
        if mafia.user_has_active_mafia(session, old_id) or mafia.user_has_active_mafia(session, new_id):
            return "⛔️ یکی از دو اکانت تو بازیِ مافیاست؛ بعد از تمومِ بازی دوباره امتحان کن."
    except Exception:
        logger.exception("چکِ مافیا برایِ بازیابی")
    return None


SNAPSHOT_KEEP_DAYS = 30


def _write_snapshot(old_id: int, new_id: int):
    """قبل از شروعِ انتقال، دیتای هر دو اکانت رو جدا (تو تراکنشِ مستقل و commit‌شده) ذخیره می‌کنه؛
    حتی اگه بعداً هر اتفاقی بیفته، دیتای اصلی قابلِ برگشته. اگه ذخیره نشه، انتقال شروع نمی‌شه."""
    import json
    snap = {}
    with db.engine.connect() as conn:
        def dump(table, cols):
            where = " OR ".join(f'"{c}" IN (:o, :n)' for c in cols)
            rows = conn.execute(text(f'SELECT * FROM "{table}" WHERE {where}'), {"o": old_id, "n": new_id}).mappings().all()
            if rows:
                snap[table] = [dict(r) for r in rows]
        dump("users", ["telegram_id"])
        dump("account_emails", ["user_id"])
        for tname, cols, _u in _user_col_plan():
            dump(tname, cols)
    payload = json.dumps(snap, default=str, ensure_ascii=False)
    s = db.get_session()
    try:
        s.add(AccountMigrationSnapshot(old_id=old_id, new_id=new_id, payload=payload))
        s.query(AccountMigrationSnapshot).filter(
            AccountMigrationSnapshot.created_at < _utcnow() - datetime.timedelta(days=SNAPSHOT_KEEP_DAYS)
        ).delete()
        s.commit()
    finally:
        s.close()


def _fk_violations(cur) -> set:
    return {tuple(r) for r in cur.execute("PRAGMA foreign_key_check").fetchall()}


def _pg_final_check(conn):
    """کلیدهایِ خارجیِ deferred همین‌جا (قبلِ COMMIT) چک می‌شن تا هر خطا هنوز قابلِ ROLLBACK کامل باشه."""
    conn.execute(text("SET CONSTRAINTS ALL IMMEDIATE"))


def _migrate_account_pg(session, old_id: int, new_id: int):
    """نسخه‌ی PostgreSQL همون migrate_account: یه تراکنشِ واقعی، قفلِ ردیفِ دو کاربر
    (SELECT ... FOR UPDATE)، کلیدهایِ خارجیِ «deferrable initially deferred» (چک تو COMMIT)،
    و همون تأییدهایِ صحت قبلِ COMMIT. هر خطا = ROLLBACK کاملِ هر دو اکانت."""
    session.rollback()
    session.expunge_all()
    plan = _user_col_plan()
    _write_snapshot(old_id, new_id)

    with db.engine.begin() as conn:
        def q(sql, **p):
            return conn.execute(text(sql), p)

        # قفل به ترتیبِ ثابت (جلوگیریِ deadlock اگه دو انتقالِ هم‌زمان باشه)
        for uid in sorted({old_id, new_id}):
            q('SELECT telegram_id FROM users WHERE telegram_id = :i FOR UPDATE', i=uid).fetchall()

        old_row = q("SELECT hop_points, hop_count, lvl FROM users WHERE telegram_id = :i", i=old_id).fetchone()
        if old_row is None:
            raise RuntimeError("اکانتِ قدیمی پیدا نشد")
        new_row = q("SELECT username, first_name FROM users WHERE telegram_id = :i", i=new_id).fetchone()
        uname, fname = (new_row[0], new_row[1]) if new_row else (None, None)

        for tname, cols, uniq_cols in plan:
            for col in uniq_cols:
                q(f'DELETE FROM "{tname}" WHERE "{col}" = :n', n=new_id)
        for tname, cols, _u in plan:
            for col in cols:
                q(f'UPDATE "{tname}" SET "{col}" = :n WHERE "{col}" = :o', n=new_id, o=old_id)

        q("DELETE FROM users WHERE telegram_id = :n", n=new_id)
        q("UPDATE users SET telegram_id = :n, username = :u, first_name = :f WHERE telegram_id = :o",
          n=new_id, u=uname, f=fname, o=old_id)
        q("UPDATE account_emails SET user_id = :n WHERE user_id = :o", n=new_id, o=old_id)
        q("DELETE FROM email_codes WHERE user_id = :o", o=old_id)

        got = q("SELECT hop_points, hop_count, lvl FROM users WHERE telegram_id = :i", i=new_id).fetchone()
        if got is None or tuple(got) != tuple(old_row):
            raise RuntimeError(f"verify failed: users row mismatch {tuple(old_row)} -> {got and tuple(got)}")
        if q("SELECT 1 FROM users WHERE telegram_id = :i", i=old_id).fetchone():
            raise RuntimeError("verify failed: old user row still exists")
        for tname, cols, _u in plan:
            for col in cols:
                if q(f'SELECT 1 FROM "{tname}" WHERE "{col}" = :o LIMIT 1', o=old_id).fetchone():
                    raise RuntimeError(f"verify failed: leftover reference to old id in {tname}.{col}")
        _pg_final_check(conn)
    session.expire_all()


def migrate_account(session, old_id: int, new_id: int):
    """همه‌ی دیتای old_id رو به new_id منتقل می‌کنه.

    تضمین‌ها:
    • اتمیک: یه تراکنشِ واقعیِ SQLite (BEGIN IMMEDIATE ... COMMIT). هر خطا/ناسازگاری = ROLLBACK کامل؛
      نه اکانتِ قدیمی تغییر می‌کنه نه جدید (دیتای اکانتِ جدید «صفر» نمی‌شه).
    • قبل از شروع، نسخه‌ی پشتیبانِ هر دو اکانت تو account_migration_snapshots ذخیره می‌شه.
    • بعد از انتقال، قبلِ COMMIT صحت چک می‌شه (دیتای قدیمی دقیقاً رسیده، هیچ رِفرنسی به old_id نمونده،
      خطای کلیدِ خارجیِ جدید نیست)؛ وگرنه ROLLBACK.
    • کلیدهایِ خارجی طبقِ روشِ رسمیِ SQLite (foreign_keys=OFF بیرونِ تراکنش، بعد foreign_key_check) مدیریت
      می‌شن؛ خطاهای قدیمیِ دیتابیس که ربطی به این انتقال ندارن جلوی انتقال رو نمی‌گیرن.
    اکانتِ جدید «جایگزین» می‌شه (ردیف‌هایی که با دیتای قدیمی تداخلِ یکتایی دارن پاک می‌شن)؛ username/first_name
    همون تلگرامِ جدید می‌مونه. exception می‌ده اگه چیزی ناسازگار بود (و در اون صورت هیچ تغییری اعمال نشده)."""
    if db.IS_PG:
        return _migrate_account_pg(session, old_id, new_id)
    session.rollback()               # هر تراکنشِ بازِ این session رو ببند تا قفلی نگه نداره
    session.expunge_all()
    plan = _user_col_plan()

    _write_snapshot(old_id, new_id)

    raw = db.engine.raw_connection()
    dbapi = raw.driver_connection
    prev_iso = dbapi.isolation_level
    dbapi.isolation_level = None     # کنترلِ دستیِ تراکنش
    cur = dbapi.cursor()
    in_txn = False
    try:
        cur.execute("PRAGMA foreign_keys=OFF")      # بیرونِ تراکنش؛ داخلِ تراکنش بی‌اثره
        cur.execute("BEGIN IMMEDIATE")              # قفلِ نوشتن؛ هیچ نویسنده‌ی دیگه‌ای وسطِ انتقال نمی‌پره
        in_txn = True

        old_row = cur.execute(
            "SELECT hop_points, hop_count, lvl FROM users WHERE telegram_id = ?", (old_id,)).fetchone()
        if old_row is None:
            raise RuntimeError("اکانتِ قدیمی پیدا نشد")
        new_row = cur.execute(
            "SELECT username, first_name FROM users WHERE telegram_id = ?", (new_id,)).fetchone()
        uname, fname = (new_row[0], new_row[1]) if new_row else (None, None)
        before_bad = _fk_violations(cur)

        for tname, cols, uniq_cols in plan:
            for col in uniq_cols:
                cur.execute(f'DELETE FROM "{tname}" WHERE "{col}" = ?', (new_id,))
        for tname, cols, _u in plan:
            for col in cols:
                cur.execute(f'UPDATE "{tname}" SET "{col}" = ? WHERE "{col}" = ?', (new_id, old_id))

        cur.execute("DELETE FROM users WHERE telegram_id = ?", (new_id,))
        cur.execute("UPDATE users SET telegram_id = ?, username = ?, first_name = ? WHERE telegram_id = ?",
                    (new_id, uname, fname, old_id))
        cur.execute("UPDATE account_emails SET user_id = ? WHERE user_id = ?", (new_id, old_id))
        cur.execute("DELETE FROM email_codes WHERE user_id = ?", (old_id,))

        # --- تأییدِ صحت قبل از COMMIT ---
        got = cur.execute("SELECT hop_points, hop_count, lvl FROM users WHERE telegram_id = ?", (new_id,)).fetchone()
        if got is None or tuple(got) != tuple(old_row):
            raise RuntimeError(f"verify failed: users row mismatch {old_row} -> {got}")
        if cur.execute("SELECT 1 FROM users WHERE telegram_id = ?", (old_id,)).fetchone():
            raise RuntimeError("verify failed: old user row still exists")
        for tname, cols, _u in plan:
            for col in cols:
                if cur.execute(f'SELECT 1 FROM "{tname}" WHERE "{col}" = ? LIMIT 1', (old_id,)).fetchone():
                    raise RuntimeError(f"verify failed: leftover reference to old id in {tname}.{col}")
        new_bad = _fk_violations(cur) - before_bad
        if new_bad:
            raise RuntimeError(f"foreign_key_check failed after migration: {sorted(new_bad)[:5]}")

        cur.execute("COMMIT")
        in_txn = False
    except BaseException:
        if in_txn:
            try:
                cur.execute("ROLLBACK")
            except Exception:
                logger.exception("ROLLBACK ناموفق")
        raise
    finally:
        try:
            cur.execute("PRAGMA foreign_keys=ON")
        except Exception:
            logger.exception("برگردوندنِ foreign_keys=ON ناموفق")
        dbapi.isolation_level = prev_iso
        cur.close()
        raw.close()
    session.expire_all()


def is_fresh_account(user) -> bool:
    return (user.hop_count or 0) == 0 and (user.lvl or 1) <= 1


# ---------------------------------------------------------------------------
# UI
# ---------------------------------------------------------------------------
def _menu_view(session, uid):
    link = session.get(AccountEmail, uid)
    if link:
        text_ = (f"💾 اکانتت روی «{mask_email(link.email_display)}» سیو شده.\n\n"
                 "اگه تلگرامت دیلیت شد، با اکانتِ جدید از «بازیابی اکانت» وارد همین اکانت می‌شی.\n"
                 "برایِ جداکردنِ ایمیل، «لغو سیو» رو بزن؛ کدِ تایید به همین ایمیل می‌ره.")
        rows = [[Btn("🗑 لغو سیو (کد به ایمیلِ فعلی)", callback_data=f"acct:unlink:{uid}")]]
    else:
        text_ = ("💾 هنوز اکانتت روی هیچ ایمیلی سیو نشده.\n\n"
                 "• «سیو روی جیمیل»: اکانتِ فعلی رو به جیمیلت وصل می‌کنی.\n"
                 "• «بازیابی اکانت»: اگه قبلاً سیو کردی و اکانتِ تلگرامت عوض شده، اینجا برش می‌گردونی.")
        rows = [[Btn("💾 سیو روی جیمیل", callback_data=f"acct:save:{uid}")],
                [Btn("♻️ بازیابی اکانت", callback_data=f"acct:restore:{uid}")]]
    rows.append([Btn("🔙 بازگشت", callback_data=f"back_main_owned:{uid}")])
    return text_, Kb(rows)


async def _reply_state_prompt(update, context, text_, state, uid):
    from handlers import ask_for_input, ask_for_input_reply
    if update.callback_query:
        await ask_for_input(update, context, text_, state, STATE_KEY)
    else:
        await ask_for_input_reply(update, context, text_, state, STATE_KEY)


async def callback_router(update, context) -> bool:
    q = update.callback_query
    data = q.data or ""
    parts = data.split(":")
    if len(parts) < 3 or parts[0] != "acct":
        return False
    action = parts[1]
    try:
        owner = int(parts[2])
    except ValueError:
        await q.answer()
        return True
    uid = update.effective_user.id
    if uid != owner:
        await q.answer("🚫 این پنل مالِ شما نیست.", show_alert=True)
        return True
    if update.effective_chat and update.effective_chat.type != "private":
        await q.answer("🔐 این بخش فقط تو پیوی ربات کار می‌کنه.", show_alert=True)
        return True
    from handlers import send_response
    session = db.get_session()
    try:
        db.get_or_create_user(session, update.effective_user)
        session.commit()
        link = session.get(AccountEmail, uid)

        if action == "menu":
            context.user_data.pop(STATE_KEY, None)
            t, kb = _menu_view(session, uid)
            await send_response(update, t, kb)

        elif action in ("save", "restore"):
            if link:
                await q.answer("این اکانت از قبل روی یه ایمیل سیو شده.", show_alert=True)
                return True
            if not smtp_configured():
                await q.answer("⚠️ ارسالِ ایمیل هنوز تنظیم نشده؛ به مالکِ ربات بگو.", show_alert=True)
                return True
            if _codes_sent(session, user_id=uid) >= MAX_CODES_PER_DAY:
                await q.answer(LIMIT_TEXT, show_alert=True)
                return True
            await _reply_state_prompt(update, context,
                                      "📧 آدرسِ جیمیلت رو بفرست (مثلاً name@gmail.com):",
                                      {"type": f"{action}_email"}, uid)

        elif action == "unlink":
            if not link:
                await q.answer("این اکانت روی هیچ ایمیلی سیو نشده.", show_alert=True)
                return True
            code_id, err = await issue_code(session, uid, link.email_norm, link.email_display, "unlink")
            if err:
                await q.answer(err, show_alert=True)
                return True
            await _reply_state_prompt(
                update, context,
                f"📨 کدِ تایید به {mask_email(link.email_display)} فرستاده شد.\n"
                f"کدِ ۶ رقمی رو تا {CODE_TTL_SECONDS} ثانیه‌ی دیگه همین‌جا بفرست تا سیو لغو بشه.",
                {"type": "code", "purpose": "unlink", "email": link.email_norm, "code_id": code_id}, uid)

        elif action == "rok":
            try:
                code_id = int(parts[3])
            except (IndexError, ValueError):
                await q.answer()
                return True
            await _do_confirmed_restore(update, context, session, uid, code_id)

        else:
            await q.answer()
    finally:
        session.close()
    return True


async def _do_confirmed_restore(update, context, session, uid, code_id):
    from handlers import send_response
    q = update.callback_query
    row = session.get(EmailCode, code_id)
    if (not row or row.user_id != uid or row.purpose != "restore" or row.status != "verified"
            or _utcnow() > row.expires_at):
        await q.answer("⛔️ این تایید منقضی شده؛ از اول شروع کن.", show_alert=True)
        return
    row.status = "used"
    session.commit()
    await _finish_restore(update, context, session, uid, row.email_norm)


async def _finish_restore(update, context, session, uid, email_norm):
    """مشترکِ مسیرِ مستقیم (اکانتِ تازه) و مسیرِ تاییدشده. جوابِ نهایی رو می‌فرسته."""
    link = session.query(AccountEmail).filter_by(email_norm=email_norm).first()
    reply = None
    if link is None:
        reply = "⚠️ این ایمیل دیگه به هیچ اکانتی وصل نیست."
    else:
        old_id = link.user_id
        err = restore_blockers(session, old_id, uid)
        if err:
            reply = err
        else:
            try:
                migrate_account(session, old_id, uid)
                reply = ("✅ اکانتت بازیابی شد! همه‌ی دیتات (هاپ‌پوینت، لول، کارخونه، بانک، جنگ و ...) "
                         "به این اکانت منتقل شد.")
                try:
                    await context.bot.send_message(
                        old_id, "ℹ️ اکانتِ شما با کدِ ایمیل روی یه اکانتِ تلگرامیِ جدید بازیابی شد. "
                                "اگه خودت نبودی، سریع به مالکِ ربات خبر بده.")
                except Exception:
                    pass
            except Exception:
                session.rollback()
                logger.exception("بازیابیِ اکانت شکست خورد old=%s new=%s", old_id, uid)
                reply = "⚠️ بازیابی با خطا روبه‌رو شد و هیچ تغییری اعمال نشد؛ دوباره امتحان کن."
    kb = Kb([[Btn("🏠 منوی اصلی", callback_data=f"back_main_owned:{uid}")]])
    if update.callback_query:
        from handlers import send_response
        await send_response(update, reply, kb)
    else:
        await update.message.reply_text(reply, reply_markup=kb)


async def awaiting_handler(update, context):
    """جوابِ متنیِ مرحله‌های ایمیل/کد. اگه پیام مالِ این فلو بود ApplicationHandlerStop می‌ده تا
    روترهای دیگه (مثلاً text_router) دوباره روی همون پیام کار نکنن."""
    handled = await _awaiting_inner(update, context)
    if handled:
        raise ApplicationHandlerStop


async def _awaiting_inner(update, context):
    from handlers import is_reply_to_prompt, clear_prompt_keyboard
    st = context.user_data.get(STATE_KEY)
    if not st:
        return False
    if update.effective_chat and update.effective_chat.type != "private":
        return False
    if not is_reply_to_prompt(update, st):
        return False
    await clear_prompt_keyboard(context, st)
    context.user_data.pop(STATE_KEY, None)
    uid = update.effective_user.id
    raw = (update.message.text or "").strip()
    session = db.get_session()
    try:
        db.get_or_create_user(session, update.effective_user)
        session.commit()
        t = st.get("type")

        if t in ("save_email", "restore_email"):
            purpose = "link" if t == "save_email" else "restore"
            norm, display = normalize_email(raw)
            if not norm:
                await update.message.reply_text("❌ فقط آدرسِ جیمیلِ معتبر (…@gmail.com) قبول می‌شه. دوباره از منو شروع کن.")
                return True
            mine = session.get(AccountEmail, uid)
            if mine:
                await update.message.reply_text("این اکانت از قبل روی یه ایمیل سیو شده.")
                return True
            owner = session.query(AccountEmail).filter_by(email_norm=norm).first()
            if purpose == "link" and owner is not None:
                await update.message.reply_text(LINKED_ELSEWHERE_TEXT)
                return True
            if purpose == "restore":
                if owner is None:
                    await update.message.reply_text("⚠️ هیچ اکانتی روی این ایمیل سیو نشده.")
                    return True
                if owner.user_id == uid:
                    await update.message.reply_text("این اکانت همونیه که ایمیل رو سیو کرده.")
                    return True
            code_id, err = await issue_code(session, uid, norm, display, purpose)
            if err:
                await update.message.reply_text(err)
                return True
            from handlers import ask_for_input_reply
            await ask_for_input_reply(
                update, context,
                f"📨 کدِ ۶ رقمی به {mask_email(display)} فرستاده شد.\n"
                f"تا {CODE_TTL_SECONDS} ثانیه‌ی دیگه همین‌جا بفرستش.",
                {"type": "code", "purpose": purpose, "email": norm, "display": display, "code_id": code_id},
                STATE_KEY)
            return True

        if t == "code":
            ok, msg = check_code(session, st["code_id"], uid, raw)
            if not ok:
                row = session.get(EmailCode, st["code_id"])
                if row and row.status == "pending":      # هنوز فرصت هست؛ دوباره منتظر کد
                    from handlers import ask_for_input_reply
                    await ask_for_input_reply(update, context, msg + "\nدوباره کد رو بفرست:", st, STATE_KEY)
                else:
                    await update.message.reply_text(msg)
                return True
            await _on_code_ok(update, context, session, uid, st)
            return True
        return True
    finally:
        session.close()


async def _on_code_ok(update, context, session, uid, st):
    purpose, norm, code_id = st["purpose"], st["email"], st["code_id"]
    row = session.get(EmailCode, code_id)

    if purpose == "link":
        if session.get(AccountEmail, uid) is not None:
            row.status = "used"
            session.commit()
            await update.message.reply_text("این اکانت از قبل روی یه ایمیل سیو شده.")
            return
        try:
            session.add(AccountEmail(user_id=uid, email_norm=norm, email_display=st.get("display") or norm))
            row.status = "used"
            session.commit()
        except IntegrityError:
            session.rollback()
            await update.message.reply_text(LINKED_ELSEWHERE_TEXT)
            return
        await update.message.reply_text(f"✅ اکانتت روی {mask_email(st.get('display') or norm)} سیو شد.",
                                        reply_markup=Kb([[Btn("🏠 منوی اصلی", callback_data=f"back_main_owned:{uid}")]]))

    elif purpose == "unlink":
        link = session.get(AccountEmail, uid)
        if link is None or link.email_norm != norm:
            row.status = "used"
            session.commit()
            await update.message.reply_text("این اکانت دیگه روی این ایمیل سیو نیست.")
            return
        session.delete(link)
        row.status = "used"
        session.commit()
        await update.message.reply_text("✅ سیوِ اکانت لغو شد؛ ایمیل از این اکانت جدا شد.",
                                        reply_markup=Kb([[Btn("🏠 منوی اصلی", callback_data=f"back_main_owned:{uid}")]]))

    elif purpose == "restore":
        user = session.get(db.User, uid)
        if user is not None and not is_fresh_account(user):
            row.status = "verified"
            row.expires_at = _utcnow() + datetime.timedelta(seconds=CODE_TTL_SECONDS)
            session.commit()
            await update.message.reply_text(
                "⚠️ این اکانت خودش دیتا داره (هاپ/لول). با بازیابی، دیتای فعلیِ همین اکانت پاک و "
                "جایگزینِ دیتای اکانتِ قدیمی می‌شه.\nمطمئنی؟",
                reply_markup=Kb([[Btn("✅ بله، جایگزین کن", callback_data=f"acct:rok:{uid}:{code_id}")],
                                 [Btn("❌ نه", callback_data=f"acct:menu:{uid}")]]))
            return
        row.status = "used"
        session.commit()
        await _finish_restore(update, context, session, uid, norm)
