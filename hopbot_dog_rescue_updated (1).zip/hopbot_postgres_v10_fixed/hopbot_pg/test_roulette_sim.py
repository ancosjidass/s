# -*- coding: utf-8 -*-
"""تستِ رولت روسی با آبجکت‌هایِ جعلیِ تلگرام (بدونِ اینترنت / توکنِ واقعی)."""
import asyncio
import datetime
import os
import random
import sys
import tempfile

_tmp = tempfile.mkdtemp()
os.environ["DB_PATH"] = os.path.join(_tmp, "t.db")
os.environ["BOT_TOKEN"] = "1:x"
os.environ["OWNER_ID"] = "999"

import db  # noqa: E402
import casino  # noqa: E402
import roulette  # noqa: E402
import uno  # noqa: E402
from telegram.ext import ApplicationHandlerStop  # noqa: E402

db.init_db()
_s = db.get_session()
db.cfg_set(_s, "casino_rr_spin_wait_seconds", "0")   # بیشترِ تست‌ها بدونِ انتظارِ چرخاندنِ خشاب (تستِ اختصاصیِ انتظار پایین‌تره)
_s.close()


# ---------------------------------------------------------------- fakes
class FakeBot:
    def __init__(self):
        self.edits = []      # (chat_id, message_id, text, kb)
        self.sent = []       # (chat_id, text, mid)
        self.deleted = []
        self.next_id = 5000
        self.fail_edit_ids = set()
        self.transient = {}   # message_id -> تعدادِ خطایِ موقتیِ باقی‌مونده (فلود/تایم‌اوت)
        self.stripped = []

    async def edit_message_reply_markup(self, chat_id=None, message_id=None, reply_markup=None, **kw):
        self.stripped.append((chat_id, message_id))

    async def edit_message_text(self, chat_id=None, message_id=None, text=None, reply_markup=None, **kw):
        if self.transient.get(message_id, 0) > 0:
            self.transient[message_id] -= 1
            raise Exception("Timed out")
        if message_id in self.fail_edit_ids:
            raise Exception("Bad Request: message to edit not found")
        self.edits.append((chat_id, message_id, text, reply_markup))

    async def send_message(self, chat_id=None, text=None, reply_markup=None, **kw):
        self.next_id += 1
        self.sent.append((chat_id, text, self.next_id))
        return FakeMsg(chat_id, self.next_id)

    async def delete_message(self, chat_id=None, message_id=None):
        self.deleted.append((chat_id, message_id))

    def last_edit(self, message_id):
        for e in reversed(self.edits):
            if e[1] == message_id:
                return e
        return None


class FakeMsg:
    def __init__(self, chat_id, message_id):
        self.chat_id = chat_id
        self.message_id = message_id


class FakeQuery:
    def __init__(self, bot, data, chat_id, message_id):
        self.bot = bot
        self.data = data
        self.message = FakeMsg(chat_id, message_id)
        self.answers = []

    async def answer(self, text=None, show_alert=False):
        self.answers.append((text, show_alert))

    async def edit_message_text(self, text, reply_markup=None):
        await self.bot.edit_message_text(self.message.chat_id, self.message.message_id, text, reply_markup)
        return FakeMsg(self.message.chat_id, self.message.message_id)


class FakeUser:
    def __init__(self, uid, username=None, first="U"):
        self.id = uid
        self.username = username or f"u{uid}"
        self.first_name = first or f"U{uid}"


class FakeChat:
    def __init__(self, cid, typ="supergroup"):
        self.id = cid
        self.type = typ


class FakeUpdate:
    def __init__(self, user, chat, query=None, text=None, reply_to=None):
        self.effective_user = user
        self.effective_chat = chat
        self.callback_query = query
        self.message = None
        if text is not None:
            self.message = FakeTextMessage(text, chat, reply_to, user)


class FakeTextMessage:
    def __init__(self, text, chat, reply_to, user):
        self.text = text
        self.chat = chat
        self.reply_to_message = reply_to
        self.replies = []

    async def reply_text(self, text, **kw):
        self.replies.append(text)


class FakeCtx:
    def __init__(self, bot):
        self.bot = bot
        self.user_data = {}
        self.job_queue = None


BOT = FakeBot()
CTX = {}  # uid -> ctx (user_data per user)


def ctx_for(uid):
    if uid not in CTX:
        CTX[uid] = FakeCtx(BOT)
    return CTX[uid]


_msg_counter = [100]


def new_panel(chat_id):
    _msg_counter[0] += 1
    return _msg_counter[0]


async def press(user, chat, msg_id, data):
    q = FakeQuery(BOT, data, chat.id, msg_id)
    upd = FakeUpdate(user, chat, q)
    await casino_or_rr(upd, ctx_for(user.id))
    return q


async def casino_or_rr(upd, ctx):
    data = upd.callback_query.data
    if data.startswith("rr_"):
        assert await roulette.rr_callback_router(upd, ctx)
    elif data.startswith("casino"):
        assert await casino.casino_callback_router(upd, ctx)
    else:
        raise AssertionError(data)


def mk_user(uid, balance):
    s = db.get_session()
    try:
        u = db.get_or_create_user(s, FakeUser(uid))
        u.hop_points = balance
        s.commit()
    finally:
        s.close()


def bal(uid):
    s = db.get_session()
    try:
        return db.get_or_create_user(s, FakeUser(uid)).hop_points
    finally:
        s.close()


def rnd(rid):
    s = db.get_session()
    try:
        r = s.get(db.RouletteRound, rid)
        s.expunge(r)
        return r
    finally:
        s.close()


def players_of(rid):
    s = db.get_session()
    try:
        return [(p.user_id, p.alive) for p in roulette._all_players(s, rid)]
    finally:
        s.close()


def last_alert(q):
    return q.answers[-1] if q.answers else None


def total_money(uids):
    return sum(bal(u) for u in uids)


passed = []


def ok(name):
    passed.append(name)
    print("  ✓", name)


def latest_round_id(mode=None):
    s = db.get_session()
    try:
        q = s.query(db.RouletteRound)
        if mode:
            q = q.filter_by(mode=mode)
        r = q.order_by(db.RouletteRound.id.desc()).first()
        return r.id
    finally:
        s.close()


# ---------------------------------------------------------------- tests

async def play_out(rid, users_by_id, chat_of, panel_of, max_steps=200, use_seq_check=True):
    """بازی رو تا آخر می‌بره: همیشه «نوبتِ فعلی» شلیک می‌کنه."""
    steps = 0
    while True:
        r = rnd(rid)
        if r.status != "playing":
            return r
        steps += 1
        assert steps < max_steps, "بازی تموم نشد!"
        holder = r.turn_user_id
        await press(users_by_id[holder], chat_of[holder], panel_of[holder], f"rr_fire:{rid}:{r.turn_seq}")


async def test_group_full_game():
    print("test_group_full_game")
    uids = [11, 12, 13]
    for u in uids:
        mk_user(u, 10_000_000)
    before = total_money(uids)
    users = {u: FakeUser(u) for u in uids}
    chat = FakeChat(-100500)
    panel = new_panel(chat.id)

    q = await press(users[11], chat, panel, "rr_new:11")
    assert "کجا بازی کنیم" in BOT.last_edit(panel)[2]
    # کسِ دیگه نمی‌تونه منوی من رو بزنه
    q = await press(users[12], chat, panel, "rr_mode_group:11")
    assert last_alert(q)[1] is True
    q = await press(users[11], chat, panel, "rr_mode_group:11")
    rid = latest_round_id("group")
    assert rnd(rid).status == "setup"
    # کازینو دومی نمی‌تونه باز کنه (وسطِ کازینوئه)
    panel_b = new_panel(chat.id)
    q = await press(users[11], chat, panel_b, "rr_mode_group:11")
    assert last_alert(q)[0].startswith("⛔️ تو همین الان")
    ok("owner-lock + busy check for second casino")

    await press(users[11], chat, panel, f"rr_amt_pick:{rid}:1000")
    await press(users[11], chat, panel, f"rr_plr_pick:{rid}:3")
    # فقط سازنده می‌تونه تنظیمات رو عوض کنه
    q = await press(users[12], chat, panel, f"rr_plr_pick:{rid}:2")
    assert last_alert(q)[1] is True and rnd(rid).target_players == 3
    await press(users[11], chat, panel, f"rr_start:{rid}")
    assert rnd(rid).status == "lobby"
    assert bal(11) == 10_000_000 - 1000
    assert "(1/3)" in BOT.last_edit(panel)[2]
    ok("group setup -> lobby, creator paid")

    # کسی که خودش وسطِ کازینوئه نمی‌تونه بپیونده؛ دوبار پیوستن ثبت نمی‌شه
    q = await press(users[12], chat, panel, f"rr_join:{rid}")
    q = await press(users[12], chat, panel, f"rr_join:{rid}")
    assert last_alert(q)[0] == "قبلا پیوستی ✅"
    assert bal(12) == 10_000_000 - 1000
    assert "(2/3)" in BOT.last_edit(panel)[2]
    # سازنده نمی‌تونه «ترک» بزنه، عضو می‌تونه
    q = await press(users[11], chat, panel, f"rr_leave:{rid}")
    assert last_alert(q)[1] is True
    q = await press(users[12], chat, panel, f"rr_leave:{rid}")
    assert bal(12) == 10_000_000 and "(1/3)" in BOT.last_edit(panel)[2]
    await press(users[12], chat, panel, f"rr_join:{rid}")
    await press(users[13], chat, panel, f"rr_join:{rid}")
    r = rnd(rid)
    assert r.status == "playing", r.status
    assert r.turn_user_id in uids
    ok("join/leave/full -> playing")

    # فقط نوبتِ فعلی می‌تونه شلیک کنه
    others = [u for u in uids if u != r.turn_user_id]
    q = await press(users[others[0]], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
    assert last_alert(q)[1] is True and "نوبتِ" in last_alert(q)[0]
    assert rnd(rid).turn_seq == r.turn_seq
    # دکمه‌ی قدیمی (seq اشتباه) هم اثری نداره
    q = await press(users[r.turn_user_id], chat, panel, f"rr_fire:{rid}:{r.turn_seq + 5}")
    assert rnd(rid).turn_seq == r.turn_seq and rnd(rid).chamber_idx == 0
    # پنل «نوبتِ کی» رو نشون می‌ده
    txt = BOT.last_edit(panel)[2]
    assert "نوبتِ" in txt and "🔫 شلیک" in BOT.last_edit(panel)[3].inline_keyboard[0][0].text
    ok("only holder can fire; stale button ignored; panel shows turn")

    chat_of = {u: chat for u in uids}
    panel_of = {u: panel for u in uids}
    r = await play_out(rid, users, chat_of, panel_of)
    assert r.status == "resolved" and r.winner_id in uids
    alive = [a for _, a in players_of(rid)]
    assert alive.count(True) == 1
    assert bal(r.winner_id) == 10_000_000 - 1000 + 3000
    assert abs(total_money(uids) - before) < 1e-6
    assert not roulette.user_has_active_roulette(db.get_session(), 11)
    assert "برنده" in BOT.last_edit(panel)[2]
    ok("full game resolves, winner paid pot, money conserved, all released")


async def test_custom_amount_and_cancel():
    print("test_custom_amount_and_cancel")
    mk_user(21, 5_000_000)
    u = FakeUser(21)
    chat = FakeChat(-100600)
    panel = new_panel(chat.id)
    await press(u, chat, panel, "rr_new:21")
    await press(u, chat, panel, "rr_mode_group:21")
    rid = latest_round_id("group")
    ctx = ctx_for(21)

    # ۱) کنسلِ پرامپت: برمی‌گرده به پنل، دور سرِ جاشه
    await press(u, chat, panel, f"rr_amt_menu:{rid}")
    assert "مبلغ دلخواه" in str(BOT.last_edit(panel)[3].inline_keyboard)
    await press(u, chat, panel, f"rr_amt_custom:{rid}")
    assert ctx.user_data.get("rr_awaiting")
    q = await press(u, chat, panel, f"rr_amtx:{rid}")
    assert not ctx.user_data.get("rr_awaiting")
    assert rnd(rid).status == "setup"
    assert "مبلغ ورودی" in BOT.last_edit(panel)[2] and BOT.last_edit(panel)[3] is not None
    ok("custom-amount prompt cancel returns to setup panel (round alive)")

    # ۲) مبلغِ نامعتبر: پنل با خطا برمی‌گرده
    await press(u, chat, panel, f"rr_amt_menu:{rid}")
    await press(u, chat, panel, f"rr_amt_custom:{rid}")
    upd = FakeUpdate(u, chat, text="abc")
    try:
        await roulette.rr_awaiting_handler(upd, ctx)
        raise AssertionError("expected Stop")
    except ApplicationHandlerStop:
        pass
    e = BOT.last_edit(panel)
    assert "مقدار اشتباه" in e[2] and e[3] is not None and rnd(rid).entry_amount is None
    assert not ctx.user_data.get("rr_awaiting")
    ok("invalid amount restores panel with error")

    # ۳) مبلغِ معتبر با کوتاه‌نویسی
    await press(u, chat, panel, f"rr_amt_menu:{rid}")
    await press(u, chat, panel, f"rr_amt_custom:{rid}")
    upd = FakeUpdate(u, chat, text="2m")
    try:
        await roulette.rr_awaiting_handler(upd, ctx)
    except ApplicationHandlerStop:
        pass
    assert rnd(rid).entry_amount == 2_000_000
    ok("custom amount 2m accepted")

    # ۴) پیامِ نامربوط بعد از تموم شدنِ تنظیمات، ساکت رد می‌شه
    ctx.user_data["rr_awaiting"] = {"type": "amount", "round_id": rid, "_prompt_chat_id": chat.id,
                                    "_prompt_message_id": 1}
    await press(u, chat, panel, f"rr_cancel:{rid}")
    assert rnd(rid).status == "cancelled"
    upd = FakeUpdate(u, chat, text="سلام")
    await roulette.rr_awaiting_handler(upd, ctx)  # نباید Stop بده و نباید جواب بده
    assert upd.message.replies == []
    assert not roulette.user_has_active_roulette(db.get_session(), 21)
    ok("stale awaiting after cancel is silent, user released")

    # ۵) دکمه‌ی back از setup برمی‌گرده به انتخابِ مدل
    panel2 = new_panel(chat.id)
    await press(u, chat, panel2, "rr_new:21")
    await press(u, chat, panel2, "rr_mode_group:21")
    rid2 = latest_round_id("group")
    await press(u, chat, panel2, f"rr_back:{rid2}")
    assert rnd(rid2).status == "cancelled"
    assert "کجا بازی کنیم" in BOT.last_edit(panel2)[2]
    assert not roulette.user_has_active_roulette(db.get_session(), 21)
    ok("back from setup cancels round + shows mode menu")


async def test_group_lobby_timeout_and_cancel():
    print("test_group_lobby_timeout_and_cancel")
    for u in (31, 32):
        mk_user(u, 1_000_000)
    users = {u: FakeUser(u) for u in (31, 32)}
    chat = FakeChat(-100700)
    panel = new_panel(chat.id)
    await press(users[31], chat, panel, "rr_new:31")
    await press(users[31], chat, panel, "rr_mode_group:31")
    rid = latest_round_id("group")
    await press(users[31], chat, panel, f"rr_amt_pick:{rid}:500")
    await press(users[31], chat, panel, f"rr_plr_pick:{rid}:4")
    await press(users[31], chat, panel, f"rr_start:{rid}")
    await press(users[32], chat, panel, f"rr_join:{rid}")
    assert bal(31) == 999_500 and bal(32) == 999_500
    # قبل از مهلت: تایم‌اوت کاری نمی‌کنه
    await roulette._lobby_timeout(ctx_for(31), rid)
    assert rnd(rid).status == "lobby"
    # سازنده‌ای که نیست نمی‌تونه لغو کنه
    q = await press(users[32], chat, panel, f"rr_cancel:{rid}")
    assert last_alert(q)[1] is True and rnd(rid).status == "lobby"
    # مهلت تموم شد (۱۸۰ ثانیه)
    s = db.get_session()
    r = s.get(db.RouletteRound, rid)
    r.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=181)
    s.commit()
    s.close()
    await roulette._lobby_timeout(ctx_for(31), rid)
    assert rnd(rid).status == "cancelled"
    assert bal(31) == 1_000_000 and bal(32) == 1_000_000
    assert "لغو شد" in BOT.last_edit(panel)[2]
    assert not roulette.user_has_active_roulette(db.get_session(), 31)
    assert not casino._user_has_active_round(db.get_session(), 32)
    ok("group lobby expiry -> cancel + refund + everyone released")

    # مهلتِ ۱۸۰ ثانیه‌ای (نه ۶۰ / ۲۰۰)
    assert roulette.GROUP_LOBBY_SECONDS == 180 and roulette.GLOBAL_WAIT_SECONDS == 360 and roulette.rr_settings(db.get_session())["turn"] == 120

    # لغو توسطِ سازنده تو lobby
    panel = new_panel(chat.id)
    await press(users[31], chat, panel, "rr_new:31")
    await press(users[31], chat, panel, "rr_mode_group:31")
    rid = latest_round_id("group")
    await press(users[31], chat, panel, f"rr_amt_pick:{rid}:500")
    await press(users[31], chat, panel, f"rr_plr_pick:{rid}:3")
    await press(users[31], chat, panel, f"rr_start:{rid}")
    await press(users[32], chat, panel, f"rr_join:{rid}")
    await press(users[31], chat, panel, f"rr_cancel:{rid}")
    assert rnd(rid).status == "cancelled" and bal(31) == 1_000_000 and bal(32) == 1_000_000
    ok("creator cancel in lobby refunds everyone")


async def test_lazy_expiry_no_busy_bug():
    print("test_lazy_expiry_no_busy_bug")
    mk_user(41, 1_000_000)
    u = FakeUser(41)
    chat = FakeChat(-100800)
    panel = new_panel(chat.id)
    await press(u, chat, panel, "rr_new:41")
    await press(u, chat, panel, "rr_mode_group:41")
    rid = latest_round_id("group")
    await press(u, chat, panel, f"rr_amt_pick:{rid}:1000")
    await press(u, chat, panel, f"rr_plr_pick:{rid}:2")
    await press(u, chat, panel, f"rr_start:{rid}")
    assert bal(41) == 999_000
    # مهلتِ لابی گذشته، ولی هیچ تایمری اجرا نشده (مثلاً ربات ری‌استارت شده بود)
    s = db.get_session()
    r = s.get(db.RouletteRound, rid)
    r.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=200)
    s.commit()
    s.close()
    panel2 = new_panel(chat.id)
    q = await press(u, chat, panel2, "rr_new:41")
    # به‌جای «وسطِ کازینو هستی»، منو باز می‌شه و پول برگشته
    assert last_alert(q) is None or last_alert(q)[0] is None
    assert "کجا بازی کنیم" in BOT.last_edit(panel2)[2]
    assert rnd(rid).status == "cancelled" and bal(41) == 1_000_000
    # و ادیتِ پیامِ قدیمی تو tick انجام می‌شه
    await roulette.tick_roulette(db.get_session(), ctx_for(41))
    assert "لغو شد" in BOT.last_edit(panel)[2]
    ok("expired lobby never causes 'in the middle of casino' (lazy expiry)")

    # setup رهاشده
    await press(u, chat, panel2, "rr_mode_group:41")
    rid2 = latest_round_id("group")
    s = db.get_session()
    r = s.get(db.RouletteRound, rid2)
    r.last_action_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=120)
    s.commit()
    s.close()
    q = await press(u, chat, new_panel(chat.id), "rr_new:41")
    assert rnd(rid2).status == "cancelled"
    ok("abandoned setup is released on next attempt")

    # کلاسیک هم همین‌طور
    panel3 = new_panel(chat.id)
    await press(u, chat, panel3, "casino_game:bw:41")
    s = db.get_session()
    cr = s.query(db.CasinoRound).order_by(db.CasinoRound.id.desc()).first()
    assert cr.status == "setup"
    cr.created_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=100)
    s.commit()
    s.close()
    s = db.get_session()
    assert casino._user_has_active_round(s, 41) is False
    s.close()
    ok("classic casino stale setup released lazily")


async def test_global_flow():
    print("test_global_flow")
    uids = [51, 52, 53, 54]
    for u in uids:
        mk_user(u, 1_000_000_000)
    before = total_money(uids)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-200000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    T = 100_000_000

    # جهانی: منو -> میز -> تعداد
    await press(users[51], chats[51], panels[51], "rr_new:51")
    await press(users[51], chats[51], panels[51], "rr_mode_global:51")
    kb = BOT.last_edit(panels[51])[3]
    labels = [b.text for row in kb.inline_keyboard for b in row]
    assert any("1,000,000" in l for l in labels) and any("100,000,000" in l for l in labels) and any("500,000,000" in l for l in labels)
    assert not any("دلخواه" in l for l in labels)
    await press(users[51], chats[51], panels[51], f"rr_gtier:51:{T}")
    kb = BOT.last_edit(panels[51])[3]
    assert [b.text for b in kb.inline_keyboard[0]] == ["👥 2 نفره", "👥 3 نفره", "👥 4 نفره"]
    ok("global menus: 3 fixed tiers, no custom amount, 2/3/4 players")

    # میزِ نامعتبر
    q = await press(users[51], chats[51], panels[51], "rr_gtier:51:12345")
    assert last_alert(q)[1] is True
    q = await press(users[51], chats[51], panels[51], "rr_gjoin:51:12345:4")
    assert last_alert(q)[1] is True and bal(51) == 1_000_000_000
    ok("tampered tier rejected")

    await press(users[51], chats[51], panels[51], f"rr_gjoin:51:{T}:4")
    rid = latest_round_id("global")
    assert bal(51) == 1_000_000_000 - T
    assert "(1/4)" in BOT.last_edit(panels[51])[2]

    # کسی با انتخابِ متفاوت (۳ نفره) میزِ جدید می‌گیره
    await press(users[52], chats[52], panels[52], f"rr_gjoin:52:{T}:3")
    rid3 = latest_round_id("global")
    assert rid3 != rid
    # 52 منصرف می‌شه تا دوباره ۴نفره بزنه
    await press(users[52], chats[52], panels[52], f"rr_gleave:{rid3}:52")
    assert rnd(rid3).status == "cancelled" and bal(52) == 1_000_000_000
    ok("different player-count => separate table; last leaver cancels empty table")

    # مبلغ/تعدادِ یکسان با هم می‌افتن
    await press(users[52], chats[52], panels[52], "rr_new:52")
    await press(users[52], chats[52], panels[52], "rr_mode_global:52")
    await press(users[52], chats[52], panels[52], f"rr_gjoin:52:{T}:4")
    assert len(players_of(rid)) == 2
    assert "(2/4)" in BOT.last_edit(panels[51])[2] and "(2/4)" in BOT.last_edit(panels[52])[2]
    await press(users[53], chats[53], panels[53], f"rr_gjoin:53:{T}:4")
    assert "(3/4)" in BOT.last_edit(panels[51])[2]
    ok("same tier+count matchmake together; counters update on everyone's panel")

    # «منصرف شدم»: فقط صاحبِ پنل
    q = await press(users[52], chats[52], panels[52], f"rr_gleave:{rid}:51")
    assert last_alert(q)[1] is True and len(players_of(rid)) == 3
    # ۵۱ منصرف می‌شه -> برای بقیه ۲/۴ ، برای خودش کازینوی فعالی نیست
    await press(users[51], chats[51], panels[51], f"rr_gleave:{rid}:51")
    assert len(players_of(rid)) == 2 and bal(51) == 1_000_000_000
    assert "(2/4)" in BOT.last_edit(panels[52])[2] and "(2/4)" in BOT.last_edit(panels[53])[2]
    assert "خارج شدی" in BOT.last_edit(panels[51])[2]
    s = db.get_session()
    assert not casino._user_has_active_round(s, 51)
    s.close()
    ok("leave: others see 2/4, leaver released + refunded, others cannot press it")

    # خودش می‌تونه دوباره بره میزِ جدید یا همون میز
    panels[51] = new_panel(chats[51].id)
    await press(users[51], chats[51], panels[51], f"rr_gjoin:51:{T}:4")
    assert len(players_of(rid)) == 3
    await press(users[54], chats[54], panels[54], f"rr_gjoin:54:{T}:4")
    r = rnd(rid)
    assert r.status == "playing" and len(players_of(rid)) == 4
    # هر پلیر پنلِ خودش رو داره و نوبتِ کی نشون داده می‌شه
    holder = r.turn_user_id
    for u in uids:
        e = BOT.last_edit(panels[u])
        assert "نوبتِ" in e[2], e[2]
    assert "نوبتِ توئه" in BOT.last_edit(panels[holder])[2]
    ok("global game starts on every player's own panel; holder sees 'your turn'")

    # پینگِ «نوبتِ توئه» برایِ کسی که نوبتشه (تو گپِ خودش)
    assert any(c == chats[holder].id and "نوبتِ توئه" in t for c, t, _m in BOT.sent)

    # نوبتِ دیگری: دکمه رو می‌شه از پنلِ خودش زد ولی جواب «نوبتِ تو نیست» می‌گیره
    other = [u for u in uids if u != holder][0]
    q = await press(users[other], chats[other], panels[other], f"rr_fire:{rid}:{r.turn_seq}")
    assert last_alert(q)[1] is True and rnd(rid).chamber_idx == 0

    r = await play_out(rid, users, chats, panels)
    assert r.status == "resolved" and r.winner_id in uids
    assert bal(r.winner_id) == 1_000_000_000 - T + 4 * T
    assert abs(total_money(uids) - before) < 1e-3
    for u in uids:
        s = db.get_session()
        assert not casino._user_has_active_round(s, u)
        s.close()
        assert "پایان بازی" in BOT.last_edit(panels[u])[2]
    ok("global full game: winner gets 4x pot, all panels finalized, all released")


async def test_global_timeout_and_expiry():
    print("test_global_timeout_and_expiry")
    uids = [61, 62, 63]
    for u in uids:
        mk_user(u, 5_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-300000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    T = 500_000_000
    await press(users[61], chats[61], panels[61], f"rr_gjoin:61:{T}:3")
    rid = latest_round_id("global")
    await press(users[62], chats[62], panels[62], f"rr_gjoin:62:{T}:3")
    # ۵ دقیقه: هنوز لغو نشده
    s = db.get_session()
    r = s.get(db.RouletteRound, rid)
    r.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=300)
    s.commit()
    s.close()
    await roulette._lobby_timeout(ctx_for(61), rid)
    assert rnd(rid).status == "lobby"
    # ۶ دقیقه گذشت -> لغو، پنلِ همه ادیت، پول برگشت
    s = db.get_session()
    r = s.get(db.RouletteRound, rid)
    r.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=361)
    s.commit()
    s.close()
    await roulette.tick_roulette(db.get_session(), ctx_for(61))
    assert rnd(rid).status == "cancelled"
    assert bal(61) == 5_000_000_000 and bal(62) == 5_000_000_000
    assert "۶ دقیقه" in BOT.last_edit(panels[61])[2] or "6 دقیقه" in BOT.last_edit(panels[61])[2]
    assert "لغو" in BOT.last_edit(panels[62])[2]
    for u in (61, 62):
        s = db.get_session()
        assert not casino._user_has_active_round(s, u)
        s.close()
    ok("global 6-minute expiry: cancelled, refunded, everyone released (next day works)")

    # میزی که کمتر از ۱۵ ثانیه به لغوش مونده به آدمِ جدید داده نمی‌شه
    panels[61] = new_panel(chats[61].id)
    await press(users[61], chats[61], panels[61], f"rr_gjoin:61:{T}:3")
    rid_old = latest_round_id("global")
    s = db.get_session()
    r = s.get(db.RouletteRound, rid_old)
    r.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=355)
    s.commit()
    s.close()
    await press(users[62], chats[62], panels[62], f"rr_gjoin:62:{T}:3")
    rid_new = latest_round_id("global")
    assert rid_new != rid_old
    await roulette._lobby_timeout(ctx_for(61), rid_old)  # (۳۵۵ ثانیه: هنوز منقضی نشده)
    s = db.get_session()
    r = s.get(db.RouletteRound, rid_old)
    r.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=400)
    s.commit()
    s.close()
    await roulette._lobby_timeout(ctx_for(61), rid_old)
    assert rnd(rid_old).status == "cancelled" and rnd(rid_new).status == "lobby"
    await press(users[62], chats[62], panels[62], f"rr_gleave:{rid_new}:62")
    ok("nearly-expired table is not offered to newcomers")

    # ۱۲۰ ثانیه نوبت: شلیک نکنه حذف می‌شه (۳ نفر -> بازی ادامه)
    panels = {u: new_panel(chats[u].id) for u in uids}
    for u in uids:
        await press(users[u], chats[u], panels[u], f"rr_gjoin:{u}:{T}:3")
    rid = latest_round_id("global")
    r = rnd(rid)
    assert r.status == "playing"
    holder = r.turn_user_id
    seq = r.turn_seq
    # زودتر از موعد: تایم‌اوت اثری نداره
    await roulette._turn_timeout(ctx_for(holder), rid, seq)
    assert rnd(rid).turn_seq == seq
    s = db.get_session()
    r = s.get(db.RouletteRound, rid)
    r.turn_deadline_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
    s.commit()
    s.close()
    await roulette.tick_roulette(db.get_session(), ctx_for(holder))
    r = rnd(rid)
    assert dict(players_of(rid))[holder] is False
    assert r.status == "playing" and r.turn_seq == seq + 1 and r.turn_user_id != holder
    s = db.get_session()
    assert not casino._user_has_active_round(s, holder)  # حذف‌شده آزاده
    s.close()
    assert "حذف شد" in BOT.last_edit(panels[holder])[2]
    ok("AFK holder eliminated after 120s, game continues, eliminated player released")
    # تایمرِ قدیمی (seq قبلی) نباید نوبتِ جدید رو بخوره
    await roulette._turn_timeout(ctx_for(holder), rid, seq)
    assert rnd(rid).turn_seq == seq + 1 and [a for _, a in players_of(rid)].count(True) == 2
    ok("stale timer for old turn is ignored")
    # نفرِ بعدی هم AFK: بازی تموم و آخری برنده
    r = rnd(rid)
    holder2 = r.turn_user_id
    s = db.get_session()
    rr = s.get(db.RouletteRound, rid)
    rr.turn_deadline_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
    s.commit()
    s.close()
    await roulette._turn_timeout(ctx_for(holder2), rid, r.turn_seq)
    r = rnd(rid)
    assert r.status == "resolved"
    winner = r.winner_id
    assert winner not in (holder, holder2)
    assert bal(winner) == 5_000_000_000 - T + 3 * T
    assert bal(holder) == 5_000_000_000 - T and bal(holder2) == 5_000_000_000 - T
    s = db.get_session()
    for u in uids:
        assert not casino._user_has_active_round(s, u)
    s.close()
    ok("last survivor by forfeit wins pot; nobody stuck")


async def test_two_player_afk_and_concurrency():
    print("test_two_player_afk_and_concurrency")
    for u in (71, 72, 73, 74):
        mk_user(u, 10_000_000)
    users = {u: FakeUser(u) for u in (71, 72, 73, 74)}
    chat = FakeChat(-400001)
    panel = new_panel(chat.id)
    await press(users[71], chat, panel, "rr_new:71")
    await press(users[71], chat, panel, "rr_mode_group:71")
    rid = latest_round_id("group")
    await press(users[71], chat, panel, f"rr_amt_pick:{rid}:1000")
    await press(users[71], chat, panel, f"rr_plr_pick:{rid}:2")
    await press(users[71], chat, panel, f"rr_start:{rid}")
    # پنج کلیکِ هم‌زمان رو «پیوستن» (۳ نفرِ مختلف): فقط ۱ نفر جا داره
    qs = await asyncio.gather(*[press(users[u], chat, panel, f"rr_join:{rid}") for u in (72, 73, 74, 72, 73)])
    r = rnd(rid)
    assert r.status == "playing" and len(players_of(rid)) == 2
    joined = [u for u, _ in players_of(rid)]
    total = sum(bal(u) for u in (71, 72, 73, 74))
    assert total == 40_000_000 - 2000
    ok("concurrent joins: capacity respected, money charged once")

    # دبل‌کلیک هم‌زمانِ شلیک: فقط یک بار پردازش می‌شه
    holder = r.turn_user_id
    await asyncio.gather(*[press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}") for _ in range(5)])
    r2 = rnd(rid)
    if r2.status == "playing":
        assert r2.turn_seq == r.turn_seq + 1
        assert (r2.chamber_idx == 1) or (r2.chamber_idx == 0)  # کلیک یا (کشته شدن → پایان)
    ok("concurrent fire double-click processed exactly once")

    # دونفره: AFK => حریف برنده
    if rnd(rid).status == "playing":
        rr = rnd(rid)
        s = db.get_session()
        x = s.get(db.RouletteRound, rid)
        x.turn_deadline_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
        s.commit()
        s.close()
        await roulette._turn_timeout(ctx_for(rr.turn_user_id), rid, rr.turn_seq)
    r = rnd(rid)
    assert r.status == "resolved"
    assert bal(r.winner_id) == 10_000_000 - 1000 + 2000
    ok("2-player: AFK loses, opponent wins pot")


async def test_concurrent_global_matchmaking():
    print("test_concurrent_global_matchmaking")
    uids = list(range(81, 89))
    for u in uids:
        mk_user(u, 2_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-500000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    T = 1_000_000
    # ۸ نفرِ هم‌زمان، همه میزِ ۴نفره‌ی یک میلیونی -> باید دقیقاً ۲ میزِ کامل بسازن
    await asyncio.gather(*[press(users[u], chats[u], panels[u], f"rr_gjoin:{u}:{T}:4") for u in uids])
    s = db.get_session()
    tables = s.query(db.RouletteRound).filter(db.RouletteRound.mode == "global",
                                              db.RouletteRound.entry_amount == T,
                                              db.RouletteRound.target_players == 4).all()
    ids = [t.id for t in tables if len(roulette._all_players(s, t.id)) > 0]
    counts = sorted(len(roulette._all_players(s, i)) for i in ids)
    s.close()
    assert counts == [4, 4], counts
    for i in ids:
        assert rnd(i).status == "playing"
    total = sum(bal(u) for u in uids)
    assert total == 8 * 2_000_000_000 - 8 * T
    # بازی‌ها رو تموم کن
    for i in ids:
        pl = [u for u, _ in players_of(i)]
        await play_out(i, users, chats, panels)
    assert sum(bal(u) for u in uids) == 8 * 2_000_000_000
    ok("8 concurrent global joins -> exactly two full 4-player tables, money conserved")


async def test_max_bet_and_private():
    print("test_max_bet_and_private")
    mk_user(91, 10_000_000_000)
    u = FakeUser(91)
    chat = FakeChat(91, "private")
    panel = new_panel(chat.id)
    await press(u, chat, panel, "rr_new:91")
    # تو پیوی مستقیم می‌ره سراغِ لابیِ جهانی
    assert "لابیِ جهانی" in BOT.last_edit(panel)[2]
    q = await press(u, chat, panel, "rr_mode_group:91")
    assert last_alert(q)[1] is True
    s = db.get_session()
    db.cfg_set(s, "casino_max_bet", "50000000")
    s.close()
    await press(u, chat, panel, "rr_mode_global:91")
    labels = [b.text for row in BOT.last_edit(panel)[3].inline_keyboard for b in row]
    assert any("1,000,000" in l for l in labels) and not any("500,000,000" in l for l in labels) and not any("100,000,000" in l for l in labels)
    q = await press(u, chat, panel, "rr_gjoin:91:500000000:2")
    assert last_alert(q)[1] is True and bal(91) == 10_000_000_000
    s = db.get_session()
    db.cfg_set(s, "casino_max_bet", "0")
    s.close()
    ok("private chat goes straight to global; casino_max_bet respected")

    # موجودی ناکافی
    mk_user(92, 100)
    u2 = FakeUser(92)
    chat2 = FakeChat(-600000)
    p2 = new_panel(chat2.id)
    q = await press(u2, chat2, p2, "rr_gjoin:92:1000000:2")
    assert last_alert(q)[0].startswith("موجودی کافی نیست")
    assert bal(92) == 100
    ok("insufficient balance rejected")


async def test_classic_casino_interplay():
    print("test_classic_casino_interplay")
    mk_user(101, 1_000_000)
    u = FakeUser(101)
    chat = FakeChat(-700000)
    panel = new_panel(chat.id)
    # منوی کازینو دکمه‌ی رولت داره
    kb = casino.casino_menu_keyboard(101)
    assert any("rr_new:101" in (b.callback_data or "") for row in kb.inline_keyboard for b in row)
    # وسطِ رولتِ گروهی نمی‌شه کازینوی کلاسیک باز کرد و برعکس
    await press(u, chat, panel, "rr_new:101")
    await press(u, chat, panel, "rr_mode_group:101")
    p2 = new_panel(chat.id)
    q = await press(u, chat, p2, "casino_game:bw:101")
    assert last_alert(q)[0].startswith("⛔️ تو همین الان")
    await press(u, chat, panel, f"rr_back:{latest_round_id('group')}")
    q = await press(u, chat, p2, "casino_game:bw:101")
    s = db.get_session()
    assert casino._user_has_active_round(s, 101) is True  # کلاسیک setup فعال
    s.close()
    q = await press(u, chat, p2, "rr_new:101")
    assert last_alert(q)[0].startswith("⛔️ تو همین الان")
    ok("roulette and classic casino block each other while active")

    # کنسلِ پرامپتِ مبلغِ دلخواهِ کلاسیک: پنل برمی‌گرده
    s = db.get_session()
    cr = s.query(db.CasinoRound).order_by(db.CasinoRound.id.desc()).first()
    cid = cr.id
    s.close()
    await press(u, chat, p2, f"casino_amt_custom:{cid}")
    assert ctx_for(101).user_data.get("casino_awaiting")
    await press(u, chat, p2, f"casino_amtx:{cid}")
    assert not ctx_for(101).user_data.get("casino_awaiting")
    assert "مبلغ ورودی" in BOT.last_edit(p2)[2] and BOT.last_edit(p2)[3] is not None
    # مبلغِ نامعتبر تو کلاسیک: پنل دوباره سرِ جاشه
    await press(u, chat, p2, f"casino_amt_custom:{cid}")
    upd = FakeUpdate(u, chat, text="xx")
    try:
        await casino.casino_awaiting_handler(upd, ctx_for(101))
    except ApplicationHandlerStop:
        pass
    e = BOT.last_edit(p2)
    assert "مقدار اشتباه" in e[2] and e[3] is not None
    ok("classic casino: cancel/invalid custom amount keeps panel alive")

    # اونو هم جزوِ «وسطِ کازینو» شمرده می‌شه
    s = db.get_session()
    s.add(db.UnoRound(chat_id=1, message_id=1, initiator_id=555, status="lobby"))
    s.commit()
    assert casino._user_has_active_round(s, 555) is True
    s.close()
    ok("uno counts as active casino too")


async def test_message_deleted_fallback():
    print("test_message_deleted_fallback")
    uids = [111, 112]
    for u in uids:
        mk_user(u, 1_000_000)
    users = {u: FakeUser(u) for u in uids}
    chat = FakeChat(-800000)
    panel = new_panel(chat.id)
    await press(users[111], chat, panel, "rr_new:111")
    await press(users[111], chat, panel, "rr_mode_group:111")
    rid = latest_round_id("group")
    await press(users[111], chat, panel, f"rr_amt_pick:{rid}:100")
    await press(users[111], chat, panel, f"rr_plr_pick:{rid}:2")
    await press(users[111], chat, panel, f"rr_start:{rid}")
    BOT.fail_edit_ids.add(panel)  # پیامِ لابی پاک شده
    await press(users[112], chat, panel, f"rr_join:{rid}")
    r = rnd(rid)
    assert r.status == "playing" and r.message_id != panel  # پیامِ جدید فرستاده و ذخیره شد
    new_panel_id = r.message_id
    chats = {u: chat for u in uids}
    panels = {u: new_panel_id for u in uids}
    r = await play_out(rid, users, chats, panels)
    assert r.status == "resolved"
    ok("deleted panel message -> new message sent, game still completes")


def set_gun(rid, bullet_pos, chamber_idx=0, layout=None):
    """خشابِ پیش‌فرض (۵ مشقی + ۱ جنگی) با تیرِ جنگی تو خونه‌ی bullet_pos، یا چیدمانِ دلخواه."""
    s = db.get_session()
    r = s.get(db.RouletteRound, rid)
    r.chambers = layout or ("B" * bullet_pos + "L" + "B" * (5 - bullet_pos))
    r.chamber_idx = chamber_idx
    s.commit()
    s.close()


def all_buttons(msg_id):
    kb = BOT.last_edit(msg_id)[3]
    return [b for row in kb.inline_keyboard for b in row] if kb else []


async def start_group_game(base_uid, n, chat_id, stake=1000):
    uids = [base_uid + i for i in range(n)]
    for u in uids:
        mk_user(u, 10_000_000)
    users = {u: FakeUser(u) for u in uids}
    chat = FakeChat(chat_id)
    panel = new_panel(chat.id)
    await press(users[uids[0]], chat, panel, f"rr_new:{uids[0]}")
    await press(users[uids[0]], chat, panel, f"rr_mode_group:{uids[0]}")
    rid = latest_round_id("group")
    await press(users[uids[0]], chat, panel, f"rr_amt_pick:{rid}:{stake}")
    await press(users[uids[0]], chat, panel, f"rr_plr_pick:{rid}:{n}")
    await press(users[uids[0]], chat, panel, f"rr_start:{rid}")
    for u in uids[1:]:
        await press(users[u], chat, panel, f"rr_join:{rid}")
    assert rnd(rid).status == "playing"
    return rid, uids, users, chat, panel


def reason_of(rid, uid):
    s = db.get_session()
    try:
        return roulette._get_player(s, rid, uid).out_reason
    finally:
        s.close()


async def test_shoot_other():
    print("test_shoot_other")
    # ---- تیرِ جنگی: هدف می‌میره، شلیک‌کننده زنده می‌مونه
    rid, uids, users, chat, panel = await start_group_game(2000, 3, -410001)
    r = rnd(rid)
    holder = r.turn_user_id
    tgt = [u for u in uids if u != holder][0]
    third = [u for u in uids if u not in (holder, tgt)][0]
    # پنلِ گروه: دکمه‌ی شلیک به خودش + یه دکمه به ازایِ هر حریفِ زنده
    datas = [b.callback_data for b in all_buttons(panel)]
    assert f"rr_fire:{rid}:{r.turn_seq}" in datas
    assert sorted(d for d in datas if d.startswith("rr_shoot")) == sorted(
        f"rr_shoot:{rid}:{r.turn_seq}:{u}" for u in uids if u != holder)
    txt0 = BOT.last_edit(panel)[2]
    assert "شلیک به دیگری" in txt0
    set_gun(rid, bullet_pos=0, chamber_idx=0)
    # ۱) غیرِ نوبت‌دار نمی‌تونه شلیک کنه (نه به خودش نه به دیگری)
    q = await press(users[tgt], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:{third}")
    assert last_alert(q)[1] is True and rnd(rid).turn_seq == r.turn_seq
    assert all(a for _, a in players_of(rid))
    # ۲) هدفِ نامعتبر: خودش / کسی که تو بازی نیست
    q = await press(users[holder], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:{holder}")
    assert last_alert(q)[1] is True and rnd(rid).turn_seq == r.turn_seq
    q = await press(users[holder], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:424242")
    assert last_alert(q)[1] is True and rnd(rid).turn_seq == r.turn_seq
    # ۳) seq قدیمی
    q = await press(users[holder], chat, panel, f"rr_shoot:{rid}:{r.turn_seq + 3}:{tgt}")
    assert rnd(rid).turn_seq == r.turn_seq and all(a for _, a in players_of(rid))
    assert rnd(rid).chamber_idx == 0
    # ۴) شلیکِ واقعی: تیرِ جنگی
    q = await press(users[holder], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:{tgt}")
    st = dict(players_of(rid))
    assert st[tgt] is False and st[holder] is True and st[third] is True
    assert "شلیک موفق جنگی از طرف" in reason_of(rid, tgt)
    assert users[holder].username in reason_of(rid, tgt)
    r2 = rnd(rid)
    assert r2.status == "playing" and r2.turn_seq == r.turn_seq + 1 and r2.chamber_idx == 0
    assert r2.turn_user_id in (holder, third)
    txt = BOT.last_edit(panel)[2]
    assert f"شلیک موفق جنگی از طرف @{users[holder].username}" in txt and "☠️" in txt
    # مرده دیگه نه می‌تونه شلیک کنه نه هدف بشه
    q = await press(users[tgt], chat, panel, f"rr_fire:{rid}:{r2.turn_seq}")
    assert last_alert(q)[1] is True
    if r2.turn_user_id == holder:
        q = await press(users[holder], chat, panel, f"rr_shoot:{rid}:{r2.turn_seq}:{tgt}")
        assert last_alert(q)[1] is True and rnd(rid).turn_seq == r2.turn_seq
    # دکمه‌ها فقط به زنده‌ها
    datas = [b.callback_data for b in all_buttons(panel)]
    assert not any(d.endswith(f":{tgt}") for d in datas if d.startswith("rr_shoot"))
    ok("live shot at other: target dies (reason shown), shooter lives, gun reloaded, guards work")

    # ---- بازی رو تموم کن
    chats = {u: chat for u in uids}
    panels = {u: panel for u in uids}
    r = await play_out(rid, users, chats, panels)
    assert r.status == "resolved"

    # ---- تیرِ مشقی: شلیک‌کننده حذف می‌شه و هدف زنده می‌مونه
    rid, uids, users, chat, panel = await start_group_game(2100, 3, -410002)
    r = rnd(rid)
    holder = r.turn_user_id
    tgt = [u for u in uids if u != holder][0]
    set_gun(rid, bullet_pos=3, chamber_idx=0)
    await press(users[holder], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:{tgt}")
    st = dict(players_of(rid))
    assert st[holder] is False and st[tgt] is True
    assert reason_of(rid, holder) == f"حذف شد (به دلیل شلیک ناموفق به @{users[tgt].username})"
    r2 = rnd(rid)
    assert r2.status == "playing" and r2.chamber_idx == 1 and r2.chambers == "BBBLBB"  # خشاب ری‌لود نشد
    assert r2.turn_user_id != holder
    assert f"به دلیل شلیک ناموفق به @{users[tgt].username}" in BOT.last_edit(panel)[2]
    s = db.get_session()
    assert not casino._user_has_active_round(s, holder)
    s.close()
    ok("blank shot at other: shooter eliminated with reason, target lives, chamber advanced")

    # ---- دونفره: هر دو نتیجه بازی رو تموم می‌کنه و پول درست جابه‌جا می‌شه
    for live in (True, False):
        rid, uids, users, chat, panel = await start_group_game(2200 + (10 if live else 20), 2, -410003 - int(live))
        r = rnd(rid)
        holder = r.turn_user_id
        other = [u for u in uids if u != holder][0]
        set_gun(rid, bullet_pos=0 if live else 4, chamber_idx=0)
        await press(users[holder], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:{other}")
        r = rnd(rid)
        assert r.status == "resolved"
        winner = holder if live else other
        loser = other if live else holder
        assert r.winner_id == winner
        assert bal(winner) == 10_000_000 - 1000 + 2000 and bal(loser) == 10_000_000 - 1000
        final = BOT.last_edit(panel)[2]
        assert "پایان بازی" in final and ("شلیک موفق جنگی از طرف" in final if live else "شلیک ناموفق" in final)
        s = db.get_session()
        assert not casino._user_has_active_round(s, holder) and not casino._user_has_active_round(s, other)
        s.close()
    ok("2-player: live shot -> shooter wins, blank shot -> target wins, pot paid, all released")

    # ---- شلیک به خودم هنوز مثلِ قبل کار می‌کنه؛ آخرین خونه = قطعاً جنگی
    rid, uids, users, chat, panel = await start_group_game(2300, 3, -410010)
    r = rnd(rid)
    holder = r.turn_user_id
    set_gun(rid, bullet_pos=5, chamber_idx=5)
    q = await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
    assert dict(players_of(rid))[holder] is False
    assert reason_of(rid, holder) == "کشته شد (تیرِ جنگی به خودش)"
    assert rnd(rid).chamber_idx == 0
    ok("self shot still works (reason recorded, reload)")

    # ---- لابیِ جهانی: پنلِ نوبت‌دار دکمه‌ی شلیک داره، بقیه فقط «نوبتِ X»
    uids = [2400, 2401, 2402]
    for u in uids:
        mk_user(u, 1_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-420000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    for u in uids:
        await press(users[u], chats[u], panels[u], f"rr_gjoin:{u}:1000000:3")
    rid = latest_round_id("global")
    r = rnd(rid)
    assert r.status == "playing"
    holder = r.turn_user_id
    for u in uids:
        datas = [b.callback_data for b in all_buttons(panels[u])]
        if u == holder:
            assert f"rr_fire:{rid}:{r.turn_seq}" in datas
            assert len([d for d in datas if d.startswith("rr_shoot")]) == 2
        else:
            assert datas == ["rr_noop"], datas
    # کسی که نوبتش نیست حتی با دکمه‌ی دستی هم نمی‌تونه
    other = [u for u in uids if u != holder][0]
    third = [u for u in uids if u not in (holder, other)][0]
    q = await press(users[other], chats[other], panels[other], f"rr_shoot:{rid}:{r.turn_seq}:{third}")
    assert last_alert(q)[1] is True and all(a for _, a in players_of(rid))
    set_gun(rid, bullet_pos=0, chamber_idx=0)
    await press(users[holder], chats[holder], panels[holder], f"rr_shoot:{rid}:{r.turn_seq}:{other}")
    for u in uids:
        assert f"شلیک موفق جنگی از طرف @{users[holder].username}" in BOT.last_edit(panels[u])[2]
    # دکمه‌ی noop بی‌خطره
    q = await press(users[other], chats[other], panels[other], "rr_noop")
    ok("global: only the holder's panel has fire/shoot buttons; reasons shown on all panels")

    # ---- کلیکِ هم‌زمانِ چندنفره رویِ «شلیک به دیگری»: فقط یک‌بار پردازش
    rid, uids, users, chat, panel = await start_group_game(2500, 4, -410020)
    r = rnd(rid)
    holder = r.turn_user_id
    tg = [u for u in uids if u != holder]
    set_gun(rid, bullet_pos=0, chamber_idx=0)
    await asyncio.gather(*[press(users[holder], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:{t}") for t in tg])
    dead = [u for u, a in players_of(rid) if not a]
    assert len(dead) == 1, dead
    ok("concurrent multi-target clicks: exactly one shot resolved")


class fast_sleep:
    """asyncio.sleep رو تو تست‌ها سریع می‌کنه (مثلاً تایمِ بین تلاش‌هایِ ادیت)."""
    def __enter__(self):
        self._orig = asyncio.sleep

        async def quick(delay, *a, **k):
            await self._orig(0)
        asyncio.sleep = quick
        return self

    def __exit__(self, *a):
        asyncio.sleep = self._orig


def cancel_all_lobbies():
    s = db.get_session()
    for r in s.query(db.RouletteRound).filter(db.RouletteRound.status.in_(("lobby", "setup"))).all():
        r.status = "cancelled"
    s.commit()
    s.close()


async def classic_lobby(owner, chat, panel, game="bw", n=4, amount=1000):
    await press(FakeUser(owner), chat, panel, f"casino_game:{game}:{owner}")
    s = db.get_session()
    rid = s.query(db.CasinoRound).order_by(db.CasinoRound.id.desc()).first().id
    s.close()
    await press(FakeUser(owner), chat, panel, f"casino_amt_pick:{rid}:{amount}")
    if game not in ("bk", "fb", "ws"):
        await press(FakeUser(owner), chat, panel, f"casino_plr_pick:{rid}:{n}")
    await press(FakeUser(owner), chat, panel, f"casino_start:{rid}")
    return rid


def crnd(rid):
    s = db.get_session()
    try:
        r = s.get(db.CasinoRound, rid)
        s.expunge(r)
        return r
    finally:
        s.close()


async def test_classic_timeout_text_and_dead_buttons():
    print("test_classic_timeout_text_and_dead_buttons")
    mk_user(3001, 1_000_000)
    mk_user(3002, 1_000_000)
    chat = FakeChat(-930001)
    panel = new_panel(chat.id)
    rid = await classic_lobby(3001, chat, panel)
    assert crnd(rid).status == "lobby" and bal(3001) == 999_000
    # تایم‌اوت وقتی فقط سازنده هست: «هیچ هاپویی نیومد» + پول برگشت + دکمه‌ها برداشته
    s = db.get_session()
    x = s.get(db.CasinoRound, rid)
    x.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=120)
    s.commit()
    s.close()
    await casino._casino_timeout_core(ctx_for(3001), rid)
    e = BOT.last_edit(panel)
    assert crnd(rid).status == "cancelled" and bal(3001) == 1_000_000
    assert "هیچ هاپویی نیومد" in e[2] and e[3] is None
    s = db.get_session()
    assert not casino._user_has_active_round(s, 3001)
    s.close()
    ok("classic lobby timeout: 'no hopoo came', refund, buttons removed, creator released")

    # ادیتِ پیام به‌خاطرِ خطای موقتی شکست می‌خوره -> دکمه‌ها می‌مونن (سناریوی گزارش‌شده)
    panel = new_panel(chat.id)
    rid = await classic_lobby(3001, chat, panel)
    s = db.get_session()
    x = s.get(db.CasinoRound, rid)
    x.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=120)
    s.commit()
    s.close()
    BOT.transient[panel] = 1000
    with fast_sleep():
        await casino._casino_timeout_core(ctx_for(3001), rid)
    assert crnd(rid).status == "cancelled" and bal(3001) == 1_000_000
    assert "در انتظار بازیکن" in BOT.last_edit(panel)[2]       # پیام هنوز کهنه‌ست
    assert (chat.id, panel) in BOT.stripped                      # ولی حداقل تلاش شد دکمه‌ها برداشته بشه
    BOT.transient[panel] = 0
    # کاربر رویِ دکمه‌ی مرده می‌زنه: به‌جایِ فقط «فعال نیست»، پیام درست می‌شه
    q = await press(FakeUser(3002), chat, panel, f"casino_join:{rid}")
    assert last_alert(q)[1] is True
    e = BOT.last_edit(panel)
    assert "هیچ هاپویی نیومد" in e[2] and e[3] is None
    assert bal(3002) == 1_000_000
    # و کازینوی جدید بدونِ «نیمه‌کاره داری» ساخته می‌شه
    panel2 = new_panel(chat.id)
    rid2 = await classic_lobby(3001, chat, panel2)
    assert crnd(rid2).status == "lobby"
    await press(FakeUser(3001), chat, panel2, f"casino_cancel:{rid2}")
    ok("dead classic buttons heal on press; new casino works right after cancel")

    # جاروبِ سریع هم لغوِ لابی رو با متنِ درست انجام می‌ده و به چیزی دوباره ریفاند نمی‌ده
    panel3 = new_panel(chat.id)
    rid3 = await classic_lobby(3001, chat, panel3)
    s = db.get_session()
    x = s.get(db.CasinoRound, rid3)
    x.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=90)
    s.commit()
    s.close()
    before = bal(3001)
    await casino.sweep_stale_rounds(ctx_for(3001))
    await casino._casino_timeout_core(ctx_for(3001), rid3)    # تایمرِ خودِ دور بعدِ جاروب: بی‌اثر
    await casino.sweep_stale_rounds(ctx_for(3001))
    assert crnd(rid3).status == "cancelled" and bal(3001) == before + 1000
    assert "هیچ هاپویی نیومد" in BOT.last_edit(panel3)[2]
    ok("sweep + timer on same round: refunded exactly once")

    # لابیِ ۲نفره‌ی نیمه‌پر: متنِ «تعدادِ کافی نیومد» ولی نه «هیچ هاپویی»
    panel4 = new_panel(chat.id)
    rid4 = await classic_lobby(3001, chat, panel4, n=4)
    await press(FakeUser(3002), chat, panel4, f"casino_join:{rid4}")
    s = db.get_session()
    x = s.get(db.CasinoRound, rid4)
    x.lobby_opened_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=120)
    s.commit()
    s.close()
    await casino._casino_timeout_core(ctx_for(3001), rid4)
    e = BOT.last_edit(panel4)
    assert "(2/4)" in e[2] and "هیچ هاپویی" not in e[2]
    assert bal(3001) == before + 1000 and bal(3002) == 1_000_000
    ok("classic partial lobby: correct text, everyone refunded")


async def test_classic_dice_failure_refunds():
    print("test_classic_dice_failure_refunds")
    # FakeBot عمداً send_dice نداره => همون خطای «تلگرام کار نکرد»
    for u in (3101, 3102, 3103):
        mk_user(u, 1_000_000)
    chat = FakeChat(-930002)
    panel = new_panel(chat.id)
    rid = await classic_lobby(3101, chat, panel, game="bw", n=2)
    await press(FakeUser(3102), chat, panel, f"casino_join:{rid}")
    assert crnd(rid).status == "cancelled"
    assert bal(3101) == 1_000_000 and bal(3102) == 1_000_000
    assert "⚠️" in BOT.last_edit(panel)[2]
    s = db.get_session()
    assert not casino._user_has_active_round(s, 3101) and not casino._user_has_active_round(s, 3102)
    s.close()
    ok("result phase failure: cancelled, everyone refunded, nobody stuck")

    panel = new_panel(chat.id)
    await press(FakeUser(3103), chat, panel, "casino_game:ws:3103")
    s = db.get_session()
    rid = s.query(db.CasinoRound).order_by(db.CasinoRound.id.desc()).first().id
    s.close()
    await press(FakeUser(3103), chat, panel, f"casino_amt_pick:{rid}:5000")
    await press(FakeUser(3103), chat, panel, f"casino_start:{rid}")
    assert crnd(rid).status == "cancelled" and bal(3103) == 1_000_000
    ok("solo game dice failure: stake refunded")


async def test_global_panels_stay_in_sync_under_load():
    print("test_global_panels_stay_in_sync_under_load")
    cancel_all_lobbies()
    uids = [3201, 3202, 3203, 3204]
    for u in uids:
        mk_user(u, 1_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-940000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    T = 1_000_000
    for u in uids[:3]:
        await press(users[u], chats[u], panels[u], f"rr_gjoin:{u}:{T}:4")
    rid = latest_round_id("global")
    assert "(3/4)" in BOT.last_edit(panels[3203])[2]
    # ۲ تا از پنل‌ها موقعِ شروعِ بازی خطای موقتی (فلود/تایم‌اوت) می‌گیرن
    BOT.transient[panels[3203]] = 10_000
    BOT.transient[panels[3204]] = 10_000
    with fast_sleep():
        await press(users[3204], chats[3204], panels[3204], f"rr_gjoin:3204:{T}:4")
        await asyncio.sleep(0)   # اجازه‌ی تلاش‌هایِ پس‌زمینه
        for _ in range(20):
            await asyncio.sleep(0)
    r = rnd(rid)
    assert r.status == "playing"
    for u in (3201, 3202):
        assert "نوبتِ" in BOT.last_edit(panels[u])[2]
    for u in (3203, 3204):
        e = BOT.last_edit(panels[u])
        assert e is None or "نوبتِ" not in e[2]   # هنوز رویِ صفحه‌ی قبلی (عضوگیری/منوی انتخاب)
    ok("simulated flood: 2 panels stuck on lobby while game already started")

    # ۱) کاربرِ گیرکرده رویِ «منصرف شدم»ِ کهنه می‌زنه: نه خارج می‌شه نه چیزی خراب می‌شه،
    #    پنلش با بازیِ واقعی ادیت می‌شه
    BOT.transient[panels[3203]] = 0
    BOT.transient[panels[3204]] = 0
    q = await press(users[3203], chats[3203], panels[3203], f"rr_gleave:{rid}:3203")
    assert last_alert(q)[1] is True
    assert "نوبتِ" in BOT.last_edit(panels[3203])[2]
    assert len(players_of(rid)) == 4 and bal(3203) == 1_000_000_000 - T
    ok("stale lobby button heals the panel (does not leave the running game)")

    # ۲) پنلِ ۴ هم بدونِ هیچ کلیکی، با جاروب/همگام‌سازی درست می‌شه
    e = BOT.last_edit(panels[3204])
    assert e is None or "نوبتِ" not in e[2]
    roulette._dirty[rid] = 6
    await roulette.tick_roulette(db.get_session(), ctx_for(3201))
    assert "نوبتِ" in BOT.last_edit(panels[3204])[2]
    ok("background resync fixes panels without any click")

    # بازی عادی ادامه پیدا می‌کنه
    r = await play_out(rid, users, chats, panels)
    assert r.status == "resolved"
    for u in uids:
        assert "پایان بازی" in BOT.last_edit(panels[u])[2]


async def test_full_lobby_never_stuck():
    print("test_full_lobby_never_stuck")
    cancel_all_lobbies()
    uids = [3301, 3302]
    for u in uids:
        mk_user(u, 1_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-950000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    T = 1_000_000
    await press(users[3301], chats[3301], panels[3301], f"rr_gjoin:3301:{T}:2")
    rid = latest_round_id("global")
    # نفرِ دوم: پول کم شد و ردیف اضافه شد، ولی هندلر بعدش (مثلاً answer/کرش) نصفه موند
    orig = roulette._after_join

    async def boom(context, rid_):
        raise RuntimeError("handler crashed after commit")
    roulette._after_join = boom
    try:
        try:
            await press(users[3302], chats[3302], panels[3302], f"rr_gjoin:3302:{T}:2")
        except RuntimeError:
            pass
    finally:
        roulette._after_join = orig
    r = rnd(rid)
    assert r.status == "lobby" and len(players_of(rid)) == 2   # پر ولی شروع نشده
    await roulette.tick_roulette(db.get_session(), ctx_for(3301))
    assert rnd(rid).status == "playing"
    for u in uids:
        assert "نوبتِ" in BOT.last_edit(panels[u])[2]
    r = await play_out(rid, users, chats, panels)
    assert r.status == "resolved"
    ok("full-but-unstarted lobby is started by the sweep (no permanent 'recruiting' panel)")


async def test_global_lobbies_list():
    print("test_global_lobbies_list")
    cancel_all_lobbies()
    now = datetime.datetime.utcnow()
    s = db.get_session()
    n_users = [0]

    def mk_table(target, amount, count, age):
        r = db.RouletteRound(mode="global", chat_id=-1, message_id=1, entry_amount=amount, target_players=target,
                             status="lobby", lobby_opened_at=now - datetime.timedelta(seconds=age),
                             created_at=now - datetime.timedelta(seconds=age))
        s.add(r)
        s.flush()
        for _ in range(count):
            n_users[0] += 1
            uid = 8_000_000 + n_users[0]
            s.add(db.RoulettePlayer(round_id=r.id, user_id=uid, chat_id=-1, message_id=1))
        s.commit()
        return r.id

    assert roulette.global_lobbies_text(s).count("\n") >= 1 and "هیچ لابی" in roulette.global_lobbies_text(s)
    a = mk_table(4, 1_000_000, 1, 50)         # ۱/۴ قدیمی‌تر
    b = mk_table(4, 100_000_000, 3, 10)       # ۳/۴
    c = mk_table(2, 500_000_000, 1, 5)        # ۱/۲ جدیدتر
    d = mk_table(3, 1_000_000, 2, 30)         # ۲/۳
    e = mk_table(4, 100_000_000, 4, 20)       # پر (باید حذف بشه)
    f = mk_table(4, 1_000_000, 2, 350)        # کمتر از ۱۵ ثانیه به لغوش مونده (حذف)
    rows = roulette.global_lobbies(s)
    assert [r[2] for r in rows] == [b, d, a, c], [r[2] for r in rows]
    txt = roulette.global_lobbies_text(s)
    lines = txt.split("\n")
    assert "در حالِ عضوگیری" in lines[0]
    assert lines[1].startswith("1.") and "3/4" in lines[1] and "100,000,000" in lines[1]
    assert lines[2].startswith("2.") and "2/3" in lines[2]
    assert lines[3].startswith("3.") and "1/4" in lines[3] and "1,000,000" in lines[3]
    assert lines[4].startswith("4.") and "1/2" in lines[4]
    assert "حذف می‌شه" in lines[-1]
    ok("lobby list: sorted by joined count then earliest; full/expiring tables excluded")

    # فقط ۸ تا لابیِ جدا => فقط ۸ تا؛ و بیشتر از ۱۰ => ۱۰ تا
    for i in range(4):
        mk_table(4, 1_000_000, 1, 60 + i)
    assert len(roulette.global_lobbies(s)) == 8
    for i in range(8):
        mk_table(4, 1_000_000, 1, 70 + i)
    assert len(roulette.global_lobbies(s)) == 10
    # وقتی یه لابی پر بشه و شروع بشه از لیست می‌ره
    r = s.get(db.RouletteRound, b)
    r.status = "playing"
    s.commit()
    assert b not in [x[2] for x in roulette.global_lobbies(s)]
    s.close()
    ok("lobby list: shows only what exists (8) and caps at 10; started lobbies drop out")

    # منو + دکمه‌ی به‌روزرسانی
    cancel_all_lobbies()
    text, kb = casino.menu_text_and_kb(9001)
    assert text.startswith("🎰 کازینو هاپویی") and "فعلاً هیچ لابی" in text
    assert any(b.callback_data == "casino_menu_refresh:9001" for row in kb.inline_keyboard for b in row)
    uid = 9001
    mk_user(uid, 1_000_000_000)
    other = 9002
    mk_user(other, 1_000_000_000)
    chat = FakeChat(-960001)
    panel = new_panel(chat.id)
    await press(FakeUser(other), chat, new_panel(chat.id), "rr_gjoin:9002:100000000:3")
    q = await press(FakeUser(uid), chat, panel, "casino_menu_refresh:9001")
    e = BOT.last_edit(panel)
    assert "1/3" in e[2] and "100,000,000" in e[2] and "🔫 3 نفره" in e[2]
    q = await press(FakeUser(other), chat, panel, "casino_menu_refresh:9001")
    assert last_alert(q)[1] is True
    # «بازگشت» از منوی رولت هم لیست رو نشون می‌ده
    await press(FakeUser(uid), chat, panel, "rr_new:9001")
    await press(FakeUser(uid), chat, panel, "rr_menu:9001")
    assert "1/3" in BOT.last_edit(panel)[2]
    # تریگرِ متنیِ «کازینو هاپویی»
    class TM:
        def __init__(self): self.sent = []
        async def reply_text(self, text, reply_markup=None): self.sent.append((text, reply_markup))
    upd = FakeUpdate(FakeUser(uid), chat)
    upd.message = TM()
    await casino.handle_casino_trigger(upd, ctx_for(uid))
    assert "1/3" in upd.message.sent[0][0]
    ok("casino main menu shows the global lobby list (+refresh button, back-navigation, text trigger)")
    cancel_all_lobbies()


async def test_random_simulation():
    print("test_random_simulation (300 random games)")
    random.seed(7)
    base = 2000
    uid_pool = list(range(1000, 1040))
    for u in uid_pool:
        mk_user(u, 10_000_000_000)
    users = {u: FakeUser(u) for u in uid_pool}
    total0 = sum(bal(u) for u in uid_pool)
    stuck = 0
    for g in range(300):
        set_cfg("casino_rr_blank_bullets", str(random.randint(0, 7)))     # خشابِ تصادفی: ۰..۷ مشقی
        set_cfg("casino_rr_live_bullets", str(random.randint(1, 4)))      # و ۱..۴ جنگی
        n = random.choice([2, 3, 4])
        mode = random.choice(["group", "global"])
        ps = random.sample(uid_pool, n)
        chats = {u: FakeChat(-900000 - u) for u in ps}
        panels = {u: new_panel(chats[u].id) for u in ps}
        if mode == "group":
            c = FakeChat(-999999)
            chats = {u: c for u in ps}
            pn = new_panel(c.id)
            panels = {u: pn for u in ps}
            await press(users[ps[0]], c, pn, f"rr_mode_group:{ps[0]}")
            rid = latest_round_id("group")
            await press(users[ps[0]], c, pn, f"rr_amt_pick:{rid}:{random.choice([100, 500, 1000])}")
            await press(users[ps[0]], c, pn, f"rr_plr_pick:{rid}:{n}")
            await press(users[ps[0]], c, pn, f"rr_start:{rid}")
            for u in ps[1:]:
                await press(users[u], c, pn, f"rr_join:{rid}")
        else:
            T = random.choice(roulette.GLOBAL_TIERS)
            for u in ps:
                await press(users[u], chats[u], panels[u], f"rr_gjoin:{u}:{T}:{n}")
            rid = latest_round_id("global")
        r = rnd(rid)
        assert r.status == "playing", (mode, n, r.status)
        # هر نوبت یا شلیک می‌کنه یا (با احتمالِ کم) AFK می‌شه
        steps = 0
        while rnd(rid).status == "playing":
            steps += 1
            assert steps < 100
            r = rnd(rid)
            h = r.turn_user_id
            if random.random() < 0.05:
                s = db.get_session()
                x = s.get(db.RouletteRound, rid)
                x.turn_deadline_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
                s.commit()
                s.close()
                await roulette.tick_roulette(db.get_session(), ctx_for(h))
            else:
                alive_others = [u for u, a in players_of(rid) if a and u != h]
                if alive_others and random.random() < 0.5:
                    t = random.choice(alive_others)
                    await press(users[h], chats[h], panels[h], f"rr_shoot:{rid}:{r.turn_seq}:{t}")
                else:
                    await press(users[h], chats[h], panels[h], f"rr_fire:{rid}:{r.turn_seq}")
        r = rnd(rid)
        assert r.status == "resolved"
        pl = players_of(rid)
        assert [a for _, a in pl].count(True) == 1 and r.winner_id in [u for u, a in pl if a]
        # هیچ‌کس وسطِ کازینو نمونده
        s = db.get_session()
        for u in ps:
            assert not casino._user_has_active_round(s, u), (g, u)
        s.close()
    total1 = sum(bal(u) for u in uid_pool)
    assert abs(total0 - total1) < 1e-3, (total0, total1)
    set_cfg("casino_rr_blank_bullets", "5")
    set_cfg("casino_rr_live_bullets", "1")
    ok("300 random games with random bullet counts (group+global, self/other shots+AFK): all finish, exactly 1 survivor, money conserved, nobody stuck")


def set_cfg(key, value):
    s = db.get_session()
    db.cfg_set(s, key, value)
    s.close()


def turn_times(rid):
    r = rnd(rid)
    return (r.turn_ready_at - r.turn_started_at).total_seconds(), (r.turn_deadline_at - r.turn_ready_at).total_seconds()


def shift_turn(rid, seconds):
    """زمان رو «جلو می‌بره»: همه‌ی زمان‌هایِ نوبت رو seconds ثانیه عقب می‌کشه."""
    s = db.get_session()
    r = s.get(db.RouletteRound, rid)
    d = datetime.timedelta(seconds=seconds)
    r.turn_started_at -= d
    r.turn_ready_at -= d
    r.turn_deadline_at -= d
    s.commit()
    s.close()


async def test_cylinder_settings():
    print("test_cylinder_settings")
    # چیدمانِ خشاب: تعدادِ درست، جای تیرها یکنواخت
    counts = [0] * 7
    for _ in range(7000):
        lay = roulette._new_layout(4, 3)
        assert len(lay) == 7 and lay.count("L") == 3
        for i, ch in enumerate(lay):
            counts[i] += ch == "L"
    assert all(2600 < c < 3400 for c in counts), counts   # هر خونه ≈ ۳/۷ = ۴۲٪
    assert roulette._cyl_counts("BBLBL") == (3, 2)
    ok("layout: exact blank/live counts, uniform positions")

    # ---- ۴ مشقی + ۳ جنگی: همه‌جا (منو، لابی، پنل) عوض می‌شه
    set_cfg("casino_rr_blank_bullets", "4")
    set_cfg("casino_rr_live_bullets", "3")
    text, kb = roulette._mode_menu_view(1)
    assert "4 تیرِ مشقی + 3 تیرِ جنگی (مجموع 7 تیر)" in text
    rid, uids, users, chat, panel = None, None, None, None, None
    uids = [4001, 4002, 4003]
    for u in uids:
        mk_user(u, 10_000_000)
    users = {u: FakeUser(u) for u in uids}
    chat = FakeChat(-970001)
    panel = new_panel(chat.id)
    await press(users[4001], chat, panel, "rr_new:4001")
    assert "4 تیرِ مشقی + 3 تیرِ جنگی (مجموع 7 تیر)" in BOT.last_edit(panel)[2]
    await press(users[4001], chat, panel, "rr_mode_group:4001")
    assert "مجموع 7 تیر" in BOT.last_edit(panel)[2]                    # صفحه‌ی تنظیمات
    rid = latest_round_id("group")
    await press(users[4001], chat, panel, f"rr_amt_pick:{rid}:1000")
    await press(users[4001], chat, panel, f"rr_plr_pick:{rid}:3")
    await press(users[4001], chat, panel, f"rr_start:{rid}")
    assert "4 تیرِ مشقی + 3 تیرِ جنگی" in BOT.last_edit(panel)[2]       # لابی
    await press(users[4002], chat, panel, f"rr_join:{rid}")
    await press(users[4003], chat, panel, f"rr_join:{rid}")
    r = rnd(rid)
    assert r.status == "playing" and roulette._cyl_counts(r.chambers) == (4, 3) and len(r.chambers) == 7
    e = BOT.last_edit(panel)[2]
    assert "خشاب: 4 مشقی + 3 جنگی (مجموع 7 تیر)" in e and "شانسِ تیرِ جنگیِ بعدی: 3 از 7" in e
    ok("4 blank + 3 live shown in menu, setup, lobby and game panel; layout matches")

    # کلیکِ مشقی: شانس عوض می‌شه؛ تیرِ جنگی: کشته + ری‌لودِ ۴+۳
    holder = r.turn_user_id
    set_gun(rid, 0, 0, layout="BBLLBLB")
    await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
    r = rnd(rid)
    assert r.chamber_idx == 1 and r.chambers == "BBLLBLB" and dict(players_of(rid))[holder] is True
    assert "شانسِ تیرِ جنگیِ بعدی: 3 از 6" in BOT.last_edit(panel)[2]
    holder = r.turn_user_id
    await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")          # idx 1 = B
    r = rnd(rid)
    holder = r.turn_user_id
    assert r.chamber_idx == 2 and "شانسِ تیرِ جنگیِ بعدی: 3 از 5" in BOT.last_edit(panel)[2]
    await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")          # idx 2 = L → کشته
    r = rnd(rid)
    assert dict(players_of(rid))[holder] is False and r.chamber_idx == 0
    assert roulette._cyl_counts(r.chambers) == (4, 3) and len(r.chambers) == 7
    ok("multi-live cylinder: odds update per blank click, live kill reloads 4+3")

    # شلیک به دیگری با چند تیرِ جنگی: جنگی = هدف می‌میره
    r = await play_out(rid, users, {u: chat for u in uids}, {u: panel for u in uids})
    assert r.status == "resolved"

    rid, uids, users, chat, panel = await start_group_game(4100, 3, -970002)
    r = rnd(rid)
    holder = r.turn_user_id
    tgt = [u for u in uids if u != holder][0]
    assert roulette._cyl_counts(r.chambers) == (4, 3)
    set_gun(rid, 0, 0, layout="LBBBLLB")
    await press(users[holder], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:{tgt}")
    st = dict(players_of(rid))
    assert st[tgt] is False and st[holder] is True and "شلیک موفق جنگی" in reason_of(rid, tgt)
    ok("multi-live: live shot at other kills target")

    # ---- تغییرِ تنظیمات وسطِ بازی: از نوبتِ بعدی اعمال می‌شه
    rid, uids, users, chat, panel = await start_group_game(4200, 3, -970003)
    r = rnd(rid)
    assert roulette._cyl_counts(r.chambers) == (4, 3)
    set_cfg("casino_rr_blank_bullets", "2")
    set_cfg("casino_rr_live_bullets", "1")
    holder = r.turn_user_id
    set_gun(rid, 0, 0, layout="BBBBLLL")
    await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")          # مشقی
    r = rnd(rid)
    assert roulette._cyl_counts(r.chambers) == (2, 1) and r.chamber_idx == 0
    e = BOT.last_edit(panel)[2]
    assert "تنظیماتِ خشاب عوض شد" in e and "خشاب: 2 مشقی + 1 جنگی (مجموع 3 تیر)" in e
    ok("changing bullet counts in admin applies from the next turn of a running game")

    # ---- اعتبارسنجی و clamp
    for key, bad in [("casino_rr_live_bullets", "0"), ("casino_rr_live_bullets", "11"),
                     ("casino_rr_blank_bullets", "-1"), ("casino_rr_blank_bullets", "21"),
                     ("casino_rr_spin_wait_seconds", "601"), ("casino_rr_turn_seconds", "5"),
                     ("casino_rr_live_bullets", "2.5"), ("casino_rr_live_bullets", "abc")]:
        assert roulette.validate_cfg(key, bad), (key, bad)
    for key, good in [("casino_rr_live_bullets", "1"), ("casino_rr_live_bullets", "10"),
                      ("casino_rr_blank_bullets", "0"), ("casino_rr_blank_bullets", "20"),
                      ("casino_rr_spin_wait_seconds", "0"), ("casino_rr_spin_wait_seconds", "600"),
                      ("casino_rr_turn_seconds", "10"), ("casino_max_bet", "abc")]:
        assert roulette.validate_cfg(key, good) is None, (key, good)
    set_cfg("casino_rr_live_bullets", "-5")
    set_cfg("casino_rr_blank_bullets", "999")
    set_cfg("casino_rr_spin_wait_seconds", "99999")
    set_cfg("casino_rr_turn_seconds", "abc")
    c = roulette.rr_settings(db.get_session())
    assert c == {"blank": 20, "live": 1, "wait": 600, "turn": 120}, c
    ok("admin validation + safe clamping of bad config values")

    # ---- پنلِ ادمین: کلیدها هستن و ذخیره/رد کردن کار می‌کنه
    import admin
    keys = dict(admin.CFG_CASINO_KEYS)
    for k in ("casino_rr_blank_bullets", "casino_rr_live_bullets", "casino_rr_spin_wait_seconds", "casino_rr_turn_seconds"):
        assert k in keys
    admin_user = FakeUser(999)
    achat = FakeChat(999, "private")
    apanel = new_panel(achat.id)
    for key, text, expect_saved in [("casino_rr_live_bullets", "3", "3"), ("casino_rr_live_bullets", "0", None),
                                    ("casino_rr_spin_wait_seconds", "3", "3"), ("casino_rr_spin_wait_seconds", "700", None)]:
        actx = ctx_for(999)
        q = FakeQuery(BOT, f"admin_cfg_edit:{key}", achat.id, apanel)
        await admin.cb_admin_cfg_edit(FakeUpdate(admin_user, achat, q), actx)
        assert actx.user_data.get("admin_state")
        upd = FakeUpdate(admin_user, achat, text=text)
        try:
            await admin.admin_awaiting_handler(upd, actx)
        except ApplicationHandlerStop:
            pass
        s_ = db.get_session()
        val = db.cfg_get(s_, key)
        s_.close()
        if expect_saved:
            assert val == expect_saved and "✅" in upd.message.replies[-1], (key, val, upd.message.replies)
        else:
            assert val != text and "❌" in upd.message.replies[-1], (key, val, upd.message.replies)
        assert not actx.user_data.get("admin_state")
    ok("admin panel: roulette keys editable, invalid values rejected with a clear message")

    # برگردون به پیش‌فرض‌های تست
    set_cfg("casino_rr_blank_bullets", "5")
    set_cfg("casino_rr_live_bullets", "1")
    set_cfg("casino_rr_spin_wait_seconds", "0")
    set_cfg("casino_rr_turn_seconds", "120")


async def test_spin_wait():
    print("test_spin_wait")
    set_cfg("casino_rr_spin_wait_seconds", "40")
    set_cfg("casino_rr_turn_seconds", "120")
    rid, uids, users, chat, panel = await start_group_game(4300, 3, -971001)
    r = rnd(rid)
    holder = r.turn_user_id
    assert turn_times(rid) == (40.0, 120.0)          # ۴۰ ثانیه انتظار، بعدش ۱۲۰ ثانیه (نه ۴۰ تا اون ۱۲۰)
    e = BOT.last_edit(panel)[2]
    assert e.split("\n")[1] == "⏳ 40 ثانیه انتظار برای چرخاندنِ خشابِ تفنگ"         # بالای پنل
    assert "خشاب در حالِ چرخیدنه" in e and "بعد از چرخیدنِ خشاب 120 ثانیه" in e
    tgt = [u for u in uids if u != holder][0]

    # قبل از تمومِ ۴۰ ثانیه: شلیک به خودش / به دیگری هر دو رد می‌شن و هیچ‌چیز عوض نمی‌شه
    before = (rnd(rid).turn_seq, rnd(rid).chamber_idx, rnd(rid).chambers, players_of(rid))
    q = await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
    assert last_alert(q)[1] is True and "هنوز 40 ثانیه نشده" in last_alert(q)[0]
    q = await press(users[holder], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:{tgt}")
    assert last_alert(q)[1] is True and "هنوز 40 ثانیه نشده" in last_alert(q)[0]
    assert (rnd(rid).turn_seq, rnd(rid).chamber_idx, rnd(rid).chambers, players_of(rid)) == before
    ok("shots before the 40s wait are rejected with 'still 40 seconds' and change nothing")

    # نفرِ غیرِ نوبت‌دار همچنان «نوبتِ تو نیست» می‌گیره (نه پیامِ انتظار)
    q = await press(users[tgt], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
    assert "نوبتِ" in last_alert(q)[0]

    # ساعتِ حذف از بعدِ ۴۰ ثانیه حساب می‌شه: ۱۰۰ ثانیه بعد از شروعِ نوبت هنوز نباید حذف بشه
    now = datetime.datetime.utcnow()
    s_ = db.get_session()
    x = s_.get(db.RouletteRound, rid)
    assert (x.turn_deadline_at - now).total_seconds() > 155      # ≈ ۴۰ + ۱۲۰
    s_.close()
    shift_turn(rid, 100)                                          # ۱۰۰ ثانیه گذشته: ۴۰ انتظار + ۶۰ ثانیه از مهلت
    await roulette._turn_timeout(ctx_for(holder), rid, r.turn_seq)
    await roulette.tick_roulette(db.get_session(), ctx_for(holder))
    assert rnd(rid).turn_seq == r.turn_seq and dict(players_of(rid))[holder] is True
    ok("AFK clock starts after the wait: 100s into the turn nobody is eliminated yet")

    # ۴۰ ثانیه گذشته: پنل «آماده» می‌شه و شلیک ممکنه
    await roulette._ready_notice(ctx_for(holder), rid, r.turn_seq)
    assert "✅ خشاب چرخید" in BOT.last_edit(panel)[2]
    await roulette._ready_notice(ctx_for(holder), rid, r.turn_seq + 9)      # تایمرِ نوبتِ دیگه: بی‌اثر
    set_gun(rid, 3, 0)
    await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
    r2 = rnd(rid)
    assert r2.chamber_idx == 1 and r2.turn_seq == r.turn_seq + 1 and dict(players_of(rid))[holder] is True
    ok("after the wait the shot works; ready notice flips panel to 'shooting is free'")
    assert turn_times(rid) == (40.0, 120.0)

    # حذفِ AFK: ۴۰ + ۱۲۰ ثانیه بعد از شروعِ نوبت
    h2 = r2.turn_user_id
    shift_turn(rid, 40 + 110)          # ۱۱۰ ثانیه از مهلتِ ۱۲۰ثانیه‌ای گذشته
    await roulette._turn_timeout(ctx_for(h2), rid, r2.turn_seq)
    assert dict(players_of(rid))[h2] is True
    shift_turn(rid, 12)                # حالا از مهلت رد شده
    await roulette._turn_timeout(ctx_for(h2), rid, r2.turn_seq)
    assert dict(players_of(rid))[h2] is False
    assert "عدم شلیک در مهلتِ 120 ثانیه" in reason_of(rid, h2)
    ok("AFK elimination only at wait + 120s")

    # ---- تغییرِ انتظار از پنل: ۳ ثانیه؛ از نوبتِ بعدی اعمال می‌شه و بالایِ پنل عوض می‌شه
    set_cfg("casino_rr_spin_wait_seconds", "3")
    rid, uids, users, chat, panel = await start_group_game(4400, 3, -971002)
    r = rnd(rid)
    assert turn_times(rid) == (3.0, 120.0)
    e = BOT.last_edit(panel)[2]
    assert e.split("\n")[1] == "⏳ 3 ثانیه انتظار برای چرخاندنِ خشابِ تفنگ"
    holder = r.turn_user_id
    q = await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
    assert "هنوز 3 ثانیه نشده" in last_alert(q)[0]
    # مقدارِ ۶۰: نوبتِ بعدی ۶۰ ثانیه انتظار + ۱۲۰
    set_cfg("casino_rr_spin_wait_seconds", "60")
    shift_turn(rid, 5)
    set_gun(rid, 4, 0)
    await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
    assert turn_times(rid) == (60.0, 120.0)
    assert BOT.last_edit(panel)[2].split("\n")[1] == "⏳ 60 ثانیه انتظار برای چرخاندنِ خشابِ تفنگ"
    ok("wait setting (3 -> 60) applies to the next turn and to the panel text")

    # ---- انتظارِ ۰: مثلِ قبل، فوراً شلیک
    set_cfg("casino_rr_spin_wait_seconds", "0")
    rid, uids, users, chat, panel = await start_group_game(4500, 2, -971003)
    r = rnd(rid)
    assert turn_times(rid) == (0.0, 120.0)
    assert "انتظار برای چرخاندنِ خشابِ تفنگ" not in BOT.last_edit(panel)[2].split("\n")[1]
    await press(users[r.turn_user_id], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
    assert rnd(rid).turn_seq == r.turn_seq + 1 or rnd(rid).status == "resolved"
    ok("wait = 0 means immediate shooting")

    # ---- لابیِ جهانی: همون قانون؛ فقط پنلِ نوبت‌دار دکمه داره ولی زودتر از موعد نمی‌شه زد
    set_cfg("casino_rr_spin_wait_seconds", "40")
    cancel_all_lobbies()
    uids = [4601, 4602]
    for u in uids:
        mk_user(u, 1_000_000_000)
    users = {u: FakeUser(u) for u in uids}
    chats = {u: FakeChat(-972000 - u) for u in uids}
    panels = {u: new_panel(chats[u].id) for u in uids}
    for u in uids:
        await press(users[u], chats[u], panels[u], f"rr_gjoin:{u}:1000000:2")
    rid = latest_round_id("global")
    r = rnd(rid)
    holder = r.turn_user_id
    assert "40 ثانیه انتظار برای چرخاندنِ خشابِ تفنگ" in BOT.last_edit(panels[holder])[2]
    q = await press(users[holder], chats[holder], panels[holder], f"rr_fire:{rid}:{r.turn_seq}")
    assert "هنوز 40 ثانیه نشده" in last_alert(q)[0]
    shift_turn(rid, 41)
    await press(users[holder], chats[holder], panels[holder], f"rr_fire:{rid}:{r.turn_seq}")
    assert rnd(rid).turn_seq == r.turn_seq + 1 or rnd(rid).status == "resolved"
    ok("global lobby follows the same wait rule")
    set_cfg("casino_rr_spin_wait_seconds", "0")
    if rnd(rid).status == "playing":
        shift_turn(rid, 41)          # نوبتِ جاری هنوز با انتظارِ ۴۰ ثانیه‌ای شروع شده بود
    r = await play_out(rid, users, chats, panels)
    assert r.status == "resolved"


async def test_turn_rotation_and_wait_every_turn():
    print("test_turn_rotation_and_wait_every_turn")
    # ---- دونفره: نوبت دقیقاً یکی‌درمیون (قبلاً ممکن بود پشتِ‌هم دستِ یه نفر بیفته)
    rid, uids, users, chat, panel = await start_group_game(5000, 2, -975001)
    holders = []
    for _ in range(40):
        r = rnd(rid)
        holders.append(r.turn_user_id)
        set_gun(rid, 0, 0, layout="B" * 12 + "L")        # قطعاً مشقی => همه زنده می‌مونن
        await press(users[r.turn_user_id], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
        assert rnd(rid).status == "playing"
    assert all(a != b for a, b in zip(holders, holders[1:])), holders
    assert set(holders) == set(uids)
    ok("2 players: the turn strictly alternates")

    # ---- ۴ نفره: هیچ‌وقت پشتِ‌هم یه نفر نیست، ولی شانسیه (همه‌ی بقیه پیش میان)
    rid, uids, users, chat, panel = await start_group_game(5100, 4, -975002)
    nxt = {u: set() for u in uids}
    prev = rnd(rid).turn_user_id
    for _ in range(240):
        r = rnd(rid)
        h = r.turn_user_id
        set_gun(rid, 0, 0, layout="B" * 12 + "L")
        await press(users[h], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
        n = rnd(rid).turn_user_id
        assert n != h
        nxt[h].add(n)
    for u in uids:
        assert nxt[u] == set(uids) - {u}, (u, nxt[u])
    ok("4 players: never the same shooter twice in a row, but still random among the others")

    # ---- بعد از شلیک به دیگری، بعد از حذفِ AFK و بعد از کشته‌شدن هم نوبت جابه‌جا می‌شه
    rid, uids, users, chat, panel = await start_group_game(5200, 3, -975003)
    r = rnd(rid)
    h = r.turn_user_id
    tgt = [u for u in uids if u != h][0]
    set_gun(rid, 0, 0, layout="LBBBBB")
    await press(users[h], chat, panel, f"rr_shoot:{rid}:{r.turn_seq}:{tgt}")           # جنگی: هدف مرد، شلیک‌کننده زنده
    r = rnd(rid)
    assert dict(players_of(rid))[h] is True and r.turn_user_id not in (h, tgt)
    h2 = r.turn_user_id
    s_ = db.get_session()
    x = s_.get(db.RouletteRound, rid)
    x.turn_deadline_at = datetime.datetime.utcnow() - datetime.timedelta(seconds=1)
    s_.commit()
    s_.close()
    await roulette._turn_timeout(ctx_for(h2), rid, r.turn_seq)                          # AFK: بازی تموم (۲ نفر → ۱ نفر)
    assert rnd(rid).status == "resolved" and rnd(rid).winner_id == h
    ok("turn passes on after shoot-other and after AFK elimination")

    # ---- انتظارِ ۴۰ ثانیه تو *همه‌ی* نوبت‌ها (نه فقط اولی)، برایِ هر نفری که نوبتش می‌رسه
    set_cfg("casino_rr_spin_wait_seconds", "40")
    rid, uids, users, chat, panel = await start_group_game(5300, 3, -975004)
    seen = []
    for turn_no in range(9):
        r = rnd(rid)
        h = r.turn_user_id
        seen.append(h)
        assert turn_times(rid) == (40.0, 120.0), (turn_no, turn_times(rid))
        # تو خودِ این نوبت قبل از ۴۰ ثانیه نمی‌شه زد
        q = await press(users[h], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
        assert "هنوز 40 ثانیه نشده" in last_alert(q)[0], (turn_no, last_alert(q))
        assert rnd(rid).turn_seq == r.turn_seq
        assert "40 ثانیه انتظار برای چرخاندنِ خشابِ تفنگ" in BOT.last_edit(panel)[2]
        shift_turn(rid, 41)
        set_gun(rid, 0, 0, layout="B" * 12 + "L")
        await press(users[h], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")
        assert rnd(rid).turn_seq == r.turn_seq + 1 and rnd(rid).turn_user_id != h
    assert all(a != b for a, b in zip(seen, seen[1:]))
    ok("the 40s wait applies on every turn, and the turn always moves to someone else")
    set_cfg("casino_rr_spin_wait_seconds", "0")


async def test_legacy_round_compat():
    print("test_legacy_round_compat")
    # بازیِ نیمه‌کاره‌ی نسخه‌ی قبل: chambers خالی و فقط bullet_pos/chamber_idx
    rid, uids, users, chat, panel = await start_group_game(4700, 2, -973001)
    s_ = db.get_session()
    x = s_.get(db.RouletteRound, rid)
    x.chambers = None
    x.bullet_pos = 2
    x.chamber_idx = 2
    x.turn_ready_at = None
    s_.commit()
    s_.close()
    r = rnd(rid)
    assert roulette._layout(r) == "BBLBBB"
    text, kb = roulette._view(db.get_session(), r, None)
    assert "خشاب: 5 مشقی + 1 جنگی" in text and "شانسِ تیرِ جنگیِ بعدی: 1 از 4" in text
    holder = r.turn_user_id
    await press(users[holder], chat, panel, f"rr_fire:{rid}:{r.turn_seq}")     # idx 2 = L → می‌میره (خشابِ قدیمی)
    assert dict(players_of(rid))[holder] is False
    ok("in-flight game from the old version keeps working (legacy single-bullet layout)")


async def main():
    tests = [test_group_full_game, test_custom_amount_and_cancel, test_group_lobby_timeout_and_cancel,
             test_lazy_expiry_no_busy_bug, test_global_flow, test_global_timeout_and_expiry,
             test_two_player_afk_and_concurrency, test_concurrent_global_matchmaking, test_shoot_other,
             test_classic_timeout_text_and_dead_buttons, test_classic_dice_failure_refunds,
             test_global_panels_stay_in_sync_under_load, test_full_lobby_never_stuck, test_global_lobbies_list,
             test_max_bet_and_private, test_classic_casino_interplay, test_message_deleted_fallback,
             test_cylinder_settings, test_spin_wait, test_turn_rotation_and_wait_every_turn, test_legacy_round_compat,
             test_random_simulation]
    for t in tests:
        await t()
    print(f"\nALL {len(passed)} CHECKS PASSED")


if __name__ == "__main__":
    asyncio.run(main())
