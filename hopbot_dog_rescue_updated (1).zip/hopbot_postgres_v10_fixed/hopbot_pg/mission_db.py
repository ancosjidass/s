# -*- coding: utf-8 -*-
"""
مدل‌ها + تنظیماتِ «مأموریت‌های هاپویی» (استریک، فصل، مأموریتِ روزانه/هفتگی).
هر مأموریت از پنلِ ادمین ساخته می‌شه (بدونِ مأموریتِ پیش‌فرضِ خودکار؛ فقط دکمه‌ی «نصبِ بسته‌ی شروع» که خودت می‌زنی).
"""
from sqlalchemy import Column, Integer, BigInteger, Float, String, Boolean, DateTime, Text, Index, UniqueConstraint

import db
from db import Base, now

# کلید، برچسبِ فارسی، پیش‌فرض، توضیح
CFG = [
    ("ct_enabled", "🟢 مأموریت‌ها روشن باشه؟ (۱/۰)", "1", ""),
    ("ct_tz_minutes", "🕐 اختلافِ ساعتِ محلی با UTC (دقیقه)", "210", "ایران = ۲۱۰ (۳:۳۰)"),
    ("ct_daily_count", "📅 تعدادِ مأموریتِ روزانه برای هر نفر", "3", "از رده‌ی آسان/متوسط/سخت به‌ترتیب"),
    ("ct_once_visible", "⭐ تعدادِ مأموریت‌های «مسیرِ تازه‌کار» که هم‌زمان نشون داده می‌شه", "2", ""),
    ("ct_weekly_count", "🗓 تعدادِ مأموریتِ هفتگی برای هر نفر", "2", ""),
    ("ct_floor_hourly", "🛟 کفِ درآمدِ ساعتی برای محاسبه‌ی پاداش (هاپ)", "60000", "بازیکنِ تازه‌کار هم پاداشِ معنی‌دار بگیره"),
    ("ct_reward_min", "🔻 حداقلِ پاداشِ هر مأموریت (هاپ)", "20000", ""),
    ("ct_reward_max", "🔺 سقفِ پاداشِ هر مأموریت (هاپ؛ ۰=بدونِ سقف)", "5000000000", "ضدِ تورم؛ بازیکنِ خیلی پولدار از این بیشتر نمی‌گیره"),
    ("ct_reward_multiplier", "✖️ ضریبِ کلیِ پاداشِ مأموریت‌ها", "1", "برای ایونت/تعدیلِ سریعِ اقتصاد"),
    ("ct_streak_min_claims", "🔥 حداقلِ مأموریتِ دریافت‌شده در روز برای حفظِ استریک", "1", ""),
    ("ct_streak_grace_days", "🛡 مهلتِ استریک (روزِ ازدست‌رفته‌ی مجاز)", "0", ""),
    ("ct_streak_steps", "🔥 ضریبِ پاداش به‌ازای استریک (روز:ضریب با کاما)", "3:1.1,7:1.25,14:1.4,30:1.6", ""),
    ("ct_all_done_bonus_hours", "🎁 پاداشِ تکمیلِ همه‌ی مأموریت‌های امروز (ساعتِ درآمد)", "2", "۰ = خاموش"),
    ("ct_season_days", "🏆 طولِ هر فصل (روز)", "30", ""),
    ("ct_season_points_per_tier", "⭐ امتیازِ فصل به‌ازای مأموریتِ رده‌ی ۱/۲/۳ (با کاما)", "10,25,60", ""),
    ("ct_season_top_hours", "🥇 پاداشِ پایانِ فصل برای رتبه‌ی ۱،۲،۳ (ساعتِ درآمد، با کاما)", "48,24,12", ""),
    ("ct_season_min_points", "⭐ حداقلِ امتیاز برای گرفتنِ پاداشِ فصل", "50", ""),
    ("ct_board_size", "📋 تعدادِ نفراتِ جدولِ برترین‌ها", "10", ""),
    ("ct_new_player_bonus_hours", "👋 هدیه‌ی اولین مأموریتِ هر بازیکنِ تازه (ساعتِ درآمد)", "6", "برای بازیکنایی که فقط یه‌بار هاپ زدن و رفتن"),
]
CFG_DEFAULT = {k: v for k, _l, v, _h in CFG}
CFG_LABEL = {k: l for k, l, _v, _h in CFG}
CFG_HELP = {k: h for k, _l, _v, h in CFG}
db.DEFAULT_CONFIG.update(CFG_DEFAULT)
db.MODULE_LEVEL_GATES.setdefault("mission", "🎯 مأموریت‌های هاپویی")
db.DEFAULT_CONFIG.setdefault("minlvl_mission", "0")

MSG = {
    "ct_msg_all_done": ("🎉 پیامِ تکمیلِ همه‌ی مأموریت‌ها", "🎉 همه‌ی مأموریت‌های امروزت تموم شد! جایزه‌ی ویژه گرفتی."),
    "ct_msg_claimed": ("✅ پیامِ دریافتِ پاداش", "✅ پاداشِ مأموریت دریافت شد."),
    "ct_msg_not_done": ("⏳ پیامِ هنوز تموم نشده", "هنوز این مأموریت تموم نشده."),
    "ct_msg_new_player": ("👋 پیامِ خوش‌آمد", "👋 به مأموریت‌های هاپویی خوش اومدی! هر روز چند مأموریت داری؛ انجامشون بده و جایزه بگیر."),
}
for _k, (_l, _v) in MSG.items():
    CFG_LABEL[_k] = _l
    CFG_DEFAULT[_k] = _v
    db.DEFAULT_CONFIG.setdefault(_k, _v)

TIERS = {1: "🟢 آسان", 2: "🟡 متوسط", 3: "🔴 سخت"}
PERIODS = {"daily": "📅 روزانه", "weekly": "🗓 هفتگی", "once": "⭐ یک‌بار (مسیرِ تازه‌کار)"}

# فیلدهای مأموریت (کلید، برچسبِ فارسی، نوع)
DEF_FIELDS = [
    ("title", "📛 عنوانِ مأموریت", "str"),
    ("metric", "📏 چه کاری حساب بشه؟ (از لیستِ معیارها)", "metric"),
    ("target", "🎯 تعدادِ لازم", "int"),
    ("period", "⏱ دوره (daily/weekly/once)", "enum:daily|weekly|once"),
    ("tier", "🏷 رده (۱ آسان، ۲ متوسط، ۳ سخت)", "int"),
    ("reward_ref_hours", "💰 پاداش (ساعتِ درآمدِ خودِ بازیکن)", "float"),
    ("reward_hop_abs", "💰 پاداشِ ثابت (هاپ)", "float"),
    ("min_level", "⭐ حداقل لولِ بازیکن", "int"),
    ("sort", "↕️ ترتیب", "int"),
]
DEF_LABEL = {k: l for k, l, _t in DEF_FIELDS}
DEF_KIND = {k: t for k, _l, t in DEF_FIELDS}


class MissionDef(Base):
    __tablename__ = "mission_defs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    title = Column(String, nullable=False)
    metric = Column(String, nullable=False)
    target = Column(Integer, default=1)
    period = Column(String, default="daily")
    tier = Column(Integer, default=1)
    reward_ref_hours = Column(Float, default=1)
    reward_hop_abs = Column(Float, default=0)
    min_level = Column(Integer, default=0)
    sort = Column(Integer, default=0)
    enabled = Column(Boolean, default=True)
    deleted = Column(Boolean, default=False, index=True)


class MissionPlayer(Base):
    __tablename__ = "mission_players"
    user_id = Column(BigInteger, primary_key=True)
    streak = Column(Integer, default=0)
    best_streak = Column(Integer, default=0)
    last_streak_day = Column(String, default="")
    total_claimed = Column(Integer, default=0)
    welcomed = Column(Boolean, default=False)
    lang = Column(String, default="")
    created_at = Column(DateTime, default=now)


class MissionClaim(Base):
    """هر دریافتِ پاداش دقیقاً یک ردیف؛ UniqueConstraint جلوی دریافتِ دوباره (دابل‌کلیک/ری‌استارت) رو می‌گیره."""
    __tablename__ = "mission_claims"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    mission_id = Column(Integer, nullable=False)
    period_key = Column(String, nullable=False)
    chat_id = Column(BigInteger, nullable=True)
    tier = Column(Integer, default=1)
    hop = Column(Float, default=0)
    points = Column(Integer, default=0)
    season_id = Column(Integer, default=0)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("user_id", "mission_id", "period_key", name="uq_mission_claim"),
                      Index("ix_mission_claim_season", "season_id", "user_id"))


class MissionBonus(Base):
    """پاداش‌های ویژه (همه‌ی مأموریت‌ها / خوش‌آمد / فصل) با کلیدِ یکتا."""
    __tablename__ = "mission_bonuses"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    kind = Column(String, nullable=False)
    ref = Column(String, nullable=False)
    hop = Column(Float, default=0)
    created_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("user_id", "kind", "ref", name="uq_mission_bonus"),)


class MissionSeason(Base):
    __tablename__ = "mission_seasons"
    id = Column(Integer, primary_key=True, autoincrement=True)
    started_at = Column(DateTime, nullable=False)
    ends_at = Column(DateTime, nullable=False)
    settled_at = Column(DateTime, nullable=True)


def init_missions():
    Base.metadata.create_all(db.engine)
    s = db.get_session()
    try:
        have = {c.key for c in s.query(db.Config).all()}
        for k, v in CFG_DEFAULT.items():
            if k not in have:
                s.add(db.Config(key=k, value=v))
        if "minlvl_mission" not in have:
            s.add(db.Config(key="minlvl_mission", value="0"))
        s.commit()
        db.cfg_cache_clear()   # کلیدهایِ تازه‌سیدشده فوراً دیده بشن
    finally:
        s.close()
