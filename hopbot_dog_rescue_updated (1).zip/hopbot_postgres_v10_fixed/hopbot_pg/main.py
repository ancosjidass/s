# -*- coding: utf-8 -*-
import asyncio
import datetime
import logging
import re

from telegram import Update
from telegram.ext import (
    Application, ApplicationHandlerStop, CommandHandler, MessageHandler,
    CallbackQueryHandler, ContextTypes, TypeHandler, filters,
)

import config
import db
import handlers
import admin
import casino
import myawy
import chef
import taxi
import cards
import redeem
import jobs
import battleship
import attack
import smuggling
import guide
import guessnum
import mastermind
import uno
import roulette
import mafia
import war_db
import db_purge
import premium_emoji
import war_ui
import frontier_db
import frontier_ui
import heist_db
import mentions
import chat_prefs
import lang_ui
import keyboards
import heist_ui
import mission_db
import referral
import mission_ui
import account_backup
import update_proc
import battlepass_db
import battlepass_ui
import dog_rescue

logging.basicConfig(
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
    level=logging.INFO,
)
logger = logging.getLogger(__name__)


async def _private_chat_blocked(update: Update, context=None) -> bool:
    """True یعنی این آپدیت باید کاملاً نادیده گرفته بشه: پیوی برای عموم خاموشه
    و فرستنده هم نه مالکه نه یکی از ادمین‌های فرعی. مالک و ادمین‌های فرعی
    همیشه (حتی وقتی پیویِ عمومی خاموشه) به پیوی دسترسی دارن، چون پنلِ مدیریت
    (یا بخشی از اون که به هرکدومشون واگذار شده) فقط از همون‌جا در دسترسه.
    علاوه‌بر این، دکمه‌های «نبردِ دریایی» (bship_...)، مسترمایند (mm_)، اونو
    (uno_) و کلِ «مافیا/گرگینه» (mf_...) هم همیشه (چه پیویِ عمومی روشن باشه چه
    نه) کار می‌کنن - چون بخشِ زیادی از این بازی‌ها (جای‌گذاریِ کشتی‌ها، حدس‌زدن،
    نقش‌ِشبِ مافیا، رای‌دادن/پیوستنِ لابیِ جهانی) دقیقاً به‌خاطرِ مخفی‌موندن یا
    نبودِ گروهِ مشترک باید از تویِ همین پیوی انجام بشه؛ اگه این استثنا نبود، با
    خاموش‌بودنِ پیویِ عمومی، این بازی‌ها برای بازیکن‌های عادی اصلاً قابل‌بازی
    نمی‌شدن. به همین ترتیب، اگه یه پیامِ متنیِ ساده (فقط عدد) از کسیه که همین
    الان تو نقشِ «سازنده‌ی عددِ مخفی»یِ یه بازیِ «حدسِ عدد»ه، اونم استثنا می‌شه -
    وگرنه سازنده نمی‌تونست عددش رو تو پیوی بفرسته."""
    chat = update.effective_chat
    if not chat or chat.type != "private":
        return False
    if update.callback_query and (update.callback_query.data or "").startswith(
            ("bship", "mm_", "uno_", "mf_", "wr:", "fr:", "wrgs:", "acct:", "ref:", "back_main", "lang:")):
        # «back_main*»: دکمه‌ی بازگشت به «منوی اصلی». با پیویِ خاموش، منوی اصلی فقط دکمه‌ی
        # «سیو / بازیابی اکانت» رو داره (handlers.cb_back_main / keyboards.main_private_menu).
        return False
    msg_text = (update.message.text or "").strip().lower() if update.message and update.message.text else ""
    if msg_text and (msg_text.startswith(("/lang", "/language")) or lang_ui.is_lang_text(msg_text, True)):
        return False   # انتخابِ زبان (Language) حتی با پیویِ خاموش برایِ همه کار می‌کنه
    if msg_text in ("/start", "/cancel") or msg_text.startswith(("/start@", "/cancel@")):
        # فقط «/start» ساده (بدونِ deep-link) و «/cancel»: برایِ رسیدن به منوی اصلیِ محدود (فقط سیو/بازیابی)
        # حتی با پیویِ خاموش. /start با پارامتر (مثلاً war_...) مثلِ قبل بلاک می‌مونه.
        if " " not in msg_text or msg_text.split(" ", 1)[1].startswith("ref_"):
            return False          # «/start ref_...» (لینکِ دعوت) حتی با پیویِ بسته کار می‌کنه
    if context is not None and context.user_data.get("acct_awaiting"):
        return False   # وسطِ فلوی سیو/بازیابیِ اکانت (ایمیل/کد) باید حتی با پیویِ خاموش کار کنه
    user = update.effective_user
    session = db.get_session()
    try:
        if user and db.is_any_admin(session, user.id):
            return False
        if (
            user and update.message and update.message.text
            and getattr(update.message, "reply_to_message", None) is not None
            and mafia.is_current_speaker(session, user.id)
        ):
            # نوبتِ صحبتِ روزِ مافیا: ریپلای رویِ پنلِ بازی باید حتی با پیویِ خاموش کار کنه
            return False
        if (
            user and update.message and update.message.text
            and re.match(r"^\s*\d+\s*$", update.message.text)
            and session.query(db.GuessNumberRound)
            .filter(db.GuessNumberRound.status == "setting_number", db.GuessNumberRound.setter_id == user.id)
            .first()
        ):
            return False
        enabled = db.cfg_get(session, "private_chat_enabled") == "1"
    finally:
        session.close()
    return not enabled


async def private_chat_gate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """اگه مالک از پنل، پیوی رو برای عموم خاموش کرده باشه، هیچ پیام یا دکمه‌ای
    تو پیوی (جز مالک) پردازش نمی‌شه - برای گروه‌هایی که می‌خوان کاربرها فقط تو
    خودِ چت با بات کار کنن."""
    if not await _private_chat_blocked(update, context):
        return
    if update.message:
        await update.message.reply_text("🚫 پیویِ این ربات فعلاً خاموشه؛ لطفاً از تو گروه استفاده کن.")
    elif update.callback_query:
        await update.callback_query.answer("🚫 پیویِ این ربات فعلاً خاموشه؛ لطفاً از تو گروه استفاده کن.", show_alert=True)
    raise ApplicationHandlerStop


async def jail_gate(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """زندانِ سراسریِ هاپویی (User.jailed_until - مثلاً بابتِ ندادنِ فیِ پلتفرم
    سرِ وقت، یا دستورِ «زندان هاپویی» مالک، یا قبول‌شدنِ یه گزارش) - جلوی همه‌ی
    دکمه‌های شیشه‌ای (که همیشه دستورِ باتن) رو برای کاربرِ زندانی می‌گیره، فارغ
    از گروه/پیوی. مالک هیچ‌وقت گیر نمی‌کنه.

    توجه: این فقط دکمه‌ها رو می‌گیره. زندانِ متنیِ کلمه‌های تریگر/انتقال جدا تو
    handlers.text_router چک می‌شه، چون اونجا باید فقط برای کلمه‌های خاصِ بات
    باشه، نه هر پیامِ عادیِ گروه (وگرنه جلوی چت‌کردنِ معمولیِ زندانی‌ها هم گرفته
    می‌شد که درست نیست - زندان فقط رو استفاده از بات اثر داره)."""
    if not update.callback_query:
        return
    data = update.callback_query.data or ""
    if data.startswith(("bail_", "lang:")):
        # همه‌ی دکمه‌های خودِ صفحه‌ی وثیقه (انتخابِ جیب/بانک، تاییدِ نهایی،
        # برگشت، بیخیال) باید برایِ زندانی‌ها کار کنه - منطقاً این تنها راهیه
        # که یه زندانیِ وثیقه‌دار می‌تونه آزاد شه؛ اگه این‌جا هم گیرش بندازیم،
        # هیچ‌وقت نمی‌تونه وثیقه بده.
        return
    user = update.effective_user
    if not user or handlers.is_owner(user.id):
        return
    session = db.get_session()
    try:
        u = db.get_or_create_user(session, user)
        nowt = datetime.datetime.utcnow()
        is_jailed = bool(u.jailed_until and u.jailed_until > nowt)
        forever = is_jailed and u.jailed_until >= db.JAIL_FOREVER
        remain = (u.jailed_until - nowt) if (is_jailed and not forever) else None
        session.commit()
    finally:
        session.close()
    if not is_jailed:
        return
    if forever:
        text = "🔒 شما برای همیشه در زندان هاپویی هستید. برای وثیقه بنویس «وثیقه»."
    else:
        h = int(remain.total_seconds() // 3600)
        m = int((remain.total_seconds() % 3600) // 60)
        text = f"🔒 شما در زندان هاپویی هستید! {h} ساعت و {m} دقیقه‌ی دیگه آزاد می‌شید. برای وثیقه بنویس «وثیقه»."
    await update.callback_query.answer(text, show_alert=True)
    raise ApplicationHandlerStop


# قفلِ per-user برایِ دکمه‌ها (کال‌بک‌ها):
#
# قبلاً این‌جا یه ست به اسمِ _busy_users بود که کلیکِ دومِ همون کاربر رو، تا
# وقتی پردازشِ کلیکِ اول تموم نشده، کاملاً رد می‌کرد (نه پیامِ جدید، نه
# پردازش - فقط یه توستِ «صبر کن») - این یعنی بازیکنی که با اسپمِ کلیک عادت
# داره پشتِ‌سرِهم چندبار بزنه، کلیک‌هاش عملاً گم می‌شدن (حسِ کندی/بی‌جواب‌موندنِ
# بات رو می‌داد)، در حالی که خودِ هدفِ اصلی («پنل به خودش ریپلایِ تکراری نده»)
# فقط با جلوگیری از *هم‌زمان* پردازش‌شدنِ دوتا کلیکِ یه کاربر رویِ یه وضعیتِ
# قدیمی به دست میاد - نه با ردکردنِ کلیکِ دوم.
#
# پس الان دیگه هیچ کلیکی رد نمی‌شه و هیچ محدودیت/تاخیری رویِ خودِ پلیر اعمال
# نمی‌شه: هر کلیک (هرچقدرم پشتِ‌سرِهم و سریع) قطعاً پردازش می‌شه. فقط
# پردازشِ کلیک‌هایِ *همون یه کاربر* با asyncio.Lock صف می‌شن (دقیقاً همون
# الگویِ with_round_lock تو casino.py/battleship.py/...، منتها per-user
# به‌جایِ per-round) تا کلیکِ دوم حتماً بعد از کامل‌شدن (و commit‌شدن) کلیکِ
# اول اجرا بشه - این همون چیزیه که جلویِ ریس‌کاندیشن/خودِ‌پیام‌اسپمی رو واقعاً
# می‌گیره، چون پردازشِ دوم دیگه رویِ وضعیتِ به‌روزشده کار می‌کنه، نه وضعیتِ
# بی‌اثرِ قدیمی. صفِ per-user بودنش یعنی رویِ بقیه‌ی کاربرها و بقیه‌ی
# درخواست‌های هم‌زمانِ ربات هیچ اثری نداره - ربات همچنان هم‌زمان به چندین نفرِ
# مختلف سرویس می‌ده، فقط کلیک‌هایِ پشتِ‌سرهمِ خودِ یه نفر به ترتیب پردازش می‌شن.
_user_callback_locks = {}


def _get_user_callback_lock(user_id: int) -> asyncio.Lock:
    lock = _user_callback_locks.get(user_id)
    if lock is None:
        lock = asyncio.Lock()
        _user_callback_locks[user_id] = lock
    return lock


# کاربرهایی که همین الان یه پیامِ متنی ازشون در حالِ پردازشه - این جدا از
# قفلِ per-user بالا (که فقط رویِ دکمه‌هاست) نگه داشته شده و دست‌نخورده مونده؛
# طبقِ خواسته، محدودیتِ اسپمِ متن قبلاً جداگونه اعمال شده و نیازی به تغییر
# نداره.
_busy_users = set()


async def unified_callback_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id if update.effective_user else None
    if uid is None:
        await _dispatch_callback(update, context)
        return
    async with _get_user_callback_lock(uid):
        await _dispatch_callback(update, context)


async def _dispatch_callback(update: Update, context: ContextTypes.DEFAULT_TYPE):
    data = update.callback_query.data or ""
    if data.startswith("lang:"):
        if await lang_ui.lang_callback(update, context):
            return
    if data.startswith("wr:"):
        handled = await war_ui.wr_callback_router(update, context)
        if handled:
            return
    if data.startswith("fr:"):
        handled = await frontier_ui.fr_callback_router(update, context)
        if handled:
            return
    if data.startswith("wrgs:"):
        handled = await war_ui.gs_callback(update, context)
        if handled:
            return
    if data.startswith("ref:"):
        import referral_ui
        await referral_ui.cb_ref(update, context)
        return
    if data.startswith("dogrescue:"):
        await dog_rescue.callback_router(update, context)
        return
    if data.startswith(("bp:", "bail_bpjc")):
        if await battlepass_ui.callback_router(update, context):
            return
    if data.startswith("mt:"):
        if await mission_ui.mission_callback_router(update, context):
            return
    if data.startswith("ht:"):
        handled = await heist_ui.heist_callback_router(update, context)
        if handled:
            return
    if data.startswith("acct:"):
        handled = await account_backup.callback_router(update, context)
        if handled:
            return
    if data.startswith("admin"):
        handled = await admin.admin_callback_router(update, context)
        if handled:
            return
    if data.startswith("casino"):
        handled = await casino.casino_callback_router(update, context)
        if handled:
            return
    if data.startswith("myawy"):
        handled = await myawy.myawy_callback_router(update, context)
        if handled:
            return
    if data.startswith("chef"):
        handled = await chef.chef_callback_router(update, context)
        if handled:
            return
    if data.startswith("taxi"):
        handled = await taxi.taxi_callback_router(update, context)
        if handled:
            return
    if data.startswith("cards"):
        handled = await cards.cards_callback_router(update, context)
        if handled:
            return
    if data.startswith("redeem"):
        handled = await redeem.redeem_callback_router(update, context)
        if handled:
            return
    if data.startswith("bship"):
        handled = await battleship.bship_callback_router(update, context)
        if handled:
            return
    if data.startswith("attack"):
        handled = await attack.attack_callback_router(update, context)
        if handled:
            return
    if data.startswith("duel"):
        handled = await attack.duel_callback_router(update, context)
        if handled:
            return
    if data.startswith("smg"):
        handled = await smuggling.smg_callback_router(update, context)
        if handled:
            return
    if data.startswith("hguide"):
        handler = guide.PLAYER_HELP_CALLBACKS.get(data.split(":")[0])
        if handler:
            await handler(update, context)
            return
    if data.startswith("gtn"):
        handled = await guessnum.gtn_callback_router(update, context)
        if handled:
            return
    if data.startswith("mm_"):
        handled = await mastermind.mm_callback_router(update, context)
        if handled:
            return
    if data.startswith("uno_"):
        handled = await uno.uno_callback_router(update, context)
        if handled:
            return
    if data.startswith("rr_"):
        handled = await roulette.rr_callback_router(update, context)
        if handled:
            return
    if data.startswith("mf_"):
        handled = await mafia.mf_callback_router(update, context)
        if handled:
            return
    await handlers.callback_router(update, context)


async def guarded_text_router(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """همون قفلِ per-user رو رویِ handlers.text_router هم می‌ذاره (نگاه کن به
    توضیحِ _busy_users بالا) - این همون هندلری هست که با تایپ‌کردنِ کلماتی مثل
    «بانک»، «قاچاق»، «هاپ منیج»، «منوی اصلی هاپویی» و... پنل‌ها رو باز می‌کنه."""
    uid = update.effective_user.id if update.effective_user else None
    if uid is not None:
        if uid in _busy_users:
            try:
                await update.message.reply_text("⏳ صبر کن، درخواستِ قبلیت هنوز در حالِ پردازشه...")
            except Exception:
                pass
            return
        _busy_users.add(uid)
    try:
        await handlers.text_router(update, context)
    finally:
        if uid is not None:
            _busy_users.discard(uid)


async def global_error_handler(update: object, context: ContextTypes.DEFAULT_TYPE):
    """هر خطای مدیریت‌نشده‌ای تو هر هندلری رو لاگ می‌کنه تا هیچ‌وقت یه خطا کاملا
    بی‌صدا از دستمون در نره (قبلا همین باعث می‌شد بعضی جاها ربات هیچ جوابی نده
    بدونِ اینکه معلوم باشه چرا)."""
    logger.exception("خطای مدیریت‌نشده در پردازش آپدیت", exc_info=context.error)


async def unified_awaiting_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    uid = update.effective_user.id if update.effective_user else None
    if uid is not None:
        if uid in _busy_users:
            try:
                await update.message.reply_text("⏳ صبر کن، درخواستِ قبلیت هنوز در حالِ پردازشه...")
            except Exception:
                pass
            return
        _busy_users.add(uid)
    try:
        await _dispatch_awaiting_text(update, context)
    finally:
        if uid is not None:
            _busy_users.discard(uid)


async def _dispatch_awaiting_text(update: Update, context: ContextTypes.DEFAULT_TYPE):
    """اول چک می‌کنیم مالک تو یه مرحله‌ی پنل مدیریت نیست، بعد چک می‌کنیم کاربر
    منتظر واردکردن عدد برای واریز/برداشت/خرید/فروش نیست.

    نکته: به‌محضِ رسیدنِ جوابِ کاربر (چه معتبر چه نامعتبر)، دکمه‌ی «بازگشت/کنسل»
    زیرِ همون پرامپت برداشته می‌شه (نگاه کن به handlers.clear_prompt_keyboard) -
    چون از این لحظه به بعد دیگه منطقی نیست کسی (خودِ کاربر با دوبار زدن، یا تو
    گروه یه‌نفرِ دیگه) بتونه روش بزنه و عملیاتی که داره پردازش می‌شه رو به‌هم
    بریزه."""
    # حدسِ عدد: چه عددِ مخفیِ سازنده تو پیوی، چه حدسِ بازیکن تو گروه - این دوتا
    # مستقلِ از سیستمِ awaiting هستن (نیازی به state تو user_data ندارن، مستقیم
    # از رویِ دیتابیس چک می‌شن)، پس قبل از بقیه چک می‌شن.
    if update.effective_chat and update.effective_chat.type == "private":
        if await guessnum.handle_setter_number_dm(update, context):
            return
        # صحبتِ روزِ مافیا: ریپلای رویِ پنلِ بازی تو پیوی (هر دو حالتِ گروهی/جهانی)
        if await mafia.handle_day_speech(update, context):
            raise ApplicationHandlerStop
    else:
        if await guessnum.handle_guess_text(update, context):
            return
    if context.user_data.get("war_awaiting"):
        await war_ui.war_awaiting_handler(update, context)
    if context.user_data.get(account_backup.STATE_KEY):
        await account_backup.awaiting_handler(update, context)   # خودش ApplicationHandlerStop می‌ده
    if context.user_data.get("admin_state"):
        state = context.user_data["admin_state"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await admin.admin_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("awaiting"):
        state = context.user_data["awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await handlers.awaiting_number_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("attack_awaiting"):
        state = context.user_data["attack_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await attack.attack_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("casino_awaiting"):
        state = context.user_data["casino_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await casino.casino_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("rr_awaiting"):
        state = context.user_data["rr_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await roulette.rr_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("mf_awaiting"):
        state = context.user_data["mf_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await mafia.mf_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("uno_awaiting"):
        state = context.user_data["uno_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await uno.uno_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("myawy_awaiting"):
        state = context.user_data["myawy_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await myawy.myawy_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("chef_awaiting"):
        state = context.user_data["chef_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await chef.chef_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("cards_awaiting"):
        state = context.user_data["cards_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await cards.cards_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("redeem_awaiting"):
        state = context.user_data["redeem_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await redeem.redeem_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("bship_awaiting"):
        state = context.user_data["bship_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await battleship.bship_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("gtn_awaiting"):
        state = context.user_data["gtn_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await guessnum.gtn_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    if context.user_data.get("mm_awaiting"):
        state = context.user_data["mm_awaiting"]
        if handlers.is_reply_to_prompt(update, state):
            await handlers.clear_prompt_keyboard(context, state)
        try:
            await mastermind.mm_awaiting_handler(update, context)
        except ApplicationHandlerStop:
            raise
        return
    # هیچ‌کدوم -> بذار به هندلر بعدی (متن‌های بازی) برسه


class _FallbackJobContext:
    """جاب‌کیوِ واقعیِ PTB به تابعِ جاب یه context با .bot می‌ده؛ چون اینجا از
    asyncio ساده استفاده می‌کنیم (نه job_queue)، یه شبیه‌سازِ سبک از همون
    رابطه لازمه - وگرنه کدی تو jobs.py که context.bot.send_message صدا می‌زنه
    (مثلا اطلاع‌رسانیِ انقضای فیِ پلتفرمِ گوشی هاپویی) با None کرش می‌کنه."""
    def __init__(self, bot):
        self.bot = bot


async def _tick_loop_fallback(app: Application):
    """
    اگه job_queue در دسترس نباشه (پکیج job-queue نصب نشده)، جاب تناوبی
    (سود بانکی/سوپرمارکت/بروزرسانی خودکار قیمت ارزها) هیچ‌وقت اجرا نمی‌شد -
    دقیقا همین بود که باعث می‌شد «بروزرسانی خودکار قیمت‌ها» با روشن‌کردنش هم
    هیچ اتفاقی نیفته. این تابع همون کار رو با یک حلقه‌ی asyncio ساده انجام
    می‌ده تا این قابلیت فارغ از نصب‌بودنِ آن پکیج قطعا کار کنه.
    """
    fake_context = _FallbackJobContext(app.bot)
    while True:
        await asyncio.sleep(60)
        try:
            await jobs.tick_job(fake_context)
        except Exception:
            logger.exception("خطا در اجرای tick_job (حلقه‌ی fallback)")


async def _game_tick_loop_fallback(app: Application):
    """نسخه‌ی fallbackِ جاروبِ سریعِ لابی‌هایِ کازینو (نگاه کن به jobs.game_tick_job)."""
    fake_context = _FallbackJobContext(app.bot)
    while True:
        await asyncio.sleep(10)
        try:
            await jobs.game_tick_job(fake_context)
        except Exception:
            logger.exception("خطا در اجرای game_tick_job (حلقه‌ی fallback)")
        try:
            await war_ui.war_tick_job(fake_context)
        except Exception:
            logger.exception("خطا در war_tick_job (حلقه‌ی fallback)")
        try:
            await frontier_ui.frontier_tick_job(fake_context)
        except Exception:
            logger.exception("خطا در frontier_tick_job (حلقه‌ی fallback)")
        try:
            await heist_ui.heist_tick_job(fake_context)
        except Exception:
            logger.exception("خطا در heist_tick_job (حلقه‌ی fallback)")


async def _post_init(app: Application):
    if config.PERF_LOG:
        asyncio.create_task(update_proc.loop_lag_monitor())
    try:
        keyboards.BOT_USERNAME = app.bot.username or ""
    except Exception:
        keyboards.BOT_USERNAME = ""
    if not app.job_queue:
        asyncio.create_task(_tick_loop_fallback(app))
        asyncio.create_task(_game_tick_loop_fallback(app))


def _build_telegram_requests():
    """دو شیءِ HTTPXRequest می‌سازه که فقط به‌صورتِ IPv4 به تلگرام وصل می‌شن.

    ترفند: با «local_address="0.0.0.0"» روی ترنسپورتِ httpx، سوکت به یه آدرسِ محلیِ IPv4
    بایند می‌شه و در نتیجه فقط رکوردهایِ A (IPv4) دامنه‌یِ api.telegram.org امتحان می‌شن و
    هیچ تلاشی برایِ IPv6 نمی‌شه. چون این فقط تو کلاینتِ تلگرام ست می‌شه (نه به‌صورتِ
    سراسری)، اتصال به Supabase/PostgreSQL مثلِ قبل و با انتخابِ خودِ سیستم برقرار می‌شه.

    خروجی: (request_عادی, request_مخصوصِ_getUpdates) یا (None, None) اگه خاموش/ناموفق بود.
    """
    if not getattr(config, "FORCE_TELEGRAM_IPV4", True):
        logger.info("FORCE_TELEGRAM_IPV4=0 → ارتباط با تلگرام با تنظیماتِ پیش‌فرضِ سیستم.")
        return None, None
    try:
        import httpx
        from telegram.request import HTTPXRequest

        def _make(pool_size: int) -> "HTTPXRequest":
            transport = httpx.AsyncHTTPTransport(
                local_address="0.0.0.0",   # فقط IPv4
                limits=httpx.Limits(
                    max_connections=pool_size,
                    max_keepalive_connections=pool_size,
                ),
            )
            return HTTPXRequest(
                connection_pool_size=pool_size,
                httpx_kwargs={"transport": transport},
            )

        # اندازه‌یِ پول‌ها = پیش‌فرضِ خودِ PTB (۲۵۶ برایِ درخواست‌هایِ عادی، ۱ برایِ getUpdates)
        req, upd_req = _make(256), _make(1)
        logger.info("ارتباط با تلگرام: فقط IPv4 (FORCE_TELEGRAM_IPV4=1).")
        return req, upd_req
    except Exception:
        logger.exception("ساختِ کلاینتِ IPv4 برایِ تلگرام ناموفق بود؛ با تنظیماتِ پیش‌فرض ادامه می‌دم.")
        return None, None


def main():
    db.init_db()
    chat_prefs.init()   # جدولِ زبانِ چت‌ها + پیوی‌هایِ شناخته‌شده (برایِ منشن)
    referral.init_referral()   # جدولِ دعوت‌ها + کانفیگ
    mission_db.init_missions()   # مأموریت‌ها: جدول + کانفیگ (بدونِ مأموریتِ خودکار)
    battlepass_db.init_battlepass()   # بتل‌پس: جدول‌ها + کانفیگ + چلنج‌هایِ پیش‌فرض
    heist_db.init_heist()   # جدول‌ها + کانفیگِ «سرقت تیمی هاپویی» (هیچ مکانِ پیش‌فرضی ساخته نمی‌شه)
    war_db.init_war()   # جدول‌ها + کانفیگ + دیتای اولیه‌ی «جنگ هاپویی»
    dog_rescue.init_dog_rescue()   # 🐕 رویدادِ مستقلِ نجاتِ سگ
    frontier_db.init_frontier()   # 🌌 Frontier: جدول‌های جدید (create_all) + کانفیگ + مناطق/باس‌ها؛ به دیتای قبلی دست نمی‌زنه
    account_backup.init_backup()   # جدول‌های سیو/بازیابیِ اکانت با جیمیل
    db.ensure_pg_indexes()   # فقط PostgreSQL: ایندکس‌هایِ جاافتاده (IF NOT EXISTS؛ به دیتا دست نمی‌زنه)

    premium_emoji.install()   # ایموجیِ پریمیوم (هوک رویِ Bot._post)
    mentions.install()   # همه‌ی @یوزرنیم‌ها → منشنِ قابل‌کلیک (حتی برای بدونِ یوزرنیم)
    builder = Application.builder().token(config.BOT_TOKEN).post_init(_post_init)
    _req, _upd_req = _build_telegram_requests()
    if _req is not None:
        # فقط ارتباط با تلگرام (هم ارسال/دریافتِ عادی هم getUpdates) با IPv4؛ دیتابیس دست‌نخورده.
        builder = builder.request(_req).get_updates_request(_upd_req)
    if config.CONCURRENT_UPDATES > 0:
        # آپدیت‌هایِ کاربرهایِ مختلف هم‌زمان پردازش می‌شن (تا N تا)، ولی آپدیت‌هایِ *هر کاربر*
        # هنوز به ترتیب صف می‌شن. قبلاً کلِ بات یکی‌یکی کار می‌کرد و هر `asyncio.sleep` تو
        # بازی‌ها (کازینو/مافیا/رولت) همه‌ی کاربرها رو معطل می‌کرد. خاموش‌کردن: CONCURRENT_UPDATES=0
        builder = builder.concurrent_updates(update_proc.PerUserUpdateProcessor(config.CONCURRENT_UPDATES))
    if config.PERF_LOG:
        update_proc.install_api_timer()
    app = builder.build()
    premium_emoji.register(app)   # /emoji ... (فقط مالک، فقط پیوی)

    app.add_handler(CommandHandler("start", handlers.cmd_start))
    app.add_handler(CommandHandler("help", guide.cmd_help))
    app.add_handler(CommandHandler("panel", admin.cb_admin_panel))
    app.add_handler(CommandHandler("cancel", handlers.cmd_cancel))
    app.add_handler(CommandHandler(["lang", "language"], lang_ui.cmd_lang))

    # گروه -۳: پیش‌پردازشِ هر آپدیت (زبانِ چتِ جاری، ثبتِ پیویِ کاربر برایِ منشن، دستورهایِ انگلیسی → فارسی)
    app.add_handler(TypeHandler(Update, lang_ui.pre_handler), group=-3)

    # گروه ۰-۲: قفلِ پیویِ عمومی (اگه مالک از پنل خاموشش کرده باشه) - قبل از
    # هر چیزِ دیگه‌ای چک می‌شه و در صورتِ نیاز کاملاً جلوی ادامه رو می‌گیره
    app.add_handler(MessageHandler(filters.ChatType.PRIVATE, private_chat_gate), group=-2)
    app.add_handler(CallbackQueryHandler(private_chat_gate), group=-2)
    # نکته‌ی مهم: jail_gate باید تو یه گروهِ جدا از private_chat_gate ثبت بشه.
    # کتابخونه‌ی PTB تو هر گروه فقط اولین هندلرِ مچ‌شده رو اجرا می‌کنه (بعدش
    # break می‌زنه) - قبلاً هر دو رو تو گروهِ -۲ ثبت کرده بودیم و چون
    # private_chat_gate اول ثبت شده بود، jail_gate هیچ‌وقت اجرا نمی‌شد و کاربرِ
    # زندانی می‌تونست رو دکمه‌های هر منویی که از قبل باز بود (مثلا کازینو) کار
    # کنه - این باگ الان با جداکردنِ گروه‌ها رفع شده.
    app.add_handler(CallbackQueryHandler(jail_gate), group=-1)

    # گروه ۰-۱: رصدِ گروه‌ها (برای اعلامِ سراسریِ قرعه‌کشی) - هیچ‌وقت propagation رو قطع نمی‌کنه
    app.add_handler(
        MessageHandler(filters.ChatType.GROUPS, handlers.track_group_chat_handler), group=-1
    )
    # گروه ۰: اول چک کن ببین منتظر یک ورودی عددی (پنل مدیریت یا بانک/ارز) هستیم یا نه
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, unified_awaiting_text), group=0
    )
    # گروه ۱: مسیریابیِ متن‌های بازی (هاپ هاپ / هاپ منیج / قرعه‌کشی / ارز هاپ / انتقال)
    app.add_handler(
        MessageHandler(filters.TEXT & ~filters.COMMAND, guarded_text_router), group=1
    )

    # گروه ۲: تریگرِ متنیِ انتخابِ زبان (جدا از گروه ۱ تا با text_router تداخل نکنه)
    app.add_handler(MessageHandler(filters.TEXT & ~filters.COMMAND, lang_ui.text_lang), group=2)

    app.add_handler(CallbackQueryHandler(unified_callback_router))
    app.add_error_handler(global_error_handler)

    if app.job_queue:
        app.job_queue.run_repeating(jobs.tick_job, interval=60, first=10)
        app.job_queue.run_repeating(jobs.game_tick_job, interval=10, first=15)
        app.job_queue.run_repeating(mission_ui.mission_tick_job, interval=600, first=60)
        app.job_queue.run_repeating(battlepass_ui.tick_job, interval=600, first=70)   # رولِ فصلِ بتل‌پس (ادامه‌دار)
        app.job_queue.run_repeating(dog_rescue.tick_job, interval=dog_rescue.TICK_SECONDS, first=45)  # 🐕 هر ۳ دقیقه، شانس مستقل در هر گروه
        app.job_queue.run_repeating(dog_rescue.expire_job, interval=10, first=55)  # ⏳ پایان دقیق مهلتِ پنج‌دقیقه‌ای
        app.job_queue.run_repeating(db_purge.purge_job, interval=300, first=90)   # پاک‌سازیِ دیتایِ عملیات‌هایِ تمام‌شده
        app.job_queue.run_repeating(heist_ui.heist_tick_job, interval=5, first=25)   # سرقت تیمی: پلیس/تایمرها/به‌روزرسانیِ پنل
        app.job_queue.run_repeating(war_ui.war_tick_job, interval=15, first=20)   # Resolve نبردها/جنگ‌ها/تسویه‌ها
        app.job_queue.run_repeating(frontier_ui.frontier_tick_job, interval=15, first=25)   # 🌌 Frontier: عملیات/فصل/باف‌ها

    logger.info("ربات هاپ در حال اجراست...")
    app.run_polling(allowed_updates=Update.ALL_TYPES)


if __name__ == "__main__":
    main()
