# -*- coding: utf-8 -*-
"""
مدل‌های دیتابیس «جنگ هاپویی» (Hāpoyi War) + کانفیگ پیش‌فرض + دیتای اولیه.

اصول:
- هیچ ارز جدیدی نساختیم: «Money» همان هاپ پوینتِ کیف‌پول (User.hop_points) است و همه‌ی
  تغییراتش از war_svc.hop_apply (با لجر HopTransaction) می‌گذرد.
- هر عددِ مهم یا در جدولِ تعریفی (WarUnitDef/WarBuildingDef/...) یا در db.Config با
  پیشوند war_ است، پس از پنل ادمین قابل تغییره.
- همه‌ی State ها (نبرد، صف ساخت، ارتقا، شیلد، جنگ قبیله) در دیتابیسه؛ ری‌استارت امنه.
"""
import json

from sqlalchemy import (
    Column, Integer, BigInteger, Float, String, Boolean, DateTime, Text, Index,
    UniqueConstraint, text,
)

import db
from db import Base, now

# ---------------------------------------------------------------------------
# لجر هاپ پوینت + آدیت
# ---------------------------------------------------------------------------


class HopTransaction(Base):
    __tablename__ = "hop_point_transactions"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, index=True, nullable=False)
    amount = Column(Float, nullable=False)          # علامت‌دار: + دریافت / - پرداخت
    type = Column(String, nullable=False)           # EARN/SPEND/BONUS/...
    reason = Column(String, nullable=False)
    reference_id = Column(String, nullable=True)
    balance_after = Column(Float, nullable=True)
    created_at = Column(DateTime, default=now, index=True)


class WarAudit(Base):
    __tablename__ = "war_audit_logs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    actor_id = Column(BigInteger, index=True, nullable=True)
    action = Column(String, index=True, nullable=False)
    detail = Column(Text, default="{}")
    created_at = Column(DateTime, default=now, index=True)


# ---------------------------------------------------------------------------
# بازیکن / ساختمان / نیرو
# ---------------------------------------------------------------------------


class WarPlayer(Base):
    __tablename__ = "war_players"
    user_id = Column(BigInteger, primary_key=True)
    xp = Column(Float, default=0)                  # Personal XP (کل، نه داخل سطح)
    th_level = Column(Integer, default=1)
    trophies = Column(Integer, default=0, index=True)
    fuel = Column(Float, default=0)
    fuel_at = Column(DateTime, default=now)
    readiness = Column(Float, default=100)
    readiness_at = Column(DateTime, default=now)
    vault_hop = Column(Float, default=0)
    vault_mat = Column(Float, default=0)
    vault_at = Column(DateTime, default=now)
    shield_until = Column(DateTime, nullable=True)
    clan_id = Column(Integer, nullable=True, index=True)
    attacks = Column(Integer, default=0)
    wins = Column(Integer, default=0)
    losses = Column(Integer, default=0)
    defense_wins = Column(Integer, default=0)
    defense_losses = Column(Integer, default=0)
    stars_total = Column(Integer, default=0)
    seen_unlocks = Column(Text, default="")        # CSV از featureهایی که اعلانِ باز‌شدنشون داده شده
    last_seen_at = Column(DateTime, default=now)
    last_league_week = Column(String, nullable=True)
    coup_cooldown_until = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=now)


class WarBuildingDef(Base):
    __tablename__ = "war_building_defs"
    key = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    emoji = Column(String, default="🏗")
    kind = Column(String, nullable=False)  # th/mine/depot/vault/camp/barracks/def_ground/def_air/wall/workshop/radar
    max_level = Column(Integer, default=30)
    unlock_th = Column(Integer, default=1)
    req_level = Column(Integer, default=0)          # حداقل سطح XP
    value_base = Column(Float, default=1.0)
    value_growth = Column(Float, default=1.0)
    value_add = Column(Float, default=0.0)
    cost_weight = Column(Float, default=1.0)        # وزنِ هزینه نسبت به درآمدِ مرجع
    time_weight = Column(Float, default=1.0)
    free_start = Column(Boolean, default=False)     # از ابتدا سطح ۱ رایگان داده می‌شه
    visible_before = Column(Boolean, default=True)
    enabled = Column(Boolean, default=True)
    sort = Column(Integer, default=100)


class WarBuilding(Base):
    __tablename__ = "war_buildings"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    key = Column(String, nullable=False)
    level = Column(Integer, default=1)
    upgrade_to = Column(Integer, nullable=True)
    upgrade_finish_at = Column(DateTime, nullable=True)
    __table_args__ = (UniqueConstraint("user_id", "key", name="uq_war_building_user_key"),
                      Index("ix_war_building_finish", "upgrade_finish_at"))


class WarUnitDef(Base):
    __tablename__ = "war_unit_defs"
    key = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    emoji = Column(String, default="🪖")
    category = Column(String, default="ground")      # ground/armor/air/naval/missile/defense/support/special/...
    tier = Column(Integer, default=1)
    rarity = Column(String, default="common")
    description = Column(String, default="")
    atk = Column(Float, default=0)
    defn = Column(Float, default=0)
    durability = Column(Float, default=1.0)          # بالاتر = کمتر آسیب می‌بینه
    accuracy = Column(Float, default=1.0)            # ضریبِ حمله
    special_power = Column(Float, default=0)         # support_pct: درصدِ بونوسِ حمله برای هر واحد
    housing = Column(Integer, default=1)
    train_seconds = Column(Integer, default=60)
    cost = Column(Float, default=0)                  # هاپ پوینت (قیمتِ ساخت/خرید هر واحد)
    cost_mat = Column(Float, default=0)
    repair_pct = Column(Float, default=25)           # هزینه‌ی تعمیر = درصدی از cost
    repair_seconds = Column(Integer, default=30)
    sell_pct = Column(Float, default=30)
    maint_per_hour = Column(Float, default=0)        # نگهداری (از تولیدِ معدن کم می‌شه)
    upgradeable = Column(Boolean, default=True)
    repairable = Column(Boolean, default=True)
    max_level = Column(Integer, default=5)
    upg_stat_pct = Column(Float, default=12)         # درصدِ رشدِ قدرت به‌ازای هر سطح
    req_th = Column(Integer, default=1)
    req_level = Column(Integer, default=1)
    req_clan_level = Column(Integer, default=0)
    req_research = Column(String, default="")
    req_achievement = Column(String, default="")
    visible_before = Column(Boolean, default=True)
    enabled = Column(Boolean, default=True)
    sort = Column(Integer, default=100)


class WarUnit(Base):
    __tablename__ = "war_units"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    unit_key = Column(String, nullable=False)
    healthy = Column(Integer, default=0)
    damaged = Column(Integer, default=0)
    level = Column(Integer, default=1)
    destroyed_total = Column(Integer, default=0)
    __table_args__ = (UniqueConstraint("user_id", "unit_key", name="uq_war_unit_user_key"),)


class WarJob(Base):
    """صفِ ساخت/تعمیرِ نیرو (Persistent)."""
    __tablename__ = "war_jobs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    kind = Column(String, nullable=False)          # train / repair
    unit_key = Column(String, nullable=False)
    qty = Column(Integer, nullable=False)
    start_at = Column(DateTime, default=now)
    finish_at = Column(DateTime, nullable=False)
    status = Column(String, default="queued")      # queued / done / cancelled
    __table_args__ = (Index("ix_war_jobs_due", "status", "finish_at"),)


# ---------------------------------------------------------------------------
# نبرد
# ---------------------------------------------------------------------------


class WarBattleType(Base):
    __tablename__ = "war_battle_types"
    key = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    emoji = Column(String, default="⚔️")
    min_seconds = Column(Integer, default=600)
    max_seconds = Column(Integer, default=1200)
    fuel = Column(Float, default=1)
    cost_ref_hours = Column(Float, default=0.2)     # هزینه‌ی عملیات (هاپ پوینت) نسبت به درآمدِ مرجع
    atk_mult = Column(Float, default=1.0)
    loot_mult = Column(Float, default=1.0)
    casualty_mult = Column(Float, default=1.0)
    readiness_loss = Column(Float, default=15)
    xp_mult = Column(Float, default=1.0)
    reward_mult = Column(Float, default=1.0)
    min_army_housing = Column(Integer, default=1)
    unlock_feature = Column(String, default="attack")
    enabled = Column(Boolean, default=True)
    sort = Column(Integer, default=100)


class WarBattle(Base):
    __tablename__ = "war_battles"
    id = Column(Integer, primary_key=True, autoincrement=True)
    attacker_id = Column(BigInteger, nullable=False, index=True)
    defender_id = Column(BigInteger, nullable=False, index=True)
    btype = Column(String, nullable=False)
    clan_war_id = Column(Integer, nullable=True, index=True)
    is_revenge = Column(Boolean, default=False)
    revenge_of = Column(Integer, nullable=True, index=True)
    status = Column(String, default="marching")     # marching / resolved / cancelled
    outcome = Column(String, nullable=True)         # attacker / defender / draw
    formula_version = Column(Integer, default=1)
    seed = Column(BigInteger, default=0)
    farm_mult = Column(Float, default=1.0)
    created_at = Column(DateTime, default=now)
    resolve_at = Column(DateTime, nullable=False)
    resolved_at = Column(DateTime, nullable=True)
    army_json = Column(Text, default="{}")
    result_json = Column(Text, default="{}")
    stars = Column(Integer, default=0)
    destruction = Column(Float, default=0)
    loot_hop = Column(Float, default=0)
    loot_mat = Column(Float, default=0)
    origin_chat_id = Column(BigInteger, nullable=True)
    __table_args__ = (
        Index("ix_war_battles_due", "status", "resolve_at"),
        Index("ix_war_battles_pair", "attacker_id", "defender_id", "created_at"),
        # جلوگیری از دو حمله‌ی هم‌زمانِ یکسان (دبل‌کلیک/Race): فقط یک حمله‌ی در راه از A به B
        Index("uq_war_battle_active_pair", "attacker_id", "defender_id", unique=True,
              sqlite_where=text("status = 'marching'"), postgresql_where=text("status = 'marching'")),
    )


class WarFormulaVersion(Base):
    __tablename__ = "war_formula_versions"
    version = Column(Integer, primary_key=True)
    params_json = Column(Text, nullable=False)
    note = Column(String, default="")
    created_at = Column(DateTime, default=now)


class WarConfirm(Base):
    """توکنِ یک‌بارمصرفِ تایید (ضد Replay / دبل‌کلیک)."""
    __tablename__ = "war_confirms"
    token = Column(String, primary_key=True)
    user_id = Column(BigInteger, nullable=False)
    action = Column(String, nullable=False)
    payload = Column(Text, default="{}")
    used = Column(Boolean, default=False)
    expires_at = Column(DateTime, nullable=False)


# ---------------------------------------------------------------------------
# پاداش / آنلاک / مأموریت / دستاورد / ایونت
# ---------------------------------------------------------------------------


class WarRewardRule(Base):
    __tablename__ = "war_reward_rules"
    trigger = Column(String, primary_key=True)
    label = Column(String, default="")
    xp = Column(Float, default=0)
    xp_min = Column(Float, default=0)
    xp_max = Column(Float, default=0)                # 0 = بدون سقف
    clan_xp = Column(Float, default=0)
    contribution = Column(Float, default=0)
    hop_abs = Column(Float, default=0)
    hop_ref_hours = Column(Float, default=0)         # مقدار = ساعت‌های درآمدِ مرجعِ بازیکن
    materials = Column(Float, default=0)
    hop_min = Column(Float, default=0)
    hop_max = Column(Float, default=0)               # 0 = بدون سقف
    ledger_type = Column(String, default="BONUS")
    daily_cap_hop = Column(Float, default=0)         # 0 = بدون سقف (سقف روزانه‌ی هاپِ همین تریگر)
    daily_cap_xp = Column(Float, default=0)
    antifarm = Column(Boolean, default=True)
    multiplier = Column(Float, default=1.0)
    enabled = Column(Boolean, default=True)


class WarRewardCounter(Base):
    __tablename__ = "war_reward_counters"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    trigger = Column(String, nullable=False)
    day = Column(String, nullable=False)
    hop_total = Column(Float, default=0)
    xp_total = Column(Float, default=0)
    count = Column(Integer, default=0)
    __table_args__ = (UniqueConstraint("user_id", "trigger", "day", name="uq_war_reward_counter"),)


class WarUnlockRule(Base):
    __tablename__ = "war_unlock_rules"
    feature = Column(String, primary_key=True)
    label = Column(String, default="")
    emoji = Column(String, default="🔓")
    req_level = Column(Integer, default=0)
    req_th = Column(Integer, default=0)
    req_clan_level = Column(Integer, default=0)
    req_wins = Column(Integer, default=0)
    req_quest = Column(String, default="")
    req_achievement = Column(String, default="")
    req_research = Column(String, default="")
    hint = Column(String, default="")
    visible_before = Column(Boolean, default=True)
    enabled = Column(Boolean, default=True)
    sort = Column(Integer, default=100)


class WarQuestDef(Base):
    __tablename__ = "war_quest_defs"
    key = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    kind = Column(String, default="daily")          # daily / weekly / special
    metric = Column(String, nullable=False)
    target = Column(Integer, default=1)
    xp = Column(Float, default=0)
    hop_ref_hours = Column(Float, default=0)
    materials = Column(Float, default=0)
    clan_xp = Column(Float, default=0)
    unlock_feature = Column(String, default="")     # کامل‌شدنش این feature رو باز می‌کنه
    req_level = Column(Integer, default=1)
    enabled = Column(Boolean, default=True)


class WarQuestProgress(Base):
    __tablename__ = "war_quest_progress"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    quest_key = Column(String, nullable=False)
    period = Column(String, nullable=False)
    progress = Column(Integer, default=0)
    claimed = Column(Boolean, default=False)
    __table_args__ = (UniqueConstraint("user_id", "quest_key", "period", name="uq_war_quest_prog"),)


class WarAchievementDef(Base):
    __tablename__ = "war_achievement_defs"
    key = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    emoji = Column(String, default="🏆")
    metric = Column(String, nullable=False)
    threshold = Column(Integer, default=1)
    xp = Column(Float, default=0)
    hop_ref_hours = Column(Float, default=0)
    materials = Column(Float, default=0)
    badge = Column(String, default="")
    enabled = Column(Boolean, default=True)


class WarAchievement(Base):
    __tablename__ = "war_achievements"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    key = Column(String, nullable=False)
    unlocked_at = Column(DateTime, default=now)
    __table_args__ = (UniqueConstraint("user_id", "key", name="uq_war_ach_user_key"),)


class WarMetric(Base):
    """شمارنده‌های تجمعی (برای مأموریت/دستاورد/آنلاک)."""
    __tablename__ = "war_metrics"
    id = Column(Integer, primary_key=True, autoincrement=True)
    user_id = Column(BigInteger, nullable=False)
    metric = Column(String, nullable=False)
    value = Column(Float, default=0)
    __table_args__ = (UniqueConstraint("user_id", "metric", name="uq_war_metric"),)


class WarEvent(Base):
    __tablename__ = "war_events"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, nullable=False)
    start_at = Column(DateTime, nullable=False)
    end_at = Column(DateTime, nullable=False)
    xp_mult = Column(Float, default=1.0)
    loot_mult = Column(Float, default=1.0)
    hop_mult = Column(Float, default=1.0)
    income_mult = Column(Float, default=1.0)
    min_level = Column(Integer, default=0)
    battle_type = Column(String, default="")       # خالی = همه
    enabled = Column(Boolean, default=True)


# ---------------------------------------------------------------------------
# قبیله
# ---------------------------------------------------------------------------


class WarClan(Base):
    __tablename__ = "war_clans"
    id = Column(Integer, primary_key=True, autoincrement=True)
    name = Column(String, unique=True, nullable=False)
    tag = Column(String, unique=True, nullable=False)
    leader_id = Column(BigInteger, nullable=False)
    xp = Column(Float, default=0)
    level = Column(Integer, default=1)
    treasury = Column(Float, default=0)
    join_mode = Column(String, default="request")   # request (درخواست + تایید) / closed
    min_trophies = Column(Integer, default=0)
    min_level = Column(Integer, default=0)
    last_active_at = Column(DateTime, default=now)
    announce_chat_id = Column(BigInteger, nullable=True)   # گروهِ اعلان‌های قبیله
    description = Column(String, default="")
    last_settlement_at = Column(DateTime, default=now)
    war_search_until = Column(DateTime, nullable=True)
    war_search_size = Column(Integer, default=0)
    coup_cooldown_until = Column(DateTime, nullable=True)
    created_at = Column(DateTime, default=now)
    disbanded = Column(Boolean, default=False)


class WarClanMember(Base):
    __tablename__ = "war_clan_members"
    user_id = Column(BigInteger, primary_key=True)
    clan_id = Column(Integer, nullable=False, index=True)
    rank = Column(Integer, default=1)               # ۱ عضو ... ۴ معاون ... ۵ سازنده (نام‌ها از کانفیگ)
    joined_at = Column(DateTime, default=now)
    last_promoted_at = Column(DateTime, nullable=True)
    contribution = Column(Float, default=0)
    week_contribution = Column(Float, default=0)
    deposits_total = Column(Float, default=0)
    settled_total = Column(Float, default=0)


class WarClanTx(Base):
    __tablename__ = "war_clan_treasury_tx"
    id = Column(Integer, primary_key=True, autoincrement=True)
    clan_id = Column(Integer, nullable=False, index=True)
    user_id = Column(BigInteger, nullable=True)
    amount = Column(Float, nullable=False)
    type = Column(String, nullable=False)           # deposit/expense/settlement/coup/war_bonus
    reason = Column(String, default="")
    reference_id = Column(String, nullable=True)
    balance_after = Column(Float, default=0)
    created_at = Column(DateTime, default=now)


class WarClanRequest(Base):
    """درخواستِ عضویت (مثل CoC): سازنده/معاون با دیدنِ مشخصاتِ متقاضی قبول یا رد می‌کنه."""
    __tablename__ = "war_clan_requests"
    id = Column(Integer, primary_key=True, autoincrement=True)
    clan_id = Column(Integer, nullable=False, index=True)
    user_id = Column(BigInteger, nullable=False, index=True)
    message = Column(String, default="")
    status = Column(String, default="pending")      # pending / accepted / rejected / cancelled / expired
    decided_by = Column(BigInteger, nullable=True)
    created_at = Column(DateTime, default=now)
    decided_at = Column(DateTime, nullable=True)
    __table_args__ = (
        Index("uq_war_clan_request_pending", "clan_id", "user_id", unique=True,
              sqlite_where=text("status = 'pending'"), postgresql_where=text("status = 'pending'")),
    )


class WarClanLog(Base):
    """لاگِ رویدادهای قبیله (ورود/خروج/ارتقا/اخراج/کودتا...) - تاریخچه‌ی قابل‌نمایش."""
    __tablename__ = "war_clan_logs"
    id = Column(Integer, primary_key=True, autoincrement=True)
    clan_id = Column(Integer, nullable=False, index=True)
    text = Column(String, nullable=False)
    created_at = Column(DateTime, default=now)


class WarDonation(Base):
    """درخواستِ نیرو از هم‌قبیله‌ای‌ها (Clan Castle)."""
    __tablename__ = "war_donations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    clan_id = Column(Integer, nullable=False, index=True)
    requester_id = Column(BigInteger, nullable=False)
    unit_key = Column(String, nullable=False)
    qty = Column(Integer, nullable=False)
    filled = Column(Integer, default=0)
    status = Column(String, default="open")         # open / done / cancelled
    created_at = Column(DateTime, default=now)


class WarResearchDef(Base):
    __tablename__ = "war_research_defs"
    key = Column(String, primary_key=True)
    name = Column(String, nullable=False)
    branch = Column(String, default="combat")       # combat/defense/economy/production/repair/logistics/intelligence
    effect = Column(String, default="atk_pct")      # atk_pct/def_pct/income_pct/train_speed_pct/repair_disc_pct/loot_pct/spy_pct/readiness_pct
    effect_per_level = Column(Float, default=2.0)
    max_level = Column(Integer, default=5)
    cost_ref_hours = Column(Float, default=20)
    time_minutes = Column(Integer, default=180)
    req_clan_level = Column(Integer, default=4)
    enabled = Column(Boolean, default=True)


class WarClanResearch(Base):
    __tablename__ = "war_clan_research"
    id = Column(Integer, primary_key=True, autoincrement=True)
    clan_id = Column(Integer, nullable=False)
    key = Column(String, nullable=False)
    level = Column(Integer, default=0)
    upgrade_finish_at = Column(DateTime, nullable=True)
    __table_args__ = (UniqueConstraint("clan_id", "key", name="uq_war_clan_research"),)


class WarClanWar(Base):
    __tablename__ = "war_clan_wars"
    id = Column(Integer, primary_key=True, autoincrement=True)
    clan_a = Column(Integer, nullable=False, index=True)
    clan_b = Column(Integer, nullable=False, index=True)
    status = Column(String, default="prep")         # prep / active / ended
    prep_end_at = Column(DateTime, nullable=False)
    end_at = Column(DateTime, nullable=False)
    stars_a = Column(Integer, default=0)
    stars_b = Column(Integer, default=0)
    dest_a = Column(Float, default=0)
    dest_b = Column(Float, default=0)
    winner = Column(String, nullable=True)          # a / b / draw
    formula_version = Column(Integer, default=1)
    created_at = Column(DateTime, default=now)
    __table_args__ = (Index("ix_war_clan_wars_status", "status", "end_at"),)


class WarClanWarMember(Base):
    __tablename__ = "war_clan_war_members"
    id = Column(Integer, primary_key=True, autoincrement=True)
    war_id = Column(Integer, nullable=False, index=True)
    clan_id = Column(Integer, nullable=False)
    user_id = Column(BigInteger, nullable=False)
    power = Column(Float, default=0)
    attacks_used = Column(Integer, default=0)
    best_stars_taken = Column(Integer, default=0)    # بیشترین ستاره‌ای که دشمن روی این عضو گرفته
    best_dest_taken = Column(Float, default=0)
    stars_scored = Column(Integer, default=0)
    __table_args__ = (UniqueConstraint("war_id", "user_id", name="uq_war_cw_member"),)


class WarRelation(Base):
    __tablename__ = "war_relations"
    id = Column(Integer, primary_key=True, autoincrement=True)
    clan_a = Column(Integer, nullable=False)
    clan_b = Column(Integer, nullable=False)
    kind = Column(String, default="neutral")        # ally / truce / enemy / neutral / pending_ally / pending_truce
    proposer = Column(Integer, nullable=True)
    score = Column(Integer, default=0)              # -100..+100
    until = Column(DateTime, nullable=True)
    __table_args__ = (UniqueConstraint("clan_a", "clan_b", name="uq_war_relation"),)


class WarCoup(Base):
    __tablename__ = "war_clan_coups"
    id = Column(Integer, primary_key=True, autoincrement=True)
    clan_id = Column(Integer, nullable=False, index=True)
    initiator_id = Column(BigInteger, nullable=False)
    old_leader_id = Column(BigInteger, nullable=False)
    success = Column(Boolean, default=False)
    chance = Column(Float, default=0)
    xp_cost = Column(Float, default=0)
    reward = Column(Float, default=0)
    created_at = Column(DateTime, default=now)


class WarGroupSetting(Base):
    __tablename__ = "war_group_settings"
    chat_id = Column(BigInteger, primary_key=True)
    enabled = Column(Boolean, default=True)
    war_enabled = Column(Boolean, default=True)
    clan_enabled = Column(Boolean, default=True)
    notify_battles = Column(Boolean, default=True)
    clan_announcements = Column(Boolean, default=True)
    text_triggers = Column(Boolean, default=True)
    admin_only_actions = Column(Boolean, default=False)


class WarAlias(Base):
    __tablename__ = "war_aliases"
    id = Column(Integer, primary_key=True, autoincrement=True)
    panel = Column(String, nullable=False)          # main/war_room/attack/clan_attack/clan/history/units/resources/xp/profile/quests/treasury/diplomacy/status/clan_war
    text = Column(String, nullable=False, unique=True)   # نرمال‌شده
    builtin = Column(Boolean, default=False)


# ---------------------------------------------------------------------------
# کانفیگ پیش‌فرض (همه از پنل ادمین قابل تغییر)
# ---------------------------------------------------------------------------

# پارامترهای فرمولِ نبرد: نسخه‌بندی می‌شن (Battle Formula vN). ادمین «پیش‌نویس» رو
# ویرایش می‌کنه و با دکمه‌ی «انتشار نسخه‌ی جدید» یه Snapshot ساخته می‌شه.
FORMULA_KEYS = {
    "war_f_k": "2.2",                 # شیبِ منحنیِ تخریب
    "war_f_h": "1.15",                # نسبتِ قدرتی که به ۵۰٪ تخریب می‌رسه
    "war_f_random": "0.15",           # نویزِ کنترل‌شده (±)
    "war_f_damaged_mult": "0.6",      # قدرتِ تجهیزِ آسیب‌دیده نسبت به سالم
    "war_f_support_cap": "0.25",      # سقفِ بونوسِ پشتیبانی
    "war_f_def_army_share": "0.8",    # سهمِ قدرتِ ارتشِ مستقر در دفاع
    "war_f_readiness_floor": "0.5",   # با ریدینسِ ۰٪ هم این‌قدر از قدرت می‌مونه
    "war_f_star_thresholds": "40,65,90",
    "war_f_draw_threshold": "30",     # تخریبِ ≥ این و بدونِ ستاره = مساوی
    "war_f_atk_destroy": "0.08",      # نرخِ پایه‌ی نابودیِ نیروی مهاجم
    "war_f_atk_damage": "0.20",       # نرخِ پایه‌ی آسیب‌دیدنِ نیروی مهاجم
    "war_f_def_destroy": "0.06",
    "war_f_def_damage": "0.18",
    "war_f_counter_matrix": json.dumps({
        "ground":  {"ground": 0.90, "air": 1.20, "generic": 1.00},
        "armor":   {"ground": 0.85, "air": 1.25, "generic": 1.00},
        "air":     {"ground": 1.25, "air": 0.55, "generic": 1.00},
        "missile": {"ground": 1.10, "air": 1.00, "generic": 1.15},
        "naval":   {"ground": 1.00, "air": 1.10, "generic": 1.00},
        "special": {"ground": 1.00, "air": 1.00, "generic": 1.00},
        "support": {"ground": 1.00, "air": 1.00, "generic": 1.00},
    }, separators=(",", ":")),
}

WAR_DEFAULT_CONFIG = {
    "war_enabled": "1",
    # --- اقتصاد ---
    "war_income_multiplier": "3.5",         # درآمدِ جنگ نسبت به بخش‌های دیگه (۳ تا ۴ برابر)
    "war_level_step": "3",                  # سقفِ سطحِ هر ساختمان = TH × این
    "war_vault_cap_hours": "8",
    "war_mat_cap_hours": "12",
    "war_upgrade_h0": "1.5",                # هزینه‌ی ارتقا = ساعتِ درآمد: h0 + h1×(سطح-۲)
    "war_upgrade_h1": "1.2",
    "war_mat_base_per_hour": "120",
    "war_mat_growth": "1.10",
    "war_mat_upgrade_hours": "5",
    "war_start_mat_hours": "8",
    "war_build_time_base_min": "5",
    "war_build_time_growth": "1.32",
    "war_build_time_max_hours": "72",
    "war_builders_base": "1",
    "war_builders_per_th": "3",             # به‌ازای هر N سطحِ TH یه سازنده‌ی اضافه
    "war_hop_max_balance": "1e15",
    # --- XP ---
    "war_level_base_xp": "250",
    "war_level_growth": "110",
    "war_level_quad": "0.6",
    "war_max_level": "100",
    # --- سوخت/ریدینس ---
    "war_fuel_max": "10",
    "war_fuel_regen_minutes": "30",
    "war_start_fuel": "10",
    "war_start_infantry": "30",
    "war_readiness_recovery_per_hour": "6",
    "war_prepare_cost_ref_hours": "0.4",
    "war_prepare_fuel": "1",
    "war_prepare_gain": "30",
    "war_prepare_seconds": "0",
    "war_defense_readiness_loss": "6",
    # --- شیلد/انتقام ---
    "war_shield_rules": "40:8,90:14",       # حداقل تخریب:ساعت
    "war_shield_buy_hours": "12",
    "war_shield_buy_ref_hours": "2",
    "war_attack_breaks_shield": "1",
    "war_revenge_hours": "24",
    "war_revenge_loot_bonus_pct": "15",
    "war_revenge_xp_mult": "1.1",
    # --- غنیمت / ضد فارم ---
    "war_antifarm_steps": "1,0.7,0.4,0.15,0",
    "war_antifarm_window_hours": "24",
    "war_loot_max_frac_pct": "35",
    "war_loot_exp": "1.5",
    "war_vault_protect_pct": "10",
    "war_loot_cap_hours": "6",              # سقفِ غنیمتِ هر نبرد = ساعتِ درآمدِ خودِ مهاجم
    "war_pair_daily_loot_cap_hours": "10",
    "war_crushing_threshold": "90",
    "war_crushing_bonus_pct": "25",
    "war_weak_target_trophy_gap": "400",    # هدفِ خیلی ضعیف‌تر → غنیمت کمتر
    "war_weak_target_loot_pct": "50",
    "war_matchmaking_trophy_range": "350",
    "war_target_max_inactive_days": "14",
    "war_scout_cost_ref_hours": "0.05",
    "war_spy_cost_ref_hours": "0.3",
    "war_spy_base_error_pct": "35",
    "war_spy_error_per_radar_pct": "3",
    "war_spy_cooldown_minutes": "10",
    # --- کاپ/لیگ ---
    "war_trophy_base": "30",
    "war_trophy_loss_ratio": "0.7",
    "war_leagues": "برنز:0,نقره:400,طلا:900,کریستال:1500,استاد:2200,قهرمان:3000,افسانه:4000",
    "war_league_weekly_ref_hours": "0.5,1,2,4,7,10,15",
    # --- آموزش/تعمیر ---
    "war_queue_per_barracks_levels": "3",
    "war_repair_workshop_disc_pct": "2",    # به‌ازای هر سطح کارگاه
    "war_repair_workshop_max_pct": "50",
    "war_sell_enabled": "1",
    # --- قبیله ---
    "war_clan_create_ref_hours": "5",
    "war_clan_create_min_th": "2",
    "war_clan_max_members": "25",           # سقفِ مطلقِ اعضا
    "war_clan_capacity_base": "10",         # ظرفیتِ سطح ۱؛ هر سطح +per_level تا سقفِ مطلق
    "war_clan_capacity_per_level": "3",
    "war_clan_rank_names": "عضو,ارشد,افسر,معاون,سازنده",
    # حداقل رتبه‌ی لازم برای هر اقدام (۱..۵). ۵ = فقط سازنده
    "war_clan_perms": json.dumps({"view_requests": 2, "accept_requests": 4, "kick": 4, "start_war": 3,
                                  "research": 4, "diplomacy": 4, "edit": 5, "promote": 5, "transfer": 5,
                                  "disband": 5, "withdraw_log": 2, "donate_request": 1}, separators=(",", ":")),
    "war_clan_coleader_kick_max_rank": "1",  # معاون فقط عضوهای همین رتبه (و پایین‌تر) رو می‌تونه اخراج کنه
    "war_clan_request_ttl_hours": "48",
    "war_clan_max_pending_requests": "3",
    "war_clan_suggest_count": "6",
    "war_donate_daily_cap": "40",           # سقفِ تعدادِ واحدِ اهدایی در روز (ضد سوءاستفاده)
    "war_donate_max_request": "10",
    "war_donate_contrib": "1",              # امتیازِ مشارکت به‌ازای هر واحدِ اهدایی
    "war_clan_max_level": "10",
    "war_clan_xp_base": "1500",
    "war_clan_xp_growth": "1.55",
    "war_treasury_cap_hours": "300",
    "war_deposit_min_ref_hours": "0.05",
    "war_deposit_contrib_per_ref_hour": "10",
    "war_deposit_contrib_daily_cap": "60",
    "war_settle_days": "7",
    "war_settle_pool_pct": "20",
    "war_settle_member_cap_pct": "25",
    "war_settle_min_contribution": "20",
    "war_settle_max_ref_hours": "30",       # سقفِ برداشتِ هر عضو در هر تسویه
    "war_leave_cooldown_hours": "12",
    # --- جنگ قبیله ---
    "war_cw_prep_minutes": "60",
    "war_cw_duration_minutes": "360",
    "war_cw_attacks_per_member": "2",
    "war_cw_min_size": "2",
    "war_cw_max_size": "10",
    "war_cw_search_timeout_minutes": "120",
    "war_cw_match_level_gap": "2",
    "war_cw_loot_mult": "1.5",
    # --- کودتا ---
    "war_coup_min_membership_days": "3",
    "war_coup_min_contribution": "50",
    "war_coup_min_xp": "1500",
    "war_coup_xp_cost": "600",
    "war_coup_base_chance_pct": "20",
    "war_coup_max_chance_pct": "70",
    "war_coup_reward_treasury_pct": "4",    # پاداش از خزانه‌ی قبیله (نه پولِ بی‌منشأ)
    "war_coup_reward_cap_hours": "20",
    "war_coup_user_cooldown_days": "7",
    "war_coup_clan_cooldown_days": "3",
    "war_coup_fail_xp_extra": "300",
    "war_coup_fail_contrib_pct": "30",
    "war_coup_leader_inactive_days": "3",
    # --- دیپلماسی ---
    "war_dip_truce_hours": "12",
    "war_dip_ally_min_clan_level": "3",
    "war_dip_max_allies": "2",
    # --- ارتقای تجهیز ---
    "war_unit_upgrade_ref_hours": "0.15",   # هزینه‌ی ارتقای هر واحد = این × قیمتِ واحد×سطح
    "war_unit_upgrade_cost_mult": "3",
    # --- ریت‌لیمیت/UI ---
    "war_panel_cooldown_seconds": "3",
    "war_page_size": "5",
    "war_confirm_ttl_seconds": "180",
    "war_notify_group_max_chars": "600",
    "war_formula_version": "1",
    "war_ref_calibration": "0",             # R(1) لحظه‌ی آخرین کالیبراسیونِ قیمت‌ها
    "minlvl_war": "0",
}
WAR_DEFAULT_CONFIG.update(FORMULA_KEYS)

db.DEFAULT_CONFIG.update(WAR_DEFAULT_CONFIG)
db.MODULE_LEVEL_GATES.setdefault("war", "⚔️ جنگ هاپویی")

# ---------------------------------------------------------------------------
# دیتای اولیه (فقط اگه جدول خالی باشه؛ بعدش کاملاً ادمین‌محور)
# ---------------------------------------------------------------------------

BUILDINGS = [
    # key, name, emoji, kind, max_level, unlock_th, value_base, growth, add, cost_w, time_w, free, visible, sort
    ("th", "مقر فرماندهی", "🏛", "th", 10, 1, 1, 1, 0, 3.0, 2.0, True, True, 1),
    ("mine", "معدن هاپ", "⛏", "mine", 30, 1, 1.0, 1, 0, 1.0, 1.0, True, True, 2),
    ("depot", "انبار مواد", "🔩", "depot", 30, 1, 1, 1, 0, 0.8, 1.0, True, True, 3),
    ("vault", "گاوصندوق", "🏦", "vault", 30, 1, 1, 1, 0, 0.9, 1.0, True, True, 4),
    ("camp", "پادگان", "🏕", "camp", 30, 1, 30, 1, 12, 0.8, 1.0, True, True, 5),
    ("barracks", "کارخانه‌ی ساخت", "🏭", "barracks", 20, 1, 1, 1, 0.08, 0.9, 1.0, True, True, 6),
    ("turret", "برج دفاعِ زمینی", "🗼", "def_ground", 30, 1, 90, 1.22, 0, 0.7, 1.0, True, True, 7),
    ("aa", "پدافند هوایی", "🎯", "def_air", 30, 2, 70, 1.22, 0, 0.7, 1.0, False, True, 8),
    ("wall", "سپر دفاعی", "🧱", "wall", 20, 2, 1.0, 1, 0.03, 0.8, 1.0, False, True, 9),
    ("workshop", "کارگاه تعمیر", "🔧", "workshop", 20, 3, 1, 1, 0, 0.7, 1.0, False, True, 10),
    ("radar", "رادار / اطلاعات", "📡", "radar", 15, 4, 1, 1, 0, 0.7, 1.0, False, False, 11),
]

# key,name,emoji,cat,tier,rarity,atk,def,dur,acc,special,housing,train_s,cost_frac,mat,repair_pct,repair_s,maint_frac,req_th,req_lvl,visible,sort
# cost_frac: کسری از درآمدِ ساعتیِ مرجعِ سطحِ req_th (در زمانِ seed به عدد تبدیل می‌شه)
UNITS = [
    ("infantry", "پیاده‌نظام", "🪖", "ground", 1, "common", 10, 8, 1.0, 1.0, 0, 1, 20, 0.010, 5, 20, 8, 0, 1, 1, True, 1),
    ("drone", "پهپاد", "🛩", "air", 2, "common", 42, 14, 0.9, 1.0, 0, 2, 60, 0.030, 20, 25, 20, 0, 1, 2, True, 2),
    ("tank", "تانک", "🚜", "armor", 2, "common", 62, 58, 1.1, 1.0, 0, 4, 120, 0.055, 40, 25, 40, 0, 2, 3, True, 3),
    ("medic", "تیم امداد", "🚑", "support", 2, "common", 0, 10, 1.0, 1.0, 1.5, 3, 90, 0.030, 15, 20, 20, 0, 2, 3, True, 4),
    ("artillery", "توپخانه‌ی موشکی", "🚀", "missile", 3, "rare", 165, 20, 0.9, 1.0, 0, 6, 240, 0.110, 90, 28, 60, 0, 3, 5, True, 5),
    ("fighter", "جنگنده", "✈️", "air", 3, "rare", 135, 60, 1.0, 1.0, 0, 6, 300, 0.130, 100, 30, 70, 0, 3, 6, True, 6),
    ("destroyer", "ناوشکن", "🚢", "naval", 4, "epic", 210, 125, 1.3, 1.0, 0, 10, 600, 0.240, 180, 30, 120, 0.004, 5, 8, True, 7),
    ("f35", "اف-۳۵", "🛸", "air", 4, "epic", 430, 185, 1.2, 1.05, 0, 14, 900, 0.420, 260, 32, 160, 0.006, 6, 10, False, 8),
    ("defsys", "سامانه‌ی دفاعی", "🛡", "defense", 3, "rare", 0, 320, 1.4, 1.0, 0, 8, 300, 0.150, 120, 20, 60, 0.002, 4, 6, True, 9),
    ("icbm", "موشک قاره‌پیما", "☄️", "missile", 5, "legendary", 2600, 0, 1.0, 1.1, 0, 40, 3600, 1.600, 800, 40, 400, 0.020, 8, 20, False, 10),
]

BATTLE_TYPES = [
    # key,name,emoji,min_s,max_s,fuel,cost_h,atk,loot,cas,rloss,xp,reward,min_housing,feature,sort
    ("quick", "یورش سریع", "⚡", 600, 1200, 1, 0.10, 0.85, 0.70, 0.80, 8, 0.7, 0.7, 1, "attack", 1),
    ("standard", "حمله‌ی استاندارد", "⚔️", 2700, 5400, 2, 0.25, 1.00, 1.00, 1.00, 16, 1.0, 1.0, 5, "attack", 2),
    ("major", "عملیات بزرگ", "💥", 10800, 21600, 4, 0.70, 1.15, 1.45, 1.20, 32, 1.6, 1.6, 20, "major_ops", 3),
    ("clanwar", "نبردِ جنگ قبیله", "🏰", 1200, 2700, 0, 0.0, 1.00, 1.00, 1.00, 12, 1.0, 1.0, 1, "clan_war", 4),
]

UNLOCKS = [
    # feature,label,emoji,lvl,th,clan_lvl,wins,quest,ach,research,hint,visible,sort
    ("war_room", "اتاق جنگ", "⚔️", 0, 0, 0, 0, "", "", "", "", True, 1),
    ("attack", "حمله", "🎯", 1, 0, 0, 0, "", "", "", "", True, 2),
    ("quests", "مأموریت‌ها", "📜", 1, 0, 0, 0, "", "", "", "", True, 3),
    ("factory", "کارخانه‌ی ساخت", "🏭", 2, 0, 0, 0, "", "", "", "", True, 4),
    ("repair", "تعمیرگاه", "🔧", 2, 0, 0, 0, "", "", "", "", True, 5),
    ("achievements", "دستاوردها", "🏆", 3, 0, 0, 0, "", "", "", "یه چیزی هست که پیشرفتت رو ثبت می‌کنه...", False, 6),
    ("league", "لیگ", "🏅", 4, 0, 0, 0, "", "", "", "", True, 7),
    ("clan", "قبیله", "🏰", 5, 2, 0, 0, "", "", "", "یه قدرتِ گروهی در انتظارته...", False, 8),
    ("clan_war", "جنگ قبیله", "🛡", 0, 0, 2, 0, "", "", "", "قبیله‌ت هنوز آماده‌ی جنگ بزرگ نیست...", False, 9),
    ("spy", "جاسوسی", "🕵️", 7, 0, 0, 5, "", "", "", "یه قابلیتِ ناشناخته به‌زودی برات باز می‌شه.", False, 10),
    ("major_ops", "عملیات بزرگ", "💥", 8, 3, 0, 0, "", "", "", "", False, 11),
    ("diplomacy", "دیپلماسی", "🤝", 0, 0, 3, 0, "", "first_clan", "", "یه قابلیتِ ناشناخته در آینده برای شما باز خواهد شد.", False, 12),
    ("clan_research", "تحقیقاتِ قبیله", "🔬", 0, 0, 4, 0, "", "", "", "", False, 13),
    ("coup", "کودتا", "🚨", 10, 0, 0, 0, "", "first_cw", "", "", False, 14),
    ("endgame", "سیستم‌های Endgame", "⚛️", 0, 8, 0, 0, "", "", "", "", False, 15),
]

RULES = [
    # trigger,label,xp,clan_xp,contrib,hop_abs,hop_ref_h,mat,ledger,cap_hop_day,cap_xp_day,antifarm
    ("battle_win", "برد حمله", 90, 40, 4, 0, 0.35, 40, "BATTLE_REWARD", 0, 0, True),
    ("battle_draw", "مساویِ حمله", 45, 15, 2, 0, 0.12, 15, "BATTLE_REWARD", 0, 0, True),
    ("battle_loss", "شرکت در حمله‌ی ناموفق", 40, 10, 1, 0, 0.10, 10, "COMPENSATION", 0, 0, True),
    ("defense_win", "دفاعِ موفق", 60, 20, 3, 0, 0.25, 25, "BATTLE_REWARD", 0, 0, True),
    ("defense_loss", "غرامتِ دفاعِ ناموفق", 35, 5, 1, 0, 0.18, 30, "COMPENSATION", 0, 0, True),
    ("cw_attack", "حمله در جنگ قبیله", 60, 60, 6, 0, 0.20, 0, "CLAN_REWARD", 0, 0, False),
    ("cw_win", "برد جنگ قبیله", 200, 900, 25, 0, 2.0, 100, "CLAN_REWARD", 0, 0, False),
    ("cw_draw", "مساویِ جنگ قبیله", 120, 500, 15, 0, 1.0, 50, "CLAN_REWARD", 0, 0, False),
    ("cw_loss", "غرامتِ باخت در جنگ قبیله", 100, 350, 12, 0, 0.8, 60, "COMPENSATION", 0, 0, False),
    ("cw_star", "هر ستاره‌ی جنگ قبیله", 25, 60, 3, 0, 0.30, 0, "CLAN_REWARD", 0, 0, False),
    ("upgrade_done", "پایانِ ارتقا", 40, 5, 0, 0, 0, 0, "BONUS", 0, 0, False),
    ("train_done", "پایانِ ساخت", 8, 0, 0, 0, 0, 0, "BONUS", 0, 120, False),
    ("repair_done", "پایانِ تعمیر", 5, 0, 0, 0, 0, 0, "BONUS", 0, 80, False),
    ("prepare", "آماده‌سازی", 6, 0, 0, 0, 0, 0, "BONUS", 0, 30, False),
    ("deposit", "کمک به خزانه", 10, 10, 0, 0, 0, 0, "CLAN_REWARD", 0, 60, False),
    ("league_weekly", "پاداشِ هفتگیِ لیگ", 0, 0, 0, 0, 0, 0, "BONUS", 0, 0, False),
    ("coup_success", "کودتای موفق", 0, 0, 0, 0, 0, 0, "BONUS", 0, 0, False),
]

QUESTS = [
    # key,name,kind,metric,target,xp,hop_h,mat,clan_xp,unlock,req_level
    ("d_attack3", "۳ حمله انجام بده", "daily", "attacks", 3, 60, 0.30, 30, 0, "", 1),
    ("d_win1", "۱ نبرد رو ببر", "daily", "wins", 1, 50, 0.25, 20, 0, "", 1),
    ("d_train10", "۱۰ واحد بساز", "daily", "trained", 10, 40, 0.20, 20, 0, "", 2),
    ("d_repair5", "۵ واحد تعمیر کن", "daily", "repaired", 5, 35, 0.15, 10, 0, "", 2),
    ("d_upgrade1", "۱ ساختمان رو ارتقا بده", "daily", "upgrades", 1, 45, 0.25, 0, 0, "", 1),
    ("d_deposit1", "به خزانه‌ی قبیله کمک کن", "daily", "deposits", 1, 30, 0.10, 0, 30, "", 5),
    ("w_win10", "۱۰ نبرد رو ببر", "weekly", "wins", 10, 300, 2.0, 150, 100, "", 1),
    ("w_cw2", "۲ حمله در جنگ قبیله", "weekly", "cw_attacks", 2, 250, 1.5, 100, 200, "", 5),
    ("w_xp2000", "۲۰۰۰ XP جمع کن", "weekly", "xp_gain", 2000, 200, 1.2, 100, 0, "", 1),
    ("w_build30", "۳۰ واحد بساز", "weekly", "trained", 30, 200, 1.0, 100, 0, "", 2),
    ("s_first_win", "اولین برد: مسیرِ جاسوسی رو باز کن", "special", "wins", 5, 120, 0.5, 50, 0, "spy", 1),
]

ACHIEVEMENTS = [
    # key,name,emoji,metric,thr,xp,hop_h,mat,badge
    ("first_blood", "اولین خون", "🩸", "attacks", 1, 50, 0.3, 20, "🩸"),
    ("first_victory", "اولین پیروزی", "🥇", "wins", 1, 80, 0.5, 30, "🥇"),
    ("wins_10", "۱۰ پیروزی", "🏅", "wins", 10, 200, 1.5, 80, "🏅"),
    ("attacks_100", "۱۰۰ حمله", "💯", "attacks", 100, 500, 4, 200, "💯"),
    ("first_clan", "اولین قبیله", "🏰", "joined_clan", 1, 100, 0.8, 50, "🏰"),
    ("first_cw", "اولین جنگ قبیله", "🛡", "cw_attacks", 1, 250, 2, 100, "🛡"),
    ("coup_success", "کودتای موفق", "🚨", "coups_won", 1, 300, 3, 0, "🚨"),
    ("defense_master", "استادِ دفاع", "🧱", "defense_wins", 25, 400, 3, 150, "🧱"),
]

RESEARCH = [
    # key,name,branch,effect,per_level,max,cost_h,time_min,req_clan_lvl
    ("r_atk", "تاکتیک‌های تهاجمی", "combat", "atk_pct", 2.0, 5, 15, 180, 4),
    ("r_def", "استحکامات", "defense", "def_pct", 2.5, 5, 15, 180, 4),
    ("r_eco", "اقتصادِ جنگی", "economy", "income_pct", 3.0, 5, 20, 240, 4),
    ("r_prod", "خطِ تولید", "production", "train_speed_pct", 5.0, 5, 12, 120, 4),
    ("r_rep", "لجستیکِ تعمیر", "repair", "repair_disc_pct", 4.0, 5, 12, 120, 4),
    ("r_log", "لجستیک و غنیمت", "logistics", "loot_pct", 3.0, 5, 18, 240, 5),
    ("r_int", "اطلاعات", "intelligence", "spy_pct", 4.0, 5, 10, 120, 5),
]

ALIASES = {
    "main": ["پنل هاپویی", "منوی جنگ هاپویی"],
    "war_room": ["اتاق جنگ هاپویی", "اتاق جنگ", "جنگ هاپویی", "پنل جنگ هاپویی"],
    "attack": ["حمله هاپویی", "حمله فردی هاپویی"],
    "clan_attack": ["حمله قبیله ای هاپویی", "حمله قبیله‌ای هاپویی", "حمله به قبیله هاپویی"],
    "clan": ["قبیله هاپویی"],
    "history": ["گزارش جنگ هاپویی"],
    "status": ["وضعیت جنگ هاپویی"],
    "units": ["تجهیزات هاپویی"],
    "resources": ["منابع هاپویی"],
    "xp": ["xp هاپویی", "ایکس پی هاپویی"],
    "profile": ["پروفایل هاپویی"],
    "quests": ["ماموریت هاپویی", "مأموریت هاپویی"],
    "treasury": ["خزانه هاپویی"],
    "diplomacy": ["دیپلماسی هاپویی"],
    "clan_war": ["جنگ قبیله هاپویی", "جنگ قبیله ای هاپویی"],
    "group_settings": ["تنظیمات جنگ هاپویی"],
}


def seed_defaults(session):
    """دیتای اولیه رو فقط برای جدول‌های خالی می‌ریزه (ادمین بعدش همه‌چیز رو عوض می‌کنه)."""
    import economy
    mult = float(db.cfg_get(session, "war_income_multiplier") or 3.5)

    def ref(level):
        prod, _, _ = economy.factory_level_values(session, max(1, int(level)))
        return prod * 60 * mult

    if session.query(WarBuildingDef).count() == 0:
        for (k, n, e, kind, mx, uth, vb, vg, va, cw, tw, free, vis, sort) in BUILDINGS:
            session.add(WarBuildingDef(key=k, name=n, emoji=e, kind=kind, max_level=mx, unlock_th=uth,
                                       value_base=vb, value_growth=vg, value_add=va, cost_weight=cw,
                                       time_weight=tw, free_start=free, visible_before=vis, sort=sort))
    if session.query(WarUnitDef).count() == 0:
        for (k, n, e, cat, tier, rar, atk, dfn, dur, acc, sp, hs, ts, cf, mat, rp, rs, mf, rth, rlv, vis, sort) in UNITS:
            r = ref(1 + (rth - 1) * 3)
            session.add(WarUnitDef(key=k, name=n, emoji=e, category=cat, tier=tier, rarity=rar, atk=atk, defn=dfn,
                                   durability=dur, accuracy=acc, special_power=sp, housing=hs, train_seconds=ts,
                                   cost=round(cf * r, -1), cost_mat=mat, repair_pct=rp, repair_seconds=rs,
                                   maint_per_hour=round(mf * r, 0), req_th=rth, req_level=rlv,
                                   visible_before=vis, sort=sort,
                                   req_achievement=""))
    if session.query(WarBattleType).count() == 0:
        for (k, n, e, mn, mx, fuel, ch, am, lm, cm, rl, xm, rm, mh, ft, sort) in BATTLE_TYPES:
            session.add(WarBattleType(key=k, name=n, emoji=e, min_seconds=mn, max_seconds=mx, fuel=fuel,
                                      cost_ref_hours=ch, atk_mult=am, loot_mult=lm, casualty_mult=cm,
                                      readiness_loss=rl, xp_mult=xm, reward_mult=rm, min_army_housing=mh,
                                      unlock_feature=ft, sort=sort))
    if session.query(WarUnlockRule).count() == 0:
        for (f, l, e, lv, th, cl, w, q, a, rs, h, v, s) in UNLOCKS:
            session.add(WarUnlockRule(feature=f, label=l, emoji=e, req_level=lv, req_th=th, req_clan_level=cl,
                                      req_wins=w, req_quest=q, req_achievement=a, req_research=rs, hint=h,
                                      visible_before=v, sort=s))
    if session.query(WarRewardRule).count() == 0:
        for (t, l, xp, cxp, ct, ha, hh, mat, lt, cap, capx, af) in RULES:
            session.add(WarRewardRule(trigger=t, label=l, xp=xp, clan_xp=cxp, contribution=ct, hop_abs=ha,
                                      hop_ref_hours=hh, materials=mat, ledger_type=lt, daily_cap_hop=cap,
                                      daily_cap_xp=capx, antifarm=af))
    if session.query(WarQuestDef).count() == 0:
        for (k, n, kind, m, tg, xp, hh, mat, cxp, uf, rl) in QUESTS:
            session.add(WarQuestDef(key=k, name=n, kind=kind, metric=m, target=tg, xp=xp, hop_ref_hours=hh,
                                    materials=mat, clan_xp=cxp, unlock_feature=uf, req_level=rl))
    if session.query(WarAchievementDef).count() == 0:
        for (k, n, e, m, th, xp, hh, mat, b) in ACHIEVEMENTS:
            session.add(WarAchievementDef(key=k, name=n, emoji=e, metric=m, threshold=th, xp=xp,
                                          hop_ref_hours=hh, materials=mat, badge=b))
    if session.query(WarResearchDef).count() == 0:
        for (k, n, br, ef, pl, mx, ch, tm, rc) in RESEARCH:
            session.add(WarResearchDef(key=k, name=n, branch=br, effect=ef, effect_per_level=pl, max_level=mx,
                                       cost_ref_hours=ch, time_minutes=tm, req_clan_level=rc))
    if session.query(WarAlias).count() == 0:
        from war_text import normalize
        for panel, texts in ALIASES.items():
            for t in texts:
                nt = normalize(t)
                if not session.query(WarAlias).filter_by(text=nt).first():
                    session.add(WarAlias(panel=panel, text=nt, builtin=True))
    if session.get(WarFormulaVersion, 1) is None:
        params = {k: db.cfg_get(session, k) for k in FORMULA_KEYS}
        session.add(WarFormulaVersion(version=1, params_json=json.dumps(params, ensure_ascii=False),
                                      note="نسخه‌ی اولیه"))
    if not float(db.cfg_get(session, "war_ref_calibration") or 0):
        db.cfg_set(session, "war_ref_calibration", str(ref(1)))
    session.commit()


def init_war():
    """بعد از db.init_db() صدا زده می‌شه (جدول‌ها قبلاً با Base.metadata.create_all ساخته شدن)."""
    Base.metadata.create_all(db.engine)
    s = db.get_session()
    try:
        existing = {c.key for c in s.query(db.Config).all()}
        for k, v in WAR_DEFAULT_CONFIG.items():
            if k not in existing:
                s.add(db.Config(key=k, value=v))
        s.commit()
        db.cfg_cache_clear()   # کلیدهایِ تازه‌سیدشده فوراً دیده بشن
        seed_defaults(s)
    finally:
        s.close()
